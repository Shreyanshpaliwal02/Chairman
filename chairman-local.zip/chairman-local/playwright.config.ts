import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./tests/browser",
  timeout: 60_000,
  expect: { timeout: 10_000 },
  workers: 1,
  fullyParallel: false,
  reporter: "list",
  use: { channel: "chrome", headless: true, screenshot: "only-on-failure", trace: "retain-on-failure" }
});
