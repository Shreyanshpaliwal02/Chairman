/**
 * Pure, deterministic helpers shared by the extension page script and the local service.
 * No DOM, Node or network APIs: the same input always produces the same output on both sides.
 */

/** Stable page-assistance field keys: `f` + 11 base-36 hash characters, optional ordinal for repeated identities. */
export const ASSIST_KEY = /^f[0-9a-z]{11}(?:-\d{1,2})?$/;

/** JSON with recursively sorted object keys, so hashes never depend on property insertion order. */
export function canonicalJson(value: unknown): string {
  return JSON.stringify(sortKeys(value));
}
function sortKeys(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(item => item === undefined ? null : sortKeys(item));
  if (value && typeof value === "object") {
    const result: Record<string, unknown> = {};
    for (const key of Object.keys(value).sort()) {
      const item = (value as Record<string, unknown>)[key];
      if (item !== undefined) result[key] = sortKeys(item);
    }
    return result;
  }
  return value;
}

/** cyrb53: fast 53-bit string hash. Used only for field identity, never for integrity. */
export function cyrb53(text: string, seed = 0): number {
  let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
  for (let index = 0; index < text.length; index++) {
    const code = text.charCodeAt(index);
    h1 = Math.imul(h1 ^ code, 2654435761);
    h2 = Math.imul(h2 ^ code, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507);
  h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507);
  h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}
export function stableFieldKey(identity: string): string {
  return `f${cyrb53(identity).toString(36).padStart(11, "0").slice(-11)}`;
}

export function normalizeText(text: string): string {
  return text.normalize("NFKC").toLowerCase().replace(/[‘’`´]/g, "'").replace(/[“”]/g, '"').replace(/\s+/g, " ").trim();
}
/** Question labels without required/optional markers and trailing punctuation. */
export function cleanQuestion(text: string, limit = 300): string {
  return text.replace(/\s+/g, " ").trim()
    .replace(/(?:\s*\((?:required|optional)\)|\s*[*✱]|\s*:)+\s*$/i, "").trim().slice(0, limit);
}

export interface ChoiceOption { value: string; label: string }
export type ChoiceMatch = { value: string; label: string; tier: ChoiceTier } | { error: "none" | "ambiguous" };
export type ChoiceTier = "value" | "label" | "core" | "synonym" | "boolean" | "range" | "country" | "tokens";

/** Closed equivalence groups for self-identification wording that differs across forms. No other meaning is inferred. */
const SYNONYM_GROUPS: readonly string[][] = [
  ["i don't wish to answer", "i do not wish to answer", "decline to self identify", "decline to self-identify", "i decline to self identify", "i decline to self-identify",
    "prefer not to say", "prefer not to answer", "i prefer not to answer", "i prefer not to say", "decline to answer", "choose not to disclose",
    "i choose not to disclose", "i do not wish to disclose", "i don't wish to disclose", "i do not want to answer", "i don't want to answer", "decline", "not declared"],
  ["male", "man", "cis man", "cisgender man"],
  ["female", "woman", "cis woman", "cisgender woman"],
  ["non-binary", "nonbinary", "non binary", "genderqueer", "gender non-conforming", "gender nonconforming"],
  ["i am not a protected veteran", "i am not a veteran", "not a protected veteran", "not a veteran", "no, i am not a protected veteran", "i'm not a protected veteran", "i am not a protected veteran."],
  ["i identify as one or more of the classifications of protected veteran", "i am a protected veteran", "protected veteran", "yes, i am a protected veteran",
    "i identify as a protected veteran", "i identify as one or more of the classifications of protected veterans"],
  ["no, i do not have a disability", "no, i don't have a disability", "i do not have a disability", "no disability",
    "no, i do not have a disability and have not had one in the past", "no, i don't have a disability and have not had one in the past"],
  ["yes, i have a disability (or previously had a disability)", "yes, i have a disability", "i have a disability",
    "yes, i have a disability, or have had one in the past", "yes, i have a disability or have a history/record of having a disability"],
  ["asian", "asian (not hispanic or latino)"],
  ["white", "white (not hispanic or latino)", "caucasian"],
  ["black or african american", "black or african american (not hispanic or latino)", "black", "african american"],
  ["hispanic or latino", "hispanic/latino", "hispanic", "latino", "latina", "latinx"],
  ["two or more races", "two or more races (not hispanic or latino)", "multiracial", "mixed race"],
];
function synonymGroup(text: string): number {
  const value = normalizeText(text).replace(/[.!]+$/, "");
  return SYNONYM_GROUPS.findIndex(group => group.includes(value));
}

const placeholderLabel = /^(?:[-–—._\s]*|(?:please\s+)?(?:select|choose|pick)(?:\s+(?:one|an?\s+option|an?\s+answer|from\s+the\s+list))?(?:\s*\.{3}|…)?|none selected|--\s*(?:select|choose)\s*--)$/i;
export function isPlaceholderOption(option: ChoiceOption): boolean {
  return !option.value.trim() || placeholderLabel.test(option.label.trim());
}

const stopWords = new Set(["a", "an", "the", "of", "in", "and", "or", "to", "for", "with", "at", "on", "i", "am", "my", "me", "is", "are", "be"]);
function core(text: string): string {
  return normalizeText(text).replace(/\([^)]*\)|\[[^\]]*\]/g, " ").replace(/'s\b/g, "")
    .replace(/[^\p{L}\p{N}+#\s]/gu, " ").replace(/\s+/g, " ").trim();
}
function tokens(text: string): string[] {
  return core(text).split(" ").filter(token => token && !stopWords.has(token));
}
export function booleanOf(text: string): boolean | undefined {
  const value = normalizeText(text).replace(/[.!]+$/, "");
  if (["yes", "true", "y"].includes(value)) return true;
  if (["no", "false", "n"].includes(value)) return false;
  return undefined;
}
function leadingBoolean(label: string): boolean | undefined {
  const value = normalizeText(label);
  if (/^yes\b/.test(value)) return true;
  if (/^no\b/.test(value) && !/^no\s+(?:preference|answer)\b/.test(value)) return false;
  return booleanOf(value);
}

/** Numeric option ranges such as "0-2 years", "3 to 5", "10+", "Less than 1 year", "More than 10". */
export function parseRange(label: string): { min: number; max: number } | undefined {
  const text = normalizeText(label).replace(/(\d),(\d{3})/g, "$1$2");
  const number = "(\\d+(?:\\.\\d+)?)";
  let match: RegExpMatchArray | null;
  if ((match = text.match(new RegExp(`^(?:less than|under|fewer than|below|<)\\s*${number}`)))) return { min: -Infinity, max: Number(match[1]) - 1e-9 };
  if ((match = text.match(new RegExp(`^(?:more than|over|above|greater than|>)\\s*${number}`)))) return { min: Number(match[1]) + 1e-9, max: Infinity };
  if ((match = text.match(new RegExp(`^${number}\\s*(?:\\+|or more\\b|and above\\b|and up\\b|plus\\b)`)))) return { min: Number(match[1]), max: Infinity };
  if ((match = text.match(new RegExp(`^${number}\\s*(?:-|–|—|to)\\s*${number}`)))) return { min: Number(match[1]), max: Number(match[2]) };
  if ((match = text.match(new RegExp(`^${number}(?:\\s*(?:years?|yrs?|months?|weeks?|days?))?$`)))) return { min: Number(match[1]), max: Number(match[1]) };
  return undefined;
}
const unitWords: Record<string, RegExp> = {
  years: /\b(?:months?|weeks?|days?|hours?)\b/, days: /\b(?:years?|months?|weeks?|hours?)\b/,
};

const isoCodes = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(" ");
const countryAliases: Record<string, string> = {
  usa: "US", "u s a": "US", "u s": "US", "united states of america": "US", america: "US", uk: "GB", "u k": "GB", britain: "GB",
  "great britain": "GB", england: "GB", "south korea": "KR", "korea republic of": "KR", "north korea": "KP", "czech republic": "CZ",
  turkey: "TR", türkiye: "TR", russia: "RU", "russian federation": "RU", vietnam: "VN", "viet nam": "VN", uae: "AE",
  "hong kong sar": "HK", "hong kong sar china": "HK", holland: "NL", "the netherlands": "NL",
};
let countryIndex: Map<string, string> | undefined;
function countryKey(text: string): string {
  return core(text.replace(/\./g, " ")).replace(/^the /, "");
}
/** ISO-3166 alpha-2 code for an English country name, closed alias, or an exact uppercase two-letter code. */
export function countryCode(text: string): string | undefined {
  const trimmed = text.trim();
  if (/^[A-Z]{2}$/.test(trimmed)) return isoCodes.includes(trimmed) ? trimmed : undefined;
  if (!countryIndex) {
    countryIndex = new Map(Object.entries(countryAliases).map(([name, code]) => [countryKey(name), code]));
    try {
      const names = new Intl.DisplayNames(["en"], { type: "region" });
      for (const code of isoCodes) {
        const name = names.of(code);
        if (name && name !== code) countryIndex.set(countryKey(name), code);
      }
    } catch { /* Aliases remain available without Intl region names. */ }
  }
  return countryIndex.get(countryKey(trimmed));
}

/**
 * Deterministic option choice. Tiers run strongest-first; a tier with several matches is ambiguous
 * and stops (a weaker tier never overrides an ambiguous stronger one). Placeholders never match.
 */
export function matchChoice(answer: string, options: ChoiceOption[], unit?: "years" | "days"): ChoiceMatch {
  const usable = options.filter(option => !isPlaceholderOption(option));
  const wanted = answer.trim();
  if (!wanted || !usable.length) return { error: "none" };
  const boolean = booleanOf(wanted);
  const numeric = /^\d+(?:\.\d+)?$/.test(wanted) ? Number(wanted) : undefined;
  const country = countryCode(wanted);
  const wantedTokens = tokens(wanted);
  const tiers: [ChoiceTier, (option: ChoiceOption) => boolean][] = [
    ["value", option => option.value === wanted],
    ["label", option => normalizeText(option.label) === normalizeText(wanted)],
    ["core", option => !!core(wanted) && core(option.label) === core(wanted)],
    ["synonym", option => synonymGroup(wanted) >= 0 && synonymGroup(option.label) === synonymGroup(wanted)],
    ["boolean", option => boolean !== undefined && leadingBoolean(option.label) === boolean],
    ["range", option => {
      if (numeric === undefined || (unit && unitWords[unit].test(normalizeText(option.label)))) return false;
      const range = parseRange(option.label);
      return !!range && numeric >= range.min && numeric <= range.max;
    }],
    ["country", option => !!country && (countryCode(option.label) === country || countryCode(option.value) === country)],
    ["tokens", option => {
      if (boolean !== undefined || numeric !== undefined) return false;
      const optionTokens = tokens(option.label);
      if (!optionTokens.length || !wantedTokens.length) return false;
      const contains = (whole: string[], part: string[]) => part.every(token => whole.includes(token));
      return (core(wanted).length >= 3 && contains(optionTokens, wantedTokens))
        || (core(option.label).length >= 3 && contains(wantedTokens, optionTokens));
    }],
  ];
  for (const [tier, test] of tiers) {
    const matches = usable.filter(test);
    if (matches.length === 1) return { value: matches[0].value, label: matches[0].label, tier };
    if (matches.length > 1) return { error: "ambiguous" };
  }
  return { error: "none" };
}

export interface FieldConstraints { type?: string; pattern?: string; maxLength?: number; minLength?: number; placeholder?: string; label?: string }

function compilePattern(pattern: string): RegExp | undefined {
  if (!pattern || pattern.length > 500) return undefined;
  for (const flags of ["v", "u"]) {
    try { return new RegExp(`^(?:${pattern})$`, flags); } catch { /* Try the older HTML pattern flag set. */ }
  }
  return undefined;
}
/** Mirrors the browser's own constraint validation for the attributes Chairman can see. */
export function fitsConstraints(value: string, field: FieldConstraints): boolean {
  if (field.maxLength !== undefined && field.maxLength >= 0 && value.length > field.maxLength) return false;
  if (field.minLength !== undefined && field.minLength > 0 && value.length < field.minLength) return false;
  const pattern = field.pattern ? compilePattern(field.pattern) : undefined;
  if (pattern && !pattern.test(value)) return false;
  if (field.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return false;
  if (field.type === "number" && !/^-?(?:\d+(?:\.\d+)?|\.\d+)$/.test(value)) return false;
  if (field.type === "date" && !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  if (field.type === "url") {
    try { if (!/^https?:$/.test(new URL(value).protocol)) return false; } catch { return false; }
  }
  return true;
}

const dateTokens = /\b(MM|DD|YYYY|YY)([/.\-])(MM|DD|YYYY|YY)(?:\2(MM|DD|YYYY|YY))?\b/i;
/** Formats an ISO date for a placeholder/message pattern such as MM/DD/YYYY. */
export function formatDateLike(iso: string, hint: string): string | undefined {
  const date = iso.match(/^(\d{4})-(\d{2})-(\d{2})$/), format = hint.match(dateTokens);
  if (!date || !format) return undefined;
  const parts: Record<string, string> = { YYYY: date[1], YY: date[1].slice(2), MM: date[2], DD: date[3] };
  const order = [format[1], format[3], format[4]].filter(Boolean).map(token => token.toUpperCase());
  if (new Set(order).size !== order.length || !order.includes("MM") || (!order.includes("YYYY") && !order.includes("YY"))) return undefined;
  return order.map(token => parts[token]).join(format[2]);
}

const phoneLabel = /\b(?:phone|mobile|telephone|cell|contact number|whatsapp)\b/i;
const urlLabel = /\b(?:url|website|web site|linkedin|github|portfolio|homepage|link)\b/i;
/**
 * Format-only rewrites of an already approved value, strongest evidence first. Every candidate
 * preserves the original information (digit suffix, date parts, number, URL body); nothing new is invented.
 */
export function formatCandidates(value: string, field: FieldConstraints, message = ""): { value: string; reason: string }[] {
  const text = value.trim(), hints = `${field.placeholder ?? ""} ${message}`, result: { value: string; reason: string }[] = [];
  const add = (candidate: string, reason: string) => {
    if (candidate && !result.some(item => item.value === candidate)) result.push({ value: candidate, reason });
  };
  if (text !== value) add(text, "Removed surrounding spaces.");
  const label = field.label ?? "";
  if (field.type === "tel" || phoneLabel.test(label)) {
    const digits = text.replace(/\D/g, "");
    if (digits.length >= 7 && digits.length <= 15) {
      const national = digits.length > 10 ? digits.slice(-10) : digits;
      const preferNational = /\b10[- ]?digits?\b|without (?:the )?country code|national/i.test(message);
      const preferDigits = /\b(?:digits?|numbers?|numeric)\s+only\b|only\s+(?:digits?|numbers?)/i.test(message);
      const preferInternational = /country code|international|e\.?164|\+/i.test(message);
      const ordered: [string, string][] = [
        ...(preferNational ? [[national, "Used the national number without the country code."] as [string, string]] : []),
        ...(preferDigits ? [[digits, "Removed spaces and punctuation from the phone number."] as [string, string]] : []),
        ...(preferInternational ? [[`+${digits}`, "Used international format with the country code."] as [string, string]] : []),
        [`+${digits}`, "Used international format with the country code."],
        [digits, "Removed spaces and punctuation from the phone number."],
        [national, "Used the national number without the country code."],
      ];
      for (const [candidate, reason] of ordered) add(candidate, reason);
    }
  }
  if ((field.type === "url" || urlLabel.test(label)) && text && !/^[a-z][a-z0-9+.-]*:/i.test(text) && /^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(text))
    add(`https://${text}`, "Added https:// to the web address.");
  if (/^\d{4}-\d{2}-\d{2}$/.test(text)) {
    const formatted = formatDateLike(text, hints);
    if (formatted) add(formatted, "Reformatted the date to the requested pattern.");
  }
  if (field.type === "number" || /\b(?:number|numeric|digits?)\b/i.test(message)) {
    const numbers = text.replace(/(\d),(\d{3})\b/g, "$1$2").match(/-?\d+(?:\.\d+)?/g) ?? [];
    if (numbers.length === 1 && numbers[0] !== text) add(numbers[0], "Kept only the number.");
  }
  if (field.type === "email" && /^mailto:/i.test(text)) add(text.replace(/^mailto:/i, ""), "Removed mailto: from the email.");
  return result;
}

/** Picks the first format-only candidate that satisfies the visible constraints; undefined when none is safe. */
export function adaptToField(value: string, field: FieldConstraints, message = ""): { value: string; reason: string } | undefined {
  if (fitsConstraints(value, field) && !message) return undefined;
  const constrained = !!(field.pattern || field.maxLength !== undefined || field.minLength !== undefined || ["email", "url", "number", "date"].includes(field.type ?? ""));
  for (const candidate of formatCandidates(value, field, message)) {
    if (candidate.value === value) continue;
    if (constrained ? fitsConstraints(candidate.value, field) : !!message) return candidate;
  }
  return undefined;
}

/** Autocomplete tokens are explicit site semantics; they map to the same canonical answer keys as labels. */
export const AUTOCOMPLETE_MEANINGS: Readonly<Record<string, string>> = Object.freeze({
  name: "name", "given-name": "first_name", "family-name": "last_name", email: "email", tel: "phone", "tel-national": "phone",
  "address-level2": "city", "country-name": "country", country: "country", "postal-code": "postal_code",
});
export function autocompleteMeaning(value: string | undefined): string | undefined {
  const tokens = (value ?? "").toLowerCase().split(/\s+/).filter(token => token && !/^(?:section-.*|shipping|billing|home|work|mobile|fax|pager|on|off)$/.test(token));
  return tokens.length === 1 ? AUTOCOMPLETE_MEANINGS[tokens[0]] : undefined;
}

/** Comparable form of a field value, tolerant of presentation-only differences (masks, spacing, case). */
export function comparableValue(type: string, value: string): string {
  const text = value.normalize("NFKC").replace(/\s+/g, " ").trim();
  if (type === "tel") return text.replace(/\D/g, "");
  if (type === "number") return Number.isFinite(Number(text)) && text !== "" ? String(Number(text)) : text;
  if (type === "email" || type === "url" || type === "combobox") return text.toLowerCase();
  return text;
}
export function sameComparable(type: string, expected: string, actual: string): boolean {
  const a = comparableValue(type, expected), b = comparableValue(type, actual);
  if (a === b) return true;
  // Phone masks can drop or add a country code; the remaining digits must still agree.
  return type === "tel" && a.length >= 7 && b.length >= 7 && (a.endsWith(b) || b.endsWith(a));
}

/** Closed-synonym option match only (safe for unattended use): exactly one option in the answer's equivalence group. */
export function synonymChoice(answer: string, options: ChoiceOption[]): ChoiceOption | undefined {
  const group = synonymGroup(answer);
  if (group < 0) return undefined;
  const matches = options.filter(option => !isPlaceholderOption(option) && synonymGroup(option.label) === group);
  return matches.length === 1 ? matches[0] : undefined;
}
