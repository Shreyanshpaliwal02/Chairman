import type { Job, KeywordAnalysis, KeywordEvidence, Profile } from "./types.js";

type Concept = { aliases: readonly string[]; caseSensitive?: boolean };
// Closed, reviewed equivalences only: a tool, its vendor, and a neighboring platform are not synonyms.
const concepts: readonly Concept[] = [
  { aliases: ["infrastructure as code", "infrastructure-as-code", "IaC"] },
  { aliases: ["Kubernetes", "K8s"] },
  { aliases: ["Amazon Web Services", "AWS"] },
  { aliases: ["Google Cloud Platform", "Google Cloud", "GCP"] },
  { aliases: ["Microsoft Azure", "Azure"] },
  { aliases: ["Amazon S3", "AWS S3", "S3"] },
  { aliases: ["Amazon EC2", "AWS EC2", "EC2"] },
  { aliases: ["AWS Lambda", "Amazon Lambda"] },
  { aliases: ["Amazon EKS", "AWS EKS", "EKS"] },
  { aliases: ["Azure DevOps"] },
  { aliases: ["Terraform"] }, { aliases: ["CloudFormation"] }, { aliases: ["Pulumi"] },
  { aliases: ["Ansible"] }, { aliases: ["Docker"] }, { aliases: ["Helm"] },
  { aliases: ["Linux"] }, { aliases: ["Unix"] },
  { aliases: ["continuous integration", "CI"] },
  { aliases: ["continuous delivery"] }, { aliases: ["continuous deployment"] },
  { aliases: ["continuous integration and continuous delivery", "continuous integration/continuous delivery", "CI/CD"] },
  { aliases: ["GitHub Actions"] }, { aliases: ["GitLab CI"] }, { aliases: ["Jenkins"] },
  { aliases: ["Git"] }, { aliases: ["Bash"] }, { aliases: ["PowerShell"] },
  { aliases: ["Python"] }, { aliases: ["JavaScript", "JS"] }, { aliases: ["TypeScript", "TS"] },
  { aliases: ["Java"] }, { aliases: ["Kotlin"] }, { aliases: ["Scala"] }, { aliases: ["Rust"] },
  { aliases: ["Golang", "Go"], caseSensitive: true },
  { aliases: ["C++"], caseSensitive: true }, { aliases: ["C#"], caseSensitive: true },
  { aliases: ["C"], caseSensitive: true }, { aliases: ["R"], caseSensitive: true },
  { aliases: [".NET", "dotnet"] }, { aliases: ["Ruby"] }, { aliases: ["PHP"] }, { aliases: ["Swift"] },
  { aliases: ["Node.js", "NodeJS"] }, { aliases: ["React.js", "ReactJS", "React"] },
  { aliases: ["React Native"] }, { aliases: ["Angular"] }, { aliases: ["Vue.js", "VueJS", "Vue"] },
  { aliases: ["Django"] }, { aliases: ["Flask"] }, { aliases: ["FastAPI"] }, { aliases: ["Spring Boot"] },
  { aliases: ["PostgreSQL", "Postgres"] }, { aliases: ["MySQL"] }, { aliases: ["SQL"] },
  { aliases: ["MongoDB"] }, { aliases: ["Redis"] }, { aliases: ["Elasticsearch"] },
  { aliases: ["Apache Spark", "Spark"] }, { aliases: ["PySpark"] },
  { aliases: ["Databricks"] }, { aliases: ["Snowflake"] },
  { aliases: ["Google BigQuery", "BigQuery"] }, { aliases: ["Amazon Redshift", "Redshift"] },
  { aliases: ["Apache Airflow", "Airflow"] }, { aliases: ["Dagster"] }, { aliases: ["Prefect"] },
  { aliases: ["Apache Kafka", "Kafka"] }, { aliases: ["Apache Flink", "Flink"] },
  { aliases: ["Apache Hadoop", "Hadoop"] }, { aliases: ["dbt"] },
  { aliases: ["extract transform load", "extract, transform, load", "ETL"] },
  { aliases: ["extract load transform", "extract, load, transform", "ELT"] },
  { aliases: ["data pipelines"] }, { aliases: ["data warehousing"] }, { aliases: ["data modeling", "data modelling"] },
  { aliases: ["machine learning", "ML"] }, { aliases: ["deep learning"] },
  { aliases: ["MLOps", "machine learning operations"] },
  { aliases: ["MLflow"] }, { aliases: ["Kubeflow"] },
  { aliases: ["Amazon SageMaker", "AWS SageMaker", "SageMaker"] }, { aliases: ["Vertex AI"] },
  { aliases: ["PyTorch"] }, { aliases: ["TensorFlow"] }, { aliases: ["scikit-learn", "sklearn"] },
  { aliases: ["pandas"] }, { aliases: ["NumPy"] },
  { aliases: ["large language models", "large language model", "LLMs", "LLM"] },
  { aliases: ["retrieval augmented generation", "retrieval-augmented generation", "RAG"] },
  { aliases: ["RESTful", "REST"] }, { aliases: ["GraphQL"] }, { aliases: ["gRPC"] },
  { aliases: ["OpenTelemetry", "OTel"] }, { aliases: ["Prometheus"] }, { aliases: ["Grafana"] },
  { aliases: ["distributed systems"] }, { aliases: ["microservices"] },
  { aliases: ["customer-facing", "customer facing"] }, { aliases: ["stakeholder communication"] },
];

export const PUBLIC_KEYWORD_TOKENS: readonly string[] = Object.freeze(concepts.map((concept) => concept.aliases[0]));

/** Emits reviewed canonical vocabulary only, never source text or custom skills. */
export function publicKeywordTags(text: string, requireAffirmative = true): string[] {
  const found = new Set(mentions(text.slice(0, 100_000), concepts)
    .filter((mention) => !requireAffirmative || affirmative(text, mention))
    .map((mention) => mention.concept.aliases[0]));
  return PUBLIC_KEYWORD_TOKENS.filter((token) => found.has(token));
}

// Directional review suggestions, never evidence of possessing the destination skill.
const transferableFrom: Readonly<Record<string, readonly string[]>> = {
  Databricks: ["Apache Spark", "PySpark"],
  "Apache Spark": ["Databricks", "Apache Flink", "PySpark"],
  PySpark: ["Apache Spark"],
  Snowflake: ["Google BigQuery", "Amazon Redshift"],
  "Google BigQuery": ["Snowflake", "Amazon Redshift"],
  "Amazon Redshift": ["Snowflake", "Google BigQuery"],
  "Apache Airflow": ["Dagster", "Prefect"],
  Dagster: ["Apache Airflow", "Prefect"],
  Prefect: ["Apache Airflow", "Dagster"],
  "Microsoft Azure": ["Amazon Web Services", "Google Cloud Platform"],
  "Amazon Web Services": ["Microsoft Azure", "Google Cloud Platform"],
  "Google Cloud Platform": ["Microsoft Azure", "Amazon Web Services"],
  Kubernetes: ["Docker"],
  PyTorch: ["TensorFlow"],
  TensorFlow: ["PyTorch"],
};

type Mention = { term: string; concept: Concept; start: number; end: number };
type Source = { text: string; factId?: string; skill?: string; mentions: Mention[] };
const fold = (value: string): string => value.toLowerCase();
const unsafeText = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]/u;

function mentions(text: string, vocabulary: readonly Concept[]): Mention[] {
  const found: Mention[] = [];
  for (const concept of vocabulary) {
    for (const alias of concept.aliases) {
      const escaped = alias.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const pattern = new RegExp(`(?<![\\p{L}\\p{N}_+#&])${escaped}(?![\\p{L}\\p{N}_+#&])`, concept.caseSensitive ? "gu" : "giu");
      for (const match of text.matchAll(pattern)) {
        found.push({ term: match[0], concept, start: match.index, end: match.index + match[0].length });
      }
    }
  }
  // Prefer whole products/phrases: React Native is not React, Azure DevOps is not Azure.
  const whole: Mention[] = [];
  for (const mention of found.sort((a, b) => (b.end - b.start) - (a.end - a.start) || a.start - b.start)) {
    if (!whole.some((other) => mention.start < other.end && other.start < mention.end)) whole.push(mention);
  }
  return whole.sort((a, b) => a.start - b.start);
}

function affirmative(text: string, mention: Mention): boolean {
  const before = text.slice(0, mention.start).split(/[.!?;\n]/u).at(-1)!.slice(-180);
  const after = text.slice(mention.end).split(/[.!?;\n]/u)[0].slice(0, 180);
  const clause = `${before} ${mention.term} ${after}`;
  const token = text.slice(0, mention.start).split(/\s/u).at(-1)! + text.slice(mention.start).split(/\s/u)[0];
  if (/:\/\/|@/u.test(token)) return false;
  if (/\b(?:no|not|never|without|lack(?:s|ed|ing)?|unfamiliar|learn(?:ing)?|studying|interested|aspir(?:e|ing)|want|wish|plan(?:ned|ning)?|future|willing|could|would|should|ignore|pretend|invent|claim|add)\b/iu.test(before)) return false;
  if (/\b(?:similar to|equivalent to|transferable|easy to learn|quickly learn|not yet|no (?:hands-on )?experience|not (?:used|known)|never used)\b/iu.test(clause)) return false;
  if (/\b(?:can|could|will|would|should|must)\s+(?:be\s+)?(?:learned|learn|claimed|added)\b/iu.test(clause)) return false;
  if (/^\s*[-:([]?\s*(?:learning|to learn|theory only|planned|unverified)\b/iu.test(after)) return false;
  if (/^\s*(?:experience\s+)?(?:is\s+|was\s+)?(?:absent|missing|limited to theory|not\b|never\b|unknown\b|unfamiliar\b)/iu.test(after)) return false;
  return true;
}

function evidence(term: string, kind: KeywordEvidence["kind"], sources: Source[], explanation: string): KeywordEvidence {
  return {
    term, kind,
    factIds: [...new Set(sources.flatMap((source) => source.factId ? [source.factId] : []))],
    sourceSkills: [...new Set(sources.flatMap((source) => source.skill ? [source.skill] : []))],
    explanation,
  };
}

/**
 * Bounded, deterministic term analysis, not an assessment of proficiency.
 * Only title/description supply JD terms. Only affirmative confirmed fact text
 * and skills from a confirmed profile supply evidence; metadata/answers/links do not.
 * Unknown vocabulary is omitted unless it is an exact supplied skill. Negated,
 * hypothetical and learning-only mentions are conservatively excluded.
 */
export function analyzeKeywords(profile: Profile, job: Job): KeywordAnalysis {
  const skills = profile.skills.slice(0, 150).filter((skill) => skill.trim() && skill.length <= 200 && !unsafeText.test(skill));
  const custom = skills.filter((skill) => !mentions(skill, concepts).length)
    .map((skill): Concept => ({ aliases: [skill] }));
  const vocabulary = [...concepts, ...custom];
  const sourceValues = [
    ...profile.facts.slice(0, 300).filter((fact) => fact.confirmed === true && fact.text.trim() && !unsafeText.test(fact.text))
      .map((fact) => ({ text: fact.text.slice(0, 8_000), factId: fact.id })),
    ...(profile.confirmed === true ? skills.map((skill) => ({ text: skill, skill })) : []),
  ];
  const sources: Source[] = sourceValues.map((source) => ({
    ...source, mentions: mentions(source.text, vocabulary).filter((mention) => affirmative(source.text, mention)),
  }));
  const result: KeywordAnalysis = { supported: [], transferable: [], gaps: [] };
  const seen = new Set<string>();
  for (const mention of mentions(`${job.title}\n${job.description}`.slice(0, 100_000), vocabulary)) {
    const key = fold(mention.term);
    if (seen.has(key)) continue;
    seen.add(key);
    const matching = sources.filter((source) => source.mentions.some((item) => item.concept === mention.concept));
    const direct = matching.filter((source) => source.mentions.some((item) => fold(item.term) === key));
    if (direct.length) {
      result.supported.push(evidence(mention.term, "direct", direct, "Exact JD term appears in affirmative confirmed source text or a confirmed profile skill; no proficiency level is inferred."));
    } else if (matching.length) {
      const aliases = [...new Set(matching.flatMap((source) => source.mentions
        .filter((item) => item.concept === mention.concept).map((item) => item.term)))];
      result.supported.push(evidence(mention.term, "equivalent", matching, `Documented name/abbreviation equivalent of ${aliases.join(", ")}; no additional platform experience is inferred.`));
    } else {
      const related = transferableFrom[mention.concept.aliases[0]] ?? [];
      const transferable = sources.filter((source) => source.mentions.some((item) => related.includes(item.concept.aliases[0])));
      if (transferable.length) {
        result.transferable.push(evidence(mention.term, "transferable", transferable, `Related source technology (${related.filter((name) => transferable.some((source) => source.mentions.some((item) => item.concept.aliases[0] === name))).join(", ")}), not an equivalent. ${mention.term} experience is unverified; review or learning only, never a possessed skill.`));
      } else {
        result.gaps.push(mention.term);
      }
    }
  }
  return result;
}
