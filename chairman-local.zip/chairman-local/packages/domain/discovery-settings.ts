import type { Source } from "./types.js";

export interface ConfiguredSource extends Source {
  discoveryEnabled?: boolean;
  nextScanAt?: string;
}

export interface SearchPortal {
  id: string;
  label: string;
  urlTemplate: string;
  builtIn: boolean;
}

export interface SearchPortalList { portals: SearchPortal[] }

export function validateSearchTemplate(value: string): string {
  const template = value.trim();
  if (!template || template.length > 2000) throw new Error("Enter a search URL of at most 2,000 characters.");
  if (/[{}]/.test(template.replaceAll("{role}", "").replaceAll("{location}", "")))
    throw new Error("Only {role} and {location} placeholders are supported.");
  let url: URL;
  try { url = new URL(template.replaceAll("{role}", "engineer").replaceAll("{location}", "worldwide")); }
  catch { throw new Error("Enter a valid HTTPS search URL."); }
  if (url.protocol !== "https:" || url.username || url.password)
    throw new Error("Use an HTTPS URL without a username or password.");
  const hostname = url.hostname.toLowerCase();
  if (!hostname.includes(".") || hostname === "localhost" || hostname.endsWith(".localhost") || hostname.endsWith(".local")
    || hostname.endsWith(".internal") || /^\[|^[\d.]+$/.test(hostname))
    throw new Error("Use a public website hostname, not a local address or IP.");
  if (/^https:\/\/[^/?#]*[{}]/i.test(template))
    throw new Error("Placeholders belong in the path or query, not the website hostname.");
  return template;
}

export function searchPortalUrl(template: string, role: string, location: string): string {
  return validateSearchTemplate(template).replaceAll("{role}", encodeURIComponent(role.trim())).replaceAll("{location}", encodeURIComponent(location.trim()));
}
