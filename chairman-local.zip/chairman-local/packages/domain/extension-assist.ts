import type { FormSnapshot, Packet, ResumeVariant } from "./types.js";
import { canonicalJson } from "./assist-match.js";

export type AssistanceStatus = "detected" | "prepared" | "fill_intent" | "filled" | "manual_required" | "submission_unknown" | "submitted_confirmed" | "abandoned" | "queued";
export interface AssistanceRecord {
  id: string;
  jobId: string;
  packetId?: string;
  sourceUrl: string;
  company: string;
  title: string;
  portal: string;
  status: AssistanceStatus;
  notes: string;
  blockers: string[];
  createdAt: string;
  updatedAt: string;
  filledAt?: string;
  submittedAt?: string;
  confirmation?: string;
  /** SHA-256 of comparableValue(type, value) for each value Chairman actually filled most recently. Never the values. */
  lastFill?: { url: string; at: string; values: Record<string, string> };
  /** Reviewed format repairs suggested after the site reported validation errors. */
  repairs?: AssistRepair[];
  /** Where Chairman left this application in its Chrome tab. */
  stage?: { name: "working" | "needs_you" | "review" | "submitted"; detail: string; at: string };
}
/**
 * Wording employers show once an application has been submitted ("Thank you for applying", "Your application has been
 * received"). The extension reports such a page only from the tab you applied in; the service checks the same wording.
 */
export const CONFIRMATION_TEXT = /\b(?:thank(?:s| you) for (?:applying|your application|submitting(?: your application)?)|(?:your )?application (?:has been |was |is )?(?:successfully )?(?:submitted|received|sent|completed?)\b(?! (?:by|before|on or before|until))|we(?:'ve| have) (?:successfully )?received your application|you(?:'ve| have) (?:successfully )?(?:applied|submitted your application)|successfully (?:applied|submitted)|application submitted)/i;
export interface CapturedJob {
  title: string;
  company: string;
  location: string;
  description: string;
  evidence: "JobPosting" | "visible-description";
}
export interface EmbeddedForm { url: string; host: string }
export interface AssistancePage {
  url: string;
  kind: "job" | "form" | "listing" | "unsupported";
  /** Visible page heading (or document title); informational, excluded from the fingerprint. */
  title: string;
  job?: CapturedJob;
  snapshot: FormSnapshot;
  occupied: string[];
  fingerprint: string;
  blockers: string[];
  embedded?: EmbeddedForm;
}
export interface AssistanceReview {
  record: AssistanceRecord;
  packet?: Packet;
  variants: ResumeVariant[];
  suggestedVariantId?: string;
  suggestion?: string;
  factOptions: { id: string; text: string; category: string }[];
  skillOptions: string[];
  fields: Record<string, string>;
  blockers: string[];
}

export type AssistPlanSource = "profile" | "answers" | "remembered" | "acknowledgement" | "ai_mapped" | "ai_option" | "ai_draft" | "repair" | "manual";
export interface AssistPlanItem {
  key: string;
  label: string;
  type: string;
  required: boolean;
  /** Exact value to fill; for select/radio this is the option value. */
  value?: string;
  /** Human-readable value, e.g. the option label. */
  display?: string;
  source: AssistPlanSource;
  detail?: string;
  /** AI-derived and repaired values are highlighted for review. */
  review: boolean;
  include: boolean;
  /** Replaces a value Chairman filled earlier (only if the page still holds exactly that value). */
  overwrite?: boolean;
  reason?: string;
  options?: { value: string; label: string }[];
  maxLength?: number;
}
export interface AssistResumeOption { id: string; label: string; format: "pdf" | "docx"; sha256: string; source: "packet" | "baseline" }
export interface AssistAiSummary {
  enabled: boolean;
  available: boolean;
  provider?: string;
  model?: string;
  remote?: boolean;
  asked: number;
  cached: number;
  reason?: string;
}
/** Value-free diagnostic step (labels, counts, sources and errors; never answers, contact details or files). */
export interface AssistDebugStep { step: string; detail?: string; ok?: false }
export interface AssistPlan {
  recordId: string;
  url: string;
  pageFingerprint: string;
  items: AssistPlanItem[];
  resume?: { key: string; label: string; required: boolean; options: AssistResumeOption[]; selected?: string; reason?: string };
  blockers: string[];
  ai: AssistAiSummary;
  planHash: string;
  debug?: AssistDebugStep[];
}
/** A reviewed fix after the site rejected a value: a format-only rewrite, an AI-shortened draft, or the site's options to pick from. */
export interface AssistRepair { key: string; value: string; display?: string; options?: string[]; reason: string; source: "repair" | "ai_repair" }
export interface AssistanceGrant {
  id: string;
  recordId: string;
  packetId?: string;
  url: string;
  pageFingerprint: string;
  expiresAt: number;
  fields: Record<string, string>;
  /** Keys that may replace Chairman's own earlier value; maps key -> SHA-256 of comparableValue(type, value expected on the page). */
  overwrite?: Record<string, string>;
  resume?: { key: string; filename: string; mime: string; base64: string; sha256: string };
}
export interface AssistFillError { key: string; message: string; options?: string[] }
export interface AssistanceFillResult {
  filled: string[];
  preserved: string[];
  skipped: { key: string; reason: string }[];
  errors: AssistFillError[];
  newFields: number;
  blockers: string[];
}

/** Structural snapshot payload: labels, types, options and requiredness, never current values or live hint/error text. */
export function assistanceSnapshotPayload(snapshot: Omit<FormSnapshot, "fingerprint"> | FormSnapshot): string {
  return canonicalJson({ v: 2, url: snapshot.url, fields: snapshot.fields.map(({ hint: _hint, ...field }) => field),
    hasCaptcha: snapshot.hasCaptcha, hasLegal: snapshot.hasLegal, unsupported: snapshot.unsupported });
}

/**
 * Page fingerprint shared by the isolated content script and local service. It covers structure only:
 * typing into the page, volatile titles, description text and informational blockers do not invalidate a reviewed plan.
 */
export function assistancePagePayload(page: Omit<AssistancePage, "fingerprint"> | AssistancePage): string {
  return canonicalJson({ v: 2, url: page.url, kind: page.kind,
    job: page.job ? { title: page.job.title, company: page.job.company, evidence: page.job.evidence } : null,
    snapshot: JSON.parse(assistanceSnapshotPayload(page.snapshot)), embedded: page.embedded ?? null });
}

/** Human-readable, value-free structural difference between a reviewed page and the current one. */
export function pageDifference(before: AssistancePage, after: AssistancePage): string {
  const changes: string[] = [];
  if (before.url !== after.url) changes.push("the URL changed");
  const left = new Map(before.snapshot.fields.map(field => [field.key, field])), right = new Map(after.snapshot.fields.map(field => [field.key, field]));
  for (const [key, field] of right) if (!left.has(key)) changes.push(`new question "${field.label}"`);
  for (const [key, field] of left) if (!right.has(key)) changes.push(`"${field.label}" disappeared`);
  for (const [key, field] of left) {
    const other = right.get(key);
    if (!other) continue;
    const kinds = [field.label !== other.label ? "label" : "", field.type !== other.type ? "type" : "", field.required !== other.required ? (other.required ? "now required" : "no longer required") : "",
      canonicalJson([field.options, field.optionLabels ?? null]) !== canonicalJson([other.options, other.optionLabels ?? null]) ? "options" : "",
      canonicalJson([field.placeholder ?? null, field.pattern ?? null, field.maxLength ?? null, field.minLength ?? null, field.accept ?? null, field.autocomplete ?? null])
        !== canonicalJson([other.placeholder ?? null, other.pattern ?? null, other.maxLength ?? null, other.minLength ?? null, other.accept ?? null, other.autocomplete ?? null]) ? "input rules" : ""].filter(Boolean);
    if (kinds.length) changes.push(`"${other.label}" changed (${kinds.join(", ")})`);
  }
  if (before.snapshot.hasCaptcha !== after.snapshot.hasCaptcha) changes.push(after.snapshot.hasCaptcha ? "a CAPTCHA challenge opened" : "a CAPTCHA challenge closed");
  if (before.snapshot.hasLegal !== after.snapshot.hasLegal) changes.push("consent/declaration questions changed");
  if (canonicalJson(before.snapshot.unsupported) !== canonicalJson(after.snapshot.unsupported)) changes.push("manual-only questions changed");
  if (before.kind !== after.kind || before.job?.title !== after.job?.title || before.job?.company !== after.job?.company) changes.push("the job details changed");
  if (canonicalJson(before.embedded ?? null) !== canonicalJson(after.embedded ?? null)) changes.push("the embedded form changed");
  return changes.slice(0, 10).join("; ") || "the page structure changed";
}
