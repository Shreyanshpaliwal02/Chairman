export function localDate(now = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit" }).format(now);
}
export function validDate(value: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(`${value}T00:00:00Z`))
    && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value;
}
export function shiftDate(value: string, days: number): string {
  if (!validDate(value)) throw new Error("Invalid calendar date.");
  return new Date(Date.parse(`${value}T00:00:00Z`) + days * 86400_000).toISOString().slice(0, 10);
}
export function daysBetween(start: string, end: string): number {
  if (!validDate(start) || !validDate(end)) throw new Error("Invalid calendar date.");
  return Math.round((Date.parse(`${end}T00:00:00Z`) - Date.parse(`${start}T00:00:00Z`)) / 86400_000);
}
