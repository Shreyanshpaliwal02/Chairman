/**
 * Standard application questions. Each entry is an answer-bank key (profile.answers[key]) with the wordings forms use.
 * The dashboard renders this catalog for you to answer once; the resolver uses the same wordings to recognize questions.
 * Answers come only from you: nothing here is ever inferred from your resume.
 */
export type QuestionCategory = "identity" | "contact" | "location" | "eligibility" | "preferences" | "availability" | "experience"
  | "education" | "company" | "background" | "disclosures";
export type QuestionKind = "text" | "textarea" | "number" | "date" | "yesno" | "choice" | "url";
export interface BankQuestion {
  key: string;
  label: string;
  category: QuestionCategory;
  kind: QuestionKind;
  aliases: string[];
  choices?: string[];
  help?: string;
  /** Answered by your profile's contact details instead of the answer bank. */
  profileField?: "name" | "email" | "phone" | "location";
  /** Voluntary self-identification (keys start with eeo_): filled from your saved answer only when you enable disclosures. */
  disclosure?: true;
  unit?: "years" | "days";
}
export const QUESTION_CATEGORIES: Readonly<Record<QuestionCategory, string>> = Object.freeze({
  identity: "Identity", contact: "Contact & links", location: "Location", eligibility: "Work eligibility & visa",
  preferences: "Work preferences", availability: "Availability & compensation", experience: "Experience", education: "Education",
  company: "About this application", background: "Checks & clearances", disclosures: "Voluntary self-identification (EEO)",
});
const DECLINE = "I don't wish to answer";
export const DECLINE_ANSWER = DECLINE;

export const QUESTION_BANK: readonly BankQuestion[] = Object.freeze([
  { key: "name", label: "Full name", category: "identity", kind: "text", profileField: "name", aliases: [] },
  { key: "first_name", label: "First name", category: "identity", kind: "text", aliases: [] },
  { key: "last_name", label: "Last name", category: "identity", kind: "text", aliases: [] },
  { key: "preferred_name", label: "Preferred first name", category: "identity", kind: "text",
    aliases: ["preferred name", "preferred first name", "what name do you go by?", "nickname", "name you go by"] },
  { key: "eeo_pronouns", label: "Pronouns", category: "disclosures", kind: "text", disclosure: true,
    aliases: ["pronouns", "your pronouns", "preferred pronouns", "what are your pronouns?"] },
  { key: "email", label: "Email", category: "contact", kind: "text", profileField: "email", aliases: [] },
  { key: "phone", label: "Phone", category: "contact", kind: "text", profileField: "phone", aliases: [] },
  { key: "phone_country_code", label: "Phone country code", category: "contact", kind: "text",
    aliases: [], help: "Leave blank to use the code in your phone number (for example +91)." },
  { key: "phone_device_type", label: "Phone type", category: "contact", kind: "choice", choices: ["Mobile", "Landline"],
    aliases: [], help: "Leave blank for Mobile." },
  { key: "alternate_phone", label: "Alternate phone", category: "contact", kind: "text",
    aliases: ["alternate phone", "alt phone", "alt. phone", "secondary phone", "other phone", "alternative phone number"] },
  { key: "linkedin", label: "LinkedIn profile URL", category: "contact", kind: "url", aliases: [], help: "Saved under Profile links as LinkedIn." },
  { key: "github", label: "GitHub profile URL", category: "contact", kind: "url", aliases: [], help: "Saved under Profile links as GitHub." },
  { key: "portfolio_url", label: "Portfolio or personal website", category: "contact", kind: "url",
    aliases: ["portfolio", "portfolio url", "portfolio link", "website", "personal website", "website url", "other website", "personal site"] },
  { key: "location", label: "Current location (city, region, country)", category: "location", kind: "text", profileField: "location", aliases: [] },
  { key: "city", label: "City", category: "location", kind: "text", aliases: [] },
  { key: "state_province", label: "State / province", category: "location", kind: "text",
    aliases: ["state", "province", "state/province", "state / province", "region", "state or province", "location - state"] },
  { key: "country", label: "Country of residence", category: "location", kind: "text", aliases: [] },
  { key: "postal_code", label: "Postal / ZIP / PIN code", category: "location", kind: "text",
    aliases: ["location - zip code", "zip/postal code", "zip / postal code", "postal code / zip", "pin code", "pincode"] },
  { key: "street_address", label: "Street address", category: "location", kind: "text",
    aliases: ["street address", "address", "address line 1", "home address", "mailing address"] },
  { key: "address_line_2", label: "Address line 2 (apartment, floor, landmark)", category: "location", kind: "text",
    aliases: ["address line 2", "address 2", "street address line 2", "apartment, suite, unit", "apt, suite, etc.", "apartment/suite"] },
  { key: "timezone", label: "Time zone", category: "location", kind: "text",
    aliases: ["time zone", "timezone", "what time zone are you in?", "your time zone"] },
  { key: "citizenship", label: "Citizenship", category: "eligibility", kind: "text",
    aliases: ["citizenship", "country of citizenship", "what is your citizenship?", "nationality"],
    help: "Used only when a form asks for it directly." },
  { key: "visa_status", label: "Current visa / immigration status", category: "eligibility", kind: "text",
    aliases: ["visa status", "current visa status", "immigration status", "what is your current visa status?", "work permit status"] },
  { key: "age_18_or_over", label: "Are you at least 18 years old?", category: "eligibility", kind: "yesno",
    aliases: ["are you at least 18 years of age?", "are you 18 years of age or older?", "are you 18 years or older?", "are you over 18?", "are you at least 18 years old?"] },
  { key: "willing_to_relocate", label: "Willing to relocate?", category: "preferences", kind: "yesno", aliases: [] },
  { key: "relocation_locations", label: "Locations you would relocate to", category: "preferences", kind: "text",
    aliases: ["which locations are you willing to relocate to?", "preferred locations", "preferred work locations", "where would you like to work?"] },
  { key: "work_arrangement", label: "Remote / hybrid / onsite preference", category: "preferences", kind: "choice",
    choices: ["Remote", "Hybrid", "Onsite", "Flexible"],
    aliases: ["work arrangement", "work arrangement preference", "remote or onsite preference", "are you looking for remote, hybrid or onsite work?", "preferred work arrangement"] },
  { key: "work_location", label: "Planned work location", category: "preferences", kind: "text", aliases: [] },
  { key: "open_to_onsite", label: "Open to working onsite / in office?", category: "preferences", kind: "yesno",
    aliases: ["are you open to working onsite?", "are you able to work onsite?", "are you open to working in the office?", "can you work from our office?", "are you comfortable working in office?"] },
  { key: "travel_willingness", label: "Willingness to travel", category: "preferences", kind: "text", aliases: [] },
  { key: "notice_period_days", label: "Notice period (days)", category: "availability", kind: "number", unit: "days", aliases: [] },
  { key: "available_start_date", label: "Earliest start date (YYYY-MM-DD)", category: "availability", kind: "date", aliases: [] },
  { key: "serving_notice_period", label: "Currently serving your notice period?", category: "availability", kind: "yesno",
    aliases: ["are you currently serving your notice period?", "are you serving your notice period?", "are you serving notice period?", "currently serving notice period", "serving notice period"] },
  { key: "last_working_day", label: "Last working day, if serving notice (YYYY-MM-DD)", category: "availability", kind: "date",
    aliases: ["last working day", "last working date", "what is your last working day?", "last working day (lwd)", "lwd"] },
  { key: "currently_employed", label: "Currently employed?", category: "availability", kind: "yesno",
    aliases: ["are you currently employed?", "currently employed", "are you currently working?"] },
  { key: "expected_salary_INR_annual", label: "Expected salary, INR per year", category: "availability", kind: "number",
    aliases: [], help: "Add other currencies in Application answers as expected_salary_<CURRENCY>_annual." },
  { key: "expected_salary_USD_annual", label: "Expected salary, USD per year", category: "availability", kind: "number", aliases: [] },
  { key: "total_years_experience", label: "Total years of professional experience", category: "experience", kind: "number", unit: "years", aliases: [] },
  { key: "current_employer", label: "Current employer", category: "experience", kind: "text",
    aliases: ["current employer", "current company", "current or most recent employer", "most recent employer", "current or most recent company", "company name"],
    help: "Leave blank to use the employer on your confirmed \"Present\" experience fact." },
  { key: "current_title", label: "Current job title", category: "experience", kind: "text",
    aliases: ["current job title", "current title", "current or most recent job title", "most recent job title", "current role"],
    help: "Leave blank to use the title on your confirmed \"Present\" experience fact." },
  { key: "highest_degree", label: "Highest level of education", category: "education", kind: "choice",
    choices: ["High school", "Associate's degree", "Bachelor's degree", "Master's degree", "Doctorate (PhD)", "Other"],
    aliases: ["highest level of education", "highest degree", "what is your highest level of education?", "highest education level", "education level", "highest degree earned", "highest degree obtained"] },
  { key: "school", label: "School / university", category: "education", kind: "text",
    aliases: ["school", "university", "college", "institution", "school name", "university name", "school or university"] },
  { key: "field_of_study", label: "Field of study / major", category: "education", kind: "text",
    aliases: ["field of study", "major", "discipline", "area of study", "degree subject", "specialization"] },
  { key: "graduation_year", label: "Graduation year", category: "education", kind: "number",
    aliases: ["graduation year", "year of graduation", "graduation date", "when did you graduate?"] },
  { key: "how_did_you_hear", label: "How did you hear about the job?", category: "company", kind: "text",
    aliases: ["how did you hear about us?", "how did you hear about this job?", "how did you hear about this position?", "how did you hear about this role?",
      "how did you hear about {company}?", "how did you find out about {company}?", "how did you find out about this job?", "where did you hear about this position?",
      "where did you hear about us?", "source", "how did you learn about this opportunity?", "how did you hear about this opportunity?"],
    help: "For example: Company careers page." },
  { key: "previously_employed_here", label: "Previously employed by the company?", category: "company", kind: "yesno",
    help: "Leave blank: Chairman answers from your confirmed work history (Yes only for a company you have worked at).",
    aliases: ["have you previously been employed at {company}?", "have you previously been employed at {company} or one of our subsidiaries?",
      "have you ever worked for {company}?", "have you worked at {company} before?", "have you previously worked at {company}?",
      "are you a current or former employee of {company}?", "have you ever been employed by {company}?"] },
  { key: "interviewed_here_before", label: "Interviewed with the company before?", category: "company", kind: "yesno",
    aliases: ["have you ever interviewed at {company} before?", "have you interviewed with {company} before?", "have you previously interviewed at {company}?",
      "have you interviewed at {company} in the past?", "have you ever interviewed with {company}?"],
    help: "Your usual answer (typically No). Answer a specific company differently in the side panel; it is remembered for that company." },
  { key: "referred_by_employee", label: "Referred by a current employee?", category: "company", kind: "yesno",
    aliases: ["were you referred by an employee?", "were you referred by a current employee?", "were you referred?", "do you have a referral?"] },
  { key: "marketing_opt_in", label: "Receive marketing, SMS or talent-community updates?", category: "company", kind: "yesno",
    aliases: [], help: "Used for optional or required marketing and text-message consent questions. Answer No to decline them." },
  { key: "non_compete", label: "Bound by a non-compete or non-solicitation agreement?", category: "background", kind: "yesno",
    aliases: ["are you subject to a non-compete agreement?", "are you bound by a non-compete agreement?", "are you subject to any non-compete or non-solicitation agreements?"] },
  { key: "background_check_willing", label: "Willing to undergo a background check?", category: "background", kind: "yesno",
    aliases: ["are you willing to undergo a background check?", "would you be willing to undergo a background check?", "are you willing to submit to a background check?"] },
  { key: "drug_test_willing", label: "Willing to undergo a drug test?", category: "background", kind: "yesno",
    aliases: ["are you willing to undergo a drug test?", "are you willing to take a drug test?", "would you be willing to take a drug test?"] },
  { key: "security_clearance", label: "Active security clearance", category: "background", kind: "text",
    aliases: ["do you have an active security clearance?", "security clearance", "current security clearance", "clearance level", "what is your security clearance level?"],
    help: "For example: None." },
  { key: "military_service", label: "Have you served in the military?", category: "background", kind: "yesno",
    aliases: ["have you served in the military?", "military service", "have you ever served in the armed forces?", "are you currently serving in the military?"] },
  { key: "eeo_gender", label: "Gender", category: "disclosures", kind: "choice", disclosure: true, choices: ["Male", "Female", "Non-binary", DECLINE],
    aliases: ["gender", "what is your gender?", "gender identity", "i identify my gender as", "what is your gender identity?", "sex"] },
  { key: "eeo_race_ethnicity", label: "Race / ethnicity", category: "disclosures", kind: "choice", disclosure: true,
    choices: ["Asian", "Black or African American", "Hispanic or Latino", "White", "American Indian or Alaska Native", "Native Hawaiian or Other Pacific Islander", "Two or more races", DECLINE],
    aliases: ["race", "ethnicity", "race/ethnicity", "race / ethnicity", "what is your race/ethnicity?", "what is your race?", "what is your ethnicity?", "race or ethnicity"] },
  { key: "eeo_hispanic_latino", label: "Hispanic or Latino?", category: "disclosures", kind: "choice", disclosure: true, choices: ["Yes", "No", DECLINE],
    aliases: ["are you hispanic/latino?", "are you hispanic or latino?", "hispanic or latino", "hispanic/latino"] },
  { key: "eeo_veteran_status", label: "Protected veteran status", category: "disclosures", kind: "choice", disclosure: true,
    choices: ["I am not a protected veteran", "I identify as one or more of the classifications of protected veteran", DECLINE],
    aliases: ["veteran status", "are you a protected veteran?", "protected veteran status", "military/veteran status", "veteran"] },
  { key: "eeo_disability_status", label: "Disability status", category: "disclosures", kind: "choice", disclosure: true,
    choices: ["No, I do not have a disability", "Yes, I have a disability (or previously had a disability)", DECLINE],
    aliases: ["disability status", "do you have a disability?", "disability", "voluntary self-identification of disability"] },
  { key: "eeo_sexual_orientation", label: "Sexual orientation", category: "disclosures", kind: "choice", disclosure: true,
    choices: ["Heterosexual", "Gay or lesbian", "Bisexual", "Other", DECLINE],
    aliases: ["sexual orientation", "what is your sexual orientation?"] },
  { key: "eeo_transgender", label: "Do you identify as transgender?", category: "disclosures", kind: "choice", disclosure: true, choices: ["Yes", "No", DECLINE],
    aliases: ["do you identify as transgender?", "transgender"] },
]);
export const DISCLOSURE_KEYS: ReadonlySet<string> = new Set(QUESTION_BANK.filter(question => question.disclosure).map(question => question.key));
export function bankQuestion(key: string): BankQuestion | undefined { return QUESTION_BANK.find(question => question.key === key); }
