import type { Job } from "./types.js";

/** A kind of role you apply to, with the words that identify it and the resume slot used for it. */
export interface RoleFamily {
  id: string;
  label: string;
  /** Phrases matched as whole words in the job title; one match classifies the job into this family. */
  titleKeywords: string[];
  /** Skills/keywords looked for in the job description; they rank relevance and are reported per job. */
  skillKeywords: string[];
  /** Title words that disqualify a job from this family (for example "manager" or "intern"). */
  excludeKeywords: string[];
  /** Apply to this family at every tracked company, not only companies where you picked it. */
  alwaysApply: boolean;
  /** Resume slot (1-8) sent for this family. Without one, the best-matching approved resume is used. */
  resumeSlot?: number;
  /** Minimum description keyword matches for a title match to count as relevant (0 = title alone is enough). */
  minSkillMatches: number;
}
export interface JobClassification {
  familyId?: string;
  familyLabel?: string;
  /** Title matches a family, no exclusion applies and enough description keywords match. */
  relevant: boolean;
  /** The family is one you apply to for this company (picked for the company, or "always apply"). */
  interested: boolean;
  score: number;
  matchedTitle: string[];
  matchedSkills: string[];
  excludedBy?: string;
  reason: string;
}

export const MAX_RESUME_SLOTS = 8;
const EXCLUDE = ["intern", "internship", "sales", "recruiter", "director", "vice president", "vp"];
export const DEFAULT_ROLE_FAMILIES: RoleFamily[] = [
  { id: "data-engineering", label: "Data Engineering", alwaysApply: true, minSkillMatches: 1, excludeKeywords: EXCLUDE,
    titleKeywords: ["data engineer", "analytics engineer", "etl", "data platform", "big data", "data pipeline", "data infrastructure", "data warehouse"],
    skillKeywords: ["spark", "airflow", "kafka", "dbt", "sql", "snowflake", "databricks", "bigquery", "redshift", "python", "etl", "elt", "data pipeline", "streaming", "flink", "hadoop", "lakehouse", "data modeling", "delta lake", "iceberg"] },
  { id: "cloud-engineering", label: "Cloud Engineering", alwaysApply: true, minSkillMatches: 1, excludeKeywords: EXCLUDE,
    titleKeywords: ["cloud engineer", "devops", "site reliability", "sre", "infrastructure engineer", "cloud operations", "cloud infrastructure", "reliability engineer"],
    skillKeywords: ["aws", "gcp", "google cloud", "azure", "terraform", "kubernetes", "docker", "ci/cd", "linux", "networking", "iam", "ansible", "helm", "observability", "prometheus", "cloudformation"] },
  { id: "cloud-platform-engineering", label: "Cloud Platform Engineering", alwaysApply: false, minSkillMatches: 1, excludeKeywords: EXCLUDE,
    titleKeywords: ["platform engineer", "cloud platform", "infrastructure platform", "developer platform", "platform reliability"],
    skillKeywords: ["kubernetes", "terraform", "golang", "internal developer platform", "service mesh", "istio", "aws", "gcp", "azure", "ci/cd", "argo", "observability", "multi tenant"] },
  { id: "software-engineering", label: "Software Engineering", alwaysApply: false, minSkillMatches: 1, excludeKeywords: EXCLUDE,
    titleKeywords: ["software engineer", "software developer", "backend engineer", "back end engineer", "full stack", "fullstack", "sde", "developer", "programmer", "member of technical staff"],
    skillKeywords: ["java", "python", "golang", "typescript", "javascript", "node", "microservices", "distributed systems", "api", "rest", "grpc", "sql", "system design", "react", "c++", "rust"] },
  { id: "ai-ml-engineering", label: "AI / ML Engineering", alwaysApply: false, minSkillMatches: 1, excludeKeywords: EXCLUDE,
    titleKeywords: ["machine learning", "ml engineer", "ai engineer", "mlops", "applied scientist", "llm", "genai", "generative ai", "deep learning", "ml platform", "ai platform"],
    skillKeywords: ["pytorch", "tensorflow", "llm", "mlops", "model serving", "rag", "nlp", "transformers", "vector database", "embeddings", "fine tuning", "kubeflow", "mlflow", "python", "inference"] },
  { id: "forward-deployed-engineering", label: "Forward Deployed Engineering", alwaysApply: false, minSkillMatches: 0, excludeKeywords: EXCLUDE,
    titleKeywords: ["forward deployed", "solutions engineer", "customer engineer", "deployment engineer", "field engineer", "solutions architect", "implementation engineer"],
    skillKeywords: ["customer", "deployment", "integration", "python", "sql", "api", "stakeholder", "prototype", "consulting", "cloud", "data"] },
];

const normalize = (text: string) => ` ${text.normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}+#./]+/gu, " ").replace(/\s+/g, " ").trim()} `;
/** Whole-word phrase match, tolerant of punctuation ("Data-Engineer", "CI/CD", "C++"). */
function contains(text: string, phrase: string): boolean {
  const needle = normalize(phrase).trim();
  if (!needle) return false;
  const escaped = needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(?:^|[^\\p{L}\\p{N}+#])${escaped}(?:s|es)?(?=$|[^\\p{L}\\p{N}+#])`, "u").test(text);
}

/**
 * Deterministic classification: the family whose title keywords match the title (most specific match wins),
 * unless an exclude keyword matches; relevance also needs the family's minimum description keyword matches.
 */
export function classifyJob(job: Pick<Job, "title" | "description">, families: RoleFamily[], interested?: ReadonlySet<string>): JobClassification {
  const title = normalize(job.title), description = normalize(job.description.slice(0, 60_000));
  const shortDescription = job.description.trim().length < 200;
  let best: { family: RoleFamily; matchedTitle: string[]; matchedSkills: string[]; specificity: number; order: number } | undefined;
  families.forEach((family, order) => {
    const matchedTitle = family.titleKeywords.filter(keyword => contains(title, keyword));
    if (!matchedTitle.length) return;
    const matchedSkills = [...new Set(family.skillKeywords.filter(keyword => contains(description, keyword)))];
    const specificity = Math.max(...matchedTitle.map(keyword => normalize(keyword).trim().length));
    const better = !best || specificity > best.specificity || specificity === best.specificity && matchedSkills.length > best.matchedSkills.length;
    if (better) best = { family, matchedTitle, matchedSkills, specificity, order };
  });
  if (!best) return { relevant: false, interested: false, score: 0, matchedTitle: [], matchedSkills: [], reason: "The title matches none of your role families." };
  const { family, matchedTitle, matchedSkills } = best;
  const excludedBy = family.excludeKeywords.find(keyword => contains(title, keyword));
  const enoughSkills = shortDescription || matchedSkills.length >= family.minSkillMatches;
  const relevant = !excludedBy && enoughSkills;
  const isInterested = relevant && (family.alwaysApply || !!interested?.has(family.id));
  const score = relevant ? Math.min(100, 60 + matchedSkills.length * 5) : 0;
  const skills = matchedSkills.length ? `${matchedSkills.length} keyword${matchedSkills.length === 1 ? "" : "s"} (${matchedSkills.slice(0, 6).join(", ")}${matchedSkills.length > 6 ? ", …" : ""})` : "no description keywords";
  const reason = excludedBy ? `${family.label}, but the title contains "${excludedBy}", which you excluded.`
    : !enoughSkills ? `${family.label} title, but only ${matchedSkills.length} of the required ${family.minSkillMatches} description keywords matched.`
      : `${family.label}: title matches "${matchedTitle[0]}"; ${skills}.${isInterested ? "" : " You have not picked this role family for this company."}`;
  return { familyId: family.id, familyLabel: family.label, relevant, interested: isInterested, score, matchedTitle, matchedSkills, ...(excludedBy ? { excludedBy } : {}), reason };
}
