/** Levels a role's title can name, junior to senior (dependency-free so the dashboard can import it). */
export type Seniority = "intern" | "entry" | "mid" | "senior" | "staff" | "principal" | "manager" | "director";
export const SENIORITIES: readonly Seniority[] = ["intern", "entry", "mid", "senior", "staff", "principal", "manager", "director"];
