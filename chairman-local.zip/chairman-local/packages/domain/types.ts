export type AiPolicy = "allowed" | "prohibited" | "unknown";
export type SourceMode = "enabled" | "candidate" | "manual_only" | "paused" | "blocked";
export type ApplicationStatus = "prepared" | "approved" | "executing" | "awaiting_human" | "submitted_confirmed" | "submission_unknown" | "failed" | "manual_only" | "withdrawn_from_queue";

export interface Fact {
  id: string;
  category: "experience" | "education" | "publication" | "summary";
  text: string;
  employer?: string;
  role?: string;
  dates?: string;
  confirmed: boolean;
}

export interface Preferences {
  roles: string[];
  countries: string[];
  excludedEmployers: string[];
  salaryTargetInr: number;
  dailyLimit: number | null;
  timezone: "Asia/Kolkata";
  allowLongTermContracts: boolean;
  authorizedCountries: string[];
  needsSponsorshipAbroad: boolean;
  /** Fill voluntary self-identification (EEO) questions from your saved eeo_* answers. Off by default. */
  fillVoluntaryDisclosures?: boolean;
  /** Tick required acknowledgements and consents in your name (each is logged per application). Off by default. */
  acceptRequiredAcknowledgements?: boolean;
}

export interface Profile {
  name: string;
  email: string;
  phone: string;
  location: string;
  links: Record<string, string>;
  skills: string[];
  facts: Fact[];
  answers: Record<string, string>;
  confirmed: boolean;
  version: number;
  preferences: Preferences;
}

export interface Salary {
  min?: number;
  max?: number;
  currency?: string;
  period?: string;
  kind?: "base" | "total" | "unknown";
}

export interface Job {
  id: string;
  sourceId: string;
  sourceJobId: string;
  title: string;
  company: string;
  location: string;
  remote: boolean;
  countries: string[];
  employmentType: string;
  description: string;
  applyUrl: string;
  canonicalUrl: string;
  postedAt?: string;
  expiresAt?: string;
  fetchedAt: string;
  cacheExpiresAt?: string;
  cacheExpired?: boolean;
  salary: Salary | null;
  language: string | null;
  sponsorship: "yes" | "no" | "unknown";
  aiPolicy: AiPolicy;
  status: "open" | "closed";
  careerSourceIds?: string[];
  /** Onsite, hybrid or remote, when the board says so. */
  workplaceType?: "remote" | "hybrid" | "onsite";
  department?: string;
  /** Experience level as labelled by the board (for example SmartRecruiters "Mid-Senior Level"). */
  seniority?: string;
}

/** Hosted job boards read through their public listing APIs; "generic" is a careers page read as HTML. */
export type CareerProvider = "ashby" | "greenhouse" | "lever" | "smartrecruiters" | "workday" | "eightfold" | "oracle" | "rippling"
  | "google" | "apple" | "atlassian" | "nutanix" | "generic";
export interface CareerBoardTarget {
  provider: CareerProvider;
  board: string;
  boardUrl: string;
  jobId?: string;
}
export interface CareerSource {
  id: string;
  inputUrl: string;
  label: string;
  target?: CareerBoardTarget;
  enabled: boolean;
  status: "resolving" | "ready" | "scanning" | "paused" | "unsupported" | "error";
  message: string;
  createdAt: string;
  updatedAt: string;
  lastScannedAt?: string;
  nextScanAt?: string;
  jobCount: number;
  /** Company name shown in Progress (defaults to the label). */
  company?: string;
  /** Role family ids you apply to at this company, in addition to "always apply" families. */
  roleFamilies?: string[];
  /** Your note: this company sponsors visas for roles abroad (used when a posting does not say). */
  sponsorsVisas?: boolean;
  /** Last full crawl of the board: open roles listed, roles matching your role families, roles no longer listed. */
  crawl?: { at: string; listed: number; relevant: number; closed: number; truncated: boolean };
}
export interface CareerLinkResolution {
  target?: CareerBoardTarget;
  candidates: CareerBoardTarget[];
  message: string;
}

export interface Source {
  id: string;
  name: string;
  mode: SourceMode;
  kind: "himalayas" | "rss" | "remotive" | "arbeitnow" | "remoteok" | "manual" | CareerProvider;
  endpoint?: string;
  careersUrl: string;
  discoveryAllowed: boolean;
  assistanceAllowed: boolean;
  submissionAllowed: boolean;
  policyUrl: string;
  notes: string;
  lastScannedAt?: string;
  lastError?: string;
  count?: number;
}

export interface Match {
  score: number;
  matchedSkills: string[];
  missingSkills: string[];
  reasons: string[];
  warnings: string[];
  blockers: string[];
  eligible: boolean;
  needsReview: boolean;
}

export interface ResumeDraft {
  factIds: string[];
  skills: string[];
  mode: "local-ai" | "deterministic" | "uploaded-variant" | "jd-tailored";
  notes: string[];
  keywordTerms?: string[];
  inference?: InferenceIdentity;
}
export interface InferenceIdentity {
  provider: "ollama" | "copilot" | "gemini";
  model: string;
  remote: boolean;
}

export interface KeywordEvidence {
  term: string;
  kind: "direct" | "equivalent" | "transferable";
  factIds: string[];
  sourceSkills: string[];
  explanation: string;
}
export interface KeywordAnalysis {
  supported: KeywordEvidence[];
  transferable: KeywordEvidence[];
  gaps: string[];
}
export type ReferenceFamily = "software" | "cloud" | "data" | "forward-deployed" | "mlops" | "hybrid";
export interface ReferenceResume {
  id: string;
  family: ReferenceFamily;
  title: string;
  createdAt: string;
  sourceProfileHash: string;
  profileVersion: number;
  needsReview: true;
  artifacts: Artifact[];
}
export type PipelineStage = "applied" | "screening" | "interview" | "offer" | "rejected" | "withdrawn";
export interface ApplicationProgress {
  stage: PipelineStage;
  note: string;
  nextActionDate?: string;
  updatedAt: string;
}
export interface ExternalApplication {
  id: string;
  jobId: string;
  sourceId: string;
  submittedDate: string;
  confirmation: string;
  progress: ApplicationProgress;
  createdAt: string;
}
export interface CampaignConfig {
  startDate: string;
  days: number;
  dailyTarget: number;
  timezone: "Asia/Kolkata";
}
export interface CampaignStats {
  config: CampaignConfig;
  endDate: string;
  dayNumber: number;
  daysRemaining: number;
  totalTarget: number;
  confirmedToday: number;
  confirmedTotal: number;
  targetToDate: number;
  remainingToGoal: number;
  interviews: number;
  offers: number;
  followUpsDue: number;
  interviewRate: number;
  untrackedSubmissionDates: number;
  daily: { date: string; confirmed: number; target: number }[];
  sources: { sourceId: string; submitted: number; interviews: number; offers: number }[];
}
export interface PreparationTask {
  id: string;
  jobId: string;
  mode: "local-ai" | "deterministic";
  profileHash: string;
  status: "queued" | "running" | "completed" | "failed" | "cancelled";
  packetId?: string;
  error?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Artifact {
  format: "pdf" | "docx";
  filename: string;
  sha256: string;
  bytes: number;
}

export interface FormField {
  key: string;
  label: string;
  type: string;
  required: boolean;
  options: string[];
  optionLabels?: Record<string, string>;
  accept?: string[];
  /** Optional public structure captured by the Chrome page assistant (never current values). */
  hint?: string;
  placeholder?: string;
  autocomplete?: string;
  pattern?: string;
  maxLength?: number;
  minLength?: number;
  /** Voluntary self-identification, or a consent/acknowledgement: filled only from explicit Profile choices. */
  sensitivity?: "disclosure" | "acknowledgement";
}

export interface FormSnapshot {
  url: string;
  fields: FormField[];
  fingerprint: string;
  hasCaptcha: boolean;
  hasLegal: boolean;
  unsupported: string[];
}

export interface Packet {
  id: string;
  jobId: string;
  sourceId?: string;
  jobHash: string;
  profileHash: string;
  profileVersion: number;
  draft: ResumeDraft;
  artifacts: Artifact[];
  answers: Record<string, string>;
  warnings: string[];
  status: ApplicationStatus;
  createdAt: string;
  approvedAt?: string;
  approvalHash?: string;
  formSnapshot?: FormSnapshot;
  confirmation?: string;
  error?: string;
  submittedAt?: string;
  progress?: ApplicationProgress;
  variantId?: string;
  authorizationId?: string;
  approvedBy?: "user" | "autopilot";
  tailoring?: ResumeTailoring;
  resumeContent?: {
    name: string;
    email: string;
    phone: string;
    location: string;
    links: Record<string, string>;
    facts: Fact[];
    skills: string[];
    keywordTerms: string[];
  };
  submissionArtifactSha256?: string;
  workflowSteps?: {
    url: string;
    fingerprint: string;
    answers: Record<string, string>;
    humanSupplied: boolean;
    recordedAt: string;
  }[];
}

export interface ResumeTailoring {
  baseVariantId: string;
  baseVariantLabel: string;
  baseVariantSha256: string;
  jobDescriptionHash: string;
  engine: "deterministic" | "local-ai";
  supportedKeywords: string[];
  missingKeywords: string[];
  notes: string[];
  inference?: InferenceIdentity;
}

export type KnownAutomationProvider = "ashby" | "greenhouse";
export type AutomationProvider = KnownAutomationProvider | "generic";
export interface ResumeVariant {
  id: string;
  slot: number;
  label: string;
  families: ReferenceFamily[];
  originalFilename: string;
  artifact: Artifact;
  uploadedAt: string;
  approved: boolean;
  textLength: number;
  issues: string[];
}
export interface AutopilotRules {
  providers: AutomationProvider[];
  minimumScore: number;
  allowUnknownSalary: boolean;
  allowUnknownSponsorship: boolean;
  allowUnknownRemoteEligibility: boolean;
  intervalSeconds: number;
  stopAtDailyGoal: boolean;
  employerAllowlist: string[];
  resumeStrategy?: "job-tailored" | "original";
  tailoringMode?: "deterministic" | "local-ai";
  humanInLoop?: boolean;
  autoDiscover?: boolean;
  /** Only apply to jobs whose role family you track (always-apply families, or families picked for the company). */
  requireRoleFamily?: boolean;
  /** How many prefilled tabs may wait for you (CAPTCHA or answers) at once, 1-50. */
  maxWaitingTabs?: number;
  /** AI help for questions without a saved answer: off, only mapping to your saved answers (default), or also AI choices/drafts. */
  aiAnswers?: "off" | "saved-only" | "all";
}
export interface AutopilotAuthorization {
  id: string;
  snapshotHash: string;
  approvedAt: string;
  expiresAt: string;
}
export type AutopilotJobStatus = "queued" | "inspecting" | "prefilling" | "awaiting_human" | "needs_input" | "auth_required" | "captcha_required" | "unsupported" | "skipped" | "submitting" | "submitted_confirmed" | "submission_unknown" | "failed";
export interface AutopilotJob {
  id: string;
  jobId: string;
  status: AutopilotJobStatus;
  variantId?: string;
  packetId?: string;
  reason: string;
  createdAt: string;
  updatedAt: string;
  seenFetchedAt?: string;
  humanTaskId?: string;
  /** You picked this role (Today → Auto-apply): it runs before other candidates and skips your rule-based filters. */
  priority?: boolean;
}
export interface AutopilotView {
  enabled: boolean;
  ready: boolean;
  blockers: string[];
  rules: AutopilotRules;
  authorization?: AutopilotAuthorization;
  snapshotHash: string;
  jobs: AutopilotJob[];
  lastRunAt?: string;
  nextRunAt?: string;
  browserRunning: boolean;
  status: string;
  humanTasks?: HumanTask[];
  liveEvents?: LiveEvent[];
  discoveryStatus?: string;
}

export interface HumanTask {
  id: string;
  jobId: string;
  packetId: string;
  sessionId: string;
  status: "waiting" | "resuming" | "resolved" | "abandoned" | "session_lost";
  reason: string;
  url: string;
  step: number;
  filledFields: string[];
  missingFields: FormField[];
  createdAt: string;
  updatedAt: string;
  canContinue?: boolean;
  /** Why the tab waits: a CAPTCHA before Submit, a challenge raised by Submit, or answers/other review. */
  waitingFor?: "captcha" | "captcha_after_submit" | "answers";
}
export interface LiveEvent {
  id: number;
  jobId?: string;
  phase: string;
  message: string;
  timestamp: string;
}

export interface ScanResult {
  jobs: Job[];
  nextCursor?: string;
}

export const DEFAULT_PREFERENCES: Preferences = {
  roles: ["software engineering", "cloud engineering", "data engineering", "forward deployed engineering", "MLOps engineering"],
  countries: ["India", "United States", "European Union", "Japan", "Australia", "Singapore", "Switzerland"],
  excludedEmployers: ["HPE", "Hewlett Packard Enterprise", "Aruba"],
  salaryTargetInr: 5_000_000,
  dailyLimit: null,
  timezone: "Asia/Kolkata",
  allowLongTermContracts: true,
  authorizedCountries: ["India"],
  needsSponsorshipAbroad: true
};

export const MAX_APPROVAL_BATCH_SIZE = 1000;
export const MIN_APPROVED_RESUMES = 2;

export function emptyProfile(): Profile {
  return { name: "", email: "", phone: "", location: "", links: {}, skills: [], facts: [], answers: {}, confirmed: false, version: 1, preferences: structuredClone(DEFAULT_PREFERENCES) };
}
