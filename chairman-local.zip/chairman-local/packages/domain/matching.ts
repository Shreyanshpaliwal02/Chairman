import { createHash } from "node:crypto";
import type { Job, Match, Profile } from "./types.js";

const ALIASES: Record<string, string[]> = {
  "Apache Kafka": ["apache kafka", "kafka"],
  "Apache Spark": ["apache spark", "spark"],
  "AWS": ["aws", "amazon web services"],
  "Kubernetes": ["kubernetes", "k8s"],
  "Terraform": ["terraform"],
  "Apache Airflow": ["apache airflow", "airflow", "mwaa"],
  "Python": ["python"], "Scala": ["scala"], "Java": ["java"], "SQL": ["sql"],
  "Snowflake": ["snowflake"], "Docker": ["docker"], "dbt": ["dbt"],
  "Databricks": ["databricks"], "Azure": ["azure"],
  "Google Cloud": ["google cloud", "gcp"], "React": ["react", "reactjs"],
  "TypeScript": ["typescript"], "JavaScript": ["javascript"],
  "PostgreSQL": ["postgresql", "postgres"], "Rust": ["rust"],
  "MLOps": ["mlops"], "Machine learning": ["machine learning"],
  "MLflow": ["mlflow"], "PyTorch": ["pytorch"], "TensorFlow": ["tensorflow"],
  "CI/CD": ["ci/cd", "continuous integration"],
  "Distributed systems": ["distributed systems"],
  "Data modeling": ["data modeling", "data modelling"],
  "LLM": ["llm", "large language model"], "MCP": ["mcp", "model context protocol"]
};
const escape = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const contains = (text: string, word: string) => new RegExp(`(?<![a-z0-9])${escape(word)}(?![a-z0-9])`, "i").test(text);
const ROLE_PATTERNS: [RegExp, RegExp][] = [
  [/software/i, /software|backend|front.?end|full.?stack|development|developer/i],
  [/cloud/i, /cloud|platform|devops|infrastructure|site reliability|\bsre\b/i],
  [/data/i, /data|analytics|streaming/i],
  [/forward/i, /forward.?deployed|solutions|customer engineer|field engineer/i],
  [/mlops|machine learning/i, /mlops|ml platform|machine learning|\bml engineer|\bai engineer/i]
];
function countryName(country: string): string {
  const value = country.trim().toLowerCase();
  return ({ us: "united states", usa: "united states", "u.s.": "united states", in: "india", uk: "united kingdom", gb: "united kingdom",
    jp: "japan", au: "australia", sg: "singapore", ch: "switzerland" } as Record<string, string>)[value] ?? value;
}
export function prohibitsAi(text: string): boolean {
  return /(?:no|without|not (?:use|using)|prohibit(?:ed)?|disqualif\w*)[^.\n]{0,100}(?:AI[- ]generated|AI[- ]written|generative AI|artificial intelligence)|(?:AI[- ]generated|AI[- ]written)[^.\n]{0,100}(?:prohibited|not allowed|disqualif)|only my own words|do not use (?:AI|ChatGPT)/i.test(text);
}
export function jobHash(job: Job): string {
  const { fetchedAt: _f, cacheExpiresAt: _cacheExpiry, sourceId: _s, sourceJobId: _si, id: _id, careerSourceIds: _careerSources, ...material } = job;
  return digest(material);
}
export function digest(value: unknown): string {
  return createHash("sha256").update(JSON.stringify(value)).digest("hex");
}
export function matchJob(profile: Profile, job: Job): Match {
  const blockers: string[] = [], warnings: string[] = [], reasons: string[] = [];
  const text = `${job.title}\n${job.description}`;
  if (job.cacheExpired) blockers.push("The cached job description has expired. Refresh its original source before preparing or applying; this does not mean the job is closed.");
  const proof = profile.skills.join("\n");
  const mentioned = Object.keys(ALIASES).filter(key => ALIASES[key]!.some(alias => contains(text, alias)));
  const matchedSkills = mentioned.filter(key => ALIASES[key]!.some(alias => contains(proof, alias)));
  const missingSkills = mentioned.filter(key => !matchedSkills.includes(key));
  const employer = job.company.toLowerCase().replace(/[^a-z0-9]+/g, " ");
  if (profile.preferences.excludedEmployers.some(e => contains(employer, e.toLowerCase().replace(/[^a-z0-9]+/g, " "))))
    blockers.push("Employer is on your exclusion list.");
  if (job.status === "closed" || (job.expiresAt && Date.parse(job.expiresAt) <= Date.now()))
    blockers.push("This opening is closed or expired.");
  const engineering = /engineer|developer|architect|mlops|devops|site reliability/i.test(job.title);
  const targetRole = profile.preferences.roles.some(role => {
    const pattern = ROLE_PATTERNS.find(([name]) => name.test(role))?.[1];
    return pattern ? pattern.test(job.title) : contains(job.title, role);
  });
  if (!engineering || !targetRole) blockers.push("Title is outside your requested engineering role families.");
  const experience = text.match(/\b(\d{1,2})(?:\s*[-–]\s*\d{1,2})?\s*\+?\s*(?:years?|yrs?)[^.\n]{0,65}\bexperience\b/i);
  if (experience) warnings.push(`The JD mentions ${experience[1]}+ years of experience. Confirm the relevant requirement against your actual full-time experience; do not merge internship tenure silently.`);
  if (/\bstaff\b|\bprincipal\b|\bmanager\b|\bdirector\b|\bhead of\b/i.test(job.title))
    warnings.push("Review seniority and leadership requirements separately; matching technology keywords do not establish that experience.");
  if (/intern(?:ship)?|ambassador|creator|short[- ]term|temporary gig/i.test(`${job.title} ${job.employmentType}`))
    blockers.push("Internships, creator campaigns and short gigs are outside your preferences.");
  if (/contract|freelance/i.test(job.employmentType)) {
    if (!profile.preferences.allowLongTermContracts) blockers.push("Contracts are excluded in your preferences.");
    else if (!/long[- ]term|permanent|indefinite|ongoing/i.test(`${job.employmentType} ${job.description}`))
      warnings.push("Contract duration is unverified; confirm this is a long-term engagement.");
  } else if (!/full[- ]?time|permanent/i.test(job.employmentType))
    warnings.push("Employment type needs confirmation.");
  const authorized = profile.preferences.authorizedCountries.map(countryName);
  const listingCountries = job.countries.map(countryName);
  const authorizedLocation = authorized.some(country => listingCountries.includes(country) || contains(job.location, country));
  if (authorizedLocation) reasons.push("The listing includes a country where you confirmed work authorization.");
  else if (job.sponsorship === "no") {
    blockers.push("This job requires work authorization outside your confirmed countries and says sponsorship is unavailable.");
  } else if (job.remote) {
    warnings.push("Remote does not automatically mean India-eligible; confirm the permitted work country.");
    if (job.countries.length && !job.countries.some(c => /worldwide|anywhere|global/i.test(c)))
      warnings.push(`Remote location restrictions: ${job.countries.join(", ")}.`);
  } else if (job.sponsorship === "unknown") warnings.push("Overseas visa sponsorship is not verified.");
  else reasons.push("The listing explicitly mentions sponsorship; verify it applies to this role and your circumstances.");
  if (!job.language || !/english/i.test(job.language))
    warnings.push("English as the working language needs confirmation.");
  if (/(?:fluent|fluency|proficien\w*)\s+(?:in\s+)?(?:japanese|german|french|mandarin|korean)|(?:japanese|german|french|mandarin|korean)\s+(?:is\s+)?required/i.test(text))
    warnings.push("The JD may require another language; confirm your proficiency rather than assuming eligibility.");
  if (!profile.confirmed) warnings.push("Confirm your factual profile before preparing applications.");
  if (job.aiPolicy === "prohibited" || prohibitsAi(text))
    warnings.push("This application restricts AI-generated content. Keep it human-authored and manual.");
  if (!job.salary) warnings.push("Compensation is undisclosed.");
  else {
    if (job.salary.kind !== "base") warnings.push("The disclosed compensation is not verified base salary.");
    if (job.salary.currency === "INR" && /year|annual/i.test(job.salary.period ?? "") && job.salary.kind === "base") {
      const upper = job.salary.max ?? job.salary.min;
      if (upper !== undefined && upper < profile.preferences.salaryTargetInr) warnings.push(`Published base is below your INR ${profile.preferences.salaryTargetInr / 100000} lakh target (not a hard exclusion).`);
      else reasons.push("Published INR base may meet your target.");
    } else warnings.push("Compare this pay in its original currency and billing period; no FX or contract annualization has been assumed.");
  }
  const travel = /international travel|travel internationally|global travel/i.test(text);
  if (travel) reasons.push("The description mentions international travel.");
  if (matchedSkills.length) reasons.push(`${matchedSkills.length} JD skill mentions are evidenced in your profile.`);
  const score = Math.min(100, Math.round((mentioned.length ? matchedSkills.length / mentioned.length * 70 : 0) + (engineering ? 26 : 0) + (travel ? 4 : 0)));
  return { score, matchedSkills, missingSkills, reasons, warnings, blockers, eligible: blockers.length === 0, needsReview: warnings.length > 0 };
}
