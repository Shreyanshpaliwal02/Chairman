import type { ApplicationStatus, AutopilotJobStatus, PipelineStage } from "./types.js";
import type { AssistanceRecord } from "./extension-assist.js";

export type TrackingKind = "packet" | "external" | "assistance";
export type TrackingStatus = ApplicationStatus | AutopilotJobStatus | AssistanceRecord["status"];
export interface TrackingRow {
  id: string;
  kind: TrackingKind;
  jobId: string;
  packetId?: string;
  company: string;
  title: string;
  portal: string;
  applyUrl: string;
  date: string;
  updatedAt: string;
  status: TrackingStatus;
  stage?: PipelineStage;
  notes: string;
  runnerOwned?: boolean;
  progress?: { kind: "packet" | "external"; id: string; note: string; nextActionDate?: string };
}
export interface TrackingPage { items: TrackingRow[]; total: number; offset: number; limit: number }
