import type { Job, Profile } from "./types.js";
import type { JobClassification } from "./role-families.js";
import { matchJob } from "./matching.js";

/**
 * Where a role can be done from, relative to a candidate in India:
 * india / remote_india — an Indian location (onsite, hybrid or remote); remote_global — "Remote", "Remote - Global",
 * "Anywhere"; remote_apac — remote within a region that includes India; remote_restricted — remote but limited to
 * another country or region ("Remote - US", "EMEA", "California - Remote"); abroad — an office outside India.
 */
export type LocationTier = "india" | "remote_india" | "remote_global" | "remote_apac" | "remote_restricted" | "abroad" | "unknown";
export type Sponsorship = "available" | "not_available" | "unknown";
import { SENIORITIES, type Seniority } from "./seniority.js";
export { SENIORITIES, type Seniority };

const INDIA = /\b(?:india|bharat|bengaluru|bangalore|hyderabad|secunderabad|pune|mumbai|navi mumbai|thane|gurugram|gurgaon|noida|greater noida|new delhi|delhi|delhi ncr|ncr|chennai|kolkata|ahmedabad|gandhinagar|gift city|jaipur|kochi|cochin|coimbatore|indore|chandigarh|mohali|thiruvananthapuram|trivandrum|mysuru|mysore|vadodara|nagpur|bhubaneswar|visakhapatnam|vizag|lucknow|goa|surat|karnataka|telangana|maharashtra|tamil nadu|haryana|uttar pradesh|kerala|west bengal|gujarat)\b/i;
/** An Indian country, state or city name appears in this text. */
export const inIndia = (text: string): boolean => INDIA.test(text);
const REMOTE = /\b(?:remote|work from home|wfh|home[- ]based|distributed|telecommute|virtual)\b/i;
const APAC = /\b(?:apac|apj|asia[- ]pacific|asia|south asia)\b/i;
const US_STATES = "alabama|alaska|arizona|arkansas|california|colorado|connecticut|delaware|florida|georgia|hawaii|idaho|illinois|indiana|iowa|kansas|kentucky|louisiana|maine|maryland|massachusetts|michigan|minnesota|mississippi|missouri|montana|nebraska|nevada|new hampshire|new jersey|new mexico|new york|north carolina|north dakota|ohio|oklahoma|oregon|pennsylvania|rhode island|south carolina|south dakota|tennessee|texas|utah|vermont|virginia|washington|west virginia|wisconsin|wyoming|district of columbia";
const ELSEWHERE = new RegExp(`\\b(?:united states|america|americas|north america|latam|latin america|canada|mexico|brazil|argentina|colombia|chile|uk|u\\.k\\.|united kingdom|england|scotland|britain|ireland|europe|european union|eu|eea|emea|dach|nordics?|germany|france|spain|netherlands|belgium|poland|portugal|italy|switzerland|sweden|norway|denmark|finland|austria|czech(?:ia| republic)?|romania|hungary|greece|turkey|israel|uae|dubai|saudi arabia|qatar|egypt|nigeria|kenya|south africa|africa|middle east|australia|new zealand|anz|japan|korea|china|hong kong|taiwan|singapore|malaysia|indonesia|philippines|vietnam|thailand|pakistan|bangladesh|sri lanka|nepal|${US_STATES}|san francisco|new york city|nyc|seattle|austin|boston|chicago|los angeles|bay area|london|berlin|amsterdam|dublin|paris|toronto|vancouver|sydney|melbourne|tokyo|zurich|munich|tel aviv|est|pst|cet|gmt|utc[+-]?\\d*)\\b`, "i");
/** "US"/"U.S."/"USA" in capitals only, so the word "us" in prose is not a country. */
const US = /(?:^|[^A-Za-z])(?:US|U\.S\.A?\.?|USA)(?![A-Za-z])/;
const elsewhere = (text: string) => ELSEWHERE.test(text) || US.test(text);
const US_CODE = /,\s*(?:A[KLRZ]|C[AOT]|D[CE]|FL|GA|HI|I[ADLN]|K[SY]|LA|M[ADEINOST]|N[CDEHJMVY]|O[HKR]|PA|RI|S[CD]|T[NX]|UT|V[AT]|W[AIVY])\b/;
const US_PLACES = new RegExp(`\\b(?:${US_STATES}|san francisco|new york city|nyc|seattle|austin|boston|chicago|los angeles|bay area|silicon valley|san jose|mountain view|palo alto|sunnyvale|santa clara|redmond|bellevue|cupertino|menlo park|denver|atlanta|dallas|houston|miami|san diego|portland|pittsburgh|raleigh)\\b`, "i");
/**
 * Countries a location names without spelling them out: "San Francisco, CA | Seattle, WA" is the United States and
 * "Bengaluru, Karnataka" is India. Only these two are inferred; anything else must be stated.
 */
export function inferCountries(location: string): string[] {
  const found: string[] = [];
  if (INDIA.test(location)) found.push("India");
  if (US.test(location) || US_CODE.test(location) || US_PLACES.test(location)) found.push("United States");
  return found;
}
const WORKPLACE_ONLY = /^(?:hybrid|on-?site|in[- ]office|office|flexible|full[- ]time|in person)$/i;
const GLOBAL_WORDS = /\b(?:remote|work from home|wfh|home[- ]based|distributed|telecommute|virtual|global(?:ly)?|worldwide|world[- ]wide|anywhere|international|first|friendly|fully|100%|only|position|role|opportunity|full[- ]time|part[- ]time|contract|flexible|option(?:al)?)\b/gi;
const ONLY_THERE = /\b(?:must (?:be )?(?:located|based|reside|live|residing) in|(?:candidates|applicants|employees) (?:must be )?(?:based|located|residing) in|open (?:only )?to (?:candidates|applicants|residents)(?: (?:based|located|residing))? in|only (?:open|available) to (?:candidates|applicants|residents)(?: (?:based |located )?in| of)?|within the (?:continental )?(?:united states|u\.s\.|us|uk|european union|eu)|(?:us|u\.s\.|uk|eu|canada|europe)[- ](?:based|only) (?:candidates|applicants|remote|role|position))\b([^.;\n]{0,60})/gi;

const NO_SPONSOR = /\b(?:visa\s+sponsorship\s*[:\-–]\s*(?:no|none|not\s+available)\b|(?:not|unable to|cannot|can ?not|can't|won't|will not|do not|don't|does not|doesn't|are not able to|is not able to|we are unable to)\s+(?:be able to\s+)?(?:offer|provide|support|sponsor)(?:ing)?\s*(?:any\s+)?(?:visa\s+|immigration\s+|employment\s+|work\s+|h-?1b\s+)?(?:sponsorship|sponsor|visas?)|no\s+(?:visa\s+|immigration\s+|h-?1b\s+)?sponsorship|sponsorship\s+(?:is\s+)?(?:not|un)\s*(?:available|offered|provided|possible)|without\s+(?:the\s+need\s+for\s+)?(?:current\s+or\s+future\s+|now\s+or\s+in\s+the\s+future\s+|any\s+)?(?:visa\s+|employer\s+|company\s+|immigration\s+)?sponsorship|not\s+eligible\s+for\s+(?:visa\s+)?sponsorship)/i;
const YES_SPONSOR = /\b(?:visa\s+sponsorship\s*[:\-–]\s*(?:yes|available|provided)|visa\s+sponsorship\s+(?:is\s+|may\s+be\s+)?(?:available|provided|offered|possible|supported)|we\s+(?:do\s+|can\s+|will\s+)?(?:offer|provide|support)\s+(?:visa|immigration|work\s+visa)\s+sponsorship|we\s+(?:do\s+|can\s+|will\s+|are\s+able\s+to\s+)?(?:offer\s+|provide\s+|support\s+)?(?:visa\s+|work\s+visa\s+|immigration\s+)?sponsor(?:ship)?\s+(?:for\s+)?(?:visas?|eligible|qualified|candidates|this\s+role|international|work\s+permits?)|sponsor(?:s|ing)?\s+(?:work\s+|employment\s+)?visas|(?:relocation|immigration)\s+(?:and|&)\s+visa\s+(?:support|assistance|sponsorship)|visa\s+(?:and\s+relocation\s+)?(?:support|assistance|sponsorship)\s+(?:is\s+|will\s+be\s+)?(?:available|provided|offered)|open\s+to\s+(?:visa\s+)?sponsor(?:ing|ship)|sponsorship\s+(?:is\s+)?available|we\s+do\s+sponsor\s+visas|relocation\s+(?:and\s+)?visa\s+support)/i;

export interface LocationFit {
  tier: LocationTier;
  /** Short label for lists, e.g. "Bengaluru", "Remote · global", "Abroad · sponsorship stated". */
  label: string;
  sponsorship: Sponsorship;
  reason: string;
}

function segments(job: Pick<Job, "location">): string[] {
  const parts = job.location.split(/\s*(?:;|\||\n|•| \/ | or )\s*/i).map(part => part.trim()).filter(Boolean);
  const places = parts.filter(part => !WORKPLACE_ONLY.test(part));
  return places.length ? places : parts.length ? parts : [job.location];
}
function segmentTier(segment: string, remoteRole: boolean): LocationTier {
  const text = segment.replace(/[()[\]]/g, " ");
  const remote = remoteRole || REMOTE.test(text) || /^\s*(?:anywhere(?: in the world)?|worldwide|world[- ]wide|global(?:ly)?)\s*$/i.test(text);
  if (INDIA.test(text)) return remote ? "remote_india" : "india";
  if (!text.trim() || /\b(?:location unspecified|unspecified|multiple locations|various locations|tbd|to be determined)\b/i.test(text)) return remote ? "remote_global" : "unknown";
  if (remote) {
    if (APAC.test(text) && !elsewhere(text.replace(APAC, " "))) return "remote_apac";
    if (elsewhere(text) || US_CODE.test(segment)) return "remote_restricted";
    const rest = text.replace(GLOBAL_WORDS, " ").replace(/[^a-z]+/gi, " ").trim();
    return rest ? "remote_restricted" : "remote_global";
  }
  return "abroad";
}
const ORDER: LocationTier[] = ["india", "remote_india", "remote_global", "remote_apac", "abroad", "unknown", "remote_restricted"];

/** Visa sponsorship for a role abroad: the posting's own words first, then your company-level note. */
export function sponsorshipOf(job: Pick<Job, "description" | "sponsorship">, company?: boolean): Sponsorship {
  if (job.sponsorship === "yes") return "available";
  if (job.sponsorship === "no") return "not_available";
  const text = job.description.slice(0, 60_000);
  // "unable to sponsor visas" contains "sponsor visas": a positive phrase counts only when it is not negated just before.
  const yes = [...text.matchAll(new RegExp(YES_SPONSOR.source, "gi"))].some(match =>
    !/\b(?:no|not|unable|cannot|can't|won't|don't|doesn't|aren't|isn't|no longer|never)\b[^.!?\n]{0,30}$/i.test(text.slice(Math.max(0, match.index - 45), match.index)));
  const no = NO_SPONSOR.test(text);
  if (yes && !no) return "available";
  if (no && !yes) return "not_available";
  if (yes && no) return "unknown";
  return company === true ? "available" : company === false ? "not_available" : "unknown";
}

export function locationFit(job: Pick<Job, "location" | "remote" | "description" | "sponsorship"> & { workplaceType?: Job["workplaceType"] }, companySponsors?: boolean): LocationFit {
  // Only a board's explicit "remote" workplace type applies to every listed location; a "Remote" entry is one location among others.
  const remoteRole = job.workplaceType === "remote";
  const tiers = segments(job).map(segment => ({ segment, tier: segmentTier(segment, remoteRole) }));
  let best = tiers.sort((a, b) => ORDER.indexOf(a.tier) - ORDER.indexOf(b.tier))[0] ?? { segment: job.location, tier: "unknown" as LocationTier };
  let reason = "";
  if (best.tier === "remote_global" || best.tier === "remote_apac") {
    for (const match of job.description.slice(0, 60_000).matchAll(ONLY_THERE)) {
      const place = match[1] ?? "", phrase = match[0];
      if (INDIA.test(phrase) || /\b(?:global|worldwide|anywhere|apac|asia)\b/i.test(phrase)) continue;
      if (elsewhere(`${phrase.slice(0, phrase.length - place.length)} ${place}`)) {
        best = { segment: best.segment, tier: "remote_restricted" }; reason = `The description limits it: "${phrase.trim().slice(0, 90)}".`; break;
      }
    }
  }
  const sponsorship = best.tier === "abroad" || best.tier === "unknown" ? sponsorshipOf(job, companySponsors) : "unknown";
  const place = best.segment.trim().slice(0, 60) || "Location not stated";
  const label = best.tier === "india" ? place : best.tier === "remote_india" ? `Remote · India` : best.tier === "remote_global" ? "Remote · global"
    : best.tier === "remote_apac" ? "Remote · APAC" : best.tier === "remote_restricted" ? `${place} (restricted)`
      : `${place} · ${sponsorship === "available" ? "visa sponsorship stated" : sponsorship === "not_available" ? "no sponsorship" : "sponsorship not stated"}`;
  reason ||= best.tier === "india" || best.tier === "remote_india" ? "Based in India."
    : best.tier === "remote_global" ? "Remote without a country restriction."
      : best.tier === "remote_apac" ? "Remote within a region that includes India."
        : best.tier === "remote_restricted" ? `Remote only within another country or region (${place}).`
          : sponsorship === "available" ? "Office abroad; the posting (or your note for this company) says visas are sponsored."
            : sponsorship === "not_available" ? "Office abroad and the posting says sponsorship is not available."
              : best.tier === "unknown" ? "The posting does not say where the role is based." : "Office abroad; the posting does not mention visa sponsorship.";
  return { tier: best.tier, label, sponsorship, reason };
}

/** Level named in the title. Unknown titles return undefined and are judged by required years only. */
export function titleSeniority(title: string): Seniority | undefined {
  const t = ` ${title.toLowerCase().replace(/[_/]/g, " ")} `;
  if (/\b(?:intern|internship|co-?op|apprentice(?:ship)?|summer analyst)\b/.test(t)) return "intern";
  if (/\b(?:director|head of|vice president|vp|chief|cto|cio)\b/.test(t)) return "director";
  if (/\b(?:manager|mgr)\b/.test(t)) return "manager";
  if (/\b(?:distinguished|fellow|principal)\b/.test(t)) return "principal";
  if (/\b(?:senior staff|staff)\b/.test(t)) return "staff";
  if (/\b(?:senior|sr\.?|snr|lead)\b/.test(t) || /\b(?:iv|4|v|5)\s*(?:$|[,(\-–])/.test(`${t.trim()} `) && /\b(?:engineer|developer|scientist|sde|swe)\b/.test(t)) return "senior";
  if (/\b(?:new grad(?:uate)?|graduate|early career|university|campus|fresher|trainee|entry[- ]level|junior|jr\.?)\b/.test(t)) return "entry";
  if (/\bassociate (?:software|data|cloud|ml|machine|ai|platform|site|devops|engineer|developer)\b/.test(t)) return "entry";
  if (/\b(?:engineer|developer|sde|swe|scientist)\s*(?:-|–)?\s*(?:i|1)\s*(?:$|[,(\-–])/.test(`${t.trim()} `)) return "entry";
  if (/\b(?:engineer|developer|sde|swe|scientist)\s*(?:-|–)?\s*(?:ii|iii|2|3)\s*(?:$|[,(\-–])/.test(`${t.trim()} `)) return "mid";
  return undefined;
}

const OPTIONAL_HEADING = /\b(?:preferred|nice[- ]to[- ]have|bonus|desired|desirable|ideally|good[- ]to[- ]have|pluses|extra credit)\b/i;
const REQUIRED_HEADING = /\b(?:minimum|basic|required|requirements|qualifications|what you(?:'ll| will)? need|must[- ]haves?|who you are|you have|about you)\b/i;
/** Whether the text at `index` sits under a "Preferred / Nice to have" heading (a short line) or on a line that says so. */
function optionalSection(text: string, index: number): boolean {
  const lineStart = text.lastIndexOf("\n", index - 1) + 1;
  const line = text.slice(lineStart, index);
  if (OPTIONAL_HEADING.test(line) && !REQUIRED_HEADING.test(line)) return true;
  let end = lineStart - 1;
  for (let lines = 0; end > 0 && lines < 40; lines++) {
    const start = text.lastIndexOf("\n", end - 1) + 1;
    const heading = text.slice(start, end).trim();
    end = start - 1;
    if (!heading || heading.length > 70) continue;
    if (OPTIONAL_HEADING.test(heading)) return true;
    if (REQUIRED_HEADING.test(heading)) return false;
  }
  return false;
}
/** "5+ years of experience", "3-5 years", "minimum of 4 years": the first requirement stated outside a preferred/bonus section. */
export function requiredYears(description: string): { min?: number; max?: number; text?: string } {
  const text = description.slice(0, 60_000);
  const patterns = [
    /(?:at least|minimum(?: of)?|min\.?|over|more than|a minimum of)\s+(\d{1,2})\s*\+?\s*(?:(?:-|–|to)\s*(\d{1,2})\s*)?(?:years?|yrs?)/gi,
    /\b(\d{1,2})\s*(?:\+|plus)?\s*(?:(?:-|–|to)\s*(\d{1,2})\s*\+?\s*)?(?:years?|yrs?)(?:'s)?(?:\s+of)?[^.\n]{0,70}?\b(?:experience|expertise|exp\b|industry|professional|hands[- ]on|work(?:ing)?\b)/gi,
  ];
  const found: { index: number; min: number; max?: number; text: string }[] = [];
  for (const pattern of patterns) for (const match of text.matchAll(pattern)) {
    const min = Number(match[1]), max = match[2] ? Number(match[2]) : undefined;
    if (!Number.isFinite(min) || min < 1 || min > 25 || (max !== undefined && (max < min || max > 30))) continue;
    if (optionalSection(text, match.index)) continue;
    found.push({ index: match.index, min, ...(max !== undefined ? { max } : {}), text: match[0].slice(0, 90) });
  }
  const first = found.sort((a, b) => a.index - b.index)[0];
  return first ? { min: first.min, ...(first.max !== undefined ? { max: first.max } : {}), text: first.text } : {};
}

const MONTHS: Record<string, number> = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, sept: 8, oct: 9, nov: 10, dec: 11 };
function monthOf(raw: string, end: boolean, now: Date): number | undefined {
  const value = raw.trim().toLowerCase();
  if (/^(?:present|current|now|today|ongoing)$/.test(value)) return now.getFullYear() * 12 + now.getMonth();
  const named = value.match(/^([a-z]{3,9})\.?\s+(\d{4})$/);
  if (named) {
    const month = MONTHS[named[1]!.slice(0, 4)] ?? MONTHS[named[1]!.slice(0, 3)];
    if (month !== undefined) return Number(named[2]) * 12 + month;
  }
  const numeric = value.match(/^(\d{1,2})[/.-](\d{4})$/);
  if (numeric && Number(numeric[1]) >= 1 && Number(numeric[1]) <= 12) return Number(numeric[2]) * 12 + Number(numeric[1]) - 1;
  const year = value.match(/^(\d{4})$/);
  if (year) return Number(year[1]) * 12 + (end ? 11 : 0);
  return undefined;
}
/** Your professional experience in years: the saved answer if present, else merged confirmed (non-internship) experience dates. */
export function candidateYears(profile: Pick<Profile, "answers" | "facts">, now = new Date()): number | undefined {
  const saved = Number(profile.answers.total_years_experience);
  if (profile.answers.total_years_experience?.trim() && Number.isFinite(saved) && saved >= 0 && saved <= 60) return saved;
  const ranges: [number, number][] = [];
  for (const fact of profile.facts) {
    if (!fact.confirmed || fact.category !== "experience" || !fact.dates || /\bintern/i.test(`${fact.role ?? ""} ${fact.text}`)) continue;
    const parts = fact.dates.split(/\s*(?:-|–|—|to|until)\s*/i);
    if (parts.length !== 2) continue;
    const start = monthOf(parts[0]!, false, now), end = monthOf(parts[1]!, true, now);
    if (start !== undefined && end !== undefined && end >= start) ranges.push([start, end + 1]);
  }
  if (!ranges.length) return undefined;
  ranges.sort((a, b) => a[0] - b[0]);
  let months = 0, [from, to] = ranges[0]!;
  for (const [start, end] of ranges.slice(1)) {
    if (start <= to) to = Math.max(to, end);
    else { months += to - from; [from, to] = [start, end]; }
  }
  months += to - from;
  return Math.round(months / 6) / 2;
}
/** Levels that fit your years of experience, unless you choose them yourself. */
export function defaultLevels(years: number | undefined): Seniority[] {
  if (years === undefined) return ["entry", "mid", "senior"];
  if (years < 1) return ["entry"];
  if (years < 3) return ["entry", "mid"];
  if (years < 6) return ["mid", "senior"];
  if (years < 10) return ["mid", "senior", "staff"];
  return ["senior", "staff", "principal"];
}

export interface ExperienceFit {
  fit: "match" | "stretch" | "under" | "over" | "unknown";
  level?: Seniority;
  requiredMin?: number;
  reason: string;
  excluded?: string;
}
export function experienceFit(job: Pick<Job, "title" | "description"> & { seniority?: string }, years: number | undefined, levels: Seniority[]): ExperienceFit {
  const level = titleSeniority(job.title);
  const required = requiredYears(job.description);
  if (level && !levels.includes(level)) {
    const rank = (value: Seniority) => SENIORITIES.indexOf(value);
    const below = !["manager", "director"].includes(level) && levels.every(item => rank(item) > rank(level));
    return { fit: below ? "over" : "under", level, ...(required.min !== undefined ? { requiredMin: required.min } : {}),
      reason: `${level} level`, excluded: `The title is ${level} level; you target ${levels.join(", ")}.` };
  }
  if (required.min !== undefined && years !== undefined) {
    const gap = required.min - years;
    if (gap > 2) return { fit: "under", ...(level ? { level } : {}), requiredMin: required.min, reason: `needs ${required.min}+ years`, excluded: `Asks for ${required.min}+ years; you have ${years}.` };
    if (gap > 0) return { fit: "stretch", ...(level ? { level } : {}), requiredMin: required.min, reason: `asks ${required.min}+ years (you have ${years})` };
    if (years - required.min >= 8 && (level === "entry" || level === undefined) && required.min <= 2)
      return { fit: "over", ...(level ? { level } : {}), requiredMin: required.min, reason: `asks only ${required.min}+ years` };
    return { fit: "match", ...(level ? { level } : {}), requiredMin: required.min, reason: `${required.min}+ years fits your ${years}` };
  }
  return { fit: level ? "match" : "unknown", ...(level ? { level } : {}), ...(required.min !== undefined ? { requiredMin: required.min } : {}),
    reason: level ? `${level} level` : required.min !== undefined ? `asks ${required.min}+ years` : "experience not stated" };
}

export interface FitPolicy {
  priority: "abroad-first" | "india-first";
  includeIndia: boolean;
  includeRemoteGlobal: boolean;
  includeAbroadSponsored: boolean;
  includeAbroadUnknown: boolean;
  years?: number;
  levels: Seniority[];
  maxAgeDays: number;
}
export type ExclusionKind = "role" | "blocked" | "experience" | "remote_restricted" | "no_sponsorship" | "settings" | "stale";
export interface JobFit {
  eligible: boolean;
  score: number;
  excluded?: string;
  excludedKind?: ExclusionKind;
  location: LocationFit;
  experience: ExperienceFit;
  familyId?: string;
  familyLabel?: string;
  matchedSkills: string[];
  reasons: string[];
}
const TITLE_BLOCKER = "Title is outside your requested engineering role families.";
/** Roles only a (U.S.) citizen or clearance holder can take. */
const CLEARANCE = /\b(?:ts\/sci|top secret|(?:active|current|secret|public trust)\s+(?:security\s+)?clearance|security clearance (?:is )?required|(?:must|required to) (?:be able to )?(?:obtain|hold|have|maintain) (?:an? )?(?:active )?(?:security |secret |ts )?clearance|polygraph|(?:u\.?s\.?|united states) citizen(?:ship)? (?:is )?required|must be an? (?:u\.?s\.?|united states) citizen|only (?:u\.?s\.?|us) citizens|itar)\b/i;

/** One role scored for your daily list: role family and skills, experience, location/sponsorship and freshness. */
export function jobFit(job: Job, profile: Profile, classification: JobClassification, policy: FitPolicy, companySponsors?: boolean, now = Date.now()): JobFit {
  const location = locationFit(job, companySponsors);
  const experience = experienceFit(job, policy.years, policy.levels);
  const match = matchJob(profile, job);
  const skills = [...new Set([...classification.matchedSkills, ...match.matchedSkills])].slice(0, 12);
  const base = { location, experience, ...(classification.familyId ? { familyId: classification.familyId } : {}),
    ...(classification.familyLabel ? { familyLabel: classification.familyLabel } : {}), matchedSkills: skills };
  const out = (excluded: string, excludedKind: ExclusionKind): JobFit => ({ ...base, eligible: false, score: 0, excluded, excludedKind, reasons: [] });
  if (!classification.relevant || !classification.interested) return out(classification.reason, "role");
  const blockers = match.blockers.filter(blocker => blocker !== TITLE_BLOCKER);
  if (blockers.length) return out(blockers[0]!, "blocked");
  if (CLEARANCE.test(`${job.title}\n${job.description.slice(0, 60_000)}`) && !/united states|\bu\.?s\.?a?\b|american/i.test(profile.answers.citizenship ?? ""))
    return out("Requires a U.S. security clearance or citizenship.", "blocked");
  if (experience.excluded) return out(experience.excluded, "experience");
  const tier = location.tier;
  if (tier === "remote_restricted") return out(location.reason, "remote_restricted");
  if ((tier === "india" || tier === "remote_india") && !policy.includeIndia) return out("Roles in India are turned off in your daily-list settings.", "settings");
  if ((tier === "remote_global" || tier === "remote_apac") && !policy.includeRemoteGlobal) return out("Global remote roles are turned off in your daily-list settings.", "settings");
  if (tier === "abroad" || tier === "unknown") {
    if (location.sponsorship === "not_available") return out(location.reason, "no_sponsorship");
    if (location.sponsorship === "available" && !policy.includeAbroadSponsored) return out("Roles abroad are turned off in your daily-list settings.", "settings");
    if (location.sponsorship === "unknown" && !policy.includeAbroadUnknown) return out("Roles abroad that do not mention visa sponsorship are turned off in your daily-list settings.", "settings");
  }
  const posted = job.postedAt ? Date.parse(job.postedAt) : NaN;
  const age = Number.isFinite(posted) ? (now - posted) / 86400_000 : undefined;
  if (age !== undefined && age > policy.maxAgeDays) return out(`Posted ${Math.round(age)} days ago (older than your ${policy.maxAgeDays}-day limit).`, "stale");
  const abroadFirst = policy.priority === "abroad-first";
  const locationPoints = tier === "abroad" || tier === "unknown"
    ? location.sponsorship === "available" ? (abroadFirst ? 16 : 10) : 1
    : tier === "remote_apac" ? 9 : abroadFirst ? 12 : 16;
  const experiencePoints = { match: 10, stretch: 3, unknown: 5, over: -4, under: 0 }[experience.fit];
  const freshness = age === undefined ? 0 : age <= 7 ? 6 : age <= 21 ? 3 : age > 45 ? -3 : 0;
  const score = Math.max(0, Math.min(100, Math.round(20 + match.score * 0.35 + Math.min(classification.matchedSkills.length, 8) * 2.5
    + experiencePoints + locationPoints + freshness)));
  const reasons = [
    `${classification.familyLabel ?? "Role family"} match${skills.length ? `: ${skills.slice(0, 5).join(", ")}` : ""}`,
    location.reason,
    `Experience: ${experience.reason}.`,
    ...(age !== undefined ? [`Posted ${age < 1 ? "today" : `${Math.round(age)} day${Math.round(age) === 1 ? "" : "s"} ago`}.`] : []),
    ...(job.aiPolicy === "prohibited" ? ["The posting restricts AI help: fill it with saved answers only."] : []),
  ];
  return { ...base, eligible: true, score, reasons };
}
