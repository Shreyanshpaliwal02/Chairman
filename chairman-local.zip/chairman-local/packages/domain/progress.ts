import type { JobClassification, RoleFamily } from "./role-families.js";
import type { CareerSource } from "./types.js";

/**
 * Where an application stands, as shown in Progress. "applied" always has proof (see ApplicationEvidence);
 * "marked" means you said you applied but no confirmation has been seen, so it is never counted as applied.
 */
export type ProgressStatus = "applied" | "marked" | "in_progress" | "needs_you" | "not_applied" | "not_relevant" | "failed";
/** Proof that an application was submitted. A click on "I submitted it" is not proof. */
export interface ApplicationEvidence {
  /**
   * confirmation_page: the extension saw the employer's "application received" page in the tab you applied in.
   * runner_receipt: the Chairman window submitted and verified the result. recorded_receipt: you recorded a
   * confirmation number or text. confirmation_email: an employer email acknowledged it.
   */
  kind: "confirmation_page" | "runner_receipt" | "recorded_receipt" | "confirmation_email";
  at: string;
  /** What was seen and where, in plain words. */
  detail: string;
  url?: string;
}
export interface ProgressJob {
  jobId: string;
  title: string;
  location: string;
  countries: string[];
  remote: boolean;
  department?: string;
  yearsRequired?: { min: number; max?: number };
  applyUrl: string;
  fetchedAt: string;
  classification: JobClassification;
  status: ProgressStatus;
  /** What happened or what is needed, in plain words. */
  detail: string;
  updatedAt?: string;
  /** How the application was (or is being) made. */
  channel?: "auto_apply" | "extension" | "manual" | "packet";
  resume?: string;
  /** Present exactly when status is "applied". */
  evidence?: ApplicationEvidence;
  /** For in-progress extension applications: filled at least once, or stopped at the final step for your review. */
  step?: "filled" | "review";
}
export interface ProgressCompany {
  source: CareerSource;
  company: string;
  roleFamilies: string[];
  counts: Record<ProgressStatus, number> & { total: number };
  jobs: ProgressJob[];
}
export interface ProgressView {
  companies: ProgressCompany[];
  /** Companies you track without a public board: their careers pages, to check yourself. */
  manual: { name: string; careersUrl: string; notes?: string }[];
  families: RoleFamily[];
  candidateYears?: number;
  totals: Record<ProgressStatus, number> & { total: number };
  generatedAt: string;
}
/** A real form question with no saved answer, collected so you can answer it once for every future form. */
export interface InboxQuestion {
  id: string;
  label: string;
  type: string;
  options: string[];
  required: boolean;
  /** Question-bank key this wording maps to, when known. */
  bankKey?: string;
  seen: number;
  companies: string[];
  firstSeenAt: string;
  lastSeenAt: string;
}
export interface AnswerBankExport {
  format: "chairman-answers";
  version: 1;
  exportedAt: string;
  answers: Record<string, string>;
  preferences: { authorizedCountries: string[]; needsSponsorshipAbroad: boolean; fillVoluntaryDisclosures: boolean; acceptRequiredAcknowledgements: boolean };
}
