import type { PipelineStage } from "./types.js";

export interface GmailSuggestion {
  id: string;
  messageId: string;
  applicationId: string;
  applicationKind: "packet" | "external";
  jobId: string;
  company: string;
  title: string;
  subject: string;
  sender: string;
  receivedAt: string;
  stage: PipelineStage;
  previousStage: PipelineStage;
}

export interface GmailStatus {
  configured: boolean;
  connected: boolean;
  authorizing: boolean;
  busy: boolean;
  lastScanAt?: string;
  nextScanAt?: string;
  error?: string;
  suggestions: GmailSuggestion[];
}
