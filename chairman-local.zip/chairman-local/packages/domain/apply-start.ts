/**
 * Where an application starts, skipping the job-description page where the site links straight to its application form.
 * Workday: "Autofill with Resume" (you upload your resume and Workday fills your work history and education from it; this
 * is the first of the three options its Apply button offers). Lever: /apply. Ashby: /application. Other sites are unchanged.
 */
export const WORKDAY_HOST = /\.myworkdayjobs\.com$|^wd\d{1,3}\.myworkdaysite\.com$/;
export function applicationStartUrl(raw: string): string {
  let url: URL;
  try { url = new URL(raw); } catch { return raw; }
  const path = url.pathname.replace(/\/+$/, "");
  if (WORKDAY_HOST.test(url.hostname) && /\/job\//.test(path) && !/\/apply(?:\/|$)/.test(path)) { url.pathname = `${path}/apply/autofillWithResume`; url.hash = ""; return url.href; }
  if (/^jobs(?:\.eu)?\.lever\.co$/.test(url.hostname) && /^\/[^/]+\/[0-9a-f-]{36}$/i.test(path)) { url.pathname = `${path}/apply`; return url.href; }
  if (url.hostname === "jobs.ashbyhq.com" && /^\/[^/]+\/[0-9a-f-]{36}$/i.test(path)) { url.pathname = `${path}/application`; return url.href; }
  return url.href;
}
