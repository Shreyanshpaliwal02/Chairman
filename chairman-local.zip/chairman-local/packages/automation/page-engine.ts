import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";

/**
 * The extension's page scanner and filler (apps/extension/assist-page.ts), bundled once as `globalThis.ChairmanPage`,
 * so the dedicated runner detects and fills questions exactly like the extension does.
 */
let source: Promise<string> | undefined;
const entry = fileURLToPath(new URL("../../apps/extension/assist-page.ts", import.meta.url));
const prebuilt = fileURLToPath(new URL("../../dist/runner/page-engine.js", import.meta.url));

export function pageEngineSource(): Promise<string> {
  source ??= (async () => {
    try {
      const { build } = await import("esbuild");
      const result = await build({ entryPoints: [entry], bundle: true, write: false, format: "iife", globalName: "ChairmanPage", platform: "browser", target: "chrome120", logLevel: "silent" });
      return result.outputFiles[0]!.text;
    } catch (error) {
      try { return await readFile(prebuilt, "utf8"); }
      catch { throw new Error(`The page engine could not be prepared: ${error instanceof Error ? error.message : String(error)}`); }
    }
  })();
  source.catch(() => { source = undefined; });
  return source;
}

/** Defines ChairmanPage in the page once per document; page scripts cannot pre-define it to intercept fills. */
export function pageEngineInstaller(bundle: string): string {
  return `(() => { if (globalThis.__chairmanPageEngine === 1 && globalThis.ChairmanPage) return true;
    ${bundle}
    Object.defineProperty(globalThis, "ChairmanPage", { value: ChairmanPage, configurable: false, writable: false });
    Object.defineProperty(globalThis, "__chairmanPageEngine", { value: 1, configurable: false, writable: false });
    return true; })()`;
}
