import type { AutomationProvider, FormSnapshot, Job, Profile } from "../domain/types.js";
import type { AssistancePage } from "../domain/extension-assist.js";

/** What the assisted runner may send on the current page without review, and what still needs you. */
export interface PagePlan {
  fill: Record<string, string>;
  sources: Record<string, string>;
  needs: { key: string; label: string; required: boolean; reason: string }[];
  /** Resume upload control on this page, when it is empty. */
  resumeKey?: string;
  notes: string[];
  debug?: string[];
}

export interface BrowserInspection {
  status: "ready" | "needs_input" | "auth_required" | "captcha_required" | "unsupported" | "job_closed";
  provider?: AutomationProvider;
  snapshot?: FormSnapshot;
  reason: string;
  retryAfterMs?: number;
}
export interface BrowserSubmission {
  status: "submitted_confirmed" | "submission_unknown" | "failed" | "needs_input" | "auth_required" | "captcha_required" | "unsupported" | "cancelled";
  reason: string;
  evidence?: string;
  retryAfterMs?: number;
}
export interface BrowserSubmitInput {
  job: Job;
  snapshot: FormSnapshot;
  answers: Record<string, string>;
  resumePath: string;
  resumeFilename: string;
  resumeSha256: string;
  checkAuthorization: () => Promise<boolean>;
  beforeSubmit: () => Promise<void>;
}
export interface ApplicationBrowserDriver {
  inspect(job: Job): Promise<BrowserInspection>;
  submit(input: BrowserSubmitInput): Promise<BrowserSubmission>;
  openForSetup(url?: string): Promise<void>;
  isRunning(): boolean;
  close(): Promise<void>;
  runWorkflow?(input: WorkflowInput): Promise<WorkflowResult>;
  resumeWorkflow?(sessionId: string, input: HumanContinuation): Promise<WorkflowResult>;
  focusWorkflow?(sessionId: string): Promise<void>;
  screenshotWorkflow?(sessionId?: string): Promise<Buffer | undefined>;
  abandonWorkflow?(sessionId: string): Promise<void>;
  /** Checks parked tabs without touching them: a CAPTCHA you solved, or a receipt that appeared after you finished a challenge. */
  watchWaiting?(): Promise<WaitingSignal[]>;
}
export interface WaitingSignal {
  sessionId: string;
  signal: "captcha_solved" | "receipt_visible" | "challenge_cleared";
}
export interface AnswerPlan {
  answers: Record<string, string>;
  missing: string[];
  blockers: string[];
  /** Provenance per answered key: `answers:<bank key>` or `profile:<canonical field>`. */
  sources?: Record<string, string>;
}
export type AnswerResolver = (profile: Profile, job: Job, snapshot: FormSnapshot) => AnswerPlan;

export interface WorkflowProgress {
  phase: "navigating" | "inspecting" | "prefilling" | "uploading" | "advancing" | "awaiting_human" | "submitting" | "confirming";
  message: string;
  step: number;
  url: string;
  filledFields: string[];
  missingFields: FormSnapshot["fields"];
}
export interface WorkflowInput {
  job: Job;
  resumePath: string;
  resumeFilename: string;
  resumeSha256: string;
  resumeAlternatives?: { path: string; filename: string; sha256: string }[];
  onResumeSelected?: (sha256: string) => Promise<void>;
  allowHuman: boolean;
  resolveAnswers: (snapshot: FormSnapshot, overrides?: Record<string, string>) => Promise<AnswerPlan>;
  checkAuthorization: () => Promise<boolean>;
  beforeTransmit: (snapshot: FormSnapshot, answers: Record<string, string>, humanSupplied: boolean) => Promise<void>;
  beforeSubmit: () => Promise<void>;
  onProgress: (progress: WorkflowProgress) => Promise<void>;
  /** Plans a page scanned by the extension's page scanner. When present, the runner fills with the same engine as the extension. */
  planPage?: (page: AssistancePage) => Promise<PagePlan>;
  /** Profile → "Accept required acknowledgements" is on: required consent the plan accepted, and "by submitting you agree" text, do not stop the run. */
  acceptAcknowledgements?: boolean;
  /** Records each acknowledgement accepted in your name. */
  onAcknowledge?: (labels: string[]) => Promise<void>;
}
export interface HumanContinuation {
  answers: Record<string, string>;
  useCurrentValues: boolean;
}
export interface WorkflowResult {
  status: "submitted_confirmed" | "submission_unknown" | "failed" | "human_required" | "unsupported" | "cancelled";
  /** Why the tab waits: a CAPTCHA before Submit, a challenge raised by Submit, or answers/other review. */
  waitingFor?: "captcha" | "captcha_after_submit" | "answers";
  reason: string;
  evidence?: string;
  sessionId?: string;
  progress?: WorkflowProgress;
  retryAfterMs?: number;
}
