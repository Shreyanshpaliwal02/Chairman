# Generic portal workflows and human review

`PortalBrowser` is the monitored application runner. It supplements the older
provider-specific driver with ordinary company application forms and a bounded
multi-step workflow; it is not a universal browser agent.

## Supported path

- The initial URL must be a public HTTPS company/application URL. Known restricted
  job boards, private-network addresses, credentials in URLs and unsafe routes
  are rejected. Constructor-only loopback allowances exist for synthetic tests.
- A single recognizable application form, or one same-origin Apply link, is
  required. On HTTPS pages the runner reads and fills questions with the
  extension's page engine (`apps/extension/assist-page.ts`, bundled by
  `page-engine.ts`) and the service's page planner, so custom Yes/No buttons,
  React-style comboboxes, the correct resume uploader and conditional questions
  behave exactly as in the extension. Other pages use the native scanner for
  labeled text fields, textareas, native selects/radios, explicit choices,
  approved file uploads and public combobox choices. Ambiguous controls, required
  manual-only controls and native validity errors become human-review tasks.
- Up to ten application steps can advance through unambiguous Next/Continue
  actions. The final submit boundary is persisted before its click. Exact
  answer/file acceptance is rechecked, including changes made by resume autofill.
- PDF and DOCX alternatives must both come from the already approved packet.
  The compatible file is selected by the form's accept list; its exact SHA-256
  is recorded before upload. This is not permission to fetch or invent another file.
- A new, attributable confirmation region plus an observed successful submission
  request is needed for automatic confirmation. Arbitrary success text, old
  receipts, missing responses and uncertain navigation do not count as success.

Known answers and a compatible resume are filled before an ordinary missing-answer
handoff. No-AI/own-words policies stop generated material before transmission.
Credentials, CAPTCHA and assessments are not filled by the assistant. Required
legal checkboxes are clicked only when Profile → *Accept required acknowledgements*
is on (each one is recorded as an `acknowledgement` event); otherwise a human may
complete them directly and explicitly approve the current form, except where
policy requires the entire process to remain manual.

## CAPTCHA hand-off

A tab whose only blocker is a CAPTCHA parks with `waitingFor: "captcha"` and a
`🔐 Solve CAPTCHA` title prefix. `watchWaiting()` reads the widget's response
token (`g-recaptcha-response`, `h-captcha-response`, `cf-turnstile-response`)
without touching the page; once you have solved it, the autopilot queues the
continuation, which re-verifies the form and submits once. A challenge raised by
Submit parks with `waitingFor: "captcha_after_submit"`; its continuation only
checks for the receipt (a new confirmation plus an observed successful
submission response) and never clicks Submit again. Nothing is solved or bypassed.

## Human-in-the-loop behavior

`human_required` retains the actual browser tab and returns a session ID plus
field names already filled and pending questions. The backend stores a task with
private execution credentials; those credentials are excluded from dashboard/SSE
responses.

The dashboard can focus the existing tab, supply explicit one-off factual answers,
continue it, record a manually verified receipt, or abandon it. Continuing does
not open a replacement application or consume a second attempt. Up to 50 parked
tabs (Auto Apply → *Tabs waiting for you*, 10 by default) are retained while other
jobs progress; a new job's tab does not take focus from the tab you are viewing. An uncertain final submission cannot
be continued automatically; its retained tab is for manual receipt review.

Opening a parked tab for manual review hands control to the user. Normal public
HTTPS sign-in/identity-provider pages and popups can be used by the user; the
assistant neither fills those pages nor extracts their credentials. Automatic
continuation returns to the original approved application origin. Cross-origin
application routing and unrecognized embedded flows require human handling.

Closing/restarting the browser loses those live sessions. Durable records become
unknown/session-lost rather than being replayed. Changing profile, templates or
authorization scope invalidates automatic continuation of the old session.

## Network and privacy

Chrome uses a fixed loopback security proxy that resolves destinations and connects
to the verified public address. HTTPS remains end-to-end encrypted; the proxy
does not decrypt or log application data. It blocks private/reserved destinations
and is not a rotating proxy, anti-bot workaround or CAPTCHA bypass.

Automatic application navigation remains origin-scoped. Data requests may reach
the application's own site (for example `boards-api.greenhouse.io` from
`job-boards.greenhouse.io`) under the standing authorization. Requests to other
sites (analytics, monitoring) are dropped without stopping the run and are listed
in an uncertain outcome's reason. CAPTCHA provider frames load inside the tab but
never as the tab itself. Blocked nonessential static resources are not silently
converted into required form answers. Manual browser control is explicit and
separate from automatic actions.

The optional local screenshot endpoint masks form controls, editable content,
iframes and credential/dialog regions. Cross-origin sign-in screens are not shown
as application screenshots. Images are not sent to a model or public service.

Live progress uses authenticated, same-origin server-sent events. It reports
phases, field names and reasons, not passwords, cookies or execution tokens.
Only the stored receipt/user-reported confirmation changes submission counts.

## Limitations

Some SPA widgets, embedded cross-origin ATS flows, login requirements, portals
with special file-upload protocols and custom receipts will need human handling.
No claim is made that every career portal works unattended or that 500 confirmed
applications are available or achievable each day.

AI is not needed for browser control. The selected AI provider may assist factual
resume selection; Copilot requires separate hosted-processing consent, OAuth
sign-in and exact model access. It never receives browser cookies or credentials.
