import { lookup } from "node:dns/promises";
import { createServer, request as httpRequest, type Server } from "node:http";
import { connect, isIP, type Socket } from "node:net";
import { isPublicIpAddress } from "../adapters/public-page.js";

/** A local security boundary, not an application proxy: production traffic is opaque TLS. */
export class PortalEgressProxy {
  private server?: Server;
  private readonly sockets = new Set<Socket>();
  private closing = false;

  constructor(private readonly testOrigins: ReadonlySet<string> = new Set()) {}

  private async destination(host: string, port: number, protocol: string): Promise<string> {
    host = host.replace(/^\[|\]$/g, "");
    const literal = isIP(host);
    const authority = literal === 6 ? `[${host}]` : host;
    const url = new URL(`${protocol}//${authority}:${port}`);
    // Playwright's redirect-inspecting transport uses CONNECT even for HTTP fixtures.
    const fixture = this.testOrigins.has(url.origin) ||
      protocol === "https:" && this.testOrigins.has(new URL(`http://${authority}:${port}`).origin);
    if ((!fixture && (protocol !== "https:" || port !== 443)) ||
        (!literal && (!/^[a-z0-9-]+(?:\.[a-z0-9-]+)+$/i.test(host) ||
          /\.(?:local|localhost|internal|test|invalid|onion|lan|home|corp|arpa)$/i.test(host)))) {
      if (!(fixture && host === "localhost")) throw new Error("Denied destination");
    }
    const addresses = literal ? [{ address: host, family: literal }] : await Promise.race([
      lookup(host, { all: true, verbatim: true }),
      new Promise<never>((_, reject) => {
        const timer = setTimeout(() => reject(new Error("DNS timeout")), 5000);
        timer.unref();
      }),
    ]);
    if (!addresses.length || addresses.some(({ address, family }) => isIP(address) !== family ||
      !(isPublicIpAddress(address) || fixture && ["127.0.0.1", "::1"].includes(address)))) {
      throw new Error("Denied address");
    }
    if (this.closing) throw new Error("Proxy closed");
    return addresses[0]!.address;
  }

  async start(): Promise<string> {
    if (this.server) throw new Error("Proxy already started");
    this.closing = false;
    const server = this.server = createServer(async (incoming, outgoing) => {
      // Plain HTTP exists only for explicit local fixtures. Never forward production HTTP.
      try {
        const url = new URL(incoming.url ?? "");
        if (!this.testOrigins.has(url.origin) || url.protocol !== "http:" || url.username || url.password) throw new Error("Denied");
        const address = await this.destination(url.hostname, Number(url.port || 80), url.protocol);
        const headers = { ...incoming.headers };
        delete headers["proxy-authorization"];
        delete headers["proxy-connection"];
        const upstream = httpRequest({
          hostname: address, port: Number(url.port || 80), path: `${url.pathname}${url.search}`,
          method: incoming.method, headers, agent: false, timeout: 20_000,
        }, response => {
          outgoing.writeHead(response.statusCode ?? 502, response.headers);
          response.pipe(outgoing);
        });
        upstream.on("socket", socket => this.track(socket));
        upstream.on("timeout", () => upstream.destroy());
        upstream.on("error", () => { if (!outgoing.headersSent) outgoing.writeHead(502); outgoing.end(); });
        incoming.on("aborted", () => upstream.destroy());
        outgoing.on("close", () => upstream.destroy());
        incoming.pipe(upstream);
      } catch { outgoing.writeHead(403); outgoing.end(); }
    });
    server.on("connection", socket => {
      if (this.sockets.size >= 128) { socket.destroy(); return; }
      this.track(socket);
      socket.setTimeout(60_000, () => socket.destroy());
    });
    server.on("connect", async (request, client, head) => {
      try {
        if (!/^(?:[a-z0-9.-]+|\[[a-f0-9:]+\]):\d{1,5}$/i.test(request.url ?? "")) throw new Error("Denied");
        const url = new URL(`https://${request.url}`);
        if (url.username || url.password) throw new Error("Denied");
        const port = Number(url.port || 443);
        const address = await this.destination(url.hostname, port, "https:");
        if (client.destroyed) return;
        const upstream = connect({ host: address, port });
        this.track(upstream);
        upstream.setTimeout(60_000, () => upstream.destroy());
        upstream.once("connect", () => {
          if (client.destroyed) { upstream.destroy(); return; }
          client.write("HTTP/1.1 200 Connection Established\r\n\r\n");
          if (head.length) upstream.write(head);
          client.pipe(upstream);
          upstream.pipe(client);
        });
        upstream.on("error", () => client.destroy());
        client.on("error", () => upstream.destroy());
        client.on("close", () => upstream.destroy());
        upstream.on("close", () => client.destroy());
      } catch { client.end("HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n"); }
    });
    server.on("clientError", (_, socket) => socket.destroy());
    await new Promise<void>((accept, reject) => {
      server.once("error", reject);
      server.listen(0, "127.0.0.1", () => { server.off("error", reject); accept(); });
    });
    const address = server.address();
    if (!address || typeof address === "string") throw new Error("Proxy failed to bind");
    return `http://127.0.0.1:${address.port}`;
  }

  private track(socket: Socket): void {
    this.sockets.add(socket);
    socket.once("close", () => this.sockets.delete(socket));
  }

  async close(): Promise<void> {
    this.closing = true;
    for (const socket of this.sockets) socket.destroy();
    this.sockets.clear();
    const server = this.server;
    this.server = undefined;
    if (server) await new Promise<void>(accept => server.close(() => accept()));
  }
}
