import type { FormField, FormSnapshot, Job, Profile } from "../domain/types.js";
import { hasNoAiRestriction } from "../documents/safety.js";
import type { AnswerPlan } from "./contracts.js";
import { matchChoice, synonymChoice } from "../domain/assist-match.js";
import { DISCLOSURE_KEYS, QUESTION_BANK } from "../domain/question-bank.js";
import { inferCountries } from "../domain/job-fit.js";

/** `derived` names what a value was worked out from (your location, phone number, work history…) when it is not a saved answer. */
type Answer = { value?: string; source?: string; error?: string; derived?: string };
type Question = { key: string; unit?: string; currency?: string };
const controls = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff\ufffe\uffff]/u;
const own = (record: Record<string, string>, key: string): string | undefined =>
  Object.hasOwn(record, key) ? record[key] : undefined;

function normalize(text: string): string {
  return text.normalize("NFC").toLowerCase().replace(/[‘’]/g, "'")
    .replace(/[_-]/g, " ").replace(/\s+/g, " ").trim()
    .replace(/(?:\s*\((?:required|optional)\)|\s*[*?:])+\s*$/g, "").trim();
}

const questions = new Map<string, Question>();
function aliases(key: string, labels: string[], unit?: string): void {
  for (const label of [key, ...labels]) questions.set(normalize(label), { key, unit });
}

aliases("name", ["full name", "your name", "your full name", "applicant name", "legal full name", "full legal name", "legal name", "preferred full name", "name (first and last)"]);
aliases("first_name", ["first name", "given name", "given name(s)", "given names", "first name(s)", "legal first name", "legal given name", "legal given name(s)",
  "first name (legal)", "first/given name", "forename"]);
aliases("last_name", ["last name", "family name", "surname", "family name(s)", "family names", "surname(s)", "last name(s)", "legal last name", "legal family name",
  "last name (surname)", "last/family name"]);
aliases("email", ["email address", "e-mail", "e-mail address", "your email", "your email address"]);
aliases("phone", ["phone number", "telephone", "telephone number", "mobile", "mobile number", "contact number", "mobile phone", "mobile phone number", "cell phone", "cell phone number", "primary phone"]);
aliases("location", ["current location", "your location", "location (city)", "where are you based?", "where are you located?", "location - city, state", "location (city, state)", "city, state", "current city and state"]);
aliases("work_location", ["work location", "planned work location", "where do you plan on working?", "where would you plan on working?"]);
aliases("linkedin", ["linkedin url", "linkedin profile", "linkedin profile url"]);
aliases("github", ["github url", "github profile", "github profile url"]);
aliases("city", ["current city", "city of residence", "town/city", "city/town", "city / town", "city or town", "town"]);
aliases("country", ["current country", "country of residence", "country/region", "country / region", "country or region", "residence country"]);
aliases("postal_code", ["postal code", "zip", "zip code", "postcode", "post code", "postal/zip code", "zip / postal"]);
aliases("phone_country_code", ["country phone code", "phone country code", "country code", "country calling code", "dialing code", "dial code", "phone code", "country dial code"]);
aliases("phone_device_type", ["phone device type", "phone type", "device type", "type of phone"]);
aliases("notice_period_days", ["notice period (days)", "notice period in days", "notice period days"], "days");
aliases("available_start_date", ["available start date", "earliest start date", "when can you start?", "when are you available to start?"]);
aliases("total_years_experience", [
  "total years of experience", "years of experience", "total experience (years)",
  "how many years of experience do you have?", "how many total years of experience do you have?",
], "years");
aliases("willing_to_relocate", ["willing to relocate", "are you willing to relocate?", "are you open to relocation?", "relocation willingness", "are you open to relocation for this role?",
  "are you willing to relocate for this role?", "are you willing to relocate for this position?", "would you be willing to relocate?", "are you open to relocating?", "would you consider relocating?"]);
aliases("travel_willingness", ["travel willingness", "willingness to travel", "are you willing to travel?"]);
aliases("cover_letter", ["cover letter", "covering letter", "your cover letter", "cover letter text", "please provide a cover letter"]);
aliases("motivation", [
  "why this role?", "why are you interested in this role?", "why are you interested in this position?",
  "why do you want this role?", "what interests you about this role?", "why do you want to work here?",
  "why are you interested in working with us?", "motivation for applying",
  "why {company}?", "why do you want to work at {company}?", "why do you want to join {company}?", "why are you interested in {company}?",
  "why are you interested in working at {company}?", "what excites you about {company}?", "what interests you about {company}?", "why do you want to work for {company}?",
]);
for (const entry of QUESTION_BANK) {
  if (entry.key.startsWith("expected_salary_") || entry.profileField && !entry.aliases.length) continue;
  aliases(entry.key, [entry.label, ...entry.aliases], entry.unit);
}
// Keys whose questions mention protected or eligibility terms but are answered only from your explicit saved answer.
const EXPLICIT_ONLY = new Set([...DISCLOSURE_KEYS, "citizenship", "visa_status", "age_18_or_over"]);
const escapeRegex = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
/** "Have you worked at Confluent?" is the same saved question as "Have you worked at {company}?". */
function companyQuestion(text: string, company: string): Question | undefined {
  const name = company.trim();
  if (name.length < 2 || !text.toLowerCase().includes(name.toLowerCase())) return undefined;
  return questions.get(normalize(text.replace(new RegExp(escapeRegex(name), "gi"), "{company}")));
}
/**
 * Recognized question shapes for wordings no alias list can enumerate ("Have you ever been issued a Cisco Employee ID…",
 * "Are you open to working in-person in one of our offices 25% of the time?"). Checked only after exact aliases.
 */
function patternQuestion(label: string, company: string): Question | undefined {
  const text = normalize(label);
  const name = company.trim().toLowerCase();
  const mentions = name.length >= 2 && text.includes(name);
  const history = /\b(?:previously|formerly|ever|before|prior|past)\b/.test(text);
  if (/\binterview(?:ed|s)?\b/.test(text) && history && (mentions || /\b(?:with us|here|our company)\b/.test(text))) return { key: "interviewed_here_before" };
  if (mentions && (/\b(?:issued|had|have|given|received)\b.{0,60}\b(?:employee (?:id|number)|employee email|email address|badge)\b/.test(text)
    || history && /\b(?:employed|worked|work(?:ing)? (?:for|at)|intern(?:ed)?|contract(?:ed|or)|employee)\b/.test(text)
    || /\b(?:current or former|former|ex)[- ](?:employee|intern|contractor|worker)s?\b/.test(text))) return { key: "previously_employed_here" };
  if (/\breloca(?:te|tion|ting)\b/.test(text) && /\b(?:open|willing|consider|able)\b/.test(text) && !/\b(?:assistance|support|package|help|benefit)\b/.test(text)) return { key: "willing_to_relocate" };
  if (/\b(?:open|willing|able|comfortable|available)\b/.test(text) && /\b(?:in[- ]person|on[- ]?site|in (?:the|our|an|one of our) offices?|in[- ]office|from (?:the|our) office|hybrid)\b/.test(text)) return { key: "open_to_onsite" };
  if (/\bhow (?:did|do) you (?:hear|find out|learn|come across)\b|\bwhere did you (?:hear|find|see|learn)\b|\breferral source\b/.test(text)) return { key: "how_did_you_hear" };
  if (/\b(?:earliest|soonest|when)\b.{0,40}\b(?:start|join|begin)\b/.test(text) && !/\b(?:started|previous|last)\b/.test(text)) return { key: "available_start_date" };
  // Notice: the last working day, whether you are serving notice (a yes/no question), then the notice period itself.
  if (/\blast (?:working|work|employment) (?:day|date)\b|\blast day (?:of work|at (?:your )?(?:current|present) (?:company|employer|organi[sz]ation|job))\b|\brelieving date\b|\blwd\b/.test(text)) return { key: "last_working_day" };
  if (/\bserving\b.{0,30}\bnotice\b/.test(text)) return { key: "serving_notice_period" };
  if (/\bnotice period\b/.test(text) && !/^(?:are|is|do|does|did|can|could|will|would|have|has)\b/.test(text)
    && !/\b(?:negotiable|buy ?out|early release|reduc|shorten|serv(?:ing|ed))/.test(text)) return { key: "notice_period_days" };
  return undefined;
}
const marketingWording = /\b(?:opt in|subscribe|newsletter|marketing|text messages?|sms|(?:receive|send me|sign me up for) .{0,100}(?:updates|communications|news|offers|alerts|messages)|keep me (?:informed|updated)|talent (?:community|network)|contact me about (?:future|other) (?:roles|jobs|opportunities))\b/i;
/** The single affirmative choice of a required acknowledgement (checkbox "true", or an "I agree / I acknowledge" option). */
function acknowledgementAnswer(field: FormField): string | undefined {
  if (field.type.toLowerCase() === "checkbox") return "true";
  const affirmative = field.options.filter((value) => {
    const label = normalize(own(field.optionLabels ?? {}, value) ?? value);
    return /^(?:yes\b[\s,.-]*)?(?:i\s+)?(?:agree|acknowledge|accept|consent|certify|confirm|understand|have read)\b/.test(label) || /^(?:yes|i do|agree|accept)$/.test(label);
  });
  return affirmative.length === 1 ? affirmative[0] : undefined;
}

const narrativeTemplates = new Map([
  ["cover_letter", "cover_letter_template"],
  ["motivation", "motivation_template"],
]);
const isTemplateKey = (key: string) => [...narrativeTemplates.values()].includes(key);
export const instructionLike = /\b(?:ignore|override|disregard)\b.{0,100}\b(?:instructions?|policy|rules?|profile|previous|above)\b|\b(?:system prompt|developer message|tool calls?|execute (?:code|command)|run (?:this |the )?(?:command|script)|pretend|fabricate|invent qualifications)\b/i;

// These are name equivalents, not transferable skills or inferred experience.
const technologies: Record<string, string[]> = {
  python: ["Python"], javascript: ["JavaScript", "JS"], typescript: ["TypeScript", "TS"],
  java: ["Java"], scala: ["Scala"], rust: ["Rust"], go: ["Go", "Golang"], ruby: ["Ruby"],
  sql: ["SQL"], cpp: ["C++"], csharp: ["C#"], c: ["C"], r: ["R"],
  aws: ["AWS", "Amazon Web Services"], azure: ["Azure", "Microsoft Azure"],
  gcp: ["GCP", "Google Cloud", "Google Cloud Platform"],
  kubernetes: ["Kubernetes", "K8s"], docker: ["Docker"], terraform: ["Terraform"],
  spark: ["Spark", "Apache Spark"], pyspark: ["PySpark"], databricks: ["Databricks"],
  snowflake: ["Snowflake"], airflow: ["Airflow", "Apache Airflow"], kafka: ["Kafka", "Apache Kafka"],
  postgresql: ["PostgreSQL", "Postgres"], mysql: ["MySQL"], react: ["React", "React.js", "ReactJS"],
  react_native: ["React Native"], nodejs: ["Node.js", "NodeJS"], machine_learning: ["machine learning"],
};
for (const [key, names] of Object.entries(technologies)) {
  aliases(`years_${key}`, names.flatMap((name) => [
    `years_${name}`, `years of ${name} experience`, `years of experience with ${name}`,
    `years of experience in ${name}`, `${name} experience (years)`, `${name} experience in years`,
    `how many years of experience do you have with ${name}?`,
    `how many years of experience do you have in ${name}?`,
  ]), "years");
}

const currencies = new Set("AED AUD BDT BRL CAD CHF CNY CZK DKK EGP EUR GBP HKD IDR ILS INR JPY KRW MXN MYR NOK NZD PHP PKR PLN QAR RON SAR SEK SGD THB TRY TWD UAH USD VND ZAR".split(" "));
const periodWords: Record<string, string> = {
  annual: "annual", annually: "annual", yearly: "annual", year: "annual",
  monthly: "monthly", month: "monthly", hourly: "hourly", hour: "hourly",
};
function currencyIn(text: string): string | undefined {
  const found = currenciesIn(text);
  return found.length === 1 ? found[0] : undefined;
}
function currenciesIn(text: string): string[] {
  return [...new Set((text.toUpperCase().match(/\b[A-Z]{3}\b/g) ?? []).filter((word) => currencies.has(word)))];
}
function periodsIn(text: string): string[] {
  return [...new Set((normalize(text).match(/\b(?:annual(?:ly)?|yearly|year|monthly|month|hourly|hour)\b/g) ?? [])
    .map((word) => periodWords[word]))];
}
function periodIn(text: string): string | undefined {
  const periods = periodsIn(text);
  return periods.length === 1 ? periods[0] : undefined;
}
function salaryQuestion(text: string): Question | undefined {
  const label = normalize(text);
  const currency = currencyIn(label);
  const unit = periodIn(label);
  const rest = label.replace(/\b(?:annual(?:ly)?|yearly|year|monthly|month|hourly|hour|per|in)\b/g, "")
    .replace(/\b[a-z]{3}\b/g, (word) => currencies.has(word.toUpperCase()) ? "" : word)
    .replace(/[()/]/g, " ").replace(/\s+/g, " ").trim();
  if (!["expected salary", "salary expectations", "desired salary", "what is your expected salary", "what are your salary expectations"].includes(rest)) return undefined;
  return { key: currency ? `expected_salary_${currency}${unit ? `_${unit}` : ""}` : "expected_salary", currency, unit };
}
const question = (text: string): Question | undefined => questions.get(normalize(text)) ?? salaryQuestion(text);
/** What a visible question asks for: exact aliases, then "{company}" wordings, then recognized question shapes. */
function meaningOf(text: string, company: string): Question | undefined {
  return question(text) ?? companyQuestion(text, company) ?? patternQuestion(text, company);
}
/** Canonical answer-bank key recognized for a visible question, if any (closed alias list and salary patterns; with a company, also "{company}" wordings and question shapes). */
export function questionKey(text: string, company?: string): string | undefined { return (company !== undefined ? meaningOf(text, company) : question(text))?.key; }
/** The resolver's own question normalization, for exact-question answer matching elsewhere. */
export function normalizeQuestion(text: string): string { return normalize(text); }

function entriesAnswer(entries: [string, string][]): Answer {
  if (!entries.length) return {};
  if (new Set(entries.map(([, value]) => value)).size !== 1) return { error: "Conflicting approved answer-bank entries match this question." };
  return { value: entries[0][1], source: entries[0][0] };
}
function directAnswer(profile: Profile, field: FormField): Answer {
  const value = own(profile.answers, field.key);
  if (value !== undefined && !isTemplateKey(field.key)) return { value, source: field.key };
  if (!normalize(field.label)) return {};
  return entriesAnswer(Object.entries(profile.answers).filter(([key]) => !isTemplateKey(key) && normalize(key) === normalize(field.label)));
}
function canonicalAnswer(profile: Profile, meaning: Question): Answer {
  return entriesAnswer(Object.entries(profile.answers).filter(([key]) => question(key)?.key === meaning.key));
}

function narrativeAnswer(profile: Profile, job: Job, meaning: Question): Answer {
  const source = narrativeTemplates.get(meaning.key);
  if (!source) return {};
  const template = own(profile.answers, source);
  if (template === undefined || !template.trim()) return {};
  if (controls.test(template)) return { error: `${source} contains unsupported control characters.` };
  const placeholders = [...template.matchAll(/\{([^{}]*)\}/g)].map((match) => match[1]);
  const unknown = [...new Set(placeholders.filter((name) => name !== "company" && name !== "role"))];
  if (unknown.length) return { error: `${source} has unsupported placeholders: ${unknown.map((name) => `{${name}}`).join(", ")}. Only {company} and {role} are supported.` };
  if (/[{}]/.test(template.replace(/\{[^{}]*\}/g, "")) || /\$\{/.test(template)) {
    return { error: `${source} has malformed placeholder syntax. Use only literal {company} and {role} placeholders.` };
  }
  const replacements: Record<string, string> = { company: job.company, role: job.title };
  for (const placeholder of new Set(placeholders)) {
    const value = replacements[placeholder];
    if (!value?.trim()) return { error: `${source} needs a nonempty job ${placeholder} for {${placeholder}}; no replacement was invented.` };
    if (value.length > 500 || controls.test(value) || /[\r\n{}<>]/.test(value) || instructionLike.test(value)) {
      return { error: `The job ${placeholder} contains unsupported metadata for {${placeholder}}; review it rather than inserting instructions into approved prose.` };
    }
  }
  // One literal replacement pass: metadata is data, never another template or executable text.
  return { source, value: template.replace(/\{(company|role)\}/g, (_match, name: string) => replacements[name]) };
}

function splitName(name: string): string[] {
  const parts = name.trim().split(/\s+/u);
  if (parts.length > 2 || parts.some((part) => !/^\p{L}[\p{L}\p{M}'’-]*$/u.test(part)
    || /^(?:mr|mrs|ms|miss|dr|prof|sir|jr|sr|ii|iii|iv)$/i.test(part))) return [];
  return parts;
}
const DIAL: Record<string, string> = { 1: "US", 7: "RU", 20: "EG", 27: "ZA", 30: "GR", 31: "NL", 32: "BE", 33: "FR", 34: "ES", 36: "HU", 39: "IT", 40: "RO", 41: "CH",
  43: "AT", 44: "GB", 45: "DK", 46: "SE", 47: "NO", 48: "PL", 49: "DE", 52: "MX", 54: "AR", 55: "BR", 56: "CL", 57: "CO", 60: "MY", 61: "AU", 62: "ID", 63: "PH", 64: "NZ",
  65: "SG", 66: "TH", 81: "JP", 82: "KR", 84: "VN", 86: "CN", 90: "TR", 91: "IN", 92: "PK", 94: "LK", 234: "NG", 254: "KE", 351: "PT", 353: "IE", 358: "FI", 420: "CZ",
  852: "HK", 880: "BD", 886: "TW", 966: "SA", 971: "AE", 972: "IL", 974: "QA", 977: "NP" };
/** "+91 98765 43210" → code +91 (India) and the national number. */
export function phoneParts(phone: string): { code: string; country?: string; national: string } | undefined {
  const compact = phone.replace(/[^\d+]/g, "");
  if (!/^\+\d{6,15}$/.test(compact)) return undefined;
  const digits = compact.slice(1);
  for (const length of [3, 2, 1]) {
    const iso = DIAL[digits.slice(0, length)];
    if (iso) return { code: `+${digits.slice(0, length)}`, ...(iso !== "US" ? { country: regionNames.of(iso) } : {}), national: digits.slice(length) };
  }
  return undefined;
}
/** City, state and country of residence from your saved location ("Bengaluru, Karnataka" is in India) or an unambiguous phone code. */
function residence(profile: Profile): { city?: string; state?: string; country?: string } {
  const parts = profile.location.split(/[,|]/).map(part => part.trim()).filter(Boolean);
  let name: string | undefined;
  const last = parts.at(-1);
  if (last && country(last)) { name = regionNames.of(country(last)!); parts.pop(); }
  if (!name) { const inferred = inferCountries(profile.location); if (inferred.length === 1) name = inferred[0]; }
  if (!name) name = phoneParts(profile.phone)?.country;
  return { ...(parts[0] && !/\bremote\b/i.test(parts[0]) ? { city: parts[0] } : {}), ...(parts.length >= 2 ? { state: parts[1] } : {}), ...(name ? { country: name } : {}) };
}
/** A company's name words without legal suffixes ("Cisco Systems, Inc." → cisco systems). */
const companyWords = (name: string) => normalize(name).replace(/[^a-z0-9]+/g, " ").split(" ").filter(word => word && !/^(?:inc|llc|ltd|limited|corp|corporation|co|plc|gmbh|pvt|private|the)$/.test(word));
/** Same company when one name is the other's leading words: "Cisco" / "Cisco Systems", never "Fictional Labs" / "Fictional Employer". */
function sameCompany(a: string, b: string): boolean {
  const left = companyWords(a), right = companyWords(b);
  const [short, long] = left.length <= right.length ? [left, right] : [right, left];
  return short.length > 0 && short.join(" ").length >= 3 && short.every((word, index) => long[index] === word);
}
/**
 * Values Chairman can state from what you already confirmed, used only when you have no saved answer for the key.
 * Each says what it came from, and your saved answer for the same key always wins.
 */
function derivedAnswer(profile: Profile, job: Job, key: string): Answer {
  const home = residence(profile);
  if (key === "city" && home.city) return { value: home.city, derived: "your saved location" };
  if (key === "state_province" && home.state) return { value: home.state, derived: "your saved location" };
  if (key === "country" && home.country) return { value: home.country, derived: "your saved location and phone number" };
  const phone = phoneParts(profile.phone);
  if (key === "phone_country_code" && phone) return { value: phone.code, derived: "your phone number" };
  if (key === "phone_device_type" && phone) return { value: "Mobile", derived: "your phone number" };
  if (key === "previously_employed_here") {
    const history = profile.facts.filter(fact => fact.confirmed && fact.category === "experience" && fact.employer?.trim());
    if (!history.length || companyWords(job.company).join(" ").length < 3) return {};
    const worked = history.some(fact => sameCompany(fact.employer!, job.company));
    return { value: worked ? "Yes" : "No", derived: worked ? `your confirmed work history (a ${job.company} role)` : `your confirmed work history (no ${job.company} role)` };
  }
  if (key === "willing_to_relocate") {
    const place = [...new Set([...job.countries.map(value => country(value)), ...inferCountries(job.location).map(value => country(value))].filter(Boolean))];
    const homeCode = home.country ? country(home.country) : undefined;
    const targets = new Set((profile.preferences.countries ?? []).map(value => country(value)).filter(Boolean));
    if (place.length === 1 && homeCode && place[0] !== homeCode && (targets.has(place[0]) || profile.preferences.needsSponsorshipAbroad))
      return { value: "Yes", derived: `your preferences: you are applying to roles in ${regionNames.of(place[0]!)}` };
    return {};
  }
  if (key === "how_did_you_hear" && job.sourceId.startsWith("career-")) return { value: "Company careers website", derived: "where Chairman found this role (the company's careers site)" };
  return {};
}
function contactAnswer(profile: Profile, key: string, nationalPhone = false): Answer {
  if (key === "phone" && nationalPhone) { const parts = phoneParts(profile.phone); if (parts) return { value: parts.national, derived: "your phone number without its country code" }; }
  if (["name", "email", "phone", "location"].includes(key)) return { value: profile[key as "name" | "email" | "phone" | "location"] };
  if (key === "first_name" || key === "last_name") return { value: splitName(profile.name)[key === "first_name" ? 0 : 1] };
  if (key === "linkedin" || key === "github") {
    return entriesAnswer(Object.entries(profile.links).filter(([name]) => question(name)?.key === key));
  }
  return {};
}

// A closed ISO-3166 list avoids treating regions such as "EU" or "worldwide" as countries.
const isoCodes = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(" ");
const countryNames = new Map<string, string>();
const countryLabel = (text: string) => normalize(text).replace(/\./g, "").replace(/^the /, "");
const regionNames = new Intl.DisplayNames(["en"], { type: "region" });
for (const code of isoCodes) {
  countryNames.set(countryLabel(code), code);
  countryNames.set(countryLabel(regionNames.of(code)!), code);
}
for (const [name, code] of Object.entries({
  USA: "US", "United States of America": "US", UK: "GB", Britain: "GB", "Great Britain": "GB",
  "South Korea": "KR", "North Korea": "KP", "Czech Republic": "CZ", Turkey: "TR", Türkiye: "TR",
})) countryNames.set(countryLabel(name), code);
function country(text: string): string | undefined {
  return countryNames.get(countryLabel(text));
}

function workCountry(job: Job, specified?: string): { code?: string; error?: string } {
  const listing = [...new Set(job.countries.map(country))];
  if (specified && !/^(?:this country|the country of employment|the job location)$/i.test(specified)) {
    const code = country(specified);
    if (!code) return { error: `The work country "${specified}" is unknown or ambiguous; confirm a single country.` };
    if (listing.length && listing.every(Boolean) && !listing.includes(code)) {
      return { error: `The question's work country (${code}) contradicts the listing's countries (${job.countries.join(", ")}).` };
    }
    return { code };
  }
  if (listing.length === 1 && listing[0]) return { code: listing[0] };
  if (!listing.length && country(job.location)) return { code: country(job.location) };
  const inferred = listing.length ? [] : inferCountries(job.location).map(country);
  if (inferred.length === 1 && inferred[0]) return { code: inferred[0] };
  return { error: "Confirm a single work country for this authorization or sponsorship question; remote/worldwide is not a country." };
}

type Immigration = { kind: "authorization" | "sponsorship" | "unknown"; specified?: string };
function immigration(field: FormField): Immigration | undefined {
  // "Do you now, or will you in the future, require sponsorship…" reads the same without its commas.
  const label = normalize(field.label || field.key).replace(/\((?:e\.g\.?|for example|such as|i\.e\.?)[^)]*\)/g, " ").replace(/,/g, " ").replace(/\s+/g, " ").trim()
    .replace(/\bin the country (?:in which|where) (?:the|this) (?:job|role|position) (?:you(?:'re| are) applying (?:for|to) )?is (?:located|based)$/, "in this country")
    .replace(/\bin the (?:job|role|position)'?s? (?:country|location)$/, "in this country");
  let match = label.match(/^(?:are you|are you currently|are you legally|are you currently legally|are you legally currently) (?:authorized|authorised|eligible|legally authorized|legally authorised) to work(?: in (.+))?$/)
    ?? label.match(/^do you (?:have|currently have) (?:the (?:legal )?right|(?:legal )?authorization|(?:legal )?authorisation) to work(?: in (.+))?$/);
  if (match) return { kind: "authorization", specified: match[1] };
  if (["work authorization", "work authorisation", "authorized to work", "authorised to work"].includes(label)) return { kind: "authorization" };
  const asks = "(?:(?:do|will|would) you(?: now)?(?: or (?:will you |do you )?in the future)?|now or in the future will you)";
  match = label.match(new RegExp(`^${asks} (?:require|need) (?:visa |employment visa |work visa |employer |immigration )?sponsorship(?: (?:to work|for employment)(?: in (.+))?| in (.+))?$`))
    ?? label.match(new RegExp(`^${asks} (?:require|need) sponsorship for (?:employment )?visa status(?: in (.+?))?(?: now or in the future)?$`));
  if (match) return { kind: "sponsorship", specified: match[1] ?? match[2] };
  if (["visa sponsorship", "require sponsorship", "requires sponsorship", "need sponsorship", "needs sponsorship"].includes(label)) return { kind: "sponsorship" };
  if (/\b(?:visa|sponsor(?:ship)?|work (?:permit|authorization|authorisation)|(?:authorized|authorised|eligible|right) to work|immigration)\b/.test(`${label} ${normalize(field.key)}`)) return { kind: "unknown" };
  return undefined;
}

function booleanValue(value: string): boolean | undefined {
  const text = normalize(value);
  if (text === "yes" || text === "true") return true;
  if (text === "no" || text === "false") return false;
  return undefined;
}

function immigrationAnswer(profile: Profile, job: Job, field: FormField, kind: Immigration, approved: Answer, fuzzy = false): Answer {
  if (kind.kind === "unknown") return { error: "This visa or immigration question is not equivalent to confirmed work authorization or sponsorship; review it manually." };
  const context = workCountry(job, kind.specified);
  if (context.error) return { error: context.error };
  const code = context.code!;
  const authorized = profile.preferences.authorizedCountries?.map(country);
  if (!authorized || authorized.some((value) => !value)) return { error: "Confirm valid, explicit authorizedCountries in your profile preferences." };
  if (approved.error) return approved;
  let expected: boolean | undefined;
  if (kind.kind === "authorization") {
    expected = authorized.includes(code);
  } else {
    if (typeof profile.preferences.needsSponsorshipAbroad !== "boolean") return { error: "Confirm needsSponsorshipAbroad in your profile preferences." };
    const saved = canonicalAnswer(profile, { key: "country" });
    if (saved.error) return saved;
    const derivedHome = residence(profile).country;
    const home = saved.value ? country(saved.value) : derivedHome ? country(derivedHome) : undefined;
    const specific = own(profile.answers, `needs_sponsorship_${code}`);
    if (approved.value === undefined && specific !== undefined) approved = { value: specific, source: `needs_sponsorship_${code}` };
    // Authorization does not establish whether present or future sponsorship is needed, except in the country you live in and
    // are authorized to work in without holding a visa there (no saved visa_status).
    if (home && home !== code) expected = profile.preferences.needsSponsorshipAbroad;
    else if (home === code && authorized.includes(code) && !canonicalAnswer(profile, { key: "visa_status" }).value) expected = false;
    else if (!approved.value) return { error: `Supply an explicit country-specific sponsorship answer (needs_sponsorship_${code}); the abroad preference alone does not describe sponsorship in your home or unknown residence country.` };
  }
  if (approved.value !== undefined) {
    const resolved = choice(field, approved.value, fuzzy);
    const visible = resolved.value !== undefined ? own(field.optionLabels ?? {}, resolved.value) ?? resolved.value : approved.value;
    const explicit = booleanValue(visible) ?? (fuzzy ? leadingBoolean(visible) : undefined);
    if (explicit === undefined) return { error: "Supply an explicit, unambiguous Yes/No answer for this country-specific authorization or sponsorship question." };
    if (expected !== undefined && explicit !== expected) return { error: `The approved answer contradicts your confirmed ${kind.kind === "authorization" ? "authorizedCountries" : "needsSponsorshipAbroad"} preference for ${code}.` };
    return { value: explicit ? "Yes" : "No" };
  }
  return { value: expected ? "Yes" : "No" };
}

const legalOptInPolicy = "Legal consent, declarations, and signatures require your manual review.";

function fieldPolicy(field: FormField): string | undefined {
  const values = [field.key, field.label, ...field.options.map((value) => own(field.optionLabels ?? {}, value) ?? value)];
  const text = values.join("\n");
  if (controls.test(text) || /<\/?[a-z][^>]*>/i.test(text)) return "Unsupported control characters or markup in a form label.";
  if (hasNoAiRestriction(text) || /\bown (?:work|writing)\b/i.test(text)) return "Own-words or no-AI requirements require a manual application.";
  if (/\b(?:captcha|recaptcha|hcaptcha|verify (?:that )?you are human|i am not a robot)\b/i.test(normalize(text))) return "CAPTCHA or human verification requires your intervention.";
  if (instructionLike.test(text)) return "Instruction-like form content is unsupported; it cannot override your approved facts or safety policy.";
  if (/\b(?:consent|agree|agreement|attest|certify|declare|declaration|acknowledge|signature|under penalty|privacy|terms (?:of|and)|gdpr|ccpa|fcra|background check|i (?:confirm|understand|accept)|by (?:submitting|continuing|clicking)|opt in|subscribe|newsletter|marketing (?:emails?|communications?|updates)|(?:receive|send me|sign me up for) .{0,100}(?:updates|communications|news|offers|alerts)|keep me (?:informed|updated)|join .{0,40}talent (?:community|network)|contact me about (?:future|other) (?:roles|jobs|opportunities))\b/i.test(normalize(text))) return legalOptInPolicy;
  if (field.type.toLowerCase() === "password" || /\b(?:password|passcode|credentials?|login|api key|access token|secret key|one time (?:code|password)|verification code|security (?:answer|question)|social security|ssn|passport|national (?:id|identification))\b/i.test(normalize(text))) return "Credentials, identity documents, and verification secrets must be supplied manually.";
  if (/\b(?:assessment|coding (?:test|challenge|exercise)|take (?:a|the) test|solve (?:this|the)|aptitude test|personality test)\b/i.test(normalize(text))) return "Assessments and test responses require your manual work.";
  return undefined;
}

const sensitive = /\b(?:gender|sex|sexual|pronouns?|ethnic(?:ity)?|race|racial|disabilit\w*|veteran|religion|religious|marital|nationality|citizenship|date of birth|birth date|age)\b/i;

function leadingBoolean(text: string): boolean | undefined {
  const value = normalize(text);
  if (/^yes\b/.test(value)) return true;
  if (/^no\b/.test(value) && !/^no (?:preference|answer)\b/.test(value)) return false;
  return undefined;
}

function choice(field: FormField, answer: string, fuzzy = false, unit?: string): Answer {
  if (!field.options.length) {
    if (["select", "select-one", "radio", "combobox"].includes(field.type.toLowerCase())) return { error: "The form exposes no usable options; do not select a default." };
    return { value: answer };
  }
  const boolean = booleanValue(answer);
  const matches = field.options.filter((value) => {
    const visible = own(field.optionLabels ?? {}, value) ?? value;
    if (!value.trim() || /^(?:[-–—]+|please select(?: an? option)?|select(?: an? option)?|choose(?: an? option)?)$/i.test(visible.trim())) return false;
    if (boolean !== undefined) return booleanValue(visible) === boolean;
    return value === answer || normalize(visible) === normalize(answer);
  });
  if (!matches.length) {
    // Closed synonym groups ("I don't wish to answer" = "Decline to self-identify", "Male" = "Man") are exact meanings, not guesses.
    const synonym = synonymChoice(answer, field.options.map((value) => ({ value, label: own(field.optionLabels ?? {}, value) ?? value })));
    if (synonym) return { value: synonym.value };
  }
  if (!matches.length && fuzzy) {
    // Reviewed Chrome assistance only: strict, uniqueness-guarded tiers (ranges, "Yes, ..." phrasing, country names).
    const fuzzyMatch = matchChoice(answer, field.options.map((value) => ({ value, label: own(field.optionLabels ?? {}, value) ?? value })),
      unit === "years" || unit === "days" ? unit : undefined);
    if ("value" in fuzzyMatch) return { value: fuzzyMatch.value };
    if (fuzzyMatch.error === "ambiguous") return { error: "The approved answer matches multiple options; select an unambiguous option manually." };
  }
  if (matches.length !== 1) return { error: matches.length
    ? "The approved answer matches multiple options; select an unambiguous option manually."
    : "The approved answer does not match an available option or visible label; no default or substitute was chosen." };
  return { value: matches[0] };
}

function validateUnits(field: FormField, meaning: Question | undefined, answer: Answer): string | undefined {
  const text = normalize(field.label || field.key);
  const source = answer.source ? question(answer.source) : undefined;
  if (source?.unit === "years" && /\b(?:months?|weeks?|days?)\b/.test(text)) return "The approved answer is in years, but this question requests different experience units.";
  if (source?.unit === "days" && /\b(?:months?|weeks?|hours?)\b/.test(text)) return "The approved notice period is in days, but the question requests different units.";
  const durationUnits = (answer.value?.match(/\b(?:years?|months?|weeks?|days?|hours?)\b/gi) ?? []).map((unit) => `${unit.toLowerCase().replace(/s$/, "")}s`);
  const duration = meaning?.unit === "years" || meaning?.unit === "days" ? meaning.unit : undefined;
  if (duration && durationUnits.some((unit) => unit !== duration)) return "The approved answer contains duration units that contradict the requested experience or notice-period units.";
  if (/\b(?:salary|compensation|pay|ctc)\b/.test(text)) {
    if (currenciesIn(text).length > 1 || currenciesIn(answer.value ?? "").length > 1
      || periodsIn(text).length > 1 || periodsIn(answer.value ?? "").length > 1) {
      return "The salary question or approved answer contains conflicting currency or pay-period units.";
    }
    const fieldCurrency = currencyIn(text);
    const valueCurrency = currencyIn(answer.value ?? "");
    const suppliedCurrency = source?.currency ?? valueCurrency;
    if (fieldCurrency && suppliedCurrency && fieldCurrency !== suppliedCurrency) return "The approved salary currency contradicts the question; currency conversion is not allowed.";
    if (source?.currency && valueCurrency && source.currency !== valueCurrency) return "The salary answer contradicts its answer-bank currency key.";
    const hasAmount = /\d/.test(answer.value ?? "");
    if (hasAmount && !fieldCurrency && !valueCurrency) return "Specify the salary currency explicitly in this question's approved answer; no currency is inferred from the job or salary target.";
    const unit = periodIn(text);
    const suppliedUnit = source?.unit ?? periodIn(answer.value ?? "");
    if (unit && unit !== suppliedUnit && (hasAmount || suppliedUnit)) return "Supply an explicit salary answer in the requested annual, monthly, or hourly units; no pay-period conversion or assumption is allowed.";
    if (source?.unit && periodIn(answer.value ?? "") && source.unit !== periodIn(answer.value!)) return "The salary answer contradicts its answer-bank pay-period key.";
  }
  if (source && meaning && source.key !== meaning.key
    && !(source.currency && source.currency === meaning.currency && (!source.unit || source.unit === meaning.unit))) {
    return "The approved answer-bank key describes a different question or unit than this field's visible label.";
  }
  if (source && !meaning && field.label.trim()) {
    return "The approved answer-bank key is not equivalent to this field's visible question; approve the exact question instead.";
  }
  if ((meaning?.unit === "years" || meaning?.unit === "days" || meaning?.currency) && Number(answer.value) < 0) {
    return "The approved experience, notice period, or salary cannot be negative.";
  }
  return undefined;
}

/**
 * Deterministic single-page answers from a confirmed profile, never from resume prose or job instructions.
 * Exact field keys and normalized question text take precedence over closed, reviewed aliases.
 *
 * Optional bank keys: first_name, last_name, city, country (residence), postal_code,
 * notice_period_days, available_start_date (YYYY-MM-DD), total_years_experience,
 * years_<technology> (e.g. python, kubernetes, spark), expected_salary_<ISO currency>,
 * expected_salary_<ISO currency>_<annual|monthly|hourly>, willing_to_relocate,
 * travel_willingness, and needs_sponsorship_<ISO country> (explicit Yes/No).
 * Salary keys without a period never imply annual pay. Country-specific sponsorship
 * answers cannot contradict an applicable confirmed abroad preference.
 * Missing required answers also create a blocker. Resume uploads belong to the browser.
 * Optional legal/marketing opt-ins and file uploads stay untouched, even with a bank entry.
 * cover_letter_template and motivation_template contain user-authored prose for ordinary
 * cover-letter and why-this-role text fields respectively. Only {company} and {role}
 * are substituted, once, using job.company and job.title. Unknown or malformed placeholders
 * need review. Exact field/question answers and fixed cover_letter/motivation answers win.
 */
export interface ResolveOptions {
  /** Uniqueness-guarded fuzzy option matching. Used only where a human reviews the plan before any value is filled. */
  fuzzyOptions?: boolean;
  /** Also return where each answer came from (`plan.sources`). */
  provenance?: boolean;
  /** Fill voluntary self-identification (EEO) questions from your explicit saved answers. */
  disclosures?: boolean;
  /** Tick required acknowledgements (privacy notice, certifications, consents) in your name; decline required marketing opt-ins. */
  acknowledgements?: boolean;
}
/** The disclosure/acknowledgement choices you made in Profile, as resolver options. */
export function profileResolveOptions(profile: Profile): Pick<ResolveOptions, "disclosures" | "acknowledgements"> {
  return { disclosures: profile.preferences.fillVoluntaryDisclosures === true, acknowledgements: profile.preferences.acceptRequiredAcknowledgements === true };
}
export function resolveAnswers(profile: Profile, job: Job, snapshot: FormSnapshot, options: ResolveOptions = {}): AnswerPlan {
  const plan: AnswerPlan = { answers: {}, missing: [], blockers: [] };
  const sources: Record<string, string> = {};
  const fuzzy = options.fuzzyOptions === true;
  const answers = new Map<string, string>();
  const block = (reason: string) => { if (!plan.blockers.includes(reason)) plan.blockers.push(reason); };
  if (snapshot.hasCaptcha) block("CAPTCHA requires your intervention.");
  // With "Accept required acknowledgements" on, each consent field is answered (or reported missing) on its own below.
  if (snapshot.hasLegal && !options.acknowledgements) block("The form contains legal consent or declarations requiring manual review.");
  for (const reason of snapshot.unsupported) block(`Unsupported form requirement: ${reason}`);
  const noAi = job.aiPolicy === "prohibited" || hasNoAiRestriction(`${job.title}\n${job.description}`);
  if (noAi) block("This job requires human-authored / no-AI material; apply manually.");
  if (!profile.confirmed) {
    block("Confirm your profile and answer bank before resolving application answers.");
    return plan;
  }
  const counts = new Map<string, number>();
  for (const field of snapshot.fields) counts.set(field.key, (counts.get(field.key) ?? 0) + 1);
  // A form that asks for the country code separately wants the phone number without it.
  const nationalPhone = snapshot.fields.some(field => meaningOf(field.label || field.key, job.company)?.key === "phone_country_code");
  const missing = (field: FormField, reason: string) => {
    const message = `${field.label || field.key} [${field.key}]: ${reason}`;
    if (field.required && !plan.missing.includes(message)) plan.missing.push(message);
  };
  for (const field of snapshot.fields) {
    if (!field.key.trim() || ["__proto__", "prototype", "constructor"].includes(field.key) || counts.get(field.key)! > 1) {
      block(`The form has an unsafe or duplicate field key: ${field.key || "(empty)"}.`);
      continue;
    }
    const type = field.type.toLowerCase();
    if (type === "file" && !field.required) continue;
    const policy = fieldPolicy(field);
    // A saved factual question that merely uses legal words ("subject to a non-compete agreement?") is answered normally.
    const knownFactual = policy === legalOptInPolicy ? meaningOf(field.label || field.key, job.company) : undefined;
    if (policy && !knownFactual) {
      if (policy === legalOptInPolicy && options.acknowledgements && field.required) {
        if (marketingWording.test(normalize([field.label, ...field.options.map((value) => own(field.optionLabels ?? {}, value) ?? value)].join(" ")))) {
          const saved = canonicalAnswer(profile, { key: "marketing_opt_in" });
          const declined = saved.value !== undefined ? choice(field, saved.value, true) : choice(field, "No", true);
          if (declined.value !== undefined && field.type.toLowerCase() !== "checkbox") {
            answers.set(field.key, declined.value); sources[field.key] = saved.value !== undefined ? "answers:marketing_opt_in" : "marketing:declined"; continue;
          }
        } else {
          const accepted = acknowledgementAnswer(field);
          if (accepted !== undefined) { answers.set(field.key, accepted); sources[field.key] = "acknowledgement:auto"; continue; }
        }
      }
      if (policy === legalOptInPolicy && !field.required) continue;
      block(`${field.label || field.key} [${field.key}]: ${policy}`);
      missing(field, policy);
      continue;
    }
    if (type === "file") {
      if (!/\b(?:resume|cv|curriculum vitae)\b/i.test(`${field.label} ${field.key}`)) {
        const reason = "Provide this required non-resume file manually; the answer bank cannot upload files.";
        missing(field, reason);
        block(`${field.label || field.key}: ${reason}`);
      }
      continue;
    }
    if (type === "checkbox" && !field.required) continue;
    if (!["text", "textarea", "email", "tel", "url", "number", "date", "select", "select-one", "radio", "combobox", "autocomplete"].includes(type)) {
      block(`${field.label || field.key}: Unsupported input type "${field.type}"; handle it manually.`);
      continue;
    }
    let answer = directAnswer(profile, field);
    const work = immigration(field);
    const meaning = meaningOf(field.label || field.key, job.company);
    if (type === "autocomplete" && !["location", "work_location", "city", "country"].includes(meaning?.key ?? "")) {
      block(`${field.label || field.key}: Only a recognized location autocomplete can use a saved location value.`);
      continue;
    }
    if (work) {
      answer = immigrationAnswer(profile, job, field, work, answer, fuzzy);
    } else if (!answer.source && !answer.error && meaning && (EXPLICIT_ONLY.has(meaning.key)
      // Saved voluntary disclosures (eeo_*) match other wordings only when you chose to have them filled.
      ? !DISCLOSURE_KEYS.has(meaning.key) || options.disclosures === true : !sensitive.test(normalize(`${field.label} ${field.key}`)))) {
      answer = canonicalAnswer(profile, meaning);
      if (!answer.source && !answer.error && meaning.currency && meaning.unit) {
        answer = canonicalAnswer(profile, { key: `expected_salary_${meaning.currency}`, currency: meaning.currency });
      }
      if (!answer.source && !answer.error && !noAi && ["text", "textarea"].includes(type)) answer = narrativeAnswer(profile, job, meaning);
      if (!answer.source && !answer.error) answer = contactAnswer(profile, meaning.key, nationalPhone);
      if (answer.value === undefined && !answer.source && !answer.error) answer = derivedAnswer(profile, job, meaning.key);
    }
    if (answer.error) {
      block(`${field.label || field.key} [${field.key}]: ${answer.error}`);
      missing(field, answer.error);
      continue;
    }
    if (answer.value === undefined || !answer.value.trim()) {
      const template = meaning && narrativeTemplates.get(meaning.key);
      missing(field, `Add an explicit approved answer${meaning ? ` (${meaning.key})` : " for this exact question"}${template ? ` or a user-authored ${template}` : ""}; no value was inferred.`);
      continue;
    }
    const invalid = controls.test(answer.value) ? "The approved answer contains unsupported control characters." : validateUnits(field, meaning, answer);
    if (invalid) { block(`${field.label || field.key} [${field.key}]: ${invalid}`); missing(field, invalid); continue; }
    const selected = choice(field, answer.value, fuzzy, meaning?.unit);
    if (selected.error) { block(`${field.label || field.key} [${field.key}]: ${selected.error}`); missing(field, selected.error); continue; }
    let value = selected.value!;
    // Typed text: a notice period in days says so when the question does not name its unit ("30 days", not a bare "30").
    if (["text", "textarea"].includes(type) && meaning?.key === "notice_period_days" && /^\d+$/.test(value) && !/\bdays?\b/.test(normalize(field.label || field.key)))
      value = `${value} day${value === "1" ? "" : "s"}`;
    if (type === "number" && !/^-?(?:\d+(?:\.\d+)?|\.\d+)$/.test(value)) {
      missing(field, "Supply an explicit numeric answer in this question's units.");
      block(`${field.label || field.key}: The approved value is not a plain number; no units or text were discarded.`);
      continue;
    }
    if (type === "date" && (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString().slice(0, 10) !== value)) {
      missing(field, "Supply a valid date in YYYY-MM-DD format.");
      block(`${field.label || field.key}: The approved date is invalid or ambiguous.`);
      continue;
    }
    answers.set(field.key, value);
    sources[field.key] = answer.source ? `answers:${answer.source}` : work ? "profile:preferences" : answer.derived ? `derived:${answer.derived}` : `profile:${meaning?.key ?? "profile"}`;
  }
  if (plan.missing.length) block("Required questions need explicit approved answers before submission.");
  plan.answers = Object.fromEntries(answers);
  if (options.provenance) plan.sources = sources;
  return plan;
}
