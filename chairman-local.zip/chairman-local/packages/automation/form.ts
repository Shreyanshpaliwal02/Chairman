import { createHash } from "node:crypto";
import type { Locator, Page } from "playwright";
import type { KnownAutomationProvider as AutomationProvider, FormField, FormSnapshot } from "../domain/types.js";
import { PROVIDER_DOM } from "./providers.js";

export interface FieldBinding {
  field: FormField;
  selector: string;
  kind: "input" | "select" | "radio" | "file" | "combobox" | "autocomplete" | "yesno" | "checkbox";
  accept: string;
  optionMode?: "value" | "label";
  selectedLocation?: string;
}
export interface FormStructure {
  snapshot: FormSnapshot;
  bindings: FieldBinding[];
  root: Locator;
  destination: string;
}

export function fingerprint(snapshot: Omit<FormSnapshot, "fingerprint">): string {
  return createHash("sha256").update(JSON.stringify({
    url: snapshot.url,
    fields: snapshot.fields.map(f => ({
      key: f.key, label: f.label, type: f.type, required: f.required, options: f.options,
      ...(f.optionLabels ? { optionLabels: f.optionLabels } : {}),
      ...(f.accept ? { accept: f.accept } : {}),
    })),
    hasCaptcha: snapshot.hasCaptcha, hasLegal: snapshot.hasLegal, unsupported: snapshot.unsupported,
  })).digest("hex");
}

/**
 * CAPTCHA state: an open challenge (image grid, "verify you are human"), a widget you solve before Submit, and whether
 * a widget's response token is present. Chairman never solves or bypasses a CAPTCHA; it only notices that you did.
 */
export async function captchaStatus(page: Page): Promise<{ active: boolean; widget: boolean; solved: boolean }> {
  return page.evaluate(() => {
    const visible = (e: Element) => {
      const r = e.getBoundingClientRect();
      return r.width > 2 && r.height > 2 && getComputedStyle(e).visibility !== "hidden" && !e.closest('[hidden],[aria-hidden="true"]');
    };
    const tokens = [...document.querySelectorAll<HTMLTextAreaElement | HTMLInputElement>('[name^="g-recaptcha-response"],[name="h-captcha-response"],[name="cf-turnstile-response"],[data-captcha-token]')];
    const solved = tokens.some(token => (token.value || token.getAttribute("data-captcha-token") || "").trim().length >= 20);
    const challenge = [...document.querySelectorAll('iframe[src*="/bframe"], iframe[src*="hcaptcha"][src*="frame=challenge"], [data-captcha-challenge="open"]')]
      .some(e => visible(e) && !e.closest(".grecaptcha-badge"));
    // A passive invisible-reCAPTCHA badge is not a challenge.
    const widget = [...document.querySelectorAll('.g-recaptcha:not([data-size="invisible"]), .h-captcha:not([data-size="invisible"]), .cf-turnstile, iframe[src*="recaptcha/api2/anchor"], iframe[src*="recaptcha/enterprise/anchor"], iframe[src*="hcaptcha"]:not([src*="frame=challenge"]), iframe[src*="challenges.cloudflare.com"], [data-captcha-challenge]:not([data-captcha-challenge="open"])')]
      .some(e => visible(e) && !e.closest(".grecaptcha-badge"));
    const text = [...document.querySelectorAll('[role="alert"], .error, .error-message, .application--error, h1, h2')]
      .some(e => visible(e) && /(?:captcha|verify (?:that )?you(?:'re| are) (?:a )?human|security verification|verification (?:failed|required)|complete the security check)/i.test(e.textContent ?? ""));
    return { active: challenge || text && !solved, widget, solved };
  });
}
/** True while a challenge is open or a visible widget is still unsolved. */
export async function activeCaptcha(page: Page): Promise<boolean> {
  const state = await captchaStatus(page);
  return state.active || state.widget && !state.solved;
}

export async function pageState(page: Page): Promise<"auth_required" | "job_closed" | undefined> {
  return page.evaluate(() => {
    const visible = (e: Element) => !!e.getClientRects().length && getComputedStyle(e).visibility !== "hidden" && !e.closest('[hidden],[aria-hidden="true"]');
    if ([...document.querySelectorAll('input[type="password"], form[action*="sign_in"], form[action*="login"]')].some(visible)) return "auth_required";
    const text = [...document.querySelectorAll('h1,h2,[role="alert"],.job-closed,.ashby-job-posting-not-found')].filter(visible).map(e => e.textContent).join(" ");
    if (/job (?:is |has been )?(?:closed|expired|no longer available)|no longer accepting applications|job (?:not found|does not exist)|position has been filled/i.test(text)) return "job_closed";
    if (/(?:sign in|log in|create an account) (?:is required|to (?:continue|apply))|authentication required/i.test(text)) return "auth_required";
    return undefined;
  });
}

export async function readForm(page: Page, provider: AutomationProvider, url: string): Promise<FormStructure | undefined> {
  const spec = PROVIDER_DOM[provider];
  const roots = page.locator(spec.root).filter({ visible: true });
  if (await roots.count() !== 1) return undefined;
  const root = roots.first();
  const result = await root.evaluate((container, { provider, fieldSelector }) => {
    const locationSelector = '.ashby-application-form-field-entry[data-field-path="_systemfield_location"] input.ashby-application-form-input-autocomplete[role="combobox"][aria-autocomplete="list"][aria-haspopup="listbox"]';
    const locationOpen = provider === "ashby" && !!container.querySelector(`${locationSelector}[aria-expanded="true"]`);
    const visible = (e: Element) => {
      const r = e.getBoundingClientRect(), style = getComputedStyle(e);
      if (e.closest("[hidden]")) return false;
      for (let node: Element | null = e; node; node = node.parentElement) {
        if (node.getAttribute("aria-hidden") === "true" && !(locationOpen && node.getAttribute("data-aria-hidden") === "true")) return false;
      }
      return r.width > 1 && r.height > 1 && style.visibility !== "hidden" && style.display !== "none" && style.opacity !== "0" &&
        !e.closest("[hidden]");
    };
    const clean = (s: string | null | undefined) => (s ?? "").replace(/\s+/g, " ").trim();
    const escape = (s: string) => CSS.escape(s);
    const wrapper = (e: Element) => e.closest(fieldSelector) ?? e.parentElement!;
    const title = (e: Element) => {
      const w = wrapper(e);
      const own = e as HTMLInputElement;
      const label = w.querySelector(".ashby-application-form-question-title, .file-upload__label, .upload-label, legend, .field-label");
      return clean(label?.textContent || own.labels?.[0]?.textContent || e.getAttribute("aria-label") ||
        (e.getAttribute("aria-labelledby") ?? "").split(" ").map(id => document.getElementById(id)?.textContent).join(" ") ||
        w.querySelector("label")?.textContent).replace(/\s*\*$/, "");
    };
    const required = (e: Element) => e.hasAttribute("required") || e.getAttribute("aria-required") === "true" ||
      !!wrapper(e).querySelector('[class*="_required_"], .required, .asterisk') ||
      /\*\s*$/.test(clean(wrapper(e).querySelector("label,legend,.file-upload__label")?.textContent));
    const bindings: FieldBinding[] = [];
    const unsupported: string[] = [];
    const seen = new Set<string>();
    const radios = new Set<string>();
    const optionalOptIns: string[] = [];
    const controls = [...container.querySelectorAll("input,textarea,select,[role=combobox],.ashby-application-form-input-yesno")];
    for (const e of controls) {
      const input = e as HTMLInputElement;
      const kind = e.matches(".ashby-application-form-input-yesno") ? "yesno" :
        provider === "ashby" && e.matches(locationSelector) ? "autocomplete" :
        e.getAttribute("role") === "combobox" ? "combobox" :
        e.tagName === "SELECT" ? "select" : input.type === "radio" ? "radio" : input.type === "file" ? "file" :
        input.type === "checkbox" ? "checkbox" : "input";
      if (e.closest(".ashby-application-form-autofill-uploader") ||
        (kind !== "yesno" && e.closest(".ashby-application-form-input-yesno")) ||
        input.type === "hidden" || ["button", "submit", "reset"].includes(input.type) ||
        (kind !== "file" && !visible(e)) || (kind === "file" && !visible(wrapper(e)))) continue;
      if (input.disabled) {
        if (required(e)) unsupported.push("Disabled required field");
        continue;
      }
      if (kind === "radio" && radios.has(input.name)) continue;
      const label = kind === "radio" ?
        clean(e.closest('fieldset,[role="radiogroup"],.ashby-application-form-field-entry,.field-wrapper')?.querySelector("legend,.ashby-application-form-question-title,.field-label")?.textContent) :
        title(e);
      const key = kind === "yesno" ? e.querySelector("input")?.getAttribute("name") :
        kind === "radio" ? input.name : e.id || e.getAttribute("name") || wrapper(e).getAttribute("data-field-path");
      if (!key || !label || seen.has(key)) { unsupported.push("Unlabelled or ambiguous application control"); continue; }
      seen.add(key);
      let selector = e.id ? `#${escape(e.id)}` :
        e.getAttribute("name") ? `[name="${escape(e.getAttribute("name")!)}"]` :
        `[data-field-path="${escape(key)}"] ${kind === "combobox" || kind === "autocomplete" ? '[role="combobox"]' : ".ashby-application-form-input-yesno"}`;
      if (kind === "autocomplete") selector = locationSelector;
      if (kind === "yesno") selector = `.ashby-application-form-input-yesno:has(input[name="${escape(key)}"])`;
      const options: string[] = [];
      const optionLabels: Record<string, string> = {};
      if (kind === "select") {
        if ((e as HTMLSelectElement).multiple) unsupported.push("Multiple-select question requires manual handling");
        for (const o of [...(e as HTMLSelectElement).options].filter(o => !o.disabled && o.value !== "")) {
          options.push(o.value); optionLabels[o.value] = clean(o.textContent);
        }
      } else if (kind === "radio") {
        radios.add(input.name);
        selector = `input[type="radio"][name="${escape(input.name)}"]`;
        for (const o of [...container.querySelectorAll<HTMLInputElement>(selector)].filter(visible)) {
          options.push(o.value); optionLabels[o.value] = clean(o.labels?.[0]?.textContent);
        }
      } else if (kind === "yesno") {
        for (const o of e.querySelectorAll("button[data-option]")) {
          options.push(o.getAttribute("data-option")!); optionLabels[o.getAttribute("data-option")!] = clean(o.textContent);
        }
      }
      if (kind === "input" && !["text", "email", "tel", "url", "number", "date", "search", "textarea"].includes(e.tagName === "TEXTAREA" ? "textarea" : input.type)) {
        unsupported.push(`${input.type || "Custom"} question requires manual handling`);
      }
      if (kind === "checkbox") {
        const optIn = !required(e) && /\b(?:marketing|newsletter|updates|communications|contact|consent|agree|privacy|terms|opt[- ]?in|subscribe)\b/i.test(label) &&
          !/\b(?:own words|own work|AI policy|no[- ]AI|attest|certify|certification|assessment|without.{0,20}(?:AI|artificial intelligence))\b/i.test(clean(wrapper(e).textContent));
        if (optIn) optionalOptIns.push(selector);
        else unsupported.push("Checkbox question requires manual handling");
      }
      const type = kind === "input" ? (e.tagName === "TEXTAREA" ? "textarea" : input.type) : kind === "yesno" ? "radio" : kind;
      const field: FormField = { key, label, type, required: required(e), options };
      if (options.length) field.optionLabels = optionLabels;
      if (kind === "file" && e.hasAttribute("accept")) field.accept = input.accept.split(",").map(s => s.trim().toLowerCase()).filter(Boolean);
      bindings.push({ field, selector, kind, accept: kind === "file" ? input.accept : "" });
    }
    const clone = container.cloneNode(true) as HTMLElement;
    for (const selector of optionalOptIns) {
      const checkbox = clone.querySelector<HTMLInputElement>(selector);
      if (!checkbox) continue;
      const group = checkbox.closest(fieldSelector);
      if (group && group.querySelectorAll("input,textarea,select,[role=combobox]").length === 1) group.remove();
      else {
        if (checkbox.id) clone.querySelectorAll(`label[for="${escape(checkbox.id)}"]`).forEach(label => label.remove());
        checkbox.closest("label")?.remove();
      }
    }
    // Exclude existing answers, token/honeypot nodes, and passive privacy-link copy.
    clone.querySelectorAll("input,textarea,select,script,style,.grecaptcha-badge,a").forEach(e => e.remove());
    if (provider === "ashby") clone.querySelectorAll('[role="listbox"]:has(.ashby-application-form-input-autocomplete-popup-result)').forEach(e => e.remove());
    const legalText = clean(clone.textContent);
    const hasLegal = /(?:\b(?:I|you|applicants?|candidates?)\s+(?:hereby\s+)?(?:agree|consent|certify|attest|acknowledge)|\b(?:consent|attestation|certification|arbitration)\b|\b(?:accept|agree to|acknowledge).{0,30}(?:terms|policy|conditions|agreement)\b|\bby (?:submitting|applying|clicking)\b|\b(?:own words|own work|without (?:the use of )?(?:AI|artificial intelligence)|no[- ]AI|AI policy|AI.{0,35}(?:prohibited|not permitted|not allowed))\b|\b(?:complete|take|coding|skills|technical)\s+(?:an?\s+)?(?:assessment|test|challenge)\b)/i.test(legalText);
    const action = container instanceof HTMLFormElement ? container.getAttribute("action") : null;
    const submitters = [...container.querySelectorAll<HTMLButtonElement>('button,input[type="submit"]')].filter(e => visible(e) && /^(?:submit application|submit your application|submit|apply now)$/i.test(clean(e.textContent || e.getAttribute("value"))));
    if (submitters.length !== 1) unsupported.push("Missing or ambiguous final application submit control");
    if (container.querySelector('[contenteditable="true"],canvas,[role="slider"]')) unsupported.push("Rich editor or assessment requires manual handling");
    if (bindings.some(b => b.field.options.length !== new Set(b.field.options).size)) unsupported.push("Ambiguous option values");
    return { bindings, unsupported, hasLegal, action, submitAction: submitters[0]?.getAttribute("formaction"), submitTarget: submitters[0]?.getAttribute("formtarget") ?? container.getAttribute("target") };
  }, { provider, fieldSelector: spec.field });
  if (result.submitTarget && result.submitTarget !== "_self") result.unsupported.push("External form target");
  const destination = new URL(result.submitAction ?? result.action ?? page.url(), page.url()).href;
  const snapshot: FormSnapshot = {
    url, fields: result.bindings.map(b => b.field), fingerprint: "", hasCaptcha: await activeCaptcha(page),
    hasLegal: result.hasLegal, unsupported: result.unsupported,
  };
  return { root, bindings: result.bindings, destination, snapshot };
}

/** Open menus without typing, selecting, or reading an existing answer. */
export async function collectComboboxOptions(structure: FormStructure, page: Page, provider: AutomationProvider): Promise<void> {
  for (const binding of structure.bindings.filter(b => b.kind === "combobox")) {
    const control = structure.root.locator(binding.selector);
    await control.click({ timeout: 2500 });
    const listId = await control.getAttribute("aria-controls") ?? await control.getAttribute("aria-owns");
    const list = listId ? page.locator(`[id=${JSON.stringify(listId)}]`) : page.locator('[role="listbox"]:visible');
    const options = await list.locator('[role="option"]').evaluateAll(nodes => nodes.map(e => ({
      value: e.getAttribute("data-value") ?? e.getAttribute("value"),
      label: (e.textContent ?? "").replace(/\s+/g, " ").trim(),
      disabled: e.getAttribute("aria-disabled") === "true",
      greenhouseOption: e.matches(".select__option[id^='react-select-']"),
    })));
    await control.press("Escape");
    // React Select exposes choices as ARIA option names, not native select values.
    // Only the observed Greenhouse widget can use unique, fully rendered names.
    const labelMode = provider === "greenhouse" && await control.evaluate(e => e.matches("input.select__input")) &&
      options.length > 0 && options.every(o => o.value === null && o.greenhouseOption && o.label);
    const choices = options.filter(o => !o.disabled).map(o => ({ value: labelMode ? o.label : o.value, label: o.label }));
    if (!choices.length || choices.some(o => o.value === null) || new Set(choices.map(o => o.value)).size !== choices.length) {
      structure.snapshot.unsupported.push("Autocomplete has no reliable public option values; manual selection required");
      continue;
    }
    binding.optionMode = labelMode ? "label" : "value";
    binding.field.options = choices.map(o => o.value!);
    binding.field.optionLabels = Object.fromEntries(choices.map(o => [o.value!, o.label]));
  }
}

export async function validationError(page: Page): Promise<boolean> {
  return page.locator('[role="alert"]:visible, .field-error:visible, .input__error:visible, .error-message:visible, .ashby-application-form-error:visible, [aria-invalid="true"]:visible')
    .evaluateAll(nodes => nodes.some(e => e.getAttribute("aria-invalid") === "true" || !!e.textContent?.trim()));
}

export async function receiptVisible(page: Page, provider: AutomationProvider): Promise<boolean> {
  const spec = PROVIDER_DOM[provider];
  return page.locator(spec.receipt).evaluateAll((nodes, description) => nodes.some(e =>
    !e.closest(description) && !!e.getClientRects().length && getComputedStyle(e).visibility !== "hidden" &&
    !e.closest('[hidden],[aria-hidden="true"]') &&
    /(?:application (?:has been |was )?(?:received|submitted)|thank you for (?:applying|(?:submitting )?your application)|thanks for applying|(?:successfully )?(?:submitted|received) your application)/i.test(e.textContent ?? "")
  ), spec.description);
}
