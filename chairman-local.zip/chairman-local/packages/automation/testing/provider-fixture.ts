/** Synthetic test markup only. No requests occur until a test serves this HTML. */
export type ProviderFixtureMode = "normal" | "legal" | "ownwords" | "captcha" | "passive" | "auth" | "closed" | "unknown-widget" | "conditional" |
  "upload-reject" | "filelist-only" | "changed-action" | "navigate-away" | "post-timeout" | "preexisting-success" |
  "validation" | "rate-limit" | "after-captcha" | "after-auth" | "opaque-combo" | "native-navigation" | "no-receipt" | "redirect" |
  "post-redirect" | "fake-receipt" | "upload-autofill" | "upload-conditional" | "mime-reject" |
  "required-document" | "checked-opt-in" | "optional-ownwords" | "accept-change" | "preflight-throttle" |
  "location-exact" | "location-ambiguous" | "location-mismatch" | "location-field-change" | "location-stop" | "location-unselected" | "location-opaque" |
  "integration";

export function providerFixtureHtml(provider: "ashby" | "greenhouse", mode: ProviderFixtureMode, action: string): string {
  if (mode === "auth") return '<h1>Sign in to apply</h1><input type="password">';
  if (mode === "closed") return '<h1>This job is no longer accepting applications</h1>';
  const root = provider === "ashby" ? 'div id="form"' : `form id="application-form" action="${action}" method="post"`;
  const end = provider === "ashby" ? "div" : "form";
  const wrapper = provider === "ashby" ? "ashby-application-form-field-entry" : "field-wrapper";
  const upload = provider === "ashby" ? "ashby-application-form-input-file" : "file-upload";
  const receipt = provider === "ashby" ? "_successConfirmation_fixture_77" : "confirmation";
  const row = (label: string, id: string, html: string) => `<div class="${wrapper}"><label for="${id}">${label}</label>${html}</div>`;
  const combo = row("Country*", "country", provider === "greenhouse" ?
    `<div class="select__control"><span class="select__single-value"></span><input id="country" class="select__input" role="combobox" aria-controls="countries" aria-expanded="false" aria-required="true" autocomplete="off"></div><div id="countries" role="listbox" hidden><div role="option" class="select__option" id="react-select-country-option-0">India</div><div role="option" class="select__option" id="react-select-country-option-1">Canada</div></div>` :
    `<input id="country" role="combobox" aria-controls="countries" aria-expanded="false" aria-required="true" autocomplete="off"><div id="countries" role="listbox" hidden><div role="option" ${mode === "opaque-combo" ? "" : 'data-value="IN"'}>India</div><div role="option" ${mode === "opaque-combo" ? "" : 'data-value="CA"'}>Canada</div></div>`);
  return `<!doctype html><html><head><meta charset="utf-8"><style>body {font-family:sans-serif} label {display:block} input,textarea,select {margin:8px} .visually-hidden {position:absolute;width:1px;height:1px;clip:rect(0,0,0,0)} [hidden]{display:none!important}</style></head><body>
    <section class="${provider === "ashby" ? "ashby-job-posting-description" : "job__description"}"><h1>Synthetic test job</h1>Successful applicants join our success team. <div class="${receipt}">Thank you for applying</div></section>
    ${mode === "preexisting-success" ? `<div class="${receipt}">Application submitted</div>` : ""}
    <${root}><div class="${provider === "ashby" ? "ashby-application-form-container" : "application--questions"}">
    ${row("First Name*", "first_name", '<input id="first_name" required>')}
    ${row("Email*", "email", '<input id="email" type="email" required>')}
    ${row("Notes", "notes", '<textarea id="notes"></textarea>')}
    ${row("Work authorization*", "work", `<select id="work" required><option value="">Choose</option><option value="authorized">${mode === "integration" ? "Yes" : "Eligible to work"}</option><option value="sponsorship">${mode === "integration" ? "No" : "Needs sponsorship"}</option></select>`)}
    <fieldset class="${wrapper}"><legend>Schedule</legend><label for="remote">Remote</label><input id="remote" name="schedule" type="radio" value="r"><label for="office">Office</label><input id="office" name="schedule" type="radio" value="o"></fieldset>
    ${combo}
    ${mode.startsWith("location-") ? `<div class="ashby-application-form-field-entry" data-field-path="${mode === "location-opaque" ? "custom_location" : "_systemfield_location"}"><label class="ashby-application-form-question-title _required_fixture_91" for="_systemfield_location">Current location</label><div><input class="ashby-application-form-input-autocomplete" role="combobox" aria-autocomplete="list" aria-haspopup="listbox" aria-expanded="false"></div></div>` : ""}
    ${provider === "ashby" ? `<div class="${wrapper}" data-field-path="relocate"><label class="ashby-application-form-question-title">Relocate</label><div class="ashby-application-form-input-yesno"><button data-option="yes" aria-pressed="false">Yes</button><button data-option="no" aria-pressed="false">No</button><input type="checkbox" name="relocate" hidden></div></div>` : ""}
    ${row("Resume/CV*", "resume", `<div class="${upload}"><div class="upload-label">Resume/CV<span class="required">*</span></div><input id="resume" type="file" accept="${mode === "mime-reject" ? ".txt" : ".pdf,.docx"}" class="visually-hidden"><label for="resume">Attach</label><span id="uploaded"></span><button id="remove" type="button" hidden>Remove file</button></div>`)}
    ${row(`Cover letter${mode === "required-document" ? "*" : ""}`, "cover_letter", `<input id="cover_letter" type="file" accept=" .PDF, application/PDF, .docx " class="visually-hidden" ${mode === "required-document" ? "required" : ""}>`)}
    ${row("Optional portfolio", "portfolio", '<input id="portfolio" type="file" class="visually-hidden">')}
    ${row("I consent to receive marketing updates under the privacy policy (optional)", "marketing", `<input id="marketing" type="checkbox" ${mode === "checked-opt-in" ? "checked" : ""}>`)}
    <input type="hidden" name="csrf" value="synthetic-internal-token"><input name="honeypot" required style="display:none">
    <div hidden>${row("Invisible required question", "invisible", '<input id="invisible" required>')}</div>
    ${mode === "unknown-widget" ? row("Signature*", "signature", '<input id="signature" type="color" required>') : ""}
    ${mode === "legal" ? row("I agree to the terms", "legal", '<input id="legal" type="checkbox" required>') : ""}
    ${mode === "ownwords" ? '<p>Please write in your own words without the use of AI.</p>' : ""}
    ${mode === "optional-ownwords" ? row("I certify this application is in my own words", "ownwords", '<input id="ownwords" type="checkbox">') : ""}
    ${mode === "captcha" ? '<div data-captcha-challenge>Verify you are human</div>' : ""}
    ${mode === "passive" ? '<div class="grecaptcha-badge">This site is protected by reCAPTCHA. <a href="https://example.test/privacy">Privacy policy</a></div>' : ""}
    <a href="https://example.test/privacy">Privacy Policy</a>
    <button type="submit">Submit application</button></div></${end}>
    <div id="location-results" role="listbox" hidden></div>
    <script>
    const form=document.getElementById('${provider === "ashby" ? "form" : "application-form"}');
    const mode=${JSON.stringify(mode)};
    const country=document.getElementById('country'), countries=document.getElementById('countries');
    country.onclick=()=>{countries.hidden=false;country.setAttribute('aria-expanded','true')};
    country.onkeydown=e=>{if(e.key==='Escape'){countries.hidden=true;country.setAttribute('aria-expanded','false')}};
    countries.onclick=e=>{if(e.target.getAttribute('role')==='option'){const selected=document.querySelector('.select__single-value');if(selected){selected.textContent=e.target.textContent;country.value=''}else country.value=e.target.textContent;countries.hidden=true;country.setAttribute('aria-expanded','false')}};
    const locationInput=form.querySelector('input.ashby-application-form-input-autocomplete');
    const locationResults=document.getElementById('location-results');
    if(locationInput) {
      locationInput.oninput=async()=>{
        locationInput.setAttribute('aria-expanded','true');locationInput.setAttribute('aria-controls','location-results');
        locationResults.hidden=false;locationResults.setAttribute('aria-busy','true');locationResults.replaceChildren();
        form.querySelectorAll('.ashby-application-form-field-entry,button[type=submit]').forEach(e=>{
          if(!e.contains(locationInput)){e.setAttribute('data-aria-hidden','true');e.setAttribute('aria-hidden','true')}
        });
        try {
          const suggestions=await fetch('/location-suggestions?text='+encodeURIComponent(locationInput.value)).then(r=>r.json());
          if(mode==='location-field-change') form.insertAdjacentHTML('beforeend',${JSON.stringify(row("New required location follow-up*", "location-extra", '<input id="location-extra" required>'))});
          for(const label of suggestions) {
            const option=document.createElement('div');option.className='ashby-application-form-input-autocomplete-popup-result';
            option.setAttribute('role','option');option.setAttribute('aria-selected',String(locationResults.children.length===0));
            option.textContent=label;locationResults.append(option);
          }
          locationResults.setAttribute('aria-busy','false');
        } catch {}
      };
      locationResults.onclick=e=>{
        const option=e.target.closest('[role=option]');
        if(!option||mode==='location-unselected')return;
        locationInput.value=option.textContent;locationInput.setAttribute('aria-expanded','false');locationInput.removeAttribute('aria-controls');
        locationResults.hidden=true;
        form.querySelectorAll('[data-aria-hidden=true]').forEach(e=>{e.removeAttribute('data-aria-hidden');e.removeAttribute('aria-hidden')});
        fetch('/location-selected?label='+encodeURIComponent(option.textContent)).catch(()=>{});
      };
    }
    document.querySelectorAll('[data-option]').forEach(b=>b.onclick=()=>{b.parentElement.querySelectorAll('[data-option]').forEach(o=>o.setAttribute('aria-pressed',String(o===b)))});
    const error=t=>{const p=document.createElement('div');p.setAttribute('role','alert');p.textContent=t;form.append(p)};
    document.getElementById('first_name').addEventListener('input',()=>{
      if(mode==='conditional'&&!document.getElementById('extra')) form.insertAdjacentHTML('beforeend',${JSON.stringify(row("New required question*", "extra", '<input id="extra" required>'))});
      if(mode==='changed-action') form.setAttribute('action','http://localhost:9/not-approved');
      if(mode==='accept-change') document.getElementById('resume').accept='.docx';
    });
    document.getElementById('resume').onchange=()=>{
      const f=document.getElementById('resume').files[0];
      if(mode==='upload-reject'){error('File type rejected');return}
      if(mode==='filelist-only')return;
      if(mode==='upload-autofill')document.getElementById('email').value='different@example.test';
      if(mode==='upload-conditional')form.insertAdjacentHTML('beforeend',${JSON.stringify(row("New document question*", "upload-extra", '<input id="upload-extra" required>'))});
      setTimeout(()=>{document.getElementById('uploaded').textContent=f.name;document.getElementById('remove').hidden=false},50);
    };
    const submit=async e=>{
      e.preventDefault();
      if(mode==='validation'){error('Please correct this answer');return}
      if(mode==='after-captcha'){error('CAPTCHA verification required');return}
      if(mode==='after-auth'){form.innerHTML='<h2>Sign in to continue</h2><input type="password">';return}
      if(mode==='fake-receipt'){form.parentNode.removeChild(form);document.body.insertAdjacentHTML('beforeend','<div class="${receipt}">Application received. Thank you for applying.</div>');return}
      const data={answers:{first_name:document.getElementById('first_name').value,email:document.getElementById('email').value,work:document.getElementById('work').value,country:document.querySelector('.select__single-value')?.textContent||country.value,schedule:document.querySelector('[name=schedule]:checked')?.value},resume:{name:document.getElementById('resume').files[0].name,type:document.getElementById('resume').files[0].type,bytes:${mode === "integration" ? "btoa(String.fromCharCode(...new Uint8Array(await document.getElementById('resume').files[0].arrayBuffer())))" : "await document.getElementById('resume').files[0].text()"}},internal:document.querySelector('[name=csrf]').value,honeypot:document.querySelector('[name=honeypot]').value,optionalFiles:[document.getElementById('cover_letter').files.length,document.getElementById('portfolio').files.length],marketing:document.getElementById('marketing').checked};
      if(locationInput)data.answers.location=locationInput.value;
      if(mode==='native-navigation'||mode==='post-redirect'){const f=document.createElement('form');f.method='post';f.action=location.pathname;document.body.append(f);f.submit();return}
      const response=await fetch(location.pathname,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(data)});
      if(!response.ok){error('Request rejected');return}
      if(mode==='navigate-away'){location.href='/different/jobs/999';return}
      if(mode==='no-receipt')return;
      form.parentNode.removeChild(form);
      const confirmation=document.createElement('div');confirmation.className='${receipt}';confirmation.textContent='Thank you for applying. Your application has been received.';document.body.append(confirmation);
    };
    form.querySelector('button[type=submit]').onclick=submit;
    </script></body></html>`;
}
