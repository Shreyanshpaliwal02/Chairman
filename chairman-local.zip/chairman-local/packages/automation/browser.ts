import { createHash } from "node:crypto";
import { readFile, mkdir, realpath } from "node:fs/promises";
import { basename, extname, resolve } from "node:path";
import { chromium, type BrowserContext, type Locator, type Page, type Request, type Response } from "playwright";
import type { ApplicationBrowserDriver, BrowserInspection, BrowserSubmission, BrowserSubmitInput } from "./contracts.js";
import type { KnownAutomationProvider as AutomationProvider, FormSnapshot, Job } from "../domain/types.js";
import { canonicalApplicationUrl, providerForUrl, sameApplication, testApplication, PROVIDER_DOM } from "./providers.js";
import { isNormalBrowserProfile } from "./profile-path.js";
import { getChromeLaunchOptions } from "../platform/browser.js";
import {
  activeCaptcha, collectComboboxOptions, fingerprint, pageState, readForm, receiptVisible, validationError,
  type FieldBinding, type FormStructure,
} from "./form.js";

export { canonicalApplicationUrl, providerForUrl, sameApplication, PROVIDERS } from "./providers.js";

type Options = { userDataDir: string; headless?: boolean; testOrigins?: string[] };
type Target = { url: string; provider: AutomationProvider };
const normalizeLocation = (value: string) => value.normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase();
class Halt extends Error {
  constructor(readonly status: BrowserSubmission["status"], message: string) { super(message); }
}

export class ApplicationBrowser implements ApplicationBrowserDriver {
  private context?: BrowserContext;
  private tab?: Page;
  private setupTab?: Page;
  private readonly manualTabs = new Set<Page>();
  private starting?: Promise<BrowserContext>;
  private busy = false;
  private stopped = false;
  private target?: Target;
  private navigationBlocked = false;
  private rateLimit?: number;
  private authorization?: () => Promise<boolean>;
  private clickStarted = false;
  private submissionResponse = false;
  private readonly submissionRequests = new Set<Request>();
  private readonly finished = new Set<string>();
  private readonly testOrigins: Set<string>;

  constructor(private readonly options: Options) {
    if (!options.userDataDir?.trim()) throw new Error("A dedicated browser profile directory is required");
    if (isNormalBrowserProfile(resolve(options.userDataDir))) {
      throw new Error("Use a dedicated automation profile, never your normal Chrome profile");
    }
    this.testOrigins = new Set((options.testOrigins ?? []).map(value => {
      const url = new URL(value);
      if (url.origin !== value || !["http:", "https:"].includes(url.protocol) ||
          !["127.0.0.1", "localhost", "[::1]"].includes(url.hostname)) throw new Error("Test origins must be explicit loopback origins");
      return url.origin;
    }));
  }

  isRunning(): boolean { return !!this.context && !this.stopped; }

  private identify(raw: string): Target {
    const test = testApplication(raw, this.testOrigins);
    if (test) return test;
    const provider = providerForUrl(raw);
    if (!provider) throw new Halt("unsupported", "Unsafe or unsupported application destination");
    return { provider, url: canonicalApplicationUrl(raw) };
  }

  private same(raw: string, target = this.target): boolean {
    try { return !!target && this.identify(raw).url === target.url; } catch { return false; }
  }

  private async launch(): Promise<BrowserContext> {
    if (this.context && !this.stopped) return this.context;
    if (this.starting) return this.starting;
    this.stopped = false;
    this.starting = (async () => {
      await mkdir(this.options.userDataDir, { recursive: true, mode: 0o700 });
      const profile = await realpath(this.options.userDataDir);
      if (isNormalBrowserProfile(profile)) throw new Error("Normal Chrome profiles are not allowed");
      const context = await chromium.launchPersistentContext(profile, {
        ...getChromeLaunchOptions(), headless: this.options.headless ?? false,
        acceptDownloads: false, serviceWorkers: "block", timeout: 30_000,
      });
      if (this.stopped) { await context.close(); throw new Halt("cancelled", "Browser was stopped"); }
      this.context = context;
      context.setDefaultTimeout(5000);
      context.setDefaultNavigationTimeout(20_000);
      // tsx/esbuild preserves local function names with this helper inside evaluate().
      // It changes no browser identity, navigator properties, or provider behavior.
      await context.addInitScript("globalThis.__name ??= (fn) => fn;");
      // Restored browser tabs never become automation targets.
      for (const page of context.pages()) await page.close();
      context.on("close", () => {
        if (this.context === context) { this.context = undefined; this.tab = undefined; this.setupTab = undefined; this.manualTabs.clear(); }
      });
      await context.route("**/*", async route => {
        try {
          const request = route.request();
          const page = request.frame().page();
          const opener = page === this.tab ? null : await page.opener();
          if (page !== this.tab && (page === this.setupTab || this.manualTabs.has(page) || (opener && this.manualTabs.has(opener)))) {
            this.manualTabs.add(page);
            // Native sign-in and its identity-provider redirects remain user-operated.
            if (request.isNavigationRequest() && request.frame() === page.mainFrame() && !this.manualNavigationAllowed(request.url())) await route.abort();
            else await route.continue();
            return;
          }
          if (page !== this.tab && page !== this.setupTab) { await route.abort(); return; }
          if (request.isNavigationRequest() && request.frame() === page.mainFrame()) {
            const allowed = (url: string) => page === this.tab ? this.same(url) : this.setupAllowed(url);
            if (!allowed(request.url())) {
              if (page === this.tab) this.navigationBlocked = true;
              await route.abort();
              return;
            }
            if (page === this.tab && request.method() !== "GET") {
              let authorized = false;
              try { authorized = !!this.authorization && await this.authorization(); } catch { /* Deny on failure. */ }
              if (!authorized) { await route.abort(); return; }
            }
            // continue() follows server redirects without rerouting each hop.
            // Inspect redirect headers before contacting an unrelated destination.
            const response = await route.fetch({ maxRedirects: 0, maxRetries: 0, timeout: 20_000 });
            const location = response.headers()["location"];
            if (response.status() >= 300 && response.status() < 400 && location && !allowed(new URL(location, request.url()).href)) {
              if (page === this.tab) this.navigationBlocked = true;
              await route.abort();
            } else {
              await route.fulfill({ response });
            }
            return;
          }
          if (page === this.tab && this.authorization &&
              (!["GET", "HEAD", "OPTIONS"].includes(request.method()) || ["xhr", "fetch"].includes(request.resourceType()))) {
            let allowed = false;
            try { allowed = !this.stopped && await this.authorization(); } catch { /* Authorization errors stop transmission. */ }
            if (!allowed) { await route.abort(); return; }
          }
          await route.continue();
        } catch {
          await route.abort().catch(() => undefined);
        }
      });
      return context;
    })();
    try { return await this.starting; } finally { this.starting = undefined; }
  }

  private async automationPage(): Promise<Page> {
    const context = await this.launch();
    if (!this.tab || this.tab.isClosed()) {
      this.tab = await context.newPage();
      this.tab.on("popup", popup => { void popup.close(); });
      this.tab.on("request", request => {
        if (this.clickStarted && request.method() === "POST" &&
            new URL(request.url()).origin === (this.target && new URL(this.target.url).origin)) this.submissionRequests.add(request);
      });
      this.tab.on("response", response => {
        if (this.clickStarted && this.isSubmissionResponse(response)) this.submissionResponse = true;
        if (response.status() !== 429) return;
        const url = new URL(response.url());
        const targetOrigin = this.target && new URL(this.target.url).origin;
        if (url.origin !== targetOrigin && !["jobs.ashbyhq.com", "job-boards.greenhouse.io"].includes(url.hostname)) return;
        const header = response.headers()["retry-after"];
        const seconds = header && /^\d+$/.test(header) ? Number(header) * 1000 : header ? Date.parse(header) - Date.now() : 60_000;
        this.rateLimit = Math.max(1000, Math.min(Number.isFinite(seconds) ? seconds : 60_000, Number.MAX_SAFE_INTEGER - Date.now()));
      });
    }

    return this.tab;
  }

  private isSubmissionResponse(response: Response): boolean {
    const request = response.request();
    return this.submissionRequests.has(request) && request.frame().page() === this.tab && request.method() === "POST" &&
      response.status() >= 200 && response.status() < 400 &&
      new URL(response.url()).origin === (this.target && new URL(this.target.url).origin);
  }

  private setupAllowed(raw: string): boolean {
    try {
      const url = new URL(raw);
      if (url.username || url.password) return false;
      if (this.testOrigins.has(url.origin)) return true;
      return url.protocol === "https:" && !url.port &&
        ["jobs.ashbyhq.com", "job-boards.greenhouse.io", "boards.greenhouse.io", "my.greenhouse.com"].includes(url.hostname);
    } catch { return false; }
  }
  private manualNavigationAllowed(raw: string): boolean {
    try {
      const url = new URL(raw);
      if (raw === "about:blank" || this.testOrigins.has(url.origin)) return true;
      return url.protocol === "https:" && !url.username && !url.password && !url.port
        && /^[a-z0-9-]+(?:\.[a-z0-9-]+)+$/i.test(url.hostname)
        && !/^\d[\d.]+$/.test(url.hostname) && !/\.(local|localhost|internal|test|invalid)$/i.test(url.hostname);
    } catch { return false; }
  }

  async openForSetup(url = "https://my.greenhouse.com/"): Promise<void> {
    if (!this.setupAllowed(url)) throw new Error("Unsupported setup destination");
    const context = await this.launch();
    if (!this.setupTab || this.setupTab.isClosed()) this.setupTab = await context.newPage();
    this.manualTabs.add(this.setupTab);
    await this.setupTab.goto(url, { waitUntil: "domcontentloaded" });
    await this.setupTab.bringToFront();
  }

  async close(): Promise<void> {
    this.stopped = true;
    const context = this.context;
    this.context = undefined;
    this.tab = undefined;
    this.setupTab = undefined;
    this.manualTabs.clear();
    if (context) await context.close();
    if (this.starting) await this.starting.catch(() => undefined);
  }

  private async structure(page: Page, target: Target, options = true): Promise<FormStructure | undefined> {
    const result = await readForm(page, target.provider, target.url);
    if (!result) return undefined;
    if (!this.same(result.destination, target)) result.snapshot.unsupported.push("Form destination does not match the approved application");
    if (options) await collectComboboxOptions(result, page, target.provider);
    result.snapshot.fingerprint = fingerprint(result.snapshot);
    return result;
  }

  private async load(job: Job): Promise<{ page: Page; target: Target; form?: FormStructure; state?: BrowserInspection["status"] }> {
    if (job.status === "closed" || (job.expiresAt && Date.parse(job.expiresAt) <= Date.now())) throw new Halt("unsupported", "This job is closed or expired");
    if (job.aiPolicy === "prohibited") throw new Halt("unsupported", "Employer policy prohibits AI assistance; manual application required");
    const target = this.identify(job.applyUrl);
    this.target = target;
    this.navigationBlocked = false;
    this.rateLimit = undefined;
    const page = await this.automationPage();
    let response;
    try {
      response = await page.goto(target.url, { waitUntil: "domcontentloaded" });
    } catch {
      // A failed document navigation may leave a Chrome error-page commit pending.
      // Retire that tab instead of racing its late navigation on the next job.
      await page.close().catch(() => undefined);
      if (this.tab === page) this.tab = undefined;
      throw new Halt("unsupported", this.navigationBlocked ? "Application redirected outside the approved job" : "Application navigation failed safely");
    }
    if (this.navigationBlocked || !this.same(page.url(), target)) throw new Halt("unsupported", "Application redirected outside the approved job");
    if ([404, 410].includes(response?.status() ?? 0)) return { page, target, state: "job_closed" };
    if ([401, 403].includes(response?.status() ?? 0)) return { page, target, state: await activeCaptcha(page) ? "captcha_required" : "auth_required" };
    const deadline = Date.now() + 12_000;
    do {
      if (this.stopped) throw new Halt("cancelled", "Browser was stopped");
      if (this.navigationBlocked || !this.same(page.url(), target)) throw new Halt("unsupported", "Application redirected outside the approved job");
      if (await activeCaptcha(page)) return { page, target, state: "captcha_required" };
      const state = await pageState(page);
      if (state) return { page, target, state };
      if (this.rateLimit) throw new Halt("failed", "Provider rate limit reached; do not retry automatically");
      const form = await this.structure(page, target);
      if (form) {
        await page.waitForTimeout(200);
        const settled = await this.structure(page, target);
        if (this.rateLimit) throw new Halt("failed", "Provider rate limit reached; do not retry automatically");
        if (settled?.snapshot.fingerprint === form.snapshot.fingerprint) return { page, target, form: settled };
      }
      await page.waitForTimeout(250);
    } while (Date.now() < deadline);
    return { page, target, state: "unsupported" };
  }

  async inspect(job: Job): Promise<BrowserInspection> {
    if (this.busy) return { status: "unsupported", reason: "The dedicated automation tab is busy" };
    this.busy = true;
    this.rateLimit = undefined;
    try {
      if (job.status === "closed" || (job.expiresAt && Date.parse(job.expiresAt) <= Date.now())) return { status: "job_closed", reason: "Job is closed or expired" };
      const { target, form, state } = await this.load(job);
      if (!form) return {
        status: state ?? "unsupported", provider: target.provider,
        reason: state === "captcha_required" ? "Visible verification challenge requires manual handling" : "Application unavailable, requires sign-in, or no supported form appeared",
        ...(this.rateLimit ? { retryAfterMs: this.rateLimit } : {}),
      };
      const snapshot = form.snapshot;
      const resumes = form.bindings.filter(b => b.kind === "file" && /\b(resume|cv)\b/i.test(b.field.label));
      const manualDocuments = resumes.length !== 1 || form.bindings.some(b => b.kind === "file" && b.field.required && b !== resumes[0]);
      return {
        provider: target.provider, snapshot,
        status: snapshot.hasCaptcha ? "captcha_required" : snapshot.hasLegal || manualDocuments ? "needs_input" : snapshot.unsupported.length ? "unsupported" : "ready",
        reason: snapshot.hasLegal ? "Legal, consent, own-words, AI-policy or assessment declaration requires manual handling" :
          manualDocuments ? "Exactly one recognized resume upload is required; other required documents are manual" :
          snapshot.unsupported.length ? snapshot.unsupported.join("; ") : "Form structure inspected; employer permission and exact answers are still required",
      };
    } catch (error) {
      return {
        status: "unsupported",
        reason: error instanceof Halt ? error.message : "Browser inspection failed safely; no application was sent",
        ...(this.rateLimit ? { retryAfterMs: this.rateLimit } : {}),
      };
    } finally { this.busy = false; }
  }

  private async guard(input: BrowserSubmitInput, page: Page, expected: FormStructure): Promise<FormStructure> {
    if (this.stopped || page.isClosed()) throw new Halt("cancelled", "Browser was stopped");
    if (this.navigationBlocked || !this.same(page.url())) throw new Halt("unsupported", "Application destination changed");
    if (!await input.checkAuthorization()) throw new Halt("cancelled", "Authorization was stopped or expired");
    if (this.rateLimit) throw new Halt("failed", "Provider rate limit reached; do not retry automatically");
    if (await activeCaptcha(page)) throw new Halt("captcha_required", "Visible verification challenge requires manual handling");
    const state = await pageState(page);
    if (state) throw new Halt(state === "job_closed" ? "unsupported" : state, state === "job_closed" ? "Job is no longer accepting applications" : "Manual sign-in is required");
    const current = await this.structure(page, this.target!, false);
    if (!current) throw new Halt("needs_input", "The approved application form disappeared");
    // Opening a combo is read-only, but do not reopen it during each input's guard.
    for (const b of current.bindings.filter(b => b.kind === "combobox")) {
      const previous = expected.bindings.find(p => p.field.key === b.field.key);
      if (previous) { b.field.options = previous.field.options; b.field.optionLabels = previous.field.optionLabels; }
    }
    current.snapshot.fingerprint = fingerprint(current.snapshot);
    if (current.snapshot.hasLegal) throw new Halt("needs_input", "New manual declaration requires review");
    if (current.snapshot.fingerprint !== expected.snapshot.fingerprint || current.destination !== expected.destination ||
        current.bindings.some((b, i) => b.accept !== expected.bindings[i]?.accept || b.selector !== expected.bindings[i]?.selector)) {
      throw new Halt("needs_input", "Form questions, options, upload restrictions or destination changed; inspect and approve again");
    }
    // Check last, immediately before the caller's browser interaction.
    if (!await input.checkAuthorization()) throw new Halt("cancelled", "Authorization was stopped or expired");
    return current;
  }

  private async approvedFile(input: BrowserSubmitInput): Promise<{ name: string; mimeType: string; buffer: Buffer }> {
    if (!input.resumeFilename.trim() || basename(input.resumeFilename) !== input.resumeFilename ||
        /[\u0000-\u001f\u007f/\\]/.test(input.resumeFilename) || !/^[a-f0-9]{64}$/i.test(input.resumeSha256)) {
      throw new Halt("failed", "Approved resume filename or checksum is invalid");
    }
    const buffer = await readFile(input.resumePath);
    if (createHash("sha256").update(buffer).digest("hex") !== input.resumeSha256.toLowerCase()) throw new Halt("failed", "Resume bytes do not match the approved SHA-256");
    if (buffer.length === 0 || buffer.length > 20 * 1024 * 1024) throw new Halt("failed", "Resume must be nonempty and at most 20 MB");
    const extension = extname(input.resumeFilename).toLowerCase();
    const pdf = extension === ".pdf" && buffer.subarray(0, 5).toString() === "%PDF-";
    const docx = extension === ".docx" && buffer.subarray(0, 4).equals(Buffer.from([0x50, 0x4b, 0x03, 0x04])) &&
      buffer.includes(Buffer.from("[Content_Types].xml")) && buffer.includes(Buffer.from("word/document.xml"));
    if (!pdf && !docx) throw new Halt("failed", "Only byte-verified PDF or DOCX resumes are supported");
    return { name: input.resumeFilename, mimeType: pdf ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document", buffer };
  }

  private async fill(binding: FieldBinding, answer: string, form: FormStructure, page: Page, input: BrowserSubmitInput): Promise<void> {
    const control = form.root.locator(binding.selector);
    await this.guard(input, page, form);
    if (binding.kind === "radio") {
      const option = control.and(form.root.locator(`[value=${JSON.stringify(answer)}]`));
      await option.check();
    } else if (binding.kind === "select") {
      await control.selectOption({ value: answer });
    } else if (binding.kind === "yesno") {
      await control.locator(`button[data-option=${JSON.stringify(answer)}]`).click();
    } else if (binding.kind === "autocomplete") {
      await this.fillLocation(binding, answer, form, page, input);
    } else if (binding.kind === "combobox") {
      await control.click();
      const id = await control.getAttribute("aria-controls") ?? await control.getAttribute("aria-owns");
      const list = id ? page.locator(`[id=${JSON.stringify(id)}]`) : page.locator('[role="listbox"]:visible');
      const options = await list.locator('[role="option"]').evaluateAll((es, mode) => es.filter(e => e.getAttribute("aria-disabled") !== "true").map(e =>
        mode === "label" ? (e.textContent ?? "").replace(/\s+/g, " ").trim() : e.getAttribute("data-value") ?? e.getAttribute("value")
      ), binding.optionMode);
      if (JSON.stringify(options) !== JSON.stringify(binding.field.options)) throw new Halt("needs_input", "Combobox options changed");
      await this.guard(input, page, form);
      if (binding.optionMode === "label") await list.getByRole("option", { name: answer, exact: true }).click();
      else await list.locator(`[role="option"][data-value=${JSON.stringify(answer)}], [role="option"][value=${JSON.stringify(answer)}]`).click();
    } else {
      await control.fill(answer);
    }

    // A blur can transmit too; recheck authorization before leaving the control.
    await this.guard(input, page, form);
    if (binding.kind === "input") await control.blur();
    await page.waitForTimeout(150);
    await this.guard(input, page, form);
  }

  private async fillLocation(binding: FieldBinding, answer: string, form: FormStructure, page: Page, input: BrowserSubmitInput): Promise<void> {
    if (this.target?.provider !== "ashby" || binding.field.key !== "_systemfield_location" || !normalizeLocation(answer) || answer.length > 512) {
      throw new Halt("needs_input", "Only an explicitly approved full location can be used with the known Ashby location control");
    }
    const control = form.root.locator(binding.selector);
    const wanted = normalizeLocation(answer);
    const optionSelector = '[role="option"].ashby-application-form-input-autocomplete-popup-result';
    const deadline = Date.now() + 6000;
    let previous = "", stableSince = 0;
    try {
      await this.guard(input, page, form);
      await control.fill(answer);
      do {
        await this.guard(input, page, form);
        const listId = await control.getAttribute("aria-controls");
        if (listId && await control.getAttribute("aria-expanded") === "true") {
          const list = page.locator(`[id=${JSON.stringify(listId)}][role="listbox"]:visible`);
          if (await list.count() === 1 && await list.getAttribute("aria-busy") !== "true") {
            const options = list.locator(optionSelector).filter({ visible: true });
            const labels = await options.evaluateAll(es => es.map(e => ({
              label: e.textContent ?? "", disabled: e.getAttribute("aria-disabled") === "true",
            })));
            const matches = labels.map((option, index) => ({ ...option, index })).filter(o => normalizeLocation(o.label) === wanted);
            if (matches.length > 1) throw new Halt("needs_input", "Location suggestions contain multiple exact matches; choose manually");
            const signature = JSON.stringify(labels);
            if (signature !== previous) { previous = signature; stableSince = Date.now(); }
            if (matches.length === 1 && !matches[0].disabled && Date.now() - stableSince >= 250) {
              const chosen = matches[0];
              const element = await options.nth(chosen.index).elementHandle();
              if (!element) throw new Halt("needs_input", "The exact location suggestion disappeared");
              await this.guard(input, page, form);
              const current = await options.evaluateAll(es => es.map(e => ({
                label: e.textContent ?? "", disabled: e.getAttribute("aria-disabled") === "true",
              })));
              if (JSON.stringify(current) !== signature || !await element.evaluate((e, expected) =>
                (e.textContent ?? "").normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase() === expected &&
                e.getAttribute("aria-disabled") !== "true", wanted)) {
                throw new Halt("needs_input", "Location suggestions changed before selection; review manually");
              }
              if (!await input.checkAuthorization()) throw new Halt("cancelled", "Authorization was stopped or expired");
              await element.click({ timeout: 2500 });
              await element.dispose();
              const confirmationDeadline = Date.now() + 2500;
              do {
                await this.guard(input, page, form);
                const selected = await control.evaluate((e, expected) => {
                  const normalized = (e as HTMLInputElement).value.normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase();
                  const popup = document.getElementById(e.getAttribute("aria-controls") ?? "");
                  return normalized === expected && e.getAttribute("aria-expanded") === "false" &&
                    (!popup || !popup.getClientRects().length || getComputedStyle(popup).visibility === "hidden");
                }, wanted);
                if (selected) { binding.selectedLocation = chosen.label; return; }
                await page.waitForTimeout(100);
              } while (Date.now() < confirmationDeadline);
              throw new Halt("needs_input", "The location suggestion click did not produce a verified selection");
            }
          }
        }
        await page.waitForTimeout(100);
      } while (Date.now() < deadline);
      throw new Halt("needs_input", "No unique exact location suggestion appeared; no location was selected");
    } catch (error) {
      if (error instanceof Halt) throw error;
      throw new Halt("needs_input", "The known location widget changed or did not accept the exact approved location");
    }
  }

  private async verifyAnswers(input: BrowserSubmitInput, form: FormStructure): Promise<void> {
    for (const binding of form.bindings.filter(b => b.kind !== "file")) {
      const expected = input.answers[binding.field.key];
      const matches = await form.root.locator(binding.selector).evaluateAll((elements, { expected, kind, label, optionMode, selectedLocation }) => {
        if (kind === "checkbox") return elements.length === 1 && !(elements[0] as HTMLInputElement).checked;
        if (kind === "yesno") {
          const selected = elements[0]?.querySelector('button[aria-pressed="true"]');
          return expected === undefined ? !selected : selected?.getAttribute("data-option") === expected;
        }
        if (kind === "radio") {
          const selected = (elements as HTMLInputElement[]).filter(e => e.checked);
          return expected === undefined ? selected.length === 0 : selected.length === 1 && selected[0].value === expected;
        }
        if (kind === "combobox" && optionMode === "label") {
          const selected = elements[0]?.closest(".select__control")?.querySelector(".select__single-value");
          const text = selected?.textContent?.replace(/\s+/g, " ").trim();
          return expected === undefined ? !text : text === expected;
        }
        if (kind === "autocomplete") {
          const element = elements[0] as HTMLInputElement | undefined;
          if (expected === undefined) return !element?.value;
          const normalize = (text: string) => text.normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase();
          return !!element && !!selectedLocation && normalize(selectedLocation) === normalize(expected) &&
            normalize(element.value) === normalize(expected) && element.getAttribute("aria-expanded") === "false";
        }
        const value = (elements[0] as HTMLInputElement | undefined)?.value;
        return expected === undefined ? !value : value === (kind === "combobox" ? label : expected);
      }, {
        expected, kind: binding.kind, label: expected === undefined ? undefined : binding.field.optionLabels?.[expected],
        optionMode: binding.optionMode, selectedLocation: binding.selectedLocation,
      });
      if (!matches) throw new Halt("needs_input", "A form answer was prefilled, changed, or not accepted exactly as approved");
    }
    for (const binding of form.bindings.filter(b => b.kind === "file" && !/\b(resume|cv)\b/i.test(b.field.label))) {
      const empty = await form.root.locator(binding.selector).evaluate(element => !(element as HTMLInputElement).files?.length);
      if (!empty) throw new Halt("needs_input", "An optional document contains an unapproved attachment; review it manually");
    }
  }

  private async upload(input: BrowserSubmitInput, page: Page, form: FormStructure, binding: FieldBinding, file: { name: string; mimeType: string; buffer: Buffer }): Promise<void> {
    const accepted = binding.accept.split(",").map(s => s.trim().toLowerCase()).filter(Boolean);
    if (accepted.length && !accepted.some(a => a === extname(file.name).toLowerCase() || a === file.mimeType || a === "*/*" || a === "application/*")) {
      throw new Halt("needs_input", "Approved resume MIME type or filename is not accepted by this upload control");
    }
    const control = form.root.locator(binding.selector);
    await this.guard(input, page, form);
    await control.setInputFiles(file);
    await this.verifyFile(control, input, file);
    const deadline = Date.now() + 7000;
    do {
      await this.guard(input, page, form);
      if (await validationError(page)) throw new Halt("needs_input", "Provider rejected the upload or reported a validation error");
      const acceptedByUi = await control.evaluate((element, { filename, selector }) => {
        const wrapper = element.closest(selector);
        if (!wrapper || wrapper.querySelector('[aria-busy="true"],[role="progressbar"]')) return false;
        const visible = (e: Element) => !!e.getClientRects().length && getComputedStyle(e).visibility !== "hidden" && !e.closest('[hidden],[aria-hidden="true"]');
        const filenameShown = [...wrapper.querySelectorAll("*")].some(e => visible(e) && e.childElementCount === 0 && e.textContent?.trim() === filename);
        const removeShown = [...wrapper.querySelectorAll("button,a,[role=button]")].some(e => visible(e) &&
          /remove|delete|replace/i.test(`${e.getAttribute("aria-label") ?? ""} ${e.getAttribute("title") ?? ""} ${e.textContent ?? ""}`));
        return filenameShown && removeShown;
      }, { filename: file.name, selector: PROVIDER_DOM[this.target!.provider].upload });
      if (acceptedByUi) return;
      await page.waitForTimeout(150);
    } while (Date.now() < deadline);
    throw new Halt("needs_input", "No trustworthy upload acceptance UI appeared; file selection alone is insufficient");
  }

  private async verifyFile(control: Locator, input: BrowserSubmitInput, file: { name: string; mimeType: string; buffer: Buffer }): Promise<void> {
    const matches = await control.evaluate(async (element, expected) => {
      const files = (element as HTMLInputElement).files;
      if (!files || files.length !== 1) return false;
      const f = files[0];
      const hash = [...new Uint8Array(await crypto.subtle.digest("SHA-256", await f.arrayBuffer()))].map(n => n.toString(16).padStart(2, "0")).join("");
      return f.name === expected.name && f.type === expected.mime && f.size === expected.size && hash === expected.hash;
    }, { name: file.name, mime: file.mimeType, size: file.buffer.length, hash: input.resumeSha256.toLowerCase() });
    if (!matches) throw new Halt("needs_input", "Uploader did not retain the approved file bytes, filename and MIME type");
  }

  async submit(input: BrowserSubmitInput): Promise<BrowserSubmission> {
    if (this.busy) return { status: "failed", reason: "The dedicated automation tab is busy" };
    this.busy = true;
    let boundary = false;
    let clicked = false;
    let target: Target | undefined;
    try {
      target = this.identify(input.job.applyUrl);
      this.clickStarted = false;
      this.submissionResponse = false;
      this.submissionRequests.clear();
      if (this.finished.has(target.url)) return { status: "submission_unknown", reason: "This browser already sent or attempted this application; verify manually, never retry automatically" };
      if (!await input.checkAuthorization()) throw new Halt("cancelled", "Authorization was stopped or expired");
      if (!this.same(input.snapshot.url, target) || fingerprint(input.snapshot) !== input.snapshot.fingerprint) throw new Halt("needs_input", "Approved form snapshot is invalid");
      if (input.snapshot.hasLegal || input.snapshot.hasCaptcha || input.snapshot.unsupported.length) throw new Halt("needs_input", "Approved form contains a manual-only step");
      const file = await this.approvedFile(input);
      this.authorization = input.checkAuthorization;
      const loaded = await this.load(input.job);
      const { page, form, state } = loaded;
      if (!form) throw new Halt(state === "auth_required" || state === "captcha_required" ? state : "unsupported", "Application cannot be submitted in its current state");
      if (form.snapshot.fingerprint !== input.snapshot.fingerprint) throw new Halt("needs_input", "Form changed since approval; inspect and approve again");
      if (await receiptVisible(page, target.provider)) throw new Halt("needs_input", "Confirmation was already present before submission; manual review required");
      const uploads = form.bindings.filter(b => b.kind === "file" && /\b(resume|cv)\b/i.test(b.field.label));
      if (uploads.length !== 1 || form.bindings.some(b => b.kind === "file" && b.field.required && b !== uploads[0])) throw new Halt("needs_input", "Exactly one recognized resume upload is required; other required documents are manual");
      const unknown = Object.keys(input.answers).filter(k => !form.bindings.some(b => b.field.key === k && b.kind !== "file" && b.kind !== "checkbox"));
      if (unknown.length) throw new Halt("needs_input", "Approved answers contain unknown or non-answer fields");
      for (const binding of form.bindings.filter(b => b.kind !== "file" && b.kind !== "checkbox")) {
        const answer = input.answers[binding.field.key];
        if (binding.field.required && (typeof answer !== "string" || !answer.trim())) throw new Halt("needs_input", "An approved answer to a required question is missing");
        if (answer !== undefined && typeof answer !== "string") throw new Halt("needs_input", "Invalid approved answer");
        if (answer !== undefined && binding.field.options.length && !binding.field.options.includes(answer)) throw new Halt("needs_input", "Approved option does not match an actual form option value");
      }
      for (const binding of form.bindings.filter(b => b.kind !== "file" && b.kind !== "checkbox")) {
        const answer = input.answers[binding.field.key];
        if (answer !== undefined) await this.fill(binding, answer, form, page, input);
      }
      await this.verifyAnswers(input, form);
      await this.upload(input, page, form, uploads[0], file);
      await this.guard(input, page, form);
      await this.verifyAnswers(input, form);
      await this.verifyFile(form.root.locator(uploads[0].selector), input, file);
      if (await validationError(page)) throw new Halt("needs_input", "Form validation requires manual review");
      const invalid = await form.root.locator("input,textarea,select").evaluateAll(es => es.some(e => {
        const input = e as HTMLInputElement;
        return input.willValidate && !input.validity.valid && !!e.getClientRects().length;
      }));
      if (invalid) throw new Halt("needs_input", "A visible field did not pass native validation");
      if (await receiptVisible(page, target.provider)) throw new Halt("needs_input", "Confirmation appeared before final submission; refusing an unverified receipt");
      const button = this.submitButton(form.root);
      if (await button.count() !== 1 || !await button.isEnabled()) throw new Halt("needs_input", "Final submit control is unavailable");
      await this.guard(input, page, form);
      boundary = true;
      await input.beforeSubmit();
      // Persist first; Stop may be pressed while persistence is in progress.
      await this.verifyAnswers(input, form);
      await this.verifyFile(form.root.locator(uploads[0].selector), input, file);
      await this.guard(input, page, form);
      clicked = true;
      this.clickStarted = true;
      await button.click({ timeout: 6000, noWaitAfter: true });
      const deadline = Date.now() + 12_000;
      do {
        if (page.isClosed() || this.stopped || this.navigationBlocked || !this.same(page.url(), target)) break;
        if (await activeCaptcha(page)) return { status: "captcha_required", reason: "Provider requested verification after submit; verify manually before any further attempt" };
        if (this.rateLimit) return { status: "failed", reason: "Provider rate limited the attempt; verify manually before any retry", retryAfterMs: this.rateLimit };
        const state = await pageState(page);
        if (state === "auth_required") return { status: "auth_required", reason: "Provider requires manual sign-in; verify whether the attempt was received" };
        if (await validationError(page)) return { status: "needs_input", reason: "Provider displayed a submission validation error; manual review required" };
        const disappeared = await page.locator(PROVIDER_DOM[target.provider].root).filter({ visible: true }).count() === 0;
        if (disappeared && this.submissionResponse && await receiptVisible(page, target.provider)) {
          this.finished.add(target.url);
          return {
            status: "submitted_confirmed", reason: "New provider confirmation replaced the application form after the submit action",
            evidence: JSON.stringify({ provider: target.provider, url: target.url, observedAt: new Date().toISOString(), receipt: "application-confirmation", formFingerprint: input.snapshot.fingerprint }),
          };
        }
        await page.waitForTimeout(200);
      } while (Date.now() < deadline);
      this.finished.add(target.url);
      return { status: "submission_unknown", reason: "Submit was attempted without a trustworthy receipt; never retry automatically" };
    } catch (error) {
      if (boundary && (clicked || !(error instanceof Halt && error.status === "cancelled"))) {
        if (target) this.finished.add(target.url);
        return { status: "submission_unknown", reason: "Sending state was persisted but no trustworthy receipt is available; verify manually and never retry automatically" };
      }
      return error instanceof Halt ? { status: error.status, reason: error.message, ...(this.rateLimit ? { retryAfterMs: this.rateLimit } : {}) } :
        { status: "failed", reason: "Browser operation failed safely before final submission; manual review required" };
    } finally { this.authorization = undefined; this.clickStarted = false; this.submissionRequests.clear(); this.busy = false; }
  }

  private submitButton(root: Locator): Locator {
    return root.getByRole("button", { name: /^(?:submit application|submit your application|submit|apply now)$/i }).filter({ visible: true });
  }
}
