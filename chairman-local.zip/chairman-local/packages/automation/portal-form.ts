import type { Locator, Page } from "playwright";
import type { FormField, FormSnapshot } from "../domain/types.js";
import { hasNoAiRestriction } from "../documents/safety.js";
import { activeCaptcha, fingerprint, pageState } from "./form.js";

export interface PortalBinding {
  field: FormField;
  selector: string;
  kind: "text" | "select" | "radio" | "checkbox" | "file" | "combobox";
  manual: boolean;
  legal: boolean;
  sensitive: boolean;
  multiple: boolean;
}
export interface PortalAction {
  selector: string;
  kind: "next" | "submit";
  destination: string;
  target: string;
}
export interface PortalForm {
  root: Locator;
  snapshot: FormSnapshot;
  bindings: PortalBinding[];
  actions: PortalAction[];
  destinations: string[];
  signature: string;
}
export interface PortalScan {
  form?: PortalForm;
  noAi: boolean;
  policyIncomplete: boolean;
  auth: boolean;
  closed: boolean;
  captcha: boolean;
  assessment: boolean;
  implicitLegal: boolean;
  complex: boolean;
  frame: boolean;
  applyLinks: { url: string; target: string }[];
}

export async function scanPortal(page: Page): Promise<PortalScan> {
  const meta = await page.evaluate(() => {
    const visible = (e: Element) => {
      const style = getComputedStyle(e), rect = e.getBoundingClientRect();
      return rect.width > 1 && rect.height > 1 && style.display !== "none" &&
        style.visibility !== "hidden" && style.opacity !== "0" && !e.closest('[hidden],[aria-hidden="true"]');
    };
    const clean = (s: string | null) => (s ?? "").replace(/\s+/g, " ").trim();
    const text: string[] = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node: Node | null;
    let bytes = 0;
    while ((node = walker.nextNode()) && bytes < 300_000) {
      const parent = node.parentElement;
      if (!parent || !visible(parent) || parent.closest("input,textarea,select,script,style,noscript,[contenteditable],.grecaptcha-badge")) continue;
      const part = clean(node.textContent);
      bytes += part.length;
      text.push(part);
    }
    const candidates = [...document.querySelectorAll("form,[role=form],.ashby-application-form-container,#form:has(.ashby-application-form-field-entry)")]
      .filter(e => visible(e) && e.querySelector('input:not([type=hidden]):not([type=submit]),textarea,select,[role=combobox]'));
    const roots = candidates.filter(e => !candidates.some(other => other !== e && e.contains(other)));
    const applicationHeading = [...document.querySelectorAll("h1,h2")].some(e => visible(e) && /\b(?:application|apply)\b/i.test(e.textContent ?? ""));
    const plausible = roots.filter(e => /(?:application|apply)/i.test(`${e.id} ${e.className} ${e.getAttribute("aria-label")}`) ||
      /\b(?:resume|cv|curriculum vitae)\b/i.test(e.textContent?.slice(0, 20_000) ?? "") ||
      roots.length === 1 && applicationHeading && /\b(?:first name|full name|given name)\b/i.test(e.textContent ?? ""));
    const chosen = plausible.length === 1 ? plausible[0] : undefined;
    document.querySelectorAll("[data-portal-root]").forEach(e => e.removeAttribute("data-portal-root"));
    chosen?.setAttribute("data-portal-root", "active");
    const links = [...document.querySelectorAll<HTMLAnchorElement>("a[href]")].filter(e => visible(e) &&
      /^(?:apply|apply now|apply for (?:this (?:job|role|position)|the role)|start application)$/i.test(clean(e.textContent)));
    const frame = [...document.querySelectorAll<HTMLIFrameElement>("iframe")].some(e =>
      visible(e) && !e.closest(".grecaptcha-badge") && !/captcha|recaptcha|hcaptcha|challenges\.cloudflare\.com|arkoselabs|funcaptcha/i.test(e.src));
    const complex = bytes >= 300_000 || !!chosen && [...chosen.querySelectorAll("*")].some(e =>
      !!e.shadowRoot || visible(e) && e.matches('[contenteditable="true"],canvas,[role=slider],[role=spinbutton]:not(input)'));
    return {
      text: text.join(" "), policyIncomplete: bytes >= 300_000, hasRoot: !!chosen, frame, complex,
      applyLinks: links.slice(0, 3).map(e => ({ url: e.getAttribute("href") ?? "", target: e.target })),
    };
  });
  const state = await pageState(page);
  const captcha = await activeCaptcha(page);
  const result: PortalScan = {
    noAi: hasNoAiRestriction(meta.text), policyIncomplete: meta.policyIncomplete, auth: state === "auth_required", closed: state === "job_closed", captcha,
    assessment: /\b(?:complete|take|coding|skills|technical)\s+(?:an?\s+)?(?:assessment|test|challenge)\b/i.test(meta.text),
    implicitLegal: /\bby (?:submitting|applying|clicking)\b.{0,100}\b(?:agree|consent|certify|attest|accept)\b/i.test(meta.text),
    complex: meta.complex, frame: meta.frame, applyLinks: meta.applyLinks,
  };
  if (!meta.hasRoot) return result;
  const root = page.locator('[data-portal-root="active"]');
  const structure = await root.evaluate(container => {
    const clean = (s: string | null | undefined) => (s ?? "").replace(/\s+/g, " ").trim();
    const visible = (e: Element) => {
      const style = getComputedStyle(e), rect = e.getBoundingClientRect();
      return rect.width > 1 && rect.height > 1 && style.display !== "none" &&
        style.visibility !== "hidden" && style.opacity !== "0" && !e.closest('[hidden],[aria-hidden="true"]');
    };
    const unsafe = (s: string) => s.length > 500 || /[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f]/u.test(s) ||
      /\b(?:ignore|override|disregard)\b.{0,100}\b(?:instructions?|policy|rules?|profile|previous|above)\b|\b(?:system prompt|developer message|tool calls?|execute (?:code|command)|run (?:this |the )?(?:command|script)|pretend|fabricate|invent qualifications)\b/i.test(s);
    const sensitive = (s: string) => /\b(?:password|passcode|one.?time|otp|2fa|mfa|ssn|social security|national (?:id|insurance)|passport|credit card|bank account|routing number|secret|csrf|token|honeypot)\b/i.test(s.replace(/[_-]/g, " "));
    const legal = (s: string) => /\b(?:agree|consent|certify|attest|acknowledge|terms|privacy|arbitration|declaration|certification)\b/i.test(s);
    const assessment = (s: string) => /\b(?:assessment|coding challenge|technical test|solve|captcha)\b/i.test(s);
    const controls = [...container.querySelectorAll<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>(
      'input,textarea,select,[role="combobox"]')];
    const bindings: PortalBinding[] = [], unsupported: string[] = [], seen = new Set<string>(), radios = new Set<string>();
    container.querySelectorAll("[data-portal-field],[data-portal-action]").forEach(e => {
      e.removeAttribute("data-portal-field"); e.removeAttribute("data-portal-action");
    });
    for (const [index, e] of controls.entries()) {
      const type = e.tagName === "TEXTAREA" ? "textarea" : e.tagName === "SELECT" ? "select" : e.getAttribute("type") || "text";
      if (["hidden", "button", "submit", "reset", "image"].includes(type)) continue;
      const wrapper = e.closest("fieldset,.field,.field-wrapper,.ashby-application-form-field-entry,.file-upload") ?? e.parentElement!;
      if (!visible(e) && !(type === "file" && visible(wrapper) && wrapper !== container && !e.closest("[hidden]"))) continue;
      const name = e.getAttribute("name") ?? "";
      const isRadio = type === "radio";
      if (isRadio && radios.has(name)) continue;
      const labels = "labels" in e ? [...(e.labels ?? [])].map(l => l.textContent).join(" ") : "";
      const labelRaw = isRadio ? e.closest("fieldset,[role=radiogroup],.field-wrapper,.ashby-application-form-field-entry")
        ?.querySelector("legend,.field-label,.ashby-application-form-question-title")?.textContent :
        labels || e.getAttribute("aria-label") ||
        (e.getAttribute("aria-labelledby") ?? "").split(" ").filter(Boolean).map(id => document.getElementById(id)?.textContent ?? "").join(" ") ||
        wrapper.querySelector(".ashby-application-form-question-title,.file-upload__label,.field-label")?.textContent;
      const label = clean(labelRaw).replace(/\s*\*$/, "");
      const rawKey = isRadio ? name : e.id || name || `field-${index}`;
      const required = e.hasAttribute("required") || e.getAttribute("aria-required") === "true" || /\*\s*$/.test(clean(labelRaw));
      if (type === "password" || sensitive(`${rawKey} ${label}`) || /^(?:current-password|new-password|one-time-code|cc-)/.test(e.getAttribute("autocomplete") ?? "")) {
        unsupported.push("Credential or highly sensitive control requires direct manual handling");
        continue;
      }
      if (!label || unsafe(label) || unsafe(rawKey) || ["__proto__", "constructor", "prototype"].includes(rawKey) || seen.has(rawKey)) {
        unsupported.push("Unlabelled, unsafe, or ambiguous control requires manual review");
        continue;
      }
      if (bindings.length >= 100) { unsupported.push("Form exceeds 100-control limit"); break; }
      seen.add(rawKey);
      const kind: PortalBinding["kind"] = e.getAttribute("role") === "combobox" ? "combobox" :
        type === "select" ? "select" : type === "radio" ? "radio" : type === "checkbox" ? "checkbox" : type === "file" ? "file" : "text";
      const options: string[] = [], optionLabels: Record<string, string> = {};
      e.setAttribute("data-portal-field", String(index));
      if (kind === "select") {
        for (const o of [...(e as HTMLSelectElement).options].filter(o => !o.disabled && o.value)) {
          options.push(o.value); optionLabels[o.value] = clean(o.textContent);
        }
      } else if (kind === "radio") {
        radios.add(name);
        for (const radio of controls.filter(c => c.getAttribute("name") === name && c.getAttribute("type") === "radio" && visible(c))) {
          radio.setAttribute("data-portal-field", String(index));
          options.push(radio.value); optionLabels[radio.value] = clean(radio.labels?.[0]?.textContent);
        }
      } else if (kind === "checkbox") {
        options.push("true", "false");
      } else if (kind === "combobox") {
        const list = document.getElementById(e.getAttribute("aria-controls") ?? e.getAttribute("aria-owns") ?? "");
        if (list?.getAttribute("role") === "listbox") for (const o of list.querySelectorAll('[role=option]:not([aria-disabled=true])')) {
          const label = clean(o.textContent);
          const value = o.getAttribute("data-value") ?? o.getAttribute("value") ?? label;
          options.push(value); optionLabels[value] = label;
        }
      }
      const multiple = e.hasAttribute("multiple");
      const manual = e.hasAttribute("disabled") || e.hasAttribute("readonly") || multiple ||
        kind === "text" && !["text", "email", "tel", "url", "number", "date", "search", "textarea"].includes(type) ||
        kind === "combobox" && (!options.length || options.length > 100) ||
        kind === "combobox" && e.tagName === "BUTTON" && e.getAttribute("type") !== "button" ||
        assessment(label) || options.length > 100 || new Set(options).size !== options.length ||
        options.some(o => unsafe(o) || unsafe(optionLabels[o] ?? ""));
      const field: FormField = { key: rawKey, label, type: kind === "text" ? type : kind, required, options: options.slice(0, 100) };
      if (options.length && kind !== "checkbox") field.optionLabels = optionLabels;
      if (kind === "file") field.accept = (e.getAttribute("accept") ?? "").split(",").map(s => s.trim().toLowerCase()).filter(Boolean);
      bindings.push({ field, kind, selector: `[data-portal-field="${index}"]`, manual, legal: legal(label), sensitive: false, multiple });
    }
    const actions: PortalAction[] = [];
    const destinations = [container.getAttribute("action") ?? ""];
    const actionNodes = [...container.querySelectorAll<HTMLElement>('button,input[type=submit],a[href],[role=button]')].filter(visible);
    for (const [index, e] of actionNodes.entries()) {
      const label = clean(e.textContent || e.getAttribute("value") || e.getAttribute("aria-label"));
      const next = /^(?:next|continue|next step|continue application|save (?:&|and) continue)$/i.test(label);
      const submit = /^(?:submit|submit application|submit your application|send application|apply now)$/i.test(label);
      if (!next && !submit) continue;
      const destination = e.getAttribute("href") ?? e.getAttribute("formaction") ?? container.getAttribute("action") ?? "";
      destinations.push(destination);
      e.setAttribute("data-portal-action", String(index));
      actions.push({ kind: next ? "next" : "submit", selector: `[data-portal-action="${index}"]`, destination,
        target: e.getAttribute("formtarget") ?? e.getAttribute("target") ?? container.getAttribute("target") ?? "_self" });
    }
    return { bindings, unsupported, actions, destinations };
  });
  const snapshot: FormSnapshot = {
    url: page.url().split(/[?#]/)[0]!, fields: structure.bindings.map(b => b.field), fingerprint: "",
    hasCaptcha: captcha, hasLegal: structure.bindings.some(b => b.legal && b.field.required) || result.implicitLegal,
    unsupported: structure.unsupported,
  };
  snapshot.fingerprint = fingerprint(snapshot);
  result.form = {
    root, snapshot, ...structure,
    signature: JSON.stringify([snapshot.fingerprint, structure.destinations, structure.actions, structure.bindings.map(b => [b.selector, b.manual, b.legal])]),
  };
  return result;
}

/** Only ordinary controls. Credential values, hidden inputs and editable assessment text are never read. */
export async function ordinaryValues(form: PortalForm): Promise<Record<string, string>> {
  const entries: [string, string][] = [];
  for (const binding of form.bindings) {
    if (binding.sensitive || binding.kind === "file" || binding.manual) continue;
    const value = await form.root.locator(binding.selector).evaluateAll((nodes, kind) => {
      const e = nodes[0] as HTMLInputElement | undefined;
      if (!e) return "";
      if (kind === "checkbox") return e.checked ? "true" : "";
      if (kind === "radio") return (nodes as HTMLInputElement[]).find(e => e.checked)?.value ?? "";
      if (kind === "combobox") {
        if (e.tagName === "INPUT") return e.value;
        return e.getAttribute("aria-valuetext") ?? e.textContent?.trim() ?? "";
      }
      return e.value;
    }, binding.kind);
    entries.push([binding.field.key, value]);
  }
  return Object.fromEntries(entries);
}

export async function portalReceipts(page: Page): Promise<string[]> {
  // Provider regions plus headings of a same-origin "thanks" page (e.g. Lever's /thanks); attributed only together with an observed submission response.
  return page.locator('[role=status],[role=alert],.confirmation,.application-confirmation,.application--confirmation,#confirmation,#application_confirmation,#application_confirmation_container,.ashby-application-form-success-container,.ashby-application-form-success-message,[class*="_successConfirmation_"],[class*="thanks" i],[class*="success-message" i],main h1,main h2,main h3,body > h1,body > h2,body > h3').evaluateAll(nodes => nodes.filter(e =>
    !!e.getClientRects().length && getComputedStyle(e).visibility !== "hidden" &&
    !e.closest('[hidden],[aria-hidden=true],.job__description,.ashby-job-posting-description,[data-job-description],form,[role=form]') &&
    /(?:application (?:has been |was )?(?:received|submitted)|thank you for (?:applying|(?:submitting )?your application)|thanks for applying|(?:successfully )?(?:submitted|received) your application)/i.test(e.textContent ?? "")
  ).map(e => (e.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 1000)));
}
