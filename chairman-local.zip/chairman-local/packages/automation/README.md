# Browser application driver

`ApplicationBrowser` implements the parent-owned `ApplicationBrowserDriver` contract.

```ts
const browser = new ApplicationBrowser({
  userDataDir: "/absolute/path/to/a/dedicated-application-profile",
  headless: false,
});
```

Exports:

- `ApplicationBrowser` from `browser.ts`.
- `providerForUrl(url): AutomationProvider | undefined`.
- `canonicalApplicationUrl(url): string` (throws for unsafe/unsupported URLs).
- `sameApplication(a, b): boolean`.
- `PROVIDERS`, provider/domain/help/policy/limitations metadata.

The last four exports are available from both `providers.ts` and `browser.ts`.
The constructor's optional `testOrigins` is exclusively for tests. Production must
never populate it. Only explicitly listed loopback origins are accepted in tests;
environment variables, URL parameters and provider metadata cannot enable it.

## Technical support is not permission

Recognized application URLs are:

- `https://jobs.ashbyhq.com/<board>/<uuid>[/application]`
- `https://job-boards.greenhouse.io/<board>/jobs/<positive-integer>`
- `https://boards.greenhouse.io/<board>/jobs/<positive-integer>` (canonicalizes to
  the modern host).

HTTPS, exact hosts, matching board/job identity and noncredentialed URLs are
mandatory. Tracking queries/fragments are removed. LinkedIn, Wellfound, Naukri,
custom employer hosts, private hosts, arbitrary redirects and unsupported paths
are not automation destinations. Redirect headers are checked **before following**
the next document request, including POST redirects. An identity-losing
confirmation redirect is uncertain, not permission to visit another destination.

`job.applyUrl` pins the application identity. `job.canonicalUrl` may instead point
to its attributed discovery listing (for example Himalayas); it is not navigated
or treated as an alternative application destination.

The parent must determine employer/source permission, job eligibility, approved
answers, and durable authorization. These adapters do **not** assert a partnership,
candidate API grant, or universal permission to automate either platform.
`job.aiPolicy === "prohibited"` is rejected without opening a form. Explicit
required consent/arbitration, own-words/no-AI declarations and assessments require
manual handling even if the caller supplied an answer. Optional marketing/legal
opt-in checkboxes can remain unchecked and untouched; the driver never activates
them. A prechecked opt-in requires manual review.

### Official sources reviewed on 2026-09-15

- [Ashby Terms of Service](https://www.ashbyhq.com/resources/terms):
  the agreement identifies the customer as a business entity. §5.1(f) forbids
  attempting to “circumvent or disable any security or other technological
  features”; §5.1(g) forbids disruptive/overburdening use. The reviewed text is
  **not a candidate automation grant**. We did not verify a blanket prohibition
  on ordinary applicant form assistance in this customer agreement.
- [Ashby application-form help](https://docs.ashbyhq.com/application-forms):
  employers can customize, unlink and change forms per job. Therefore approval
  applies to an exact inspected snapshot, not a presumed universal template.
- [Greenhouse legal index](https://www.greenhouse.com/legal) and its linked
  [Master Subscription Agreement](https://www.greenhouse.com/uk/master-subscription-agreement):
  §4(c)(v) disallows unauthorized access and §4(c)(ix) disallows circumventing
  technological protective measures. These are customer terms, not a grant to
  applicants. No blanket candidate-automation permission is inferred.
- [Greenhouse confirmation-page help](https://support.greenhouse.io/hc/en-us/articles/115005516483-Edit-application-confirmation-page):
  confirmation is the response **after** submission and is customizable per board.
- Privacy references:
  [Ashby](https://www.ashbyhq.com/privacy),
  [Greenhouse](https://www.greenhouse.com/privacy-policy).

An initial search result incorrectly attributed blanket bot-prohibition quotations
to the providers. They were not present in the fetched Ashby agreement, and the
claimed Greenhouse `/legal/user-agreement` URL returned 404; those quotations are
not evidence and are not used to make a policy decision. Re-review actual
employer/source terms before enabling a source. A known prohibition is a reason
to leave it manual, not to evade it.

## Actual public DOM observations (read-only)

No application, resume upload, login, account creation, or credential extraction
was performed against any employer during development.

### Ashby

Observed:
`https://jobs.ashbyhq.com/ashby/206c6a86-74e3-4fcf-9175-fdfe07858676/application`
(Manager of Renewals, SMB).

- The form root is **a `div#form`, not an HTML `<form>`**.
- It contains `.ashby-application-form-container` and
  `.ashby-application-form-field-entry`.
- Name/email are `#_systemfield_name` / `#_systemfield_email`; both had native
  `required` attributes.
- Resume is hidden `input[type=file]#_systemfield_resume`, inside
  `.ashby-application-form-input-file`. The separate
  `.ashby-application-form-autofill-uploader` is not a resume attachment and is
  deliberately excluded.
- Questions use `.ashby-application-form-question-title`; `data-field-path`
  identifies some controls that have no input ID.
- Boolean controls use `.ashby-application-form-input-yesno` with
  `button[data-option="yes"|"no"][aria-pressed]`. Its implementation checkbox is
  not an extra applicant question.
- Native radio options have real `value` attributes and linked labels.
- The location input was an unnamed `input[role=combobox]` in a field with
  `data-field-path="_systemfield_location"`,
  `.ashby-application-form-input-autocomplete`, `aria-autocomplete="list"` and
  `aria-haspopup="listbox"`. This exact provider/system control is represented as
  `type: "autocomplete", options: []`; inspection never types or queries it.
- A separate public-geography-only inspection using `Reykjavik` (not candidate
  data) established that suggestions are associated by `aria-controls` and use
  `[role=option].ashby-application-form-input-autocomplete-popup-result`.
  Suggestions included `Reykjavík, Capital Region, Iceland` and
  `Capital Region, Iceland`. No suggestion was selected during that research.
  `aria-selected="true"` can mark the **initial highlighted** suggestion and is
  not treated as proof of selection.
- During authorized submission, the driver types only the explicitly approved
  full location string and waits for one exact normalized matching suggestion.
  Normalization is Unicode NFKC, whitespace folding/trimming and case folding:
  there is no fuzzy matching, punctuation removal, abbreviation expansion,
  geographic inference or first-option fallback. Duplicate matches, no match,
  structural changes, or an unconfirmed click return `needs_input`.
- Selection requires clicking the uniquely matching rendered option, the popup
  closing and the accepted displayed value matching that approved location.
  The approved text is checked again before final submission.
- Ashby's open location menu temporarily applies `data-aria-hidden="true"` with
  `aria-hidden="true"` to otherwise visible sibling questions. These known,
  temporary accessibility markers and suggestion rows do not change the
  snapshot; actual hidden/display state, labels, types, required flags and new
  questions still do.
- Final button text: `Submit Application`.
- Provider-served public CSS included `._successConfirmation_kyg4m_77`; the
  adapter recognizes this scoped component prefix, without hardcoding its build
  hash. No confirmation screen was triggered against the employer.
- The page exposed an application-limit notice; this driver does not bypass limits.

### Greenhouse

Verified read-only redirect:
`https://boards.greenhouse.io/anthropic/jobs/4669581008`
→ `https://job-boards.greenhouse.io/anthropic/jobs/4669581008`.

- `form#application-form.application--form`, action
  `/anthropic/jobs/4669581008`.
- `#first_name`, `#last_name`, `#email`, `#phone`; required state commonly uses
  `aria-required="true"`, not native `required`.
- Resume: `#resume.visually-hidden`, inside
  `.file-upload[role=group][aria-labelledby="upload-label-resume"]`.
  The actual heading is `.upload-label` (`Resume/CV*`), **not** the input's
  visually hidden “Attach” label.
- Resume accept string: `.pdf,.doc,.docx,.txt,.rtf`; this driver restricts its own
  approved artifacts further to verified PDF/DOCX.
- Country and many custom questions use `input.select__input[role=combobox]`.
  Opening the country menu displayed `.select__option[role=option]`, with
  IDs such as `react-select-country-option-0`, but **no public value/data-value**.
  Indexes are not submission values. For this specific **ARIA combobox** widget,
  the driver uses unique, fully rendered visible option names as the approved
  interaction keys (`type: "combobox"`), clicks that exact option and verifies
  `.select__single-value`. For example, the actual country choice is
  `India +91`, not a guessed native value `IN`. Native select/radio snapshots
  always retain actual native values. Ambiguous or remote-autocomplete variants
  remain unsupported; the driver never reads private component state.
- The hidden React Select required sentinel and the hidden telephone-country
  search widget are not extra visible questions.
- The observed Anthropic form contained `AI Policy for Application` and an
  `Agreement to Arbitrate`. **This application is manual-only**; neither
  declaration was accepted or filled.
- Final button text: `Submit application`.
- The provider-served public stylesheet exposes `.confirmation`,
  `.confirmation__content` and `.confirmation__links`. `.confirmation` is the
  current confirmation-region selector; no real application was sent to display it.

Native text/email/tel/url/number/date fields, textareas, selects, native radio
groups, Ashby yes/no buttons, public explicit-value comboboxes, and the observed
Greenhouse uniquely named ARIA options are supported. Ashby's exact
`_systemfield_location` autocomplete additionally supports approved full-location
queries with unique exact matches; arbitrary opaque comboboxes remain blocked.
Opaque/ambiguous choices, multi-selects, custom editors, disabled required
questions and unrecognized controls stop the operation. This is deliberately
narrower than “all Ashby/Greenhouse jobs supported.”

## Submission guarantees and limitations

- Uses installed Chrome (`channel: "chrome"`) with a dedicated persistent profile,
  one automation tab and a separate `openForSetup()` tab. Normal Chrome profile
  paths are rejected, including symlink resolutions. No stealth, navigator
  modification, proxies, anti-bot evasion or CAPTCHA solving.
  The separate manual setup tab can follow normal public-HTTPS identity-provider
  redirects/popups so the user can complete sign-in. No form automation, credential
  reading or applicant-data injection runs in that tab; the automation tab remains
  restricted to its exact supported application identity.
- `inspect()` only returns field structure, labels and actual option values, never
  existing answers, hidden CSRF tokens, cookies or form bodies. SHA-256 uses
  `JSON.stringify({url,fields,hasCaptcha,hasLegal,unsupported})`, with fields ordered
  `key,label,type,required,options`, followed by optional `optionLabels` and then
  optional `accept`. File `accept` arrays contain the site's MIME types/extensions,
  trimmed and lowercased in DOM order. Missing attributes remain absent; an explicit
  empty accept attribute produces `[]`. Accept-list changes invalidate approval.
- Native/ARIA required controls are checked; hidden honeypots/internal inputs are
  untouched. Hidden resume inputs remain supported.
- Exactly one recognizable resume input is required. Optional cover-letter and
  other file inputs remain empty and untouched; their presence does not block
  submission. Other required documents return `needs_input`. Existing unapproved
  optional attachments and prechecked opt-ins require manual review, not clearing
  or automatically consenting on the user's behalf.
- Every answer operation, blur, upload and final click rechecks job identity,
  destination, authorization and form structure. Conditional questions, changed
  options and changed upload restrictions require fresh review. Actual accepted
  answers are checked again after upload, so resume autofill cannot silently
  replace approved answers.
  Known location suggestions are bounded to six seconds, checked for stability
  before clicking, and revalidated for uniqueness immediately before selection.
  Stop is checked while waiting and before selection; browser fetch/XHR requests
  (including deferred GET autocomplete queries) also recheck authorization.
- Only the supplied approved resume bytes/name/hash are uploaded. SHA-256, PDF/
  DOCX signatures, extension/MIME and the upload control's accept list must match.
  A hash-named private packet artifact may have a different basename from the
  approved original display filename (for example, `<sha256>.docx` versus
  `data.docx`). The driver reads the exact private path, verifies its bytes, and
  gives Chrome the separately approved safe display name without rewriting files.
  A matching `FileList` alone is insufficient: the provider uploader must show the
  exact filename, a visible remove/replace control and no error/progress state.
  Unsupported uploader presentation pauses; it is not presumed accepted.
- A passive privacy link or invisible reCAPTCHA badge is not a challenge.
  Visible verification challenges and verification errors stop automation.
- `beforeSubmit()` is called exactly once before final click. After that boundary,
  missing responses, lost pages, unsupported navigation or absent trustworthy
  confirmation are `submission_unknown`. There is no automatic retry; this
  instance also refuses a repeated confirmed/uncertain attempt. The parent must
  persist this rule across process restarts.
- Confirmation requires a **new provider-specific confirmation region**, the form
  disappearing after the click, and a same-origin POST response. Job-description
  text, pre-existing “success,” HTTP 200 alone and a generic body-text match are
  never receipts. Supported region selectors live in `PROVIDER_DOM`; arbitrary
  customized confirmation pages can remain unknown. No real employer submission
  was authorized, so **production post-submit confirmation was not exercised**.
- The returned receipt evidence only contains provider, canonical job URL, time,
  a fixed confirmation classification and form fingerprint. No screenshots,
  request bodies, resume content, passwords or candidate details are logged.
- Validation, CAPTCHA, authentication and 429 responses are structured results;
  `Retry-After` is bounded and reported, never used for automatic retries.
  Preflight throttling returns `BrowserInspection.status: "unsupported"` with
  the rate-limit reason and `retryAfterMs` (there is no throttled status in the
  inspection contract); this delay is cleared for subsequent inspections.
- Dedicated profile contents are sensitive local browser data. The caller owns
  profile retention, OS access controls, durable queue state and receipt storage.

## Tests

Run the existing Node test runner with installed Chrome:

```sh
node --import tsx --test tests/automation-browser.test.ts tests/autopilot-browser-integration.test.ts
```

Tests serve **synthetic local forms**, not employer endpoints. They exercise both
provider layouts, actual browser typing/options/radios/yes-no controls, accepted
hidden uploads and exact bytes, native navigation, receipt transitions, conditional
questions, changed destinations, strict production URL recognition, redirect
blocking, Stop/authorization callbacks, legal/account/CAPTCHA/manual states,
MIME/hash errors, file-selection-without-acceptance, validation/429 responses,
premature/fake receipts and unknown outcomes without repeat submission.
Optional empty documents/unchecked opt-ins, required additional documents and
attestations, and ordered accept-list fingerprints are also covered.
Location scenarios cover delayed suggestions with a nonmatching first option,
case/whitespace-normalized exact selection, duplicate matches, mismatches,
conditional changes, unaccepted clicks, unknown lookalike widgets and Stop.
Profiles and synthetic resumes are created under the project and cleaned up.
The integration file contains one combined case using the real `Store`,
`ResumeLibrary`, `Engine`, `AutopilotService` and Chrome driver: four approved
DOCX variants, standing activation, automatic selection of `data.docx`, unchanged
private artifact bytes, the exact displayed filename/MIME/bytes received locally,
the durable submit boundary and a confirmed receipt—without per-job approval.
It uses `allowTestJobs: true` and explicit `testOrigins`, never employer endpoints.

### Reusing the exact fixture in service integration tests

Import the side-effect-free test helper, **not** the test module:

```ts
import { ApplicationBrowser } from "./packages/automation/browser.js";
import { providerFixtureHtml } from "./packages/automation/testing/provider-fixture.js";

const path = "/fixture/jobs/100";
// GET path: respond with Content-Type: text/html and this string.
const html = providerFixtureHtml("greenhouse", "normal", path);
// POST path: consume the synthetic JSON body and respond HTTP 200 JSON.
// The fixture then removes the form and renders the provider confirmation region.
const driver = new ApplicationBrowser({
  userDataDir: ".integration-browser-profile",
  headless: true,
  testOrigins: ["http://127.0.0.1:YOUR_TEST_PORT"],
});
```

`providerFixtureHtml(provider, mode, action): string` and
`ProviderFixtureMode` are exported from `testing/provider-fixture.ts`; importing
them does not start servers or register/run tests. `tests/automation-browser.test.ts`
contains the reusable example server routing, synthetic PDF construction, job
metadata and all abnormal response modes.
Mode `integration` exposes ordinary Yes/No work-authorization labels over the
existing native option values and base64-encodes `resume.bytes`, allowing the
test server to compare binary DOCX bytes exactly. Other fixture modes retain
their text-resume representation.

Use job `applyUrl`/`canonicalUrl` equal to the local origin plus `path` for direct
driver testing. For Ashby, use
`/fixture/206c6a86-74e3-4fcf-9175-fdfe07858676/application` instead.
Production `providerForUrl`/`sameApplication` remain production-only; if a service
requires production URLs before calling the driver, keep any synthetic
public-to-loopback identity translation entirely in its test harness rather than
loosening production allowlists.

Explicit fixture answer keys:
`first_name: "Synthetic"`, `email: "fixture@example.test"`,
`work: "authorized"`, `schedule: "r"`, and `country: "India"` for Greenhouse
or `"IN"` for Ashby. Ashby additionally supports `relocate: "no"`.
`notes` is optional. Omit `marketing`, `cover_letter` and `portfolio` entirely.
The resume is passed only through the approved file path/name/hash arguments.
For normal JSON POSTs the fixture sends synthetic answers, resume name/MIME/bytes,
and empty optional-file/unchecked-opt-in assertions; the server must never route
these requests to a real employer.

For Ashby async-location coverage, use a `location-*` fixture mode and provide
`_systemfield_location: "Test City, Test Region, Test Country"`. The example server
in the driver test handles GET `/location-suggestions?text=...` with synthetic
JSON labels and GET `/location-selected?label=...` as a test-only selection
counter. `location-exact` deliberately puts the exact result second; other modes
exercise ambiguity, mismatch, field changes and Stop. These fixture endpoints
must remain local and must never forward location queries to any real provider.
