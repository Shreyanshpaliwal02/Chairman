import type { KnownAutomationProvider as AutomationProvider } from "../domain/types.js";

export const PROVIDERS = [
  {
    id: "ashby" as const,
    name: "Ashby",
    domains: ["jobs.ashbyhq.com"],
    officialDomains: ["jobs.ashbyhq.com"],
    support: "Hosted application forms; standard controls, resume uploads, explicit-value widgets and exact-match system location autocomplete.",
    limitations: ["Employer-specific permission required", "Known location autocomplete requires one exact normalized suggestion; other opaque widgets remain manual", "No CAPTCHA, required legal declarations or assessments", "Custom confirmation messages can require manual receipt review"],
    permission: "employer_policy_required",
    policyUrl: "https://www.ashbyhq.com/resources/terms",
    policyUrls: ["https://www.ashbyhq.com/resources/terms", "https://www.ashbyhq.com/privacy"],
    helpUrl: "https://docs.ashbyhq.com/application-forms",
    policyNotes: "The reviewed terms govern Ashby's business customers, prohibit circumvention and abusive use, and do not grant candidate automation permission. Technical support is not authorization or a partnership.",
  },
  {
    id: "greenhouse" as const,
    name: "Greenhouse",
    domains: ["job-boards.greenhouse.io", "boards.greenhouse.io"],
    officialDomains: ["job-boards.greenhouse.io", "boards.greenhouse.io"],
    support: "Hosted application forms and identity-preserving legacy redirects; standard controls and resume uploads.",
    limitations: ["Employer-specific permission required", "Only unique fully rendered Greenhouse combobox option names are supported; remote/ambiguous options remain manual", "No MyGreenhouse login automation, declarations, assessments, or CAPTCHA", "Custom confirmation messages can require manual receipt review"],
    permission: "employer_policy_required",
    policyUrl: "https://www.greenhouse.com/legal",
    policyUrls: ["https://www.greenhouse.com/legal", "https://www.greenhouse.com/uk/master-subscription-agreement", "https://www.greenhouse.com/privacy-policy"],
    helpUrl: "https://support.greenhouse.io/hc/en-us/articles/115005516483-Edit-application-confirmation-page",
    policyNotes: "The reviewed customer agreement restricts circumvention; it is not a candidate automation grant. Employer policies and declarations still apply. Employer submission APIs and keys are not used.",
  },
] as const;

const UUID = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
const ASHBY_PATH = new RegExp(`^/([A-Za-z0-9_-]+)/(${UUID})(?:/application)?/?$`, "i");
const GREENHOUSE_PATH = /^\/([A-Za-z0-9_-]+)\/jobs\/([1-9]\d*)\/?$/;

function safeUrl(raw: string): URL {
  if (raw !== raw.trim() || /[\\\u0000-\u0020]/.test(raw)) throw new Error("Unsafe application URL");
  const url = new URL(raw);
  if (url.username || url.password || url.port || url.protocol !== "https:" || /%/.test(url.pathname)) throw new Error("Unsafe application URL");
  // URL normalizes dot segments; do not silently accept a different input path.
  const originalPath = raw.replace(/^https:\/\/[^/]+/i, "").split(/[?#]/)[0];
  if (/(?:^|\/)\.{1,2}(?:\/|$)/.test(originalPath)) throw new Error("Unsafe application URL");
  return url;
}

export function providerForUrl(raw: string): AutomationProvider | undefined {
  try {
    const url = safeUrl(raw);
    if (url.hostname === "jobs.ashbyhq.com" && ASHBY_PATH.test(url.pathname)) return "ashby";
    if (["job-boards.greenhouse.io", "boards.greenhouse.io"].includes(url.hostname) && GREENHOUSE_PATH.test(url.pathname)) return "greenhouse";
  } catch { /* Invalid URLs are unsupported, not destinations. */ }
  return undefined;
}

export function canonicalApplicationUrl(raw: string): string {
  const provider = providerForUrl(raw);
  if (!provider) throw new Error("Unsafe or unsupported application URL");
  const url = safeUrl(raw);
  if (provider === "ashby") {
    const [, board, id] = url.pathname.match(ASHBY_PATH)!;
    return `https://jobs.ashbyhq.com/${board}/${id.toLowerCase()}/application`;
  }
  const [, board, id] = url.pathname.match(GREENHOUSE_PATH)!;
  return `https://job-boards.greenhouse.io/${board}/jobs/${id}`;
}

export function sameApplication(a: string, b: string): boolean {
  try { return canonicalApplicationUrl(a) === canonicalApplicationUrl(b); } catch { return false; }
}

export const PROVIDER_DOM = {
  ashby: {
    root: '#form:has(.ashby-application-form-field-entry), .ashby-application-form-container:has(.ashby-application-form-field-entry):not(#form *)',
    field: ".ashby-application-form-field-entry",
    upload: ".ashby-application-form-input-file",
    receipt: '.ashby-application-form-success-container, .ashby-application-form-success-message, [class*="_successConfirmation_"]',
    description: ".ashby-job-posting-description",
  },
  greenhouse: {
    root: "form#application-form, form#application_form",
    field: ".field-wrapper, .field",
    upload: ".file-upload, .attach-or-paste",
    receipt: ".confirmation, .application--confirmation, .application-confirmation, #application_confirmation, #application_confirmation_container, #confirmation",
    description: ".job__description, #content",
  },
} as const;

/** Only explicit constructor-injected loopback origins can exercise synthetic provider DOM. */
export function testApplication(raw: string, origins: ReadonlySet<string>): { url: string; provider: AutomationProvider } | undefined {
  try {
    const u = new URL(raw);
    if (!origins.has(u.origin) || u.username || u.password || /[%\\]/.test(u.pathname)) return undefined;
    const ashby = u.pathname.match(ASHBY_PATH);
    if (ashby) return { url: `${u.origin}/${ashby[1]}/${ashby[2].toLowerCase()}/application`, provider: "ashby" };
    const greenhouse = u.pathname.match(GREENHOUSE_PATH);
    if (greenhouse) return { url: `${u.origin}/${greenhouse[1]}/jobs/${greenhouse[2]}`, provider: "greenhouse" };
  } catch { /* Fail closed. */ }
  return undefined;
}
