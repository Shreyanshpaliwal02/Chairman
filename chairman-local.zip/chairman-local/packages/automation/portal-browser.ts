import { createHash, randomUUID } from "node:crypto";
import { chmod, mkdir, readFile, realpath, stat } from "node:fs/promises";
import { basename, extname, join, resolve } from "node:path";
import { chromium, type BrowserContext, type Page, type Request, type Route } from "playwright";
import { safeCareerUrl } from "../adapters/public-page.js";
import { isNormalBrowserProfile } from "./profile-path.js";
import { getChromeLaunchOptions } from "../platform/browser.js";
import { hasNoAiRestriction } from "../documents/safety.js";
import type { FormField, FormSnapshot, Job } from "../domain/types.js";
import type { AssistanceFillResult, AssistanceGrant, AssistancePage } from "../domain/extension-assist.js";
import type {
  ApplicationBrowserDriver, BrowserInspection, BrowserSubmission, BrowserSubmitInput, HumanContinuation,
  PagePlan, WaitingSignal, WorkflowInput, WorkflowProgress, WorkflowResult,
} from "./contracts.js";
import { PortalEgressProxy } from "./egress-proxy.js";
import { activeCaptcha, captchaStatus, fingerprint } from "./form.js";
import { pageEngineInstaller, pageEngineSource } from "./page-engine.js";
import { ordinaryValues, portalReceipts, scanPortal, type PortalBinding, type PortalForm, type PortalScan } from "./portal-form.js";

type Options = { userDataDir: string; headless?: boolean; testOrigins?: string[]; maxHumanSessions?: number };
type Upload = { name: string; mimeType: string; buffer: Buffer; sha256: string };
type Waiting = NonNullable<WorkflowResult["waitingFor"]>;
type Engine = { ChairmanPage: {
  inspectAssistancePage(doc: Document, timing: object): Promise<AssistancePage>;
  fillAssistancePage(doc: Document, grant: AssistanceGrant, timing: object): Promise<AssistanceFillResult>;
} };
const MARK = /^(?:🔐 Solve CAPTCHA|✋ Needs you) · /u;
type Session = {
  id: string; page: Page; input: WorkflowInput; origin: string; jobKey: string; step: number;
  busy: boolean; waiting: boolean; abandoned: boolean; blocked?: string; stopped: boolean;
  finalStarted: boolean; boundaryCalled: boolean; manualIntent: boolean; manualControl: boolean; navigationPermit: boolean;
  requests: Set<Request>; receiptResponse: boolean; baseline: Set<string>; progress: WorkflowProgress;
  submitDestinations: Set<string>;
  navigationTargets: Set<string>; writeAttempts: Set<string>;
  approved: Map<string, string>; humanKeys: Set<string>; uploads: Map<string, string>;
  transmitted: boolean; advancedSignature?: string; noAi: boolean; upload?: Upload;
  waitingFor?: Waiting; clearedAt?: number; acknowledgedTerms?: boolean; thirdParty: Set<string>;
};
class Stop extends Error {
  constructor(readonly status: WorkflowResult["status"], message: string, readonly waitingFor?: Waiting) { super(message); }
}

/** CAPTCHA widgets load in frames from their provider; they may run inside an application tab, never as the tab itself. */
export function captchaProvider(url: URL): boolean {
  if (url.protocol !== "https:" || url.port || url.username || url.password) return false;
  const host = url.hostname.toLowerCase();
  if (["www.google.com", "www.gstatic.com", "www.recaptcha.net", "recaptcha.net"].includes(host)) return url.pathname.startsWith("/recaptcha/");
  return host === "hcaptcha.com" || host.endsWith(".hcaptcha.com") || host === "challenges.cloudflare.com" || host === "arkoselabs.com" || host.endsWith(".arkoselabs.com");
}
/** Registrable-domain approximation: jobs.example.com and api.example.com are the same site; example.co.uk keeps three labels. */
function site(host: string): string {
  const parts = host.toLowerCase().split(".");
  return parts.length > 2 && /^(?:co|com|org|net|ac|gov|edu)\.[a-z]{2}$/.test(parts.slice(-2).join(".")) ? parts.slice(-3).join(".") : parts.slice(-2).join(".");
}
function engineMessage(error: unknown): string {
  const text = error instanceof Error ? error.message : String(error);
  return (text.split("\n").find(line => /Error:/.test(line)) ?? text.split("\n")[0] ?? "").replace(/^.*?Error:\s*/, "").trim().slice(0, 300);
}

/** Career sites whose every application starts with your personal account sign-in (Apple ID); you apply there in your own Chrome. */
const ACCOUNT_ONLY = new Set(["jobs.apple.com"]);
/** Syntactic admission only; DNS is independently validated and pinned at the egress boundary. */
export function canUsePortal(url: string): boolean {
  try {
    const parsed = safeCareerUrl(url);
    return !/\.(?:example|alt|localdomain)$/.test(parsed.hostname) && !ACCOUNT_ONLY.has(parsed.hostname) &&
      ![...parsed.searchParams.keys()].some(key => /^(?:access_token|id_token|token|authorization|password|session|session_id|secret|api_key|apikey|code)$/i.test(key)) &&
      !parsed.pathname.split("/").some(part => /^(?:sign_in|sign_up|log_in|log_out|sign_out|register|registration)$/i.test(part));
  } catch { return false; }
}

export class PortalBrowser implements ApplicationBrowserDriver {
  static canUsePortal = canUsePortal;
  private context?: BrowserContext;
  private proxy?: PortalEgressProxy;
  private starting?: Promise<BrowserContext>;
  private stopping = false;
  private setup?: Page;
  private setupOrigin?: string;
  private readonly manualPages = new Set<Page>();
  private readonly sessions = new Map<string, Session>();
  private readonly results = new Map<string, WorkflowResult>();
  private readonly attempted = new Set<string>();
  private readonly pendingJobs = new Set<string>();
  private readonly testOrigins: Set<string>;
  private readonly limit: number;

  constructor(private readonly options: Options) {
    if (!options.userDataDir?.trim() || isNormalBrowserProfile(resolve(options.userDataDir))) throw new Error("A dedicated private data directory is required");
    this.limit = options.maxHumanSessions ?? 10;
    if (!Number.isInteger(this.limit) || this.limit < 1 || this.limit > 50) throw new Error("maxHumanSessions must be between 1 and 50");
    this.testOrigins = new Set((options.testOrigins ?? []).map(raw => {
      const url = new URL(raw);
      if (raw !== url.origin || !["http:", "https:"].includes(url.protocol) || url.username || url.password ||
        !["127.0.0.1", "localhost", "[::1]"].includes(url.hostname)) throw new Error("Test origins must be explicit loopback origins");
      return url.origin;
    }));
  }

  private url(raw: string, base?: string): URL {
    if (typeof raw !== "string" || raw.length > 2048 || /[\\\u0000-\u0020\u007f]/.test(raw) ||
      /%|(?:^|\/)\.{1,2}(?:\/|$)/.test(raw.split(/[?#]/)[0]!)) throw new Stop("unsupported", "Unsafe application destination");
    const url = new URL(raw || base!, base);
    if (url.username || url.password) throw new Stop("unsupported", "Credentials are not allowed in application URLs");
    if (this.testOrigins.has(url.origin)) return url;
    if (!canUsePortal(url.href)) throw new Stop("unsupported", "Use a public HTTPS company application, not an account or restricted website");
    return url;
  }
  private same(raw: string, session: Session, base = session.page.url()): boolean {
    try { return this.url(raw, base).origin === session.origin; } catch { return false; }
  }
  private publicUrl(session: Session): string {
    try { const url = new URL(session.page.url()); return `${url.origin}${url.pathname}`; } catch { return session.input.job.applyUrl.split(/[?#]/)[0]!; }
  }

  isRunning(): boolean { return !!this.context && !this.stopping; }
  async inspect(_job: Job): Promise<BrowserInspection> {
    return { status: "unsupported", reason: "Portal inspection is part of runWorkflow; use its live, authorized form snapshot rather than replaying a detached inspection" };
  }
  async submit(_input: BrowserSubmitInput): Promise<BrowserSubmission> {
    return { status: "unsupported", reason: "Generic portals require runWorkflow; detached inspect/submit replay is not supported" };
  }

  private async launch(): Promise<BrowserContext> {
    if (this.context && !this.stopping) return this.context;
    if (this.starting) return this.starting;
    if (this.stopping) throw new Stop("cancelled", "Browser was stopped");
    this.starting = (async () => {
      await mkdir(this.options.userDataDir, { recursive: true, mode: 0o700 });
      const parent = await realpath(this.options.userDataDir);
      if (isNormalBrowserProfile(parent)) throw new Error("Normal browser profiles are not allowed");
      // A fresh child profile cannot restore a tab or silently replay an old application.
      const profile = join(parent, `portal-${randomUUID()}`);
      await mkdir(profile, { mode: 0o700 });
      await chmod(profile, 0o700);
      const proxy = this.proxy = new PortalEgressProxy(this.testOrigins);
      const server = await proxy.start();
      let context: BrowserContext;
      try {
        context = await chromium.launchPersistentContext(profile, {
          ...getChromeLaunchOptions(), headless: this.options.headless ?? false, acceptDownloads: false,
          serviceWorkers: "block", proxy: { server, bypass: "<-loopback>" }, timeout: 30_000,
          args: ["--disable-quic", "--disable-background-networking", "--disable-component-update",
            "--force-webrtc-ip-handling-policy=disable_non_proxied_udp",
            "--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1"],
        });
      } catch (error) { await proxy.close(); throw error; }
      if (this.stopping) { await context.close(); await proxy.close(); throw new Stop("cancelled", "Browser was stopped"); }
      this.context = context;
      context.setDefaultTimeout(3000);
      context.setDefaultNavigationTimeout(15_000);
      await context.addInitScript("globalThis.__name ??= (fn) => fn;");
      await context.exposeBinding("__portalManualIntent", ({ page }) => {
        const session = [...this.sessions.values()].find(s => s.page === page);
        if (session?.waiting && !session.busy) session.manualIntent = true;
      });
      await context.addInitScript(() => {
        const mark = (event: Event) => {
          if (!event.isTrusted) return;
          const target = event.target as Element | null;
          const control = target?.closest("button,input[type=submit],[role=button]");
          const label = (control?.textContent || control?.getAttribute("value") || control?.getAttribute("aria-label") || "").trim();
          const final = /^(?:submit|submit application|submit your application|send application|apply now)$/i.test(label);
          if (final || event.type === "submit" && !(event as SubmitEvent).submitter?.textContent?.match(/^(?:next|continue|next step|save (?:&|and) continue)$/i)) {
            void (globalThis as unknown as { __portalManualIntent: () => Promise<void> }).__portalManualIntent();
          }
        };
        document.addEventListener("click", mark, true);
        document.addEventListener("submit", mark, true);
      });
      await context.route("**/*", route => this.route(route));
      await context.routeWebSocket("**/*", socket => {
        const s = [...this.sessions.values()].find(s => s.origin === new URL(socket.url()).origin.replace(/^ws/, "http"));
        if (s) s.blocked = "Live socket form requires manual review";
        socket.close();
      });
      for (const page of context.pages()) await page.close();
      context.on("page", page => { page.on("popup", popup => {
        const owner = [...this.sessions.values()].find(session => session.page === page);
        if (page === this.setup || this.manualPages.has(page) || owner?.manualControl) this.manualPages.add(popup);
        else void popup.close();
      }); });
      context.on("close", () => {
        if (this.context === context) this.context = undefined;
        for (const session of this.sessions.values()) {
          session.stopped = true;
          this.results.set(session.id, { status: session.finalStarted ? "submission_unknown" : "failed",
            reason: "Browser session was lost; no navigation or submission was replayed" });
        }
        this.sessions.clear();
        this.manualPages.clear();
        void proxy.close();
      });
      return context;
    })();
    try { return await this.starting; } finally { this.starting = undefined; }
  }

  private async route(route: Route): Promise<void> {
    try {
      const request = route.request(), page = request.frame().page(), raw = request.url(), url = new URL(raw);
      if (this.stopping) { await route.abort(); return; }
      const session = [...this.sessions.values()].find(s => s.page === page);
      const navigation = request.isNavigationRequest();
      const dynamic = !["GET", "HEAD", "OPTIONS"].includes(request.method()) || ["xhr", "fetch", "ping", "eventsource"].includes(request.resourceType());
      if (session && !session.stopped && !session.abandoned && captchaProvider(url) && !(navigation && request.frame() === page.mainFrame())) {
        // You solve the challenge in its own provider frame; no application data is sent there.
        await route.continue(); return;
      }
      const opener = session ? null : await page.opener();
      const manualOpener = opener && (opener === this.setup || this.manualPages.has(opener) || [...this.sessions.values()].some(s => s.page === opener && s.manualControl));
      if (page === this.setup || this.manualPages.has(page) || manualOpener || session?.waiting && session.manualControl && !session.busy) {
        if (!this.manualUrl(raw)) { await route.abort(); return; }
        if (!session) this.manualPages.add(page);
        if (session?.manualIntent && request.method() === "POST" && !session.finalStarted && url.origin === session.origin) await this.manualBoundary(session);
        if (session?.finalStarted && request.method() === "POST" && this.applicationPost(url, session)) session.requests.add(request);
        await route.continue();
        return;
      }
      if (!session && page !== this.setup) { await route.abort(); return; }
      if (session && (session.stopped || session.abandoned || this.stopping)) { await route.abort(); return; }
      const origin = session?.origin ?? this.setupOrigin;
      if (url.username || url.password || (!this.testOrigins.has(url.origin) && url.protocol !== "https:")) {
        if (session && (navigation || dynamic)) session.blocked = "Unsafe network destination was blocked";
        await route.abort(); return;
      }
      const sameSite = !navigation && !!session && !!origin && url.protocol === "https:" && !url.port && site(url.hostname) === site(new URL(origin).hostname);
      if ((navigation || dynamic) && url.origin !== origin && !sameSite) {
        if (session && !navigation) {
          // Third-party beacons (analytics, monitoring) are dropped, so nothing leaves for another site, and the run continues.
          if (session.thirdParty.size < 20) session.thirdParty.add(url.hostname);
          await route.abort(); return;
        }
        if (session) session.blocked = `Cross-origin application redirect or frame (${url.hostname}) requires manual review`;
        await route.abort(); return;
      }
      if (navigation && !(session ? this.same(raw, session) : this.url(raw).origin === origin)) {
        if (session) session.blocked = "Unsafe application navigation was blocked";
        await route.abort(); return;
      }
      if (navigation && session && request.frame() === page.mainFrame() && !session.navigationPermit &&
        !session.navigationTargets.has(raw.split("#")[0]!) && !(session.waiting && session.manualIntent)) {
        session.blocked = "Unexpected navigation outside an explicit application action was blocked";
        await route.abort(); return;
      }
      if (session && (dynamic || navigation)) {
        if (!await this.authorized(session)) { session.stopped = true; await route.abort(); return; }
        if (session.waiting && session.manualIntent && request.method() === "POST" && !session.finalStarted) {
          await this.manualBoundary(session);
        }
        if (session.finalStarted && request.method() === "POST" && this.applicationPost(url, session)) {
          session.requests.add(request);
        }
      }
      if (navigation || dynamic) {
        // Chromium's route.continue follows redirects internally. Inspect every Location first.
        const response = await route.fetch({ maxRedirects: 0, maxRetries: 0, timeout: 15_000 });
        const location = response.headers()["location"];
        if (response.status() >= 300 && response.status() < 400 && location) {
          const allowed = session ? this.same(location, session, raw) : this.url(location, raw).origin === origin;
          if (!allowed) {
            if (session) session.blocked = "Application redirect left the approved public origin";
            await route.abort(); return;
          }
          if (session && navigation) session.navigationTargets.add(new URL(location, raw).href.split("#")[0]!);
        }
        await route.fulfill({ response });
      } else {
        if (!dynamic && !["script", "stylesheet", "image", "font", "media", "manifest", "other"].includes(request.resourceType())) {
          await route.abort(); return;
        }
        await route.continue();
      }
    } catch { await route.abort().catch(() => undefined); }
  }

  private async authorized(s: Session): Promise<boolean> {
    if (s.stopped || s.abandoned || this.stopping || s.page.isClosed()) return false;
    try { return await s.input.checkAuthorization(); } catch { return false; }
  }
  private applicationPost(url: URL, session: Session): boolean {
    const related = url.origin === session.origin || url.protocol === "https:" && !url.port && site(url.hostname) === site(new URL(session.origin).hostname);
    return related && (session.submitDestinations.has(`${url.origin}${url.pathname}`)
      || (!/\/(?:analytics|telemetry|track|events?|metrics|logs?)(?:\/|$)/i.test(url.pathname)
        && /\/[^/]*(?:applications?|applicants?|candidates?|apply|submit|recruit(?:ing|ment)?|graphql|forms?)[^/]*(?:\/|$)/i.test(url.pathname)));
  }
  private async check(s: Session): Promise<void> {
    if (!await this.authorized(s)) throw new Stop(s.finalStarted ? "submission_unknown" : "cancelled", "Authorization was stopped, expired, or the live browser session was lost");
    if (s.blocked || !this.same(s.page.url(), s)) throw new Stop(s.finalStarted ? "submission_unknown" : "human_required", s.blocked ?? "Application scope changed; review manually");
  }
  private async progress(s: Session, phase: WorkflowProgress["phase"], message: string, missing: FormSnapshot["fields"] = s.progress.missingFields): Promise<void> {
    s.progress = { phase, message, step: s.step, url: this.publicUrl(s), filledFields: [...s.progress.filledFields], missingFields: missing };
    await s.input.onProgress(structuredClone(s.progress));
  }
  private async guard(s: Session, expected: PortalForm): Promise<PortalForm> {
    await this.check(s);
    const scan = await scanPortal(s.page);
    if (scan.policyIncomplete) throw new Stop("human_required", "Page exceeds the bounded policy scan; review manually before using any personal data");
    if (scan.noAi) { s.noAi = true; throw new Stop("human_required", "No-AI / own-words policy requires an entirely manual application; no generated material may be used"); }
    if (scan.closed) throw new Stop("unsupported", "This job is no longer accepting applications");
    if (!scan.form || scan.form.signature !== expected.signature) throw new Stop("human_required", "Form fields, choices, or destinations changed; review the existing tab");
    this.destinations(s, scan.form);
    await this.check(s);
    return scan.form;
  }
  private destinations(s: Session, form: PortalForm): void {
    if (form.destinations.some(url => !this.same(url, s)) || form.actions.some(a => !["", "_self"].includes(a.target))) {
      throw new Stop("human_required", "Form action or frame target is outside the approved same-origin application");
    }
    for (const raw of form.destinations) s.navigationTargets.add(this.url(raw, s.page.url()).href.split("#")[0]!);
  }
  private async transmit(s: Session, form: PortalForm, answers: Record<string, string>, human: boolean): Promise<PortalForm> {
    let current = await this.guard(s, form);
    await s.input.beforeTransmit(structuredClone(current.snapshot), { ...answers }, human);
    current = await this.guard(s, form);
    s.transmitted = true;
    return current;
  }

  private async file(s: Session, binding?: PortalBinding): Promise<Upload> {
    const accept = binding?.field.accept?.map(value => value.toLowerCase()) ?? [];
    const compatible = (name: string) => !accept.length || accept.includes(extname(name).toLowerCase())
      || accept.includes(extname(name).toLowerCase() === ".pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
      || accept.includes("*/*") || accept.includes("application/*");
    if (s.upload) {
      if (!compatible(s.upload.name)) throw new Stop("human_required", "A later upload requires a different format from the already selected resume; review manually.");
      return s.upload;
    }
    const candidates = [{ path: s.input.resumePath, filename: s.input.resumeFilename, sha256: s.input.resumeSha256 }, ...s.input.resumeAlternatives ?? []];
    if (candidates.length > 4) throw new Stop("failed", "Too many alternate resume artifacts.");
    const verified: Upload[] = [];
    for (const candidate of candidates) verified.push(await this.readUpload(candidate));
    const selected = verified.find(item => compatible(item.name));
    if (!selected) throw new Stop("human_required", "None of the approved resume formats is accepted by this form.");
    await this.check(s);
    await s.input.onResumeSelected?.(selected.sha256);
    return s.upload = selected;
  }
  private async readUpload(candidate: { path: string; filename: string; sha256: string }): Promise<Upload> {
    const { filename: name, sha256: hash, path: resumePath } = candidate;
    if (!name.trim() || basename(name) !== name || /[\u0000-\u001f\u007f/\\]/.test(name) || !/^[a-f0-9]{64}$/i.test(hash)) {
      throw new Stop("failed", "Approved resume filename or checksum is invalid");
    }
    const info = await stat(resumePath);
    if (!info.isFile() || !info.size || info.size > 20 * 1024 * 1024) throw new Stop("failed", "Resume must be a nonempty file of at most 20 MB");
    const buffer = await readFile(resumePath);
    if (!buffer.length || buffer.length > 20 * 1024 * 1024 ||
      createHash("sha256").update(buffer).digest("hex") !== hash.toLowerCase()) throw new Stop("failed", "Resume bytes do not match the approved SHA-256 or size limit");
    const pdf = extname(name).toLowerCase() === ".pdf" && buffer.subarray(0, 5).toString() === "%PDF-";
    const docx = extname(name).toLowerCase() === ".docx" && buffer.subarray(0, 4).equals(Buffer.from([80, 75, 3, 4])) &&
      buffer.includes(Buffer.from("[Content_Types].xml")) && buffer.includes(Buffer.from("word/document.xml"));
    if (!pdf && !docx) throw new Stop("failed", "Resume signature must match its PDF or DOCX filename");
    return { name, mimeType: pdf ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document", buffer, sha256: hash.toLowerCase() };
  }

  private async verifyUpload(s: Session, form: PortalForm, b: PortalBinding, file: Upload): Promise<boolean> {
    return form.root.locator(b.selector).evaluate(async (node, expected) => {
      const input = node as HTMLInputElement, files = input.files;
      if (!files || files.length !== 1) return false;
      const f = files[0]!;
      const hash = [...new Uint8Array(await crypto.subtle.digest("SHA-256", await f.arrayBuffer()))].map(n => n.toString(16).padStart(2, "0")).join("");
      const rect = input.getBoundingClientRect(), style = getComputedStyle(input);
      const nativeVisible = rect.width > 1 && rect.height > 1 && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
      const wrapper = input.closest(".file-upload,.field-wrapper,.field,.ashby-application-form-field-entry") ?? input.parentElement;
      const ui = nativeVisible || !!wrapper && [...wrapper.querySelectorAll("*")].some(e =>
        !!e.getClientRects().length && e.childElementCount === 0 && e.textContent?.trim() === expected.name);
      return f.name === expected.name && f.type === expected.mime && f.size === expected.size && hash === expected.hash && ui &&
        !wrapper?.querySelector('[aria-invalid=true],[aria-busy=true],[role=progressbar],.error,.field-error');
    }, { name: file.name, mime: file.mimeType, size: file.buffer.length, hash: file.sha256 });
  }

  private valueMatches(b: PortalBinding, value: string, answer: string): boolean {
    return value === answer || b.kind === "checkbox" && answer === "false" && value === "" ||
      b.kind === "combobox" && value === b.field.optionLabels?.[answer];
  }
  private permitted(b: PortalBinding, answer: unknown): answer is string {
    return !b.manual && !b.sensitive && typeof answer === "string" && answer.length <= 8000 &&
      !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(answer) &&
      (!["select", "radio", "combobox", "checkbox"].includes(b.kind) || b.field.options.includes(answer));
  }
  private async fill(s: Session, form: PortalForm, b: PortalBinding, answer: string, human: boolean): Promise<void> {
    await this.transmit(s, form, { [b.field.key]: answer }, human);
    s.writeAttempts.add(`${s.step}:${b.field.key}`);
    const control = form.root.locator(b.selector);
    if (b.kind === "select") await control.selectOption(answer);
    else if (b.kind === "radio") {
      const options = await control.elementHandles();
      const chosen = [];
      for (const option of options) if (await option.getAttribute("value") === answer) chosen.push(option);
      if (chosen.length !== 1) throw new Stop("human_required", "Radio choice is ambiguous");
      await chosen[0]!.check();
    } else if (b.kind === "checkbox") await control.setChecked(answer === "true");
    else if (b.kind === "combobox") {
      await control.click();
      const id = await control.getAttribute("aria-controls") ?? await control.getAttribute("aria-owns");
      const lists = s.page.locator('[role=listbox]').filter({ visible: true });
      let list = lists;
      if (id) list = s.page.locator(`[id=${JSON.stringify(id)}][role=listbox]`);
      if (await list.count() !== 1) throw new Stop("human_required", "Combobox list is not uniquely attributable");
      const choices = list.locator('[role=option]:not([aria-disabled=true])');
      const current = await choices.evaluateAll(nodes => nodes.map(e => ({
        value: e.getAttribute("data-value") ?? e.getAttribute("value") ?? e.textContent?.replace(/\s+/g, " ").trim(),
        label: e.textContent?.replace(/\s+/g, " ").trim(),
      })));
      if (JSON.stringify(current.map(o => o.value)) !== JSON.stringify(b.field.options)) throw new Stop("human_required", "Combobox options changed; select manually");
      const index = current.findIndex(o => o.value === answer);
      if (index < 0 || current.filter(o => o.value === answer).length !== 1) throw new Stop("human_required", "No unique exact combobox choice");
      await this.transmit(s, form, { [b.field.key]: answer }, human);
      await choices.nth(index).click();
    } else await control.fill(answer);
    await this.transmit(s, form, { [b.field.key]: answer }, human);
    if (b.kind === "text") await control.blur();
    await this.guard(s, form);
    if (!this.valueMatches(b, (await ordinaryValues(form))[b.field.key] ?? "", answer)) {
      throw new Stop("human_required", "A control did not retain the exact approved answer; inspect the existing tab");
    }
    s.approved.set(`${s.step}:${b.field.key}`, answer);
    if (human) s.humanKeys.add(`${s.step}:${b.field.key}`);
    if (!s.progress.filledFields.includes(b.field.label)) s.progress.filledFields.push(b.field.label);
  }

  async runWorkflow(input: WorkflowInput): Promise<WorkflowResult> {
    let s: Session | undefined;
    try {
      const target = this.url(input.job.applyUrl), key = `${target.origin}${target.pathname}${target.search}`;
      if (this.attempted.has(key)) return { status: "submission_unknown", reason: "A final submission was already attempted for this application; verify manually, never retry" };
      if (this.pendingJobs.has(key) || [...this.sessions.values()].some(s => s.jobKey === key)) return { status: "failed", reason: "This application already has a live workflow; resume that session instead" };
      if (this.sessions.size + this.pendingJobs.size >= this.limit) return { status: "failed", reason: `Human-review queue is full (${this.limit}); resume or abandon a live session first` };
      if (!await input.checkAuthorization()) return { status: "cancelled", reason: "Authorization was stopped or expired" };
      if (input.job.status === "closed" || input.job.expiresAt && Date.parse(input.job.expiresAt) <= Date.now()) return { status: "unsupported", reason: "Job is closed or expired" };
      if (input.job.aiPolicy === "prohibited" || hasNoAiRestriction(`${input.job.title} ${input.job.description}`)) return { status: "unsupported", reason: "Employer no-AI / own-words policy requires a fully manual application" };
      const context = await this.launch();
      // Reserve synchronously after launch; concurrent starts may have filled the queue.
      if (this.sessions.size + this.pendingJobs.size >= this.limit || this.pendingJobs.has(key) || [...this.sessions.values()].some(s => s.jobKey === key)) return { status: "failed", reason: "Live application queue is full or this application is already open" };
      this.pendingJobs.add(key);
      const id = randomUUID();
      let page: Page;
      const viewing = await this.viewingPage(context);
      try { page = await context.newPage(); } finally { this.pendingJobs.delete(key); }
      // A new application tab must not pull you away from the CAPTCHA you are solving.
      if (viewing && !viewing.isClosed()) await viewing.bringToFront().catch(() => undefined);
      s = {
        id, page, input, jobKey: key, origin: target.origin, step: 1, busy: true, waiting: false, abandoned: false,
        stopped: false, finalStarted: false, boundaryCalled: false, manualIntent: false, manualControl: false, navigationPermit: true,
        requests: new Set(), receiptResponse: false, baseline: new Set(), submitDestinations: new Set(),
        navigationTargets: new Set([target.href.split("#")[0]!]), writeAttempts: new Set(), approved: new Map(), humanKeys: new Set(),
        uploads: new Map(), transmitted: false, noAi: false, thirdParty: new Set(),
        progress: { phase: "navigating", message: "Opening public application", step: 1, url: key, filledFields: [], missingFields: [] },
      };
      this.sessions.set(id, s);
      const session = s;
      page.on("request", request => {
        const url = new URL(request.url());
        if (session.finalStarted && request.method() === "POST" && this.applicationPost(url, session)) session.requests.add(request);
      });
      page.on("response", response => {
        if (response.status() === 429) session.blocked = "Portal rate limit reached; do not retry automatically";
        if (session.requests.has(response.request()) && response.status() >= 200 && response.status() < 400) session.receiptResponse = true;
      });
      page.on("close", () => {
        session.stopped = true;
        if (this.sessions.has(id)) {
          this.results.set(id, { status: session.finalStarted ? "submission_unknown" : "failed", reason: "Live application tab was closed; no data was replayed" });
          this.sessions.delete(id);
        }
      });
      await this.progress(s, "navigating", "Opening the approved public application");
      await this.checkInitial(s);
      try { await page.goto(target.href, { waitUntil: "domcontentloaded" }); }
      catch { throw new Stop(s.blocked ? "human_required" : "failed", s.blocked ?? "Public application could not load safely; no navigation retry was made"); }
      s.navigationPermit = false;
      s.baseline = new Set(await portalReceipts(page));
      return await this.drive(s);
    } catch (error) {
      if (s) return await this.handle(s, error);
      return { status: error instanceof Stop ? error.status : "failed", reason: error instanceof Stop ? error.message : "Portal could not start safely" };
    } finally { if (s) s.busy = false; }
  }
  private async checkInitial(s: Session): Promise<void> {
    if (!await this.authorized(s)) throw new Stop("cancelled", "Authorization was stopped or expired");
  }

  private async drive(s: Session, continuation?: HumanContinuation): Promise<WorkflowResult> {
    let human = continuation;
    for (; s.step <= 10;) {
      await this.check(s);
      await this.progress(s, "inspecting", "Checking this application's visible questions");
      await this.check(s);
      let scan = await this.settle(s);
      if (scan.policyIncomplete) throw new Stop("human_required", "Page exceeds the bounded policy scan; review manually before using any personal data");
      if (scan.noAi || s.noAi) {
        s.noAi = true;
        throw new Stop("human_required", "Whole-page no-AI / own-words policy prohibits generated materials; complete this application entirely manually");
      }
      if (scan.closed) throw new Stop("unsupported", "Job is no longer accepting applications");
      if (!scan.form && !scan.auth && !scan.captcha && scan.applyLinks.length === 1 && !s.transmitted) {
        const link = scan.applyLinks[0]!;
        if (!["", "_self"].includes(link.target) || !this.same(link.url, s)) throw new Stop("human_required", "Apply link leaves the approved origin; open it manually");
        const destination = this.url(link.url, s.page.url()).href;
        await this.progress(s, "navigating", "Following the single same-origin Apply link");
        await this.check(s);
        s.navigationPermit = true;
        try { await s.page.goto(destination, { waitUntil: "domcontentloaded" }); }
        finally { s.navigationPermit = false; }
        scan = await this.settle(s);
        if (scan.policyIncomplete) throw new Stop("human_required", "Application policy scan is incomplete; manual review is required");
        if (scan.noAi) { s.noAi = true; throw new Stop("human_required", "Application requires human-authored / no-AI material; no generated material was uploaded"); }
      }
      const form = scan.form;
      if (!form) throw new Stop("human_required", scan.auth ? "Sign-in requires direct human handling" :
        scan.captcha ? "Solve the CAPTCHA in this tab; Chairman continues on its own once it is solved" : "No single clear application form is available; review the existing tab",
        scan.captcha && !scan.auth ? "captcha" : "answers");
      this.destinations(s, form);
      if (s.advancedSignature === form.signature) throw new Stop("human_required", "The previous Next action did not advance; inspect existing state rather than repeating it");
      if (this.assistedPage(s)) {
        const outcome = await this.assisted(s, human);
        if (outcome === "next") { human = undefined; continue; }
        return outcome;
      }
      const overrides: Record<string, string> = { ...(human?.answers ?? {}) };
      const current = await ordinaryValues(form);
      if (human?.useCurrentValues) {
        for (const b of form.bindings) {
          const value = current[b.field.key];
          if (value && b.kind !== "file" && !b.manual && !b.sensitive) overrides[b.field.key] = value;
        }
      }
      const requiredLegal = form.bindings.filter(binding => binding.legal && binding.field.required);
      const legalReviewed = Boolean(human?.useCurrentValues && !scan.implicitLegal && requiredLegal.length
        && requiredLegal.every(binding => binding.kind === "checkbox" && !binding.manual && current[binding.field.key] === "true"));
      const answerSnapshot = structuredClone(form.snapshot);
      if (legalReviewed) {
        answerSnapshot.fields = answerSnapshot.fields.filter(field => !requiredLegal.some(binding => binding.field.key === field.key));
        answerSnapshot.hasLegal = false;
        answerSnapshot.fingerprint = createHash("sha256").update(JSON.stringify({
          url: answerSnapshot.url, fields: answerSnapshot.fields, hasCaptcha: answerSnapshot.hasCaptcha,
          hasLegal: answerSnapshot.hasLegal, unsupported: answerSnapshot.unsupported
        })).digest("hex");
      }
      const plan = await s.input.resolveAnswers(answerSnapshot, human ? overrides : undefined);
      await this.guard(s, form);
      const missing = new Map<string, FormSnapshot["fields"][number]>(), issues: string[] = [];
      for (const b of form.bindings) {
        if (b.kind === "file") continue;
        const key = b.field.key, stepKey = `${s.step}:${key}`, value = current[key] ?? "";
        let answer = Object.hasOwn(plan.answers, key) ? plan.answers[key] : s.approved.get(stepKey);
        const explicitlyCurrent = !!human?.useCurrentValues && value !== "";
        const explicitlyAnswered = !!human && Object.hasOwn(human.answers, key);
        if (b.manual || b.sensitive || b.kind === "checkbox" && b.legal && b.field.required) {
          if (b.kind === "checkbox" && b.legal && explicitlyCurrent && value === "true" && !b.manual) {
            await this.transmit(s, form, { [key]: value }, true);
            s.approved.set(stepKey, value); s.humanKeys.add(stepKey);
          } else if (b.field.required || b.manual) { missing.set(key, b.field); issues.push("Required declarations, credentials, and assessments are human-operated"); }
          continue;
        }
        if (explicitlyCurrent) {
          // Explicit current-value approval is not permission to solve an assessment or write a secret.
          if (this.permitted(b, value)) {
            await this.transmit(s, form, { [key]: value }, true);
            s.approved.set(stepKey, value); s.humanKeys.add(stepKey);
            continue;
          }
        }
        if (value && !(answer !== undefined && this.valueMatches(b, value, answer)) && !explicitlyAnswered) {
          missing.set(key, b.field); issues.push("Existing different values were preserved; confirm current values or provide an explicit replacement");
          continue;
        }
        if (answer === undefined || !this.permitted(b, answer) || b.legal && !Object.hasOwn(plan.answers, key)) {
          if (b.field.required || value) missing.set(key, b.field);
          continue;
        }
        if (this.valueMatches(b, value, answer)) {
          s.approved.set(stepKey, answer);
          continue;
        }
        if (s.writeAttempts.has(stepKey) && !explicitlyAnswered) {
          missing.set(key, b.field); issues.push("A previously transmitted answer was not retained; provide an explicit answer rather than retrying it"); continue;
        }
        await this.progress(s, "prefilling", `Filling ${b.field.label}`, [...missing.values()]);
        await this.fill(s, form, b, answer, explicitlyAnswered || s.humanKeys.has(stepKey));
      }
      const resumes = form.bindings.filter(b => b.kind === "file" && !b.manual && /\b(?:resume|cv|curriculum vitae)\b/i.test(b.field.label));
      for (const b of form.bindings.filter(b => b.kind === "file")) {
        const fileCount = await form.root.locator(b.selector).evaluate(e => (e as HTMLInputElement).files?.length ?? 0);
        if (resumes.length !== 1 || b !== resumes[0]) {
          if (b.field.required || fileCount) missing.set(b.field.key, b.field);
          continue;
        }
        const upload = await this.file(s, b);
        if (b.field.accept?.length && !b.field.accept.some(a => [extname(upload.name).toLowerCase(), upload.mimeType, "*/*", "application/*"].includes(a))) {
          missing.set(b.field.key, b.field); issues.push("Resume filename / MIME type is not accepted by this upload"); continue;
        }
        const uploadKey = `${s.step}:${b.field.key}`;
        if (fileCount) {
          if (!await this.verifyUpload(s, form, b, upload)) { missing.set(b.field.key, b.field); issues.push("An existing attachment is different or its acceptance is ambiguous"); }
          else s.uploads.set(uploadKey, upload.sha256);
          continue;
        }
        if (s.uploads.has(uploadKey)) { missing.set(b.field.key, b.field); issues.push("Previously transmitted attachment disappeared; verify manually rather than uploading twice"); continue; }
        await this.progress(s, "uploading", "Attaching the exact approved resume", [...missing.values()]);
        await this.transmit(s, form, { [b.field.key]: upload.name }, false);
        // Mark before the write: an ambiguous uploader must never cause a duplicate upload on resume.
        s.uploads.set(uploadKey, upload.sha256);
        await form.root.locator(b.selector).setInputFiles({ name: upload.name, mimeType: upload.mimeType, buffer: upload.buffer });
        await s.page.waitForTimeout(100);
        await this.guard(s, form);
        if (!await this.verifyUpload(s, form, b, upload)) {
          missing.set(b.field.key, b.field); issues.push("Resume acceptance could not be verified; inspect the existing attachment");
        } else if (!s.progress.filledFields.includes(b.field.label)) s.progress.filledFields.push(b.field.label);
      }
      for (const label of plan.missing) {
        const b = form.bindings.find(b => b.field.key === label || b.field.label === label);
        if (b && !s.approved.has(`${s.step}:${b.field.key}`) && !s.uploads.has(`${s.step}:${b.field.key}`)) missing.set(b.field.key, b.field);
      }
      const active = await scanPortal(s.page);
      if (active.noAi) { s.noAi = true; throw new Stop("human_required", "A no-AI / own-words policy appeared; stop and complete manually"); }
      const remainingBlockers = plan.blockers.filter(blocker => !(/^(?:Required )?(?:legal|consent|terms|declaration)\b/i.test(blocker) && human?.useCurrentValues && !missing.size &&
        form.snapshot.hasLegal && !scan.implicitLegal && form.bindings.filter(b => b.legal && b.field.required).every(b =>
          b.kind === "checkbox" && s.humanKeys.has(`${s.step}:${b.field.key}`))));
      if (missing.size || remainingBlockers.length || form.snapshot.unsupported.length || active.auth || active.captcha ||
        active.assessment || active.complex || active.frame || active.implicitLegal) {
        s.progress.missingFields = [...missing.values()];
        const captchaOnly = active.captcha && !missing.size && !form.snapshot.unsupported.length && !active.auth && !active.assessment && !active.complex
          && !active.frame && !active.implicitLegal && remainingBlockers.every(blocker => /captcha/i.test(blocker));
        throw new Stop("human_required", active.auth ? "Sign-in requires direct human handling; known safe fields were retained" :
          captchaOnly ? "Solve the CAPTCHA in this tab; Chairman continues and submits on its own once it is solved" :
          active.captcha ? "CAPTCHA requires direct human handling; known safe fields and resume were retained" :
          active.assessment ? "Assessment must be completed by you, not the assistant" :
          active.frame ? "Embedded application frame requires manual review" :
          issues[0] ?? "Review required questions, declarations, or unsupported controls in the prefilled live tab", captchaOnly ? "captcha" : "answers");
      }
      await this.guard(s, form);
      const actions = form.actions;
      if (actions.length !== 1) throw new Stop("human_required", "Next / Submit action is missing or ambiguous; review manually");
      const action = actions[0]!;
      const allAnswers = await this.approvedValues(s, form);
      if (action.kind === "next") {
        if (s.step >= 10 || /(?:^|\/)(?:submit|complete|confirmation)(?:\/|$)/i.test(this.url(action.destination, s.page.url()).pathname)) {
          throw new Stop("human_required", "Next may finalize the application or exceeds the 10-step limit; review manually");
        }
        await this.progress(s, "advancing", "Saving this step before the explicit Next action", []);
        await this.transmit(s, form, allAnswers, [...s.humanKeys].some(k => k.startsWith(`${s.step}:`)));
        s.advancedSignature = form.signature;
        s.navigationPermit = true;
        s.step++;
        try {
          await form.root.locator(action.selector).click({ noWaitAfter: true });
          const deadline = Date.now() + 5000;
          do {
            await s.page.waitForTimeout(100);
            await this.check(s);
            const next = await scanPortal(s.page);
            if (next.form && next.form.signature !== form.signature) break;
          } while (Date.now() < deadline);
        } finally { s.navigationPermit = false; }
        human = undefined;
        continue;
      }
      await this.progress(s, "submitting", "Recording the final submission boundary", []);
      await this.transmit(s, form, allAnswers, [...s.humanKeys].some(k => k.startsWith(`${s.step}:`)));
      await this.approvedValues(s, form);
      if ((await portalReceipts(s.page)).some(receipt => !s.baseline.has(receipt))) throw new Stop("human_required", "A receipt appeared before Submit; verify it manually rather than submitting again");
      await this.guard(s, form);
      s.submitDestinations = new Set(form.destinations.map(raw => {
        const url = this.url(raw, s.page.url()); return `${url.origin}${url.pathname}`;
      }));
      await this.finalBoundary(s);
      // Once the durable boundary is reached, any uncertainty remains unknown, never a retry.
      await this.guard(s, form);
      await form.root.locator(action.selector).click({ noWaitAfter: true });
      await this.progress(s, "confirming", "Checking the new receipt against the observed submission");
      return await this.confirm(s, true);
    }
    throw new Stop("human_required", "Application exceeds the 10-step automation limit");
  }

  /**
   * One application step with the extension's page engine: plan (saved answers, remembered answers, validated AI mapping),
   * fill, re-plan for questions that appeared, then Next or the single final Submit. Anything unanswered parks the tab.
   */
  private async assisted(s: Session, human?: HumanContinuation): Promise<WorkflowResult | "next"> {
    let page = await this.inspectAssisted(s);
    if (!page.snapshot.fields.length) throw new Stop("human_required", "No application questions were detected on this page; review the tab", "answers");
    const errors = new Map<string, string>(), explicit = human?.answers ?? {}, done = new Set<string>();
    for (let pass = 0; pass < 4; pass++) {
      const plan = await s.input.planPage!(page);
      await this.check(s);
      const fields = new Map(page.snapshot.fields.map(field => [field.key, field]));
      const answers: Record<string, string> = {};
      let humanSupplied = false;
      for (const [key, value] of Object.entries(plan.fill)) if (!s.writeAttempts.has(`${s.step}:${key}`) && !errors.has(key)) answers[key] = value;
      for (const [key, raw] of Object.entries(explicit)) {
        const field = fields.get(key);
        if (!field || field.type === "file" || page.occupied.includes(key) || s.writeAttempts.has(`${s.step}:${key}`)) continue;
        const value = field.options.length && !field.options.includes(raw) ? Object.entries(field.optionLabels ?? {}).find(([, label]) => label === raw)?.[0] : raw;
        if (value === undefined) { errors.set(key, "Your answer is not one of this question's choices."); continue; }
        answers[key] = value; humanSupplied = true;
      }
      const resumeKey = plan.resumeKey && !s.uploads.has(`${s.step}:${plan.resumeKey}`) && fields.has(plan.resumeKey) ? plan.resumeKey : undefined;
      const upload = resumeKey ? await this.file(s, { field: fields.get(resumeKey)! } as PortalBinding) : undefined;
      if (!Object.keys(answers).length && !upload) break;
      await this.check(s);
      await s.input.beforeTransmit(this.recordSnapshot(page), { ...answers, ...(upload ? { [resumeKey!]: upload.name } : {}) }, humanSupplied);
      s.transmitted = true;
      for (const key of Object.keys(answers)) s.writeAttempts.add(`${s.step}:${key}`);
      // Marked before the write: an ambiguous uploader must never cause a duplicate upload.
      if (upload) s.uploads.set(`${s.step}:${resumeKey}`, upload.sha256);
      await this.progress(s, upload ? "uploading" : "prefilling", `Filling ${Object.keys(answers).length} answer${Object.keys(answers).length === 1 ? "" : "s"}${upload ? " and attaching the approved resume" : ""}`);
      const result = await this.fillAssisted(s, { id: randomUUID(), recordId: `runner-${s.id}`, url: s.page.url(), pageFingerprint: page.fingerprint,
        expiresAt: Date.now() + 90_000, fields: answers,
        ...(upload ? { resume: { key: resumeKey!, filename: upload.name, mime: upload.mimeType, base64: upload.buffer.toString("base64"), sha256: upload.sha256 } } : {}) });
      for (const key of result.filled) {
        done.add(key);
        const label = fields.get(key)?.label;
        if (label && !s.progress.filledFields.includes(label)) s.progress.filledFields.push(label);
      }
      for (const error of result.errors) errors.set(error.key, error.message);
      // A question that changed or moved was never written; the next pass plans it again.
      for (const skipped of result.skipped) s.writeAttempts.delete(`${s.step}:${skipped.key}`);
      const handled = Object.keys(answers).filter(key => plan.sources[key] === "acknowledgement" && result.filled.includes(key)).map(key => fields.get(key)!.label);
      if (handled.length) await s.input.onAcknowledge?.(handled);
      await this.check(s);
      page = await this.inspectAssisted(s);
    }
    const plan: PagePlan = await s.input.planPage!(page);
    await this.check(s);
    const fields = new Map(page.snapshot.fields.map(field => [field.key, field]));
    const missing = new Map<string, FormField>();
    for (const need of plan.needs) if (!page.occupied.includes(need.key) && fields.has(need.key)) missing.set(need.key, fields.get(need.key)!);
    // An unchecked box reads as empty, so a verified "false" is the only planned answer that may still look unanswered.
    for (const [key, value] of Object.entries(plan.fill)) if (fields.has(key) && !(value === "false" && done.has(key) && fields.get(key)!.type === "checkbox")) missing.set(key, fields.get(key)!);
    for (const key of errors.keys()) if (fields.has(key)) missing.set(key, fields.get(key)!);
    if (plan.resumeKey && fields.has(plan.resumeKey)) missing.set(plan.resumeKey, fields.get(plan.resumeKey)!);
    const active = await scanPortal(s.page);
    if (active.noAi) { s.noAi = true; throw new Stop("human_required", "A no-AI / own-words policy appeared; stop and complete manually"); }
    if (active.closed) throw new Stop("unsupported", "Job is no longer accepting applications");
    const hard = active.auth ? "Sign-in requires direct human handling; filled answers were kept" : active.assessment ? "Assessment must be completed by you, not the assistant"
      : active.frame ? "Embedded application frame requires manual review" : active.policyIncomplete ? "Page exceeds the bounded policy scan; review manually" : undefined;
    if (hard) { s.progress.missingFields = [...missing.values()]; throw new Stop("human_required", hard, "answers"); }
    const current = active.form;
    const invalid = current ? await this.invalidControls(current) : [];
    const manualOnly = !human?.useCurrentValues ? page.snapshot.unsupported : [];
    const terms = active.implicitLegal && !human?.useCurrentValues;
    if (terms && s.input.acceptAcknowledgements && !s.acknowledgedTerms) {
      s.acknowledgedTerms = true;
      await s.input.onAcknowledge?.(["Submission terms stated on the page (\"by submitting, you agree…\")"]);
    }
    const captcha = await captchaStatus(s.page);
    const captchaOpen = captcha.active || captcha.widget && !captcha.solved;
    if (missing.size || manualOnly.length || invalid.length || terms && !s.input.acceptAcknowledgements) {
      s.progress.missingFields = [...missing.values()];
      const labels = [...missing.values()].map(field => field.label);
      throw new Stop("human_required", labels.length ? `Answer ${labels.length === 1 ? "this question" : `these ${labels.length} questions`} (Chairman has no saved answer${errors.size ? " or the site rejected one" : ""}): ${labels.slice(0, 4).join("; ")}${labels.length > 4 ? "; …" : ""}${captchaOpen ? ". Then solve the CAPTCHA." : ""}`
        : manualOnly.length ? `Answer these yourself in the tab, then continue: ${manualOnly.slice(0, 3).join("; ")}`
          : invalid.length ? `The site still marks these answers invalid: ${invalid.slice(0, 4).join("; ")}`
            : "The form says submitting means you agree to its terms. Review them, or turn on Profile → Accept required acknowledgements.", "answers");
    }
    s.progress.missingFields = [];
    if (captchaOpen) throw new Stop("human_required", "Solve the CAPTCHA in this tab. Chairman continues and submits on its own once it is solved.", "captcha");
    if (!current) throw new Stop("human_required", "The application form changed while filling; review the tab", "answers");
    this.destinations(s, current);
    if (current.actions.length !== 1) throw new Stop("human_required", "Next / Submit action is missing or ambiguous; review manually", "answers");
    const action = current.actions[0]!;
    if (action.kind === "next") {
      if (s.step >= 10 || /(?:^|\/)(?:submit|complete|confirmation)(?:\/|$)/i.test(this.url(action.destination, s.page.url()).pathname))
        throw new Stop("human_required", "Next may finalize the application or exceeds the 10-step limit; review manually", "answers");
      await this.progress(s, "advancing", "Continuing to the next application step", []);
      await this.check(s);
      s.advancedSignature = current.signature;
      s.navigationPermit = true;
      s.step++;
      try {
        await current.root.locator(action.selector).click({ noWaitAfter: true });
        const deadline = Date.now() + 5000;
        do {
          await s.page.waitForTimeout(100);
          await this.check(s);
          const next = await scanPortal(s.page);
          if (next.form && next.form.signature !== current.signature) break;
        } while (Date.now() < deadline);
      } finally { s.navigationPermit = false; }
      return "next";
    }
    await this.progress(s, "submitting", "Recording the final submission boundary", []);
    if ((await portalReceipts(s.page)).some(receipt => !s.baseline.has(receipt))) throw new Stop("human_required", "A receipt appeared before Submit; verify it manually rather than submitting again", "answers");
    const final = await this.inspectAssisted(s);
    if (final.fingerprint !== page.fingerprint) throw new Stop("human_required", "The form changed right before Submit; review the tab", "answers");
    s.submitDestinations = new Set(current.destinations.map(raw => {
      const url = this.url(raw, s.page.url()); return `${url.origin}${url.pathname}`;
    }));
    await this.finalBoundary(s);
    // Once the durable boundary is reached, any uncertainty remains unknown, never a retry.
    await this.check(s);
    await current.root.locator(action.selector).click({ noWaitAfter: true });
    await this.progress(s, "confirming", "Checking the new receipt against the observed submission");
    return await this.confirm(s, true);
  }
  /** The page engine runs where the extension may run: public HTTPS pages, or the controlled loopback fixture. */
  private assistedPage(s: Session): boolean {
    if (!s.input.planPage) return false;
    try { const url = new URL(s.page.url()); return url.protocol === "https:" || url.hostname === "127.0.0.1" && url.pathname === "/fixture/application"; }
    catch { return false; }
  }
  private async inspectAssisted(s: Session): Promise<AssistancePage> {
    await this.check(s);
    const bundle = await pageEngineSource();
    try {
      await s.page.evaluate(pageEngineInstaller(bundle));
      return await s.page.evaluate(timing => (globalThis as unknown as Engine).ChairmanPage.inspectAssistancePage(document, timing), { quietMs: 250, maxWaitMs: 2500 });
    } catch (error) {
      const message = engineMessage(error);
      if (/restricts AI/i.test(message)) s.noAi = true;
      throw new Stop("human_required", /credential|restricts AI|manual-only|inspection limit|Sign in/i.test(message) ? message : `The page engine could not read this form (${message || "unknown error"}); review it in the tab`, "answers");
    }
  }
  private async fillAssisted(s: Session, grant: AssistanceGrant): Promise<AssistanceFillResult> {
    try {
      return await s.page.evaluate(([value, timing]) => (globalThis as unknown as Engine).ChairmanPage.fillAssistancePage(document, value, timing),
        [grant, { quietMs: 150, maxWaitMs: 1500, stepQuietMs: 80, finalQuietMs: 300, finalMaxMs: 2500 }] as const);
    } catch (error) { throw new Stop("human_required", `Filling stopped: ${engineMessage(error) || "the page engine failed"}`, "answers"); }
  }
  /** Workflow records use the runner's structural fingerprint over the scanned questions. */
  private recordSnapshot(page: AssistancePage): FormSnapshot {
    const base = {
      url: page.snapshot.url.split(/[?#]/)[0]!,
      fields: page.snapshot.fields.map(f => ({ key: f.key, label: f.label, type: f.type, required: f.required, options: f.options,
        ...(f.optionLabels ? { optionLabels: f.optionLabels } : {}), ...(f.accept ? { accept: f.accept } : {}) })),
      hasCaptcha: page.snapshot.hasCaptcha, hasLegal: page.snapshot.hasLegal, unsupported: page.snapshot.unsupported,
    };
    return { ...base, fingerprint: fingerprint(base) };
  }
  /** Native constraint validation, read without dispatching invalid events. */
  private async invalidControls(form: PortalForm): Promise<string[]> {
    return form.root.evaluate(root => {
      const clean = (value: string | null | undefined) => (value ?? "").replace(/\s+/g, " ").trim().slice(0, 120);
      const out: string[] = [];
      for (const e of root.querySelectorAll<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>("input,select,textarea")) {
        if (e.disabled || ["hidden", "submit", "button", "reset", "image"].includes(e.type) || !e.willValidate || e.validity.valid) continue;
        const wrapper = e.closest("fieldset,.field,.field-wrapper,.ashby-application-form-field-entry") ?? e.parentElement;
        const box = (wrapper ?? e).getBoundingClientRect();
        if (box.width < 2 || box.height < 2 || getComputedStyle(wrapper ?? e).visibility === "hidden") continue;
        const group = ["radio", "checkbox"].includes(e.type) ? wrapper?.querySelector("legend,.field-label,.ashby-application-form-question-title")?.textContent : "";
        out.push(clean(group || ("labels" in e ? e.labels?.[0]?.textContent : "") || e.getAttribute("aria-label") || e.name) || "an unlabeled field");
      }
      return [...new Set(out)].slice(0, 10);
    }).catch(() => []);
  }
  /** Tab titles show which of many parked tabs need you, and for what. */
  private async mark(s: Session): Promise<void> {
    const prefix = s.waitingFor === "answers" ? "✋ Needs you · " : "🔐 Solve CAPTCHA · ";
    await s.page.evaluate(([value, pattern]) => { document.title = value + document.title.replace(new RegExp(pattern, "u"), ""); }, [prefix, MARK.source] as const).catch(() => undefined);
  }
  private async unmark(s: Session): Promise<void> {
    if (s.page.isClosed()) return;
    await s.page.evaluate(pattern => { document.title = document.title.replace(new RegExp(pattern, "u"), ""); }, MARK.source).catch(() => undefined);
  }
  private async viewingPage(context: BrowserContext): Promise<Page | undefined> {
    if (this.options.headless) return undefined;
    const pages = context.pages().filter(page => !page.isClosed());
    const visible = await Promise.all(pages.map(page => Promise.race([
      page.evaluate(() => document.visibilityState === "visible").catch(() => false),
      new Promise<boolean>(done => setTimeout(() => done(false), 400)),
    ])));
    return pages[visible.indexOf(true)];
  }
  async watchWaiting(): Promise<WaitingSignal[]> {
    const signals: WaitingSignal[] = [];
    for (const s of [...this.sessions.values()]) {
      if (!s.waiting || s.busy || s.stopped || s.abandoned || this.stopping || s.page.isClosed()) continue;
      try {
        if (s.finalStarted && s.receiptResponse && (await portalReceipts(s.page)).some(receipt => !s.baseline.has(receipt))) {
          signals.push({ sessionId: s.id, signal: "receipt_visible" }); continue;
        }
        if (s.waitingFor !== "captcha" && s.waitingFor !== "captcha_after_submit") continue;
        const state = await captchaStatus(s.page), open = state.active || state.widget && !state.solved;
        if (s.waitingFor === "captcha") { if (!open) signals.push({ sessionId: s.id, signal: "captcha_solved" }); continue; }
        if (open) { s.clearedAt = undefined; continue; }
        s.clearedAt ??= Date.now();
        // The provider's own callback normally submits within seconds; afterwards the outcome is checked once, never retried.
        if (Date.now() - s.clearedAt >= 30_000) signals.push({ sessionId: s.id, signal: "challenge_cleared" });
      } catch { /* A navigating tab is checked again on the next tick. */ }
    }
    return signals;
  }

  private async approvedValues(s: Session, form: PortalForm): Promise<Record<string, string>> {
    const current = await ordinaryValues(form), answers: Record<string, string> = {};
    for (const b of form.bindings) {
      if (b.kind === "file") {
        const count = await form.root.locator(b.selector).evaluate(e => (e as HTMLInputElement).files?.length ?? 0);
        if (count && s.uploads.has(`${s.step}:${b.field.key}`)) {
          if (!await this.verifyUpload(s, form, b, await this.file(s))) throw new Stop("human_required", "Resume changed before transmission");
          answers[b.field.key] = (await this.file(s)).name;
        } else if (count || b.field.required) throw new Stop("human_required", "An attachment is not approved");
        continue;
      }
      const value = current[b.field.key] ?? "", approved = s.approved.get(`${s.step}:${b.field.key}`);
      if (value && (approved === undefined || !this.valueMatches(b, value, approved))) throw new Stop("human_required", "A visible value changed; confirm current values before continuing");
      if (b.field.required && !value) throw new Stop("human_required", "A required field is still empty");
      if (approved !== undefined) answers[b.field.key] = approved;
    }
    return answers;
  }
  private async settle(s: Session): Promise<PortalScan> {
    const deadline = Date.now() + 3000;
    let scan: PortalScan;
    do {
      await this.check(s);
      scan = await scanPortal(s.page);
      if (scan.form || scan.noAi || scan.policyIncomplete || scan.auth || scan.captcha || scan.closed || scan.applyLinks.length || scan.frame) return scan;
      await s.page.waitForTimeout(100);
    } while (Date.now() < deadline);
    return scan!;
  }
  private async finalBoundary(s: Session): Promise<void> {
    if (s.boundaryCalled) throw new Stop("submission_unknown", "Final submission was already attempted; no retry is allowed");
    await this.check(s);
    s.boundaryCalled = true;
    s.finalStarted = true;
    this.attempted.add(s.jobKey);
    await s.input.beforeSubmit();
  }
  private async manualBoundary(s: Session): Promise<void> {
    await this.check(s);
    const scan = await scanPortal(s.page);
    if (scan.form) s.submitDestinations = new Set(scan.form.destinations.map(raw => {
      const url = this.url(raw, s.page.url()); return `${url.origin}${url.pathname}`;
    }));
    await this.finalBoundary(s);
  }
  private async confirm(s: Session, wait: boolean): Promise<WorkflowResult> {
    const deadline = Date.now() + (wait ? 5000 : 0);
    do {
      if (!s.page.isClosed() && !s.blocked && this.same(s.page.url(), s)) {
        const receipts = await portalReceipts(s.page).catch(() => []);
        if (s.receiptResponse && receipts.some(receipt => !s.baseline.has(receipt))) {
          await this.unmark(s);
          return this.finish(s, { status: "submitted_confirmed", reason: "A new application receipt followed an observed successful same-origin submission request",
            evidence: "New application confirmation region and successful submission response observed in the same live tab" });
        }
        if (s.input.allowHuman && !s.abandoned && !s.stopped && !this.stopping && await activeCaptcha(s.page).catch(() => false)) {
          const reason = "Submit opened a CAPTCHA. Solve it in this tab; Chairman then confirms the receipt and never clicks Submit again.";
          s.waiting = true; s.waitingFor = "captcha_after_submit"; s.clearedAt = undefined;
          await this.mark(s);
          await this.progress(s, "awaiting_human", reason).catch(() => undefined);
          return { status: "human_required", waitingFor: "captcha_after_submit", reason, sessionId: s.id, progress: structuredClone(s.progress) };
        }
      }
      if (Date.now() >= deadline || s.page.isClosed()) break;
      await s.page.waitForTimeout(100).catch(() => undefined);
    } while (true);
    const dropped = s.thirdParty.size ? ` Third-party requests dropped on this page: ${[...s.thirdParty].slice(0, 6).join(", ")}.` : "";
    return this.finish(s, { status: "submission_unknown", reason: `Final submission may have occurred, but no new attributable receipt and successful submission response were both observed; verify manually, never retry.${dropped}` }, false);
  }
  private async handle(s: Session, error: unknown): Promise<WorkflowResult> {
    if (s.finalStarted) return this.confirm(s, false);
    const status = error instanceof Stop ? error.status : s.transmitted ? "human_required" : "failed";
    const reason = error instanceof Stop ? error.message : "Portal state could not be verified; existing input was preserved and no operation was retried";
    if (status === "human_required" && s.input.allowHuman && !s.page.isClosed() && !s.abandoned && !s.stopped && !this.stopping) {
      s.waiting = true;
      s.waitingFor = error instanceof Stop && error.waitingFor ? error.waitingFor : "answers";
      s.clearedAt = undefined;
      await this.mark(s);
      try { await this.progress(s, "awaiting_human", reason); }
      catch { return this.finish(s, { status: "failed", reason: "Could not persist human-review progress; workflow stopped safely" }); }
      return { status: "human_required", reason, sessionId: s.id, progress: structuredClone(s.progress), waitingFor: s.waitingFor };
    }
    return this.finish(s, { status: status === "human_required" ? "unsupported" : status, reason });
  }
  private async finish(s: Session, result: WorkflowResult, close = true): Promise<WorkflowResult> {
    const completed = { ...result, sessionId: s.id, progress: structuredClone(s.progress) };
    this.results.set(s.id, completed);
    if (!close) { s.waiting = true; return completed; }
    this.sessions.delete(s.id);
    s.stopped = true;
    if (close) await s.page.close().catch(() => undefined);
    return completed;
  }

  async resumeWorkflow(sessionId: string, input: HumanContinuation): Promise<WorkflowResult> {
    const s = this.sessions.get(sessionId);
    if (!s) return this.results.get(sessionId) ?? { status: "failed", reason: "Live session is unavailable or was lost on browser restart; no navigation replay is permitted" };
    if (s.busy) return { status: "failed", sessionId, reason: "This live workflow is already running" };
    s.busy = true;
    s.manualControl = false;
    try {
      if (s.finalStarted || s.manualIntent && s.requests.size) return await this.confirm(s, true);
      await this.check(s);
      if (s.manualIntent) throw new Stop("human_required", "A manual Submit interaction was observed without a verified receipt; inspect the result instead of clicking again");
      s.waiting = false; s.waitingFor = undefined;
      await this.unmark(s);
      return await this.drive(s, input);
    } catch (error) { return await this.handle(s, error); }
    finally { s.busy = false; }
  }
  async focusWorkflow(sessionId: string): Promise<void> {
    const s = this.sessions.get(sessionId);
    if (!s || s.page.isClosed()) throw new Error("The original live application tab is unavailable");
    if (!s.busy && s.waiting) s.manualControl = true;
    await s.page.bringToFront();
  }
  async screenshotWorkflow(sessionId?: string): Promise<Buffer | undefined> {
    const s = sessionId ? this.sessions.get(sessionId) : [...this.sessions.values()].at(-1);
    const page = s?.page ?? (!sessionId ? this.setup : undefined);
    if (!page || page.isClosed()) return undefined;
    if (s && !this.same(page.url(), s)) return undefined;
    const masks = [
      page.locator("input,textarea,select,[contenteditable],iframe,canvas,[role=combobox],[role=listbox]"),
      page.locator('form:has(input[type=password]),[role=dialog], [id*="cookie" i],[class*="cookie" i],[id*="password" i],[class*="password" i],.file-upload,.ashby-application-form-input-file'),
    ];
    return page.screenshot({ type: "png", mask: masks, maskColor: "#171717", animations: "disabled" });
  }
  async abandonWorkflow(sessionId: string): Promise<void> {
    const s = this.sessions.get(sessionId);
    if (!s) return;
    s.abandoned = true;
    await this.finish(s, { status: s.finalStarted ? "submission_unknown" : "cancelled",
      reason: s.finalStarted ? "Abandoned after a possible submission; verify manually and never retry" : "Live application was abandoned without replay" });
  }
  async openForSetup(raw?: string): Promise<void> {
    if (raw && !this.manualUrl(raw)) throw new Error("Manual setup requires a public HTTPS destination.");
    const url = raw ? new URL(raw) : undefined;
    const context = await this.launch();
    if (!this.setup || this.setup.isClosed()) this.setup = await context.newPage();
    this.setupOrigin = url?.origin;
    if (url) await this.setup.goto(url.href, { waitUntil: "domcontentloaded" });
    await this.setup.bringToFront();
  }
  private manualUrl(raw: string): boolean {
    try {
      const url = new URL(raw);
      if (this.testOrigins.has(url.origin)) return true;
      return url.protocol === "https:" && !url.username && !url.password && !url.port
        && /^[a-z0-9-]+(?:\.[a-z0-9-]+)+$/i.test(url.hostname)
        && !/^\d[\d.]+$/.test(url.hostname) && !/\.(local|localhost|internal|test|invalid|onion|lan)$/i.test(url.hostname);
    } catch { return false; }
  }
  async close(): Promise<void> {
    this.stopping = true;
    for (const s of this.sessions.values()) {
      s.stopped = true;
      this.results.set(s.id, { status: s.finalStarted ? "submission_unknown" : "failed", reason: "Browser closed; its live session cannot be replayed" });
    }
    this.sessions.clear();
    this.manualPages.clear();
    const context = this.context;
    this.context = undefined;
    if (context) await context.close();
    if (this.starting) await this.starting.catch(() => undefined);
    await this.proxy?.close();
    this.proxy = undefined;
    this.setup = undefined;
    this.stopping = false;
  }
}
