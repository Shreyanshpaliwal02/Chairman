export function isNormalBrowserProfile(path: string): boolean {
  return /(?:\/Google\/Chrome|\/google-chrome|\/chromium|\/Microsoft\/Edge)(?:\/|$)/i.test(path.replaceAll("\\", "/"));
}
