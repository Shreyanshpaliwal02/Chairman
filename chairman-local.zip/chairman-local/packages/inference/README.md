# Gemini public-tag inference

Gemini uses the official Gemini Developer API, not a website session, Copilot
subscription, browser token, Vertex AI, or an app-owned credential. The reviewed
allowlist contains only `gemini-2.5-flash`, whose **standard** input/output are
listed as free-eligible in Google's pricing. Model availability and pricing can
change. There is no automatic replacement, retry, or paid upgrade.

## Free project and privacy boundaries

Before enabling Gemini, create your own Google AI Studio key, check that its
project is **Free with billing disabled**, and explicitly confirm this in Setup.
The API key/model metadata cannot establish billing tier. A billed project can
incur charges even for an allowlisted model. The application never enables
billing and does not promise unconditional free use.

Google's unpaid-service terms prohibit personal, sensitive and confidential
information; inputs can be human-reviewed and used for product improvement.
Consequently Gemini never receives raw resume facts, employers, dates, profile
fields, answers, links, original fact IDs, freeform skill labels, or the full JD.
`buildGeminiProjection` emits anonymous positional IDs and only canonical tokens
from the existing, fixed `PUBLIC_KEYWORD_TOKENS` taxonomy. Custom skill strings
cannot extend this vocabulary. `geminiProjectionSchema` independently enforces
the closed shape and vocabulary at the network boundary.

Gemini ranks these generic evidence tags, not private experience. Untagged facts
are omitted from remote ranking; zero tagged facts is an explicit error.
Anonymous selection IDs are validated for membership and uniqueness and mapped
back locally to exact confirmed fact IDs and skill labels. Existing factual
rendering and tailoring safeguards still apply. This is not freeform rewriting,
proof of proficiency, a guarantee of an ATS score, or a promise of outcomes.

## Runtime contract

- Config: `provider: "gemini"`, exact optional `model`, `allowRemoteProcessing`,
  `acknowledgeUsage`, and `confirmFreeTier`. No secrets are accepted here.
- Environment: `JAA_GEMINI_MODEL` (default `gemini-2.5-flash`),
  `JAA_ALLOW_GEMINI_REMOTE=1`, `JAA_GEMINI_FREE_TIER_CONFIRMED=1`.
  All confirmations are required, separately from Copilot.
- Key: `JAA_GEMINI_API_KEY`, falling back to `GEMINI_API_KEY`, or the dashboard's
  private key file. The private saved value overrides environment keys; removal
  writes a null marker so environment keys cannot reappear after a restart.
- Key file: `<data directory>/private/gemini-key.json`, separate from SQLite,
  exports and public packages. POSIX modes are directory `0700` and file `0600`.
  On Windows protect the per-user data directory with the account's ACLs.
  This file is not encrypted; protect the device and backups.
- `createGeminiKeyStore(dataDir)`: `load()`, `get()`, `save(key)`, `revoke()`.
  Wire `get` to `geminiInference.setApiKeyProvider`. Mutating a key must first
  invalidate Auto Apply, abort Gemini, revoke saved remote consent, and clear
  the server's AI cache. Data deletion also revokes the private key and consent.
- `POST /api/inference/gemini-key`: strict `{apiKey}` or `{revoke:true}`;
  response has no key. Saving the key does not grant processing consent.
- `getGeminiStatus()` / `refreshGeminiStatus()`: exact-model metadata GET only,
  never a generation prompt. Status contains key-presence and explicit consent
  booleans, never the key, and always `billingTierVerified:false`.
- Saved document provenance: `{provider:"gemini",model,remote:true}`.
  The legacy `local-ai` mode means the configured backend, not local processing.

Only direct verified HTTPS to `generativelanguage.googleapis.com` is permitted.
Keys use `x-goog-api-key`, never URLs. Redirects, proxy/custom endpoint settings,
disabled TLS verification, tool calls, grounding, files, caching requests and
batch endpoints are prohibited. Selection uses one non-streaming
`generateContent` POST with a JSON schema, disabled thinking, bounded input,
64 KiB response limit and timeout. Exact model and `finishReason:STOP` are
required. Upstream response bodies and network diagnostics are not exposed.

HTTP 429 pauses all Gemini operations, including status refresh, until the
`Retry-After` time (at least 60 seconds). No retry is scheduled and no other
job can bypass the shared cooldown. Quotas vary by project and model; daily
quotas reset at midnight Pacific. Cooldown is in-process; restarting is not a
quota-reset mechanism and must not be used to bypass Google's limits.

## Official references

Reviewed September 16, 2026:

- [Pricing](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash)
- [Exact model](https://ai.google.dev/gemini-api/docs/models/gemini-2.5-flash)
- [Terms](https://ai.google.dev/gemini-api/terms)
- [Rate limits](https://ai.google.dev/gemini-api/docs/rate-limits)

Tests use synthetic profiles and mocked fetch. No personal prompt or actual
Gemini generation is needed to validate this integration.
