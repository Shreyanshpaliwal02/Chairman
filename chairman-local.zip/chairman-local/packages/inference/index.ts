import { mkdtemp, mkdir, rm } from "node:fs/promises";
import { join, resolve } from "node:path";
import {
  CopilotClient,
  RuntimeConnection,
  type AssistantMessageEvent,
  type CopilotClientOptions,
  type CopilotSession,
  type SessionConfig,
  type SessionEvent,
} from "@github/copilot-sdk";
import { InferenceRequestGuard } from "./request-guard.js";

export interface CopilotStatus {
  available: boolean;
  model: string;
  reason?: string;
  provider: "copilot";
  remote: true;
  authenticated?: boolean;
  modelAvailable?: boolean;
  consentRequired?: boolean;
}

export interface CopilotModelInventory {
  provider: "copilot";
  signedIn: boolean;
  models: { id: string; name?: string; enabled: boolean; state?: string; multiplier?: number }[];
  reason?: string;
}

export type InferenceSession = Pick<CopilotSession, "sessionId" | "sendAndWait" | "abort" | "disconnect"> & {
  rpc: { model: Pick<CopilotSession["rpc"]["model"], "getCurrent"> };
};

export type InferenceClient = Pick<CopilotClient, "start" | "stop" | "forceStop" | "getAuthStatus" | "listModels" | "deleteSession"> & {
  createSession(config: SessionConfig): Promise<InferenceSession>;
};

export interface CopilotInferenceOptions {
  clientFactory?: (options: CopilotClientOptions) => InferenceClient;
  environment?: () => NodeJS.ProcessEnv;
  now?: () => number;
  statusTimeoutMs?: number;
  inferenceTimeoutMs?: number;
  cleanupTimeoutMs?: number;
}

const DEFAULT_MODEL = "gpt-6-astra";
const CACHE_MS = 60_000;
const MODEL_CACHE_MS = 5 * 60_000;
const MAX_OUTPUT_CHARS = 24_000;
const MAX_OUTPUT_BYTES = 96_000;
const CONSENT_REASON = "GitHub Copilot uses hosted processing: bounded confirmed resume facts, skills and job text leave this device and may consume Copilot allowance/premium usage. Explicitly acknowledge this with JAA_ALLOW_COPILOT_REMOTE=1 before enabling inference.";
const LOGIN_REASON = "Stored Copilot OAuth or your own GitHub CLI login is required. Sign in yourself with npm exec --package=@github/copilot -- copilot login, or with gh auth login using a GitHub CLI you installed (Homebrew or system). Tokens from environment variables, this application's or a chat session's tokens are never used.";
/**
 * Sign-ins accepted for hosted inference: your stored Copilot OAuth ("user") or your own GitHub CLI login ("gh-cli").
 * Tokens handed over in environment variables ("env", "token", …) are never accepted.
 */
const SIGN_INS = new Set(["user", "gh-cli"]);
const signedIn = (auth: { isAuthenticated: boolean; authType?: string }) => auth.isAuthenticated && SIGN_INS.has(auth.authType ?? "");
/**
 * Standard install locations only. The runtime's GitHub CLI fallback then finds a gh you installed yourself (Homebrew or
 * the system), never one bundled in another application's private folders (such as a chat app's own gh).
 */
export const RUNTIME_PATH = "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/home/linuxbrew/.linuxbrew/bin";

class InferenceError extends Error {}

function message(error: unknown): string {
  return error instanceof InferenceError ? error.message : "Copilot SDK operation failed. No automatic retry, alternative model or provider fallback was used.";
}

async function deadline<T>(operation: Promise<T>, milliseconds: number, reason: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([operation, new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new InferenceError(reason)), milliseconds);
    })]);
  } finally { clearTimeout(timer); }
}

function runtimeEnvironment(environment: NodeJS.ProcessEnv, directory: string): NodeJS.ProcessEnv {
  // Deliberately do not inherit tokens, BYOK endpoints, CLI overrides, plugins or NODE_OPTIONS.
  const result: NodeJS.ProcessEnv = {};
  for (const key of ["HOME", "USERPROFILE", "PATH", "SystemRoot", "WINDIR", "LOCALAPPDATA", "APPDATA", "DBUS_SESSION_BUS_ADDRESS", "XDG_RUNTIME_DIR"]) {
    if (environment[key]) result[key] = environment[key];
  }
  if (process.platform !== "win32") result.PATH = RUNTIME_PATH;
  return { ...result, TMPDIR: directory, TMP: directory, TEMP: directory, COPILOT_TELEMETRY_DISABLED: "1" };
}

/**
 * Whether a provider-hosted tool (web search, tool search, an advisor model…) actually ran. The envelope itself, tagged
 * only with its provider (for example {"provider":"openai-responses"}), is replay metadata and not tool use.
 */
function usedServerTools(tools: AssistantMessageEvent["data"]["serverTools"]): boolean {
  if (!tools) return false;
  const plain = new Set(["text", "output_text", "thinking", "redacted_thinking", "reasoning", "message"]);
  return !!tools.items?.length || !!tools.advisorModel || Object.keys(tools.functionCallNamespaces ?? {}).length > 0
    || (tools.rawContentBlocks ?? []).some(block => !block || typeof block !== "object" || Array.isArray(block) || !plain.has(String((block as { type?: unknown }).type)));
}
function invalidMessage(event: AssistantMessageEvent, model: string): boolean {
  return event.agentId !== undefined || event.data.parentToolCallId !== undefined
    || (event.data.model !== undefined && event.data.model !== model)
    || Boolean(event.data.toolRequests?.length) || usedServerTools(event.data.serverTools)
    || !event.data.content.trim() || event.data.content.length > MAX_OUTPUT_CHARS
    || Buffer.byteLength(event.data.content, "utf8") > MAX_OUTPUT_BYTES;
}

interface RuntimeContext {
  client: InferenceClient;
  workingDirectory: string;
  configDirectory: string;
  requestGuard: InferenceRequestGuard;
  fail: (reason: string) => void;
  assertOpen: () => void;
  openSession: (config: SessionConfig) => Promise<InferenceSession>;
}

export function createCopilotInference(options: CopilotInferenceOptions = {}) {
  const environment = options.environment ?? (() => process.env);
  const now = options.now ?? Date.now;
  const clientFactory = options.clientFactory ?? ((config) => new CopilotClient(config));
  const cleanupTimeout = options.cleanupTimeoutMs ?? 2_000;
  let busy = false;
  let cleanupFailed = false;
  let cache: { key: string; expires: number; status: CopilotStatus } | undefined;
  let pendingStatus: { key: string; promise: Promise<CopilotStatus> } | undefined;
  let modelCache: { expires: number; inventory: CopilotModelInventory } | undefined;
  let pendingModels: Promise<CopilotModelInventory> | undefined;

  function config(): { model: string; consent: boolean } {
    const env = environment();
    return { model: env.JAA_COPILOT_MODEL || DEFAULT_MODEL, consent: env.JAA_ALLOW_COPILOT_REMOTE === "1" };
  }

  function disabled(): CopilotStatus | undefined {
    const { model, consent } = config();
    const base = { available: false, model, provider: "copilot" as const, remote: true as const };
    if (!consent) return { ...base, consentRequired: true, reason: CONSENT_REASON };
    if (model === "auto" || !/^[a-z0-9][a-z0-9._-]{0,127}$/.test(model)) {
      return { ...base, consentRequired: false, reason: "JAA_COPILOT_MODEL must be an exact model ID, not auto, a URL or a provider alias." };
    }
    if (cleanupFailed) return { ...base, reason: "Copilot runtime cleanup failed. Restart the application before further inference." };
    return undefined;
  }

  async function stop(client: InferenceClient): Promise<void> {
    try {
      const errors = await deadline(client.stop(), cleanupTimeout, "Copilot shutdown timed out.");
      if (!errors.length) return;
    } catch { /* Force-stop only the SDK-owned child when graceful shutdown fails. */ }
    try { await deadline(client.forceStop(), cleanupTimeout, "Copilot forced shutdown timed out."); }
    catch {
      cleanupFailed = true;
      throw new InferenceError("Copilot runtime cleanup failed. Restart the application before further inference.");
    }
  }

  async function execute<T>(timeout: number, model: string, action: (context: RuntimeContext) => Promise<T>,
    timeoutReason = "Copilot timed out. The inference was cancelled; no retry or fallback was used."): Promise<T> {
    // A fresh private directory under the application's launch directory, never an OS shared temp directory.
    const root = await mkdtemp(resolve(".jaa-copilot-"));
    const workingDirectory = join(root, "work");
    const configDirectory = join(root, "state");
    const requestGuard = new InferenceRequestGuard(model);
    let client: InferenceClient | undefined;
    let session: InferenceSession | undefined;
    let closed = false;
    let failureReason: string | undefined;
    const closeSession = async (current: InferenceSession) => {
      for (const cleanup of [() => current.abort(), () => current.disconnect(), () => client!.deleteSession(current.sessionId)]) {
        try { await deadline(cleanup(), cleanupTimeout, "Copilot session cleanup timed out."); }
        catch { /* Client shutdown below also closes pending sessions. */ }
      }
    };
    try {
      await Promise.all([mkdir(workingDirectory, { mode: 0o700 }), mkdir(configDirectory, { mode: 0o700 })]);
      client = clientFactory({
        // SDK 1.0.13's "empty" mode disables OS-keychain OAuth. Lock down every session explicitly instead.
        mode: "copilot-cli",
        connection: RuntimeConnection.forStdio(),
        workingDirectory,
        env: runtimeEnvironment(environment(), root),
        useLoggedInUser: true,
        builtinPluginDirectories: [],
        logLevel: "none",
        enableRemoteSessions: false,
        sessionIdleTimeoutSeconds: 150,
        requestHandler: requestGuard,
      });
      const activeClient = client;
      let rejectFailure!: (error: Error) => void;
      const failure = new Promise<never>((_, reject) => { rejectFailure = reject; });
      const running = (async () => {
        await activeClient.start();
        if (closed) {
          await stop(activeClient);
          throw new InferenceError("Copilot startup completed after cancellation.");
        }
        return action({
          client: activeClient, workingDirectory, configDirectory, requestGuard,
          fail: (reason) => { failureReason = reason; requestGuard.close(); rejectFailure(new InferenceError(reason)); },
          assertOpen: () => {
            if (closed || failureReason) throw new InferenceError(failureReason ?? "Copilot inference was cancelled.");
          },
          openSession: async (settings) => {
            if (closed || failureReason) throw new InferenceError(failureReason ?? "Copilot inference was cancelled.");
            const created = await activeClient.createSession(settings);
            if (closed) {
              await closeSession(created);
              throw new InferenceError("Copilot session creation completed after cancellation.");
            }
            session = created;
            return created;
          },
        });
      })();
      return await deadline(Promise.race([running, failure]), timeout, timeoutReason);
    } finally {
      closed = true;
      requestGuard.close();
      try {
        if (session) await closeSession(session);
        if (client) await stop(client);
      } finally { await rm(root, { recursive: true, force: true }); }
    }
  }

  async function inspect(client: InferenceClient, model: string, assertOpen: () => void): Promise<CopilotStatus> {
    const base = { model, provider: "copilot" as const, remote: true as const, consentRequired: false };
    let authenticated: boolean | undefined;
    try {
      const auth = await client.getAuthStatus();
      assertOpen();
      authenticated = signedIn(auth);
      if (!authenticated) return { ...base, available: false, authenticated: false, reason: LOGIN_REASON };
      const models = await client.listModels();
      assertOpen();
      const selected = models.find((candidate) => candidate.id === model);
      if (!selected) return { ...base, available: false, authenticated, modelAvailable: false, reason: `The exact Copilot model ${model} is not in the SDK model inventory. This chat's model does not establish SDK availability; no other model will be substituted.` };
      if (selected.policy && selected.policy.state !== "enabled") {
        return { ...base, available: false, authenticated, modelAvailable: false, reason: `Copilot model ${model} is ${selected.policy.state} by account/organization policy. Enable it or review any terms yourself; the application never accepts terms.` };
      }
      return { ...base, available: true, authenticated, modelAvailable: true, reason: "Your GitHub sign-in and the exact SDK model inventory were verified. Hosted Copilot processing may consume allowance/premium usage; availability does not guarantee a future request succeeds." };
    } catch {
      return { ...base, available: false, authenticated, reason: authenticated ? "Copilot model inventory could not be verified. No inference or fallback was attempted." : "Copilot authentication status could not be verified. No inference was attempted." };
    }
  }

  async function getStatus(): Promise<CopilotStatus> {
    const blocked = disabled();
    if (blocked) return blocked;
    const { model } = config();
    const currentStatus = (status: CopilotStatus): CopilotStatus => disabled() ?? (config().model === model ? { ...status } : {
      available: false, model: config().model, provider: "copilot", remote: true,
      reason: "Copilot configuration changed during verification. Check status again.",
    });
    if (cache?.key === model && cache.expires > now()) return currentStatus(cache.status);
    if (pendingStatus?.key === model) return currentStatus(await pendingStatus.promise);
    const promise = (async (): Promise<CopilotStatus> => {
      let status: CopilotStatus;
      try {
        status = await execute(options.statusTimeoutMs ?? 15_000, model, ({ client, assertOpen }) => inspect(client, model, assertOpen),
          "Copilot status verification timed out. No inference was attempted.");
      }

      catch (error) { status = { available: false, model, provider: "copilot", remote: true, reason: message(error) }; }
      cache = { key: model, expires: now() + CACHE_MS, status };
      return status;
    })();
    pendingStatus = { key: model, promise };
    try {
      return currentStatus(await promise);
    }
    finally { if (pendingStatus?.promise === promise) pendingStatus = undefined; }
  }

  async function getModels(refresh = false): Promise<CopilotModelInventory> {
    if (cleanupFailed) return { provider: "copilot", signedIn: false, models: [], reason: "Copilot runtime cleanup failed. Restart the application before further inference." };
    if (!refresh && modelCache?.expires && modelCache.expires > now()) return { ...modelCache.inventory, models: modelCache.inventory.models.map(model => ({ ...model })) };
    if (!refresh && pendingModels) return pendingModels;
    const promise = (async (): Promise<CopilotModelInventory> => {
      try {
        const inventory = await execute(options.statusTimeoutMs ?? 15_000, config().model || DEFAULT_MODEL, async ({ client, assertOpen }) => {
          const auth = await client.getAuthStatus();
          assertOpen();
          if (!signedIn(auth)) return { provider: "copilot" as const, signedIn: false, models: [], reason: LOGIN_REASON };
          const models = await client.listModels();
          assertOpen();
          return {
            provider: "copilot" as const,
            signedIn: true,
            models: models.map(model => ({
              id: model.id,
              name: model.name,
              enabled: !model.policy || model.policy.state === "enabled",
              ...(model.policy?.state ? { state: model.policy.state } : {}),
              ...(typeof model.billing?.multiplier === "number" ? { multiplier: model.billing.multiplier } : {}),
            })),
          };
        }, "Copilot model inventory timed out. No inference was attempted.");
        modelCache = { expires: now() + MODEL_CACHE_MS, inventory };
        return { ...inventory, models: inventory.models.map(model => ({ ...model })) };
      } catch (error) {
        return { provider: "copilot", signedIn: false, models: [], reason: message(error) };
      }
    })();
    pendingModels = promise;
    try { return await promise; }
    finally { if (pendingModels === promise) pendingModels = undefined; }
  }

  async function select(system: string, user: string, schema: object): Promise<unknown> {
    const blocked = disabled();
    if (blocked) throw new InferenceError(blocked.reason);
    const { model } = config();
    let format: string;
    try { format = JSON.stringify(schema); }
    catch { throw new InferenceError("Copilot selection requires a bounded JSON schema."); }
    if (typeof format !== "string" || !schema || Array.isArray(schema) || format.length > 24_000
      || typeof system !== "string" || system.length > 4_096 || typeof user !== "string" || user.length > 28_000
      || Buffer.byteLength(system + user + format, "utf8") > 160_000) {
      throw new InferenceError("Copilot selection input exceeds the bounded context limit.");
    }
    if (busy) throw new InferenceError("Copilot inference is already running. Only one request at a time is allowed; retry explicitly after it finishes.");
    busy = true;
    try {
      return await execute(options.inferenceTimeoutMs ?? 120_000, model, async (context) => {
        const status = await inspect(context.client, model, context.assertOpen);
        context.assertOpen();
        if (!status.available) throw new InferenceError(status.reason);
        let outputChars = 0;
        const onEvent = (event: SessionEvent): void => {
          if (event.type === "session.error") context.fail("Copilot reported a model/session error. No retry or fallback was used.");
          if (event.type === "session.model_change" && event.data.newModel !== model) context.fail("Copilot attempted to switch away from the exact configured model.");
          if (event.type === "tool.execution_start" || event.type === "subagent.started") context.fail("Copilot attempted a prohibited tool or agent operation.");
          if (event.type === "assistant.message_delta") {
            outputChars += event.data.deltaContent.length;
            if (outputChars > MAX_OUTPUT_CHARS) context.fail("Copilot output exceeded the bounded response limit.");
          }
          if (event.type === "assistant.message" && invalidMessage(event, model)) context.fail("Copilot returned an oversized, tool-bearing or unexpected-model response.");
        };
        const session = await context.openSession({
          model,
          clientName: "job-application-assistant",
          workingDirectory: context.workingDirectory,
          configDirectory: context.configDirectory,
          systemMessage: { mode: "replace", content: `${system}\nReturn ONLY JSON conforming to this schema:\n${format}` },
          availableTools: [],
          excludedTools: ["builtin:*", "mcp:*", "custom:*"],
          tools: [],
          mcpServers: {},
          customAgents: [],
          skillDirectories: [],
          includedBuiltinSkills: [],
          pluginDirectories: [],
          instructionDirectories: [],
          additionalDirectories: [],
          enableConfigDiscovery: false,
          skipCustomInstructions: true,
          organizationCustomInstructions: "",
          enableSkills: false,
          enableFileHooks: false,
          enableOnDemandInstructionDiscovery: false,
          enableHostGitOperations: false,
          enableFileChangeTracking: false,
          enableSessionStore: false,
          enableSessionTelemetry: false,
          enableExperimentalMode: false,
          requestExtensions: false,
          requestCanvasRenderer: false,
          manageScheduleEnabled: false,
          coauthorEnabled: false,
          customAgentsLocalOnly: true,
          enableMcpApps: false,
          skipEmbeddingRetrieval: true,
          embeddingCacheStorage: "in-memory",
          memory: { enabled: false },
          infiniteSessions: { enabled: false },
          largeOutput: { enabled: false },
          remoteSession: "off",
          capi: { enableWebSocketResponses: false },
          streaming: true,
          onPermissionRequest: () => {
            context.fail("Copilot requested a prohibited permission. All permissions are denied.");
            return { kind: "denied-no-approval-rule-and-could-not-request-from-user" };
          },
          hooks: {
            onPreToolUse: () => {
              context.fail("Copilot attempted a prohibited tool operation.");
              return { permissionDecision: "deny" };
            },
            onErrorOccurred: () => ({ errorHandling: "abort" }),
          },
          onEvent,
        });
        const current = await session.rpc.model.getCurrent();
        context.assertOpen();
        if (current.modelId !== model) throw new InferenceError("Copilot did not select the exact configured model. No prompt was sent.");
        const changed = disabled();
        if (changed || config().model !== model) throw new InferenceError(changed?.reason ?? "Copilot configuration changed before inference. No prompt was sent.");
        context.requestGuard.enable();
        const response = await session.sendAndWait({ prompt: user }, options.inferenceTimeoutMs ?? 120_000);
        if (!response || invalidMessage(response, model)) throw new InferenceError("Copilot returned no complete, bounded, tool-free response from the configured model.");
        try { return JSON.parse(response.data.content) as unknown; }
        catch { throw new InferenceError("Copilot did not return strict structured JSON. No retry or deterministic fallback was used."); }
      });
    } catch (error) {
      cache = undefined;
      throw new InferenceError(message(error));
    } finally { busy = false; }
  }

  return { getStatus, select, listModels: getModels, clearStatusCache: () => { cache = undefined; modelCache = undefined; } };
}

/** Shared controller also permits dependency injection in offline tests without replacing SDK internals. */
export const copilotInference = createCopilotInference();
export function getCopilotStatus(): Promise<CopilotStatus> { return copilotInference.getStatus(); }
export function refreshCopilotStatus(): Promise<CopilotStatus> { copilotInference.clearStatusCache(); return copilotInference.getStatus(); }
export function copilotSelect(system: string, user: string, schema: object): Promise<unknown> { return copilotInference.select(system, user, schema); }
export function listCopilotModels(refresh = false, options?: CopilotInferenceOptions): Promise<CopilotModelInventory> {
  return options ? createCopilotInference(options).listModels(refresh) : copilotInference.listModels(refresh);
}
