import { createHash, randomUUID } from "node:crypto";
import { z } from "zod";
import { PUBLIC_KEYWORD_TOKENS } from "../domain/keywords.js";
import { DEFAULT_GEMINI_MODEL, GEMINI_FREE_MODELS } from "./gemini-policy.js";

export { DEFAULT_GEMINI_MODEL, GEMINI_FREE_MODELS } from "./gemini-policy.js";
const publicTokens = new Set(PUBLIC_KEYWORD_TOKENS);
const tags = z.array(z.string().refine((value) => publicTokens.has(value))).max(PUBLIC_KEYWORD_TOKENS.length)
  .refine((values) => new Set(values).size === values.length);
export const geminiProjectionSchema = z.object({
  job: z.object({ tags }).strict(),
  facts: z.array(z.object({ id: z.string(), tags: tags.min(1) }).strict()).min(1).max(80)
    .refine((values) => values.every((value, index) => value.id === `f${index + 1}`)),
  skills: z.array(z.object({ id: z.string(), tags: tags.min(1) }).strict()).max(80)
    .refine((values) => values.every((value, index) => value.id === `s${index + 1}`)),
}).strict();
export type GeminiProjection = z.infer<typeof geminiProjectionSchema>;
export interface GeminiSelection { factIds: string[]; skillIds: string[] }
export interface GeminiStatus {
  available: boolean;
  provider: "gemini";
  model: string;
  remote: true;
  reason?: string;
  authenticated?: boolean;
  modelAvailable?: boolean;
  consentRequired: boolean;
  keyConfigured: boolean;
  freeTierConfirmed: boolean;
  billingTierVerified: false;
  retryAt?: string;
  retryAfterSeconds?: number;
}
export interface GeminiInferenceOptions {
  environment?: () => NodeJS.ProcessEnv;
  apiKey?: () => string | undefined;
  fetch?: typeof globalThis.fetch;
  now?: () => number;
  statusTimeoutMs?: number;
  inferenceTimeoutMs?: number;
}
export class GeminiError extends Error {
  constructor(message: string, readonly retryAfterSeconds?: number) { super(message); this.name = "GeminiError"; }
}
const API = "https://generativelanguage.googleapis.com/v1beta/models/";
const MAX_RESPONSE_BYTES = 64 * 1024;
const SYSTEM = "Rank the supplied anonymous evidence IDs for relevance to the job's public technology tags. Return only factIds and skillIds in relevance order, using supplied IDs once each. Select at least one fact. You see only a closed public vocabulary, not personal facts or the full job description. Do not invent claims, write prose, request tools, or infer experience from missing tags.";
const safeReason = (error: unknown): string => error instanceof GeminiError ? error.message
  : "Gemini request failed, timed out, or attempted a redirect. No retry or provider/model fallback was used.";

export function createGeminiInference(options: GeminiInferenceOptions = {}) {
  const environment = options.environment ?? (() => process.env);
  const now = options.now ?? Date.now;
  const fetcher = options.fetch ?? ((...args: Parameters<typeof fetch>) => globalThis.fetch(...args));
  let keyProvider = options.apiKey ?? (() => environment().JAA_GEMINI_API_KEY || environment().GEMINI_API_KEY);
  let revision = randomUUID();
  let cache: { fingerprint: string; expires: number; status: GeminiStatus } | undefined;
  let pending: { fingerprint: string; promise: Promise<GeminiStatus> } | undefined;
  let retryAt = 0;
  let busy = false;
  const controllers = new Set<AbortController>();

  function config() {
    const env = environment();
    return {
      model: env.JAA_GEMINI_MODEL || DEFAULT_GEMINI_MODEL,
      consent: env.JAA_ALLOW_GEMINI_REMOTE === "1",
      free: env.JAA_GEMINI_FREE_TIER_CONFIRMED === "1",
      key: keyProvider(),
    };
  }
  function fingerprint(): string {
    return createHash("sha256").update(JSON.stringify([config(), revision])).digest("hex");
  }
  function base(): GeminiStatus {
    const current = config();
    return { available: false, provider: "gemini", model: GEMINI_FREE_MODELS.some((model) => model === current.model) ? current.model : "",
      remote: true, consentRequired: !current.consent, keyConfigured: Boolean(current.key),
      freeTierConfirmed: current.free, billingTierVerified: false };
  }
  function blocked(): GeminiStatus | undefined {
    const status = base(), current = config(), env = environment();
    if (!current.consent) return { ...status, reason: "Gemini needs separate remote-processing consent. Only anonymous IDs and fixed public technology tags may be sent; no personal, sensitive or confidential text." };
    if (!current.free) return { ...status, reason: "Confirm in Google AI Studio that this API key's project is Free with billing disabled. An API key cannot prove its billing tier; the application never enables billing." };
    if (!GEMINI_FREE_MODELS.some((model) => model === current.model)) return { ...status, reason: "Gemini requires an exact allowlisted free-eligible Flash model. No alternative model is selected automatically." };
    if (!current.key || !/^AIza[A-Za-z0-9_-]{35}$/.test(current.key)) return { ...status, reason: "A valid user-owned Google AI Studio API key is required. Save it privately in Setup; never put it in inference configuration or resume data." };
    if (Object.entries(env).some(([name, value]) => value && (
      /^(?:https?_proxy|all_proxy|npm_config_(?:https?_)?proxy|global_agent_https?_proxy)$/i.test(name)
      || /^(?:JAA_GEMINI_(?:URL|BASE_URL|ENDPOINT)|GEMINI_BASE_URL|GOOGLE_GEMINI_BASE_URL)$/i.test(name)))
      || env.NODE_USE_ENV_PROXY === "1" || /--use-env-proxy/.test(env.NODE_OPTIONS ?? "")
      || env.NODE_TLS_REJECT_UNAUTHORIZED === "0") {
      return { ...status, reason: "Gemini requires direct verified HTTPS to Google's fixed API host. Proxy, custom endpoint and disabled TLS verification settings are not allowed." };
    }
    if (retryAt > now()) {
      const seconds = Math.ceil((retryAt - now()) / 1000);
      return { ...status, retryAt: new Date(retryAt).toISOString(), retryAfterSeconds: seconds,
        reason: `Gemini quota exhausted (HTTP 429). Requests are paused for ${seconds} seconds. Quotas depend on the project and model; daily limits reset at midnight Pacific. No automatic retry or model fallback.` };
    }
    return undefined;
  }
  function assertCurrent(expected: string): void {
    if (fingerprint() !== expected) throw new GeminiError("Gemini credentials or processing permissions changed. The request was cancelled; review authorization before retrying.");
    const failure = blocked();
    if (failure) throw new GeminiError(failure.reason!, failure.retryAfterSeconds);
  }
  async function request(path: string, expected: string, body?: object, externalSignal?: AbortSignal): Promise<unknown> {
    assertCurrent(expected);
    const controller = new AbortController();
    const abort = () => controller.abort();
    externalSignal?.addEventListener("abort", abort, { once: true });
    if (externalSignal?.aborted) controller.abort();
    controllers.add(controller);
    const timer = setTimeout(abort, body ? options.inferenceTimeoutMs ?? 60_000 : options.statusTimeoutMs ?? 10_000);
    try {
      const response = await fetcher(`${API}${path}`, {
        method: body ? "POST" : "GET", redirect: "error", credentials: "omit", cache: "no-store",
        headers: { accept: "application/json", "x-goog-api-key": config().key!, ...(body ? { "content-type": "application/json" } : {}) },
        ...(body ? { body: JSON.stringify(body) } : {}), signal: controller.signal,
      });
      if (!response.ok) {
        // Never include Google's body or header text in diagnostics: they can contain credentials or prompts.
        const retry = response.headers.get("retry-after");
        if (response.status === 429) {
          const seconds = retry && /^\d{1,9}$/.test(retry) ? Number(retry) : undefined;
          const date = retry && retry.length <= 80 ? Date.parse(retry) : NaN;
          retryAt = Math.max(now() + 60_000, seconds !== undefined ? now() + seconds * 1000 : Number.isFinite(date) ? date : 0);
          cache = undefined;
        }
        await response.body?.cancel();
        if (response.status === 429) throw new GeminiError(blocked()!.reason!, Math.ceil((retryAt - now()) / 1000));
        throw new GeminiError(response.status === 401 || response.status === 403
          ? "Gemini rejected the API key or project access (HTTP 401/403). Review your own key and restrictions in AI Studio."
          : response.status === 404 ? "The exact Gemini model is unavailable (HTTP 404). No replacement or fallback was attempted."
            : `Gemini returned HTTP ${response.status}. No automatic retry or fallback was attempted.`);
      }
      if (!response.body) throw new GeminiError("Gemini returned an empty response.");
      const reader = response.body.getReader();
      const chunks: Uint8Array[] = [];
      let bytes = 0;
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          bytes += value.byteLength;
          if (bytes > MAX_RESPONSE_BYTES) {
            await reader.cancel();
            throw new GeminiError("Gemini response exceeded the bounded size limit.");
          }
          chunks.push(value);
        }
      } finally { reader.releaseLock(); }
      assertCurrent(expected);
      if (controller.signal.aborted) throw new GeminiError("Gemini request was cancelled or timed out. No retry was attempted.");
      try { return JSON.parse(Buffer.concat(chunks).toString("utf8")) as unknown; }
      catch { throw new GeminiError("Gemini returned malformed JSON. No retry was attempted."); }
    } catch (error) { throw new GeminiError(safeReason(error), error instanceof GeminiError ? error.retryAfterSeconds : undefined); }
    finally {
      clearTimeout(timer);
      controllers.delete(controller);
      externalSignal?.removeEventListener("abort", abort);
    }
  }
  async function getStatus(): Promise<GeminiStatus> {
    const failure = blocked();
    if (failure) return failure;
    const expected = fingerprint();
    if (cache?.fingerprint === expected && cache.expires > now()) return { ...cache.status };
    if (pending?.fingerprint === expected) return { ...await pending.promise };
    const promise = (async (): Promise<GeminiStatus> => {
      let status: GeminiStatus;
      try {
        const model = config().model;
        const value = await request(model, expected);
        const metadata = z.object({ name: z.literal(`models/${model}`),
          supportedGenerationMethods: z.array(z.string()).max(40) }).safeParse(value);
        if (!metadata.success || !metadata.data.supportedGenerationMethods.includes("generateContent")) {
          throw new GeminiError("Gemini did not verify the exact model's generateContent capability. No generation was attempted.");
        }
        status = { ...base(), available: true, authenticated: true, modelAvailable: true,
          reason: "Exact model metadata is available. Billing tier cannot be verified by this app: no-charge use requires your Free project with billing disabled. Only fixed public tags and anonymous IDs are sent." };
      } catch (error) { status = { ...base(), ...(blocked() ?? {}), reason: safeReason(error) }; }
      if (fingerprint() === expected) cache = { fingerprint: expected, expires: now() + 60_000, status };
      return status;
    })();
    pending = { fingerprint: expected, promise };
    try { return { ...await promise }; }
    finally { if (pending?.promise === promise) pending = undefined; }
  }
  async function select(input: GeminiProjection, signal?: AbortSignal): Promise<GeminiSelection> {
    const parsed = geminiProjectionSchema.safeParse(input);
    if (!parsed.success) throw new GeminiError("Gemini input must contain only bounded anonymous positional IDs and the fixed public technology vocabulary.");
    const projection = parsed.data;
    if (Buffer.byteLength(JSON.stringify(projection)) > 28_000) throw new GeminiError("The public Gemini projection exceeds its bounded size limit.");
    const failure = blocked();
    if (failure) throw new GeminiError(failure.reason!, failure.retryAfterSeconds);
    if (busy) throw new GeminiError("Gemini inference is already running. Only one request is allowed at a time.");
    if (signal?.aborted) throw new GeminiError("Gemini request was cancelled before sending.");
    busy = true;
    const expected = fingerprint(), model = config().model;
    try {
      const status = await getStatus();
      if (!status.available) throw new GeminiError(status.reason!, status.retryAfterSeconds);
      assertCurrent(expected);
      if (signal?.aborted) throw new GeminiError("Gemini request was cancelled before sending.");
      const factIds = projection.facts.map((fact) => fact.id), skillIds = projection.skills.map((skill) => skill.id);
      const response = await request(`${model}:generateContent`, expected, {
        systemInstruction: { parts: [{ text: SYSTEM }] },
        contents: [{ role: "user", parts: [{ text: JSON.stringify(projection) }] }],
        generationConfig: {
          temperature: 0, candidateCount: 1, maxOutputTokens: 2048, thinkingConfig: { thinkingBudget: 0 },
          responseMimeType: "application/json",
          responseJsonSchema: { type: "object", additionalProperties: false, required: ["factIds", "skillIds"], properties: {
            factIds: { type: "array", minItems: 1, maxItems: factIds.length, uniqueItems: true, items: { type: "string", enum: factIds } },
            skillIds: { type: "array", maxItems: skillIds.length, uniqueItems: true, items: skillIds.length ? { type: "string", enum: skillIds } : { type: "string" } },
          } },
        },
      }, signal);
      const envelope = z.object({
        modelVersion: z.literal(model),
        candidates: z.array(z.object({
          finishReason: z.literal("STOP"),
          content: z.object({ role: z.literal("model"), parts: z.array(z.object({
            text: z.string().min(1).max(12_000), thought: z.literal(false).optional(),
          }).strict()).length(1) }).strict(),
        })).length(1),
        promptFeedback: z.object({ blockReason: z.never().optional() }).optional(),
      }).safeParse(response);
      if (!envelope.success) throw new GeminiError("Gemini returned a blocked, incomplete, tool-bearing or unexpected-model response. No document was generated.");
      let decoded: unknown;
      try { decoded = JSON.parse(envelope.data.candidates[0].content.parts[0].text); }
      catch { throw new GeminiError("Gemini did not return strict selection JSON. No document was generated."); }
      const selection = z.object({
        factIds: z.array(z.string()).min(1).max(factIds.length),
        skillIds: z.array(z.string()).max(skillIds.length),
      }).strict().safeParse(decoded);
      if (!selection.success || new Set(selection.data.factIds).size !== selection.data.factIds.length
        || new Set(selection.data.skillIds).size !== selection.data.skillIds.length
        || selection.data.factIds.some((id) => !factIds.includes(id)) || selection.data.skillIds.some((id) => !skillIds.includes(id))) {
        throw new GeminiError("Gemini selected unknown or duplicate anonymous IDs. No document was generated.");
      }
      return selection.data;
    } finally { busy = false; }
  }
  function invalidate(): void {
    revision = randomUUID(); cache = undefined; pending = undefined;
    for (const controller of controllers) controller.abort();
  }
  return {
    getStatus, select, invalidate,
    refreshStatus: () => { cache = undefined; return getStatus(); },
    setApiKeyProvider: (provider: () => string | undefined) => { keyProvider = provider; invalidate(); },
    credentialRevision: () => revision,
  };
}
export const geminiInference = createGeminiInference();
export const getGeminiStatus = () => geminiInference.getStatus();
export const refreshGeminiStatus = () => geminiInference.refreshStatus();
