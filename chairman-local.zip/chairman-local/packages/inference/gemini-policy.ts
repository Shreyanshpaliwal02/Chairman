// Exact IDs checked against Google's standard free-tier pricing, September 2026.
export const GEMINI_FREE_MODELS = Object.freeze(["gemini-2.5-flash"] as const);
export const DEFAULT_GEMINI_MODEL = GEMINI_FREE_MODELS[0];
