import { CopilotRequestHandler, type CopilotRequestContext, type CopilotWebSocketHandler } from "@github/copilot-sdk";

/**
 * Reading the model list (GET …githubcopilot.com/models) carries no prompt. With a GitHub CLI sign-in the runtime fetches
 * it through this handler, so it passes without counting as the one inference request.
 */
function modelInventory(request: Request): boolean {
  if (request.method !== "GET") return false;
  try {
    const url = new URL(request.url);
    return url.protocol === "https:" && /(?:^|\.)githubcopilot\.com$/.test(url.hostname) && /^\/models\/?$/.test(url.pathname);
  } catch { return false; }
}
/** Limits even runtime-internal retries, summaries and compaction to one model request. */
export class InferenceRequestGuard extends CopilotRequestHandler {
  private enabled = false;
  private used = false;
  private closed = false;

  constructor(private readonly model: string) { super(); }

  enable(): void {
    if (this.closed) throw new Error("Copilot inference was cancelled.");
    this.enabled = true;
  }
  close(): void { this.enabled = false; this.closed = true; }

  protected override async sendRequest(request: Request, context: CopilotRequestContext): Promise<Response> {
    if (this.closed) throw new Error("Copilot inference was cancelled.");
    if (modelInventory(request)) return super.sendRequest(request, context);
    if (!this.enabled || this.used) throw new Error("Additional Copilot inference requests are prohibited; no automatic retry is allowed.");
    this.used = true;
    const body: unknown = await request.clone().json();
    if (!body || typeof body !== "object" || !("model" in body) || body.model !== this.model) {
      throw new Error("Copilot attempted inference with a different or unspecified model.");
    }
    if (this.closed) throw new Error("Copilot inference was cancelled.");
    return super.sendRequest(request, context);
  }

  protected override async openWebSocket(_context: CopilotRequestContext): Promise<CopilotWebSocketHandler> {
    throw new Error("Copilot inference requires the bounded single-request HTTP transport.");
  }
}
