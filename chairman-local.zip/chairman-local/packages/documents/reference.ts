import type { Fact, Profile, ReferenceFamily } from "../domain/types.js";
import { assertReferenceProfile, MAX_SELECTED_FACTS, MAX_SELECTED_SKILLS } from "./safety.js";

export const REFERENCE_WARNING = "REFERENCE DRAFT - verify facts before use";
export const REFERENCE_REVIEW = "Local review copy only. Verify source claims, skills, contact details and employer/title/date associations before use. This is not an application or approval.";

const families: Record<ReferenceFamily, { title: string; terms: string[] }> = {
  software: { title: "Software engineering", terms: ["software", "developer", "programming", "Python", "JavaScript", "TypeScript", "Java", "C++", "C#", "Rust", "Go", "API", "APIs", "REST", "backend", "frontend", "React", "testing", "tests", "test", "distributed", "microservices"] },
  cloud: { title: "Cloud engineering", terms: ["cloud", "AWS", "Azure", "GCP", "infrastructure", "IaC", "Kubernetes", "K8s", "Docker", "Terraform", "Linux", "network", "deployment", "CI/CD", "reliability", "monitoring", "platform"] },
  data: { title: "Data engineering", terms: ["data", "SQL", "PostgreSQL", "Python", "Spark", "PySpark", "Databricks", "Snowflake", "Airflow", "Kafka", "ETL", "ELT", "warehouse", "pipelines", "ingestion", "dbt", "BigQuery"] },
  "forward-deployed": { title: "Forward-deployed engineering", terms: ["customer", "customers", "client", "clients", "stakeholder", "stakeholders", "integration", "integrations", "deployed", "deployment", "implementation", "discovery", "requirements", "prototype", "API", "APIs"] },
  mlops: { title: "MLOps engineering", terms: ["MLOps", "machine learning", "ML", "model", "models", "inference", "deployment", "Python", "Docker", "Kubernetes", "MLflow", "Kubeflow", "monitoring", "PyTorch", "TensorFlow", "pipeline", "pipelines"] },
  hybrid: { title: "Software, cloud and data engineering", terms: ["software", "cloud", "data", "engineering", "Python", "API", "APIs", "infrastructure", "pipelines", "deployment", "integration", "automation"] },
};

function score(text: string, terms: string[]): number {
  return terms.filter((term) => new RegExp(`(?<![\\p{L}\\p{N}_+#])${term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?![\\p{L}\\p{N}_+#])`, "iu").test(text)).length;
}

export function referenceSelection(profile: Profile, family: ReferenceFamily): { facts: Fact[]; skills: string[]; brief: string; selectionNote: string } {
  assertReferenceProfile(profile);
  if (!Object.hasOwn(families, family)) throw new Error("Unknown reference role family.");
  const { title, terms } = families[family];
  const ranked = profile.facts.filter((fact) => fact.text.trim())
    .map((fact, index) => ({ fact, index, score: score(`${fact.text}\n${fact.role ?? ""}`, terms) }))
    .sort((a, b) => b.score - a.score || a.index - b.index);
  const relevant = ranked.filter((item) => item.score > 0 || item.fact.category !== "experience");
  const hasOverlap = ranked.some((item) => item.score > 0);
  const facts = (hasOverlap ? relevant : ranked).slice(0, MAX_SELECTED_FACTS).map((item) => item.fact);
  const skills = profile.skills.map((skill, index) => ({ skill, index, score: score(skill, terms) }))
    .sort((a, b) => b.score - a.score || a.index - b.index).slice(0, MAX_SELECTED_SKILLS).map((item) => item.skill);
  return {
    facts, skills,
    brief: `Generic role focus: ${title}. Not a real opening or a claim of qualifications.`,
    selectionNote: `Deterministic source selection (not AI): ${facts.length} of ${profile.facts.length} supplied facts; ${skills.length} of ${profile.skills.length} supplied skills. ${hasOverlap ? "Exact role terms determine selection and ordering." : "No role-term overlap; supplied source context retained."} Wording is unchanged; no new qualifications were added.`,
  };
}
