import type { Job, Profile } from "../domain/types.js";
import { publicKeywordTags } from "../domain/keywords.js";
import type { GeminiProjection, GeminiSelection } from "../inference/gemini.js";
import { MAX_SELECTED_FACTS, MAX_SELECTED_SKILLS } from "./safety.js";

export function buildGeminiProjection(profile: Profile, job: Job): {
  projection: GeminiProjection;
  resolve: (selection: GeminiSelection) => { factIds: string[]; skills: string[] };
} {
  const facts = profile.facts.filter((fact) => profile.confirmed && fact.confirmed && fact.text.trim())
    .map((fact) => ({ source: fact.id, tags: publicKeywordTags(fact.text) }))
    .filter((fact) => fact.tags.length).slice(0, MAX_SELECTED_FACTS);
  const skills = (profile.confirmed ? profile.skills : [])
    .map((skill) => ({ source: skill, tags: publicKeywordTags(skill) }))
    .filter((skill) => skill.tags.length).slice(0, MAX_SELECTED_SKILLS);
  if (!facts.length) throw new Error("Gemini found no confirmed evidence in its fixed public technology vocabulary. Choose deterministic preparation explicitly; private text will not be sent instead.");
  const projection: GeminiProjection = {
    job: { tags: publicKeywordTags(`${job.title}\n${job.description}`, false) },
    facts: facts.map((fact, index) => ({ id: `f${index + 1}`, tags: fact.tags })),
    skills: skills.map((skill, index) => ({ id: `s${index + 1}`, tags: skill.tags })),
  };
  function resolveIds(ids: string[], prefix: "f" | "s", sources: { source: string }[]): string[] {
    if (!Array.isArray(ids) || new Set(ids).size !== ids.length) throw new Error("Gemini returned duplicate or invalid anonymous evidence IDs.");
    return ids.map((id) => {
      const index = sources.findIndex((_, index) => `${prefix}${index + 1}` === id);
      if (index < 0) throw new Error("Gemini returned an unknown anonymous evidence ID.");
      return sources[index].source;
    });
  }
  return { projection, resolve: (selection) => ({
    factIds: resolveIds(selection.factIds, "f", facts), skills: resolveIds(selection.skillIds, "s", skills),
  }) };
}
