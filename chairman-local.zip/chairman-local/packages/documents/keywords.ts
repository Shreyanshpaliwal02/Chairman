import { z } from "zod";
import { analyzeKeywords } from "../domain/keywords.js";
import type { Job, KeywordEvidence, Profile, ResumeDraft } from "../domain/types.js";

const MAX_KEYWORDS = 40;
const keywordSchema = z.array(z.string().min(1).max(200)).max(MAX_KEYWORDS);

function selectedKeywords(profile: Profile, job: Job, draft: ResumeDraft): KeywordEvidence[] {
  const selected = {
    ...profile,
    facts: profile.facts.filter((fact) => draft.factIds.includes(fact.id)),
    skills: draft.skills,
  };
  // Direct terms already occur in the visible facts/skills. Only useful synonyms merit another line.
  return analyzeKeywords(selected, job).supported.filter((item) => item.kind === "equivalent").slice(0, MAX_KEYWORDS);
}

export function addSelectedKeywords(profile: Profile, job: Job, draft: ResumeDraft): ResumeDraft {
  const keywords = selectedKeywords(profile, job, draft);
  return {
    ...draft,
    keywordTerms: keywords.map((item) => item.term),
    notes: [...draft.notes, ...keywords.map((item) =>
      `Relevant keyword "${item.term}": ${item.explanation} Selected evidence: ${[
        ...item.factIds.map((id) => `fact ${id}`),
        ...item.sourceSkills.map((skill) => `skill "${skill}"`),
      ].join("; ")}.`)],
  };
}

export function validateSelectedKeywords(profile: Profile, job: Job, draft: ResumeDraft, input: unknown): string[] {
  if (input === undefined) return [];
  const result = keywordSchema.safeParse(input);
  if (!result.success || new Set(result.data.map((term) => term.toLowerCase())).size !== result.data.length) {
    throw new Error("Invalid resume keywordTerms: expected bounded, unique keyword strings.");
  }
  const allowed = new Set(selectedKeywords(profile, job, draft).map((item) => item.term));
  if (result.data.some((term) => !allowed.has(term))) {
    throw new Error("Resume keyword is not an exact JD synonym supported by the selected confirmed facts or skills.");
  }
  return result.data;
}
