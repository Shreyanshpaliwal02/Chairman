# Source-preserving resumes

`importResume` accepts DOCX, UTF-8 TXT, and text-based PDF buffers (15 MiB maximum; PDF maximum 30 pages). It never opens a source path or changes an original file. All imported facts and the profile remain **unconfirmed**. Confirm contact details, skills, headings, employer/title/date associations and paragraph boundaries in the dashboard before preparing a packet. Ambiguous lines are retained as facts rather than rewritten. PDFs with columns, unusual reading order, or missing text layers need manual verification; image-only PDFs are rejected, not OCR-transcribed. Import does not infer work authorization or other application answers.

DOCX hyperlinks labeled `LinkedIn`, `GitHub`, `Portfolio`, `Website`, or `Profile` retain their valid absolute HTTPS targets even when the URL is not visible. Recognizable LinkedIn/GitHub profile targets are also recovered behind other labels. Targets come from Mammoth's parsed document relationships, without fetching them or reading external files; external file access and image reads are disabled during conversion. Non-HTTPS, credential-bearing, malformed and control-character targets are ignored, as are unrelated citation links. Links remain unconfirmed source data, not proof of ownership. Original visible text is still imported unchanged; recovered URLs supplement contact links without overwriting existing ones (20-link limit).

`selectResume(profile, job, "deterministic")` is explicitly **not AI**: exact source/JD terms and documented equivalent names determine ordering and selected skills. Notes identify the evidence; if no terms match, confirmed source context is retained and labeled as such. This is not a semantic fit score or an ATS guarantee.

`selectResume(profile, job, "local-ai")` allows only selection/ordering of existing confirmed fact IDs and exact profile skill strings. Source sentences, metadata, metrics and contacts are never model-written. Empty selections, duplicate/unknown IDs or skills, unconfirmed facts, extra JSON fields, tools, and incomplete or oversized output fail closed. JDs are untrusted data, never authority. Model failure produces an explicit error; select deterministic mode separately if desired.

The historical `"local-ai"` wire value now dispatches by `JAA_AI_PROVIDER`:
`ollama` (the default when absent) or `copilot`. **The wire value does not mean
processing is local when Copilot is selected.** Status includes `provider` and
`remote`; Copilot draft notes explicitly say “Copilot-assisted selection.”
Unsupported providers fail instead of falling back.

## Job-specific resumes from approved uploaded templates

`createTailoredResume(profile, job, base, outDir, mode = "deterministic")` accepts
`base: { id, label, sha256, format: "pdf" | "docx", bytes: Buffer, approved }`
and returns `{ draft, artifacts, tailoring, content }`. It creates **new** PDF and
DOCX artifacts rather than forwarding the uploaded file. Neither input is
modified; no imported confirmation flag is changed. Both the canonical profile
and base must be approved. Confirmed name/email must match the safely imported
base. SHA-256, file signatures, import size/page/text/ZIP bounds, sample/reference
stamps, no-AI restrictions and current job eligibility are checked before export.

Only confirmed canonical facts and profile skills can become claims. Normalized
full-sentence overlaps with the base influence ties **after JD relevance**, not
candidate eligibility. Unknown base wording, new achievements, instructional
text and importer-generated IDs never become source facts or model candidates.
The template is a source-emphasis reference, **not a pixel-perfect layout
template**. Both formats use fresh single-column layouts and conventional
section order. PDF columns and paragraph/metadata extraction may be ambiguous;
notes explicitly identify these restrictions and unmatched source paragraphs.

Selection is bounded to 12 experience bullets, one relevant verbatim canonical
summary (if available), three education facts, two relevant publications and
24 relevant canonical skills. No target job title, invented professional summary,
rewritten metrics or inferred tenure is added. Relevant current employment
groups retain representation; role/employer/date groups stay contiguous, with
unchanged metadata. Overlong selected paragraphs fail with a request to shorten
and reconfirm source bullets, rather than being silently truncated. Missing and
transferable keywords are review notes only. Rendered synonyms pass the existing
selected-evidence keyword validator.

Deterministic tailoring is explicitly **not AI**, makes no model/network call and
has zero API cost. AI receives only the bounded canonical candidate list,
eligible exact skill strings and untrusted JD, never the uploaded document or
separate contact/answer fields. Its strict selection contract remains unchanged.
Ollama requires local weight verification; Copilot requires separate remote
processing consent, stored OAuth and exact-model availability. Invalid/unavailable AI fails, without
silent deterministic fallback; an incomplete selection below eight experience
bullets (or the available relevant count, if smaller) also fails. Required
canonical summary/education/current-role context is retained by local code.

`content` is a detached, recursively frozen snapshot of the exact rendered name,
email, phone, location, links, canonical facts (in rendered order), skills and
keyword terms. Persist it as `Packet.resumeContent`; later profile edits cannot
rewrite the historical review content. The returned `draft.mode` is
`"jd-tailored"` for packet persistence only. Rendering internally uses the
validated `"deterministic"` or `"local-ai"` draft; the existing generic selection
and document validators still reject `"jd-tailored"`.

`tailoring.jobDescriptionHash` is **`jobHash(job)` from
`packages/domain/matching.ts`**, not a hash of description text alone. Provenance
also records the approved base ID/label/SHA, engine, supported selected-evidence
terms, missing/transferable terms and selection limitations.
`validateTailoredContent(profile, job, resultOrPacket): void` is exported for
preparation/claim-time validation: it rechecks policy, canonical snapshot,
selection, rendered ordering/bounds, selected keyword provenance, job hash and
content-addressed PDF/DOCX metadata. For packets it additionally verifies
`profileHash`, `profileVersion`, `jobHash` and `variantId`. **It does not read
artifact files or establish that an upload is still approved**: callers must
recheck actual artifact hashes, approved base ID/label/SHA, standing authorization
and provider/form/application gates before claiming or submitting. Persisted
review snapshots should be displayed independently of the current profile; using
a changed current profile to validate an old packet intentionally fails.

## Evidence-backed JD keywords

`analyzeKeywords(profile, job)` is exported from `packages/domain/keywords.ts`. It returns:

- `supported`: exact JD terms with `kind: "direct"` or `"equivalent"`, their confirmed `factIds`, original `sourceSkills`, and an explanation.
- `transferable`: related technologies for review/learning only, **not** equivalents or possessed skills.
- `gaps`: recognized JD terms without confirmed direct, equivalent, or related evidence. Transferable terms remain unverified but are listed separately, not duplicated in gaps.

The deterministic vocabulary and directional transfer map live beside the analyzer. True equivalents include Kubernetes/K8s, IaC/infrastructure-as-code/infrastructure as code, AWS/Amazon Web Services, and PostgreSQL/Postgres. Spark → Databricks, Spark → PySpark, AWS → Azure, and Docker → Kubernetes are **transferable only**; Terraform does not automatically become IaC, and separate CI and delivery mentions do not automatically become CI/CD. A vendor name in an employer heading is not proof of using its platform.

Only JD title/description supply requested terms, preserving their exact spelling and first occurrence. Matching uses Unicode-aware token boundaries and prefers whole product names (React Native is not React; Azure DevOps is not Azure). The vocabulary is deliberately finite; unknown terms are considered only when they exactly match a supplied skill. This is not exhaustive JD extraction, semantic verification, a proficiency assessment, or an ATS ranking guarantee.

Evidence comes only from affirmative fact **text** marked `confirmed: true`, or skills belonging to a confirmed profile. Contacts, employer/title metadata, links and answers supply no evidence. Negated, hypothetical, instructional and learning-only mentions are conservatively excluded. User confirmation and review still matter: deterministic phrase filters cannot establish every sentence's meaning. JD instructions cannot create source evidence, and ease of learning never establishes experience.

After either selection mode, local code adds at most 40 useful equivalent terms supported by the **selected** facts/skills, with provenance in draft notes. Direct terms already visible in source text are not repeated. The model contract remains strictly `{ factIds, skills }`; model-provided `keywordTerms` are rejected. `createDocuments` independently recomputes selected evidence and rejects tampered, unsupported, transferable, duplicate or non-JD terms. Notes are never rendered as claims. Old drafts without `keywordTerms` render unchanged. When present, a visible, conventional **Relevant keywords** section contains the legitimate synonyms; there is no hidden text or gap stuffing.

## Local reference drafts (not applications)

`createReferenceDocuments(profile, family, outDir): Promise<Artifact[]>` is a separate export for `software`, `cloud`, `data`, `forward-deployed`, `mlops`, and `hybrid`. It can render an **unconfirmed** imported profile solely as a local review copy. It neither calls a model nor fabricates a company/opening: a clearly labeled, fixed generic role brief supplies context, not candidate qualifications.

This dedicated path validates the full profile's structure, bounded text, unique IDs/skills, and control characters without changing confirmation flags. Deterministic exact role terms rank supplied source facts within conventional sections; relevant experience and non-experience context are retained (up to 80 facts). If nothing overlaps, source context is retained and the fallback is labeled. Supplied skills are reordered, not expanded (up to 80). Sentences, official employers/titles/dates and metrics remain verbatim. No synonyms or inferred platform skills are added to reference drafts.

Both PDF and DOCX visibly say **REFERENCE DRAFT - verify facts before use**, include a source-review warning and selection explanation, and identify themselves as local review copies, not applications or approvals. Overflow PDF pages and the DOCX footer repeat the stamp. Unsupported glyphs fail rather than lose source text. Artifacts use the same private, immutable `resume-<sha256>.pdf`/`.docx` filenames and hashes as the ordinary renderer.

The reference function returns artifacts only, never an application draft, job, packet, or approval. It does not modify the profile or any application store. There is no `allowUnconfirmed`/bypass option on application APIs: `selectResume`, `validateResumeSelection`, and `createDocuments` still require confirmed evidence, valid application modes and all applicable policy gates. Reimporting a reference copy also leaves its facts/profile unconfirmed.

## GitHub Copilot inference (hosted; explicit consent required)

`packages/inference/index.ts` exports `getCopilotStatus()` and
`copilotSelect(system, user, schema)`. The application uses the official
`@github/copilot-sdk` package (installed version **1.0.13**, bundled runtime
**1.0.83**), not this chat's internal service or credentials. Node.js
`^20.19.0 || >=22.12.0` is required by this SDK; the application's stricter Node
requirement still applies.

| Variable | Default | Meaning |
| --- | --- | --- |
| `JAA_AI_PROVIDER` | `ollama` | Set to `copilot` explicitly for hosted processing. |
| `JAA_COPILOT_MODEL` | `gpt-6-astra` | Exact SDK inventory ID; never silently replaced with another model. `auto`, provider aliases and URLs are rejected. |
| `JAA_ALLOW_COPILOT_REMOTE` | unset | Must equal `1` after the user explicitly acknowledges remote data processing and possible Copilot allowance/premium usage. |

**Remote data processing is not local inference or a free API.** Bounded job
title/description, confirmed fact text and its employer/role/date metadata, and
exact confirmed skills are sent to GitHub Copilot's hosted processing. Facts may
themselves contain personal information. Separate contact/answer fields and
uploaded document bytes are not sent. Review GitHub Copilot's applicable data,
retention, model and billing policies. Setting the consent flag authorizes
subsequent application inference; leave it unset until the user acknowledges
these implications. This integration does not infer consent from a subscription,
an installed CLI, this chat, or an authenticated session.

Without consent, status is `available: false`, `remote: true`,
`consentRequired: true`, and no SDK process is started. Once consent is present,
status uses SDK `getAuthStatus()` and `listModels()` only (no model prompt), and
caches verification for about 60 seconds. Authenticated **stored user OAuth**
and the **exact** configured model ID with enabled policy are required.
Unavailable models, unaccepted terms, subscription/organization restrictions,
missing OAuth and unverifiable SDK responses remain explicit failures. The
application never signs in or accepts terms for the user. This chat using
GPT-6 Astra does **not** prove the user's SDK can access `gpt-6-astra`.

The SDK bundles a headless runtime, not an interactive login executable; in
1.0.13 there is no `node_modules/.bin/copilot`, and the runtime does not support
`--help` or an interactive login command. If OAuth is missing, the user can
manually run the official CLI through npm (it may offer to download the CLI):

```sh
npm exec --package=@github/copilot -- copilot login
# After reviewing hosted processing and usage costs, explicitly opt in:
JAA_AI_PROVIDER=copilot JAA_COPILOT_MODEL=gpt-6-astra JAA_ALLOW_COPILOT_REMOTE=1 npm start
```

The documented login command is [`copilot login`](https://docs.github.com/en/copilot/how-tos/copilot-cli/set-up-copilot-cli/authenticate-copilot-cli).
This package neither reads token files manually nor supplies a token. It uses
SDK `useLoggedInUser: true`, excludes ambient token/BYOK/endpoint/CLI override
variables from its child environment, and rejects non-user authentication.
The SDK may internally discover GitHub CLI credentials; those are not accepted
by the integration. Do not borrow tokens from another application or chat.
Login is separate from consenting to processing resume data.

### Inference-only boundaries

- Every request gets an empty, private (`0700`) working directory under a fresh
  `.jaa-copilot-*` application workspace, with a separate private session-state
  directory. It is never given the source checkout as its working directory.
  Ordinary cleanup deletes this workspace; an interrupted host process may
  leave a private directory for the owner to remove.
- No built-in/custom/MCP tools are available. All permission requests and
  pre-tool callbacks are denied. No MCP servers, custom agents, plugins,
  skills, repository/user/organization instructions, file hooks, git context,
  session store, cross-session memory, embedding retrieval, extension tools,
  session export or automatic compaction are enabled. The system message is
  replaced, not appended. Source/JD strings remain untrusted data.
- SDK 1.0.13's `mode: "empty"` disables the OS-keychain OAuth provider. To use
  stored OAuth correctly, this single-user local application explicitly
  disables the above features in `copilot-cli` mode instead. Do not repurpose
  it as a multi-user server or loosen the session options.
- Inputs, schema and JSON output are bounded. The existing strict selection
  validator independently rejects extra keys, duplicates, unsupported IDs,
  unconfirmed claims or non-source skill strings. No model prose is rendered.
- Only one inference is admitted per application process, including setup and
  cleanup. Parallel callers receive an explicit busy error; there is no hidden
  queue. Inference has a 120-second deadline, status a 15-second deadline, and
  timed-out sessions are aborted and disconnected. Session data is deleted and
  the owned SDK process is stopped (force-stopped if graceful shutdown hangs).
- An official SDK `CopilotRequestHandler` guard permits at most **one**
  model-layer HTTP request and verifies its exact `model` field. It blocks
  runtime-internal retries, fallback models, background summaries and WebSocket
  inference. It delegates unchanged requests to the SDK's standard transport;
  it does not replace endpoints, authentication or providers. Errors abort
  rather than trigger repair prompts. Failed cleanup blocks later inference
  until application restart.
- The package does not log prompts, replies or account/token details. Runtime
  logging and session telemetry are disabled; GitHub's hosted processing and
  retention policies still apply. These are inference capability restrictions,
  not a filesystem sandbox against a compromised SDK or local OS owner.

The integration tests use mocked SDK clients and fictional text only. They
perform no login, real model inventory check or paid inference.

## Ollama setup (manual; no installation/download is performed by the application)

Set `OLLAMA_NO_CLOUD=1` **in the environment that starts the Ollama daemon**, and restart that daemon if it was already running. Also set it for the local application. An application environment variable alone cannot configure or attest the daemon.

```sh
OLLAMA_NO_CLOUD=1 ollama serve
# In a separate terminal, explicitly install the local candidate if wanted:
OLLAMA_NO_CLOUD=1 ollama pull qwen3:4b
# Start the app with the same cloud-disable setting:
OLLAMA_NO_CLOUD=1 npm start
```

For an already installed Ollama desktop service, configure its daemon environment through its supported local setup before starting the app. Do not run a second daemon on the same port.

Optional application settings:

| Variable | Default | Restrictions |
| --- | --- | --- |
| `JAA_OLLAMA_URL` | `http://127.0.0.1:11434` | Numeric `127.0.0.1` or `[::1]`, HTTP, no credentials/path/query/fragment. Redirects are rejected. |
| `JAA_OLLAMA_MODEL` | `qwen3:4b` | Simple local model/tag name only; cloud, remote and provider names/URLs are rejected. No automatic downloads. |
| `OLLAMA_NO_CLOUD` | unset (AI disabled) | Must equal `1`; set it independently for the Ollama daemon and app. |

No cloud fallback exists. `/api/tags` must contain the exact configured model with a digest, nonzero local GGUF weights, and quantization metadata; `/api/show` must verify weight metadata and text-completion capability without remote/cloud settings. A listening port is insufficient. A missing runner, missing model, or failed verification returns `available: false` with a reason. Even successful status includes a notice that these APIs cannot attest the daemon's cloud-disable setting; configure the daemon separately. Status verifies installed capability, not generation quality, current free memory, or future success. A compromised local daemon is outside this client's trust boundary; do not expose Ollama remotely.

Only confirmed fact candidates, exact skill strings, and bounded JD text reach the loopback model. Contact fields and application answers are not included separately (source facts themselves may contain sensitive information). No tools, browsing, cloud providers, or employer requests are available. Prompts, responses and documents are not logged by this package. Review the daemon's own logging/storage settings.

## Export and policy

`createDocuments` revalidates selected IDs/skills, optional keyword terms and policy before generating a single-column, visible-text PDF and DOCX with conventional headings, confirmed contact information, exact source facts and original role/employer/date metadata. Fixed heading order is preserved; selected ordering applies within each section. Source text is not paraphrased. `pdfjs-dist` is a **runtime dependency**, including its packaged Liberation Sans fonts for embedding in PDFs. Unsupported font glyphs fail rather than silently disappear; additional scripts require a reviewed font change. The package uses PDFKit's fontkit-backed font object to verify glyph coverage.

Both deterministic and AI packets are blocked for prohibited AI policies and detected own-words/no-AI restrictions. Detection is conservative, not exhaustive; employer-policy review remains required.

Output basenames are `resume-<sha256>.pdf` / `.docx`, never derived from a company, candidate or job path. Files are written exclusively inside the provided directory, with `0400` permissions after writing; existing different bytes and symlinks are never overwritten. SHA-256 and byte length describe the actual artifact bytes. These are immutable application artifacts, not filesystem-level protection against their owner; approvals must recheck hashes. Document rendering itself sends no resume data to an external service; Copilot selection sends the bounded inputs described above only after explicit remote-processing consent.

Exports: `importResume`, `getAiStatus`, `selectResume`, `createDocuments`, `createReferenceDocuments`, `createTailoredResume`; helpers: `parseResumeText`, `extractPdfText`, `hasNoAiRestriction`, `validateResumeSelection`, `validateTailoredContent`. Tailoring types: `TailoringBase`, `TailoredResumeResult`. The independent domain export is `analyzeKeywords`.
