import { createHash } from "node:crypto";
import { constants } from "node:fs";
import { lstat, mkdir, open, realpath, unlink } from "node:fs/promises";
import { createRequire } from "node:module";
import { dirname, join, resolve } from "node:path";
import { Document, Footer, HeadingLevel, Packer, Paragraph, TextRun } from "docx";
import PDFDocument from "pdfkit";
import type { Artifact, Fact, Job, Profile, ReferenceFamily, ResumeDraft } from "../domain/types.js";
import { assertDocumentPolicy, validateResumeSelection } from "./safety.js";
import { validateSelectedKeywords } from "./keywords.js";
import { REFERENCE_REVIEW, REFERENCE_WARNING, referenceSelection } from "./reference.js";

type Block = { kind: "name" | "contact" | "heading" | "metadata" | "fact" | "skills" | "warning"; text: string };
const sections: { category: Fact["category"]; title: string }[] = [
  { category: "summary", title: "Professional Summary" },
  { category: "experience", title: "Experience" },
  { category: "education", title: "Education" },
  { category: "publication", title: "Publications" },
];

function resumeBlocks(profile: Profile, selected: Fact[], skills: string[], keywordTerms: string[] = []): Block[] {
  const blocks: Block[] = [];
  if (profile.name.trim()) blocks.push({ kind: "name", text: profile.name });
  const contact = [profile.email, profile.phone, profile.location].filter((text) => text.trim());
  if (contact.length) blocks.push({ kind: "contact", text: contact.join(" | ") });
  for (const value of Object.values(profile.links)) if (value.trim()) blocks.push({ kind: "contact", text: value });
  for (const section of sections) {
    const entries = selected.filter((fact) => fact.category === section.category);
    if (entries.length) {
      blocks.push({ kind: "heading", text: section.title });
      let previousMetadata = "";
      for (const fact of entries) {
        const metadata = [fact.role, fact.employer, fact.dates].filter((value) => value?.trim()).join(" | ");
        if (metadata && metadata !== previousMetadata) blocks.push({ kind: "metadata", text: metadata });
        previousMetadata = metadata;
        blocks.push({ kind: "fact", text: fact.text });
      }
    }
    if (section.category === "summary") {
      if (skills.length) blocks.push({ kind: "heading", text: "Skills" }, { kind: "skills", text: skills.join(", ") });
      if (keywordTerms.length) blocks.push({ kind: "heading", text: "Relevant keywords" }, { kind: "skills", text: keywordTerms.join(", ") });
    }
  }
  return blocks;
}

function embeddedFonts(): { regular: string; bold: string } {
  const require = createRequire(import.meta.url);
  const root = dirname(require.resolve("pdfjs-dist/package.json"));
  return {
    regular: join(root, "standard_fonts", "LiberationSans-Regular.ttf"),
    bold: join(root, "standard_fonts", "LiberationSans-Bold.ttf"),
  };
}

async function renderPdf(blocks: Block[]): Promise<Buffer> {
  const fonts = embeddedFonts();
  const pdf = new PDFDocument({
    size: "A4",
    margins: { top: 48, bottom: 48, left: 48, right: 48 },
    info: { Title: blocks[0]?.kind === "warning" ? "Reference draft - local review only" : "Resume", Author: "", Creator: "Local job application assistant" },
    compress: true,
    bufferPages: true,
  });
  const chunks: Buffer[] = [];
  const finished = new Promise<Buffer>((accept, reject) => {
    pdf.on("data", (chunk: Buffer) => chunks.push(chunk));
    pdf.on("end", () => accept(Buffer.concat(chunks)));
    pdf.on("error", reject);
  });
  try {
    pdf.registerFont("ResumeRegular", fonts.regular);
    pdf.registerFont("ResumeBold", fonts.bold);
    for (const block of blocks) {
      const bold = ["name", "heading", "metadata", "warning"].includes(block.kind);
      pdf.font(bold ? "ResumeBold" : "ResumeRegular");
      // PDFKit's embedded font wraps fontkit; fail instead of silently drawing missing glyphs.
      const font = (pdf as unknown as { _font: { font: { hasGlyphForCodePoint(code: number): boolean } } })._font.font;
      for (const char of block.text) {
        if (!/\s/u.test(char) && !font.hasGlyphForCodePoint(char.codePointAt(0)!)) {
          throw new Error(`The bundled PDF font cannot represent U+${char.codePointAt(0)!.toString(16).toUpperCase()}. No lossy resume was exported.`);
        }
      }
      const size = block.kind === "name" ? 21 : block.kind === "heading" ? 12 : 10.5;
      pdf.fontSize(size).fillColor("#111111");
      if (block.kind === "heading") {
        if (pdf.y + 65 > pdf.page.height - pdf.page.margins.bottom) pdf.addPage();
        pdf.moveDown(0.7);
      }
      if (block.kind === "metadata" && pdf.y + 42 > pdf.page.height - pdf.page.margins.bottom) pdf.addPage();
      pdf.text(block.text, { lineGap: 2.5, paragraphGap: 4, align: "left" });
      if (block.kind === "name") pdf.moveDown(0.15);
      if (block.kind === "fact") pdf.moveDown(0.25);
    }
    if (blocks[0]?.kind === "warning") {
      const pages = pdf.bufferedPageRange();
      for (let page = pages.start + 1; page < pages.start + pages.count; page++) {
        pdf.switchToPage(page);
        pdf.font("ResumeBold").fontSize(9).fillColor("#111111")
          .text(REFERENCE_WARNING, 48, 24, { lineBreak: false });
      }
    }
    pdf.end();
  } catch (error) {
    pdf.destroy(error instanceof Error ? error : new Error("PDF rendering failed."));
  }
  return finished;
}

async function renderDocx(blocks: Block[]): Promise<Buffer> {
  const paragraphs = blocks.map((block) => new Paragraph({
    heading: block.kind === "name" ? HeadingLevel.TITLE : block.kind === "heading" ? HeadingLevel.HEADING_1 : undefined,
    keepNext: block.kind === "heading" || block.kind === "metadata" || block.kind === "name" || block.kind === "warning",
    spacing: { before: block.kind === "heading" ? 220 : 0, after: block.kind === "fact" ? 100 : 70 },
    children: block.text.split("\n").map((line, index) => new TextRun({
      text: line,
      break: index ? 1 : undefined,
      bold: block.kind === "metadata" || block.kind === "heading" || block.kind === "warning",
      size: block.kind === "name" ? 42 : block.kind === "heading" ? 24 : 21,
      color: "111111",
    })),
  }));
  return Packer.toBuffer(new Document({
    creator: "Local job application assistant",
    title: blocks[0]?.kind === "warning" ? "Reference draft - local review only" : "Resume",
    styles: { default: { document: { run: { font: "Arial", size: 21, color: "111111" }, paragraph: { spacing: { line: 260 } } } } },
    sections: [{
      properties: { page: { margin: { top: 960, bottom: 960, left: 960, right: 960 } } },
      footers: blocks[0]?.kind === "warning" ? { default: new Footer({ children: [new Paragraph({
        children: [new TextRun({ text: REFERENCE_WARNING, bold: true, size: 18, color: "111111" })],
      })] }) } : undefined,
      children: paragraphs,
    }],
  }));
}

async function persistArtifact(directory: string, format: Artifact["format"], content: Buffer): Promise<Artifact> {
  const sha256 = createHash("sha256").update(content).digest("hex");
  const filename = `resume-${sha256}.${format}`;
  const destination = join(directory, filename);
  let handle;
  try {
    handle = await open(destination, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
    const existing = await open(destination, constants.O_RDONLY | constants.O_NOFOLLOW);
    try {
      if (!(await existing.stat()).isFile()) throw new Error("Artifact path is not a regular file.");
      const data = await existing.readFile();
      if (!data.equals(content)) throw new Error("An immutable artifact was modified; refusing to overwrite it.");
    } finally { await existing.close(); }
    return { format, filename, sha256, bytes: content.length };
  }
  try {
    await handle.writeFile(content);
    await handle.sync();
    await handle.chmod(0o400);
  } catch (error) {
    await handle.close();
    await unlink(destination);
    throw error;
  }
  await handle.close();
  return { format, filename, sha256, bytes: content.length };
}

export async function createDocuments(profile: Profile, job: Job, draft: ResumeDraft, outDir: string): Promise<Artifact[]> {
  assertDocumentPolicy(job);
  const verified = validateResumeSelection(profile, { factIds: draft.factIds, skills: draft.skills }, draft.mode);
  verified.keywordTerms = validateSelectedKeywords(profile, job, verified, draft.keywordTerms);
  const facts = new Map(profile.facts.map((fact) => [fact.id, fact]));
  return writeDocuments(resumeBlocks(profile, verified.factIds.map((id) => facts.get(id)!), verified.skills, verified.keywordTerms), outDir);
}

export async function createReferenceDocuments(profile: Profile, family: ReferenceFamily, outDir: string): Promise<Artifact[]> {
  const selected = referenceSelection(profile, family);
  const blocks: Block[] = [
    { kind: "warning", text: REFERENCE_WARNING },
    { kind: "contact", text: REFERENCE_REVIEW },
    { kind: "contact", text: selected.brief },
    { kind: "contact", text: selected.selectionNote },
    ...resumeBlocks(profile, selected.facts, selected.skills),
  ];
  return writeDocuments(blocks, outDir);
}

async function writeDocuments(blocks: Block[], outDir: string): Promise<Artifact[]> {
  if (typeof outDir !== "string" || !outDir.trim() || outDir.includes("\0")) throw new Error("An output directory is required.");
  const destination = resolve(outDir);
  // Render both formats before writing either; a rendering failure must not leave a partial packet.
  const [pdf, docx] = await Promise.all([renderPdf(blocks), renderDocx(blocks)]);
  await mkdir(destination, { recursive: true, mode: 0o700 });
  const info = await lstat(destination);
  if (!info.isDirectory() || info.isSymbolicLink()) throw new Error("The output directory must be a real directory, not a symlink.");
  const directory = await realpath(destination);
  return [
    await persistArtifact(directory, "pdf", pdf),
    await persistArtifact(directory, "docx", docx),
  ];
}
