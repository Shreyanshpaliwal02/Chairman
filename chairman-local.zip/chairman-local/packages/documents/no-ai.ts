/** Detects no-AI / own-words application rules. Dependency-free so the Chrome page script stays small. */
export function hasNoAiRestriction(text: string): boolean {
  const normalized = text
    .replace(/&#(?:x([0-9a-f]+)|([0-9]+));/gi, (_, hex: string, decimal: string) => {
      const code = Number.parseInt(hex || decimal, hex ? 16 : 10);
      return code > 0 && code <= 0x10ffff ? String.fromCodePoint(code) : " ";
    })
    .replace(/&(?:nbsp|ensp|emsp);/gi, " ")
    .replace(/<[^>]*>/g, " ")
    .replace(/[’‘]/g, "'")
    .replace(/\s+/g, " ")
    .toLowerCase();
  const ai = "(?:ai\\b|artificial intelligence|chatgpt\\b|large language models?\\b|llms?\\b)";
  return [
    /\b(?:your|their|one's|my|our|applicant's|candidate's)\s+own[- ]words\b/,
    /\bown[- ]words\b/,
    /\b(?:human[- ]authored|human[- ]written)\b/,
    /\b(?:written|completed|prepared)\s+(?:entirely|solely|only)\s+by\s+(?:you|the applicant|the candidate)\b/,
    new RegExp(`\\bno[- ]+(?:(?:use of|generative)[- ]+)*${ai}`),
    new RegExp(`\\b(?:do not|don't|must not|mustn't|cannot|can't|may not|never|not to)\\b[^.!?]{0,100}\\b(?:use|used|using|submit|accept|generate|generated|employ)\\b[^.!?]{0,100}${ai}`),
    new RegExp(`\\b(?:not|never|haven't|hasn't)\\b[^.!?]{0,80}\\b(?:used|written|generated|produced|prepared|assisted)\\b[^.!?]{0,80}${ai}`),
    new RegExp(`\\b(?:without|not using)\\b[^.!?]{0,100}${ai}`),
    new RegExp(`${ai}[^.!?]{0,100}\\b(?:prohibited|forbidden|not (?:allowed|permitted|accepted|to be used)|disallowed|rejected|disqualif(?:ied|ication|ying)|invalidate)\\b`),
    new RegExp(`\\b(?:prohibit|forbid|disallow|reject|ban)(?:s|ted|ned|ed)?\\b[^.!?]{0,100}${ai}`),
  ].some((pattern) => pattern.test(normalized));
}
