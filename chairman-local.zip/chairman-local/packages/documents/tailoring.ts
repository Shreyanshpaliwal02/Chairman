import { createHash } from "node:crypto";
import { isDeepStrictEqual } from "node:util";
import { z } from "zod";
import { analyzeKeywords } from "../domain/keywords.js";
import { digest, jobHash, matchJob } from "../domain/matching.js";
import type { Artifact, Fact, Job, Packet, Profile, ResumeDraft, ResumeTailoring } from "../domain/types.js";
import { importResume } from "./import.js";
import { addSelectedKeywords, validateSelectedKeywords } from "./keywords.js";
import { createDocuments } from "./render.js";
import { assertConfirmedProfile, assertDocumentPolicy, validateResumeSelection } from "./safety.js";
import { selectResume } from "./selection.js";

export interface TailoringBase {
  id: string;
  label: string;
  sha256: string;
  format: "pdf" | "docx";
  bytes: Buffer;
  approved: boolean;
}
export interface TailoredResumeResult {
  draft: ResumeDraft;
  artifacts: Artifact[];
  tailoring: ResumeTailoring;
  content: NonNullable<Packet["resumeContent"]>;
}

const MAX_EXPERIENCE = 12;
const MAX_CONTENT_CHARS = 10_000;
const categoryOrder: Fact["category"][] = ["summary", "experience", "education", "publication"];
const sample = /REFERENCE\s+DRAFT|verify facts before use|Sample Applicant|applicant@example\.test/i;
const normalize = (text: string): string => text.normalize("NFKC").toLowerCase()
  .replace(/[’‘]/g, "'").replace(/[“”]/g, '"').replace(/[–—]/g, "-")
  .replace(/[•●▪◦]/g, " ").replace(/\s+/g, " ").trim();
const stopWords = new Set("a an and are as at be by for from in is it of on or our that the their this to was we will with you your engineer engineering experience years team work".split(" "));
const tokens = (text: string): Set<string> => new Set((normalize(text).match(/[\p{L}\p{N}][\p{L}\p{N}+#.-]*/gu) ?? [])
  .map((term) => term.replace(/[.-]+$/, "")).filter((term) => term.length > 1 && !stopWords.has(term)));
const groupKey = (fact: Fact): string => JSON.stringify([fact.category, fact.employer ?? "", fact.role ?? "", fact.dates ?? ""]);
const employerKey = (fact: Fact): string => fact.employer?.trim() ? JSON.stringify([fact.category, fact.employer]) : groupKey(fact);
const current = (fact: Fact): boolean => /\b(?:present|current|now|ongoing)\b/i.test(fact.dates ?? "");

function assertTailoringPolicy(profile: Profile, job: Job): void {
  assertConfirmedProfile(profile);
  assertDocumentPolicy(job);
  if (!profile.name.trim() || !profile.email.trim()) throw new Error("A confirmed name and email are required for tailoring.");
  if (sample.test(JSON.stringify(profile))) throw new Error("Reference/sample profiles cannot be used for an application.");
  const match = matchJob(profile, job);
  if (!match.eligible) throw new Error(match.blockers.join(" "));
}

function sourceText(profile: Pick<Profile, "name" | "email" | "phone" | "location" | "links" | "facts" | "skills">): string {
  return [profile.name, profile.email, profile.phone, profile.location, ...Object.values(profile.links),
    ...profile.facts.flatMap((fact) => [fact.text, fact.role ?? "", fact.employer ?? "", fact.dates ?? ""]), ...profile.skills].join("\n");
}

async function readBase(base: TailoringBase, profile: Profile): Promise<Profile> {
  if (!base || base.approved !== true) throw new Error("Approve the uploaded base resume before tailoring.");
  if (typeof base.id !== "string" || !base.id.trim() || base.id.length > 200
    || typeof base.label !== "string" || !base.label.trim() || base.label.length > 500
    || /[\u0000-\u001f\u007f]/u.test(base.id + base.label)) throw new Error("Invalid base resume identity or label.");
  if (!Buffer.isBuffer(base.bytes) || !base.bytes.length || base.bytes.length > 15 * 1024 * 1024) {
    throw new Error("Base resume must be a nonempty file of at most 15 MiB.");
  }
  if (!/^[a-f0-9]{64}$/.test(base.sha256) || createHash("sha256").update(base.bytes).digest("hex") !== base.sha256) {
    throw new Error("Base resume SHA-256 does not match the approved bytes.");
  }
  if ((base.format !== "pdf" && base.format !== "docx")
    || (base.format === "pdf" && base.bytes.subarray(0, 5).toString("ascii") !== "%PDF-")
    || (base.format === "docx" && !base.bytes.subarray(0, 4).equals(Buffer.from([0x50, 0x4b, 0x03, 0x04])))) {
    throw new Error("Base resume format does not match its PDF/DOCX file signature.");
  }
  // Import enforces text/page/ZIP bounds; imported IDs, claims and confirmation flags are never adopted.
  const imported = await importResume(base.bytes, base.format);
  const text = sourceText(imported);
  if (sample.test(text)) throw new Error("Reference/sample drafts cannot be used as an application template.");
  if (text.trim().length < 80) throw new Error("Base resume has too little extractable text for reliable tailoring.");
  if (!normalize(text).includes(normalize(profile.name)) || imported.email.trim().toLowerCase() !== profile.email.trim().toLowerCase()) {
    throw new Error("Base resume name/email do not match the confirmed profile, or cannot be safely extracted.");
  }
  return imported;
}

type Ranked = { fact: Fact; score: number; matches: string[]; basePosition: number; index: number };
const compare = (a: Ranked, b: Ranked): number => b.score - a.score || a.basePosition - b.basePosition || a.index - b.index;

function rankedFacts(profile: Profile, job: Job, baseText: string): Ranked[] {
  const jdTerms = tokens(`${job.title}\n${job.description}`.slice(0, 100_000));
  const titleTerms = tokens(job.title);
  const supported = analyzeKeywords(profile, job).supported;
  return profile.facts.filter((fact) => fact.confirmed && fact.text.trim()).map((fact, index) => {
    const terms = tokens(fact.text);
    const matches = [...terms].filter((term) => jdTerms.has(term));
    const roleMatches = [...tokens(fact.role ?? "")].filter((term) => titleTerms.has(term));
    const keywords = supported.filter((item) => item.factIds.includes(fact.id));
    const position = baseText.indexOf(normalize(fact.text));
    return { fact, index, matches, score: 8 * keywords.length + matches.length + roleMatches.length,
      basePosition: position < 0 ? Number.POSITIVE_INFINITY : position };
  }).sort(compare);
}

function candidates(ranked: Ranked[]): { selected: Ranked[]; required: Set<string>; notes: string[] } {
  const notes: string[] = [];
  const experience = ranked.filter((item) => item.fact.category === "experience");
  const relevant = experience.filter((item) => item.score > 0);
  const pool = relevant.length ? relevant : experience;
  const required = new Set<string>();
  const roles = new Set<string>();
  for (const item of pool.filter((item) => current(item.fact))) {
    const key = groupKey(item.fact);
    if (!roles.has(key)) { required.add(item.fact.id); roles.add(key); }
  }
  if (required.size > MAX_EXPERIENCE) throw new Error("Too many relevant current roles for a concise resume. Review the canonical employment groups.");
  const selected = pool.filter((item) => required.has(item.fact.id));
  for (const item of pool) if (selected.length < MAX_EXPERIENCE && !required.has(item.fact.id)) selected.push(item);
  const summary = ranked.filter((item) => item.fact.category === "summary" && item.score > 0).slice(0, 1);
  const education = ranked.filter((item) => item.fact.category === "education").slice(0, 3);
  const publications = ranked.filter((item) => item.fact.category === "publication" && item.score > 0).slice(0, 2);
  for (const item of [...summary, ...education]) required.add(item.fact.id);
  selected.push(...summary, ...education, ...publications);
  if (!selected.length) selected.push(ranked[0]);
  selected.sort(compare);
  if (!relevant.length) notes.push("No directly relevant experience bullets were identified; bounded confirmed employment context is retained, not a claim of fit.");
  if (!summary.length) notes.push("No relevant confirmed summary sentence was available; no freeform professional summary or target-title claim was invented.");
  for (const item of selected) {
    notes.push(`${item.fact.id}: ${item.matches.length ? `source/JD overlap: ${item.matches.slice(0, 10).join(", ")}` : "confirmed source context"}; JD relevance score ${item.score}${Number.isFinite(item.basePosition) ? "; normalized base wording overlap used only to break relevance ties" : ""}${current(item.fact) && required.has(item.fact.id) ? "; retained to represent a relevant current employment group" : ""}.`);
  }
  return { selected, required, notes };
}

function orderedFacts(ranked: Ranked[], ids: string[]): Fact[] {
  const preference = new Map(ids.map((id, index) => [id, index]));
  const selected = ranked.filter((item) => preference.has(item.fact.id))
    .sort((a, b) => b.score - a.score || preference.get(a.fact.id)! - preference.get(b.fact.id)!);
  const result: Fact[] = [];
  for (const category of categoryOrder) {
    const employers = new Map<string, Map<string, Fact[]>>();
    for (const { fact } of selected.filter((item) => item.fact.category === category)) {
      const employer = employerKey(fact);
      if (!employers.has(employer)) employers.set(employer, new Map());
      const groups = employers.get(employer)!;
      const key = groupKey(fact);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(fact);
    }
    for (const groups of employers.values()) for (const facts of groups.values()) result.push(...facts);
  }
  return result;
}

function snapshot(profile: Profile, draft: ResumeDraft): TailoredResumeResult["content"] {
  const byId = new Map(profile.facts.map((fact) => [fact.id, fact]));
  return {
    name: profile.name, email: profile.email, phone: profile.phone, location: profile.location,
    links: { ...profile.links }, facts: draft.factIds.map((id) => structuredClone(byId.get(id)!)),
    skills: [...draft.skills], keywordTerms: [...draft.keywordTerms ?? []],
  };
}

function freezeContent<T>(value: T): T {
  if (value && typeof value === "object") {
    for (const item of Object.values(value)) freezeContent(item);
    Object.freeze(value);
  }
  return value;
}

const provenanceSchema = z.object({
  baseVariantId: z.string().min(1).max(200),
  baseVariantLabel: z.string().min(1).max(500),
  baseVariantSha256: z.string().regex(/^[a-f0-9]{64}$/),
  jobDescriptionHash: z.string().regex(/^[a-f0-9]{64}$/),
  engine: z.enum(["deterministic", "local-ai"]),
  supportedKeywords: z.array(z.string().min(1).max(200)).max(300),
  missingKeywords: z.array(z.string().min(1).max(200)).max(300),
  notes: z.array(z.string().max(8_000)).max(500),
  inference: z.object({ provider: z.enum(["ollama", "copilot", "gemini"]), model: z.string().min(1).max(128), remote: z.boolean() }).optional(),
}).strict();

function assertConciseContent(content: TailoredResumeResult["content"]): void {
  if (content.facts.filter((fact) => fact.category === "experience").length > MAX_EXPERIENCE
    || content.facts.filter((fact) => fact.category === "summary").length > 1
    || content.facts.filter((fact) => fact.category === "education").length > 3
    || content.facts.filter((fact) => fact.category === "publication").length > 2
    || content.skills.length > 24 || sourceText(content).length > MAX_CONTENT_CHARS) {
    throw new Error("Selected canonical paragraphs exceed the concise resume budget. Shorten and confirm source bullets; text is never silently truncated.");
  }
  const completed = new Set<string>();
  const completedEmployers = new Set<string>();
  let previous: string | undefined;
  let previousEmployer: string | undefined;
  let category = -1;
  for (const fact of content.facts) {
    if (categoryOrder.indexOf(fact.category) < category) throw new Error("Tailored content is not in rendered section order.");
    category = categoryOrder.indexOf(fact.category);
    const key = groupKey(fact);
    const employer = employerKey(fact);
    if ((key !== previous && completed.has(key)) || (employer !== previousEmployer && completedEmployers.has(employer))) {
      throw new Error("Tailored employment metadata groups must not interleave.");
    }
    completed.add(key);
    completedEmployers.add(employer);
    previous = key;
    previousEmployer = employer;
  }
}

/** Revalidates canonical content/provenance, not file bytes or standing authorization. */
export function validateTailoredContent(profile: Profile, job: Job, input: TailoredResumeResult | Packet): void {
  assertTailoringPolicy(profile, job);
  const tailoring = provenanceSchema.parse(input.tailoring);
  if (input.draft.mode !== "jd-tailored" || tailoring.jobDescriptionHash !== jobHash(job)) {
    throw new Error("Tailored resume mode or job-description provenance changed.");
  }
  if (!isDeepStrictEqual(tailoring.inference, input.draft.inference)
    || (tailoring.inference && (tailoring.engine !== "local-ai" || tailoring.inference.remote !== (tailoring.inference.provider !== "ollama")))) {
    throw new Error("Tailored inference-provider provenance is inconsistent.");
  }
  if ("resumeContent" in input || "jobHash" in input) {
    const packet = input as Packet;
    if (packet.jobHash !== jobHash(job) || packet.profileHash !== digest(profile) || packet.profileVersion !== profile.version
      || packet.variantId !== tailoring.baseVariantId) throw new Error("Tailored packet profile, job or base provenance changed.");
  }
  const verified = validateResumeSelection(profile, { factIds: input.draft.factIds, skills: input.draft.skills }, tailoring.engine);
  verified.keywordTerms = validateSelectedKeywords(profile, job, verified, input.draft.keywordTerms);
  const expected = snapshot(profile, verified);
  const content = "content" in input ? input.content : input.resumeContent;
  if (!isDeepStrictEqual(content, expected)) throw new Error("Tailored content differs from the exact selected canonical facts, skills or contact details.");
  assertConciseContent(expected);
  const ranked = rankedFacts(profile, job, "");
  const experience = ranked.filter((item) => item.fact.category === "experience");
  const relevant = experience.filter((item) => item.score > 0);
  const pool = relevant.length ? relevant : experience;
  if (expected.facts.filter((fact) => fact.category === "experience").length < Math.min(8, pool.length)) {
    throw new Error("Tailored selection omits too much confirmed experience for a complete concise resume.");
  }
  if (pool.some((item) => current(item.fact) && !expected.facts.some((fact) => groupKey(fact) === groupKey(item.fact)))) {
    throw new Error("Tailored selection omitted a relevant current employment group.");
  }
  const relevantSkills = analyzeKeywords({ ...profile, facts: [] }, job).supported.flatMap((item) => item.sourceSkills);
  if (expected.skills.some((skill) => !relevantSkills.includes(skill))) throw new Error("Tailored skills must be supported by the JD and canonical profile.");
  const analysis = analyzeKeywords({ ...profile, facts: expected.facts, skills: expected.skills }, job);
  if (!isDeepStrictEqual(tailoring.supportedKeywords, analysis.supported.map((item) => item.term))
    || !isDeepStrictEqual(tailoring.missingKeywords, [...analysis.gaps, ...analysis.transferable.map((item) => item.term)])) {
    throw new Error("Tailored keyword provenance differs from the actually selected evidence.");
  }
  if (input.artifacts.length !== 2 || new Set(input.artifacts.map((item) => item.format)).size !== 2
    || input.artifacts.some((item) => !["pdf", "docx"].includes(item.format) || !/^[a-f0-9]{64}$/.test(item.sha256)
      || item.filename !== `resume-${item.sha256}.${item.format}` || !Number.isSafeInteger(item.bytes) || item.bytes <= 0)) {
    throw new Error("Tailored resumes require content-addressed PDF and DOCX artifact metadata.");
  }
}

export async function createTailoredResume(
  profile: Profile, job: Job, base: TailoringBase, outDir: string, mode: "deterministic" | "local-ai" = "deterministic",
): Promise<TailoredResumeResult> {
  if (mode !== "deterministic" && mode !== "local-ai") throw new Error("Unknown resume tailoring engine.");
  assertTailoringPolicy(profile, job);
  const canonical = structuredClone(profile);
  const opening = structuredClone(job);
  const approvedBase = { ...base, bytes: Buffer.isBuffer(base?.bytes) ? Buffer.from(base.bytes) : base?.bytes };
  const imported = await readBase(approvedBase, canonical);
  const baseText = normalize(imported.facts.map((fact) => fact.text).join("\n"));
  const ranked = rankedFacts(canonical, opening, baseText);
  const scope = candidates(ranked);
  const supported = analyzeKeywords({ ...canonical, facts: [] }, opening).supported;
  const skills = canonical.skills.map((skill, index) => ({
    skill, index, jdPosition: supported.findIndex((item) => item.sourceSkills.includes(skill)),
    basePosition: imported.skills.findIndex((item) => normalize(item) === normalize(skill)),
  })).filter((item) => item.jdPosition >= 0)
    .sort((a, b) => a.jdPosition - b.jdPosition || (a.basePosition < 0 ? Infinity : a.basePosition) - (b.basePosition < 0 ? Infinity : b.basePosition) || a.index - b.index)
    .slice(0, 24).map((item) => item.skill);
  const scopedProfile = { ...canonical, facts: scope.selected.map((item) => item.fact), skills };
  const selected = mode === "local-ai" ? await selectResume(scopedProfile, opening, mode)
    : validateResumeSelection(scopedProfile, { factIds: scope.selected.map((item) => item.fact.id), skills }, mode);
  const ids = [...new Set([...selected.factIds, ...scope.required])];
  const facts = orderedFacts(scope.selected, ids);
  const minimumExperience = Math.min(8, scope.selected.filter((item) => item.fact.category === "experience").length);
  if (facts.filter((fact) => fact.category === "experience").length < minimumExperience) {
    throw new Error("Local AI selected too few confirmed experience bullets for a complete concise resume. No deterministic fallback was used.");
  }
  const draft = addSelectedKeywords(canonical, opening, validateResumeSelection(canonical, {
    factIds: facts.map((fact) => fact.id), skills: selected.skills,
  }, mode));
  if (selected.inference) draft.inference = { ...selected.inference };
  const content = snapshot(canonical, draft);
  assertConciseContent(content);
  const analysis = analyzeKeywords({ ...canonical, facts: content.facts, skills: content.skills }, opening);
  const unmatched = imported.facts.filter((fact) => !canonical.facts.some((item) => item.confirmed && normalize(item.text) === normalize(fact.text))).length;
  const notes = [
    mode === "deterministic" ? "Deterministic JD tailoring, explicitly not AI; zero API cost and no model/network calls."
      : selected.inference?.remote ? `${selected.inference.provider === "gemini" ? "Gemini public-tag-only" : "GitHub Copilot"} selection using ${selected.inference.model}; remote processing under explicit consent. No freeform claims or provider/model fallback.`
        : "Local AI selection only; no freeform prose, new claims or skills. No cloud or deterministic fallback.",
    "The approved upload is a base reference for canonical wording emphasis and ordering, never forwarded unchanged. JD relevance precedes template tie-breaks.",
    "A new single-column ATS-readable PDF and DOCX use conventional section order. Original PDF/DOCX layout, typography and pixel-perfect formatting are not preserved.",
    `Import boundaries/metadata may be ambiguous: ${unmatched} imported paragraphs did not exactly match confirmed canonical fact text. Unmatched template claims and imported fact IDs are never adopted; only normalized full-text overlaps affect ordering.`,
    `${content.facts.filter((fact) => fact.category === "experience").length} experience bullets selected from ${canonical.facts.filter((fact) => fact.category === "experience" && fact.confirmed).length} confirmed source bullets; official metadata, metrics, contacts and source wording are unchanged.`,
    ...scope.notes, ...selected.notes,
    ...analysis.supported.map((item) => `Keyword "${item.term}" (${item.kind}): ${item.explanation} Selected evidence: ${[...item.factIds.map((id) => `fact ${id}`), ...item.sourceSkills.map((skill) => `skill "${skill}"`)].join("; ")}.`),
    ...analysis.transferable.map((item) => `Review only, not a resume skill: ${item.term}. ${item.explanation}`),
    ...(analysis.gaps.length ? [`Missing from selected evidence; not added to resume claims: ${analysis.gaps.join(", ")}.`] : []),
  ];
  draft.notes.push(...notes);
  const tailoring: ResumeTailoring = {
    baseVariantId: approvedBase.id, baseVariantLabel: approvedBase.label, baseVariantSha256: approvedBase.sha256,
    jobDescriptionHash: jobHash(opening), engine: mode,
    supportedKeywords: analysis.supported.map((item) => item.term),
    missingKeywords: [...analysis.gaps, ...analysis.transferable.map((item) => item.term)], notes: [...notes],
    ...(selected.inference ? { inference: { ...selected.inference } } : {}),
  };
  const artifacts = await createDocuments(canonical, opening, draft, outDir);
  const result: TailoredResumeResult = { draft: { ...draft, mode: "jd-tailored" }, artifacts, tailoring, content };
  validateTailoredContent(canonical, opening, result);
  freezeContent(content);
  return result;
}
