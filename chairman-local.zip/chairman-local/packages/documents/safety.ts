import { hasNoAiRestriction } from "./no-ai.js";
import { z } from "zod";
import type { Job, Profile, ResumeDraft } from "../domain/types.js";

export const MAX_FACTS = 300;
export const MAX_SKILLS = 150;
export const MAX_SELECTED_FACTS = 80;
export const MAX_SELECTED_SKILLS = 80;

const visibleText = z.string().max(8_000).refine(
  (text) => !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff\ufffe\uffff]/u.test(text)
    && !/[\uD800-\uDFFF]/u.test(text),
  "Text contains unsupported control characters",
);
const metadata = visibleText.max(500).optional();
const profileSchema = z.object({
  name: visibleText.max(200),
  email: visibleText.max(320),
  phone: visibleText.max(100),
  location: visibleText.max(500),
  links: z.record(visibleText.max(100), visibleText.max(1_000)).refine((links) => Object.keys(links).length <= 20),
  skills: z.array(visibleText.min(1).max(200).refine((text) => Boolean(text.trim()))).max(MAX_SKILLS),
  facts: z.array(z.object({
    id: visibleText.min(1).max(100),
    category: z.enum(["summary", "experience", "education", "publication"]),
    text: visibleText.min(1),
    employer: metadata,
    role: metadata,
    dates: metadata,
    confirmed: z.boolean(),
  })).max(MAX_FACTS),
  confirmed: z.literal(true),
});

const referenceProfileSchema = profileSchema.extend({
  confirmed: z.boolean(),
  facts: z.array(profileSchema.shape.facts.element.strict()).min(1).max(MAX_FACTS),
  version: z.number().int().positive(),
  answers: z.record(visibleText.max(500), visibleText).refine((answers) => Object.keys(answers).length <= 300),
  preferences: z.object({
    roles: z.array(visibleText.max(500)).max(300),
    countries: z.array(visibleText.max(500)).max(300),
    excludedEmployers: z.array(visibleText.max(500)).max(300),
    salaryTargetInr: z.number().finite().nonnegative(),
    dailyLimit: z.number().int().nonnegative().nullable(),
    timezone: z.literal("Asia/Kolkata"),
    allowLongTermContracts: z.boolean(),
    authorizedCountries: z.array(visibleText.max(500)).max(300),
    needsSponsorshipAbroad: z.boolean(),
  }).strict(),
}).strict();

export function assertReferenceProfile(profile: Profile): void {
  if (!referenceProfileSchema.safeParse(profile).success) {
    throw new Error("The reference source profile contains invalid, oversized, or unsupported control-character fields.");
  }
  if (new Set(profile.facts.map((fact) => fact.id)).size !== profile.facts.length || new Set(profile.skills).size !== profile.skills.length) {
    throw new Error("Reference source fact IDs and skills must be unique.");
  }
  if (!profile.facts.some((fact) => fact.text.trim())) throw new Error("A nonempty source fact is required for a reference draft.");
}

export const selectionSchema = z.object({
  factIds: z.array(z.string().min(1).max(100)).min(1).max(MAX_SELECTED_FACTS),
  skills: z.array(z.string().min(1).max(200)).max(MAX_SELECTED_SKILLS),
}).strict();

export function assertConfirmedProfile(profile: Profile): void {
  if (!profile || profile.confirmed !== true) {
    throw new Error("Confirm the imported profile and its source facts before preparing a resume.");
  }
  const result = profileSchema.safeParse(profile);
  if (!result.success) throw new Error("The confirmed profile contains invalid or oversized fields.");
  if (new Set(profile.facts.map((fact) => fact.id)).size !== profile.facts.length) {
    throw new Error("Profile fact IDs must be unique.");
  }
  if (new Set(profile.skills).size !== profile.skills.length) {
    throw new Error("Profile skills must be unique.");
  }
  if (!profile.facts.some((fact) => fact.confirmed && fact.text.trim())) {
    throw new Error("At least one nonempty confirmed source fact is required.");
  }
}

export function assertDocumentPolicy(job: Job): void {
  if (job.aiPolicy === "prohibited" || hasNoAiRestriction(`${job.title}\n${job.description}`)) {
    throw new Error("This application requires human-authored / no-AI material. Generated packets, including deterministic assembly, are prohibited; apply manually.");
  }
}

export function validateResumeSelection(
  profile: Profile,
  input: unknown,
  mode: ResumeDraft["mode"],
): ResumeDraft {
  assertConfirmedProfile(profile);
  if (mode !== "local-ai" && mode !== "deterministic") throw new Error("Unknown resume selection mode.");
  const result = selectionSchema.safeParse(input);
  if (!result.success) throw new Error("Invalid resume selection: expected only bounded factIds and skills arrays, with at least one fact.");
  const { factIds, skills } = result.data;
  if (new Set(factIds).size !== factIds.length || new Set(skills).size !== skills.length) {
    throw new Error("Resume selection contains duplicate fact IDs or skills.");
  }
  const facts = new Map(profile.facts.map((fact) => [fact.id, fact]));
  for (const id of factIds) {
    const fact = facts.get(id);
    if (!fact || !fact.confirmed || !fact.text.trim()) {
      throw new Error("Resume selection contains an unknown, unconfirmed, or empty fact.");
    }
  }
  if (skills.some((skill) => !profile.skills.includes(skill))) {
    throw new Error("Resume selection contains a skill not present in the confirmed profile.");
  }
  return {
    factIds,
    skills,
    mode,
    notes: [mode === "local-ai"
      ? "Local AI selected and ordered confirmed source facts only. No claims were generated or rewritten."
      : "Deterministic evidence selection (not AI). Source wording is unchanged."],
  };
}
export { hasNoAiRestriction } from "./no-ai.js";
