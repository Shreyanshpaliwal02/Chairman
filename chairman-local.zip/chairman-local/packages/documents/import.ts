import { createHash } from "node:crypto";
import mammoth from "mammoth";
import { emptyProfile, type Fact, type Profile } from "../domain/types.js";
import { MAX_FACTS, MAX_SKILLS } from "./safety.js";

const MAX_FILE_BYTES = 15 * 1024 * 1024;
const MAX_TEXT_CHARS = 200_000;
const MAX_PAGES = 30;
const headings: Record<string, Fact["category"] | "skills" | "contact"> = {
  summary: "summary", profile: "summary", "professional summary": "summary", objective: "summary",
  experience: "experience", "work experience": "experience", "professional experience": "experience",
  "employment history": "experience", employment: "experience", "relevant experience": "experience",
  projects: "experience", "selected projects": "experience",
  education: "education", "academic background": "education", qualifications: "education",
  publications: "publication", publication: "publication", "research publications": "publication",
  skills: "skills", "technical skills": "skills", "core skills": "skills", technologies: "skills",
  contact: "contact", "contact information": "contact",
};
const rolePattern = /\b(?:engineer|developer|analyst|architect|scientist|intern|manager|lead|consultant|director|researcher|administrator|specialist|designer|technician|officer|founder)\b/i;
const degreePattern = /\b(?:bachelor|master|doctor|ph\.?d|b\.?sc|m\.?sc|b\.?tech|m\.?tech|b\.?s\.?|m\.?s\.?|mba|diploma|degree)\b/i;
const datePart = "(?:(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\\.?\\s+)?(?:19|20)\\d{2}";
const dateRange = `(?:${datePart}|\\d{1,2}[/.-](?:19|20)\\d{2})(?:\\s*(?:-|–|—|to)\\s*(?:${datePart}|\\d{1,2}[/.-](?:19|20)\\d{2}|present|current|now))?`;
const datePattern = new RegExp(`^${dateRange}$`, "i");
type Metadata = Pick<Fact, "employer" | "role" | "dates">;
type SourceLink = { key: string; url: string };
type DocxNode = { type?: string; value?: string; href?: string; children?: DocxNode[] };

function docxProfileLink(node: DocxNode): SourceLink | undefined {
  const href = node.href;
  const controls = /[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/u;
  if (!href || href.length > 1_000 || !/^https:\/\//i.test(href) || /[\s\\]/u.test(href) || controls.test(href)) return;
  let url: URL;
  try {
    url = new URL(href);
    if (url.protocol !== "https:" || !url.hostname || url.username || url.password || controls.test(decodeURIComponent(href))) return;
  } catch { return; }
  const pending = [...node.children ?? []].reverse();
  let label = "";
  let count = 0;
  while (pending.length) {
    if (++count > 1_000 || label.length > 200) return;
    const child = pending.pop()!;
    if (child.type === "text") label += child.value ?? "";
    pending.push(...[...child.children ?? []].reverse());
  }
  const contactLabel = label.trim().match(/^(linkedin|github|portfolio|website|personal website|profile)(?:\s+profile)?[.:]?$/i)?.[1].toLowerCase();
  if (contactLabel) return { key: contactLabel === "personal website" ? "website" : contactLabel, url: href };
  if (/(?:^|\.)linkedin\.com$/i.test(url.hostname) && /^\/(?:in|pub)\/[^/]+/i.test(url.pathname)) return { key: "linkedin", url: href };
  if (/^(?:www\.)?github\.com$/i.test(url.hostname) && /^\/[^/]+\/?$/.test(url.pathname)) return { key: "github", url: href };
  return;
}

async function readDocxProfileLinks(buffer: Buffer): Promise<SourceLink[]> {
  const links: SourceLink[] = [];
  await mammoth.convertToHtml({ buffer }, {
    externalFileAccess: false,
    includeEmbeddedStyleMap: false,
    // Inspect parsed hyperlink targets only; never read even embedded/external image data.
    convertImage: mammoth.images.imgElement(async () => ({ src: "" })),
    transformDocument(document: DocxNode) {
      const pending = [document];
      let count = 0;
      while (pending.length) {
        if (++count > 100_000) throw new Error("DOCX structure exceeds the supported limits.");
        const node = pending.pop()!;
        if (node.type === "hyperlink") {
          const link = docxProfileLink(node);
          if (link && !links.some((existing) => existing.url === link.url)) {
            if (links.length >= 20) throw new Error("DOCX profile links exceed the supported limits.");
            links.push(link);
          }
        }
        pending.push(...[...node.children ?? []].reverse());
      }
      return document;
    },
  });
  return links;
}

// Bound expanded ZIP entries before allowing the DOCX parser to inflate them.
function checkDocxArchive(buffer: Buffer): void {
  let end = -1;
  for (let offset = buffer.length - 22; offset >= Math.max(0, buffer.length - 65_557); offset--) {
    if (buffer.readUInt32LE(offset) === 0x06054b50 && offset + 22 + buffer.readUInt16LE(offset + 20) === buffer.length) {
      end = offset;
      break;
    }
  }
  if (end < 0) throw new Error("Invalid DOCX ZIP archive.");
  const entries = buffer.readUInt16LE(end + 10);
  let offset = buffer.readUInt32LE(end + 16);
  const size = buffer.readUInt32LE(end + 12);
  if (entries > 2_000 || offset + size > end || buffer.readUInt16LE(end + 4) !== 0 || buffer.readUInt16LE(end + 6) !== 0) {
    throw new Error("Unsupported or oversized DOCX archive.");
  }
  let expanded = 0;
  let hasDocument = false;
  for (let i = 0; i < entries; i++) {
    if (offset + 46 > end || buffer.readUInt32LE(offset) !== 0x02014b50) throw new Error("Invalid DOCX ZIP directory.");
    const flags = buffer.readUInt16LE(offset + 8);
    const bytes = buffer.readUInt32LE(offset + 24);
    expanded += bytes;
    if ((flags & 1) !== 0 || bytes > MAX_FILE_BYTES || expanded > 40 * 1024 * 1024) {
      throw new Error("Encrypted or oversized DOCX archive.");
    }
    const nameLength = buffer.readUInt16LE(offset + 28);
    const next = offset + 46 + nameLength + buffer.readUInt16LE(offset + 30) + buffer.readUInt16LE(offset + 32);
    if (next > end) throw new Error("Invalid DOCX ZIP entry.");
    const name = buffer.subarray(offset + 46, offset + 46 + nameLength).toString("utf8");
    if (name === "word/document.xml") hasDocument = true;
    offset = next;
  }
  if (!hasDocument) throw new Error("The archive is not a DOCX document.");
}

export async function extractPdfText(buffer: Buffer): Promise<string> {
  const { getDocument } = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const task = getDocument({ data: new Uint8Array(buffer), disableFontFace: true, useSystemFonts: true, useWasm: false });
  try {
    const pdf = await task.promise;
    if (pdf.numPages > MAX_PAGES) throw new Error(`PDF imports are limited to ${MAX_PAGES} pages.`);
    const pages: string[] = [];
    let chars = 0;
    for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
      const page = await pdf.getPage(pageNumber);
      const content = await page.getTextContent();
      const rows: { y: number; parts: { x: number; text: string }[] }[] = [];
      for (const item of content.items) {
        if (!("str" in item) || !item.str) continue;
        const y = item.transform[5];
        let row = rows.find((candidate) => Math.abs(candidate.y - y) < 1.5);
        if (!row) {
          row = { y, parts: [] };
          rows.push(row);
        }
        row.parts.push({ x: item.transform[4], text: item.str });
      }
      const text = rows.sort((a, b) => b.y - a.y)
        .map((row) => row.parts.sort((a, b) => a.x - b.x).map((part) => part.text).join(" ").replace(/ +/g, " ").trim())
        .join("\n");
      chars += text.length;
      if (chars > MAX_TEXT_CHARS) throw new Error("Extracted PDF text is too large.");
      pages.push(text);
      page.cleanup();
    }
    const text = pages.join("\n\n");
    if (!text.trim()) throw new Error("The PDF has no extractable text. Use DOCX/TXT or transcribe and confirm it; OCR is not performed.");
    return text;
  } finally {
    await task.destroy();
  }
}

function sectionFor(line: string): Fact["category"] | "skills" | "contact" | undefined {
  return headings[line.replace(/:$/, "").trim().toLowerCase()];
}

function splitSkills(line: string): string[] {
  const value = line.replace(/^(?:languages|programming languages|frameworks|libraries|databases|tools|platforms|cloud|cloud platforms|devops|technologies|skills|technical skills)\s*:\s*/i, "");
  const skills: string[] = [];
  let start = 0;
  let depth = 0;
  for (let index = 0; index < value.length; index++) {
    if ("([{".includes(value[index])) depth++;
    if (")]}".includes(value[index])) depth = Math.max(0, depth - 1);
    if (depth === 0 && /[,;|•]/.test(value[index])) {
      skills.push(value.slice(start, index).trim());
      start = index + 1;
    }
  }
  skills.push(value.slice(start).trim());
  return skills.filter(Boolean);
}

function combinedMetadata(line: string, category: Fact["category"]): Metadata | undefined {
  const dateSuffix = line.match(new RegExp(`${dateRange}$`, "i"));
  const prefix = dateSuffix ? line.slice(0, dateSuffix.index).replace(/[\s|—–]+$/, "") : line;
  const parts = prefix.split(/\s*\|\s*|\t+|\s+[—–]\s+/).map((part) => part.trim()).filter(Boolean);
  if (dateSuffix) parts.push(dateSuffix[0]);
  const dates = parts.filter((part) => datePattern.test(part));
  const identity = parts.filter((part) => !datePattern.test(part));
  const titlePattern = category === "education" ? degreePattern : rolePattern;
  if (dates.length > 1 || identity.length > 2) return;
  if (identity.length === 1) {
    const at = identity[0].match(/^(.+?)\s+at\s+(.+)$/i);
    if (at && titlePattern.test(at[1])) return { role: at[1], employer: at[2], dates: dates[0] };
    if (dates.length && titlePattern.test(identity[0])) return { role: identity[0], dates: dates[0] };
  }
  if (identity.length === 2) {
    const roles = identity.filter((part) => titlePattern.test(part));
    if (roles.length === 1) return { role: roles[0], employer: identity.find((part) => part !== roles[0]), dates: dates[0] };
  }
  return;
}

function extractContacts(line: string, profile: Profile): string | undefined {
  const labeled = line.match(/^(name|location|address|email|e-mail|phone|mobile|tel|linkedin|github|website|portfolio)\s*:\s*(.+)$/i);
  if (labeled && !/[|•·]/.test(labeled[2])) {
    const label = labeled[1].toLowerCase();
    const value = labeled[2].trim();
    if (label === "name" && !profile.name) { profile.name = value; return; }
    if ((label === "location" || label === "address") && !profile.location) { profile.location = value; return; }
    if (/^(email|e-mail)$/.test(label) && !profile.email) { profile.email = value; return; }
    if (/^(phone|mobile|tel)$/.test(label) && !profile.phone) { profile.phone = value; return; }
    if (/^(linkedin|github|website|portfolio)$/.test(label) && !profile.links[label]) { profile.links[label] = value; return; }
  }
  let remainder = line;
  const email = remainder.match(/[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
  if (email && !profile.email) {
    profile.email = email[0];
    remainder = remainder.replace(email[0], "").replace(/\b(?:e-?mail)\s*:\s*/i, "");
  }
  const urls = remainder.match(/(?:https?:\/\/|www\.|(?:linkedin\.com|github\.com)\/)[^\s|•·<>]+/gi) ?? [];
  for (const sourceUrl of urls) {
    const key = /linkedin\.com/i.test(sourceUrl) ? "linkedin" : /github\.com/i.test(sourceUrl) ? "github" : `link${Object.keys(profile.links).length + 1}`;
    if (Object.values(profile.links).includes(sourceUrl)) {
      remainder = remainder.replace(sourceUrl, "");
    } else if (!profile.links[key]) {
      profile.links[key] = sourceUrl;
      remainder = remainder.replace(sourceUrl, "").replace(/\b(?:linkedin|github|website|portfolio)\s*:\s*/i, "");
    }
  }
  const phone = remainder.match(/(?:^|(?<=[\s|•·:]))(\+?\d[\d ()-]{5,}\d)(?=$|[\s|•·])/);
  if (phone && !profile.phone && phone[1].replace(/\D/g, "").length >= 7) {
    profile.phone = phone[1].trim();
    remainder = remainder.replace(phone[1], "").replace(/\b(?:phone|mobile|tel)\s*:\s*/i, "");
  }
  remainder = remainder.replace(/^[\s|•·,]+|[\s|•·,]+$/g, "").trim();
  return remainder || undefined;
}

export function parseResumeText(text: string): Profile {
  if (!text.trim() || text.length > MAX_TEXT_CHARS) throw new Error("Resume text is empty or exceeds the import limit.");
  if (/[\u0000-\u0008\u000b\u000e-\u001f\u007f\u202a-\u202e\u2066-\u2069]/u.test(text)) {
    throw new Error("Resume contains unsupported control characters.");
  }
  const profile = emptyProfile();
  const lines = text.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n").replace(/\f/g, "\n").split("\n").map((line) => line.trim()).filter(Boolean);
  let section: Fact["category"] | "skills" | "contact" = "contact";
  let context: Metadata = {};
  let pending: string[] = [];
  let pendingUsed = false;
  const addFact = (value: string, category: Fact["category"], metadata: Metadata = {}) => {
    if (profile.facts.length >= MAX_FACTS) throw new Error(`Import exceeds ${MAX_FACTS} facts; use a shorter resume.`);
    if (value.length > 8_000) throw new Error("A resume paragraph exceeds the import limit.");
    const id = `fact-${createHash("sha256").update(JSON.stringify([profile.facts.length, category, value, metadata])).digest("hex").slice(0, 20)}`;
    profile.facts.push({ id, category, text: value, ...metadata, confirmed: false });
  };
  const flush = () => {
    if (pending.length && !pendingUsed) addFact(pending.join("\n"), section === "education" ? "education" : "experience", context);
    pending = [];
    pendingUsed = false;
  };
  for (let index = 0; index < lines.length; index++) {
    const raw = lines[index];
    const line = raw.replace(/^[•●▪◦*]\s*|^[-–]\s+/, "").trim();
    const heading = sectionFor(line);
    if (heading) {
      flush();
      section = heading;
      context = {};
      continue;
    }
    const inlineSkills = line.match(/^(?:technical skills|skills)\s*:\s*(.+)$/i);
    if (inlineSkills) {
      for (const skill of splitSkills(inlineSkills[1])) if (!profile.skills.includes(skill)) profile.skills.push(skill);
      continue;
    }
    if (section === "skills") {
      for (const skill of splitSkills(line)) if (!profile.skills.includes(skill)) profile.skills.push(skill);
      continue;
    }
    if (section === "contact") {
      const remainder = extractContacts(line, profile);
      if (!remainder) continue;
      if (!profile.name && index === 0 && /^[\p{L}\p{M} .'-]{2,100}$/u.test(remainder) && remainder.split(/\s+/).length <= 6) {
        profile.name = remainder;
      } else {
        addFact(remainder, "summary");
      }
      continue;
    }
    if (section === "experience" || section === "education") {
      const labeled = line.match(/^(employer|company|institution|university|role|title|degree|dates|period)\s*:\s*(.+)$/i);
      if (labeled) {
        const key = /^(employer|company|institution|university)$/i.test(labeled[1]) ? "employer" : /^(role|title|degree)$/i.test(labeled[1]) ? "role" : "dates";
        if (pendingUsed || context[key]) { flush(); context = {}; }
        context[key] = labeled[2];
        pending.push(line);
        continue;
      }
      const combined = combinedMetadata(line, section);
      if (combined) {
        const employerHeading = !combined.employer && context.employer && !context.role && !context.dates && pending.length && !pendingUsed;
        if (!employerHeading) flush();
        context = { ...(employerHeading ? { employer: context.employer } : {}), ...combined };
        pending.push(line);
        continue;
      }
      // Only treat a plain line as an employer/institution when the next line is an explicit role/date header.
      const following = lines[index + 1] && combinedMetadata(lines[index + 1], section);
      if (following && !following.employer && raw === line && line.length <= 150 && !/[.!?]$/.test(line) && !sectionFor(line)) {
        flush();
        context = { employer: line };
        pending.push(line);
        continue;
      }
      addFact(line, section, context);
      pendingUsed = true;
    } else {
      addFact(line, section);
    }
  }
  flush();
  if (profile.skills.length > MAX_SKILLS || profile.skills.some((skill) => skill.length > 200)) {
    throw new Error("Imported skills exceed the supported limits.");
  }
  if (!profile.facts.length && !profile.skills.length) throw new Error("No resume facts or skills were found. Check the source document.");
  return profile;
}

export async function importResume(buffer: Buffer, extension: string): Promise<Profile> {
  if (!Buffer.isBuffer(buffer) || !buffer.length || buffer.length > MAX_FILE_BYTES) throw new Error("Resume must be a nonempty file of at most 15 MiB.");
  const format = extension.toLowerCase().replace(/^\./, "");
  let text: string;
  let sourceLinks: SourceLink[] = [];
  if (format === "txt") {
    try { text = new TextDecoder("utf-8", { fatal: true }).decode(buffer); }
    catch { throw new Error("TXT resumes must use UTF-8 encoding."); }
  } else if (format === "docx") {
    checkDocxArchive(buffer);
    try {
      text = (await mammoth.extractRawText({ buffer })).value;
      sourceLinks = await readDocxProfileLinks(buffer);
    }
    catch { throw new Error("The DOCX could not be read. Use an unencrypted DOCX or UTF-8 TXT file."); }
  } else if (format === "pdf") {
    text = await extractPdfText(buffer);
  } else {
    throw new Error("Unsupported resume format. Use DOCX, UTF-8 TXT, or a text-based PDF.");
  }
  const profile = parseResumeText(text);
  for (const link of sourceLinks) {
    if (Object.values(profile.links).includes(link.url)) continue;
    if (Object.keys(profile.links).length >= 20) throw new Error("Imported profile links exceed the supported limits.");
    let key = link.key;
    let suffix = 1;
    while (Object.hasOwn(profile.links, key)) key = `link${suffix++}`;
    profile.links[key] = link.url;
  }
  return profile;
}
