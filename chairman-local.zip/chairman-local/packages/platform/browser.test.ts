import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, mkdir, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { getChromeLaunchOptions } from "./browser.js";

test("development uses installed Chrome; a portable bundle never hides missing browser files", async () => {
  const root = await mkdtemp(join(tmpdir(), "chairman-browser-"));
  try {
    assert.deepEqual(getChromeLaunchOptions({ root, platform: "darwin" }), { channel: "chrome" });
    assert.deepEqual(getChromeLaunchOptions({ root, platform: "win32" }), { channel: "chrome" });
    await writeFile(join(root, "bundle-manifest.json"), "{}");
    assert.throws(() => getChromeLaunchOptions({ root, platform: "win32" }), /Extract the complete/);
    await mkdir(join(root, "runtime", "chrome-win64"), { recursive: true });
    await writeFile(join(root, "runtime", "chrome-win64", "chrome.exe"), "fixture");
    assert.deepEqual(getChromeLaunchOptions({ root, platform: "win32" }), {
      executablePath: join(root, "runtime", "chrome-win64", "chrome.exe"),
    });
  } finally { await rm(root, { recursive: true, force: true }); }
});
