import { homedir } from "node:os";
import { posix, win32 } from "node:path";

export interface DataDirectoryOptions {
  platform?: NodeJS.Platform;
  env?: NodeJS.ProcessEnv;
  home?: string;
}

export function defaultDataDirectory({ platform = process.platform, env = process.env, home = homedir() }: DataDirectoryOptions = {}): string {
  if (platform === "win32") {
    const base = env.LOCALAPPDATA && win32.isAbsolute(env.LOCALAPPDATA)
      ? env.LOCALAPPDATA : win32.join(home, "AppData", "Local");
    return win32.join(base, "Job Application Assistant");
  }
  if (platform === "darwin") return posix.join(home, "Library", "Application Support", "Job Application Assistant");
  const base = env.XDG_DATA_HOME && posix.isAbsolute(env.XDG_DATA_HOME)
    ? env.XDG_DATA_HOME : posix.join(home, ".local", "share");
  return posix.join(base, "job-application-assistant");
}
