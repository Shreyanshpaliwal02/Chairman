import { lstatSync, existsSync, realpathSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const appRoot = resolve(dirname(fileURLToPath(import.meta.url)), "../..");

export function getChromeLaunchOptions(
  { root = appRoot, platform = process.platform }: { root?: string; platform?: NodeJS.Platform } = {},
): { executablePath: string } | { channel: "chrome" } {
  if (platform !== "win32") return { channel: "chrome" };
  const browserDirectory = join(root, "runtime", "chrome-win64");
  if (!existsSync(join(root, "bundle-manifest.json")) && !existsSync(browserDirectory))
    return { channel: "chrome" };
  const executablePath = join(browserDirectory, "chrome.exe");
  if (!existsSync(executablePath) || !lstatSync(executablePath).isFile()
    || lstatSync(executablePath).isSymbolicLink()
    || realpathSync(executablePath) !== join(realpathSync(root), "runtime", "chrome-win64", "chrome.exe"))
    throw new Error("Bundled Chairman Chrome is missing or redirected. Extract the complete verified Windows ZIP again.");
  return { executablePath };
}
