# Career-link discovery

This local-only adapter discovers **public listings**, not permission to apply.
It never accesses profiles, provider accounts, resumes, private APIs, employer API
keys, or application-submission endpoints. A recognized link is not an approved
application. Existing employer permission, no-AI, and submission safeguards still
apply.

## Exports

```ts
parseCareerTarget(url: string): CareerBoardTarget | undefined
resolveCareerLink(url: string, options?: {
  fetcher?: typeof fetch
  pageLoader?: (url: string) => Promise<string>
}): Promise<CareerLinkResolution>
scanCareerBoard(target: CareerBoardTarget, sourceId: string, label: string,
  cursor?: string, fetcher?: typeof fetch,
  genericOptions?: GenericScanOptions): Promise<ScanResult>

// generic-careers.ts
checkedGenericCareerTarget(target: CareerBoardTarget): CareerBoardTarget
inspectGenericCareerPage(html: string, page: string, seed?: string,
  sourceId?: string): GenericCareerInspection
scanGenericCareerBoard(target: CareerBoardTarget, sourceId: string, label: string,
  cursor?: string, options?: GenericScanOptions): Promise<ScanResult>

// preferred-search.ts
scanPreferredJobs(preferences: Pick<Preferences, "roles" | "countries">,
  cursor?: string, fetcher?: typeof fetch): Promise<ScanResult>
getPreferredSearchCooldownMs(): number // 900_000 (15 minutes)
```

For hosted providers, `boardUrl` is the canonical hosted **board root**; `jobId`, when present, restricts
the import to that one listing. Supported routes:

- `https://jobs.ashbyhq.com/<board>`
- `https://jobs.ashbyhq.com/<board>/<UUID>[/application]`
- `https://job-boards.greenhouse.io/<board>[/jobs/<positive-numeric-ID>]`
- The equivalent legacy `boards.greenhouse.io` routes.
- Greenhouse `/embed/job_board?for=<board>` and
  `/embed/job_app?for=<board>&token=<positive-numeric-ID>`.

Trailing slashes, known tracking parameters, fragments, Ashby UUID casing, and
legacy Greenhouse hosts normalize away. Board spelling is preserved: do not guess
a slug from the employer name or lowercase potentially case-sensitive slugs.
Unknown query parameters are refused rather than silently turning a job-specific
query into a whole-board import. Embed identity parameters must be unique and
occur on the exact supported hosted embed routes.

Resolved single destinations populate `target` with `candidates: []`; ambiguous
pages return distinct board/job `candidates` without selecting anything. Each
specific job remains distinct from a board target, even on the same employer page.
Unsupported links return explanatory/manual instructions. Network, size, timeout,
and upstream failure conditions throw `DiscoveryError`; callers must retain its
`retryAfterMs`/`httpStatus` rather than converting failures into empty success.

## Public employer-page transport

Resolution inspects one HTML document for actual `a[href]` and `iframe[src]` hosted
ATS links, then checks for generic career content if no hosted destinations exist.
No JavaScript, scripts containing URL strings, images, form controls,
provider accounts, arbitrary linked pages, or inferred board names are followed.
HTML attributes are entity-decoded; duplicate ATS destinations normalize together.
Resolution does not crawl relative employer links. Generic scanning separately
follows bounded same-origin candidates as described below. Protocol-relative ATS links are supported.

Before any network request, the original URL spelling is validated. Only HTTPS
DNS hostnames without credentials, explicit ports, backslashes, control/whitespace
characters, path traversal, encoded paths, or doubled path separators are accepted.
LinkedIn/lnkd.in, Wellfound/AngelList, Naukri, provider-private hosts, private/login/
API/state-changing paths, Google search hosts, IP literals, local-use suffixes, and non-tracking query parameters are
refused. Tracking parameters and fragments are removed before fetching.

`public-page.ts` uses Node HTTPS and DNS, not browser/global fetch:

- 2 MiB maximum HTML, 15 seconds total including DNS/redirects, at most three
  redirects, and only HTML/UTF-8 responses. `Accept-Encoding: identity` prevents
  compressed-body expansion; unexpected compression is refused.
- Each redirect's destination is validated **before** another DNS lookup/request.
  DNS is resolved again for each hop; every answer must be public.
- IPv4 private, loopback, link-local, CGNAT, documentation, benchmark, multicast,
  reserved, and known metadata ranges are blocked. IPv6 must be global unicast;
  special/documentation/transition ranges are blocked, including mapped IPv4,
  NAT64, ULA, link-local and loopback addresses.
- The approved DNS address is pinned with the HTTPS request's `lookup` override
  and explicit address family. A fresh socket, original hostname/SNI/Host, and
  normal certificate verification prevent DNS rebinding and preserve TLS identity.
- No cookies, authorization, referer, user content, or credentials are forwarded,
  including on redirects.

`resolveCareerLink`'s `fetcher` does **not** replace this transport: global fetch
cannot supply the required DNS pinning. For deterministic tests, inject trusted
`pageLoader` HTML; the resolver still applies URL preflight, size, and time bounds.
`scanCareerBoard` uses its own injected fetcher only for fixed official feed endpoints.
Do not wire an untrusted/general-purpose page loader into production.

The existing low-level hosted-link transport retains its three-redirect allowance.
New resolver and generic scan calls refuse redirects rather than accidentally
attributing another document's content to the original seed. Paste the direct URL
when a site redirects. Generic transport pins DNS and TLS just like the original
transport; neither `fetcher` nor a persisted cursor can replace its network policy.

## Listing scans

Hosted scans fetch only these reconstructed public GET endpoints:

- `https://api.ashbyhq.com/posting-api/job-board/<board>?includeCompensation=true`
- `https://boards-api.greenhouse.io/v1/boards/<board>/jobs`
- `https://boards-api.greenhouse.io/v1/boards/<board>/jobs/<ID>?questions=true`
- `https://boards-api.greenhouse.io/v1/boards/<board>` (at most once per scan,
  only when a job lacks its public company name and the board is not already verified)

Each entire scan has an aggregate 8 MiB body budget and 15-second deadline.
Redirects are refused, requests omit credentials, and no POST is issued. Feed
indexes are bounded to 10,000 entries; oversized/malformed snapshots fail without
silently dropping jobs. Existing normalization rejects descriptions that exceed
its storage budget rather than truncating the full JD.

- Ashby excludes `isListed: false`, requires explicit visibility and valid UUIDs,
  rejects duplicate IDs, and returns up to 20 jobs in lexicographic UUID order.
- Greenhouse excludes prospect posts with `internal_job_id: null`, validates the
  public index and detail identity, and retrieves at most 10 details after one
  index GET, plus at most one company-metadata GET when needed. Missing/failed
  details fail the page rather than advance past a job.
- Board cursors are the last returned UUID/numeric ID, not an index offset.
  Individual job targets reject cursors and import only the requested listed job.
  A missing/unlisted individual job throws an explicit 404/closed-or-missing error;
  a published deadline in the past remains a job with `status: "closed"`.
- Every Ashby job/apply URL and Greenhouse hosted URL must match the exact provider,
  board, and job. Output links are canonical hosted links without tracking.
  The existing verified native `canonical.com` and `automattic.com` destinations
  are not fetched; their fixed board index/detail identifies the hosted output.
  Other employer-native Greenhouse `absolute_url` values fail closed because this
  adapter cannot verify their board identity.
- IDs are globally stable: `<provider>:<board>:<job-ID>`, independent of the
  user-defined `sourceId`. `sourceJobId` is the provider's listing ID. Source IDs
  must match `[A-Za-z0-9][A-Za-z0-9_-]{0,127}`. The parent attaches
  `careerSourceIds` and deduplicates against original/built-in sources.
- The caller's `label` is only a user-friendly source name, **never employer
  identity evidence**. Renaming a source cannot change `Job.company` or hide an
  excluded employer. Verified boards retain Canonical, Automattic, and Supabase.
  Other Ashby boards use a readable normalized board slug; its documented feed
  supplies no company-name field, and arbitrary payload fields or job-description
  guesses are not identity evidence. Other Greenhouse boards use the documented
  job `company_name`, then the public board metadata `name` when needed, then only
  the readable slug if neither name is supplied. Slug fallbacks are not verified
  legal employer names. Metadata failures retain normal timeout/size/cooldown
  handling. The parent preserves trusted built-in source/company values when a
  custom source joins an existing deduplicated job.
- Unknown salary, sponsorship, working language, employment, and country
  eligibility stay unknown. Remote is not worldwide or immigration authorization.
  Salary normalization preserves known period/currency/base-kind, and ambiguous
  Greenhouse pay ranges remain unknown rather than guessed annual compensation.
- Description and public question no-AI restrictions are retained. The Greenhouse
  `canonical` board always retains its employer-wide prohibited hold, including
  under a custom source ID. A board imported through another source cannot bypass it.

The caller persists attempts, partial cursors, cooldowns, and source state.
429/503 errors preserve `Retry-After`; there are no immediate retries.
Board snapshots can change between pages: restarting after a completed cycle
discovers newly published lower IDs. No absence-based mass closure is inferred.

## Generic employer portals

`parseCareerTarget` still recognizes **only** the original hosted routes, unchanged.
`resolveCareerLink` first preserves its hosted destination/ambiguity behavior.
If there are none, genuine JobPosting JSON-LD, actual same-origin career links, or
an identifiable careers page can produce:

```ts
{
  provider: "generic",
  board: "careers.example.com",                 // exact seed hostname
  boardUrl: "https://careers.example.com/careers", // exact public seed, not site root
  jobId: "https://careers.example.com/careers/jobs/123" // optional raw posting URL
}
```

`jobId` is **not** a hosted ID or an encoded URL: it is the exact validated public
posting URL, same-origin with the seed. For resolution of a single posting, both
`boardUrl` and `jobId` are the supplied posting URL. Seed path spelling, case, and
trailing slash are retained; tracking/fragments are removed. Targets with a
mismatched hostname, altered URL identity, foreign/private job, or unsafe query fail
before fetching. User source IDs retain the original strict 128-character pattern.
Generic jobs have `sourceJobId = canonicalUrl` and global `id = "generic:" +
canonicalUrl`, independent of source label/ID. The parent attaches `careerSourceIds`.
The label cannot become `company`; missing employer names say “Employer unspecified.”

An identifiable JS-only/embedded careers page is a **watch source**, not an opening.
Its resolution message explicitly asks for a real posting link/full JD and human
review. No title, description, employer identity, or eligibility is fabricated.
Unrelated pages without career evidence remain unsupported. A scan with no
extractable JD returns `jobs: []`; it never creates a synthetic manual job.

Generic scans have these limits:

- One seed/index document plus at most **five** direct same-origin posting pages
  per call, **2 MiB/page**, **8 MiB aggregate**, **20 seconds total** (at most 15
  seconds per document), no redirects, no JavaScript, no account access.
- Actual linked career/job/role/position paths are candidates. On a `careers.` or
  `jobs.` hostname, an actual role-labelled link may also name a root-level posting.
  Newsletter, contact, demo, signup, talent-pool, and similar CTAs are not jobs.
  Details never expand the crawl. Foreign links and unsupported iframes are not
  followed; recognizable hosted ATS destinations remain a separate resolver review.
- At most 500 postings/candidates per index; oversized structures fail explicitly,
  not as a silently truncated success. HTML nesting and JSON graph depth/node count
  are bounded. Only literal `application/ld+json` JSON is parsed, including arrays,
  `@graph`, and JobPosting values in `mainEntity`/`itemListElement`. Hidden/raw-text
  content cannot contribute visible links, titles, or plain-HTML descriptions.
- A title-only index can point to a detail with a real JD. JSON-LD imports require
  actual `title` and full `description`; plain HTML requires a specific `h1`, a
  recognizable job-description region with actual responsibilities/requirements
  text, and exactly one clear same-origin Apply anchor. Form actions are not read.
  Original source text is normalized by the existing `normalizeHtml`, never AI.
- Posting `url` supplies the canonical public identity when safely same-origin.
  One clear same-origin Apply destination on that posting is retained separately
  but **never fetched**. Foreign, gated, query-bearing, or ambiguous apply
  destinations fall back to the actual source posting for human/browser review.
  No external destination is guessed or automatically authorized.
- `hiringOrganization`, `jobLocation`/`addressCountry`,
  `applicantLocationRequirements`, `employmentType`, `datePosted`, `validThrough`,
  and `baseSalary` are source evidence. Known HOUR/DAY/WEEK/MONTH/YEAR salary
  periods are preserved; unknown units stay unknown. Remote `TELECOMMUTE` is not
  worldwide permission, and an office country is not remote applicant eligibility.
  Unknown salary, language, and sponsorship remain unknown.
- Explicit no-AI instructions on the index or posting apply to its results.
  Canonical name/domain evidence enforces its prohibited hold despite source
  aliases. Repeated identical posting identities deduplicate; conflicting
  title/description/employer identities fail rather than merging unrelated jobs.
  Past `validThrough` yields a closed job; 404/410 candidate links produce no
  opening. Rate limits/errors are not converted to successful empty scans.

The generic cursor is canonical base64url-encoded JSON:
`{v:1, seed, page, after?, aiProhibited?:true}`. The optional prohibited flag retains
an observed index-wide no-AI restriction across pagination. `after` is the last lexicographically visited direct
candidate URL. The index is refetched on each call, so the cursor cannot inject a
new fetch destination via `after`. Its origin and career path are checked before
any request. `page` must be the exact seed path with only a unique numeric
`page=1..1000`, taken from an actual pagination anchor. The scanner-only
`publicCareerListingUrl(raw, seed)` allows this narrow structural query; the
ordinary `publicCareerPageUrl` still rejects it. Off-path, foreign, duplicate,
non-numeric and extra query parameters are refused before DNS. Pagination advances
to a larger linked page; terminal results omit `nextCursor`. Restart periodically
at the seed to discover lower/new IDs and changed listings. Never infer closure
from absence in a partial traversal.

`GenericScanOptions` contains only a trusted `pageLoader?: (url) => Promise<string>`
fixture seam. Production omits it. Size/deadline/preflight checks still surround
the fixture seam. `GenericCareerInspection` reports `jobs`, sorted `links`,
optional `nextPage`, `careerPage`, `singlePosting`, and `aiProhibited`.

## Preference-led public search

This is proactive **public feed/API discovery**, not unlimited search-engine or
whole-site crawling. The sole request destination is the officially documented
`GET https://himalayas.app/jobs/api/search?q=...&sort=recent&page=...`.
It uses no paid API, provider key, service account, profile, resume, or submission
endpoint. Input is limited to at most 10 role labels and 50 country labels, each
at most 100 characters. URL/control/query syntax is rejected. Only fixed generic
engineering-family keywords derived from requested roles are transmitted:
software, cloud, data, forward-deployed, MLOps, DevOps, SRE, platform, security,
ML/AI, frontend/backend, and full-stack engineering. Unrecognized or empty role
selections make no network request; duplicate families collapse together.

Countries bind the cursor but are **not transmitted or treated as authorization**.
Country preferences (including regions such as European Union) must be evaluated
by the parent's existing eligibility/matching rules against actual returned
restrictions. Unknown country eligibility is retained for review rather than
labelled worldwide or dropped under an invented geographic filter.

One bounded page is fetched per call: 2 MiB, 15 seconds, no redirects or credentials.
The documented/live search API uses **1-based `page`**, not the browse API's
opaque `cursor`. Its response `offset`, `limit` (1–20), and `totalCount` are
validated. Preferred-search cursors are base64url JSON
`{v:1,key,roleIndex,pages}`, with a SHA-256 preferences key and one next page number
(or `null` when exhausted) per role. Calls rotate role families fairly, resuming
each role's own page. Changed preferences require a restart; a finished cycle
omits `nextCursor` so the next periodic run begins again.

Shared `normalizeHimalayasJob` is extracted unchanged from the existing browse
mapper. New search results retain `sourceId: "himalayas"`,
`sourceJobId: <Himalayas guid URL>`, `id: "himalayas:" + guid URL`, full source text,
and Himalayas attribution, allowing ordinary browse results to merge. The live
API returns country strings; the OpenAPI Location-object form is also accepted
by the search adapter. A bare example GUID is not enough to fabricate a public
posting link. Source expiry, salary periods, unknown sponsorship/language, and
explicit/Canonical no-AI holds are retained. No result is application permission.

The caller **must persist** cursors and enforce `getPreferredSearchCooldownMs()`
(15 minutes across pages/cycles), with any larger `Retry-After` delay taking
precedence. No immediate retries occur. Do not publish Himalayas jobs to
third-party aggregators; preserve its source credit and canonical link.

## Limitations and verification

JavaScript-only pages and unsupported embeds need an actual JD/posting for review,
even when their careers seed can be watched. Custom Greenhouse employer-native routes,
unsafe/encoded URLs, authenticated pages, oversized responses, and pages without
extractable job descriptions still require a supported URL or manual handling.
Redirects alone do not infer a board identity from an arbitrary employer page.

Shared Ashby/Greenhouse normalization was extracted from `discovery.ts`; built-in
Supabase/Automattic/Canonical endpoints, pagination, names, IDs, and holds remain
unchanged. No new dependencies were installed.

Run the existing test runner:

```sh
node --import tsx --test tests/generic-careers.test.ts tests/preferred-search.test.ts \
  tests/career-links.test.ts tests/discovery.test.ts \
  tests/additional-feeds.test.ts tests/scanner.test.ts
npm run typecheck
```

Tests use synthetic public HTML, feed fixtures, and injected HTTPS/DNS. No candidate
data, accounts, live applications, or submissions are used.

Official public API documentation checked for this implementation:
[Ashby Job Postings API](https://developers.ashbyhq.com/docs/public-job-posting-api)
and [Greenhouse Job Board API](https://docs.greenhouse.io/job-board.html)
plus [Himalayas API](https://himalayas.app/api) and its
[OpenAPI 3.1 specification](https://himalayas.app/docs/openapi.json)
(2026-09-15). The public search schema was additionally checked using only generic
software/cloud-engineer queries, never candidate data. Public GET documentation
is not candidate automation permission.
