import { createHash } from "node:crypto";
import type { Preferences, ScanResult } from "../domain/types";
import { DiscoveryError, fetchPublicText, normalizeHimalayasJob, normalizeHtml } from "./discovery";
import { getSource } from "./sources";
import { safeCareerUrl } from "./public-page";

const ENDPOINT = "https://himalayas.app/jobs/api/search";
const ROLE_FAMILIES: [RegExp, string][] = [
  [/\bforward[- ]deployed\b/i, "forward deployed engineer"],
  [/\bmlops\b|\bmachine learning operations\b/i, "MLOps engineer"],
  [/\bdata\b/i, "data engineer"],
  [/\bcloud\b/i, "cloud engineer"],
  [/\bdevops\b/i, "DevOps engineer"],
  [/\bsite reliability\b|\bsre\b/i, "site reliability engineer"],
  [/\bplatform\b/i, "platform engineer"],
  [/\bsecurity\b/i, "security engineer"],
  [/\bmachine learning\b|\bml\b/i, "machine learning engineer"],
  [/\bartificial intelligence\b|\bai\b/i, "AI engineer"],
  [/\bfront[- ]?end\b/i, "frontend engineer"],
  [/\bback[- ]?end\b/i, "backend engineer"],
  [/\bfull[- ]?stack\b/i, "full stack engineer"],
  [/\bsoftware\b|\bdeveloper\b/i, "software engineer"]
];
type Cursor = { v: 1; key: string; roleIndex: number; pages: (number | null)[] };

function invalid(message: string): never { throw new DiscoveryError("INVALID_DATA", message); }
function object(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) invalid("Invalid Himalayas search response.");
  return value as Record<string, unknown>;
}
function preferenceList(value: unknown, maximum: number): string[] {
  if (!Array.isArray(value) || value.length > maximum) invalid("Preferred discovery supports at most 10 roles and 50 countries.");
  return value.map((item) => {
    if (typeof item !== "string" || !item.trim() || item.length > 100 || !/^[\p{L} .+#()-]+$/u.test(item)) invalid("Preferences must be short role or country labels, not URLs or personal data.");
    return item.trim().replace(/\s+/g, " ");
  });
}
function parseCursor(value: string | undefined, key: string, count: number): Cursor {
  const initial: Cursor = { v: 1, key, roleIndex: 0, pages: Array.from({ length: count }, () => 1) };
  if (value === undefined) return initial;
  try {
    if (typeof value !== "string" || value.length > 2_048 || !/^[a-z0-9_-]+$/i.test(value)) throw new Error();
    const decoded = Buffer.from(value, "base64url").toString("utf8");
    if (Buffer.from(decoded).toString("base64url") !== value) throw new Error();
    const cursor = object(JSON.parse(decoded));
    if (Object.keys(cursor).some((name) => !["v", "key", "roleIndex", "pages"].includes(name))
      || cursor.v !== 1 || cursor.key !== key || !Number.isInteger(cursor.roleIndex) || Number(cursor.roleIndex) < 0 || Number(cursor.roleIndex) >= count
      || !Array.isArray(cursor.pages) || cursor.pages.length !== count
      || cursor.pages.some((page) => page !== null && (!Number.isSafeInteger(page) || Number(page) < 1 || Number(page) > 1_000_000))
      || cursor.pages[Number(cursor.roleIndex)] === null) throw new Error();
    return cursor as unknown as Cursor;
  } catch { throw new DiscoveryError("INVALID_CURSOR", "Invalid preferred-search cursor; restart when preferences change."); }
}

/** Caller enforces this across pages and completed cycles, and honors larger Retry-After delays. */
export function getPreferredSearchCooldownMs(): number { return 15 * 60_000; }

/** One public API page per call, rotating role families. Never accepts profile facts or API credentials. */
export async function scanPreferredJobs(preferences: Pick<Preferences, "roles" | "countries">, cursor?: string, fetcher: typeof fetch = fetch): Promise<ScanResult> {
  if (!preferences || typeof preferences !== "object") invalid("Missing discovery preferences.");
  const requested = preferenceList(preferences.roles, 10);
  const countries = preferenceList(preferences.countries, 50);
  // Only fixed generic keywords leave the process, even if a role label contains unrelated personal prose.
  const roles = [...new Set(requested.flatMap((role) => {
    const family = ROLE_FAMILIES.find(([pattern]) => pattern.test(role));
    return family ? [family[1]] : [];
  }))];
  const key = createHash("sha256").update(JSON.stringify({ roles, countries })).digest("hex");
  const state = parseCursor(cursor, key, roles.length);
  if (!roles.length) return { jobs: [] };
  const page = state.pages[state.roleIndex]!;
  const url = new URL(ENDPOINT);
  url.searchParams.set("q", roles[state.roleIndex]!);
  url.searchParams.set("sort", "recent");
  url.searchParams.set("page", String(page));
  let payload: Record<string, unknown>;
  const body = await fetchPublicText(url, fetcher, { maxResponseBytes: 2 * 1_048_576, timeoutMs: 15_000, pageSize: 20 }, {
    Accept: "application/json", "User-Agent": "PersonalJobDiscovery/0.1 (public-preference-search)"
  });
  try { payload = object(JSON.parse(body)); }
  catch (error) {
    if (error instanceof DiscoveryError) throw error;
    return invalid("Himalayas search returned malformed JSON.");
  }
  if (!Number.isSafeInteger(payload.limit) || Number(payload.limit) < 1 || Number(payload.limit) > 20
    || !Number.isSafeInteger(payload.totalCount) || Number(payload.totalCount) < 0
    || !Number.isSafeInteger(payload.offset) || payload.offset !== (page - 1) * Number(payload.limit)
    || !Array.isArray(payload.jobs) || payload.jobs.length > Number(payload.limit)) invalid("Invalid Himalayas search pagination.");
  const source = getSource("himalayas")!;
  const jobs = payload.jobs.map((value) => {
    const item = object(value);
    // The live API uses country strings; OpenAPI also documents Location objects.
    let locations = item.locationRestrictions;
    if (locations != null) {
      if (!Array.isArray(locations) || locations.length > 250) invalid("Invalid Himalayas country restrictions.");
      locations = locations.map((location) => {
        if (typeof location === "string") return location;
        const place = object(location);
        if (typeof place.name !== "string" || !place.name.trim() || place.name.length > 100
          || typeof place.alpha2 !== "string" || !/^[A-Z]{2}$/i.test(place.alpha2)) invalid("Invalid Himalayas country object.");
        return place.name;
      });
    }
    if (typeof item.guid !== "string" || typeof item.applicationLink !== "string") invalid("Missing public Himalayas posting links.");
    // A bare OpenAPI example GUID is not enough to invent a canonical attribution URL.
    const canonical = safeCareerUrl(item.guid);
    safeCareerUrl(item.applicationLink);
    if (canonical.hostname !== "himalayas.app" || !/^\/(?:companies\/[^/]+\/jobs\/[^/]+|jobs\/[^/]+)\/?$/.test(canonical.pathname)
      || typeof item.description !== "string" || !normalizeHtml(item.description).trim()) invalid("A Himalayas result needs its public posting URL and full description.");
    const job = normalizeHimalayasJob(source, { ...item, locationRestrictions: locations });
    if (/\bcanonical\b/i.test(job.company) || item.companySlug === "canonical"
      || /(?:^|\.)canonical\.com$/i.test(new URL(job.applyUrl).hostname)
      || /^(?:boards|job-boards)\.greenhouse\.io$/.test(new URL(job.applyUrl).hostname) && /^\/canonical(?:\/|$)/i.test(new URL(job.applyUrl).pathname)) job.aiPolicy = "prohibited";
    return job;
  });
  if (new Set(jobs.map((job) => job.id)).size !== jobs.length) invalid("Duplicate Himalayas search posting identifiers.");
  const more = Number(payload.offset) + Number(payload.limit) < Number(payload.totalCount);
  if (!jobs.length && Number(payload.offset) < Number(payload.totalCount)) invalid("Himalayas search returned an empty non-terminal page.");
  if (more && page >= 1_000_000) throw new DiscoveryError("TOO_LARGE", "Himalayas search exceeded its pagination budget.");
  state.pages[state.roleIndex] = more ? page + 1 : null;
  let nextIndex = -1;
  for (let offset = 1; offset <= roles.length; offset++) {
    const index = (state.roleIndex + offset) % roles.length;
    if (state.pages[index] !== null) { nextIndex = index; break; }
  }
  if (nextIndex < 0) return { jobs };
  state.roleIndex = nextIndex;
  return { jobs, nextCursor: Buffer.from(JSON.stringify(state)).toString("base64url") };
}
