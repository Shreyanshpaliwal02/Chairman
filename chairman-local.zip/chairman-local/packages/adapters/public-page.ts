import { lookup } from "node:dns/promises";
import { request as httpsRequest } from "node:https";
import { BlockList, isIP } from "node:net";
import type { ClientRequest } from "node:http";
import { DiscoveryError, retryAfterMs } from "./discovery";

export const MAX_PUBLIC_PAGE_BYTES = 2 * 1_048_576;
const BLOCKED_DOMAINS = [
  "linkedin.com", "linkedin.cn", "lnkd.in", "wellfound.com", "angel.co", "angellist.com",
  "naukri.com", "naukrigulf.com", "mygreenhouse.io", "google.com", "google.co.in", "login.microsoftonline.com"
];
const HOSTED_ATS = new Set(["jobs.ashbyhq.com", "boards.greenhouse.io", "job-boards.greenhouse.io", "boards.eu.greenhouse.io", "job-boards.eu.greenhouse.io"]);
const PRIVATE_SEGMENT = /^(?:api|graphql|login|log-in|signin|sign-in|signup|sign-up|auth|oauth|oauth2|sso|account|accounts|admin|dashboard|candidate|candidates|profile|profiles|resume|resumes|upload|uploads|settings|logout|session|sessions|private|internal)$/i;
const TRACKING_KEY = /^(?:utm_[a-z0-9_]+|gh_src|source|ref|referrer|referral|fbclid|gclid|msclkid|mc_cid|mc_eid)$/i;

function unsafe(): never {
  throw new DiscoveryError("INVALID_DATA", "Use a public HTTPS employer careers page or a hosted Ashby/Greenhouse link; private or unsafe URLs are not fetched.");
}

/** Validate the original spelling before WHATWG URL can normalize away unsafe input. */
export function safeCareerUrl(raw: string): URL {
  if (typeof raw !== "string" || raw.length > 2_048 || /[\\\u0000-\u0020\u007f]/.test(raw)) unsafe();
  const parts = /^https:\/\/([^/?#]+)([^?#]*)/i.exec(raw);
  if (!parts || /[:@%]/.test(parts[1]!) || /%|\/{2}|(?:^|\/)\.{1,2}(?:\/|$)/.test(parts[2]!)) unsafe();
  let url: URL;
  try { url = new URL(raw); } catch { return unsafe(); }
  if (url.protocol !== "https:" || url.username || url.password || url.port
    || !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/i.test(parts[1]!)
    || url.hostname.length > 253 || isIP(url.hostname)
    || /\.(?:local|localhost|internal|test|invalid|onion|lan|home|corp|arpa)$/.test(url.hostname)
    || BLOCKED_DOMAINS.some((host) => url.hostname === host || url.hostname.endsWith(`.${host}`))
    || /(?:^|\.)indeed\.[a-z]{2,3}(?:\.[a-z]{2})?$/.test(url.hostname)
    || /(?:^|\.)google\.(?:[a-z]{2,3})(?:\.[a-z]{2})?$/.test(url.hostname)
    || (!HOSTED_ATS.has(url.hostname) && /(?:^|\.)(?:ashbyhq\.com|greenhouse\.io)$/.test(url.hostname))
    || url.pathname.split("/").some((part) => PRIVATE_SEGMENT.test(part))) unsafe();
  return url;
}

export function isTrackingKey(key: string): boolean {
  return TRACKING_KEY.test(key);
}

export function publicCareerPageUrl(raw: string): URL {
  const url = safeCareerUrl(raw);
  if (url.pathname.split("/").some((part) => /^(?:apply|application|applications|delete|remove|unsubscribe|log-out|signout|sign-out|submit|send|create|update|edit|checkout|purchase|subscribe)$/i.test(part))
    || [...url.searchParams.keys()].some((key) => !isTrackingKey(key))) unsafe();
  url.search = "";
  url.hash = "";
  return url;
}

/** Scanner-only pagination: an actual linked, positive `page` on the exact seed path. */
export function publicCareerListingUrl(raw: string, seed: string): URL {
  const root = publicCareerPageUrl(seed);
  const url = safeCareerUrl(raw);
  if (url.origin !== root.origin) unsafe();
  if (!url.searchParams.has("page")) return publicCareerPageUrl(raw);
  if (url.pathname !== root.pathname || url.searchParams.getAll("page").length !== 1
    || !/^[1-9]\d{0,3}$/.test(url.searchParams.get("page")!) || Number(url.searchParams.get("page")) > 1_000
    || [...url.searchParams.keys()].some((key) => key !== "page" && !isTrackingKey(key))) unsafe();
  const page = url.searchParams.get("page")!;
  url.search = "";
  url.searchParams.set("page", page);
  url.hash = "";
  return url;
}

const NON_PUBLIC = new BlockList();
for (const [address, prefix] of [
  ["0.0.0.0", 8], ["10.0.0.0", 8], ["100.64.0.0", 10], ["127.0.0.0", 8],
  ["169.254.0.0", 16], ["172.16.0.0", 12], ["192.0.0.0", 24], ["192.0.2.0", 24],
  ["192.88.99.0", 24], ["192.168.0.0", 16], ["198.18.0.0", 15], ["198.51.100.0", 24],
  ["203.0.113.0", 24], ["224.0.0.0", 4], ["240.0.0.0", 4]
] as const) NON_PUBLIC.addSubnet(address, prefix, "ipv4");
NON_PUBLIC.addAddress("168.63.129.16", "ipv4");
for (const [address, prefix] of [
  ["2001::", 23], ["2001:db8::", 32], ["2002::", 16], ["3fff::", 20]
] as const) NON_PUBLIC.addSubnet(address, prefix, "ipv6");
const GLOBAL_V6 = new BlockList();
GLOBAL_V6.addSubnet("2000::", 3, "ipv6");

export function isPublicIpAddress(address: string): boolean {
  if (address.includes("%")) return false;
  const family = isIP(address);
  return family === 4 ? !NON_PUBLIC.check(address, "ipv4")
    : family === 6 && GLOBAL_V6.check(address, "ipv6") && !NON_PUBLIC.check(address, "ipv6");
}

interface PageDependencies {
  resolve?: (hostname: string) => Promise<{ address: string; family: number }[]>;
  request?: typeof httpsRequest;
  timeoutMs?: number;
  maxResponseBytes?: number;
  /** Generic scanners never redirect; the fetched URL remains the provenance URL. */
  listingSeed?: string;
  maxRedirects?: number;
}

/** Local-only HTTPS transport. A fresh, pinned socket is used for every validated redirect. */
export async function loadPublicCareerPage(raw: string, dependencies: PageDependencies = {}): Promise<string> {
  const validate = (value: string) => dependencies.listingSeed
    ? publicCareerListingUrl(value, dependencies.listingSeed) : publicCareerPageUrl(value);
  let url = validate(raw);
  const resolve = dependencies.resolve ?? ((hostname) => lookup(hostname, { all: true, verbatim: true }));
  const request = dependencies.request ?? httpsRequest;
  const timeoutMs = dependencies.timeoutMs ?? 15_000;
  const maxBytes = dependencies.maxResponseBytes ?? MAX_PUBLIC_PAGE_BYTES;
  const maxRedirects = dependencies.listingSeed ? 0 : dependencies.maxRedirects ?? 3;
  if (!Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 15_000
    || !Number.isInteger(maxBytes) || maxBytes < 1 || maxBytes > MAX_PUBLIC_PAGE_BYTES
    || !Number.isInteger(maxRedirects) || maxRedirects < 0 || maxRedirects > 3) unsafe();
  let active: ClientRequest | undefined;
  let expired = false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      expired = true;
      active?.destroy();
      reject(new DiscoveryError("TIMEOUT", "Public careers page timed out; paste its hosted board link instead."));
    }, timeoutMs);
  });
  try {
    return await Promise.race([timeout, (async () => {
      for (let redirects = 0; ; redirects++) {
        const addresses = await resolve(url.hostname);
        if (expired) throw new DiscoveryError("TIMEOUT", "Public careers page timed out.");
        if (!addresses.length || addresses.some(({ address, family }) => !isPublicIpAddress(address) || isIP(address) !== family)) unsafe();
        const pinned = addresses[0]!;
        const result = await new Promise<{ html: string } | { location: string }>((accept, reject) => {
          const fail = (error: DiscoveryError) => { reject(error); active?.destroy(); };
          active = request({
            protocol: "https:", hostname: url.hostname, port: 443, method: "GET",
            path: url.pathname + url.search, servername: url.hostname, family: pinned.family,
            agent: false, rejectUnauthorized: true,
            lookup: (hostname, options, callback) => {
              if (hostname !== url.hostname) return callback(new Error("Unexpected lookup host"), "", 0);
              if (options.all) callback(null, [pinned]);
              else callback(null, pinned.address, pinned.family);
            },
            headers: {
              Host: url.hostname, Accept: "text/html, application/xhtml+xml;q=0.9",
              "Accept-Encoding": "identity", "User-Agent": "PersonalJobDiscovery/0.1 (public-careers-link-only)"
            }
          }, (response) => {
            const status = response.statusCode ?? 0;
            if ([301, 302, 303, 307, 308].includes(status)) {
              const location = response.headers.location;
              response.destroy();
              if (!location || redirects >= maxRedirects) return fail(new DiscoveryError("REDIRECT", "Public careers page exceeded its safe redirect budget; paste the direct public careers or hosted board link."));
              accept({ location });
              return;
            }
            if (status < 200 || status >= 300) {
              response.destroy();
              return fail(new DiscoveryError(status === 429 ? "RATE_LIMITED" : "HTTP_ERROR", "Public careers page request failed.", retryAfterMs(response.headers["retry-after"] ?? null), status));
            }
            if (!/^(?:text\/html|application\/xhtml\+xml)(?:;|$)/i.test(response.headers["content-type"] ?? "")
              || !/^(?:identity)?$/i.test(response.headers["content-encoding"] ?? "")) {
              response.destroy();
              return fail(new DiscoveryError("INVALID_DATA", "The public careers page must be uncompressed HTML."));
            }
            if (Number(response.headers["content-length"]) > maxBytes) {
              response.destroy();
              return fail(new DiscoveryError("TOO_LARGE", "Public careers HTML exceeds 2 MiB; paste the hosted board link."));
            }
            const chunks: Buffer[] = [];
            let bytes = 0;
            response.on("data", (chunk: Buffer) => {
              bytes += chunk.length;
              if (bytes > maxBytes) {
                response.destroy();
                fail(new DiscoveryError("TOO_LARGE", "Public careers HTML exceeds 2 MiB; paste the hosted board link."));
              } else chunks.push(chunk);
            });
            response.on("end", () => {
              try { accept({ html: new TextDecoder("utf-8", { fatal: true }).decode(Buffer.concat(chunks)) }); }
              catch { fail(new DiscoveryError("INVALID_DATA", "Public careers HTML is not valid UTF-8.")); }
            });
            response.on("error", () => fail(new DiscoveryError("NETWORK_ERROR", "Public careers page body could not be read.")));
            response.on("aborted", () => fail(new DiscoveryError("NETWORK_ERROR", "Public careers page response was incomplete.")));
          });
          active.on("error", () => reject(new DiscoveryError("NETWORK_ERROR", "Public careers page could not be fetched.")));
          active.end();
        });
        if ("html" in result) return result.html;
        // Reject unsafe spelling before resolving relative Location against the current page.
        if (/[\\\u0000-\u0020\u007f]/.test(result.location)
          || /%|(?:^|\/)\.{1,2}(?:\/|[?#]|$)/.test(result.location.split(/[?#]/)[0]!)) unsafe();
        if (/^https:/i.test(result.location)) safeCareerUrl(result.location);
        else if (result.location.startsWith("//")) safeCareerUrl(`https:${result.location}`);
        url = validate(new URL(result.location, url).href);
      }
    })()]);
  } catch (error) {
    if (error instanceof DiscoveryError) throw error;
    throw new DiscoveryError("NETWORK_ERROR", "Public careers page could not be resolved or fetched; paste the hosted board link.");
  } finally {
    clearTimeout(timer);
    active?.destroy();
  }
}
