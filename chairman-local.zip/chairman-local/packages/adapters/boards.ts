import type { CareerBoardTarget, Job, Salary } from "../domain/types";
import { inferCountries } from "../domain/job-fit";
import { XMLParser } from "fast-xml-parser";
import { countryName, detectAiPolicy, DiscoveryError, employmentLabel, locationCountries, normalizeHtml, retryAfterMs } from "./discovery";

/**
 * Whole-board crawler for hosted job boards with public listing APIs. One pass reads every open posting (or, for very
 * large Workday boards, the postings your role-family keywords find), keeps the ones whose title you care about, and
 * fetches full descriptions only for those. GET/POST reads only; nothing is applied to.
 */
type Row = Record<string, unknown>;
export const CRAWLED_PROVIDERS = ["greenhouse", "ashby", "lever", "smartrecruiters", "workday", "eightfold", "oracle", "rippling", "google", "apple", "atlassian", "nutanix"] as const;
export type CrawledProvider = typeof CRAWLED_PROVIDERS[number];
export function crawls(target: CareerBoardTarget | undefined): target is CareerBoardTarget & { provider: CrawledProvider } {
  return !!target && (CRAWLED_PROVIDERS as readonly string[]).includes(target.provider);
}
export interface CrawlOptions {
  fetcher?: typeof fetch;
  /** Keep a posting (by title and location) before any detail request or storage. Default: keep all. */
  keep?: (title: string, location: string) => boolean;
  /** Search phrases used instead of a full listing when a Workday board is very large. */
  queries?: string[];
  company?: string;
  maxJobs?: number;
  deadlineMs?: number;
  delayMs?: number;
  maxBytes?: number;
  /** Stops the crawl early (for example when the service shuts down); the result is then marked truncated. */
  signal?: AbortSignal;
}
export interface CrawlResult { jobs: Job[]; listed: number; kept: number; truncated: boolean }

/**
 * Several career sites refuse unfamiliar user agents on the same public listing APIs their own pages call, so requests
 * look like the browser you would use to read them. Volume stays low: one board at a time, paced, about once a day.
 */
const BROWSER_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36";
const WORKDAY_HOST = /^(?:[a-z0-9-]+\.wd\d{1,3}\.myworkdayjobs\.com|wd\d{1,3}\.myworkdaysite\.com)$/;
const EIGHTFOLD_HOST = /^[a-z0-9-]+\.eightfold\.ai$/;
const ORACLE_HOST = /^[a-z0-9-]+\.fa(?:\.[a-z0-9-]+)?\.oraclecloud\.com$/;
const API_HOSTS = new Set(["boards-api.greenhouse.io", "api.ashbyhq.com", "api.lever.co", "api.eu.lever.co", "api.smartrecruiters.com", "api.rippling.com", "careers.nutanix.com"]);
/** Fixed first-party career endpoints (host → allowed path prefix). */
const FIRST_PARTY: Record<string, string> = { "www.google.com": "/about/careers/applications/jobs/results", "www.atlassian.com": "/endpoint/careers/listings", "jobs.apple.com": "/api/v1/" };
const allowed = (url: URL) => API_HOSTS.has(url.hostname) || WORKDAY_HOST.test(url.hostname) || EIGHTFOLD_HOST.test(url.hostname) || ORACLE_HOST.test(url.hostname)
  || (FIRST_PARTY[url.hostname] !== undefined && url.pathname.startsWith(FIRST_PARTY[url.hostname]!));
const GREENHOUSE_PAGES = new Set(["job-boards.greenhouse.io", "boards.greenhouse.io", "job-boards.eu.greenhouse.io", "boards.eu.greenhouse.io"]);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const SLUG = /^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/;

const invalid = (message: string): never => { throw new DiscoveryError("INVALID_DATA", message); };
const record = (value: unknown): Row => value && typeof value === "object" && !Array.isArray(value) ? value as Row : {};
const rows = (value: unknown): Row[] => Array.isArray(value) ? value.slice(0, 20_000).map(record) : [];
const str = (value: unknown, max = 500): string | undefined => typeof value === "string" && value.trim() ? value.trim().slice(0, max) : undefined;
function text(value: unknown): string {
  if (typeof value !== "string" || !value.trim()) return "";
  try { return normalizeHtml(value.slice(0, 120_000)).slice(0, 47_000); } catch { return ""; }
}
function isoDate(value: unknown): string | undefined {
  const stamp = typeof value === "number" ? (value < 1e12 ? value * 1000 : value) : typeof value === "string" && /\d{4}-\d{2}-\d{2}/.test(value) ? Date.parse(value) : NaN;
  return Number.isFinite(stamp) && Math.abs(stamp) < 8.64e15 ? new Date(stamp).toISOString() : undefined;
}
function countriesOf(location: string, ...codes: unknown[]): string[] {
  const found = new Set(locationCountries(location));
  for (const name of inferCountries(location)) found.add(name);
  for (const code of codes) { const value = str(code, 100); if (value) found.add(countryName(value.length <= 3 ? value : value)); }
  return [...found].filter(item => item.length > 1).map(item => item.length <= 3 ? countryName(item) : item);
}
function workplace(value: unknown): Job["workplaceType"] {
  const label = String(value ?? "").toLowerCase();
  return /remote/.test(label) ? "remote" : /hybrid|flex/.test(label) ? "hybrid" : /on-?site|office|in[- ]person/.test(label) ? "onsite" : undefined;
}
function salaryOf(min: unknown, max: unknown, currency: unknown, period: unknown): Salary | null {
  const low = typeof min === "number" && min >= 0 ? min : undefined, high = typeof max === "number" && max >= 0 ? max : undefined;
  if (low === undefined && high === undefined) return null;
  const interval = String(period ?? "").toLowerCase();
  return { ...(low !== undefined ? { min: low } : {}), ...(high !== undefined ? { max: high } : {}),
    ...(typeof currency === "string" && /^[A-Z]{3}$/.test(currency) ? { currency } : {}),
    ...(/year|annual/.test(interval) ? { period: "annual" } : /month/.test(interval) ? { period: "monthly" } : /hour/.test(interval) ? { period: "hourly" } : {}), kind: "base" };
}
const safeId = (value: string) => value.replace(/[^A-Za-z0-9._-]+/g, "-").slice(0, 120);

class Budget {
  bytes: number; requests = 0; readonly deadline: number;
  /** Set when a request ran out of time or the crawl was stopped: postings not reached must not count as removed. */
  stopped = false;
  constructor(readonly fetcher: typeof fetch, readonly delayMs: number, deadlineMs: number, maxBytes: number, readonly signal?: AbortSignal) {
    this.deadline = Date.now() + deadlineMs; this.bytes = maxBytes;
  }
}
/** A site session some first-party boards require: headers sent with each request, updated from each response. */
interface Session { headers: Record<string, string>; seen(headers: Headers): void }
async function request(budget: Budget, raw: string, body?: unknown, session?: Session): Promise<unknown> {
  const text = await fetchBody(budget, raw, body, "application/json", session);
  try { return JSON.parse(text); } catch { return invalid("The board returned malformed JSON."); }
}
async function fetchBody(budget: Budget, raw: string, body: unknown, accept: string, session?: Session): Promise<string> {
  const url = new URL(raw);
  if (url.protocol !== "https:" || url.username || url.password || url.port || !allowed(url))
    invalid("Board crawler destination is not an allowed public board API.");
  for (let attempt = 0; ; attempt++) {
    const remaining = budget.deadline - Date.now();
    if (remaining < 1 || budget.signal?.aborted) {
      budget.stopped = true;
      throw new DiscoveryError("TIMEOUT", budget.signal?.aborted ? "The board crawl was stopped." : "The board crawl reached its time budget.");
    }
    if (budget.requests++ && budget.delayMs) await new Promise(resolve => setTimeout(resolve, budget.delayMs));
    const controller = new AbortController(), timer = setTimeout(() => controller.abort(), Math.min(30_000, remaining));
    const stop = () => controller.abort();
    budget.signal?.addEventListener("abort", stop, { once: true });
    try {
      const response = await budget.fetcher(url.href, {
        method: body === undefined ? "GET" : "POST", redirect: "error", credentials: "omit", referrerPolicy: "no-referrer", signal: controller.signal,
        headers: { Accept: accept, "Accept-Language": "en-US,en;q=0.9", "User-Agent": BROWSER_UA, ...(body === undefined ? {} : { "Content-Type": "application/json" }), ...session?.headers },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      });
      if ((response.status === 429 || response.status >= 500) && attempt === 0) {
        const wait = Math.min(retryAfterMs(response.headers.get("retry-after")) ?? 3000, 10_000);
        void response.body?.cancel().catch(() => undefined);
        await new Promise(resolve => setTimeout(resolve, wait));
        continue;
      }
      if (!response.ok) {
        void response.body?.cancel().catch(() => undefined);
        throw new DiscoveryError(response.status === 429 ? "RATE_LIMITED" : "HTTP_ERROR", `The board answered ${response.status}.`, retryAfterMs(response.headers.get("retry-after")), response.status);
      }
      session?.seen(response.headers);
      const reader = response.body?.getReader();
      if (!reader) invalid("Empty board response.");
      const chunks: Uint8Array[] = [];
      for (;;) {
        const chunk = await reader!.read();
        if (chunk.done) break;
        budget.bytes -= chunk.value.byteLength;
        if (budget.bytes < 0) { void reader!.cancel().catch(() => undefined); throw new DiscoveryError("TOO_LARGE", "The board crawl reached its download budget."); }
        chunks.push(chunk.value);
      }
      return Buffer.concat(chunks).toString("utf8");
    } catch (error) {
      if (error instanceof DiscoveryError) throw error;
      const code = String((error as { cause?: { code?: unknown } })?.cause?.code ?? "").replace(/[^A-Z0-9_]/g, "").slice(0, 40);
      if (controller.signal.aborted) budget.stopped = true;
      throw new DiscoveryError(controller.signal.aborted ? "TIMEOUT" : "NETWORK_ERROR", controller.signal.aborted ? `A request to ${url.hostname} ${budget.signal?.aborted ? "was stopped" : "timed out"}.` : `A request to ${url.hostname} failed${code ? ` (${code})` : ""}.`);
    } finally { clearTimeout(timer); budget.signal?.removeEventListener("abort", stop); }
  }
}

interface Fields {
  postingId: string; title: string; company: string; location: string; remote: boolean; countries: string[]; employmentType: string;
  description: string; canonicalUrl: string; applyUrl: string; postedAt?: string; salary?: Salary | null;
  workplaceType?: Job["workplaceType"]; department?: string; seniority?: string;
}
function makeJob(target: CareerBoardTarget, sourceId: string, board: string, fields: Fields): Job {
  return {
    id: `${target.provider}:${safeId(board)}:${safeId(fields.postingId)}`, sourceId, sourceJobId: fields.postingId,
    title: fields.title, company: fields.company, location: fields.location || "Location not stated", remote: fields.remote, countries: fields.countries,
    employmentType: fields.employmentType || "unknown", description: fields.description, applyUrl: fields.applyUrl, canonicalUrl: fields.canonicalUrl,
    ...(fields.postedAt ? { postedAt: fields.postedAt } : {}), fetchedAt: new Date().toISOString(), salary: fields.salary ?? null, language: null,
    sponsorship: "unknown", aiPolicy: detectAiPolicy(`${fields.title}\n${fields.description}`), status: "open",
    ...(fields.workplaceType ? { workplaceType: fields.workplaceType } : {}), ...(fields.department ? { department: fields.department } : {}),
    ...(fields.seniority ? { seniority: fields.seniority } : {}),
  };
}

/** Lever, SmartRecruiters and Workday board or posting links. Greenhouse and Ashby links are parsed in career-links. */
export function parseBoardUrl(raw: string): CareerBoardTarget | undefined {
  let url: URL;
  try { url = new URL(raw.trim()); } catch { return undefined; }
  if (url.protocol !== "https:" || url.username || url.password || url.port) return undefined;
  const parts = url.pathname.split("/").filter(Boolean);
  if (url.hostname === "jobs.lever.co" || url.hostname === "jobs.eu.lever.co") {
    const [site, id, apply] = parts;
    if (!site || !SLUG.test(site) || (id !== undefined && !UUID.test(id)) || (apply !== undefined && apply !== "apply") || parts.length > 3) return undefined;
    return { provider: "lever", board: site.toLowerCase(), boardUrl: `https://${url.hostname}/${site.toLowerCase()}`, ...(id ? { jobId: id.toLowerCase() } : {}) };
  }
  if (url.hostname === "jobs.smartrecruiters.com" || url.hostname === "careers.smartrecruiters.com") {
    const [company, posting] = parts;
    if (!company || !SLUG.test(company) || ["oneclick-ui", "external-referrals", "sr-jobs"].includes(company.toLowerCase())) return undefined;
    const id = posting?.match(/^(\d{6,20})(?:-|$)/)?.[1];
    return { provider: "smartrecruiters", board: company, boardUrl: `https://jobs.smartrecruiters.com/${company}`, ...(id ? { jobId: id } : {}) };
  }
  if (EIGHTFOLD_HOST.test(url.hostname)) {
    const domain = url.searchParams.get("domain")?.toLowerCase();
    if (!domain || !/^[a-z0-9-]+(?:\.[a-z0-9-]+)+$/.test(domain)) return undefined;
    const id = url.pathname.match(/^\/careers\/job\/(\d{3,20})/)?.[1];
    return { provider: "eightfold", board: `${url.hostname}|${domain}`, boardUrl: `https://${url.hostname}/careers?domain=${domain}`, ...(id ? { jobId: id } : {}) };
  }
  if (ORACLE_HOST.test(url.hostname)) {
    const match = url.pathname.match(/^\/hcmUI\/CandidateExperience\/[a-z]{2}(?:-[A-Za-z]{2})?\/sites\/([A-Za-z0-9_-]{1,40})(?:\/job\/(\d{1,20}))?/);
    if (!match) return undefined;
    return { provider: "oracle", board: `${url.hostname}|${match[1]}`, boardUrl: `https://${url.hostname}/hcmUI/CandidateExperience/en/sites/${match[1]}`, ...(match[2] ? { jobId: match[2] } : {}) };
  }
  if (url.hostname === "ats.rippling.com") {
    const [slug, jobs, id] = parts;
    if (!slug || !SLUG.test(slug) || (jobs !== undefined && jobs !== "jobs") || (id !== undefined && !UUID.test(id))) return undefined;
    return { provider: "rippling", board: slug.toLowerCase(), boardUrl: `https://ats.rippling.com/${slug.toLowerCase()}/jobs`, ...(id ? { jobId: id.toLowerCase() } : {}) };
  }
  if ((url.hostname === "www.google.com" && url.pathname.startsWith("/about/careers/")) || url.hostname === "careers.google.com")
    return { provider: "google", board: "google", boardUrl: "https://www.google.com/about/careers/applications/jobs/results/" };
  if (url.hostname === "jobs.apple.com") return { provider: "apple", board: "apple", boardUrl: "https://jobs.apple.com/en-in/search" };
  if ((url.hostname === "www.atlassian.com" && url.pathname.startsWith("/company/careers")) || url.hostname === "globalcareers-atlassian.icims.com")
    return { provider: "atlassian", board: "atlassian", boardUrl: "https://www.atlassian.com/company/careers/all-jobs" };
  if (url.hostname === "careers.nutanix.com") return { provider: "nutanix", board: "nutanix", boardUrl: "https://careers.nutanix.com/en/jobs/" };
  if (WORKDAY_HOST.test(url.hostname)) {
    const locale = /^[a-z]{2}(?:-[A-Za-z]{2})?$/.test(parts[0] ?? "") ? 1 : 0;
    if (url.hostname.endsWith("myworkdaysite.com")) {
      if (parts[locale] !== "recruiting" || !parts[locale + 1] || !parts[locale + 2]) return undefined;
      const tenant = parts[locale + 1]!, site = parts[locale + 2]!;
      if (!SLUG.test(tenant) || !SLUG.test(site)) return undefined;
      return { provider: "workday", board: `${url.hostname}/${tenant}/${site}`, boardUrl: `https://${url.hostname}/recruiting/${tenant}/${site}` };
    }
    const site = parts[locale];
    if (!site || !SLUG.test(site) || ["wday", "job", "jobs"].includes(site)) return undefined;
    const tenant = url.hostname.split(".")[0]!;
    return { provider: "workday", board: `${url.hostname}/${tenant}/${site}`, boardUrl: `https://${url.hostname}/${site}` };
  }
  return undefined;
}
function workdayParts(target: CareerBoardTarget): { host: string; tenant: string; site: string; page: string } {
  const [host, tenant, site] = target.board.split("/");
  if (!host || !WORKDAY_HOST.test(host) || !tenant || !SLUG.test(tenant) || !site || !SLUG.test(site)) invalid("Invalid Workday board.");
  return { host: host!, tenant: tenant!, site: site!, page: host!.endsWith("myworkdaysite.com") ? `https://${host}/recruiting/${tenant}/${site}` : `https://${host}/${site}` };
}

type Crawl = (target: CareerBoardTarget, sourceId: string, company: string, budget: Budget, options: CrawlOptions) => Promise<CrawlResult>;
const keepAll = () => true;

const greenhouse: Crawl = async (target, sourceId, company, budget, options) => {
  if (!SLUG.test(target.board)) invalid("Invalid Greenhouse board.");
  const payload = record(await request(budget, `https://boards-api.greenhouse.io/v1/boards/${target.board}/jobs?content=true`));
  const listed = rows(payload.jobs), jobs: Job[] = [], keep = options.keep ?? keepAll, max = options.maxJobs ?? 1500;
  let kept = 0;
  for (const row of listed) {
    if (row.internal_job_id === null || typeof row.id !== "number" || !Number.isSafeInteger(row.id)) continue;
    const title = str(row.title), location = str(record(row.location).name, 1000) ?? "";
    if (!title || !keep(title, location)) continue;
    if (++kept > max) continue;
    const description = text(row.content);
    if (!description) continue;
    let host = "job-boards.greenhouse.io";
    try { const page = new URL(String(row.absolute_url)); if (GREENHOUSE_PAGES.has(page.hostname)) host = page.hostname.replace(/^boards\./, "job-boards."); } catch { /* hosted default */ }
    const url = `https://${host}/${target.board}/jobs/${row.id}`;
    const meta = rows(row.metadata).find(entry => /^(?:employment (?:type|length)|commitment|job type|time type)$/i.test(String(entry.name ?? "")));
    jobs.push(makeJob(target, sourceId, target.board, { postingId: String(row.id), title, company: options.company?.trim() || str(row.company_name, 200) || company, location,
      remote: /\b(?:remote|home[- ]based)\b/i.test(location), countries: countriesOf(location), employmentType: employmentLabel(str(meta?.value, 100)),
      description, canonicalUrl: url, applyUrl: url, postedAt: isoDate(row.first_published ?? row.updated_at), department: str(rows(row.departments)[0]?.name, 120) }));
  }
  return { jobs, listed: listed.length, kept: Math.min(kept, max), truncated: kept > max };
};

const ashby: Crawl = async (target, sourceId, company, budget, options) => {
  if (!SLUG.test(target.board)) invalid("Invalid Ashby board.");
  const payload = record(await request(budget, `https://api.ashbyhq.com/posting-api/job-board/${target.board}?includeCompensation=true`));
  const listed = rows(payload.jobs).filter(row => row.isListed !== false), jobs: Job[] = [], keep = options.keep ?? keepAll, max = options.maxJobs ?? 1500;
  let kept = 0;
  for (const row of listed) {
    const id = str(row.id, 40)?.toLowerCase(), title = str(row.title);
    if (!id || !UUID.test(id) || !title) continue;
    const secondary = rows(row.secondaryLocations);
    const location = [str(row.location, 300), ...secondary.map(entry => str(entry.location, 300))].filter(Boolean).join("; ");
    if (!keep(title, location)) continue;
    if (++kept > max) continue;
    const description = text(row.descriptionHtml) || str(row.descriptionPlain, 47_000) || "";
    if (!description) continue;
    const address = (value: unknown) => record(record(value).postalAddress ?? value).addressCountry;
    const summary = rows(record(row.compensation).summaryComponents).filter(part => part.compensationType === "Salary");
    const pay = summary.length === 1 ? salaryOf(summary[0]!.minValue, summary[0]!.maxValue, summary[0]!.currencyCode, summary[0]!.interval) : null;
    const type = workplace(row.workplaceType);
    const canonical = `https://jobs.ashbyhq.com/${target.board}/${id}`;
    jobs.push(makeJob(target, sourceId, target.board, { postingId: id, title, company, location, remote: row.isRemote === true || type === "remote",
      countries: countriesOf(location, address(row.address), ...secondary.map(entry => address(entry.address))),
      employmentType: employmentLabel(str(row.employmentType, 60)), description, canonicalUrl: canonical, applyUrl: `${canonical}/application`,
      postedAt: isoDate(row.publishedAt), salary: pay, workplaceType: type, department: str(row.department, 120) ?? str(row.team, 120) }));
  }
  return { jobs, listed: listed.length, kept: Math.min(kept, max), truncated: kept > max };
};

const lever: Crawl = async (target, sourceId, company, budget, options) => {
  if (!SLUG.test(target.board)) invalid("Invalid Lever board.");
  const eu = target.boardUrl.startsWith("https://jobs.eu.lever.co/");
  const listed = rows(await request(budget, `https://${eu ? "api.eu.lever.co" : "api.lever.co"}/v0/postings/${target.board}?mode=json`));
  const jobs: Job[] = [], keep = options.keep ?? keepAll, max = options.maxJobs ?? 1500;
  let kept = 0;
  for (const row of listed) {
    const id = str(row.id, 40)?.toLowerCase(), title = str(row.text);
    if (!id || !UUID.test(id) || !title) continue;
    const categories = record(row.categories);
    const all = Array.isArray(categories.allLocations) ? categories.allLocations.map(value => str(value, 200)).filter(Boolean) as string[] : [];
    const location = (all.length ? all : [str(categories.location, 300)].filter(Boolean) as string[]).join("; ");
    if (!keep(title, location)) continue;
    if (++kept > max) continue;
    const lists = rows(row.lists).map(item => `<h3>${str(item.text, 300) ?? ""}</h3><ul>${typeof item.content === "string" ? item.content : ""}</ul>`);
    const description = text([row.description, ...lists, row.additional].filter(value => typeof value === "string").join("\n")) || str(row.descriptionPlain, 47_000) || "";
    if (!description) continue;
    const canonical = `https://${eu ? "jobs.eu.lever.co" : "jobs.lever.co"}/${target.board}/${id}`, range = record(row.salaryRange);
    const type = workplace(row.workplaceType);
    jobs.push(makeJob(target, sourceId, target.board, { postingId: id, title, company, location, remote: type === "remote" || /\bremote\b/i.test(location),
      countries: countriesOf(location, row.country), employmentType: employmentLabel(str(categories.commitment, 60)), description,
      canonicalUrl: canonical, applyUrl: `${canonical}/apply`, postedAt: isoDate(row.createdAt), salary: salaryOf(range.min, range.max, range.currency, range.interval),
      workplaceType: type, department: str(categories.department, 120) ?? str(categories.team, 120) }));
  }
  return { jobs, listed: listed.length, kept: Math.min(kept, max), truncated: kept > max };
};

const smartrecruiters: Crawl = async (target, sourceId, company, budget, options) => {
  if (!SLUG.test(target.board)) invalid("Invalid SmartRecruiters company.");
  const base = `https://api.smartrecruiters.com/v1/companies/${target.board}/postings`;
  const summaries: Row[] = [];
  let total = Infinity;
  for (let offset = 0; offset < total && offset < 3000; offset += 100) {
    const page = record(await request(budget, `${base}?limit=100&offset=${offset}`));
    total = typeof page.totalFound === "number" ? page.totalFound : 0;
    const content = rows(page.content);
    summaries.push(...content);
    if (content.length < 100) break;
  }
  const jobs: Job[] = [], keep = options.keep ?? keepAll, max = options.maxJobs ?? 600;
  let kept = 0;
  for (const row of summaries) {
    const id = str(row.id, 30), title = str(row.name);
    if (!id || !/^\d{6,20}$/.test(id) || !title) continue;
    const place = record(row.location);
    const location = str(place.fullLocation, 300) ?? [place.city, place.region, place.country].map(value => str(value, 100)).filter(Boolean).join(", ");
    const shown = place.remote === true ? `${location}${location ? " " : ""}(Remote)` : location;
    if (!keep(title, shown)) continue;
    if (++kept > max) continue;
    let detail: Row;
    try { detail = record(await request(budget, `${base}/${id}`)); } catch (error) {
      if (error instanceof DiscoveryError && error.code === "TIMEOUT") { kept--; break; }
      continue;
    }
    const sections = record(record(detail.jobAd).sections);
    const description = text(["jobDescription", "qualifications", "additionalInformation"].map(key => {
      const section = record(sections[key]); return `<h3>${str(section.title, 200) ?? ""}</h3>${typeof section.text === "string" ? section.text : ""}`;
    }).join("\n"));
    if (!description) continue;
    const link = (value: unknown) => { try { const url = new URL(String(value)); return url.protocol === "https:" && url.hostname === "jobs.smartrecruiters.com" ? url.href : undefined; } catch { return undefined; } };
    const canonical = link(detail.postingUrl) ?? `https://jobs.smartrecruiters.com/${target.board}/${id}`;
    jobs.push(makeJob(target, sourceId, target.board, { postingId: id, title, company, location: shown, remote: place.remote === true,
      countries: countriesOf(location, place.country), employmentType: employmentLabel(str(record(row.typeOfEmployment).label, 60)), description,
      canonicalUrl: canonical, applyUrl: link(detail.applyUrl) ?? canonical, postedAt: isoDate(row.releasedDate),
      workplaceType: place.remote === true ? "remote" : place.hybrid === true ? "hybrid" : "onsite",
      department: str(record(row.department).label, 120) ?? str(record(row.function).label, 120), seniority: str(record(row.experienceLevel).label, 60) }));
  }
  return { jobs, listed: Number.isFinite(total) ? total : summaries.length, kept: Math.min(kept, max), truncated: kept > max || summaries.length < (Number.isFinite(total) ? total : 0) };
};

const workday: Crawl = async (target, sourceId, company, budget, options) => {
  const { host, tenant, site, page } = workdayParts(target);
  const list = `https://${host}/wday/cxs/${tenant}/${site}/jobs`;
  const found = new Map<string, { title: string; location: string }>();
  const read = async (offset: number, searchText: string): Promise<number> => {
    const response = record(await request(budget, list, { appliedFacets: {}, limit: 20, offset, searchText }));
    const postings = rows(response.jobPostings);
    for (const posting of postings) {
      const path = str(posting.externalPath, 400), title = str(posting.title);
      if (path?.startsWith("/job/") && title && !found.has(path)) found.set(path, { title, location: str(posting.locationsText, 300) ?? "" });
    }
    return offset === 0 && typeof response.total === "number" ? response.total : postings.length;
  };
  const total = await read(0, "");
  let truncated = false;
  if (total <= 2000) {
    for (let offset = 20; offset < total; offset += 20) if (await read(offset, "") === 0) break;
  } else {
    truncated = true;
    const queries = [...new Set((options.queries ?? []).map(query => query.trim().toLowerCase()).filter(query => query.length >= 2))].slice(0, 15);
    for (const query of queries) for (let offset = 0; offset < 100; offset += 20) if (await read(offset, query) < 20) break;
  }
  const jobs: Job[] = [], keep = options.keep ?? keepAll, max = options.maxJobs ?? 400;
  let kept = 0;
  for (const [path, summary] of found) {
    if (!keep(summary.title, summary.location)) continue;
    if (++kept > max) continue;
    let detail: Row;
    try { detail = record(await request(budget, `https://${host}/wday/cxs/${tenant}/${site}${path}`)); } catch (error) {
      if (error instanceof DiscoveryError && error.code === "TIMEOUT") { kept--; truncated = true; break; }
      continue;
    }
    const info = record(detail.jobPostingInfo);
    const description = text(info.jobDescription);
    if (!description) continue;
    const additional = Array.isArray(info.additionalLocations) ? info.additionalLocations.map(value => str(value, 200)).filter(Boolean) as string[] : [];
    const location = [str(info.location, 300) ?? summary.location, ...additional].filter(Boolean).join("; ");
    let canonical = `${page}${path}`;
    try { const url = new URL(String(info.externalUrl)); if (url.protocol === "https:" && url.hostname === host) canonical = url.href; } catch { /* built from the path */ }
    const req = str(info.jobReqId, 60) ?? path.split("_").at(-1)!;
    const type = workplace(info.remoteType);
    jobs.push(makeJob(target, sourceId, `${tenant}:${site}`, { postingId: req, title: str(info.title) ?? summary.title, company, location,
      remote: type === "remote" || /\bremote\b/i.test(location), countries: countriesOf(location, record(info.country).descriptor),
      employmentType: employmentLabel(str(info.timeType, 60)), description, canonicalUrl: canonical, applyUrl: canonical, postedAt: isoDate(info.startDate),
      workplaceType: type }));
  }
  return { jobs, listed: total, kept: Math.min(kept, max), truncated: truncated || kept > max };
};

/** Listing pages where a board is small enough to read fully; above the limit, your role-family phrases are searched instead. */
async function listing(total: number, pageSize: number, max: number, queries: string[] | undefined,
  read: (offset: number, query: string) => Promise<number>): Promise<boolean> {
  if (total <= max) {
    for (let offset = pageSize; offset < total; offset += pageSize) if (await read(offset, "") === 0) break;
    return false;
  }
  for (const query of [...new Set((queries ?? []).map(value => value.trim().toLowerCase()).filter(value => value.length >= 2))].slice(0, 15))
    for (let offset = 0; offset < 100; offset += pageSize) if (await read(offset, query) < pageSize) break;
  return true;
}

const eightfold: Crawl = async (target, sourceId, company, budget, options) => {
  const [host, domain] = target.board.split("|");
  if (!host || !EIGHTFOLD_HOST.test(host) || !domain || !/^[a-z0-9-]+(?:\.[a-z0-9-]+)+$/.test(domain)) invalid("Invalid Eightfold board.");
  const found = new Map<string, { title: string; location: string }>();
  const read = async (offset: number, query: string): Promise<number> => {
    const page = record(await request(budget, `https://${host}/api/apply/v2/jobs?domain=${domain}&start=${offset}&num=50${query ? `&query=${encodeURIComponent(query)}` : ""}`));
    const positions = rows(page.positions);
    for (const position of positions) {
      const id = String(position.id ?? ""), title = str(position.name);
      if (/^\d{3,20}$/.test(id) && title && !found.has(id)) found.set(id, { title, location: (Array.isArray(position.locations) ? position.locations.map(value => str(value, 200)).filter(Boolean) : [str(position.location, 200)]).join("; ") });
    }
    return offset === 0 && !query && typeof page.count === "number" ? page.count : positions.length;
  };
  const total = await read(0, "");
  const truncated = await listing(total, 50, 1500, options.queries, read);
  const jobs: Job[] = [], keep = options.keep ?? keepAll, max = options.maxJobs ?? 400;
  let kept = 0;
  for (const [id, summary] of found) {
    if (!keep(summary.title, summary.location)) continue;
    if (++kept > max) continue;
    let detail: Row;
    try { detail = record(await request(budget, `https://${host}/api/apply/v2/jobs/${id}?domain=${domain}`)); } catch (error) {
      if (error instanceof DiscoveryError && error.code === "TIMEOUT") { kept--; break; }
      continue;
    }
    const description = text(detail.job_description);
    if (!description) continue;
    const locations = Array.isArray(detail.locations) ? detail.locations.map(value => str(value, 200)).filter(Boolean) as string[] : [];
    const location = locations.join("; ") || summary.location;
    let canonical = `https://${host}/careers/job/${id}`;
    try { const url = new URL(String(detail.canonicalPositionUrl)); if (url.protocol === "https:" && url.hostname === host) canonical = url.href; } catch { /* built from the id */ }
    const type = workplace(detail.work_location_option);
    jobs.push(makeJob(target, sourceId, host.split(".")[0]!, { postingId: id, title: str(detail.posting_name) ?? summary.title, company, location,
      remote: type === "remote" || /\bremote\b/i.test(location), countries: countriesOf(location), employmentType: "unknown", description,
      canonicalUrl: canonical, applyUrl: canonical, postedAt: isoDate(detail.t_create), workplaceType: type, department: str(detail.department, 120) }));
  }
  return { jobs, listed: total, kept: Math.min(kept, max), truncated: truncated || kept > max };
};

const oracle: Crawl = async (target, sourceId, company, budget, options) => {
  const [host, site] = target.board.split("|");
  if (!host || !ORACLE_HOST.test(host) || !site || !/^[A-Za-z0-9_-]{1,40}$/.test(site)) invalid("Invalid Oracle Recruiting board.");
  const api = `https://${host}/hcmRestApi/resources/latest`;
  const found = new Map<string, { title: string; location: string; posted?: string }>();
  const read = async (offset: number, query: string): Promise<number> => {
    const finder = `findReqs;siteNumber=${site},limit=25,offset=${offset},sortBy=POSTING_DATES_DESC${query ? `,keyword=${encodeURIComponent(`"${query}"`)}` : ""}`;
    const page = record(rows(record(await request(budget, `${api}/recruitingCEJobRequisitions?onlyData=true&expand=requisitionList.secondaryLocations&finder=${finder}`)).items)[0]);
    const list = rows(page.requisitionList);
    for (const item of list) {
      const id = String(item.Id ?? ""), title = str(item.Title);
      if (/^\d{1,20}$/.test(id) && title && !found.has(id)) found.set(id, { title, location: [str(item.PrimaryLocation, 200), ...rows(item.secondaryLocations).map(entry => str(entry.Name, 200))].filter(Boolean).join("; "), posted: str(item.PostedDate, 30) });
    }
    return offset === 0 && !query && typeof page.TotalJobsCount === "number" ? page.TotalJobsCount : list.length;
  };
  const total = await read(0, "");
  const truncated = await listing(total, 25, 1000, options.queries, read);
  const jobs: Job[] = [], keep = options.keep ?? keepAll, max = options.maxJobs ?? 400;
  let kept = 0;
  for (const [id, summary] of found) {
    if (!keep(summary.title, summary.location)) continue;
    if (++kept > max) continue;
    let detail: Row;
    try { detail = record(rows(record(await request(budget, `${api}/recruitingCEJobRequisitionDetails?expand=all&onlyData=true&finder=ById;Id=%22${id}%22,siteNumber=${site}`)).items)[0]); } catch (error) {
      if (error instanceof DiscoveryError && error.code === "TIMEOUT") { kept--; break; }
      continue;
    }
    const description = text([detail.ExternalDescriptionStr, detail.ExternalResponsibilitiesStr, detail.ExternalQualificationsStr].filter(value => typeof value === "string").join("\n"));
    if (!description) continue;
    const others = rows(detail.otherWorkLocations).map(entry => [str(entry.TownOrCity, 100), str(entry.Country, 60)].filter(Boolean).join(", "));
    const location = [str(detail.PrimaryLocation, 200) ?? summary.location, ...others].filter(Boolean).join("; ");
    const canonical = `https://${host}/hcmUI/CandidateExperience/en/sites/${site}/job/${id}`;
    const type = workplace(detail.WorkplaceType ?? detail.WorkplaceTypeCode);
    jobs.push(makeJob(target, sourceId, `${host.split(".")[0]}-${site}`, { postingId: id, title: str(detail.Title) ?? summary.title, company, location,
      remote: type === "remote" || /\bremote\b/i.test(location), countries: countriesOf(location, detail.PrimaryLocationCountry), employmentType: employmentLabel(str(detail.JobSchedule, 60)),
      description, canonicalUrl: canonical, applyUrl: canonical, postedAt: isoDate(detail.ExternalPostedStartDate ?? summary.posted), workplaceType: type, department: str(detail.Category, 120) }));
  }
  return { jobs, listed: total, kept: Math.min(kept, max), truncated: truncated || kept > max };
};

const rippling: Crawl = async (target, sourceId, company, budget, options) => {
  if (!SLUG.test(target.board)) invalid("Invalid Rippling board.");
  const base = `https://api.rippling.com/platform/api/ats/v1/board/${target.board}/jobs`;
  const listed = rows(await request(budget, base));
  const jobs: Job[] = [], keep = options.keep ?? keepAll, max = options.maxJobs ?? 400;
  let kept = 0;
  for (const row of listed) {
    const id = str(row.uuid, 40)?.toLowerCase(), title = str(row.name);
    if (!id || !UUID.test(id) || !title) continue;
    const location = str(record(row.workLocation).label, 300) ?? "";
    if (!keep(title, location)) continue;
    if (++kept > max) continue;
    let detail: Row;
    try { detail = record(await request(budget, `${base}/${id}`)); } catch (error) {
      if (error instanceof DiscoveryError && error.code === "TIMEOUT") { kept--; break; }
      continue;
    }
    const parts = record(detail.description);
    const description = text(Object.values(parts).filter(value => typeof value === "string").join("\n"));
    if (!description) continue;
    const places = rows(detail.workLocations).map(entry => str(entry.label ?? entry.name, 200)).filter(Boolean) as string[];
    const all = places.length ? places.join("; ") : location;
    const canonical = `https://ats.rippling.com/${target.board}/jobs/${id}`;
    jobs.push(makeJob(target, sourceId, target.board, { postingId: id, title, company: options.company?.trim() || str(detail.companyName, 200) || company, location: all,
      remote: /\bremote\b/i.test(all), countries: countriesOf(all), employmentType: employmentLabel(str(record(detail.employmentType).label ?? detail.employmentType, 60)),
      description, canonicalUrl: canonical, applyUrl: canonical, postedAt: isoDate(detail.createdOn), department: str(record(row.department).label, 120) }));
  }
  return { jobs, listed: listed.length, kept: Math.min(kept, max), truncated: kept > max };
};

/** Google's results page embeds each page of 20 postings (full sections) as the `ds:1` data block. */
const google: Crawl = async (target, sourceId, company, budget, options) => {
  const found = new Map<string, unknown[]>();
  let total = 0;
  const queries = [...new Set((options.queries ?? []).map(value => value.trim().toLowerCase()).filter(value => value.length >= 2))].slice(0, 8);
  for (const query of queries.length ? queries : [""]) {
    for (let page = 1; page <= 3; page++) {
      const html = await fetchBody(budget, `https://www.google.com/about/careers/applications/jobs/results/?${query ? `q=${encodeURIComponent(query)}&` : ""}page=${page}`, undefined, "text/html");
      const block = html.match(/AF_initDataCallback\(\{key: 'ds:1',[\s\S]*?data:([\s\S]*?), sideChannel:/)?.[1];
      let data: unknown;
      try { data = block ? JSON.parse(block) : undefined; } catch { data = undefined; }
      if (!Array.isArray(data) || !Array.isArray(data[0])) break;
      total = Math.max(total, typeof data[2] === "number" ? data[2] : 0);
      for (const entry of data[0] as unknown[]) if (Array.isArray(entry) && typeof entry[0] === "string" && /^\d{5,25}$/.test(entry[0])) found.set(entry[0], entry);
      if ((data[0] as unknown[]).length < 20 || page * 20 >= (typeof data[2] === "number" ? data[2] : 0)) break;
    }
  }
  const html = (value: unknown) => Array.isArray(value) && typeof value[1] === "string" ? value[1] : "";
  const jobs: Job[] = [], keep = options.keep ?? keepAll, max = options.maxJobs ?? 400;
  let kept = 0;
  for (const [id, entry] of found) {
    const title = str(entry[1]);
    const places = Array.isArray(entry[9]) ? (entry[9] as unknown[]).filter(Array.isArray) as unknown[][] : [];
    const location = places.map(place => str(place[0], 200)).filter(Boolean).join("; ");
    if (!title || !keep(title, location)) continue;
    if (++kept > max) continue;
    const description = text([entry[10], entry[3], entry[4], entry[19]].map(html).filter(Boolean).join("\n"));
    if (!description) continue;
    const canonical = `https://www.google.com/about/careers/applications/jobs/results/${id}`;
    const stamp = Array.isArray(entry[14]) ? entry[14][0] : Array.isArray(entry[12]) ? entry[12][0] : undefined;
    jobs.push(makeJob(target, sourceId, "google", { postingId: id, title, company: options.company?.trim() || str(entry[7], 100) || company, location, remote: /\bremote\b/i.test(location),
      countries: countriesOf(location, ...places.map(place => place[5])), employmentType: "Full-time", description, canonicalUrl: canonical, applyUrl: canonical,
      postedAt: isoDate(stamp) }));
  }
  return { jobs, listed: Math.max(total, found.size), kept: Math.min(kept, max), truncated: true };
};

/** Apple's cookie-bound search session: its CSRF token arrives as a response header together with the session cookies. */
async function appleSession(budget: Budget): Promise<Session> {
  const cookies = new Map<string, string>();
  const session: Session = { headers: {}, seen(headers) {
    for (const line of headers.getSetCookie()) {
      const pair = line.split(";")[0] ?? "", at = pair.indexOf("=");
      const name = pair.slice(0, at).trim(), value = pair.slice(at + 1).trim();
      if (at > 0 && /^[A-Za-z0-9_.-]{1,64}$/.test(name) && /^[\x21-\x3a\x3c-\x7e]{0,400}$/.test(value)) cookies.set(name, value);
    }
    const token = headers.get("x-apple-csrf-token");
    if (token && /^[A-Za-z0-9._-]{16,200}$/.test(token)) session.headers["x-apple-csrf-token"] = token;
    if (cookies.size) session.headers.Cookie = [...cookies].slice(0, 20).map(([name, value]) => `${name}=${value}`).join("; ");
  } };
  await fetchBody(budget, "https://jobs.apple.com/api/v1/CSRFToken", undefined, "application/json", session);
  if (!session.headers["x-apple-csrf-token"] || !session.headers.Cookie) invalid("Apple's jobs site did not start a search session.");
  return session;
}
const APPLE_ID = /^\d{6,12}$/, APPLE_LOCALE = /^[a-z]{2}-[a-z]{2}$/;
interface AppleSummary { title: string; places: Set<string>; locale: string; slug?: string; team?: string; posted?: string }
/**
 * Apple's own jobs site (jobs.apple.com). Every Indian opening is listed (a couple of hundred); elsewhere (thousands of
 * roles) your role-family phrases are searched as exact phrases, because a plain search matches almost every posting.
 * A role posted in several cities appears once per city and is merged. Applying needs your Apple ID sign-in.
 */
const apple: Crawl = async (target, sourceId, company, budget, options) => {
  const session = await appleSession(budget);
  const found = new Map<string, AppleSummary>();
  const search = async (query: string, india: boolean, page: number, collect = true): Promise<{ total: number; count: number }> => {
    const result = record(record(await request(budget, "https://jobs.apple.com/api/v1/search", {
      query, filters: india ? { locations: ["postLocation-INDC"] } : {}, page, locale: india ? "en-in" : "en-us",
      sort: query ? "relevance" : "newest", format: { longDate: "MMMM D, YYYY", mediumDate: "MMM D, YYYY" } }, session)).res);
    const list = rows(result.searchResults);
    for (const row of collect ? list : []) {
      const id = str(row.positionId, 20), title = str(row.postingTitle);
      if (!id || !APPLE_ID.test(id) || !title) continue;
      const locale = str(record(row.localeInfo).defaultLocaleCode, 10)?.toLowerCase();
      const entry = found.get(id) ?? { title, places: new Set<string>(), locale: locale && APPLE_LOCALE.test(locale) ? locale : india ? "en-in" : "en-us",
        slug: str(row.transformedPostingTitle, 200)?.match(/^[a-z0-9-]{1,200}$/)?.[0], team: str(record(row.team).teamCode, 20)?.match(/^[A-Z0-9]{2,20}$/)?.[0], posted: str(row.postDateInGMT, 40) };
      for (const place of rows(row.locations)) { const name = str(place.name, 100); if (name) entry.places.add(name === str(place.countryName, 60) ? name : [name, str(place.countryName, 60)].filter(Boolean).join(", ")); }
      found.set(id, entry);
    }
    return { total: typeof result.totalRecords === "number" ? result.totalRecords : list.length, count: list.length };
  };
  const everywhere = await search("", false, 1, false), india = await search("", true, 1);
  for (let page = 2; page <= Math.min(Math.ceil(india.total / 20), 25); page++) if ((await search("", true, page)).count < 20) break;
  const phrases = [...new Set((options.queries ?? []).map(value => value.trim().toLowerCase().replace(/"/g, "")).filter(value => value.length >= 3))].slice(0, 15);
  for (const phrase of phrases) {
    const first = await search(`"${phrase}"`, false, 1);
    for (let page = 2; page <= Math.min(Math.ceil(first.total / 20), 5); page++) if ((await search(`"${phrase}"`, false, page)).count < 20) break;
  }
  const listed = Math.max(everywhere.total, india.total, found.size);
  const jobs: Job[] = [], keep = options.keep ?? keepAll, max = options.maxJobs ?? 400;
  const picked = [...found].filter(([, summary]) => keep(summary.title, [...summary.places].join("; ")));
  const queue = picked.slice(0, max);
  // Its detail endpoint answers in seconds, so a few are read at once (still about one request a second).
  const read = async (): Promise<void> => { for (let next = queue.shift(); next && !budget.stopped; next = queue.shift()) await detailOf(...next); };
  const detailOf = async (id: string, summary: AppleSummary): Promise<void> => {
    let detail: Row;
    try { detail = record(record(await request(budget, `https://jobs.apple.com/api/v1/jobDetails/${id}?locale=${summary.locale}`)).res); } catch { return; }
    const section = (heading: string, value: unknown) => typeof value === "string" && value.trim() && value.trim() !== "undefined" ? `<h3>${heading}</h3><p>${value.trim().replace(/\n+/g, "<br>")}</p>` : "";
    const description = text([section("Summary", detail.jobSummary), section("Description", detail.description), section("Responsibilities", detail.responsibilities),
      section("Minimum qualifications", detail.minimumQualifications), section("Preferred qualifications", detail.preferredQualifications)].join(""));
    if (!description) return;
    const places = rows(detail.locations).map(place => [str(place.city ?? place.name, 100), str(place.stateProvince, 100), str(place.countryName, 60)].filter(Boolean).join(", ")).filter(Boolean);
    const location = (places.length ? places : [...summary.places]).join("; ");
    const home = detail.homeOffice === true;
    const slug = summary.slug ?? str(detail.transformedPostingTitle, 200)?.match(/^[a-z0-9-]{1,200}$/)?.[0];
    const canonical = `https://jobs.apple.com/${summary.locale}/details/${id}${slug ? `/${slug}` : ""}${summary.team ? `?team=${summary.team}` : ""}`;
    jobs.push(makeJob(target, sourceId, "apple", { postingId: id, title: str(detail.postingTitle) ?? summary.title, company, location: home ? `${location} (Home-based)` : location,
      remote: home, countries: countriesOf(location, ...rows(detail.locations).map(place => place.countryName)), employmentType: "Full-time", description,
      canonicalUrl: canonical, applyUrl: `https://jobs.apple.com/app/${summary.locale}/apply/${id}`, postedAt: isoDate(detail.postDateInGMT ?? summary.posted),
      workplaceType: home ? "remote" : undefined, department: Array.isArray(detail.teamNames) ? str(detail.teamNames[0], 120) : undefined }));
  };
  await Promise.all(Array.from({ length: 4 }, read));
  return { jobs, listed, kept: Math.min(picked.length, max), truncated: true };
};

const atlassian: Crawl = async (target, sourceId, company, budget, options) => {
  const listed = rows(await request(budget, "https://www.atlassian.com/endpoint/careers/listings"));
  const jobs: Job[] = [], keep = options.keep ?? keepAll, max = options.maxJobs ?? 400;
  let kept = 0;
  for (const row of listed) {
    const id = String(row.id ?? ""), title = str(row.title);
    if (!/^\d{1,12}$/.test(id) || !title) continue;
    const location = (Array.isArray(row.locations) ? row.locations.map(value => str(value, 200)).filter(Boolean) as string[] : []).join("; ");
    if (!keep(title, location)) continue;
    if (++kept > max) continue;
    const description = text([row.overview, row.responsibilities, row.qualifications].filter(value => typeof value === "string").join("\n"));
    if (!description) continue;
    let apply = `https://www.atlassian.com/company/careers/details/${id}`;
    try { const url = new URL(String(row.applyUrl)); if (url.protocol === "https:" && url.hostname.endsWith(".icims.com")) apply = url.href; } catch { /* details page */ }
    const updated = str(record(row.portalJobPost).updatedDate, 40);
    jobs.push(makeJob(target, sourceId, "atlassian", { postingId: id, title, company, location, remote: /\bremote\b/i.test(location), countries: countriesOf(location),
      employmentType: "Full-time", description, canonicalUrl: `https://www.atlassian.com/company/careers/details/${id}`, applyUrl: apply,
      postedAt: updated ? isoDate(updated.slice(0, 10)) : undefined, department: str(row.category, 120) }));
  }
  return { jobs, listed: listed.length, kept: Math.min(kept, max), truncated: kept > max };
};

const nutanix: Crawl = async (target, sourceId, company, budget, options) => {
  const xml = await fetchBody(budget, "https://careers.nutanix.com/en/jobs/xml/?rss=true", undefined, "application/xml");
  const parsed = record(new XMLParser({ ignoreAttributes: true, cdataPropName: false, processEntities: true, parseTagValue: false }).parse(xml));
  const container = record(parsed.source ?? parsed.jobs ?? parsed.rss ?? parsed);
  const list = rows(Array.isArray(container.job) ? container.job : container.job ? [container.job] : record(container.channel).job ? [].concat(record(container.channel).job as never) : []);
  const jobs: Job[] = [], keep = options.keep ?? keepAll, max = options.maxJobs ?? 400;
  let kept = 0;
  for (const row of list) {
    const id = String(row.apijobid ?? ""), title = str(row.title);
    if (!/^\d{1,12}$/.test(id) || !title) continue;
    const location = [row.city, row.state, row.country].map(value => str(value, 100)).filter(Boolean).join(", ") + (/remote/i.test(String(row.remotetype ?? "")) ? " (Remote)" : "");
    if (!keep(title, location)) continue;
    if (++kept > max) continue;
    const description = text(row.description);
    if (!description) continue;
    let canonical = `https://careers.nutanix.com/en/jobs/${id}/`;
    try { const url = new URL(String(row.url)); if (url.protocol === "https:" && url.hostname === "careers.nutanix.com") canonical = url.href; } catch { /* built from the id */ }
    jobs.push(makeJob(target, sourceId, "nutanix", { postingId: id, title, company, location, remote: /remote/i.test(location), countries: countriesOf(location, row.country),
      employmentType: employmentLabel(str(row.jobtype, 60)), description, canonicalUrl: canonical, applyUrl: canonical, postedAt: isoDate(row.date),
      workplaceType: workplace(row.remotetype), department: str(row.category, 120), seniority: str(row.experienceLevel, 40) }));
  }
  return { jobs, listed: list.length, kept: Math.min(kept, max), truncated: kept > max };
};

const CRAWLERS: Record<CrawledProvider, Crawl> = { greenhouse, ashby, lever, smartrecruiters, workday, eightfold, oracle, rippling, google, apple, atlassian, nutanix };

/** One bounded crawl of a whole board. Politeness: sequential requests with a small delay; one retry on 429/5xx. */
export async function crawlBoard(target: CareerBoardTarget, sourceId: string, label: string, options: CrawlOptions = {}): Promise<CrawlResult> {
  if (!crawls(target)) throw new DiscoveryError("INVALID_DATA", "This board type is scanned page by page, not crawled.");
  if (!/^[a-z0-9][a-z0-9_-]{0,127}$/i.test(sourceId)) invalid("Invalid career source ID.");
  const paged = ["workday", "smartrecruiters", "eightfold", "oracle", "rippling", "google", "apple"].includes(target.provider);
  const budget = new Budget(options.fetcher ?? fetch, options.delayMs ?? (paged ? 150 : 0),
    options.deadlineMs ?? (target.provider === "apple" ? 600_000 : 240_000), options.maxBytes ?? 150 * 1_048_576, options.signal);
  const result = await CRAWLERS[target.provider](target, sourceId, (options.company ?? label).trim() || target.board, budget, options);
  return budget.stopped ? { ...result, truncated: true } : result;
}
