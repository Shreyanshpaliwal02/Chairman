import type { Source } from "../domain/types";

/** Public GET permission is deliberately independent of permission to operate a form. */
export const SOURCES: Source[] = [
  {
    id: "linkedin", name: "LinkedIn", mode: "manual_only", kind: "manual",
    careersUrl: "https://www.linkedin.com/jobs/",
    discoveryAllowed: false, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://www.linkedin.com/help/linkedin/answer/a1341387/prohibited-software-and-extensions",
    notes: "Manual bookmarks only. No scraping, signed-in page extraction, browser filling or submission. An employer-original destination needs its own permission review."
  },
  {
    id: "indeed", name: "Indeed", mode: "manual_only", kind: "manual",
    careersUrl: "https://www.indeed.com/",
    discoveryAllowed: false, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://www.indeed.com/legal",
    notes: "Manual search and bookmarks only. No verified permission for scraping, signed-in page extraction, browser filling or automated submission. Sign in directly on Indeed; employer-original destinations require their own permission review."
  },
  {
    id: "wellfound", name: "Wellfound", mode: "manual_only", kind: "manual",
    careersUrl: "https://wellfound.com/jobs",
    discoveryAllowed: false, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://wellfound.com/terms",
    notes: "Manual search only; no permitted public discovery interface verified. User-opened pages and slow requests do not authorize automation. Also review https://wellfound.com/terms/jobs."
  },
  {
    id: "naukri", name: "Naukri.com", mode: "manual_only", kind: "manual",
    careersUrl: "https://www.naukri.com/",
    discoveryAllowed: false, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://www.naukri.com/termsconditions/",
    notes: "Policy text/public API permission not verified. No automated requests, DOM extraction, filling or submission."
  },
  {
    id: "supabase", name: "Supabase", mode: "enabled", kind: "ashby",
    endpoint: "https://api.ashbyhq.com/posting-api/job-board/supabase",
    careersUrl: "https://supabase.com/careers",
    discoveryAllowed: true, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://developers.ashbyhq.com/docs/public-job-posting-api",
    notes: "Documented public job-posting GET, verified board supabase; isListed=false is excluded. Personal discovery only, not an application API grant. The unpaginated board may exceed the cloud budget; local scan supported. Employer/form permission remains unverified."
  },
  {
    id: "automattic", name: "Automattic", mode: "enabled", kind: "greenhouse",
    endpoint: "https://boards-api.greenhouse.io/v1/boards/automatticcareers/jobs",
    careersUrl: "https://automattic.com/work-with-us/",
    discoveryAllowed: true, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://docs.greenhouse.io/job-board.html",
    notes: "Documented unauthenticated public GET, board automatticcareers. One job detail per scan after a bounded board index. Prospect/talent-pool posts excluded. Employer-native forms and assessments are manual; GET documentation does not permit browser assistance or POST."
  },
  {
    id: "canonical", name: "Canonical / Ubuntu", mode: "enabled", kind: "greenhouse",
    endpoint: "https://boards-api.greenhouse.io/v1/boards/canonical/jobs",
    careersUrl: "https://canonical.com/careers",
    discoveryAllowed: true, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://docs.greenhouse.io/job-board.html",
    notes: "Official RSS https://canonical.com/careers/feed and documented Greenhouse board canonical verified. Public detail questions are checked for no-AI declarations. Conservative employer-wide AI-prohibited hold: a verified form requires own-words/no-AI answers (job 6448444). Human-authored material/manual process until each current form is reviewed; no auto-certification. Large index may be cloud-deferred."
  },
  {
    id: "safetywing", name: "SafetyWing", mode: "enabled", kind: "rss",
    endpoint: "https://safetywing.pinpointhq.com/jobs.rss",
    careersUrl: "https://safetywing.pinpointhq.com/",
    discoveryAllowed: true, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://safetywing.pinpointhq.com/jobs.rss",
    notes: "Published employer Pinpoint RSS for personal feed discovery only. https://safetywing.pinpointhq.com/faq is additional hiring guidance, not permission to automate forms. Preserve employment labels (including freelance); remote alone does not establish India eligibility. Large feed may be cloud-deferred."
  },
  {
    id: "deel", name: "Deel", mode: "manual_only", kind: "manual",
    careersUrl: "https://jobs.deel.com/",
    discoveryAllowed: false, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://www.deel.com/legal/terms/",
    notes: "Current custom jobs.deel.com portal is manual pending a verified permitted interface and current terms review. Do not substitute an assumed Ashby board or scrape the portal."
  },
  {
    id: "toptal", name: "Toptal", mode: "manual_only", kind: "manual",
    careersUrl: "https://www.toptal.com/careers",
    discoveryAllowed: false, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://www.toptal.com/legal/terms",
    notes: "Manual corporate careers watch. Talent-network onboarding is not a job feed; no bulk network applications or automated screening. Distinguish long-term engineering employment from freelance marketplace gigs."
  },
  {
    id: "himalayas", name: "Himalayas", mode: "enabled", kind: "himalayas",
    endpoint: "https://himalayas.app/jobs/api",
    careersUrl: "https://himalayas.app/jobs",
    discoveryAllowed: true, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://himalayas.app/api",
    notes: "Documented free API expressly permits internal dashboards; OpenAPI license says free with attribution. Keep the original Himalayas job link AND source name. No redistribution to third-party job sites. Respect 429/Retry-After and daily-refreshed data. General terms https://himalayas.app/terms are more restrictive: private, bounded cache only; recheck terms before any wider use. Each application destination needs independent permission."
  },
  {
    id: "remotive", name: "Remotive", mode: "enabled", kind: "remotive",
    endpoint: "https://remotive.com/api/remote-jobs?category=software-dev",
    careersUrl: "https://remotive.com/remote-jobs/software-dev",
    discoveryAllowed: true, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://github.com/remotive-com/remote-jobs-api",
    notes: "Official free, unauthenticated GET; software-dev category only, not all engineering disciplines. API jobs are delayed 24 hours. Publisher advises at most 4 retrievals/day; >2/minute is blocked. At least 6 hours between attempts, including failures, is enforced locally. No documented pagination: complete category, at most 1,000 jobs and 8 MiB; oversized data fails explicitly. Preserve the Remotive name AND original URL; no third-party job-board redistribution or signup/email harvesting. Private bounded cache only; remove when permission ends. Local-only, never a grant to submit applications."
  },
  {
    id: "arbeitnow", name: "Arbeitnow", mode: "enabled", kind: "arbeitnow",
    endpoint: "https://www.arbeitnow.com/api/job-board-api",
    careersUrl: "https://www.arbeitnow.com/",
    discoveryAllowed: true, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://www.arbeitnow.com/terms",
    notes: "Official free unauthenticated API: https://www.arbeitnow.com/blog/job-board-api and linked Postman documentation. Public metadata says hourly updates and ?page= pagination; one full provider page (<=250 jobs, source-specific 2 MiB default) per call, no slicing. A 2026-09-14 read-only page had 250 jobs/1,757,017 bytes; 1 MiB explicitly failed. Caller must wait >=1 hour between attempts (conservative application limit, not a published request allowance). Observed X-RateLimit-Limit: 50 has no window; historical docs show 3, so honor 429/Retry-After, never infer requests/second. Observed HTTP max-age=432000 permits stale cached responses despite hourly-update metadata. Terms section 11 requires an Arbeitnow.com backlink and allows revocation. General terms permit transitory personal viewing and require destruction when viewing/license ends: no public/server mirror or indefinite cache. Mostly Germany/Europe, not automatic India eligibility; missing visa flag stays unknown. Local-only by default; partner application processing is not a candidate API grant."
  },
  {
    id: "remoteok", name: "Remote OK", mode: "enabled", kind: "remoteok",
    endpoint: "https://remoteok.com/api",
    careersUrl: "https://remoteok.com/",
    discoveryAllowed: true, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://remoteok.com/api",
    notes: "Public JSON API includes legal terms as its first metadata record. Requires the Remote OK name AND a follow link to the original listing; logo use requires written permission. No pagination, numeric request quota, refresh SLA or retention limit was verified; once/day is our conservative retrieval limit. Entire returned snapshot only, at most 1,000 jobs and 8 MiB; oversized responses fail explicitly. Not a complete historical archive or guaranteed daily volume. Private bounded cache; remove on permission withdrawal. Local-only; no application permission."
  },
  {
    id: "sideshift", name: "SideShift.app", mode: "manual_only", kind: "manual",
    careersUrl: "https://sideshift.app/",
    discoveryAllowed: false, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: "https://sideshift.app/",
    notes: "Corporate engineering watch only: no official corporate feed or applicable automation permission verified. Policy URL is the identity/reference page, not an automation grant. Not SideShift.ai. Never ingest creator/UGC campaigns, register a creator account or use a customer demo form as a job application."
  }
];

for (const source of SOURCES) Object.freeze(source);
Object.freeze(SOURCES);

export function getSource(id: string): Source | undefined {
  const source = SOURCES.find((entry) => entry.id === id);
  return source ? { ...source } : undefined;
}

/** Persist attempts in the caller; adapters cannot enforce a cross-process/IP-wide quota. */
export function getSourceCooldownMs(sourceId: string): number {
  if (sourceId === "remotive") return 6 * 60 * 60 * 1_000;
  if (sourceId === "arbeitnow") return 60 * 60 * 1_000;
  if (sourceId === "remoteok") return 24 * 60 * 60 * 1_000;
  return 0;
}

export const LOCAL_ONLY_SOURCE_IDS = ["remotive", "arbeitnow", "remoteok"] as const;
