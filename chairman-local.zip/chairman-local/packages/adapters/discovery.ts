import { XMLParser, XMLValidator } from "fast-xml-parser";
import type { AiPolicy, Job, Salary, ScanResult, Source } from "../domain/types";
import { getSource } from "./sources";

type RecordValue = Record<string, unknown>;
export type DiscoveryErrorCode = "UNKNOWN_SOURCE" | "SOURCE_DISABLED" | "INVALID_CURSOR" | "INVALID_DATA" | "TOO_LARGE" | "REDIRECT" | "RATE_LIMITED" | "HTTP_ERROR" | "NETWORK_ERROR" | "TIMEOUT";

export class DiscoveryError extends Error {
  constructor(
    public readonly code: DiscoveryErrorCode,
    message: string,
    public readonly retryAfterMs?: number,
    public readonly httpStatus?: number
  ) {
    super(message);
    this.name = "DiscoveryError";
  }
}

export interface ScanOptions {
  maxResponseBytes?: number;
  timeoutMs?: number;
  /** Entry budget, not a truncation request. Fixed-page feeds fail if it is too small. */
  pageSize?: number;
}

const MAX_DESCRIPTION = 48_000;
const MAX_ROWS = 2_000;
const MAX_CURSOR = 2_048;
const ENTITIES: Record<string, string> = {
  amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " ",
  ndash: "–", mdash: "—", rsquo: "’", lsquo: "‘", rdquo: "”", ldquo: "“",
  bull: "•", hellip: "…", copy: "©", reg: "®"
};

function invalid(message = "Public source returned an invalid payload."): never {
  throw new DiscoveryError("INVALID_DATA", message);
}

function record(value: unknown): RecordValue {
  if (!value || typeof value !== "object" || Array.isArray(value)) invalid();
  return value as RecordValue;
}

function text(value: unknown, max = MAX_DESCRIPTION): string {
  if (typeof value !== "string" || !value.trim() || value.length > max) invalid();
  return value.trim();
}

function optionalText(value: unknown, max = 500): string | undefined {
  if (value === null || value === undefined || value === "") return undefined;
  return text(value, max);
}

function array(value: unknown, max = MAX_ROWS): unknown[] {
  if (!Array.isArray(value) || value.length > max) invalid();
  return value;
}

function strings(value: unknown): string[] {
  return value === undefined || value === null ? [] : array(value, 250).map((item) => text(item, 100));
}

function decodeEntities(input: string): string {
  return input.replace(/&(#x[0-9a-f]{1,6}|#[0-9]{1,7}|[a-z]{2,8});/gi, (whole, entity: string) => {
    if (!entity.startsWith("#")) return ENTITIES[entity.toLowerCase()] ?? whole;
    const hex = entity[1]?.toLowerCase() === "x";
    const code = Number.parseInt(entity.slice(hex ? 2 : 1), hex ? 16 : 10);
    return code > 0 && code <= 0x10ffff && !(code >= 0xd800 && code <= 0xdfff) ? String.fromCodePoint(code) : " ";
  });
}

/** Plain text only, without DOM/Node dependencies. Not an HTML rendering sanitizer. */
export function normalizeHtml(input: string): string {
  if (input.length > 128_000) throw new DiscoveryError("TOO_LARGE", "Job text exceeds the normalization budget.");
  let decoded = input;
  for (let pass = 0; pass < 3; pass++) decoded = decodeEntities(decoded);
  const hidden = new Set(["script", "style", "iframe", "object", "template", "svg"]);
  let hiding: string | undefined;
  let position = 0;
  const pieces: string[] = [];
  for (const match of decoded.matchAll(/<[^<>]*>/g)) {
    if (!hiding) pieces.push(decoded.slice(position, match.index));
    const tag = /^<\s*(\/?)\s*([a-z][a-z0-9]*)/i.exec(match[0]);
    if (tag) {
      const name = tag[2]!.toLowerCase();
      if (tag[1] && name === hiding) hiding = undefined;
      else if (!hiding && !tag[1] && hidden.has(name)) hiding = name;
      if (!hiding && /^(p|br|div|li|h[1-6]|tr|section)$/.test(name)) pieces.push("\n");
    }
    position = match.index + match[0].length;
  }
  if (!hiding) pieces.push(decoded.slice(position));
  const output = pieces.join("").replace(/\r/g, "").replace(/[^\S\n]+/g, " ").replace(/ *\n */g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  if (output.length > MAX_DESCRIPTION) throw new DiscoveryError("TOO_LARGE", "Job description exceeds the storage budget.");
  return output;
}

function normalizedText(value: unknown, max: number): string {
  return text(normalizeHtml(text(value, max)), max);
}

export function detectAiPolicy(input: string): AiPolicy {
  const value = input.toLowerCase().replace(/\s+/g, " ");
  const ai = "(?:generative ai|artificial intelligence|chatgpt|ai[- ]generated|ai(?: tools?| assistance)?)";
  if (new RegExp(`(?:do not|don't|must not|cannot|may not|without|no use of|not to use|refrain from).{0,100}\\b${ai}\\b`).test(value)
    || new RegExp(`\\b${ai}\\b.{0,100}(?:prohibited|not (?:permitted|allowed|accepted)|forbidden|disqualif)`).test(value)
    || /\b(?:answers?|responses?|application)\b.{0,100}\b(?:your (?:own )?words|own words)\b/.test(value)
    || /\bno[- ]ai\b/.test(value)) return "prohibited";
  return "unknown";
}

function date(value: unknown): string | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  const stamp = typeof value === "number" ? (value < 1e12 ? value * 1_000 : value)
    : typeof value === "string" && !/^\d+$/.test(value) ? Date.parse(value) : NaN;
  if (!Number.isFinite(stamp) || Math.abs(stamp) > 8.64e15) invalid("Invalid public posting date.");
  return new Date(stamp).toISOString();
}

function safeLink(value: unknown, hosts?: string[]): string {
  const raw = text(value, 2_048);
  let url: URL;
  try { url = new URL(raw); } catch { return invalid("Invalid public job link."); }
  if (url.protocol !== "https:" || url.username || url.password || url.port
    || !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/i.test(url.hostname)
    || /^\d[\d.]+$/.test(url.hostname) || /\.(?:local|localhost|internal|test|invalid)$/.test(url.hostname)
    || (hosts && !hosts.includes(url.hostname))) invalid("Unsafe public job link.");
  url.hash = "";
  return url.href;
}

const COUNTRY_ALIASES: Record<string, string> = {
  in: "India", ind: "India", india: "India",
  us: "United States", usa: "United States", "united states": "United States", "united states of america": "United States",
  uk: "United Kingdom", gb: "United Kingdom", gbr: "United Kingdom", "united kingdom": "United Kingdom",
  au: "Australia", aus: "Australia", australia: "Australia",
  sg: "Singapore", sgp: "Singapore", singapore: "Singapore",
  jp: "Japan", jpn: "Japan", japan: "Japan",
  ch: "Switzerland", che: "Switzerland", switzerland: "Switzerland",
  de: "Germany", deu: "Germany", germany: "Germany",
  fr: "France", fra: "France", france: "France",
  ca: "Canada", can: "Canada", canada: "Canada",
  nl: "Netherlands", nld: "Netherlands", netherlands: "Netherlands",
  ie: "Ireland", irl: "Ireland", ireland: "Ireland",
  es: "Spain", esp: "Spain", spain: "Spain",
  pt: "Portugal", prt: "Portugal", portugal: "Portugal",
  pl: "Poland", pol: "Poland", poland: "Poland"
};

function country(value: string): string {
  return COUNTRY_ALIASES[value.trim().toLowerCase()] ?? value.trim();
}

function locationCountries(location: string): string[] {
  // Location strings are not authorization evidence. Only explicit country names, not cities/regions or "remote".
  const names = [...new Set(Object.values(COUNTRY_ALIASES))];
  return names.filter((name) => new RegExp(`\\b${name}\\b`, "i").test(location));
}

function employment(value: unknown): string {
  const label = optionalText(value, 100);
  if (!label) return "unknown";
  const compact = label.toLowerCase().replace(/[\s_-]/g, "");
  const labels: Record<string, string> = {
    fulltime: "Full-time", parttime: "Part-time", contractor: "Contract", contract: "Contract",
    temporary: "Temporary", intern: "Internship", internship: "Internship", permanentfulltime: "Permanent - Full-time"
  };
  return labels[compact] ?? label;
}

function salary(min: unknown, max: unknown, currency: unknown, period: unknown, kind: Salary["kind"] = "unknown"): Salary | null {
  const number = (value: unknown) => typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : undefined;
  const low = number(min);
  const high = number(max);
  if ((low === undefined && high === undefined) || (low !== undefined && high !== undefined && low > high)) return null;
  return {
    ...(low !== undefined ? { min: low } : {}),
    ...(high !== undefined ? { max: high } : {}),
    ...(typeof currency === "string" && /^[A-Z]{3}$/.test(currency) ? { currency } : {}),
    ...(typeof period === "string" && period.length < 50 ? { period } : {}),
    kind
  };
}

function baseJob(source: Source, id: string, fields: Pick<Job, "title" | "company" | "description" | "location" | "remote" | "countries" | "employmentType" | "canonicalUrl" | "applyUrl"> & Partial<Job>): Job {
  const fetchedAt = new Date().toISOString();
  return {
    id: `${source.id}:${id}`, sourceId: source.id, sourceJobId: id, fetchedAt,
    salary: null, language: null, sponsorship: "unknown",
    aiPolicy: source.id === "canonical" ? "prohibited" : detectAiPolicy(fields.description),
    status: fields.expiresAt && Date.parse(fields.expiresAt) <= Date.now() ? "closed" : "open",
    ...fields
  };
}

function validateCursor(cursor: string | undefined): void {
  if (cursor !== undefined && (typeof cursor !== "string" || !cursor || cursor.length > MAX_CURSOR || /[\u0000-\u001f\u007f]/.test(cursor))) {
    throw new DiscoveryError("INVALID_CURSOR", "Invalid discovery cursor.");
  }
}

function numericCursor(cursor: string | undefined): void {
  validateCursor(cursor);
  if (cursor !== undefined && !/^[1-9]\d{0,14}$/.test(cursor)) throw new DiscoveryError("INVALID_CURSOR", "Invalid board cursor.");
}

export function retryAfterMs(value: string | null, now = Date.now()): number | undefined {
  if (!value) return undefined;
  if (/^\d+$/.test(value.trim())) {
    const delay = Number(value.trim()) * 1_000;
    return Number.isSafeInteger(delay) ? delay : 365 * 86_400_000;
  }
  const target = Date.parse(value);
  return Number.isFinite(target) ? Math.max(0, target - now) : undefined;
}

function bounds(options: ScanOptions, maxPageSize = 20, defaultPageSize = 10, defaultResponseBytes = 1_048_576) {
  const result = { maxResponseBytes: options.maxResponseBytes ?? defaultResponseBytes, timeoutMs: options.timeoutMs ?? 10_000, pageSize: options.pageSize ?? defaultPageSize };
  if (!Number.isInteger(result.maxResponseBytes) || result.maxResponseBytes < 1 || result.maxResponseBytes > 8_388_608
    || !Number.isInteger(result.timeoutMs) || result.timeoutMs < 1 || result.timeoutMs > 15_000
    || !Number.isInteger(result.pageSize) || result.pageSize < 1 || result.pageSize > maxPageSize) invalid("Invalid scanner budget.");
  return result;
}

async function fetchText(url: URL, fetcher: typeof fetch, options: ReturnType<typeof bounds>, headers?: HeadersInit): Promise<string> {
  const controller = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;
  let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      controller.abort();
      if (reader) void reader.cancel().catch(() => {});
      reject(new DiscoveryError("TIMEOUT", "Public source request timed out."));
    }, options.timeoutMs);
  });
  try {
    return await Promise.race([timeout, (async () => {
      const response = await fetcher(url, {
        method: "GET", redirect: "error", credentials: "omit", referrerPolicy: "no-referrer", signal: controller.signal,
        headers: headers ?? { Accept: "application/json, application/rss+xml, application/xml;q=0.9", "User-Agent": "PersonalJobDiscovery/0.1 (public-feed-only)" }
      });
      if (controller.signal.aborted) {
        void response.body?.cancel().catch(() => {});
        throw new DiscoveryError("TIMEOUT", "Public source request timed out.");
      }
      if (response.redirected || (response.status >= 300 && response.status < 400) || (response.url && response.url !== url.href)) {
        void response.body?.cancel().catch(() => {});
        throw new DiscoveryError("REDIRECT", "Public source redirect refused.");
      }
      if (!response.ok) {
        void response.body?.cancel().catch(() => {});
        throw new DiscoveryError(response.status === 429 ? "RATE_LIMITED" : "HTTP_ERROR", "Public source request failed.", retryAfterMs(response.headers.get("retry-after")), response.status);
      }
      const contentLength = Number(response.headers.get("content-length"));
      if (contentLength > options.maxResponseBytes) {
        void response.body?.cancel().catch(() => {});
        throw new DiscoveryError("TOO_LARGE", "Public payload exceeds the configured byte budget; source deferred.");
      }
      if (!response.body) invalid("Empty public source response.");
      reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8", { fatal: true });
      let bytes = 0;
      const chunks: string[] = [];
      while (true) {
        const chunk = await reader.read();
        if (chunk.done) break;
        bytes += chunk.value.byteLength;
        if (bytes > options.maxResponseBytes) {
          void reader.cancel().catch(() => {});
          throw new DiscoveryError("TOO_LARGE", "Public payload exceeds the configured byte budget; source deferred.");
        }
        chunks.push(decoder.decode(chunk.value, { stream: true }));
      }
      chunks.push(decoder.decode());
      return chunks.join("");
    })()]);
  } catch (error) {
    if (error instanceof DiscoveryError) throw error;
    if (controller.signal.aborted) throw new DiscoveryError("TIMEOUT", "Public source request timed out.");
    throw new DiscoveryError("NETWORK_ERROR", "Public source request or body decoding failed.");
  } finally {
    clearTimeout(timer);
  }
}

export { fetchText as fetchPublicText, locationCountries, country as countryName, employment as employmentLabel };

function parseJson(input: string): unknown {
  let value: unknown;
  try { value = JSON.parse(input); } catch { return invalid("Public source returned malformed JSON."); }
  return value;
}

function json(input: string): RecordValue {
  return record(parseJson(input));
}

function uniqueJobs(jobs: Job[]): Job[] {
  const ids = new Set<string>();
  for (const job of jobs) {
    if (ids.has(job.id)) invalid("Duplicate public posting identifiers.");
    ids.add(job.id);
  }
  return jobs;
}

async function himalayas(source: Source, cursor: string | undefined, fetcher: typeof fetch, options: ReturnType<typeof bounds>): Promise<ScanResult> {
  validateCursor(cursor);
  const url = new URL("https://himalayas.app/jobs/api");
  url.searchParams.set("limit", String(options.pageSize));
  if (cursor) url.searchParams.set("cursor", cursor);
  const payload = json(await fetchText(url, fetcher, options));
  const jobs = array(payload.jobs, options.pageSize).map((value) => normalizeHimalayasJob(source, value));
  const nextCursor = optionalText(payload.nextCursor, MAX_CURSOR);
  validateCursor(nextCursor);
  if (nextCursor && (nextCursor === cursor || !jobs.length)) invalid("Public source returned a non-advancing cursor.");
  return { jobs: uniqueJobs(jobs), ...(nextCursor ? { nextCursor } : {}) };
}

/** Shared browse/search normalization; the caller validates the public endpoint and page. */
export function normalizeHimalayasJob(source: Source, value: unknown): Job {
    const item = record(value);
    const canonicalUrl = safeLink(item.guid, ["himalayas.app"]);
    const countries = [...new Set(strings(item.locationRestrictions).map(country))];
    const zones = item.timezoneRestrictions ?? item.timezoneRestriction;
    const timezoneNote = zones === undefined || zones === null ? "" : array(zones, 100).map((zone) => {
      if ((typeof zone !== "number" || !Number.isFinite(zone)) && typeof zone !== "string") invalid();
      return text(String(zone), 40);
    }).join(", ");
    const description = `${normalizeHtml(text(item.description, 128_000))}\n\nOriginal source: Himalayas — ${canonicalUrl}`;
    if (description.length > MAX_DESCRIPTION) throw new DiscoveryError("TOO_LARGE", "Attributed description exceeds the storage budget.");
    return baseJob(source, canonicalUrl, {
      title: normalizedText(item.title, 500), company: normalizedText(item.companyName, 300),
      description, location: `${countries.length ? countries.join(", ") : "Remote — country eligibility unspecified"}${timezoneNote ? `; timezone restrictions: ${timezoneNote}` : ""}`,
      remote: true, countries, employmentType: employment(item.employmentType),
      canonicalUrl, applyUrl: safeLink(item.applicationLink),
      postedAt: date(item.pubDate), expiresAt: date(item.expiryDate),
      salary: salary(item.minSalary, item.maxSalary, item.currency, item.salaryPeriod ?? "annual")
    });
}

function ashbySalary(item: RecordValue): Salary | null {
  if (item.shouldDisplayCompensationOnJobPostings === false || !item.compensation) return null;
  const compensation = record(item.compensation);
  if (!compensation.summaryComponents) return null;
  const components = array(compensation.summaryComponents, 30).map(record).filter((part) => part.compensationType === "Salary");
  if (components.length !== 1) return null;
  const part = components[0]!;
  const periods: Record<string, string> = { "1 YEAR": "annual", "1 MONTH": "monthly", "1 WEEK": "weekly", "1 HOUR": "hourly" };
  return salary(part.minValue, part.maxValue, part.currencyCode, typeof part.interval === "string" ? periods[part.interval] : undefined, "base");
}

interface AtsJobIdentity {
  company: string;
  canonicalUrl: string;
  applyUrl: string;
  strictGeography?: boolean;
  canonicalHold?: boolean;
}

/** Shared normalization; callers establish board identity and public visibility first. */
export function normalizeAshbyJob(source: Source, id: string, row: RecordValue, identity: AtsJobIdentity): Job {
  const primary = optionalText(row.location, 500) ?? "Location unspecified";
  const secondary = row.secondaryLocations == null ? [] : array(row.secondaryLocations, 100).map(record);
  const location = [primary, ...secondary.map((entry) => optionalText(entry.location, 500)).filter(Boolean)].join("; ");
  const countries = identity.strictGeography && /\b(?:except|excluding|outside|not|other than)\b/i.test(location) ? [] : locationCountries(location);
  if (row.address) {
    const address = record(row.address);
    const postal = address.postalAddress ? record(address.postalAddress) : address;
    const value = optionalText(postal.addressCountry, 100);
    if (value) countries.push(country(value));
  }
  for (const entry of secondary) {
    if (entry.address) {
      const value = optionalText(record(entry.address).addressCountry, 100);
      if (value) countries.push(country(value));
    }
  }
  return baseJob(source, id, {
    title: normalizedText(row.title, 500), company: identity.company, location,
    description: normalizeHtml(text(row.descriptionHtml ?? row.descriptionPlain, 128_000)),
    remote: identity.strictGeography
      ? row.isRemote === true || row.workplaceType === "Remote" || (row.isRemote == null && row.workplaceType == null && /\bremote\b/i.test(primary) && !/\b(?:not|no|non)[ -]remote\b/i.test(primary))
      : row.isRemote === true || row.workplaceType === "Remote" || /\bremote\b/i.test(primary),
    countries: [...new Set(countries)], employmentType: employment(row.employmentType),
    canonicalUrl: identity.canonicalUrl, applyUrl: identity.applyUrl,
    postedAt: date(row.publishedAt), salary: ashbySalary(row)
  });
}

export function normalizeGreenhouseJob(source: Source, id: string, row: RecordValue, identity: AtsJobIdentity): Job {
  const location = row.location ? text(record(row.location).name, 1_000) : "Location unspecified";
  const description = normalizeHtml(text(row.content, 128_000));
  const questionText = row.questions === undefined ? "" : array(row.questions, 150).map((value) => {
    const label = optionalText(record(value).label, 4_000) ?? "";
    return identity.strictGeography ? normalizeHtml(label) : label;
  }).join("\n");
  const metadata = row.metadata == null ? [] : array(row.metadata, 100).map(record);
  const employmentField = metadata.find((entry) => typeof entry.name === "string" && /^(employment (?:type|length)|commitment)$/i.test(entry.name));
  return baseJob(source, id, {
    title: normalizedText(row.title, 500), company: identity.company,
    location, remote: /\b(?:remote|home[- ]based)\b/i.test(location) && (!identity.strictGeography || !/\b(?:not|no|non)[ -](?:remote|home[- ]based)\b/i.test(location)),
    countries: identity.strictGeography && /\b(?:except|excluding|outside|not|other than)\b/i.test(location) ? [] : locationCountries(location),
    employmentType: employment(employmentField?.value),
    description, canonicalUrl: identity.canonicalUrl, applyUrl: identity.applyUrl,
    postedAt: date(row.first_published), expiresAt: date(row.application_deadline),
    aiPolicy: identity.canonicalHold || source.id === "canonical" ? "prohibited" : detectAiPolicy(`${description}\n${questionText}`)
    // Greenhouse's `language` describes the posting, not a working-language requirement.
  });
}

async function ashby(source: Source, cursor: string | undefined, fetcher: typeof fetch, options: ReturnType<typeof bounds>): Promise<ScanResult> {
  validateCursor(cursor);
  if (cursor && !/^[\da-f-]{36}$/i.test(cursor)) throw new DiscoveryError("INVALID_CURSOR", "Invalid Ashby cursor.");
  const payload = json(await fetchText(new URL("https://api.ashbyhq.com/posting-api/job-board/supabase?includeCompensation=true"), fetcher, options));
  const rows = array(payload.jobs).map(record).filter((row) => {
    if (typeof row.isListed !== "boolean") invalid("Missing Ashby listing visibility.");
    return row.isListed;
  }).map((row) => {
    const id = text(row.id, 36);
    if (!/^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/i.test(id)) invalid("Invalid Ashby posting ID.");
    return { id, row };
  }).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0).filter(({ id }) => !cursor || id > cursor);
  const page = rows.slice(0, options.pageSize);
  const jobs = page.map(({ id, row }) => {
    const canonicalUrl = safeLink(row.jobUrl, ["jobs.ashbyhq.com"]);
    const applyUrl = safeLink(row.applyUrl, ["jobs.ashbyhq.com"]);
    if (!new URL(canonicalUrl).pathname.startsWith(`/supabase/${id}`) || !new URL(applyUrl).pathname.startsWith(`/supabase/${id}`)) invalid("Ashby posting link does not match its board.");
    return normalizeAshbyJob(source, id, row, { company: "Supabase", canonicalUrl, applyUrl });
  });
  return { jobs: uniqueJobs(jobs), ...(rows.length > page.length ? { nextCursor: page.at(-1)!.id } : {}) };
}

async function greenhouse(source: Source, cursor: string | undefined, fetcher: typeof fetch, options: ReturnType<typeof bounds>): Promise<ScanResult> {
  numericCursor(cursor);
  const board = source.id === "canonical" ? "canonical" : "automatticcareers";
  const endpoint = `https://boards-api.greenhouse.io/v1/boards/${board}/jobs`;
  const payload = json(await fetchText(new URL(endpoint), fetcher, options));
  const ids = array(payload.jobs).map(record).filter((row) => row.internal_job_id !== null).map((row) => {
    if (typeof row.id !== "number" || !Number.isSafeInteger(row.id) || row.id < 1) invalid("Invalid Greenhouse posting ID.");
    return row.id;
  }).sort((a, b) => a - b).filter((id) => !cursor || id > Number(cursor));
  if (new Set(ids).size !== ids.length) invalid("Duplicate board posting identifiers.");
  if (!ids.length) return { jobs: [] };
  const id = ids[0]!;
  const row = json(await fetchText(new URL(`${endpoint}/${id}?questions=true`), fetcher, options));
  if (row.id !== id) invalid("Board detail does not match the requested posting.");
  const canonicalUrl = safeLink(row.absolute_url, board === "canonical"
    ? ["canonical.com", "boards.greenhouse.io", "job-boards.greenhouse.io"]
    : ["automattic.com", "boards.greenhouse.io", "job-boards.greenhouse.io"]);
  return {
    jobs: [normalizeGreenhouseJob(source, String(id), row, {
      company: board === "canonical" ? "Canonical" : "Automattic", canonicalUrl, applyUrl: canonicalUrl
    })],
    ...(ids.length > 1 ? { nextCursor: String(id) } : {})
  };
}

async function rss(source: Source, cursor: string | undefined, fetcher: typeof fetch, options: ReturnType<typeof bounds>): Promise<ScanResult> {
  numericCursor(cursor);
  const input = await fetchText(new URL("https://safetywing.pinpointhq.com/jobs.rss"), fetcher, options);
  if (/<!\s*(?:DOCTYPE|ENTITY)\b/i.test(input) || XMLValidator.validate(input) !== true) invalid("Invalid or unsafe RSS document.");
  let parsed: unknown;
  try {
    parsed = new XMLParser({ ignoreAttributes: true, parseTagValue: false, processEntities: false, trimValues: true }).parse(input);
  } catch { return invalid("Malformed RSS document."); }
  const channel = record(record(record(parsed).rss).channel);
  const items = channel.item == null ? [] : Array.isArray(channel.item) ? array(channel.item) : [channel.item];
  const rows = items.map(record).map((row) => {
    const link = safeLink(row.link, ["safetywing.pinpointhq.com"]);
    const match = /^\/jobs\/([1-9]\d{0,14})\/?$/.exec(new URL(link).pathname);
    if (!match) invalid("Unexpected Pinpoint job route.");
    return { row, link, id: match[1]! };
  }).sort((a, b) => Number(a.id) - Number(b.id)).filter(({ id }) => !cursor || Number(id) > Number(cursor));
  const page = rows.slice(0, options.pageSize);
  const jobs = page.map(({ row, link, id }) => {
    const description = normalizeHtml(text(row["content:encoded"] ?? row.description, 128_000));
    const location = /^Location:\s*([^\n]+)/im.exec(description)?.[1]?.trim() ?? "Location unspecified";
    const type = /^Employment Type:\s*([^\n]+)/im.exec(description)?.[1]?.trim();
    return baseJob(source, id, {
      title: normalizedText(row.title, 500), company: "SafetyWing", description, location,
      remote: /\bremote\b/i.test(location), countries: locationCountries(location), employmentType: employment(type),
      canonicalUrl: link, applyUrl: link, postedAt: date(row.pubDate)
    });
  });
  return { jobs: uniqueJobs(jobs), ...(rows.length > page.length ? { nextCursor: page.at(-1)!.id } : {}) };
}

const ATTRIBUTION_HOSTS: Record<string, string[]> = {
  himalayas: ["himalayas.app"], remotive: ["remotive.com"],
  arbeitnow: ["www.arbeitnow.com", "arbeitnow.com"], remoteok: ["remoteok.com"]
};

function attributedDescription(source: Source, canonicalUrl: string, description: string, notes: string[] = []): string {
  const attribution = `Original source: ${source.name} — ${canonicalUrl}`;
  const result = [description, ...notes, ...(description.includes(attribution) ? [] : [attribution])].filter(Boolean).join("\n\n");
  if (result.length > MAX_DESCRIPTION) throw new DiscoveryError("TOO_LARGE", "Attributed description exceeds the storage budget.");
  return result;
}

function feedRows(value: unknown, limit: number): RecordValue[] {
  if (!Array.isArray(value)) invalid();
  if (value.length > limit) throw new DiscoveryError("TOO_LARGE", "Complete public feed/page exceeds the entry budget; no jobs were discarded.");
  return value.map(record);
}

function noFeedCursor(cursor: string | undefined): void {
  if (cursor !== undefined) throw new DiscoveryError("INVALID_CURSOR", "This API has no documented pagination; restart a complete snapshot after its cooldown.");
}

function explicitCountries(location: string): string[] {
  // Do not turn exclusions ("everywhere except India") or regions into positive eligibility.
  if (/\b(?:except|excluding|excluded|excludes|not|outside|other than)\b/i.test(location)) return [];
  return [...new Set(location.split(/[,;|]/).flatMap((part) => {
    const value = part.trim().toLowerCase();
    if (value === "worldwide") return ["Worldwide"];
    return COUNTRY_ALIASES[value] ? [COUNTRY_ALIASES[value]!] : [];
  }))];
}

function feedDescription(row: RecordValue): string {
  return normalizeHtml(optionalText(row.description, 128_000) ?? "Description not supplied by source.");
}

function positiveId(value: unknown): string {
  const id = typeof value === "number" && Number.isSafeInteger(value) ? String(value) : text(value, 15);
  if (!/^[1-9]\d{0,14}$/.test(id)) invalid("Invalid public posting identifier.");
  return id;
}

async function remotive(source: Source, cursor: string | undefined, fetcher: typeof fetch, options: ReturnType<typeof bounds>): Promise<ScanResult> {
  noFeedCursor(cursor);
  const payload = json(await fetchText(new URL("https://remotive.com/api/remote-jobs?category=software-dev"), fetcher, options));
  const rows = feedRows(payload.jobs, options.pageSize);
  if (payload["job-count"] !== rows.length) invalid("Remotive job count does not match the complete category response.");
  text(payload["0-legal-notice"], 10_000);
  const jobs = rows.map((row) => {
    const id = positiveId(row.id);
    const canonicalUrl = safeLink(row.url, ATTRIBUTION_HOSTS.remotive);
    if (!new URL(canonicalUrl).pathname.startsWith("/remote-jobs/")) invalid("Unexpected Remotive listing route.");
    const location = optionalText(row.candidate_required_location, 2_000) ?? "Remote — country eligibility unspecified";
    const rawSalary = optionalText(row.salary, 2_000);
    const publication = optionalText(row.publication_date, 100);
    const timezoneUnspecified = publication !== undefined && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?$/.test(publication);
    const postedAt = date(publication);
    const notes = [
      ...(rawSalary ? [`Salary as published (currency, period and base/total type unverified): ${normalizeHtml(rawSalary)}`] : []),
      ...(timezoneUnspecified ? [`Publication date as published (timezone unspecified): ${publication}`] : [])
    ];
    return baseJob(source, id, {
      title: normalizedText(row.title, 500), company: normalizedText(row.company_name, 300),
      description: attributedDescription(source, canonicalUrl, feedDescription(row), notes),
      location, countries: explicitCountries(location), remote: true,
      employmentType: employment(row.job_type), postedAt: timezoneUnspecified ? undefined : postedAt,
      canonicalUrl, applyUrl: canonicalUrl
    });
  });
  return { jobs: uniqueJobs(jobs) };
}

async function arbeitnow(source: Source, cursor: string | undefined, fetcher: typeof fetch, options: ReturnType<typeof bounds>): Promise<ScanResult> {
  numericCursor(cursor);
  const page = Number(cursor ?? 1);
  if (page > 10_000) throw new DiscoveryError("INVALID_CURSOR", "Arbeitnow page exceeds the bounded pagination range.");
  const url = new URL("https://www.arbeitnow.com/api/job-board-api");
  url.searchParams.set("page", String(page));
  const payload = json(await fetchText(url, fetcher, options));
  const rows = feedRows(payload.data, options.pageSize);
  const meta = record(payload.meta);
  if (meta.current_page !== page || !Number.isInteger(meta.per_page) || Number(meta.per_page) < 1
    || Number(meta.per_page) > 250 || rows.length > Number(meta.per_page)) invalid("Invalid Arbeitnow page metadata.");
  const links = record(payload.links);
  let nextCursor: string | undefined;
  if (links.next !== null) {
    const next = new URL(safeLink(links.next, ATTRIBUTION_HOSTS.arbeitnow));
    const nextPage = next.searchParams.get("page");
    if (next.pathname !== "/api/job-board-api" || next.searchParams.size !== 1
      || nextPage !== String(page + 1) || page >= 10_000 || !rows.length) invalid("Arbeitnow returned an unsafe or non-advancing next page.");
    nextCursor = nextPage;
  }
  const jobs = rows.map((row) => {
    const id = text(row.slug, 500);
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id)) invalid("Invalid Arbeitnow posting slug.");
    const canonicalUrl = safeLink(row.url, ATTRIBUTION_HOSTS.arbeitnow);
    if (!/^\/(?:view|jobs)\/[^/]/.test(new URL(canonicalUrl).pathname)) invalid("Unexpected Arbeitnow listing route.");
    if (typeof row.remote !== "boolean" || (row.visa_sponsorship != null && typeof row.visa_sponsorship !== "boolean")) invalid("Invalid Arbeitnow remote or visa flag.");
    const location = optionalText(row.location, 2_000) ?? "Location unspecified";
    const types = strings(row.job_types).map(employment);
    const employmentType = types.length ? text(types.join(", "), 100) : "unknown";
    return baseJob(source, id, {
      title: normalizedText(row.title, 500), company: normalizedText(row.company_name, 300),
      description: attributedDescription(source, canonicalUrl, feedDescription(row)),
      location, countries: explicitCountries(location), remote: row.remote, employmentType,
      sponsorship: row.visa_sponsorship === true ? "yes" : row.visa_sponsorship === false ? "no" : "unknown",
      postedAt: date(row.created_at), canonicalUrl, applyUrl: canonicalUrl
    });
  });
  return { jobs: uniqueJobs(jobs), ...(nextCursor ? { nextCursor } : {}) };
}

async function remoteok(source: Source, cursor: string | undefined, fetcher: typeof fetch, options: ReturnType<typeof bounds>): Promise<ScanResult> {
  noFeedCursor(cursor);
  const entries = feedRows(parseJson(await fetchText(new URL("https://remoteok.com/api"), fetcher, options)), options.pageSize + 1);
  const metadata = entries.shift();
  if (!metadata || metadata.id !== undefined || !/Remote OK/.test(text(metadata.legal, 10_000))
    || typeof metadata.last_updated !== "number" || !date(metadata.last_updated)) invalid("Missing Remote OK legal/update metadata.");
  const jobs = entries.map((row) => {
    const id = positiveId(row.id);
    const canonicalUrl = safeLink(row.url, ATTRIBUTION_HOSTS.remoteok);
    if (!new URL(canonicalUrl).pathname.startsWith("/remote-jobs/")) invalid("Unexpected Remote OK listing route.");
    const location = optionalText(row.location, 2_000) ?? "Remote — country eligibility unspecified";
    const rawSalary: RecordValue = {};
    for (const key of ["salary_min", "salary_max"] as const) {
      if (row[key] != null) {
        if (typeof row[key] !== "number" || !Number.isFinite(row[key]) || row[key] < 0) invalid("Invalid Remote OK salary.");
        rawSalary[key] = row[key];
      }
    }
    const currency = optionalText(row.salary_currency, 3);
    if (currency && !/^[A-Z]{3}$/.test(currency)) invalid("Invalid Remote OK salary currency.");
    if (currency) rawSalary.salary_currency = currency;
    const pay = (Number(row.salary_min) > 0 || Number(row.salary_max) > 0)
      ? salary(Number(row.salary_min) > 0 ? row.salary_min : undefined, Number(row.salary_max) > 0 ? row.salary_max : undefined, currency, undefined) : null;
    return baseJob(source, id, {
      title: normalizedText(row.position, 500), company: normalizedText(row.company, 300),
      description: attributedDescription(source, canonicalUrl, feedDescription(row), Object.keys(rawSalary).length
        ? [`Salary fields as published (period and base/total type unverified; zero may mean unspecified): ${JSON.stringify(rawSalary)}`] : []),
      location, countries: explicitCountries(location), remote: true,
      employmentType: "unknown", salary: pay, postedAt: date(row.date ?? row.epoch),
      canonicalUrl, applyUrl: canonicalUrl
    });
  });
  return { jobs: uniqueJobs(jobs) };
}

/** One bounded provider page/snapshot. Durable cooldowns, retention and retries belong to the caller. */
export async function scanSource(sourceId: string, cursor?: string, fetcher: typeof fetch = fetch, options: ScanOptions = {}): Promise<ScanResult> {
  const source = getSource(sourceId);
  if (!source) throw new DiscoveryError("UNKNOWN_SOURCE", "Unknown discovery source.");
  if (source.mode !== "enabled" || !source.discoveryAllowed || source.kind === "manual") {
    throw new DiscoveryError("SOURCE_DISABLED", "Source is manual-only or not permitted for automated discovery.");
  }
  const limits = source.kind === "arbeitnow" ? bounds(options, 250, 250, 2_097_152)
    : source.kind === "remotive" || source.kind === "remoteok" ? bounds(options, 1_000, 1_000, 8_388_608) : bounds(options);
  if (source.kind === "himalayas") return himalayas(source, cursor, fetcher, limits);
  if (source.kind === "ashby") return ashby(source, cursor, fetcher, limits);
  if (source.kind === "greenhouse") return greenhouse(source, cursor, fetcher, limits);
  if (source.kind === "rss") return rss(source, cursor, fetcher, limits);
  if (source.kind === "remotive") return remotive(source, cursor, fetcher, limits);
  if (source.kind === "arbeitnow") return arbeitnow(source, cursor, fetcher, limits);
  if (source.kind === "remoteok") return remoteok(source, cursor, fetcher, limits);
  throw new DiscoveryError("SOURCE_DISABLED", "No permitted discovery adapter.");
}

/** Rebuild a public Job, rejecting malformed data and discarding all unknown fields. */
export function validatePublicJob(value: unknown): Job {
  const row = record(value);
  const sourceId = text(row.sourceId, 50);
  const source = getSource(sourceId);
  if (!source?.discoveryAllowed) invalid("Unknown public job source.");
  const sourceJobId = text(row.sourceJobId, 2_048);
  if (row.id !== `${sourceId}:${sourceJobId}` || typeof row.remote !== "boolean"
    || !["yes", "no", "unknown"].includes(String(row.sponsorship))
    || !["allowed", "prohibited", "unknown"].includes(String(row.aiPolicy))
    || !["open", "closed"].includes(String(row.status))) invalid("Invalid normalized public job.");
  const pay = row.salary === null ? null : record(row.salary);
  const canonicalUrl = safeLink(row.canonicalUrl, ATTRIBUTION_HOSTS[sourceId]);
  let description = normalizeHtml(text(row.description));
  if (ATTRIBUTION_HOSTS[sourceId]) description = attributedDescription(source, canonicalUrl, description);
  const fetchedAt = date(row.fetchedAt);
  if (!fetchedAt) invalid("Public job is missing its fetch timestamp.");
  return {
    id: text(row.id, 2_100), sourceId, sourceJobId,
    title: normalizedText(row.title, 500), company: normalizedText(row.company, 300),
    location: text(row.location, 2_000), remote: row.remote, countries: strings(row.countries),
    employmentType: text(row.employmentType, 100), description, canonicalUrl, applyUrl: safeLink(row.applyUrl),
    fetchedAt, postedAt: date(row.postedAt), expiresAt: date(row.expiresAt),
    salary: pay ? salary(pay.min, pay.max, pay.currency, pay.period, ["base", "total", "unknown"].includes(String(pay.kind)) ? pay.kind as Salary["kind"] : "unknown") : null,
    language: row.language === null ? null : text(row.language, 100),
    sponsorship: row.sponsorship as Job["sponsorship"],
    aiPolicy: sourceId === "canonical" || detectAiPolicy(description) === "prohibited" ? "prohibited" : row.aiPolicy as AiPolicy,
    status: row.status as Job["status"]
  };
}

export async function syncCloudJobs(baseUrl: string, token: string, cursor?: string, fetcher: typeof fetch = fetch): Promise<ScanResult> {
  let url: URL;
  try { url = new URL(baseUrl); } catch { throw new Error("Invalid scanner base URL."); }
  if (url.protocol !== "https:" || !/^job-application-scanner\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.workers\.dev$/.test(url.hostname)
    || url.port || url.username || url.password || url.pathname !== "/" || url.search || url.hash) {
    throw new Error("Use the exact https://job-application-scanner.<account>.workers.dev hostname.");
  }
  if (token.length < 32 || token.length > 512 || /[^\x21-\x7e]/.test(token)) throw new Error("Invalid scanner sync token.");
  if (cursor !== undefined && (!/^(0|[1-9]\d{0,15})$/.test(cursor) || !Number.isSafeInteger(Number(cursor)))) {
    throw new DiscoveryError("INVALID_CURSOR", "Invalid cloud sync cursor.");
  }
  url.pathname = "/jobs";
  if (cursor !== undefined) url.searchParams.set("cursor", cursor);
  const payload = json(await fetchText(url, fetcher, bounds({ maxResponseBytes: 1_048_576 }), { Accept: "application/json", Authorization: `Bearer ${token}` }));
  const jobs = uniqueJobs(array(payload.jobs, 5).map(validatePublicJob));
  const nextCursor = optionalText(payload.nextCursor, 16);
  if (nextCursor !== undefined && (!/^(0|[1-9]\d{0,15})$/.test(nextCursor) || !Number.isSafeInteger(Number(nextCursor)) || Number(nextCursor) < Number(cursor ?? 0))) {
    invalid("Invalid cloud response cursor.");
  }
  if (jobs.length && (!nextCursor || Number(nextCursor) <= Number(cursor ?? 0))) invalid("Cloud response omitted an advancing continuation cursor.");
  return { jobs, ...(nextCursor !== undefined ? { nextCursor } : {}) };
}
