import type { CareerBoardTarget, CareerLinkResolution, Job, KnownAutomationProvider, ScanResult, Source } from "../domain/types";
import { DiscoveryError, fetchPublicText, normalizeAshbyJob, normalizeGreenhouseJob, normalizeHtml } from "./discovery";
import { isTrackingKey, loadPublicCareerPage, MAX_PUBLIC_PAGE_BYTES, publicCareerPageUrl, safeCareerUrl } from "./public-page";
import { inspectGenericCareerPage, scanGenericCareerBoard, type GenericScanOptions } from "./generic-careers";
import { parseBoardUrl } from "./boards";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const BOARD = /^[a-z0-9][a-z0-9_-]{0,99}$/i;
const GREENHOUSE_HOSTS = new Set(["job-boards.greenhouse.io", "boards.greenhouse.io", "job-boards.eu.greenhouse.io", "boards.eu.greenhouse.io"]);
const MANUAL = "No supported public board link was found. Paste the employer's Greenhouse, Ashby, Lever, SmartRecruiters, Workday, Eightfold, Oracle, Rippling, Google Careers or Apple Jobs board/job link, or use a manual bookmark. JavaScript and linked pages are not loaded.";

function numericId(value: string): boolean {
  return /^[1-9]\d{0,15}$/.test(value) && Number.isSafeInteger(Number(value));
}

function targetFor(provider: KnownAutomationProvider, board: string, jobId?: string): CareerBoardTarget {
  const host = provider === "ashby" ? "jobs.ashbyhq.com" : "job-boards.greenhouse.io";
  return { provider, board, boardUrl: `https://${host}/${board}`, ...(jobId ? { jobId } : {}) };
}

/** Only hosted routes, never guessed employer slugs or arbitrary query-string destinations. */
export function parseCareerTarget(raw: string): CareerBoardTarget | undefined {
  try {
    const url = safeCareerUrl(raw);
    const provider = url.hostname === "jobs.ashbyhq.com" ? "ashby" : GREENHOUSE_HOSTS.has(url.hostname) ? "greenhouse" : undefined;
    if (!provider) return parseBoardUrl(url.href);
    if (provider === "greenhouse" && /^\/embed\/(?:job_app|job_board)\/?$/.test(url.pathname)) {
      const board = url.searchParams.get("for");
      const id = url.searchParams.get("token");
      const job = /^\/embed\/job_app/.test(url.pathname);
      if (!board || !BOARD.test(board) || url.searchParams.getAll("for").length !== 1
        || (job ? !id || !numericId(id) || url.searchParams.getAll("token").length !== 1 : id !== null)
        || [...url.searchParams.keys()].some((key) => key !== "for" && !(job && key === "token") && !isTrackingKey(key))) return undefined;
      const target = targetFor(provider, board, job ? id! : undefined);
      return parseCareerTarget(`${target.boardUrl}${target.jobId ? `/jobs/${target.jobId}` : ""}`);
    }
    if ([...url.searchParams.keys()].some((key) => !isTrackingKey(key))) return undefined;
    const segments = url.pathname.replace(/\/$/, "").slice(1).split("/");
    const board = segments[0]!;
    if (!BOARD.test(board) || board === "embed") return undefined;
    if (segments.length === 1) return targetFor(provider, board);
    if (provider === "ashby" && UUID.test(segments[1] ?? "")
      && (segments.length === 2 || (segments.length === 3 && segments[2] === "application"))) {
      return targetFor(provider, board, segments[1]!.toLowerCase());
    }
    if (provider === "greenhouse" && segments.length === 3 && segments[1] === "jobs" && numericId(segments[2]!)) {
      return targetFor(provider, board, segments[2]);
    }
  } catch {
    // Hosts the generic page fetcher never loads (for example Google Careers) are still boards with their own strict parser.
    return parseBoardUrl(raw);
  }
  return undefined;
}

function decodeAttribute(value: string): string {
  return value.replace(/&(#x[0-9a-f]{1,6}|#[0-9]{1,7}|amp|quot|apos|lt|gt|colon|sol|Tab|NewLine);/gi, (whole, entity: string) => {
    if (!entity.startsWith("#")) return ({ amp: "&", quot: '"', apos: "'", lt: "<", gt: ">", colon: ":", sol: "/", tab: "\t", newline: "\n" } as Record<string, string>)[entity.toLowerCase()] ?? whole;
    const hex = entity[1]?.toLowerCase() === "x";
    const code = Number.parseInt(entity.slice(hex ? 2 : 1), hex ? 16 : 10);
    return code > 0 && code <= 0x10ffff && !(code >= 0xd800 && code <= 0xdfff) ? String.fromCodePoint(code) : "\0";
  });
}

function linkedTargets(html: string): CareerBoardTarget[] {
  const targets = new Map<string, CareerBoardTarget>();
  const hidden = new Set(["script", "style", "textarea", "title", "xmp", "noembed", "noscript", "template", "svg", "math", "object"]);
  const hiding: string[] = [];
  for (let position = 0; position < html.length;) {
    const start = html.indexOf("<", position);
    if (start < 0) break;
    if (html.startsWith("<!--", start)) {
      const end = html.indexOf("-->", start + 4);
      position = end < 0 ? html.length : end + 3;
      continue;
    }
    let end = start + 1;
    let quote = "";
    for (; end < html.length; end++) {
      const char = html[end]!;
      if (quote) { if (char === quote) quote = ""; }
      else if (char === "'" || char === '"') quote = char;
      else if (char === ">") break;
    }
    if (end === html.length) break;
    position = end + 1;
    const tag = html.slice(start + 1, end);
    const name = /^(\/?)([a-z][a-z0-9:-]*)(?=[\s/]|$)/i.exec(tag);
    if (!name) continue;
    const element = name[2]!.toLowerCase();
    if (name[1]) {
      if (hiding.at(-1) === element) hiding.pop();
      continue;
    }
    if (hidden.has(element)) { hiding.push(element); continue; }
    if (hiding.length || (element !== "a" && element !== "iframe")) continue;
    const wanted = element === "a" ? "href" : "src";
    const attributes = tag.slice(name[0].length);
    for (const match of attributes.matchAll(/([^\s"'<>/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g)) {
      if (match[1]!.toLowerCase() !== wanted) continue;
      const raw = decodeAttribute(match[2] ?? match[3] ?? match[4] ?? "");
      const target = parseCareerTarget(raw.startsWith("//") ? `https:${raw}` : raw);
      if (target) targets.set(`${target.provider}:${target.board}:${target.jobId ?? ""}`, target);
      break;
    }
    if (element === "iframe") hiding.push(element);
  }
  return [...targets.values()];
}

export async function resolveCareerLink(
  raw: string,
  options: { fetcher?: typeof fetch; pageLoader?: (url: string) => Promise<string> } = {}
): Promise<CareerLinkResolution> {
  const target = parseCareerTarget(raw);
  if (target) return { target, candidates: [], message: target.jobId ? "Hosted job recognized. Only this public listing will be imported; application permission is separate." : "Hosted board recognized. Public listing discovery does not grant application permission." };
  let url: URL;
  try {
    url = publicCareerPageUrl(raw);
    if (url.hostname === "jobs.ashbyhq.com" || GREENHOUSE_HOSTS.has(url.hostname)) return { candidates: [], message: MANUAL };
  } catch {
    return { candidates: [], message: "This private, blocked, or unsafe link cannot be fetched. Paste a public HTTPS employer careers page or a hosted Ashby/Greenhouse link instead." };
  }
  // `fetcher` is deliberately not a generic transport: it cannot pin DNS or validate redirects.
  const loader = options.pageLoader ?? ((value: string) => loadPublicCareerPage(value, { maxRedirects: 0 }));
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    const html = await Promise.race([
      loader(url.href),
      new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new DiscoveryError("TIMEOUT", "Public careers page timed out; paste a hosted board link.")), 15_000); })
    ]);
    if (typeof html !== "string") throw new DiscoveryError("INVALID_DATA", "Public careers page did not return HTML.");
    if (Buffer.byteLength(html, "utf8") > MAX_PUBLIC_PAGE_BYTES) throw new DiscoveryError("TOO_LARGE", "Public careers HTML exceeds 2 MiB; paste the hosted board link.");
    const candidates = linkedTargets(html);
    if (candidates.length === 1) return { target: candidates[0], candidates: [], message: "One hosted destination found on the public page. Review its employer and application permission before proceeding." };
    if (!candidates.length) {
      const inspected = inspectGenericCareerPage(html, url.href);
      if (inspected.careerPage) return {
        target: { provider: "generic", board: url.hostname, boardUrl: url.href, ...(inspected.singlePosting ? { jobId: url.href } : {}) },
        candidates: [],
        message: inspected.jobs.length
          ? "Public job description found and previewable. Only source text is imported; employer identity, eligibility, and the application form require human review."
          : inspected.links.length
            ? "Public careers links found. A bounded same-origin scan will preview only postings with a real job description; no opening or application permission is assumed."
            : "Public careers watch source recognized, but no extractable job description or listing was found. Paste an actual posting link or full JD for human review. JavaScript and unsupported embedded portals are not loaded; no openings are fabricated."
      };
    }
    return { candidates, message: candidates.length ? "Multiple hosted destinations found. Choose the board or individual job you want; nothing has been imported yet." : MANUAL };
  } catch (error) {
    if (error instanceof DiscoveryError) throw error;
    throw new DiscoveryError("NETWORK_ERROR", "Public careers page could not be loaded; paste its hosted board link.");
  } finally {
    clearTimeout(timer);
  }
}

type Row = Record<string, unknown>;
function invalid(message: string): never {
  throw new DiscoveryError("INVALID_DATA", message);
}
function record(value: unknown): Row {
  if (!value || typeof value !== "object" || Array.isArray(value)) invalid("Invalid public board payload.");
  return value as Row;
}
function rows(value: unknown): Row[] {
  if (!Array.isArray(value)) invalid("Public board returned no job index.");
  if (value.length > 10_000) throw new DiscoveryError("TOO_LARGE", "Public board exceeds the 10,000-entry budget; no listings were discarded.");
  return value.map(record);
}
function missing(): never {
  throw new DiscoveryError("HTTP_ERROR", "This job is closed, missing, or not publicly listed on the selected board.", undefined, 404);
}
function companyName(value: unknown, fallback: string): string {
  if (value === undefined || value === null || value === "") return fallback;
  if (typeof value !== "string" || value.length > 300) invalid("Invalid public employer name.");
  const name = normalizeHtml(value);
  if (!name) invalid("Missing public employer name.");
  return name;
}

function verifiedCompany(target: CareerBoardTarget): string | undefined {
  if (target.provider === "ashby" && target.board.toLowerCase() === "supabase") return "Supabase";
  if (target.provider === "greenhouse") {
    if (target.board.toLowerCase() === "canonical") return "Canonical";
    if (target.board.toLowerCase() === "automatticcareers") return "Automattic";
  }
  return undefined;
}

function checkedTarget(target: CareerBoardTarget): CareerBoardTarget {
  if (!target || typeof target !== "object") invalid("Invalid career board target.");
  const parsed = parseCareerTarget(target.boardUrl);
  if (!parsed || parsed.jobId || parsed.provider !== target.provider || parsed.board !== target.board || parsed.boardUrl !== target.boardUrl
    || (target.jobId !== undefined && (typeof target.jobId !== "string" || (target.provider === "ashby" ? !UUID.test(target.jobId) || target.jobId !== target.jobId.toLowerCase() : !numericId(target.jobId))))) invalid("Career board identity must match its canonical hosted URL.");
  return { ...parsed, ...(target.jobId !== undefined ? { jobId: target.jobId } : {}) };
}

function jobLinks(target: CareerBoardTarget, id: string, values: unknown[]): { canonicalUrl: string; applyUrl: string } {
  for (const value of values) {
    if (typeof value !== "string") invalid("Missing public posting link.");
    const parsed = parseCareerTarget(value);
    if (!parsed || parsed.provider !== target.provider || parsed.board !== target.board || parsed.jobId !== id) {
      invalid("Public posting link does not match the requested board and job.");
    }
  }
  const canonicalUrl = `${target.boardUrl}/${target.provider === "greenhouse" ? "jobs/" : ""}${id}`;
  return { canonicalUrl, applyUrl: `${canonicalUrl}${target.provider === "ashby" ? "/application" : ""}` };
}

function stableJob(job: Job, target: CareerBoardTarget): Job {
  if (!job.description.trim()) invalid("The public listing has no full job description.");
  return { ...job, id: `${target.provider}:${target.board}:${job.sourceJobId}` };
}

/** Public GETs only. Caller persists cooldowns, merges source metadata, and separately authorizes forms. */
export async function scanCareerBoard(
  input: CareerBoardTarget, sourceId: string, label: string, cursor?: string, fetcher: typeof fetch = fetch, genericOptions: GenericScanOptions = {}
): Promise<ScanResult> {
  if (input?.provider === "generic") return scanGenericCareerBoard(input, sourceId, label, cursor, genericOptions);
  const target = checkedTarget(input);
  if (typeof sourceId !== "string" || !/^[a-z0-9][a-z0-9_-]{0,127}$/i.test(sourceId)) invalid("Invalid career source ID.");
  if (typeof label !== "string" || label.length > 300 || /[\u0000-\u001f\u007f]/.test(label)) invalid("Invalid career source label.");
  if (cursor !== undefined && (target.jobId || typeof cursor !== "string"
    || (target.provider === "ashby" ? !UUID.test(cursor) || cursor !== cursor.toLowerCase() : !numericId(cursor)))) {
    throw new DiscoveryError("INVALID_CURSOR", "Invalid career board cursor; individual job links do not paginate.");
  }
  const knownCompany = verifiedCompany(target);
  const boardName = target.board.replace(/[-_]+/g, " ").trim();
  const fallback = knownCompany ?? boardName;
  const source: Source = {
    id: sourceId, name: label.trim() || boardName, mode: "enabled", kind: target.provider, careersUrl: target.boardUrl,
    discoveryAllowed: true, assistanceAllowed: false, submissionAllowed: false,
    policyUrl: target.provider === "ashby" ? "https://developers.ashbyhq.com/docs/public-job-posting-api" : "https://docs.greenhouse.io/job-board.html",
    notes: "User-selected public board, discovery only. Employer identity and form permission need independent review."
  };
  let bytesRemaining = 8 * 1_048_576;
  const deadline = Date.now() + 15_000;
  const get = async (url: string, missingIsJob = Boolean(target.jobId)): Promise<Row> => {
    if (bytesRemaining < 1) throw new DiscoveryError("TOO_LARGE", "Public board scan exceeds 8 MiB.");
    const timeoutMs = deadline - Date.now();
    if (timeoutMs < 1) throw new DiscoveryError("TIMEOUT", "Public board scan exceeded 15 seconds.");
    let body: string;
    try { body = await fetchPublicText(new URL(url), fetcher, { maxResponseBytes: bytesRemaining, timeoutMs, pageSize: 20 }); }
    catch (error) {
      if (missingIsJob && error instanceof DiscoveryError && (error.httpStatus === 404 || error.httpStatus === 410)) missing();
      throw error;
    }
    bytesRemaining -= Buffer.byteLength(body, "utf8");
    let payload: unknown;
    try { payload = JSON.parse(body); } catch { return invalid("Public board returned malformed JSON."); }
    return record(payload);
  };
  if (target.provider === "ashby") {
    const payload = await get(`https://api.ashbyhq.com/posting-api/job-board/${target.board}?includeCompensation=true`);
    const listed = rows(payload.jobs).filter((row) => {
      if (typeof row.isListed !== "boolean") invalid("Missing Ashby public listing visibility.");
      return row.isListed;
    }).map((row) => {
      if (typeof row.id !== "string" || !UUID.test(row.id)) invalid("Invalid Ashby posting identifier.");
      return { id: row.id.toLowerCase(), row };
    }).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
    if (new Set(listed.map(({ id }) => id)).size !== listed.length) invalid("Duplicate public posting identifiers.");
    const remaining = listed.filter(({ id }) => target.jobId ? id === target.jobId : !cursor || id > cursor);
    if (target.jobId && !remaining.length) missing();
    const page = remaining.slice(0, 20);
    const jobs = page.map(({ id, row }) => {
      if (row.isRemote != null && typeof row.isRemote !== "boolean") invalid("Invalid Ashby remote flag.");
      return stableJob(normalizeAshbyJob(source, id, row, {
        company: fallback, ...jobLinks(target, id, [row.jobUrl, row.applyUrl]), strictGeography: true
      }), target);
    });
    return { jobs, ...(remaining.length > page.length ? { nextCursor: page.at(-1)!.id } : {}) };
  }
  const endpoint = `https://boards-api.greenhouse.io/v1/boards/${target.board}/jobs`;
  const payload = await get(endpoint);
  const listed = rows(payload.jobs).filter((row) => {
    if (row.internal_job_id === null) return false;
    if (typeof row.internal_job_id !== "number" || !Number.isSafeInteger(row.internal_job_id) || row.internal_job_id < 1) invalid("Missing Greenhouse public job identity.");
    return true;
  }).map((row) => {
    if (typeof row.id !== "number" || !Number.isSafeInteger(row.id) || row.id < 1) invalid("Invalid Greenhouse posting identifier.");
    return { id: row.id, row };
  }).sort((a, b) => a.id - b.id);
  if (new Set(listed.map(({ id }) => id)).size !== listed.length) invalid("Duplicate public posting identifiers.");
  const remaining = listed.filter(({ id }) => target.jobId ? String(id) === target.jobId : !cursor || id > Number(cursor));
  if (target.jobId && !remaining.length) missing();
  const page = remaining.slice(0, 10);
  const jobs: Job[] = [];
  let boardCompany: string | undefined;
  for (const { id, row: summary } of page) {
    const row = await get(`${endpoint}/${id}?questions=true`);
    if (row.id !== id || (row.internal_job_id !== undefined && row.internal_job_id !== summary.internal_job_id)) invalid("Greenhouse detail does not match the public index.");
    // Known original employer-native URLs are not fetched; their hosted identity comes from this board's index/detail.
    const originalEmployer = target.board.toLowerCase() === "canonical" ? "canonical.com"
      : target.board === "automatticcareers" ? "automattic.com" : undefined;
    const checkedLink = (value: unknown): string => {
      if (originalEmployer && typeof value === "string") {
        try {
          if (safeCareerUrl(value).hostname === originalEmployer) return `${target.boardUrl}/jobs/${id}`;
        } catch { /* Identity checks below fail closed. */ }
      }
      if (typeof value !== "string") invalid("Missing Greenhouse posting link.");
      return value;
    };
    const links = jobLinks(target, String(id), [
      checkedLink(row.absolute_url),
      ...(summary.absolute_url !== undefined ? [checkedLink(summary.absolute_url)] : [])
    ]);
    let company = knownCompany ?? companyName(row.company_name, "");
    if (!company) {
      if (boardCompany === undefined) {
        const metadata = await get(`https://boards-api.greenhouse.io/v1/boards/${target.board}`, false);
        boardCompany = companyName(metadata.name, fallback);
      }
      company = boardCompany;
    }
    jobs.push(stableJob(normalizeGreenhouseJob(source, String(id), row, {
      company, ...links,
      strictGeography: true, canonicalHold: target.board.toLowerCase() === "canonical"
    }), target));
  }
  return { jobs, ...(remaining.length > page.length ? { nextCursor: String(page.at(-1)!.id) } : {}) };
}
