import type { CareerBoardTarget, Job, Salary, ScanResult } from "../domain/types";
import { detectAiPolicy, DiscoveryError, normalizeHtml } from "./discovery";
import { loadPublicCareerPage, MAX_PUBLIC_PAGE_BYTES, publicCareerListingUrl, publicCareerPageUrl, safeCareerUrl } from "./public-page";

type Row = Record<string, unknown>;
type Element = { name: string; attrs: Row; start: number; end: number };
const CAREER_PATH = /(?:^|\/)(?:careers?|jobs?|roles?|positions?|vacancies|vacancy|openings?|opportunities|join-us|work-with-us)(?:\/|[-_]|$)/i;
const NOT_JOB = /\b(?:newsletter|contact|demo|sign[- ]?up|subscribe|talent (?:community|network|pool)|job alerts?|privacy|cookies?|benefits|our values|about us)\b/i;
const INDEX_TITLE = /^(?:careers?|jobs?|open (?:positions|roles)|current (?:openings|vacancies)|join (?:us|our team)|apply(?: now)?)(?:\s*[|—–:-].*)?$/i;
const NOT_JOB_PATH = /(?:^|\/)(?:contact(?:-us)?|demo|newsletter|subscribe|privacy|cookies?|benefits|about|events?|blog|talent-pool|talent-community|job-alerts?)(?:\/|[-_]|$)/i;
const MAX_LINKS = 500;
const MAX_SCAN_BYTES = 8 * 1_048_576;
const MAX_SCAN_MS = 20_000;
const MAX_FOLLOWED_PAGES = 5;

function invalid(message: string): never { throw new DiscoveryError("INVALID_DATA", message); }
function row(value: unknown): Row | undefined {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Row : undefined;
}
function plain(value: unknown, max = 500): string | undefined {
  if (value == null || value === "") return undefined;
  if (typeof value !== "string" || value.length > max) invalid("Invalid public JobPosting text.");
  return normalizeHtml(value) || undefined;
}
function attribute(value: string): string {
  return value.replace(/&(#x[0-9a-f]{1,6}|#[0-9]{1,7}|amp|quot|apos|lt|gt|colon|sol|Tab|NewLine);/gi, (whole, code: string) => {
    if (!code.startsWith("#")) return ({ amp: "&", quot: '"', apos: "'", lt: "<", gt: ">", colon: ":", sol: "/", tab: "\t", newline: "\n" } as Record<string, string>)[code.toLowerCase()] ?? whole;
    const number = Number.parseInt(code.slice(code[1]?.toLowerCase() === "x" ? 2 : 1), code[1]?.toLowerCase() === "x" ? 16 : 10);
    return number > 0 && number <= 0x10ffff && !(number >= 0xd800 && number <= 0xdfff) ? String.fromCodePoint(number) : "\0";
  });
}

/** Small inert HTML tokenizer, not a browser: raw-text/hidden elements cannot contribute links. */
function documentParts(html: string): { elements: Element[]; structured: unknown[]; visible: { start: number; end: number }[]; aiProhibited: boolean } {
  const elements: Element[] = [];
  const structured: unknown[] = [];
  const visible: { start: number; end: number }[] = [];
  const stack: { name: string; element?: Element; hidden: boolean }[] = [];
  const rawText = new Set(["script", "style", "iframe", "textarea", "title", "xmp", "noembed", "noscript"]);
  const hiddenContainers = new Set(["template", "svg", "math", "object"]);
  const voids = new Set(["area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"]);
  let position = 0;
  let tokens = 0;
  let policyTail = "";
  let aiProhibited = false;
  const policy = (text: string) => {
    for (let offset = 0; offset < text.length; offset += 24_000) {
      const part = normalizeHtml(text.slice(offset, offset + 24_000));
      const combined = policyTail + " " + part;
      aiProhibited ||= detectAiPolicy(combined) === "prohibited";
      policyTail = combined.slice(-400);
    }
  };
  while (position < html.length) {
    if (++tokens > 50_000) throw new DiscoveryError("TOO_LARGE", "Public careers HTML exceeds the element budget.");
    const start = html.indexOf("<", position);
    if (!stack.at(-1)?.hidden) {
      const end = start < 0 ? html.length : start;
      if (end > position) visible.push({ start: position, end });
      policy(html.slice(position, end));
    }
    if (start < 0) break;
    if (html.startsWith("<!--", start)) {
      const end = html.indexOf("-->", start + 4);
      position = end < 0 ? html.length : end + 3;
      continue;
    }
    let end = start + 1;
    let quote = "";
    for (; end < html.length; end++) {
      const character = html[end]!;
      if (quote) { if (character === quote) quote = ""; }
      else if (character === "'" || character === '"') quote = character;
      else if (character === ">") break;
    }
    if (end === html.length) break;
    position = end + 1;
    const tag = html.slice(start + 1, end);
    const match = /^(\/?)([a-z][a-z0-9:-]*)(?=[\s/]|$)/i.exec(tag);
    if (!match) continue;
    const name = match[2]!.toLowerCase();
    if (match[1]) {
      const index = stack.findLastIndex((entry) => entry.name === name);
      if (index >= 0) for (const entry of stack.splice(index)) if (entry.element) entry.element.end = start;
      continue;
    }
    const attrs: Row = Object.create(null) as Row;
    for (const value of tag.slice(match[0].length).matchAll(/([^\s"'<>/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g)) {
      const key = value[1]!.toLowerCase();
      if (!Object.hasOwn(attrs, key)) attrs[key] = attribute(value[2] ?? value[3] ?? value[4] ?? "");
    }
    const hidden = Boolean(stack.at(-1)?.hidden || hiddenContainers.has(name) || Object.hasOwn(attrs, "hidden")
      || attrs["aria-hidden"] === "true" || /(?:display\s*:\s*none|visibility\s*:\s*hidden)/i.test(String(attrs.style ?? "")));
    if (rawText.has(name)) {
      const close = new RegExp(`</${name}\\s*>`, "ig");
      close.lastIndex = position;
      const closing = close.exec(html);
      if (!hidden && name === "script" && attrs.type === "application/ld+json" && closing) {
        try { structured.push(JSON.parse(html.slice(position, closing.index))); } catch { /* Invalid JSON is not executable or a posting. */ }
      }
      position = closing ? close.lastIndex : html.length;
      continue;
    }
    const element = hidden ? undefined : { name, attrs, start: position, end: position };
    if (element) elements.push(element);
    if (!voids.has(name)) {
      if (stack.length >= 128) throw new DiscoveryError("TOO_LARGE", "Public careers HTML exceeds the nesting budget.");
      stack.push({ name, element, hidden });
    }
  }
  return { elements, structured, visible, aiProhibited };
}

function postingRows(values: unknown[]): Row[] {
  const jobs: Row[] = [];
  const pending = values.map((value) => ({ value, depth: 0 }));
  let count = 0;
  while (pending.length) {
    const { value, depth } = pending.pop()!;
    if (++count > 10_000 || depth > 32) throw new DiscoveryError("TOO_LARGE", "JobPosting JSON exceeds the structural budget.");
    if (Array.isArray(value)) {
      for (const child of value) pending.push({ value: child, depth: depth + 1 });
    } else {
      const object = row(value);
      if (!object) continue;
      const types = Array.isArray(object["@type"]) ? object["@type"] : [object["@type"]];
      if (types.some((type) => typeof type === "string" && /^(?:(?:https?:\/\/schema\.org\/))?JobPosting$/.test(type))) {
        jobs.push(object);
      } else {
        for (const key of ["@graph", "mainEntity", "itemListElement", "item"]) {
          if (Object.hasOwn(object, key)) pending.push({ value: object[key], depth: depth + 1 });
        }
      }
    }
  }
  if (jobs.length > MAX_LINKS) throw new DiscoveryError("TOO_LARGE", "Public page exceeds 500 job postings.");
  return jobs;
}

function relativeUrl(raw: unknown, page: string): URL | undefined {
  if (typeof raw !== "string" || raw.length > 2_048 || /[\\\u0000-\u0020\u007f]/.test(raw)
    || /%|\/{2}|(?:^|\/)\.{1,2}(?:\/|$)/.test(raw.replace(/^https:\/\//i, "").replace(/^\/\//, "").split(/[?#]/)[0]!)) return undefined;
  try {
    if (raw.startsWith("#") || !raw) return undefined;
    if (/^https:\/\//i.test(raw)) safeCareerUrl(raw);
    else if (raw.startsWith("//")) safeCareerUrl(`https:${raw}`);
    const result = safeCareerUrl(new URL(raw, page).href);
    return result.origin === new URL(page).origin ? result : undefined;
  } catch { return undefined; }
}

function jobUrl(raw: unknown, page: string): string | undefined {
  const resolved = relativeUrl(raw, page);
  if (!resolved || NOT_JOB_PATH.test(resolved.pathname)) return undefined;
  try { return publicCareerPageUrl(resolved.href).href; } catch { return undefined; }
}
function careerUrl(raw: unknown, page: string): string | undefined {
  const url = jobUrl(raw, page);
  if (!url) return undefined;
  const parsed = new URL(url);
  return CAREER_PATH.test(parsed.pathname) || (/^(?:careers?|jobs?)\./i.test(parsed.hostname) && parsed.pathname !== "/") ? url : undefined;
}
function date(value: unknown): string | undefined {
  if (value == null || value === "") return undefined;
  if (typeof value !== "string" || value.length > 100 || !/^\d{4}-\d{2}-\d{2}(?:T.*)?$/.test(value) || !Number.isFinite(Date.parse(value))) invalid("Invalid JobPosting date.");
  return new Date(value).toISOString();
}
function list(value: unknown): unknown[] {
  if (Array.isArray(value) && value.length > 250) invalid("JobPosting metadata exceeds the list budget.");
  return value == null ? [] : Array.isArray(value) ? value : [value];
}
const regionNames = new Intl.DisplayNames(["en"], { type: "region" });
function country(value: unknown): string | undefined {
  const name = plain(row(value)?.name ?? value, 100);
  if (!name || /^(?:remote|worldwide|anywhere|global)$/i.test(name)) return undefined;
  return /^[a-z]{2}$/i.test(name) ? regionNames.of(name.toUpperCase()) ?? name : name;
}
function jobSalary(value: unknown): Salary | null {
  const pay = row(value);
  const amount = row(pay?.value);
  if (!pay || !amount) return null;
  const number = (value: unknown) => typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : undefined;
  const min = number(amount.minValue ?? amount.value);
  const max = number(amount.maxValue ?? amount.value);
  if ((min === undefined && max === undefined) || (min !== undefined && max !== undefined && min > max)) return null;
  const units: Record<string, string> = { HOUR: "hourly", DAY: "daily", WEEK: "weekly", MONTH: "monthly", YEAR: "annual" };
  const period = typeof amount.unitText === "string" ? units[amount.unitText.toUpperCase()] : undefined;
  return {
    ...(min !== undefined ? { min } : {}), ...(max !== undefined ? { max } : {}),
    ...(typeof pay.currency === "string" && /^[A-Z]{3}$/.test(pay.currency) ? { currency: pay.currency } : {}),
    ...(period ? { period } : {}), kind: "base"
  };
}
function canonicalHold(company: string, page: string, organization?: Row): boolean {
  const canonicalHost = (value: string) => {
    try { return /(?:^|\.)canonical\.com$/i.test(new URL(value).hostname); } catch { return false; }
  };
  return /\bcanonical\b/i.test(company) || canonicalHost(page)
    || (typeof organization?.url === "string" && canonicalHost(organization.url));
}
function makeJob(fields: Pick<Job, "title" | "company" | "description" | "canonicalUrl" | "applyUrl"> & Partial<Job>, sourceId: string, pagePolicy: boolean): Job {
  return {
    id: `generic:${fields.canonicalUrl}`, sourceId, sourceJobId: fields.canonicalUrl,
    location: "Location unspecified", remote: false, countries: [], employmentType: "unknown",
    salary: null, language: null, sponsorship: "unknown", fetchedAt: new Date().toISOString(),
    status: fields.expiresAt && Date.parse(fields.expiresAt) <= Date.now() ? "closed" : "open",
    aiPolicy: pagePolicy || canonicalHold(fields.company, fields.canonicalUrl) ? "prohibited" : detectAiPolicy(fields.description),
    ...fields
  };
}

export interface GenericCareerInspection {
  jobs: Job[];
  links: string[];
  nextPage?: string;
  careerPage: boolean;
  singlePosting: boolean;
  aiProhibited: boolean;
}

/** JSON is untrusted source data, never instructions. A title or a CTA alone is not a JD. */
export function inspectGenericCareerPage(html: string, page: string, seed = page, sourceId = "generic"): GenericCareerInspection {
  if (typeof html !== "string") invalid("Public careers page did not return HTML.");
  if (typeof sourceId !== "string" || !/^[a-z0-9][a-z0-9_-]{0,127}$/i.test(sourceId)) invalid("Invalid generic career source identity.");
  if (Buffer.byteLength(html, "utf8") > MAX_PUBLIC_PAGE_BYTES) throw new DiscoveryError("TOO_LARGE", "Public careers HTML exceeds 2 MiB.");
  const pageUrl = publicCareerListingUrl(page, seed);
  const { elements, structured, visible, aiProhibited } = documentParts(html);
  const content = (element: Element, max = 128_000) => {
    let low = 0;
    let high = visible.length;
    while (low < high) {
      const middle = (low + high) >>> 1;
      if (visible[middle]!.start < element.start) low = middle + 1;
      else high = middle;
    }
    const parts: string[] = [];
    let length = 0;
    for (let index = low; index < visible.length && visible[index]!.start < element.end; index++) {
      const span = visible[index]!;
      length += span.end - span.start + 1;
      if (length > max) invalid("Public career element exceeds its text budget.");
      parts.push(html.slice(span.start, span.end));
    }
    return plain(parts.join(element.name === "a" || element.name === "h1" ? " " : "\n"), max);
  };
  const anchors = elements.filter((element) => element.name === "a" && typeof element.attrs.href === "string");
  const applyLinks = new Set(anchors.filter((element) => /^(?:apply(?: (?:now|here|for (?:this|the) (?:job|role|position)))?|apply for .{1,100}|submit (?:an? |your )?application)$/i.test(content(element, 4_000) ?? ""))
    .map((element) => {
      const url = relativeUrl(element.attrs.href, page);
      if (!url || NOT_JOB_PATH.test(url.pathname) || /(?:^|\/)(?:delete|remove|unsubscribe|log-out|signout|sign-out|submit|send|create|update|edit|checkout|purchase|subscribe)(?:\/|$)/i.test(url.pathname)
        || [...url.searchParams.keys()].some((key) => !/^(?:utm_[a-z0-9_]+|source|ref|gh_src)$/i.test(key))) return undefined;
      // Stored for human review only: application destinations are never fetched by discovery.
      url.search = "";
      url.hash = "";
      return url.href;
    }).filter((url): url is string => Boolean(url)));
  const headings = elements.filter((element) => element.name === "h1").map((element) => content(element, 2_000)).filter(Boolean);
  const rows = postingRows(structured);
  const links = new Set<string>();
  const jobs: Job[] = [];
  for (const item of rows) {
    const title = plain(item.title, 500);
    const description = plain(item.description, 128_000);
    const canonicalUrl = jobUrl(item.url, page) ?? (rows.length === 1 ? pageUrl.href : undefined);
    if (canonicalUrl && !description && careerUrl(canonicalUrl, page)) links.add(canonicalUrl);
    if (!title || NOT_JOB.test(title) || INDEX_TITLE.test(title) || !description || description === title || !canonicalUrl) continue;
    // An index cannot assign several jobs to itself or adopt an off-origin job identity.
    if (canonicalUrl === pageUrl.href && rows.length > 1) continue;
    const organization = row(item.hiringOrganization);
    const company = plain(organization?.name ?? (typeof item.hiringOrganization === "string" ? item.hiringOrganization : undefined), 300) ?? "Employer unspecified";
    const places = list(item.jobLocation).map((place) => row(place)?.address ?? place).map((address) => row(address));
    const remote = list(item.jobLocationType).some((value) => value === "TELECOMMUTE");
    const location = places.map((address) => [plain(address?.addressLocality, 100), plain(address?.addressRegion, 100), country(address?.addressCountry)].filter(Boolean).join(", ")).filter(Boolean).join("; ");
    const countries = [...new Set((remote
      ? list(item.applicantLocationRequirements).map((requirement) => country(row(requirement)?.name ?? row(requirement)?.addressCountry ?? requirement))
      : places.map((address) => country(address?.addressCountry))).filter((value): value is string => Boolean(value)))];
    const employmentType = list(item.employmentType).map((type) => plain(type, 100)).filter(Boolean).join(", ") || "unknown";
    jobs.push(makeJob({
      title, company, description, canonicalUrl,
      applyUrl: canonicalUrl === pageUrl.href && applyLinks.size === 1 ? [...applyLinks][0]! : canonicalUrl,
      location: location || (remote ? countries.length ? `Remote — ${countries.join(", ")}` : "Remote — country eligibility unspecified" : "Location unspecified"),
      remote, countries, employmentType, salary: jobSalary(item.baseSalary),
      postedAt: date(item.datePosted), expiresAt: date(item.validThrough),
      ...(canonicalHold(company, page, organization) ? { aiPolicy: "prohibited" as const } : {})
    }, sourceId, aiProhibited));
  }
  if (!rows.length && headings.length === 1 && applyLinks.size === 1 && !NOT_JOB.test(headings[0]!) && !INDEX_TITLE.test(headings[0]!)) {
    const regions = elements.filter((element) => element.attrs.itemprop === "description"
      || /(?:^|[\s_-])(?:job|role|position)[-_ ]?(?:description|details)(?:$|[\s_-])/i.test(`${element.attrs.id ?? ""} ${element.attrs.class ?? ""}`));
    const description = regions.length === 1 ? content(regions[0]!) : undefined;
    if (description && description !== headings[0] && /\b(?:responsibilities|requirements|qualifications|you will|you'll|what you|about (?:the|this) (?:role|job)|experience)\b/i.test(description)) {
      const employer = elements.find((element) => element.attrs.itemprop === "hiringOrganization");
      const company = employer ? content(employer, 1_000) ?? "Employer unspecified" : "Employer unspecified";
      jobs.push(makeJob({ title: headings[0]!, company, description, canonicalUrl: pageUrl.href, applyUrl: [...applyLinks][0]! }, sourceId, aiProhibited));
    }
  }
  let nextPage: string | undefined;
  for (const anchor of anchors) {
    const text = content(anchor, 8_000);
    if (!text || NOT_JOB.test(text) || /^(?:apply\b|submit\b)/i.test(text)) continue;
    const candidate = relativeUrl(anchor.attrs.href, page);
    if (!candidate) continue;
    try {
      const url = publicCareerListingUrl(candidate.href, seed);
      if (url.searchParams.has("page")) {
        if (Number(url.searchParams.get("page")) > Number(pageUrl.searchParams.get("page") ?? 1)
          && (!nextPage || Number(url.searchParams.get("page")) < Number(new URL(nextPage).searchParams.get("page")))) nextPage = url.href;
      } else if (careerUrl(url.href, page) && url.href !== pageUrl.href && url.href !== seed
        && (CAREER_PATH.test(url.pathname) || /\b(?:engineer|developer|architect|scientist|analyst|designer|manager|specialist)\b/i.test(text))) links.add(url.href);
    } catch { /* Unsafe or non-structural query links are not discovery candidates. */ }
  }
  if (links.size > MAX_LINKS) throw new DiscoveryError("TOO_LARGE", "Public careers page exceeds 500 linked candidates.");
  const unique = new Map<string, Job>();
  for (const job of jobs) {
    const previous = unique.get(job.id);
    if (previous && (previous.title !== job.title || previous.description !== job.description || previous.company !== job.company)) invalid("Conflicting duplicate public JobPosting identities.");
    if (previous?.aiPolicy === "prohibited") job.aiPolicy = "prohibited";
    if (previous?.status === "closed") job.status = "closed";
    unique.set(job.id, job);
  }
  const careerHeading = headings.some((heading) => INDEX_TITLE.test(heading!));
  return {
    jobs: [...unique.values()], links: [...links].filter((url) => ![...unique.values()].some((job) => job.canonicalUrl === url)).sort(),
    ...(nextPage ? { nextPage } : {}),
    careerPage: jobs.length > 0 || links.size > 0 || careerHeading || (CAREER_PATH.test(pageUrl.pathname) && !NOT_JOB_PATH.test(pageUrl.pathname)),
    singlePosting: unique.size === 1 && [...unique.values()][0]!.canonicalUrl === pageUrl.href,
    aiProhibited
  };
}

export function checkedGenericCareerTarget(target: CareerBoardTarget): CareerBoardTarget {
  if (!target || typeof target !== "object" || target.provider !== "generic") invalid("Invalid generic career target.");
  const seed = publicCareerPageUrl(target.boardUrl);
  if (seed.href !== target.boardUrl || seed.hostname !== target.board
    || /(?:^|\.)?(?:ashbyhq\.com|greenhouse\.io)$/.test(seed.hostname)
    || (target.jobId !== undefined && (typeof target.jobId !== "string" || jobUrl(target.jobId, seed.href) !== target.jobId
      || (target.jobId !== seed.href && !careerUrl(target.jobId, seed.href))))) invalid("Generic target identity must match its exact public seed URL.");
  return { provider: "generic", board: seed.hostname, boardUrl: seed.href, ...(target.jobId ? { jobId: target.jobId } : {}) };
}

type Cursor = { v: 1; seed: string; page: string; after?: string; aiProhibited?: true };
function readCursor(cursor: string | undefined, target: CareerBoardTarget): Cursor {
  const initial: Cursor = { v: 1, seed: target.boardUrl, page: target.boardUrl };
  if (cursor === undefined) return initial;
  try {
    if (target.jobId || typeof cursor !== "string" || cursor.length > 9_000 || !/^[A-Za-z0-9_-]+$/.test(cursor)) throw new Error();
    const json = Buffer.from(cursor, "base64url").toString("utf8");
    if (Buffer.from(json).toString("base64url") !== cursor) throw new Error();
    const parsed = row(JSON.parse(json));
    if (!parsed || Object.keys(parsed).some((key) => !["v", "seed", "page", "after", "aiProhibited"].includes(key))
      || parsed.v !== 1 || parsed.seed !== target.boardUrl || typeof parsed.page !== "string"
      || (parsed.aiProhibited !== undefined && parsed.aiProhibited !== true)) throw new Error();
    const page = publicCareerListingUrl(parsed.page, target.boardUrl);
    if (page.href !== parsed.page || page.pathname !== new URL(target.boardUrl).pathname
      || (parsed.after !== undefined && (typeof parsed.after !== "string" || careerUrl(parsed.after, target.boardUrl) !== parsed.after))) throw new Error();
    return parsed as Cursor;
  } catch { throw new DiscoveryError("INVALID_CURSOR", "Invalid generic career cursor or seed identity."); }
}

export interface GenericScanOptions {
  /** Trusted fixture seam only. Production always uses DNS-pinned HTTPS, never fetch. */
  pageLoader?: (url: string) => Promise<string>;
}

export async function scanGenericCareerBoard(input: CareerBoardTarget, sourceId: string, label: string, cursor?: string, options: GenericScanOptions = {}): Promise<ScanResult> {
  const target = checkedGenericCareerTarget(input);
  if (typeof sourceId !== "string" || !/^[a-z0-9][a-z0-9_-]{0,127}$/i.test(sourceId)
    || typeof label !== "string" || label.length > 300 || /[\u0000-\u001f\u007f]/.test(label)) invalid("Invalid generic career source identity.");
  const state = readCursor(cursor, target);
  let remaining = MAX_SCAN_BYTES;
  const deadline = Date.now() + MAX_SCAN_MS;
  const get = async (url: string) => {
    publicCareerListingUrl(url, target.boardUrl);
    const timeoutMs = Math.min(15_000, deadline - Date.now());
    if (timeoutMs < 1) throw new DiscoveryError("TIMEOUT", "Generic careers scan exceeded 20 seconds.");
    if (remaining < 1) throw new DiscoveryError("TOO_LARGE", "Generic careers scan exceeded 8 MiB.");
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      const html = await Promise.race([
        options.pageLoader ? options.pageLoader(url) : loadPublicCareerPage(url, { listingSeed: target.boardUrl, timeoutMs, maxResponseBytes: Math.min(remaining, MAX_PUBLIC_PAGE_BYTES) }),
        new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new DiscoveryError("TIMEOUT", "Generic careers page timed out.")), timeoutMs); })
      ]);
      if (typeof html !== "string") invalid("Generic careers page did not return HTML.");
      remaining -= Buffer.byteLength(html, "utf8");
      if (remaining < 0) throw new DiscoveryError("TOO_LARGE", "Generic careers scan exceeded 8 MiB.");
      return inspectGenericCareerPage(html, url, target.boardUrl, sourceId);
    } catch (error) {
      if (error instanceof DiscoveryError) throw error;
      throw new DiscoveryError("NETWORK_ERROR", "Generic careers page could not be fetched.");
    } finally { clearTimeout(timer); }
  };
  const page = await get(target.jobId ?? state.page);
  if (target.jobId) return { jobs: page.jobs.filter((job) => job.canonicalUrl === target.jobId) };
  const aiProhibited = Boolean(state.aiProhibited || page.aiProhibited);
  if (aiProhibited) for (const job of page.jobs) job.aiPolicy = "prohibited";
  const candidates = page.links.filter((url) => !state.after || url > state.after);
  const selected = candidates.slice(0, MAX_FOLLOWED_PAGES);
  const jobs = new Map(page.jobs.map((job) => [job.id, job]));
  for (const url of selected) {
    let detail: GenericCareerInspection;
    try { detail = await get(url); }
    catch (error) {
      if (error instanceof DiscoveryError && (error.httpStatus === 404 || error.httpStatus === 410)) continue;
      throw error;
    }
    // Only the index/pagination seed can expand candidates. Detail links are never recursively crawled.
    for (const job of detail.jobs) {
      if (job.canonicalUrl !== url) continue;
      if (aiProhibited || jobs.get(job.id)?.aiPolicy === "prohibited") job.aiPolicy = "prohibited";
      jobs.set(job.id, job);
    }
  }
  const next = candidates.length > selected.length ? { ...state, after: selected.at(-1)! }
    : page.nextPage ? { v: 1, seed: target.boardUrl, page: page.nextPage } : undefined;
  return { jobs: [...jobs.values()], ...(next ? { nextCursor: Buffer.from(JSON.stringify({ ...next, ...(aiProhibited ? { aiProhibited: true } : {}) })).toString("base64url") } : {}) };
}
