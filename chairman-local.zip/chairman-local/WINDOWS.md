# Chairman for Windows

**Chairman 0.9.0 is a self-contained portable Windows x64 folder.** Transfer
`chairman-windows.zip`, extract it, and double-click **Start Chairman.cmd**.
It includes the built homepage, extension files, Node.js **24.21.0**, all
lockfile-selected production dependencies (including Windows native modules),
and official **Chrome for Testing 153.0.8010.52**. First launch does **not**
download or install npm packages, Node, Chrome, Python, compilers or AI models.
No administrator permission, system PATH change or global installation is used.
This is not a signed `.exe`/MSI installer.

The target is **Windows 10/11 x64**. No native ARM64 package is supplied.
Windows ARM64 can only use this x64 package if the OS supports x64 emulation;
ARM64 compatibility has not been established. Normal supported Windows system
DLLs and security policies still apply. The app cannot bundle the operating
system or guarantee execution on a restricted or out-of-date machine.

**Optional Copilot prerequisite:** the included Copilot helper executables
import `VCRUNTIME140.dll`. On a machine without it, the Copilot backend requires
an approved **Microsoft Visual C++ v14 x64 Redistributable**. This system
component is **not included or automatically installed**. The default Gemini
workflow does not use those Copilot executables. Do not interpret the portable
core package as proof that every optional backend runs on a stock Windows host.

**Internet is still needed for job sites, sign-in, Gmail, Gemini and other
enabled online services.** The package contains software, not credentials,
paid entitlements, inference keys, personal data or pre-authorized accounts.
Nothing enables billing, logs you into websites or activates Auto Apply.

## Transfer and one-click start

1. Copy `chairman-windows.zip` and its `.sha256` sidecar to the destination.
   Compare against the checksum obtained from the trusted distributor:
   `certutil -hashfile chairman-windows.zip SHA256`.
2. Use File Explorer's **Extract All** into a writable local directory with
   a short path. Do not use a network share, protected `Program Files`, or
   run the launcher from inside the ZIP.
3. Open the extracted **Chairman** folder. Keep its `runtime`, `node_modules`,
   `apps`, `packages`, `scripts`, `dist` and `bundle-manifest.json` together.
   Double-click **Start Chairman.cmd** and leave its command window open.
4. The launcher checks the file manifest, native imports, SQLite and synthetic
   PDF processing. Only after the local server confirms this exact app instance
   is ready does bundled Chrome open **http://127.0.0.1:4318**.
5. Follow the dashboard's setup flow with your own profile, approved resumes,
   accounts, keys and consent. Public site access and remote AI need internet.

No npm installation or online repair occurs even if the bundle is incomplete.
A missing/changed runtime, dependency, app file or browser produces a failure
with instructions to re-extract a fresh verified ZIP. Never disable SmartScreen,
antivirus, execution policies, Chrome controls or organization restrictions.
Ask for normal security review when a file or operation is blocked.

The legacy `job-application-assistant-windows.zip` is a byte-identical
compatibility alias. Its own checksum sidecar names that alias. The root
`Start Job Assistant.cmd` also launches Chairman.

## Moving your data from the Mac

`npm run export-data` on the Mac writes `dist/chairman-data-<date>.zip`: your
profile, answer bank, remembered answers, questions from real forms,
companies, today's list, application history, resume library, reference
resumes and generated documents. It leaves out keys, the extension pairing,
browser profiles (sign-ins and cookies), backups and logs, and clears the Mac's
AI choice.

1. Close Chairman on Windows if it is running. If it has run before, rename
   `%LOCALAPPDATA%\Job Application Assistant` to
   `Job Application Assistant (old)`.
2. Type `%LOCALAPPDATA%` into File Explorer's address bar and extract the data
   zip there, so that `%LOCALAPPDATA%\Job Application Assistant\assistant.sqlite`
   exists.
3. Start Chairman, pair the extension again (below) and choose your AI.

The extension reads everything it fills from this folder through the local
service: saved and remembered answers, and the approved resume for each role.

## Chrome and the optional extension

Chairman's bundled Chrome uses a separate persistent **chairman-browser**
profile in the private data directory. Your everyday Chrome installation and
profiles are not imported or changed. Sign into job sites yourself in this
browser when needed. Browser profiles used for application automation are
separate from the dashboard browser; a sign-in in one is not a promise that
another is signed in.

Extension installation requires your explicit one-time action in the browser:

1. In Chairman Chrome, open `chrome://extensions`.
2. Enable **Developer mode** if your organization permits it.
3. Choose **Load unpacked** and select **Chairman\dist\extension**.
4. Follow `dist\extension\README.md` and pair it with this machine's dashboard.

The launcher prints the exact extension folder. It does not use
`--load-extension`, debugging switches, silent extension installation or
managed-policy workarounds. The app can run without the optional extension.
`chairman-chrome-extension.zip` is a separate lightweight copy; the complete
Windows ZIP already includes those same files. Keep the app at port 4318 when
using the extension unless its setup instructions explicitly support another
port.

Chrome for Testing does not automatically update itself. Maintainers must
review and refresh the official browser pin and redistribute a new verified
bundle to obtain browser security updates. Do not replace individual files in
an existing bundle: its integrity manifest will intentionally reject them.

## Free AI, Gemini and activation

AI only helps with questions that have no saved answer; its suggestions are
checked against your confirmed facts, and without AI those questions simply
wait for you. Choose the provider in the dashboard's **AI** tab.

**Ollama (free, runs on this PC).** Install Ollama for Windows from
<https://ollama.com/download>. In a terminal run `setx OLLAMA_NO_CLOUD 1`
(Chairman refuses local AI without it), then quit Ollama from its tray icon,
start it again and restart Chairman so both see the setting. Download a model:
`ollama pull qwen3:4b` (about 2.5 GB; `qwen3:8b` answers better if your GPU has
the memory). In the AI tab choose **Ollama**, pick the model and press **Test**.

**Gemini free tier (remote).** The launcher's default provider. Enter your own
Google Gemini Developer API key
from <https://aistudio.google.com/apikey> in the AI tab. This is not a login to the Gemini
consumer website or a Gemini chat subscription. The reviewed default is
`gemini-2.5-flash`; only the app's explicitly supported model is accepted.

Remote processing starts **OFF**. Review the hosted-processing and free-tier
data-use acknowledgments before opting in. Google's eligible regions, models,
quotas and terms can change. The app does not enable paid billing, but a key
attached to a paid project can incur charges under that project's settings.
Verify your project's billing/free-tier status. Free tier does not mean
unlimited requests or applications.

Existing saved provider and consent settings remain authoritative. Installing,
launching, signing in, saving keys and uploading resumes do not activate Auto
Apply. Review/confirm the profile, upload and approve the required real resumes,
review the application scope, and activate only when you intend to do so.

## Stop, restart and private storage

Press **Ctrl+C once** in the command window and wait for **Stopped**. The local
server and its dedicated automation browsers close. The separate dashboard
Chrome window can remain open; close it normally yourself. Other processes and
everyday Chrome windows are never killed. If Command Prompt asks whether to
terminate the batch job after the app stops, answer `Y`. Do not close the app
mid-submission; unresolved submissions require manual reconciliation.

A second double-click reopens the existing ready dashboard. If it is still
starting, the second window asks you to wait. A different server on the port,
or another copy sharing the same private data directory, is reported as a
conflict without stopping it.

For compatibility, private storage retains the existing name:

```text
%LOCALAPPDATA%\Job Application Assistant
```

This includes the database, resumes, profile, saved keys/consent, Gmail account
authorization if configured, browser sign-ins and `launcher\startup.log`.
Branding changes do not rename or discard your old data. Logs contain bounded
status/error information, not raw dependency failures or secret values.
The previous launcher log is retained as `launcher\startup.previous.log`.

**Deleting the Chairman workspace does not clear the interactive Chrome
profile.** Career-site and Gmail website login cookies in `chairman-browser`
remain, just as they would in an everyday browser; deleting the app's saved
Gmail authorization is separate from signing out of Gmail in Chrome. To clear
those browser sign-ins, use Chairman Chrome's **Clear browsing data** and
select **Cookies and other site data** for **All time**. Alternatively, stop
Chairman and fully exit its Chrome browser normally before manually removing
only `%LOCALAPPDATA%\Job Application Assistant\chairman-browser` (or the
`chairman-browser` folder under your custom `JAA_DATA_DIR`). Removing that
profile also removes its extension installation and other browser settings.
The app never kills Chrome or deletes this profile while it is open.

An absolute `JAA_DATA_DIR` can select another private local directory **outside
the extracted app folder**. macOS retains
`~/Library/Application Support/Job Application Assistant`; Linux retains its
XDG/local-share `job-application-assistant` directory.

For intentional local overrides, copy `.env.example` to `.env`, for example
to set `JAA_PORT=4319`. Environment variables override `.env`; saved AI choices
are still authoritative. Never transfer a used `.env`, private data folder,
browser profile, mailbox authorization, Gemini key or existing host
`node_modules` as part of an installer. Share only the newly built ZIP.

## Troubleshooting and Windows acceptance

- **Integrity failure/missing file:** extract the whole trusted ZIP again.
  Review security software's quarantine report instead of disabling it.
  Do not run npm or download replacement DLLs into the extracted folder.
- **Native runtime failure:** confirm Windows x64, sufficient disk space,
  a short writable path, supported Windows updates and approved runtime DLLs.
  The optional Copilot executables specifically need `VCRUNTIME140.dll`.
  Obtain an administrator-approved Microsoft Visual C++ v14 x64 runtime from
  <https://aka.ms/vc14/vc_redist.x64.exe> if it is absent; review the official
  instructions at <https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist>.
  Do not download loose DLLs from third-party sites. This package does not run
  the installer or request elevated permission.
- **Chrome or extension blocked:** normal organization/browser restrictions
  apply. The launcher does not bypass them or auto-grant permissions.
- **Port occupied:** use the existing app or close the other app yourself.
  Changing ports may require extension configuration; do not share one data
  directory between concurrently running copies.

From Command Prompt in the extracted **Chairman** folder, run this offline
acceptance check without starting the server, calling AI or submitting jobs:

```bat
runtime\win-x64\node.exe scripts\windows\launcher.mjs --check
```

It verifies the entire manifest and exercises native imports, SQLite and
synthetic PDF extraction. It checks Chrome's path, not browser policy approval.
Then try a normal launch, a second launch, Ctrl+C and a restart on Windows.
Packaging/native-PE inspection and helper tests on macOS are **not evidence of
Windows execution**. A real Windows run is still needed before claiming that a
particular machine needs no OS-level prerequisite.

## Building and integrity

Maintainers use the project's existing development environment:

```sh
npm run test:platform
npm run package:windows
```

`npm run package` also produces `chairman-local.zip` with source/build assets;
that source ZIP is **not** the self-contained Windows installer. Each primary
ZIP has a SHA256 sidecar and legacy `job-application-assistant-*` alias.
The packaging commands need `zip`, `unzip`, npm and internet on the build
machine for uncached official/runtime and registry downloads.

Dependencies are freshly staged with `npm ci --os=win32 --cpu=x64 --omit=dev
--include=optional --ignore-scripts --bin-links=false`, never copied from the
development machine's installed dependencies. The npm v3 lockfile supplies
public registry URLs and SHA512 integrity for every permitted package.
Only the Windows production package set is accepted. Optional native packages
are required, not silently dropped. Reviewed Koffi and esbuild packages load
their bundled Windows prebuilds directly; lifecycle scripts are not run.
A new dependency install script makes packaging fail pending maintainer review.

Official Node ZIPs are checked against the reviewed Node SHA256 pins from
<https://nodejs.org/dist/v24.21.0/SHASUMS256.txt>. Chrome comes from Google's
Chrome for Testing stable metadata:
<https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json>.
Its fixed official archive URL and computed SHA256 are pinned in
`scripts/windows/chrome-runtime.mjs`; the reviewed download also matched the
Google Storage MD5 header. These are not claims of a separately published
Google SHA256 signature. Licenses and upstream notices remain in the payload.

Build caches under `dist/.node-runtime-cache`, `dist/.browser-runtime-cache`
and `dist/.npm-package-cache` are not included. Project private directories,
browser state, keys, resumes, databases, test fixtures, Mac native files and
symlinks are excluded. Every selected native executable/DLL/addon must have a
Windows x64 PE header; renaming an ARM64 or Mac binary is not accepted.
Microsoft's Visual C++ redistribution terms require a licensed Visual Studio
distributor. No such entitlement is assumed here, so its DLLs/installer are not
silently redistributed with the optional Copilot helpers.

`bundle-manifest.json` records version, target, upstream provenance,
lock-derived dependencies, per-file sizes and actual SHA256 hashes. The
launcher rechecks these without network access before importing app
dependencies. A mutable manifest is an integrity aid, **not a code signature**;
trust comes from obtaining the ZIP and its checksum through a trusted channel.
