import { useEffect, useState, type FormEvent } from "react";
import { api } from "./api";
import { canPrepareJob, dateLabel, dateTime, errorMessage, pipelineLabels, preparationLabel, type ApplicationStatus, type HistoryItem, type MatchedJob, type ResultPage, type State } from "./model";
import { Badge, Field, Icon, Notice } from "./ui";

function useResults<T>(path: string, refreshKey: State) {
  const [result, setResult] = useState<{ path: string; value: ResultPage<T> }>();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [revision, setRevision] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError("");
    void api<ResultPage<T>>(path, { signal: controller.signal }).then((value) => {
      if (!controller.signal.aborted) setResult({ path, value });
    }).catch((cause) => {
      if (!controller.signal.aborted) setError(errorMessage(cause));
    }).finally(() => {
      if (!controller.signal.aborted) setLoading(false);
    });
    return () => controller.abort();
  }, [path, refreshKey, revision]);
  return { result: result?.path === path ? result.value : undefined, error, loading, retry: () => setRevision((value) => value + 1) };
}

function Pager({ result, busy, label, onPage }: { result: ResultPage<unknown>; busy: boolean; label: string; onPage: (offset: number) => void }) {
  const end = Math.min(result.total, result.offset + result.items.length);
  return <nav className="result-pager" aria-label={`${label} pagination`}><p aria-live="polite">{result.items.length ? `${(result.offset + 1).toLocaleString()}–${end.toLocaleString()}` : "0 records on this page"} of {result.total.toLocaleString()} matching records</p><div className="button-row">
    {result.offset > 0 && <button className="button text-button compact" disabled={busy} onClick={() => onPage(0)}>First page<span className="sr-only"> · {label}</span></button>}
    <button className="button secondary compact" disabled={busy || result.offset === 0} onClick={() => onPage(Math.max(0, result.offset - result.limit))}>Previous<span className="sr-only"> {label} page</span></button>
    <button className="button secondary compact" disabled={busy || result.offset + result.limit >= result.total} onClick={() => onPage(result.offset + result.limit)}>Next<span className="sr-only"> {label} page</span><Icon name="arrow" size={14} /></button>
  </div></nav>;
}

export function StoredJobs({ state, busy, ready, selectedIds, selectionFull, pendingJobs, onSelect, onReview }: { state: State; busy: boolean; ready: boolean; selectedIds: Set<string>; selectionFull: boolean; pendingJobs: Set<string>; onSelect: (job: MatchedJob, checked: boolean) => void; onReview: (job: MatchedJob) => void }) {
  const [draft, setDraft] = useState({ q: "", role: "", location: "", eligibleOnly: false });
  const [filters, setFilters] = useState(draft);
  const [offset, setOffset] = useState(0);
  const query = new URLSearchParams({ offset: String(offset), limit: "50", q: filters.q, role: filters.role, location: filters.location, ...(filters.eligibleOnly ? { eligibleOnly: "true" } : {}) });
  const { result, error, loading, retry } = useResults<MatchedJob>(`/api/jobs?${query}`, state);
  function search(event: FormEvent) { event.preventDefault(); setFilters({ ...draft }); setOffset(0); retry(); }
  return <section id="all-stored-jobs" className="stored-browser" aria-label="Complete opportunities browser"><div className="section-heading"><div><h2>Browse all stored opportunities</h2><p>{(state.pagination?.jobTotal ?? state.stats.totalJobs).toLocaleString()} jobs stored in total. Search the full local database, 50 results per page—not just the active shortlist.</p></div></div>
    <form className="filter-bar stored-filters" onSubmit={search}><Field label="Search all stored jobs">{(id) => <input id={id} type="search" maxLength={100} value={draft.q} onChange={(event) => setDraft({ ...draft, q: event.target.value })} placeholder="Title, employer, or description" />}</Field><Field label="Stored job role">{(id) => <input id={id} maxLength={100} value={draft.role} onChange={(event) => setDraft({ ...draft, role: event.target.value })} placeholder="e.g. data" />}</Field><Field label="Stored job location">{(id) => <input id={id} maxLength={100} value={draft.location} onChange={(event) => setDraft({ ...draft, location: event.target.value })} />}</Field><label className="checkbox-label filter-checkbox"><input type="checkbox" checked={draft.eligibleOnly} onChange={(event) => setDraft({ ...draft, eligibleOnly: event.target.checked })} />Eligible, no review flags</label><button className="button secondary" type="submit" disabled={busy || loading}>Search all jobs</button></form>
    <p className="small muted stored-selection-help">Selections remain in your exact preparation batch above, including when you change pages. Nothing is automatically selected or approved.</p>
    {loading && <p className="small muted" role="status">Loading stored opportunities…</p>}
    {error && <Notice tone="danger">{error} <button className="text-link" onClick={retry}>Retry stored job search</button></Notice>}
    {result && <><Pager result={result} busy={busy || loading} label="stored jobs" onPage={setOffset} />{!result.items.length ? <p className="small muted">No results on this page. Change the search or return to the first page; no stored jobs were deleted.</p> : <div className="application-table-wrap"><table className="application-table"><caption className="sr-only">All stored opportunities, current result page</caption><thead><tr><th scope="col">Prepare locally</th><th scope="col">Opportunity</th><th scope="col">Location</th><th scope="col">Eligibility</th><th scope="col">Details</th></tr></thead><tbody>{result.items.map((job) => <tr key={job.id}><td><label className="checkbox-label"><input type="checkbox" checked={selectedIds.has(job.id)} disabled={busy || loading || !ready || !canPrepareJob(job) || pendingJobs.has(job.id) || (selectionFull && !selectedIds.has(job.id))} onChange={(event) => onSelect(job, event.target.checked)} /><span className="sr-only">Prepare stored job {job.title} at {job.company} locally</span></label></td><td><strong>{job.title}</strong><span>{job.company}</span></td><td>{job.location || "Unknown"}</td><td><Badge tone={!canPrepareJob(job) ? "danger" : job.match.needsReview ? "warning" : "positive"}>{pendingJobs.has(job.id) ? "Already queued" : !canPrepareJob(job) ? "Blocked" : job.match.needsReview ? "Review flags" : "Eligible"}</Badge></td><td><button className="button secondary compact" disabled={loading || busy} onClick={() => onReview(job)}>Review job<span className="sr-only"> {job.title} at {job.company}</span></button></td></tr>)}</tbody></table></div>}<Pager result={result} busy={busy || loading} label="stored jobs" onPage={setOffset} /></>}
  </section>;
}

export function ApplicationHistory({ state, busy, statuses, onReview }: { state: State; busy: boolean; statuses: Record<ApplicationStatus, { label: string; tone: "neutral" | "positive" | "warning" | "danger" }>; onReview: (id: string) => void }) {
  const [draft, setDraft] = useState({ q: "", status: "", stage: "" });
  const [filters, setFilters] = useState(draft);
  const [offset, setOffset] = useState(0);
  const query = new URLSearchParams({ offset: String(offset), limit: "50", q: filters.q, ...(filters.status ? { status: filters.status } : {}), ...(filters.stage ? { stage: filters.stage } : {}) });
  const { result, error, loading, retry } = useResults<HistoryItem>(`/api/history?${query}`, state);
  function search(event: FormEvent) { event.preventDefault(); setFilters({ ...draft }); setOffset(0); retry(); }
  return <section id="all-application-history" className="stored-browser" aria-label="Complete application history"><div className="section-heading"><div><h2>Complete application history</h2><p>{(state.pagination?.packetTotal ?? state.packets.length).toLocaleString()} packets stored in total. Search older records across the full database; opening one loads its exact packet and original job.</p></div></div>
    <form className="filter-bar stored-filters" onSubmit={search}><Field label="Search application history">{(id) => <input id={id} type="search" maxLength={100} value={draft.q} onChange={(event) => setDraft({ ...draft, q: event.target.value })} placeholder="Title or employer" />}</Field><Field label="History submission outcome">{(id) => <select id={id} value={draft.status} onChange={(event) => setDraft({ ...draft, status: event.target.value })}><option value="">All outcomes</option>{Object.entries(statuses).map(([value, item]) => <option key={value} value={value}>{item.label}</option>)}</select>}</Field><Field label="History hiring stage">{(id) => <select id={id} value={draft.stage} onChange={(event) => setDraft({ ...draft, stage: event.target.value })}><option value="">All recorded stages</option>{Object.entries(pipelineLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>}</Field><button className="button secondary" type="submit" disabled={busy || loading}>Search history</button></form>
    {loading && <p className="small muted" role="status">Loading application history…</p>}
    {error && <Notice tone="danger">{error} <button className="text-link" onClick={retry}>Retry history search</button></Notice>}
    {result && <><Pager result={result} busy={busy || loading} label="history" onPage={setOffset} />{!result.items.length ? <p className="small muted">No results on this page. Adjust the filters or return to the first page. Your older records remain stored.</p> : <div className="application-table-wrap"><table className="application-table"><caption className="sr-only">Application history, current result page</caption><thead><tr><th scope="col">Opportunity</th><th scope="col">Submission</th><th scope="col">Hiring progress</th><th scope="col">Next action</th><th scope="col">Details</th></tr></thead><tbody>{result.items.map(({ packet, job }) => <tr key={packet.id}><td><strong>{job.title}</strong><span>{job.company}</span><span>{preparationLabel(packet.draft.mode, packet.tailoring?.engine)}{packet.approvedBy === "autopilot" ? " · Auto Apply consent" : ""}</span><span>{dateTime(packet.createdAt)}</span></td><td><Badge tone={statuses[packet.status].tone}>{statuses[packet.status].label}</Badge></td><td>{packet.status === "submitted_confirmed" ? pipelineLabels[packet.progress?.stage || "applied"] : "Awaiting confirmation"}</td><td>{dateLabel(packet.progress?.nextActionDate)}</td><td><button className="button secondary compact" disabled={busy || loading} onClick={() => onReview(packet.id)}>Open history packet<span className="sr-only"> {job.title} at {job.company}</span></button></td></tr>)}</tbody></table></div>}<Pager result={result} busy={busy || loading} label="history" onPage={setOffset} /></>}
  </section>;
}
