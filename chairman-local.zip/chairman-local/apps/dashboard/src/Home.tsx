import { useEffect, useState, type FormEvent } from "react";
import { post } from "./api";
import { campaignToday, dateLabel, dateTime, isFollowUpDue, pipelineLabels, type CampaignConfig, type Page, type RunAction, type State } from "./model";
import { Badge, Field, Icon, Notice, PackageDownloads } from "./ui";
import { hasAutoApply } from "./AutoApply";
import { MIN_APPROVED_RESUMES } from "../../../packages/domain/types";

export function Home({ state, busy, run, navigate, viewPacket }: { state: State; busy: boolean; run: RunAction; navigate: (page: Page) => void; viewPacket: (id: string) => void }) {
  const campaign = state.campaign;
  if (!campaign) return <><AutoApplyStart state={state} navigate={navigate} /><Notice tone="warning">Campaign statistics are not available from the local service yet. Restart the updated service, then refresh. The default plan is 500 confirmed applications per day for 45 days—not a guarantee.</Notice><PackageDownloads /></>;
  const today = campaignToday();
  const due = state.packets.filter((packet) => isFollowUpDue(packet, today)).sort((a, b) => a.progress!.nextActionDate!.localeCompare(b.progress!.nextActionDate!));
  const recentDays = campaign.daily.filter((day) => day.date <= today).slice(-7);
  const rate = campaign.confirmedTotal ? (campaign.interviews / campaign.confirmedTotal * 100).toFixed(1) : "0.0";
  const queued = state.preparationSummary ? state.preparationSummary.queued + state.preparationSummary.running
    : (state.preparationQueue || []).filter((task) => task.status === "queued" || task.status === "running").length;
  const prepared = state.packets.filter((packet) => packet.status === "prepared").length;
  const number = (value: number) => value.toLocaleString();

  return <div className="home-view">
    <AutoApplyStart state={state} navigate={navigate} />
    <section className="campaign-board" aria-label="Campaign target and confirmed results">
      <div className="campaign-plan"><h2>{number(campaign.config.dailyTarget)} a day.<br />{number(campaign.config.days)} days of intention.</h2>
        <p><strong>{number(campaign.totalTarget)} confirmed applications</strong> is your campaign goal. Preparation, approval, and attempts do not count as submissions.</p>
        <div className="campaign-dates"><span>{dateLabel(campaign.config.startDate)} — {dateLabel(campaign.endDate)}</span><Badge>{today < campaign.config.startDate ? "Not started" : today > campaign.endDate ? "Campaign ended" : `Day ${campaign.dayNumber} of ${campaign.config.days}`}</Badge></div>
        <div className="button-row"><button className="button secondary" onClick={() => navigate("opportunities")}>Browse opportunities<Icon name="arrow" size={16} /></button><button className="button text-button" onClick={() => navigate("applications")}>Review packets & receipts</button></div>
      </div>
      <div className="campaign-results"><h3>Confirmed, not estimated</h3><div className="campaign-total"><strong>{number(campaign.confirmedTotal)}</strong><span>of {number(campaign.totalTarget)} goal</span></div>
        <progress className="campaign-progress" max={Math.max(1, campaign.totalTarget)} value={Math.min(campaign.confirmedTotal, campaign.totalTarget)} aria-label={`${number(campaign.confirmedTotal)} confirmed applications of ${number(campaign.totalTarget)} campaign goal`} />
        <dl className="campaign-measures"><div><dt>Confirmed today</dt><dd>{number(campaign.confirmedToday)} <small>/ {number(campaign.config.dailyTarget)} target</small></dd></div><div><dt>Days left</dt><dd>{number(campaign.daysRemaining)}</dd></div><div><dt>Target to date</dt><dd>{number(campaign.targetToDate)}</dd></div><div><dt>Remaining to goal</dt><dd>{number(campaign.remainingToGoal)}</dd></div></dl>
      </div>
    </section>
    <p className="campaign-disclaimer">A planning target, never a promise of submissions, interviews, offers, sponsorship, or compensation. Worldwide discovery does not establish work authorization or remote eligibility. A prepared resume, filled form, manual handoff, or unknown outcome is not an applied job.</p>
    <CampaignSettings config={campaign.config} busy={busy} run={run} />
    {campaign.untrackedSubmissionDates > 0 && <Notice tone="warning">{number(campaign.untrackedSubmissionDates)} confirmed {campaign.untrackedSubmissionDates === 1 ? "submission has" : "submissions have"} no tracked submission date. Undated records cannot be placed in the campaign’s daily totals.</Notice>}

    <section className="stats-strip home-outcomes" aria-label="Campaign outcomes">
      <div><span>Interviews</span><strong>{number(campaign.interviews)}</strong><small>Explicitly recorded by you</small></div>
      <div><span>Offers</span><strong>{number(campaign.offers)}</strong><small>Explicitly recorded by you</small></div>
      <div><span>Interview conversion</span><strong>{rate}<span className="stat-denominator">%</span></strong><small>Recorded interviews / campaign confirmations</small></div>
      <div><span>Follow-ups due</span><strong>{number(campaign.followUpsDue)}</strong><small>Scheduled today or overdue · Asia/Kolkata</small></div>
    </section>

    <div className="home-columns">
      <section className="home-section"><div className="section-heading"><div><h2>Follow through</h2><p>Your next actions—not automated messages.</p></div><button className="text-link" onClick={() => navigate("applications")}>Application ledger<Icon name="arrow" size={14} /></button></div>
        {due.length ? <ul className="follow-up-list">{due.slice(0, 8).map((packet) => {
          const job = state.jobs.find((item) => item.id === packet.jobId);
          return <li key={packet.id}><div><strong>{job?.company || "Listing unavailable"} · {job?.title || packet.jobId}</strong><span>{pipelineLabels[packet.progress!.stage]} · {packet.progress!.nextActionDate! < today ? "Overdue" : "Due today"} · {dateLabel(packet.progress!.nextActionDate)}</span>{packet.progress?.note && <p>{packet.progress.note}</p>}</div><button className="button secondary compact" onClick={() => viewPacket(packet.id)}>Update<span className="sr-only"> {job?.title || packet.id}</span></button></li>;
        })}</ul> : <div className="quiet-empty"><Icon name="check" /><h3>{campaign.followUpsDue > 0 ? "Due follow-ups are in your history" : "No follow-ups due in loaded records"}</h3><p>{campaign.followUpsDue > 0 ? "Open the complete application history to find older confirmed applications and their next-action dates." : "Add a next-action date to a confirmed application to keep the next conversation in view."}</p></div>}
        <p className="small muted">This list uses loaded packets. Campaign counts cover all stored records; use complete application history and external application records for other follow-ups.</p>
        {due.length > 8 && <p className="small muted">{due.length - 8} more due. Open Applications and use “Due follow-ups” to see every record.</p>}
      </section>
      <section className="home-section"><div className="section-heading"><div><h2>Today’s workspace</h2><p>Keep preparation and sending separate.</p></div></div>
        <dl className="workspace-counts"><div><dt>Local preparation pending</dt><dd>{number(queued)}</dd></div><div><dt>Loaded packets awaiting review</dt><dd>{number(prepared)}</dd></div><div><dt>Submission attempts today</dt><dd>{number(state.stats.attemptsToday)}</dd></div><div><dt>Attempts this service session</dt><dd>{state.stats.attemptsSession === undefined ? "Not reported" : number(state.stats.attemptsSession)}</dd></div></dl>
        <Notice>{state.stats.limit === null ? <><strong>No global daily or session cap.</strong> Lower source/site limits, eligibility, policies, and explicit packet or Auto Apply authorization still apply.</> : <><strong>Your optional daily cap: {number(state.stats.limit)} attempts.</strong> No separate global session cap. Lower source limits still apply.</>}</Notice>
        <button className="text-link" onClick={() => navigate("resumes")}>Build local reference drafts<Icon name="arrow" size={14} /></button>
      </section>
    </div>
    <section className="home-section" aria-label="Discovery health"><div className="section-heading"><div><h2>Discovery & provider limits</h2><p>Your campaign goal never overrides a source cooldown or an AI provider quota.</p></div><button className="text-link" onClick={() => navigate("sources")}>Manage feeds & search websites<Icon name="arrow" size={14} /></button></div>
      <div className="discovery-health-grid">{state.sources.filter(source => source.discoveryAllowed).map(source => <div className="discovery-health" key={source.id}><strong>{source.name}</strong><Badge tone={source.lastError || source.mode === "blocked" ? "warning" : source.mode === "enabled" ? "positive" : "neutral"}>{source.mode === "enabled" ? "Discovery on" : source.mode}</Badge><span className="small muted">Last scan: {dateTime(source.lastScannedAt)}</span><span className="small muted">{source.nextScanAt && Date.parse(source.nextScanAt) > Date.now() ? `Cooldown until ${dateTime(source.nextScanAt)}` : "Next scan subject to provider limits"}</span>{source.lastError && <p className="field-error">{source.lastError}</p>}</div>)}</div>
      <p className="small muted"><strong>Configured AI: {state.runtime.ai.model || "Not selected"}.</strong> {state.runtime.ai.reason || (state.runtime.ai.available ? "Available under your saved processing choice." : "Not available; no silent model fallback.")} {state.runtime.ai.retryAt && `Retry after ${dateTime(state.runtime.ai.retryAt)}.`} Gemini free-tier quotas are set by Google and may prevent your daily goal; no automatic billing upgrade is performed.</p>
    </section>

    <section className="home-section source-funnel"><div className="section-heading"><div><h2>From source to conversation</h2><p>Confirmed campaign submissions and your recorded outcomes. No inferred interviews or offers.</p></div></div>
      {campaign.sources.length ? <div className="application-table-wrap"><table className="application-table"><caption className="sr-only">Campaign source funnel</caption><thead><tr><th scope="col">Source</th><th scope="col">Confirmed</th><th scope="col">Interviews</th><th scope="col">Offers</th></tr></thead><tbody>{campaign.sources.map((source) => <tr key={source.sourceId}><th scope="row">{state.sources.find((item) => item.id === source.sourceId)?.name || source.sourceId}</th><td>{number(source.submitted)}</td><td>{number(source.interviews)}</td><td>{number(source.offers)}</td></tr>)}</tbody></table></div> : <p className="small muted">Your first dated, confirmed campaign submission will start this funnel. A prepared packet is not a sent application.</p>}
    </section>
    {recentDays.length > 0 && <details className="daily-history"><summary>Recent daily confirmations <span>Last {recentDays.length} campaign days</span></summary><div className="application-table-wrap"><table className="application-table"><caption className="sr-only">Recent daily targets and actual confirmations, Asia/Kolkata</caption><thead><tr><th scope="col">Date · Asia/Kolkata</th><th scope="col">Confirmed</th><th scope="col">Target</th></tr></thead><tbody>{recentDays.map((day) => <tr key={day.date}><th scope="row">{dateLabel(day.date)}</th><td>{number(day.confirmed)}</td><td>{number(day.target)}</td></tr>)}</tbody></table></div></details>}
    <section className="home-install"><div><h2>Your workspace, on your computer</h2><p>For a Windows PC, download the Windows ZIP and follow its setup instructions. The local app also supports Mac; the Chrome extension is optional. Provider access and processing consent remain explicit setup steps.</p><button className="text-link" onClick={() => navigate("setup")}>Installation & account guidance<Icon name="arrow" size={14} /></button></div><PackageDownloads /></section>
  </div>;
}

function AutoApplyStart({ state, navigate }: { state: State; navigate: (page: Page) => void }) {
  const available = hasAutoApply(state);
  const approved = [1, 2, 3, 4, 5, 6, 7, 8].filter(slot => state.resumeVariants?.some(variant => variant.slot === slot && variant.approved && !variant.issues.length)).length;
  return <section className="home-auto-apply chairman-welcome" aria-labelledby="home-auto-title">
    <div><p className="eyebrow">CHAIRMAN · HOMEPAGE + CHROME</p><h2 id="home-auto-title">A considered application.<br />A clear next step.</h2>
      <p>Keep your baselines and application history here. Use the Chrome assistant on a supported employer page, or choose a job in this workspace. Review the exact resume and factual answers before filling; only a checked confirmation counts as applied.</p>
      <nav aria-label="Application workflow"><ol className="home-workflow">
        <li><button onClick={() => navigate("profile")}><span>1</span><strong>Confirm your profile</strong><small>Save your facts and preferences</small></button></li>
        <li><button onClick={() => navigate("resumes")}><span>2</span><strong>Upload baseline resumes</strong><small>Up to four originals, never overwritten by tailoring</small></button></li>
        <li><button onClick={() => navigate("opportunities")}><span>3</span><strong>Choose a job or paste a JD</strong><small>Public listings or an employer's original link</small></button></li>
        <li><button onClick={() => navigate("resumes")}><span>4</span><strong>Choose a template & tailor</strong><small>Review and edit the resulting packet</small></button></li>
        <li><button onClick={() => navigate("setup")}><span>5</span><strong>Fill with Chrome</strong><small>Pair the assistant; handle sign-in and checks yourself</small></button></li>
        <li><button onClick={() => navigate("applications")}><span>6</span><strong>Track the actual outcome</strong><small>Company, portal, stage, status and notes</small></button></li>
      </ol></nav>
      <div className="button-row"><button className="button primary" onClick={() => navigate("resumes")}>Open your resume library<Icon name="arrow" size={16} /></button><button className="button secondary" onClick={() => navigate("sources")}>Search job websites</button><button className="button text-button" onClick={() => navigate("applications")}>Application monitoring</button></div>
    </div>
    <div className="home-auto-state"><Badge tone={!available ? "warning" : state.autopilot?.enabled && !state.stats.stopped ? "positive" : "neutral"}>{!available ? "Service update required" : state.stats.stopped ? "Queue stopped" : state.autopilot?.enabled ? "Auto Apply active" : "Auto Apply not activated"}</Badge><p>{available ? `${approved} approved, valid resumes · Auto Apply minimum ${MIN_APPROVED_RESUMES}` : "Capability not reported"}</p><p className="small muted">Manual preparation needs one approved base. Auto Apply remains optional and requires a separate exact-scope authorization. Keep your computer and local service running.</p><button className="text-link" onClick={() => navigate("autopilot")}>{state.autopilot?.enabled ? "Open Auto Apply controls" : "Set up Auto Apply"}<Icon name="arrow" size={14} /></button><p className="small muted">Chrome assistant: {state.runtime.extension.paired ? "Local pairing configured" : "Not paired"}. Pairing is not a website login or permission to submit.</p><button className="text-link" onClick={() => navigate("setup")}>Extension setup & privacy<Icon name="arrow" size={14} /></button></div>
  </section>;
}

function CampaignSettings({ config, busy, run }: { config: CampaignConfig; busy: boolean; run: RunAction }) {
  const [draft, setDraft] = useState(config);
  const [dirty, setDirty] = useState(false);
  const [validation, setValidation] = useState("");
  useEffect(() => { if (!dirty) setDraft(config); }, [config, dirty]);
  async function save(event: FormEvent) {
    event.preventDefault();
    if (!Number.isSafeInteger(draft.days) || draft.days < 1 || !Number.isSafeInteger(draft.dailyTarget) || draft.dailyTarget < 1 || !Number.isSafeInteger(draft.days * draft.dailyTarget)) {
      setValidation("Days and daily target must be positive whole numbers within the supported number range."); return;
    }
    await run("Saving campaign target…", async () => {
      await post("/api/campaign", { ...draft, timezone: "Asia/Kolkata" });
      setDirty(false);
      setValidation("");
    }, "Campaign metadata saved. No profile facts, application statuses, limits, or approvals were changed.");
  }
  return <details className="campaign-settings"><summary>Edit campaign target{dirty && <span>Unsaved changes</span>}</summary><form onSubmit={(event) => void save(event)}>
    <p className="small muted">Default: 500 per day × 45 days = 22,500. Editing this plan changes target metadata only. It does not create, approve, or send applications.</p>
    <div className="form-grid three-columns"><Field label="Start date · Asia/Kolkata">{(id) => <input id={id} type="date" required value={draft.startDate} disabled={busy} onChange={(event) => { setDraft({ ...draft, startDate: event.target.value }); setDirty(true); }} />}</Field><Field label="Campaign days">{(id) => <input id={id} type="number" required min={1} step={1} value={draft.days} disabled={busy} onChange={(event) => { setDraft({ ...draft, days: Number(event.target.value) }); setDirty(true); }} />}</Field><Field label="Daily confirmed-application target">{(id) => <input id={id} type="number" required min={1} step={1} value={draft.dailyTarget} disabled={busy} onChange={(event) => { setDraft({ ...draft, dailyTarget: Number(event.target.value) }); setDirty(true); }} />}</Field></div>
    {validation && <p className="field-error" role="alert">{validation}</p>}
    <div className="button-row"><button className="button secondary" type="submit" disabled={busy || !dirty}>Save target metadata</button><button className="button text-button" type="button" disabled={busy} onClick={() => { setDraft({ ...draft, days: 45, dailyTarget: 500 }); setDirty(true); }}>Use 500 × 45</button>{dirty && <button className="button text-button" type="button" disabled={busy} onClick={() => { setDraft(config); setDirty(false); setValidation(""); }}>Discard target edits</button>}</div>
  </form></details>;
}
