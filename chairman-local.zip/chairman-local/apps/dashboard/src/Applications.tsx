import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { api, download, post } from "./api";
import { dateLabel, dateTime, errorMessage, historyJob, isFollowUpDue, MAX_APPROVAL_BATCH_SIZE, pipelineLabels, preparationLabel, type ApplicationStatus, type HistoryItem, type MatchedJob, type Packet, type Page, type PipelineStage, type ResultPage, type RunAction, type State } from "./model";
import { Badge, EmptyState, ExternalLink, Field, Icon, Notice, RecordEditor } from "./ui";
import { ApplicationHistory } from "./PagedBrowsers";
import { ExternalApplications } from "./ExternalApplications";
import { OriginalResume } from "./OriginalResume";
import { PacketProvenance } from "./PacketProvenance";
import { TrackingTable } from "./TrackingTable";

const statuses: Record<ApplicationStatus, { label: string; tone: "neutral" | "positive" | "warning" | "danger" }> = {
  prepared: { label: "Prepared · not approved", tone: "neutral" },
  approved: { label: "Approved", tone: "positive" },
  executing: { label: "In progress", tone: "warning" },
  awaiting_human: { label: "Awaiting human review", tone: "warning" },
  submitted_confirmed: { label: "Submission confirmed", tone: "positive" },
  submission_unknown: { label: "Outcome unknown · do not retry", tone: "danger" },
  failed: { label: "Failed", tone: "danger" },
  manual_only: { label: "Manual handoff", tone: "warning" },
  withdrawn_from_queue: { label: "Removed from queue", tone: "neutral" },
};

function fingerprint(packet: Packet, state: State): string {
  return JSON.stringify([packet, state.profile.version, state.profile.confirmed, state.jobs.find((job) => job.id === packet.jobId), state.sources]);
}

function canApprove(packet: Packet, state: State) {
  const job = state.jobs.find((item) => item.id === packet.jobId);
  return packet.status === "prepared" && packet.draft.mode !== "uploaded-variant" && state.profile.confirmed
    && (packet.draft.mode !== "jd-tailored" || (!!packet.resumeContent && !!packet.tailoring))
    && state.profile.facts.length > 0 && state.profile.facts.every((fact) => fact.confirmed)
    && packet.draft.factIds.every((id) => state.profile.facts.some((fact) => fact.id === id && fact.confirmed))
    && packet.profileVersion === state.profile.version && job?.status === "open"
    && job.match.eligible && job.aiPolicy !== "prohibited";
}

interface ApplicationProps { state: State; busy: boolean; run: RunAction; focusedPacket: string | null; setFocusedPacket: (id: string | null) => void; navigate: (page: Page) => void; profileDirty: boolean; visible?: boolean }

export function Applications({ state, ...props }: ApplicationProps) {
  const [history, setHistory] = useState<Record<string, { packet: Packet; job: MatchedJob }>>({});
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState("");
  const [revision, setRevision] = useState(0);
  const review = useRef<HTMLDivElement>(null);
  const lastFocusedId = useRef<string | null>(null);
  const focusOnLoad = useRef<string | null>(null);
  useEffect(() => {
    if (!props.focusedPacket) { setDetailLoading(false); setDetailError(""); return; }
    const id = props.focusedPacket;
    if (lastFocusedId.current !== id) { focusOnLoad.current = id; lastFocusedId.current = id; }
    const controller = new AbortController();
    setDetailLoading(true);
    setDetailError("");
    void (async () => {
      const item = await api<HistoryItem>(`/api/packets/${encodeURIComponent(id)}`, { signal: controller.signal });
      let job = state.jobs.find((candidate) => candidate.id === item.job.id);
      if (!job && item.packet.status === "prepared" && state.profile.confirmed && item.packet.profileVersion === state.profile.version) {
        let offset = 0;
        do {
          const query = new URLSearchParams({ offset: String(offset), limit: "50", q: item.job.company.slice(0, 100), role: item.job.title.slice(0, 100) });
          const result = await api<ResultPage<MatchedJob>>(`/api/jobs?${query}`, { signal: controller.signal });
          job = result.items.find((candidate) => candidate.id === item.job.id);
          if (job || !result.items.length || result.limit < 1 || result.offset + result.limit >= result.total) break;
          offset = result.offset + result.limit;
        } while (!controller.signal.aborted);
      }
      if (!controller.signal.aborted) {
        setHistory((current) => ({ ...current, [id]: { packet: item.packet, job: job || historyJob(item.job) } }));
        window.requestAnimationFrame(() => {
          if (focusOnLoad.current !== id) return;
          const element = document.getElementById(`packet-review-${id}`);
          if (element) { element.focus(); element.scrollIntoView({ block: "start" }); focusOnLoad.current = null; }
        });
      }
    })().catch((cause) => {
      if (!controller.signal.aborted) {
        setDetailError(errorMessage(cause));
        window.requestAnimationFrame(() => { review.current?.focus(); review.current?.scrollIntoView({ block: "start" }); });
      }
    }).finally(() => {
      if (!controller.signal.aborted) setDetailLoading(false);
    });
    return () => controller.abort();
  }, [props.focusedPacket, state, revision]);
  const supplemented = useMemo<State>(() => {
    const extra = Object.values(history);
    return { ...state, packets: [...state.packets, ...extra.filter((item) => !state.packets.some((packet) => packet.id === item.packet.id)).map((item) => item.packet)], jobs: [...state.jobs, ...Array.from(new Map(extra.filter((item) => !state.jobs.some((job) => job.id === item.job.id)).map((item) => [item.job.id, item.job])).values())] };
  }, [state, history]);
  function openHistory(id: string) {
    focusOnLoad.current = id;
    props.setFocusedPacket(id);
    setRevision((value) => value + 1);
  }
  return <><TrackingTable state={state} busy={props.busy} run={props.run} viewPacket={openHistory} visible={props.visible ?? true} /><div ref={review} tabIndex={-1} className="history-review-anchor">{detailLoading && <p className="small muted" role="status">Loading the exact saved packet and job…</p>}{detailError && <Notice tone="danger">Packet details could not be refreshed: {detailError}. <button className="text-link" onClick={() => setRevision((value) => value + 1)}>Retry packet details</button></Notice>}</div>
    <ApplicationLedger {...props} state={supplemented} busy={props.busy || detailLoading || !!detailError} />
    <ApplicationHistory state={state} busy={props.busy || detailLoading} statuses={statuses} onReview={openHistory} />
  </>;
}

function ApplicationLedger({ state, busy, run, focusedPacket, setFocusedPacket, navigate, profileDirty }: ApplicationProps) {
  const [selection, setSelection] = useState<Record<string, string>>({});
  const [acknowledgeWarnings, setAcknowledgeWarnings] = useState(false);
  const [status, setStatus] = useState("");
  const [stage, setStage] = useState("");
  const [dueOnly, setDueOnly] = useState(false);
  const [dirtyAnswers, setDirtyAnswers] = useState<Record<string, boolean>>({});
  const [dirtyProgress, setDirtyProgress] = useState<Record<string, boolean>>({});
  const selected = state.packets.filter((packet) => selection[packet.id] === fingerprint(packet, state) && canApprove(packet, state) && !dirtyAnswers[packet.id] && !profileDirty);
  const selectedSignature = selected.map((packet) => `${packet.id}:${selection[packet.id]}`).join("|");
  useEffect(() => { setAcknowledgeWarnings(false); }, [selectedSignature]);
  const packets = state.packets.filter((packet) => (!status || packet.status === status)
    && (!stage || (packet.status === "submitted_confirmed" && (packet.progress?.stage || "applied") === stage))
    && (!dueOnly || isFollowUpDue(packet))).toSorted((a, b) => b.createdAt.localeCompare(a.createdAt));
  useEffect(() => { if (focusedPacket) { setStatus(""); setStage(""); setDueOnly(false); } }, [focusedPacket]);
  const pending = state.packets.filter((packet) => packet.status === "prepared").length;
  const unknown = state.packets.filter((packet) => packet.status === "submission_unknown").length;
  const failed = state.packets.filter((packet) => packet.status === "failed").length;

  function choose(packet: Packet, checked: boolean) {
    if (checked && selected.length >= MAX_APPROVAL_BATCH_SIZE) return;
    setSelection((current) => {
      const next = { ...current };
      if (checked) next[packet.id] = fingerprint(packet, state);
      else delete next[packet.id];
      return next;
    });
  }

  async function approve() {
    if (!selected.length || selected.length > MAX_APPROVAL_BATCH_SIZE || !acknowledgeWarnings) return;
    const success = await run("Approving only your selected packets…", async () => {
      for (const packet of selected) {
        const latest = await api<HistoryItem>(`/api/packets/${encodeURIComponent(packet.id)}`);
        const original = state.jobs.find((job) => job.id === packet.jobId);
        const { match: _match, keywords: _keywords, ...reviewedJob } = original!;
        if (JSON.stringify(latest.packet) !== JSON.stringify(packet) || JSON.stringify(latest.job) !== JSON.stringify(reviewedJob)) {
          setSelection({});
          throw new Error("A selected packet or destination changed since review. Reopen the affected packet and review its current documents, answers, and warnings before selecting a new batch.");
        }
      }
      await post("/api/packets/approve", { ids: selected.map((packet) => packet.id), acknowledgeWarnings });
    }, "Your selected packets were approved. Approval is not submission confirmation.");
    if (success) { setSelection({}); setAcknowledgeWarnings(false); }
  }

  return <div className="applications-view">
    <ExternalApplications state={state} busy={busy} run={run} navigate={navigate} />
    <section className="tracker-summary" aria-label="Application outcomes"><div><strong>{pending}</strong><span>Loaded packets awaiting review</span></div><div><strong>{state.stats.submitted}</strong><span>All confirmed submissions</span></div><div><strong>{unknown}</strong><span>Unknown outcomes in loaded records</span></div><div><strong>{failed}</strong><span>Failures in loaded records</span></div></section>
    {unknown > 0 && <Notice tone="danger"><strong>{unknown} {unknown === 1 ? "outcome needs" : "outcomes need"} reconciliation.</strong> Never automatically retry an unknown outcome. A timeout or button click does not prove submission. Check the employer destination and evidence yourself before reporting confirmation.</Notice>}
    {profileDirty && <Notice tone="warning">Your profile has unsaved edits. Save and confirm it before approving packets; changed facts require a fresh packet.</Notice>}
    <div className="section-heading"><div><h2>Your application ledger</h2><p>Submission evidence and hiring progress are separate. Interviews and offers are recorded only by you.</p></div></div>
    <Notice>{state.packets.length.toLocaleString()} active or explicitly opened packets loaded of {(state.pagination?.packetTotal ?? state.packets.length).toLocaleString()} stored. The filters below cover loaded records only; campaign totals cover the entire database. <a className="text-link" href="#all-application-history">Search complete application history<Icon name="arrow" size={14} /></a></Notice>
    <div className="filter-bar application-filters"><Field label="Submission outcome">{(id) => <select id={id} value={status} onChange={(event) => setStatus(event.target.value)}><option value="">All outcomes</option>{Object.entries(statuses).map(([value, item]) => <option key={value} value={value}>{item.label}</option>)}</select>}</Field><Field label="Hiring progress">{(id) => <select id={id} value={stage} onChange={(event) => setStage(event.target.value)}><option value="">All stages</option>{Object.entries(pipelineLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>}</Field><label className="checkbox-label filter-checkbox"><input type="checkbox" checked={dueOnly} onChange={(event) => setDueOnly(event.target.checked)} />Due follow-ups</label></div>
    {!packets.length ? <EmptyState icon="applications" title={state.packets.length ? "No applications match these filters" : "No application packets yet"} action={<button className="button primary" onClick={() => state.packets.length ? (setStatus(""), setStage(""), setDueOnly(false)) : navigate("autopilot")}>{state.packets.length ? "Show all outcomes" : "Open Auto Apply"}<Icon name="arrow" size={16} /></button>}>{state.packets.length ? "Choose a different outcome, stage, or next-action filter to see your application packets." : "Auto Apply prepares matching applications after explicit setup and authorization. Manual preparation remains available under Opportunities. Only recorded receipts count as submitted."}</EmptyState> : <>
      <div className="application-table-wrap"><table className="application-table"><caption className="sr-only">Application packets, submission evidence, and separately recorded hiring progress</caption><thead><tr><th scope="col">Opportunity</th><th scope="col">Preparation</th><th scope="col">Submission outcome</th><th scope="col">Hiring progress</th><th scope="col">Next action</th><th scope="col"><span className="sr-only">Review packet</span></th></tr></thead><tbody>{packets.map((packet) => {
        const job = state.jobs.find((item) => item.id === packet.jobId);
        const statusInfo = statuses[packet.status] || statuses.prepared;
        return <tr key={packet.id} className={focusedPacket === packet.id ? "active-row" : ""}><td><strong>{job?.title || "Listing unavailable"}</strong><span>{job?.company || packet.jobId}</span>{selected.some((item) => item.id === packet.id) && <small className="selected-caption"><Icon name="check" size={12} />Selected for approval</small>}{(dirtyAnswers[packet.id] || dirtyProgress[packet.id]) && <small className="field-error">Unsaved edits</small>}</td><td>{preparationLabel(packet.draft.mode, packet.tailoring?.engine)}<span>Profile v{packet.profileVersion}</span>{packet.tailoring && <span>Base: {packet.tailoring.baseVariantLabel}</span>}<span>{packet.approvedBy === "autopilot" ? "Auto Apply authorization" : packet.approvedBy === "user" ? "Per-packet approval" : ""}</span><span>Created {dateTime(packet.createdAt)}</span></td><td><Badge tone={statusInfo.tone}>{statusInfo.label}</Badge>{packet.submissionArtifactSha256 && <span>Exact submission file fingerprint recorded</span>}{packet.submittedAt && <span>Confirmed {dateTime(packet.submittedAt)}</span>}</td><td>{packet.status === "submitted_confirmed" ? <Badge tone={packet.progress?.stage === "offer" ? "positive" : "neutral"}>{pipelineLabels[packet.progress?.stage || "applied"]}</Badge> : <span>Awaiting confirmation</span>}</td><td className="date-cell">{packet.status === "submitted_confirmed" ? dateLabel(packet.progress?.nextActionDate) : "—"}{isFollowUpDue(packet) && <span className="due-label">Due / overdue</span>}</td><td><button className="button secondary compact" aria-expanded={focusedPacket === packet.id} onClick={() => setFocusedPacket(focusedPacket === packet.id ? null : packet.id)}>Review<Icon name="arrow" size={14} /></button></td></tr>;
      })}</tbody></table></div>
    </>}
    {state.packets.filter((packet) => packet.id === focusedPacket || dirtyAnswers[packet.id] || dirtyProgress[packet.id]).map((packet) => <div key={packet.id} id={`packet-review-${packet.id}`} tabIndex={-1} hidden={packet.id !== focusedPacket}><PacketReview packet={packet} state={state} busy={busy} run={run} canSelect={canApprove(packet, state) && !profileDirty && (selected.length < MAX_APPROVAL_BATCH_SIZE || selected.some((item) => item.id === packet.id))} selected={selected.some((item) => item.id === packet.id)} onSelect={(checked) => choose(packet, checked)} onDirty={(dirty) => { setDirtyAnswers((current) => current[packet.id] === dirty ? current : { ...current, [packet.id]: dirty }); if (dirty) choose(packet, false); }} onProgressDirty={(dirty) => setDirtyProgress((current) => current[packet.id] === dirty ? current : { ...current, [packet.id]: dirty })} /></div>)}
    <section className="approval-panel" aria-labelledby="batch-title"><div><h2 id="batch-title">Approve an exact batch</h2><p>This is the separate per-packet workflow, not Auto Apply activation. No batch selection is automatic. Review each packet’s documents, answers, and warnings, then explicitly select it. Up to {MAX_APPROVAL_BATCH_SIZE.toLocaleString()} exact packets per request—not a daily or session cap. Manual packets are approved only for handoff. Chrome page assistance and the local Auto Apply runner require their own explicit actions; this approval never broadens site permissions.</p></div>
      {selected.length > 0 ? <ul className="batch-list">{selected.map((packet) => { const job = state.jobs.find((item) => item.id === packet.jobId); return <li key={packet.id}><Icon name="check" size={16} /><div><strong>{job?.company} · {job?.title}</strong><span>Packet {packet.id} · Profile v{packet.profileVersion}</span>{job && <ExternalLink href={job.applyUrl}>Named destination</ExternalLink>}</div><button className="button-icon" aria-label={`Remove ${job?.title || packet.id} from batch`} onClick={() => choose(packet, false)}><Icon name="close" /></button></li>; })}</ul> : <p className="batch-empty">No packets selected for approval.</p>}
      <label className="checkbox-label"><input type="checkbox" disabled={!selected.length || busy} checked={acknowledgeWarnings} onChange={(event) => setAcknowledgeWarnings(event.target.checked)} /><span>I reviewed all warnings and authorize sharing only these exact documents and answers with the named employers. This does not accept legal terms, answer assessments, or authorize other applications.</span></label>
      <div className="approval-footer"><span>{selected.length} / {MAX_APPROVAL_BATCH_SIZE.toLocaleString()} selected per request · No automatic retries for unknown outcomes</span><button className="button primary" disabled={busy || !selected.length || selected.length > MAX_APPROVAL_BATCH_SIZE || !acknowledgeWarnings || profileDirty} onClick={() => void approve()}><Icon name="check" />Approve {selected.length || ""} selected {selected.length === 1 ? "packet" : "packets"}</button></div>
    </section>
  </div>;
}

function PacketReview({ packet, state, busy, run, canSelect, selected, onSelect, onDirty, onProgressDirty }: { packet: Packet; state: State; busy: boolean; run: RunAction; canSelect: boolean; selected: boolean; onSelect: (selected: boolean) => void; onDirty: (dirty: boolean) => void; onProgressDirty: (dirty: boolean) => void }) {
  const job = state.jobs.find((item) => item.id === packet.jobId);
  const [answers, setAnswers] = useState<Record<string, string>>({ ...packet.answers });
  const [dirty, setDirty] = useState(false);
  const [confirmation, setConfirmation] = useState("");
  const [confirmedByUser, setConfirmedByUser] = useState(false);
  const [reviewedDocuments, setReviewedDocuments] = useState("");
  const [reviewedAnswers, setReviewedAnswers] = useState("");
  const reviewFingerprint = fingerprint(packet, state);
  const documentsReviewed = reviewedDocuments === reviewFingerprint;
  const answersReviewed = reviewedAnswers === reviewFingerprint;
  const stale = packet.profileVersion !== state.profile.version;
  const uploaded = packet.draft.mode === "uploaded-variant";
  const answersReadOnly = uploaded || ["executing", "awaiting_human", "submitted_confirmed", "submission_unknown"].includes(packet.status) || job?.aiPolicy === "prohibited"
    || !!state.autopilot?.humanTasks?.some(task => task.packetId === packet.id && ["waiting", "resuming", "session_lost"].includes(task.status));
  const tailored = packet.draft.mode === "jd-tailored";
  const variant = state.resumeVariants?.find(item => item.id === packet.variantId);
  const resumeProfile = packet.resumeContent ?? state.profile;
  const skills = packet.resumeContent?.skills ?? packet.draft.skills;
  const keywordTerms = packet.resumeContent?.keywordTerms ?? packet.draft.keywordTerms ?? [];
  const facts = packet.resumeContent ? packet.resumeContent.facts.map(fact => ({ id: fact.id, fact }))
    : tailored ? [] : packet.draft.factIds.map((id) => ({ id, fact: state.profile.facts.find((item) => item.id === id) }));
  const source = state.sources.find((item) => item.id === job?.sourceId);
  const manual = packet.status === "manual_only" || job?.aiPolicy === "prohibited" || !source?.submissionAllowed;
  useEffect(() => { if (!dirty) setAnswers({ ...packet.answers }); }, [packet.answers]);

  async function saveAnswers() {
    if (answersReadOnly) return;
    await run("Saving packet answers…", async () => {
      const result = await post<{ packet: Packet }>(`/api/packets/${encodeURIComponent(packet.id)}/answers`, { answers });
      setAnswers({ ...result.packet.answers });
      setDirty(false);
      onDirty(false);
      onSelect(false);
    }, "Answers saved. Review the changed packet; any previous approval is no longer valid.");
  }

  async function reportConfirmation(event: FormEvent) {
    event.preventDefault();
    if (!["manual_only", "awaiting_human", "submission_unknown"].includes(packet.status) || confirmation.trim().length < 10 || !confirmedByUser) return;
    const success = await run("Recording your reported confirmation…", async () => {
      await post(`/api/packets/${encodeURIComponent(packet.id)}/confirm`, { confirmation: confirmation.trim() });
    }, "Your explicitly reported submission confirmation was recorded.");
    if (success) { setConfirmation(""); setConfirmedByUser(false); }
  }

  return <section className="packet-review" aria-label="Exact application packet review"><div className="section-heading"><div><h2>{job?.title || "Application packet"}</h2><p>{job?.company || "Employer unavailable"} · <span className="small">Packet {packet.id}</span></p></div><Badge tone={statuses[packet.status]?.tone}>{statuses[packet.status]?.label || packet.status}</Badge></div>
    {job && <div className="packet-destination"><span>Review the named destination</span><ExternalLink href={job.applyUrl}>Open application manually</ExternalLink><span className="destination-url">{job.applyUrl}</span></div>}
    {stale && <Notice tone="danger"><strong>This packet uses an older profile.</strong> {uploaded ? "The saved original file and answers remain historical evidence; they are not reconstructed from your current profile. Changed profile details require a new Auto Apply authorization." : packet.resumeContent ? "The frozen content below and saved documents are unchanged by your profile edits. Prepare a new packet for new applications; this older packet cannot be approved." : "Download the immutable artifacts to inspect their actual contents, then prepare a new packet. A current-profile reconstruction is not the saved document. This packet cannot be approved."}</Notice>}
    {uploaded && <Notice><strong>Original uploaded resume · not AI-generated.</strong> This packet preserves the exact uploaded file, not selected profile facts. {packet.approvedBy === "autopilot" ? "It was authorized under your explicit Auto Apply consent, not a separate per-packet approval." : "No submission is implied by this saved packet."} <p>Variant: {variant?.label || packet.variantId || "Not recorded"} · Authorization: {packet.authorizationId || "Not recorded"}</p></Notice>}
    <PacketProvenance packet={packet} />
    {packet.status === "submission_unknown" && <Notice tone="danger"><strong>Do not retry this application automatically.</strong> Check the actual employer destination and confirmation evidence. An in-flight or timed-out attempt may already have submitted.</Notice>}
    {packet.status === "prepared" && job && !job.match.eligible && !!job.match.blockers.length && <Notice tone="warning"><strong>Current eligibility must be resolved before approval.</strong><ul>{job.match.blockers.map((blocker) => <li key={blocker}>{blocker}</li>)}</ul></Notice>}
    {manual && <Notice tone="warning"><strong>{job?.aiPolicy === "prohibited" ? "No-AI application · human-authored material only." : "Manual-only application."}</strong> {job?.aiPolicy === "prohibited" ? "Do not use generated documents or answers where the employer prohibits them." : "Approval is for manual handoff only, never automatic submission. Review and approve the exact packet, then download appropriate documents and complete the destination yourself."} Never automatically accept terms, declarations, or assessments.</Notice>}
    {!!packet.warnings.length && <Notice tone="warning"><strong>Packet warnings</strong><ul>{packet.warnings.map((warning, index) => <li key={index}>{warning}</li>)}</ul></Notice>}
    {packet.error && <Notice tone="danger"><strong>Recorded failure</strong><p>{packet.error}</p></Notice>}
    {packet.confirmation && <Notice><strong>Recorded confirmation</strong><p>{packet.confirmation}</p></Notice>}
    <div className="packet-columns">
      <div className="resume-preview"><div className="preview-heading"><h3>{uploaded ? "Original, unchanged resume" : packet.resumeContent ? "Frozen resume content" : "Factual resume content"}</h3><span>{preparationLabel(packet.draft.mode, packet.tailoring?.engine)}</span></div>
        {uploaded ? <div className="uploaded-packet-original"><p className="small muted">Read the immutable file saved with this packet. Its content is not regenerated from profile facts, and only its original format is required.</p>{packet.artifacts.map(artifact => <div key={artifact.format}><p className="variant-filename">{artifact.filename}</p><OriginalResume path={`/api/packets/${encodeURIComponent(packet.id)}/documents/${artifact.format}`} filename={artifact.filename} format={artifact.format} busy={busy || job?.aiPolicy === "prohibited"} run={run} /></div>)}{!packet.artifacts.length && <Notice tone="danger">The saved original document is unavailable. Do not treat this packet as ready to send.</Notice>}</div> : <>
          {tailored && !packet.resumeContent ? <Notice tone="warning">The frozen resume content was not returned. Current profile facts are not shown as this packet’s content. Download the exact saved documents to review them.</Notice> : <><p className="small muted">{packet.resumeContent ? "Immutable content saved when this packet was prepared—not your current, editable profile." : "Legacy content view using current profile facts. Only the downloaded artifacts show the exact saved document."}</p><div className="resume-paper"><h3>{resumeProfile.name || "Name not provided"}</h3><p className="resume-contact">{[resumeProfile.email, resumeProfile.phone, resumeProfile.location].filter(Boolean).join(" · ")}</p>{Object.entries(resumeProfile.links).map(([label, url]) => <p className="resume-link" key={label}>{label}: {url}</p>)}
          <h4>Selected skills</h4><p>{skills.join(" · ") || "No skills selected."}</p>
          {!!keywordTerms.length && <><h4>Supported / equivalent keyword terms</h4><p>{keywordTerms.join(" · ")}</p><p className="small muted">Supported evidence only. Transferable foundations and gaps are not claimed as hands-on skills.</p></>}
          <h4>Selected profile facts</h4>{facts.length ? facts.map(({ id, fact }) => <div className="preview-fact" key={id}>{fact ? <><div><strong>{[fact.role, fact.employer].filter(Boolean).join(" · ") || fact.category}</strong>{fact.dates && <span>{fact.dates}</span>}</div><p>{fact.text}</p><small>Fact ID: {id}{!fact.confirmed && " · Unconfirmed"}</small></> : <Notice tone="danger">Fact {id} no longer exists in the current profile. Prepare a new packet.</Notice>}</div>) : <p>No profile facts were selected.</p>}
        </div></>}<p className="small muted">Content review, not a page-layout preview. Download the format you intend to share to check the exact {tailored ? "derived" : "saved"} document.</p>
        <div className="button-row">{(["pdf", "docx"] as const).map((format) => {
          const artifact = packet.artifacts.find(artifact => artifact.format === format);
          return <div key={format} className="packet-download"><button className="button secondary" disabled={busy || !artifact || job?.aiPolicy === "prohibited"} onClick={() => void run(`Downloading ${format.toUpperCase()}…`, async () => { await download(`/api/packets/${encodeURIComponent(packet.id)}/documents/${format}`, artifact!.filename); }, `${format.toUpperCase()} downloaded locally. Nothing was sent to an employer.`)}><Icon name="download" />Download {format.toUpperCase()}</button>{artifact && <p className="small variant-filename">{artifact.filename}</p>}</div>;
        })}</div>
        {packet.status === "prepared" && <label className="checkbox-label document-review-check"><input type="checkbox" checked={documentsReviewed} disabled={busy || !canSelect || !packet.artifacts.length} onChange={(event) => { setReviewedDocuments(event.target.checked ? reviewFingerprint : ""); if (!event.target.checked) onSelect(false); }} />I opened and reviewed the exact PDF or DOCX I intend to share, including all facts and keyword claims.</label>}</>}
        <details className="artifact-details"><summary>Document fingerprints & preparation notes</summary><dl className="detail-grid"><dt>Profile version</dt><dd>{packet.profileVersion}</dd><dt>Profile hash</dt><dd className="hash-value">{packet.profileHash}</dd><dt>Job hash</dt><dd className="hash-value">{packet.jobHash}</dd>{packet.artifacts.map((artifact) => <div className="artifact-row" key={artifact.format}><dt>{artifact.format.toUpperCase()} · {artifact.bytes.toLocaleString()} bytes</dt><dd>{artifact.filename}<span className="hash-value">{artifact.sha256}</span></dd></div>)}</dl>{packet.draft.notes.map((note, index) => <p key={index} className="small muted">{note}</p>)}</details>
      </div>
      <div className="packet-answers"><h3>Review application answers</h3>{packet.status === "awaiting_human" && <Notice tone="warning">This packet is read-only while its prefilled session awaits review. Continue the exact session from Needs your attention in Auto Apply, not by editing packet answers or creating a new attempt.</Notice>}<p className="small muted">{uploaded ? "Saved factual answers for this exact Auto Apply packet. Edit your Profile answer bank and reactivate for future applications; these historical answers stay read-only." : "Only user-provided answers. Saving changes invalidates approval. Do not add legal declarations or assessment responses here."}</p><RecordEditor title="answer" value={answersReadOnly ? packet.answers : answers} disabled={busy || answersReadOnly} onChange={(next) => { setAnswers(next); setDirty(true); onDirty(true); }} />{!uploaded && <button className="button secondary" disabled={busy || !dirty || answersReadOnly} onClick={() => void saveAnswers()}>Save edited answers</button>}
        {dirty && <p className="field-error" role="status">Unsaved answers. Save before selecting this packet.</p>}
        {packet.status === "prepared" && !uploaded && <label className="checkbox-label document-review-check"><input type="checkbox" checked={answersReviewed} disabled={busy || dirty || !canSelect} onChange={(event) => { setReviewedAnswers(event.target.checked ? reviewFingerprint : ""); if (!event.target.checked) onSelect(false); }} />I reviewed the saved answers, named destination, and packet warnings.</label>}
        {packet.formSnapshot && <section className="form-preflight"><h4>Recorded form review</h4><p className="small">{packet.formSnapshot.fields.length} fields · {packet.formSnapshot.hasCaptcha ? "CAPTCHA requires you" : "No CAPTCHA reported"} · {packet.formSnapshot.hasLegal ? "Legal declarations require you" : "No legal declarations reported"}</p>{packet.formSnapshot.unsupported.length > 0 && <Notice tone="warning"><ul>{packet.formSnapshot.unsupported.map((field, index) => <li key={index}>{field}</li>)}</ul></Notice>}</section>}
        {!uploaded && <div className="packet-selection"><label className="checkbox-label"><input type="checkbox" checked={selected} disabled={busy || !canSelect || dirty || (!selected && (!documentsReviewed || !answersReviewed)) || facts.some(({ fact }) => !fact?.confirmed)} onChange={(event) => onSelect(event.target.checked)} /><span>I reviewed this exact packet for <strong>{job?.company || "this employer"} · {job?.title || "this role"}</strong> and select it for batch approval.{manual && " Approval permits manual handoff only, not automatic submission."}</span></label>{!canSelect && <p className="small muted">{stale ? "Prepare a new packet from your current profile." : packet.status === "manual_only" ? "This packet is ready for manual handoff. Complete the destination yourself, then record only a confirmation you personally verified." : packet.status !== "prepared" ? "Only prepared, unapproved packets can be selected." : `Confirm your saved profile, resolve eligibility and evidence restrictions, and keep each batch within ${MAX_APPROVAL_BATCH_SIZE.toLocaleString()} packets.`}</p>}{canSelect && !selected && (!documentsReviewed || !answersReviewed) && <p className="small muted">Complete the document and answer review checks above before selecting this packet.</p>}</div>}
        <ManualConfirmation job={job} packet={packet} busy={busy} confirmation={confirmation} setConfirmation={setConfirmation} confirmedByUser={confirmedByUser} setConfirmedByUser={setConfirmedByUser} submit={reportConfirmation} />
      </div>
    </div>
    {packet.status === "submitted_confirmed" && <ProgressEditor packet={packet} busy={busy} run={run} onDirty={onProgressDirty} />}
  </section>;
}

function ProgressEditor({ packet, busy, run, onDirty }: { packet: Packet; busy: boolean; run: RunAction; onDirty: (dirty: boolean) => void }) {
  const [stage, setStage] = useState<PipelineStage>(packet.progress?.stage || "applied");
  const [note, setNote] = useState(packet.progress?.note || "");
  const [nextActionDate, setNextActionDate] = useState(packet.progress?.nextActionDate || "");
  const [dirty, setDirty] = useState(false);
  const [verified, setVerified] = useState(false);
  useEffect(() => {
    if (!dirty) { setStage(packet.progress?.stage || "applied"); setNote(packet.progress?.note || ""); setNextActionDate(packet.progress?.nextActionDate || ""); }
  }, [packet.progress, dirty]);
  function changed() { setDirty(true); setVerified(false); onDirty(true); }
  async function save(event: FormEvent) {
    event.preventDefault();
    if (!dirty || !verified || packet.status !== "submitted_confirmed") return;
    await run("Saving your recorded application progress…", async () => {
      await post(`/api/packets/${encodeURIComponent(packet.id)}/progress`, { stage, note: note.trim(), ...(nextActionDate ? { nextActionDate } : {}) });
      setDirty(false); setVerified(false); onDirty(false);
    }, "Your progress and next action were saved. Submission evidence and application approval were not changed.");
  }
  return <section className="progress-editor"><div className="section-heading"><div><h3>Hiring progress & next action</h3><p>For this confirmed application only. Nothing here contacts the employer or schedules an outgoing message.</p></div><Badge tone={dirty ? "warning" : "neutral"}>{dirty ? "Unsaved progress" : packet.progress ? `Updated ${dateTime(packet.progress.updatedAt)}` : "No progress update recorded"}</Badge></div>
    <form onSubmit={(event) => void save(event)}><div className="form-grid"><Field label="Recorded hiring stage">{(id) => <select id={id} value={stage} disabled={busy} onChange={(event) => { setStage(event.target.value as PipelineStage); changed(); }}>{Object.entries(pipelineLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>}</Field><Field label="Next-action date (optional)" hint="Asia/Kolkata calendar date. Clear to remove the reminder.">{(id) => <input id={id} type="date" value={nextActionDate} disabled={busy} onChange={(event) => { setNextActionDate(event.target.value); changed(); }} />}</Field></div>
      <Field label="Progress note" hint="Record only what happened: recruiter contact, interview details, or an offer you actually received.">{(id) => <textarea id={id} rows={3} value={note} disabled={busy} onChange={(event) => { setNote(event.target.value); changed(); }} />}</Field>
      <label className="checkbox-label"><input type="checkbox" checked={verified} required disabled={busy || !dirty} onChange={(event) => setVerified(event.target.checked)} />I verified this update. Interviews and offers must not be inferred from a submission.</label>
      <div className="button-row"><button className="button primary" type="submit" disabled={busy || !dirty || !verified}>Save my progress update</button>{dirty && <button className="button text-button" type="button" disabled={busy} onClick={() => { setDirty(false); setVerified(false); onDirty(false); }}>Discard progress edits</button>}</div>
    </form>
  </section>;
}

function ManualConfirmation({ job, packet, busy, confirmation, setConfirmation, confirmedByUser, setConfirmedByUser, submit }: { job?: MatchedJob; packet: Packet; busy: boolean; confirmation: string; setConfirmation: (value: string) => void; confirmedByUser: boolean; setConfirmedByUser: (value: boolean) => void; submit: (event: FormEvent) => Promise<void> }) {
  if (!["manual_only", "awaiting_human", "submission_unknown"].includes(packet.status)) return null;
  return <details className="manual-confirmation"><summary>Report a submission you verified</summary><p className="small muted">Use this only after you personally verified the employer’s confirmation. An open page, click, or uploaded resume is not enough.</p><form onSubmit={(event) => void submit(event)}><Field label="Confirmation evidence" hint="At least 10 characters. Describe the confirmation message or reference number you actually received.">{(id) => <textarea id={id} rows={3} required minLength={10} disabled={busy} value={confirmation} onChange={(event) => setConfirmation(event.target.value)} />}</Field><label className="checkbox-label"><input type="checkbox" checked={confirmedByUser} required disabled={busy} onChange={(event) => setConfirmedByUser(event.target.checked)} />I personally verified that {job?.company || "this employer"} received this application.</label><button className="button secondary" type="submit" disabled={busy || confirmation.trim().length < 10 || !confirmedByUser}>Record my confirmation</button></form></details>;
}
