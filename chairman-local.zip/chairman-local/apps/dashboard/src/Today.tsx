import { useCallback, useEffect, useState, type FormEvent } from "react";
import { api, post } from "./api";
import { errorMessage, type RunAction, type State } from "./model";
import type { ShortlistEntry, ShortlistSettings, ShortlistStatus, ShortlistView } from "../../local/shortlist";
import type { ApplySessionView, SessionItemState } from "../../local/apply-sessions";
import type { LocationTier } from "../../../packages/domain/job-fit";
import { SENIORITIES, type Seniority } from "../../../packages/domain/seniority";
import { Badge, EmptyState, Field, Icon, Notice } from "./ui";
import "./today-session.css";

const STATUS: Record<ShortlistStatus, { label: string; tone: "neutral" | "positive" | "warning" | "danger" }> = {
  new: { label: "To do", tone: "neutral" }, opened: { label: "Opened · not submitted", tone: "neutral" }, filled: { label: "Filled · not submitted", tone: "warning" },
  review: { label: "Ready for your review", tone: "warning" }, auto_queued: { label: "Auto-applying", tone: "neutral" }, needs_you: { label: "Needs you", tone: "warning" },
  applied: { label: "Applied ✓", tone: "positive" }, marked: { label: "Marked by you · not verified", tone: "warning" },
  skipped: { label: "Skipped", tone: "neutral" }, failed: { label: "Failed", tone: "danger" },
};
const TIER: Record<LocationTier, "positive" | "neutral" | "warning"> = {
  india: "positive", remote_india: "positive", remote_global: "positive", remote_apac: "positive", abroad: "neutral", unknown: "warning", remote_restricted: "warning",
};
const EXCLUDED: Record<string, string> = {
  role: "other role families", blocked: "blocked by your preferences", experience: "outside your experience level", remote_restricted: "remote only in another region",
  no_sponsorship: "abroad without sponsorship", settings: "turned off in settings", stale: "older than your age limit", score: "below your minimum score", cap: "over the per-company cap",
};
type Filter = "todo" | "all" | ShortlistStatus;
type SessionSummary = { session?: ApplySessionView; available: number };
const ITEM: Record<SessionItemState, { label: string; tone: "neutral" | "positive" | "warning" | "danger" }> = {
  queued: { label: "Waiting to open", tone: "neutral" }, opened: { label: "Opened", tone: "neutral" }, working: { label: "Filling", tone: "neutral" },
  needs_you: { label: "Needs you", tone: "warning" }, review: { label: "Ready for your review", tone: "warning" }, submitted: { label: "Applied ✓", tone: "positive" },
  closed: { label: "Closed, not submitted", tone: "neutral" }, skipped: { label: "Skipped", tone: "neutral" }, failed: { label: "Failed", tone: "danger" },
};
type ExternalRuntime = { sendMessage: (id: string, message: unknown, callback: (response: unknown) => void) => void; lastError?: { message?: string } };
/** Asks the paired Chairman extension (by its ID) to open the session's tabs in this window. */
function askExtension(id: string, message: unknown): Promise<{ ok?: boolean; opened?: number; missingSites?: number; error?: string }> {
  return new Promise((resolve, reject) => {
    const runtime = (window as unknown as { chrome?: { runtime?: ExternalRuntime } }).chrome?.runtime;
    if (!runtime?.sendMessage) { reject(new Error("This browser cannot reach the Chairman extension from the dashboard.")); return; }
    const timer = window.setTimeout(() => reject(new Error("The extension did not answer.")), 20_000);
    try {
      runtime.sendMessage(id, message, response => {
        window.clearTimeout(timer);
        if (runtime.lastError) reject(new Error(runtime.lastError.message ?? "The extension did not answer."));
        else resolve((response ?? {}) as { ok?: boolean; opened?: number; missingSites?: number; error?: string });
      });
    } catch (cause) { window.clearTimeout(timer); reject(cause); }
  });
}
const TODO: ShortlistStatus[] = ["new", "opened", "filled", "review", "needs_you"];

function SessionCard({ summary, extensionId, busy, act }: { summary: SessionSummary | null; extensionId?: string; busy: boolean; act: RunAction }) {
  const [note, setNote] = useState("");
  if (!summary) return null;
  const session = summary.session, active = session?.status === "active";
  const next = Math.min(50, summary.available);
  async function openTabs(): Promise<string> {
    if (!extensionId) return "Session ready. Pair the Chairman extension (Setup → Browser extension), then press Start a session in its side panel.";
    try {
      const result = await askExtension(extensionId, { channel: "chairman:session", action: "open" });
      if (!result.ok) throw new Error(result.error ?? "The extension did not open the tabs.");
      return `${result.opened ? `Opened ${result.opened} tab${result.opened === 1 ? "" : "s"} in this window.` : "The session's tabs are already open."}`
        + (result.missingSites ? ` Chrome has not allowed Chairman on ${result.missingSites} company site${result.missingSites === 1 ? "" : "s"} yet: in the Chairman side panel, press Allow on all company sites.` : "")
        + " Sign in or complete verification where a site asks; Chairman fills each step and stops before Submit for your review.";
    } catch (cause) {
      return `Session ready, but the extension could not be reached from here (${errorMessage(cause)}). Click the Chairman icon, then Start a session in its side panel.`;
    }
  }
  const start = (label: string) => void act(label, async () => { await post("/api/apply-sessions", {}); setNote(await openTabs()); }, undefined);
  if (!session || !active) return <section className="form-section session-card" aria-labelledby="session-title">
    <div className="section-heading"><div><h2 id="session-title">{session ? `Session ${session.number} ${session.status === "complete" ? "finished" : "stopped"}` : "Auto-apply in your Chrome"}</h2>
      <p>{session?.status === "complete" ? `${session.counts.submitted} of ${session.size} roles applied (confirmed by their employers' pages). ` : ""}Chairman opens your top to-do roles 10 tabs at a time (50 per session) in this Chrome window. In each tab it fills every step it can and presses Next, then stops before Submit so you review and submit. You sign in and complete verification checks yourself.</p></div></div>
    <div className="button-row"><button className="button primary" disabled={busy || !next} onClick={() => start(`Starting a session of ${next} roles…`)}>{session ? `Apply to the next ${next}` : `Auto-apply top ${next} in Chrome`}</button>
      {!next && <span className="small muted">No to-do roles are left on today's list.</span>}</div>
    {note && <Notice>{note}</Notice>}
  </section>;
  const counts = session.counts;
  return <section className="form-section session-card" aria-labelledby="session-title">
    <div className="section-heading"><div><h2 id="session-title">Session {session.number}: {session.finished} of {session.size} finished</h2>
      <p>{session.open} open in Chrome · {counts.queued} waiting to open · {counts.needs_you} need you · {counts.review} ready for your review · {counts.submitted} applied ✓</p></div>
      <div className="button-row">
        <button className="button secondary" disabled={busy} onClick={() => void act("Asking the extension to open the next tabs…", async () => { setNote(await openTabs()); }, undefined)}>Open tabs in Chrome</button>
        <button className="button text-button" disabled={busy} onClick={() => { if (window.confirm("Stop this session? Open tabs stay open; nothing more is filled automatically.")) void act("Stopping the session…", async () => { await post("/api/apply-sessions/current/stop", {}); }, "Session stopped. Roles not opened yet stay on today's list."); }}>Stop session</button>
      </div></div>
    {note && <Notice>{note}</Notice>}
    <details className="form-disclosure"><summary>Roles in this session <span>{session.items.length}</span></summary>
      <ol className="session-items">{session.items.map(item => <li key={item.jobId}><Badge tone={ITEM[item.state].tone}>{ITEM[item.state].label}</Badge> <strong>{item.company}</strong> · {item.title}{item.detail && <div className="small muted">{item.detail}</div>}</li>)}</ol>
    </details>
  </section>;
}
const ago = (value?: string) => {
  if (!value) return "—";
  const days = Math.floor((Date.now() - Date.parse(value)) / 86400_000);
  return days <= 0 ? "Today" : days === 1 ? "1 day ago" : `${days} days ago`;
};

export function Today({ state, visible, busy, run }: { state: State; visible: boolean; busy: boolean; run: RunAction }) {
  const [view, setView] = useState<ShortlistView | null>(null);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState<Filter>("todo");
  const [session, setSession] = useState<SessionSummary | null>(null);
  const load = useCallback(async () => {
    try {
      const next = await api<ShortlistView>("/api/shortlist");
      if (!next || !Array.isArray(next.entries) || !next.settings) throw new Error("The local service did not return today's list.");
      setView(next); setError("");
    } catch (cause) { setError(errorMessage(cause)); }
    try { setSession(await api<SessionSummary>("/api/apply-sessions/current")); } catch { setSession(null); }
  }, []);
  useEffect(() => {
    if (!visible) return;
    void load();
    const timer = window.setInterval(() => { if (document.visibilityState === "visible") void load(); }, 15_000);
    return () => window.clearInterval(timer);
  }, [visible, load]);
  const act: RunAction = (label, action, success) => run(label, async () => { await action(); await load(); }, success);
  const mark = (entry: ShortlistEntry, status: "opened" | "skipped" | "applied" | "new") => api<ShortlistView>(`/api/shortlist/${encodeURIComponent(entry.jobId)}/status`,
    { method: "POST", body: JSON.stringify({ status }) }).then(setView).catch(cause => setError(errorMessage(cause)));

  if (error && !view) return <Notice tone="warning"><strong>Today's list is unavailable.</strong> {error} Restart the updated local service, then refresh.</Notice>;
  if (!view) return <p className="quiet-empty">Loading today's list…</p>;
  const entries = view.entries.filter(entry => filter === "all" ? true : filter === "todo" ? TODO.includes(entry.status) : entry.status === filter);
  const excluded = Object.entries(view.excluded).filter(([, count]) => count).sort((a, b) => b[1]! - a[1]!);
  const queueable = view.entries.filter(entry => entry.status === "new" && entry.autoApply).length;
  return <div className="today-page">
    <div className="stats-strip today-stats">
      <div><span>Today's roles</span><strong>{view.counts.total}</strong><small>{view.generatedAt ? `Built ${new Date(view.generatedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} from ${view.candidates} matching roles` : view.nextBuildAt ? `Builds at ${view.nextBuildAt}` : "Not built yet"}</small></div>
      <div><span>Applied</span><strong>{view.counts.applied}</strong><small>Proven by the employer's confirmation page or a receipt{view.counts.marked ? ` · ${view.counts.marked} marked by you, not verified` : ""}</small></div>
      <div><span>In progress</span><strong>{view.counts.opened + view.counts.filled + view.counts.review + view.counts.auto_queued}</strong><small>{view.counts.review ? `${view.counts.review} ready for your review · ` : ""}Opened, filled or auto-applying; none submitted</small></div>
      <div><span>Needs you</span><strong>{view.counts.needs_you}</strong><small>Sign-in, a check or questions in an open tab</small></div>
    </div>
    <div className="today-toolbar">
      <div className="button-row">
        <button className="button primary" disabled={busy} onClick={() => void act("Building today's list…", async () => { setView(await post<ShortlistView>("/api/shortlist/rebuild", {})); }, "Today's list rebuilt from the roles crawled so far.")}><Icon name="refresh" size={16} />{view.generatedAt ? "Rebuild list" : "Build list now"}</button>
        <button className="button secondary" disabled={busy} onClick={() => void act("Checking every company…", async () => { const result = await post<{ due: number }>("/api/shortlist/refresh", {}); if (!result.due) throw new Error("Every company was checked recently or is cooling down."); }, "Every company is being checked now (about a minute each, one at a time). Rebuild the list afterwards.")}>Check all companies now</button>
        {view.autoApply.enabled && <button className="button secondary" disabled={busy || !queueable} onClick={() => void act("Queuing roles for the Chairman window…", async () => { await post("/api/shortlist/auto-apply", {}); }, `Up to ${queueable} roles are queued for the Chairman window. It fills each one; solve CAPTCHAs in its tabs and it submits them itself.`)}>Chairman window: submit all to-do ({queueable})</button>}
      </div>
      <p className="small muted">{view.companies.total} companies tracked · {view.companies.crawled} checked in the last day{view.companies.stale ? ` · ${view.companies.stale} not yet` : ""}. Experience used: {view.years !== undefined ? `${view.years} years` : "not known (add total_years_experience in Profile)"}; levels: {view.levels.join(", ")}.</p>
    </div>
    {error && <Notice tone="warning">{error}</Notice>}
    <SessionCard summary={session} extensionId={state.runtime.extension.id} busy={busy} act={act} />
    <Notice><strong>Applied ✓</strong> means proof was seen: the employer's confirmation page in the tab you submitted from, or a receipt. <strong>I submitted it</strong> records your word only, shown as "Marked by you · not verified". <strong>Fill in my Chrome</strong> opens one role in a new tab, where the paired extension starts the application (on Workday: Autofill with Resume), fills each step, presses Next and stops before Submit. Sign in when a site asks; it carries on.</Notice>
    {!view.generatedAt ? <EmptyState icon="opportunities" title="Today's list is not built yet">{view.companies.total ? `It builds at ${view.settings.runHour}:00 India time after every company is checked, or build it now from the roles crawled so far.` : "Add companies in Progress first (Suggested companies → Add all)."}</EmptyState> : <>
      <div className="today-filters" role="tablist" aria-label="Filter today's roles">
        {([["todo", `To do (${view.counts.new + view.counts.opened + view.counts.filled + view.counts.review + view.counts.needs_you})`], ["all", `All (${view.counts.total})`], ["applied", `Applied ✓ (${view.counts.applied})`],
          ...(view.counts.marked ? [["marked", `Marked by you (${view.counts.marked})`]] : []), ["auto_queued", `Chairman window (${view.counts.auto_queued})`], ["skipped", `Skipped (${view.counts.skipped})`]] as [Filter, string][])
          .map(([id, label]) => <button key={id} role="tab" aria-selected={filter === id} className={`chip-button ${filter === id ? "active" : ""}`} onClick={() => setFilter(id)}>{label}</button>)}
      </div>
      {!entries.length ? <p className="quiet-empty">Nothing here. {filter === "todo" ? "You have handled every role on today's list." : ""}</p> :
        <div className="application-table-wrap" tabIndex={0} role="region" aria-label="Today's roles"><table className="application-table today-table">
          <thead><tr><th>#</th><th>Role</th><th>Where</th><th>Fit</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>{entries.map(entry => <tr key={entry.jobId}>
            <td className="small">{entry.rank}{entry.carriedOver && <div className="muted" title="Also on yesterday's list">↻</div>}</td>
            <td><strong>{entry.company}</strong><div>{entry.title}</div><div className="small muted">{entry.family ?? "Role family"} · posted {ago(entry.postedAt).toLowerCase()}{entry.aiPolicy === "prohibited" ? " · no-AI posting" : ""}</div></td>
            <td><Badge tone={TIER[entry.tier]}>{entry.label}</Badge><div className="small muted">{entry.location.length > 70 ? `${entry.location.slice(0, 70)}…` : entry.location}</div></td>
            <td><strong>{entry.score}</strong><div className="small muted">{entry.skills.slice(0, 5).join(", ") || "title match"}</div><div className="small muted">{entry.experience}</div></td>
            <td><Badge tone={STATUS[entry.status].tone}>{STATUS[entry.status].label}</Badge>{entry.detail && <div className="small muted">{entry.detail.length > 90 ? `${entry.detail.slice(0, 90)}…` : entry.detail}</div>}</td>
            <td><div className="today-actions">
              <a className="button primary compact" href={entry.applyUrl} target="_blank" rel="noopener noreferrer" onClick={event => {
                if (entry.status === "new") void mark(entry, "opened");
                const extensionId = state.runtime.extension.paired ? state.runtime.extension.id : undefined;
                if (!extensionId) return;
                // The paired extension opens the role in a tab it works through: Apply, each step and Next, stopping before Submit.
                event.preventDefault();
                void askExtension(extensionId, { channel: "chairman:session", action: "open-job", jobId: entry.jobId }).then(result => {
                  if (!result.ok) throw new Error(result.error ?? "The extension did not open the role.");
                }).catch(cause => {
                  setError(`${errorMessage(cause)} Opened the posting without Chairman instead.`);
                  window.open(entry.applyUrl, "_blank", "noopener,noreferrer");
                });
              }}>Fill in my Chrome<Icon name="external" size={14} /></a>
              <button className="button secondary compact" disabled={busy || !view.autoApply.enabled || !entry.autoApply || !["new", "opened"].includes(entry.status)}
                title={!entry.autoApply ? "This site needs your own sign-in or restricts automation; use Fill in my Chrome." : view.autoApply.enabled ? "The separate Chairman window fills it; solve its CAPTCHA and it submits it itself." : view.autoApply.reason}
                onClick={() => void act(`Queuing ${entry.company} for the Chairman window…`, async () => { await post(`/api/shortlist/${encodeURIComponent(entry.jobId)}/auto-apply`, {}); }, `${entry.company} · ${entry.title} runs next in the Chairman window.`)}>Chairman window</button>
              {entry.status === "marked" ? <button className="button text-button compact" disabled={busy} onClick={() => void mark(entry, "opened")}>Undo</button>
                : entry.status !== "applied" && <button className="button text-button compact" disabled={busy} onClick={() => { if (window.confirm(`Only use this if you submitted ${entry.company}: ${entry.title} yourself. It is shown as "Marked by you · not verified" until the employer's confirmation page or a receipt is seen.`)) void mark(entry, "applied"); }}>I submitted it</button>}
              {entry.status === "skipped" ? <button className="button text-button compact" disabled={busy} onClick={() => void mark(entry, "new")}>Restore</button>
                : !["applied", "marked"].includes(entry.status) && <button className="button text-button compact" disabled={busy} onClick={() => void mark(entry, "skipped")}>Skip</button>}
            </div></td>
          </tr>)}</tbody></table></div>}
      {!!excluded.length && <p className="small muted">Left out of today's list: {excluded.map(([kind, count]) => `${count} ${EXCLUDED[kind] ?? kind}`).join(" · ")}.</p>}
    </>}
    <TodaySettings view={view} busy={busy} act={act} setView={setView} />
    {!state.runtime.extension.paired && <Notice tone="warning">The Chairman extension is not paired, so "Fill in my Chrome" opens the page without one-click filling. Pair it under Setup → Browser extension.</Notice>}
  </div>;
}

function TodaySettings({ view, busy, act, setView }: { view: ShortlistView; busy: boolean; act: RunAction; setView: (view: ShortlistView) => void }) {
  const [draft, setDraft] = useState<ShortlistSettings>(view.settings);
  const [dirty, setDirty] = useState(false);
  useEffect(() => { if (!dirty) setDraft(view.settings); }, [view.settings, dirty]);
  const update = (change: Partial<ShortlistSettings>) => { setDraft(current => ({ ...current, ...change })); setDirty(true); };
  const levels = draft.levels ?? view.levels;
  async function save(event: FormEvent) {
    event.preventDefault();
    await act("Saving list settings…", async () => { setView(await post<ShortlistView>("/api/shortlist/settings", { settings: draft })); setDirty(false); }, "Settings saved and today's list rebuilt.");
  }
  return <details className="form-disclosure today-settings"><summary>List settings <span>{draft.dailyCount} roles a day · built at {draft.runHour}:00 India time · up to {draft.maxPerCompany} per company</span></summary>
    <form onSubmit={event => void save(event)}>
      <div className="form-grid three-columns">
        <Field label="Roles per day">{id => <input id={id} type="number" min={1} max={300} value={draft.dailyCount} onChange={event => update({ dailyCount: Number(event.target.value) })} />}</Field>
        <Field label="Build at (hour, India time)">{id => <input id={id} type="number" min={0} max={23} value={draft.runHour} onChange={event => update({ runHour: Number(event.target.value) })} />}</Field>
        <Field label="At most per company">{id => <input id={id} type="number" min={1} max={100} value={draft.maxPerCompany} onChange={event => update({ maxPerCompany: Number(event.target.value) })} />}</Field>
        <Field label="Priority" hint="Visa-sponsored roles abroad first, or India first. Global remote roles rank with India.">{id => <select id={id} value={draft.priority} onChange={event => update({ priority: event.target.value as ShortlistSettings["priority"] })}><option value="abroad-first">Sponsored roles abroad first</option><option value="india-first">India first</option></select>}</Field>
        <Field label="Your years of experience" hint={view.years !== undefined && draft.experienceYears === null ? `Using ${view.years} from your profile.` : "Leave empty to use your profile."}>{id => <input id={id} type="number" min={0} max={60} step={0.5} value={draft.experienceYears ?? ""} placeholder={view.years !== undefined ? String(view.years) : "From profile"} onChange={event => update({ experienceYears: event.target.value === "" ? null : Number(event.target.value) })} />}</Field>
        <Field label="Posted within (days)">{id => <input id={id} type="number" min={1} max={365} value={draft.maxAgeDays} onChange={event => update({ maxAgeDays: Number(event.target.value) })} />}</Field>
        <Field label="Minimum fit score (0–100)">{id => <input id={id} type="number" min={0} max={100} value={draft.minScore} onChange={event => update({ minScore: Number(event.target.value) })} />}</Field>
      </div>
      <fieldset className="family-picker"><legend>Where</legend>
        <label className="checkbox-label"><input type="checkbox" checked={draft.includeIndia} onChange={event => update({ includeIndia: event.target.checked })} />Roles in India (onsite, hybrid or remote)</label>
        <label className="checkbox-label"><input type="checkbox" checked={draft.includeRemoteGlobal} onChange={event => update({ includeRemoteGlobal: event.target.checked })} />Remote roles open globally (never "Remote - US only" or "EU only")</label>
        <label className="checkbox-label"><input type="checkbox" checked={draft.includeAbroadSponsored} onChange={event => update({ includeAbroadSponsored: event.target.checked })} />Roles abroad that say visas are sponsored</label>
        <label className="checkbox-label"><input type="checkbox" checked={draft.includeAbroadUnknown} onChange={event => update({ includeAbroadUnknown: event.target.checked })} />Roles abroad that do not mention sponsorship (ranked last)</label>
      </fieldset>
      <fieldset className="family-picker"><legend>Levels {draft.levels ? "" : "(from your experience)"}</legend>
        {(SENIORITIES as readonly Seniority[]).filter(level => level !== "intern").map(level => <label className="checkbox-label" key={level}><input type="checkbox" checked={levels.includes(level)}
          onChange={event => { const next = event.target.checked ? [...levels, level] : levels.filter(item => item !== level); update({ levels: next.length ? next : null }); }} />{level}</label>)}
        {draft.levels && <button type="button" className="button text-button compact" onClick={() => update({ levels: null })}>Use my experience</button>}
      </fieldset>
      <label className="checkbox-label"><input type="checkbox" checked={draft.enabled} onChange={event => update({ enabled: event.target.checked })} />Build a new list every day automatically</label>
      <div className="button-row"><button className="button primary" type="submit" disabled={busy || !dirty}>Save and rebuild</button>{dirty && <button className="button text-button" type="button" onClick={() => { setDraft(view.settings); setDirty(false); }}>Discard</button>}</div>
    </form>
  </details>;
}
