import { useEffect, useState, type FormEvent } from "react";
import type { ExternalApplication, Job, PipelineStage } from "../../../packages/domain/types";
import { api, post } from "./api";
import type { Page, RunAction, State } from "./model";
import { Field, Notice } from "./ui";

const stages: PipelineStage[] = ["applied", "screening", "interview", "offer", "rejected", "withdrawn"];
const today = () => new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit" }).format();
interface History { items: { application: ExternalApplication; job?: Job }[]; total: number; offset: number; limit: number; }

export function ExternalApplications({ state, busy, run, navigate }: { state: State; busy: boolean; run: RunAction; navigate: (page: Page) => void }) {
  const [history, setHistory] = useState<History>();
  const [error, setError] = useState("");
  const [offset, setOffset] = useState(0);
  const [jobId, setJobId] = useState("");
  const [sourceId, setSourceId] = useState("manual");
  const [date, setDate] = useState(today);
  const [confirmation, setConfirmation] = useState("");
  const [acknowledged, setAcknowledged] = useState(false);
  const [revision, setRevision] = useState(0);
  useEffect(() => {
    let active = true;
    void api<History>(`/api/external-applications?offset=${offset}&limit=20`).then(value => {
      if (active) { setHistory(value); setError(""); }
    }).catch(cause => { if (active) setError(cause instanceof Error ? cause.message : "External history could not be loaded."); });
    return () => { active = false; };
  }, [offset, state.stats.submitted, revision]);
  async function record(event: FormEvent) {
    event.preventDefault();
    if (!acknowledged) return;
    const success = await run("Recording your external submission…", async () => {
      await post("/api/external-applications", { jobId, sourceId, submittedDate: date, confirmation });
    }, "Your reported external application was recorded. No application or resume was sent.");
    if (success) { setConfirmation(""); setAcknowledged(false); setRevision(value => value + 1); }
  }
  return <section className="setup-section" aria-label="External application history">
    <h2>Applications submitted outside this tool</h2>
    <p>Track an application you actually submitted on LinkedIn, a manual-only employer site, or elsewhere. No generated resume or confirmed profile is required to keep a factual record.</p>
    {error && <Notice tone="danger">{error}</Notice>}
    <details><summary>Record an external application</summary>
      <Notice>Recordkeeping only. This does not apply, create an account, or claim that the tool verified a provider receipt. Use the real submission date and confirmation.</Notice>
      <form className="form-grid" onSubmit={event => void record(event)}>
        <Field label="Previously submitted job">{id => <select id={id} required value={jobId} disabled={busy} onChange={event => {
          setJobId(event.target.value);
          const source = state.jobs.find(job => job.id === event.target.value)?.sourceId;
          setSourceId(source && state.sources.some(item => item.id === source) ? source : "manual");
        }}><option value="">Choose a known job</option>{state.jobs.map(job => <option key={job.id} value={job.id}>{job.company} — {job.title}</option>)}</select>}</Field>
        <Field label="Where you applied">{id => <select id={id} value={sourceId} disabled={busy} onChange={event => setSourceId(event.target.value)}><option value="manual">Manual / original employer</option>{state.sources.map(source => <option key={source.id} value={source.id}>{source.name}</option>)}</select>}</Field>
        <Field label="Actual submission date">{id => <input id={id} type="date" required max={today()} value={date} disabled={busy} onChange={event => setDate(event.target.value)} />}</Field>
        <Field label="External confirmation evidence">{id => <textarea id={id} required minLength={10} rows={3} value={confirmation} disabled={busy} onChange={event => setConfirmation(event.target.value)} />}</Field>
        <label className="checkbox-label"><input type="checkbox" required checked={acknowledged} disabled={busy} onChange={event => setAcknowledged(event.target.checked)} />I actually submitted this application and personally checked its confirmation.</label>
        <div className="button-row"><button className="button primary" disabled={busy || !jobId || !acknowledged} type="submit">Record external submission</button><button className="button text-button" type="button" onClick={() => navigate("opportunities")}>Job missing? Add it in Opportunities</button></div>
      </form>
    </details>
    <p className="small muted">{history?.total ?? 0} external records. These are separate from prepared application packets and are included in campaign outcomes by actual submission date.</p>
    {history?.items.map(({ application, job }) => <ExternalRow key={application.id} application={application} job={job} busy={busy} run={run} updated={() => setRevision(value => value + 1)} />)}
    {!!history?.total && <div className="button-row"><button className="button secondary" disabled={offset === 0 || busy} onClick={() => setOffset(value => Math.max(0, value - 20))}>Previous external records</button><span>{offset + 1}–{Math.min(offset + 20, history.total)} of {history.total}</span><button className="button secondary" disabled={offset + 20 >= history.total || busy} onClick={() => setOffset(value => value + 20)}>Next external records</button></div>}
  </section>;
}
function ExternalRow({ application, job, busy, run, updated }: { application: ExternalApplication; job?: Job; busy: boolean; run: RunAction; updated: () => void }) {
  const [stage, setStage] = useState<PipelineStage>(application.progress.stage);
  const [note, setNote] = useState(application.progress.note);
  const [next, setNext] = useState(application.progress.nextActionDate ?? "");
  return <details className="setup-section"><summary>{job?.company ?? "Imported employer"} · {job?.title ?? application.jobId} · {application.progress.stage}</summary>
    <p>Submitted {application.submittedDate} · Source: {application.sourceId} · User-reported external application</p>
    <p>{application.confirmation}</p>
    <div className="form-grid">
      <Field label="External hiring stage">{id => <select id={id} value={stage} disabled={busy} onChange={event => {
        const value = event.target.value; const nextStage = stages.find(item => item === value); if (nextStage) setStage(nextStage);
      }}>{stages.map(value => <option key={value} value={value}>{value}</option>)}</select>}</Field>
      <Field label="External follow-up date">{id => <input id={id} type="date" value={next} disabled={busy} onChange={event => setNext(event.target.value)} />}</Field>
      <Field label="External progress note">{id => <textarea id={id} rows={2} value={note} disabled={busy} onChange={event => setNote(event.target.value)} />}</Field>
      <button className="button secondary" disabled={busy} onClick={() => void run("Saving your reported outcome…", async () => {
        await post(`/api/external-applications/${application.id}/progress`, { stage, note, ...(next ? { nextActionDate: next } : {}) }); updated();
      }, "Reported outcome saved. No contact or application was sent.")}>Save external outcome</button>
    </div>
  </details>;
}
