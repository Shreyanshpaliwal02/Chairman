import { useEffect, useRef, useState, type FormEvent } from "react";
import { api, post } from "./api";
import { type Fact, type Profile, type RunAction } from "./model";
import { Badge, Field, Icon, Notice, RecordEditor } from "./ui";
import { AnswerGuide, NarrativeTemplateGuide } from "./AnswerGuide";
import { RememberedAnswers } from "./RememberedAnswers";

export function ProfileEditor({ profile, busy, run, onDirty }: { profile: Profile; busy: boolean; run: RunAction; onDirty: (dirty: boolean) => void }) {
  const [draft, setDraft] = useState<Profile>(() => structuredClone(profile));
  const [dirty, setDirty] = useState(false);
  const [preferencesReviewed, setPreferencesReviewed] = useState(profile.confirmed);
  const [validation, setValidation] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => { if (!dirty) { setDraft(structuredClone(profile)); setPreferencesReviewed(profile.confirmed); } }, [profile]);
  useEffect(() => { onDirty(dirty); }, [dirty, onDirty]);

  function update(next: Profile) {
    setDraft({ ...next, confirmed: false });
    setDirty(true);
    setValidation("");
  }

  function updateFact(id: string, change: Partial<Fact>) {
    update({ ...draft, facts: draft.facts.map((fact) => fact.id === id ? { ...fact, ...change, ...(!Object.hasOwn(change, "confirmed") ? { confirmed: false } : {}) } : fact) });
  }

  async function importResume() {
    if (!file) return;
    if (dirty && !window.confirm("Replace your unsaved profile with the imported resume? Your original file will not be modified.")) return;
    await run("Importing resume locally…", async () => {
      const form = new FormData();
      form.append("file", file);
      const result = await api<{ profile: Profile }>("/api/profile/import", { method: "POST", body: form });
      setDraft(structuredClone(result.profile));
      setDirty(false);
      setPreferencesReviewed(false);
      setFile(null);
      if (fileInput.current) fileInput.current.value = "";
    }, "Resume imported locally. Review each extracted fact and your preferences before confirming.");
  }

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const submitter = (event.nativeEvent as SubmitEvent).submitter as HTMLButtonElement | null;
    const confirm = submitter?.value === "confirm";
    if (draft.preferences.dailyLimit !== null && (!Number.isSafeInteger(draft.preferences.dailyLimit) || draft.preferences.dailyLimit < 1)) {
      setValidation("Enter a positive whole-number daily cap, or leave it empty for no global cap."); return;
    }
    if (confirm && (!draft.facts.length || draft.facts.some((fact) => !fact.confirmed || !fact.text.trim()))) {
      setValidation("Review and confirm every fact, and include at least one non-empty fact."); return;
    }
    if (confirm && !draft.skills.length) { setValidation("Add your evidenced skills before confirming the profile."); return; }
    if (confirm && !preferencesReviewed) { setValidation("Review your application preferences and check the confirmation below."); return; }
    await run(confirm ? "Saving your confirmed profile…" : "Saving profile draft…", async () => {
      const result = await post<{ profile: Profile }>("/api/profile", { profile: { ...draft, confirmed: confirm } });
      setDraft(structuredClone(result.profile));
      setDirty(false);
      setPreferencesReviewed(result.profile.confirmed);
      setValidation("");
    }, confirm ? "Profile confirmed and saved. Approve at least two valid templates/originals in any slots and explicitly activate Auto Apply, or prepare manual packets. Previous Auto Apply consent is paused after profile changes." : "Draft saved. Confirm your reviewed profile before preparation or Auto Apply; prior consent is paused after changes.");
  }

  const confirmedFacts = draft.facts.filter((fact) => fact.confirmed).length;
  return <div className="profile-layout">
    <div className="profile-main">
      <section className="resume-import">
        <div className="import-icon"><Icon name="upload" size={25} /></div>
        <div><h2>Bring your experience with you.</h2><p>Import a PDF, DOCX, or plain-text resume. Extraction stays local, and your original file is never changed.</p>
          <div className="import-controls"><label className="file-label" htmlFor="resume-file">Choose resume<input ref={fileInput} id="resume-file" type="file" accept=".pdf,.docx,.txt,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain" disabled={busy} onChange={(event) => setFile(event.target.files?.[0] || null)} /></label><button className="button primary" type="button" disabled={!file || busy} onClick={() => void importResume()}>Import locally<Icon name="arrow" size={16} /></button></div>
          {file && <p className="small">{file.name} · {Math.ceil(file.size / 1024)} KB</p>}
        </div>
      </section>
      <form onSubmit={(event) => void save(event)}>
        <section className="form-section"><div className="section-heading"><div><h2>Contact & skills</h2><p>Only add information you want available in application documents.</p></div><Badge tone={draft.confirmed && !dirty ? "positive" : "warning"}>{dirty ? "Unsaved changes" : draft.confirmed ? "Confirmed" : "Needs confirmation"}</Badge></div>
          <div className="form-grid">
            <Field label="Full name">{(id) => <input id={id} autoComplete="name" value={draft.name} required onChange={(event) => update({ ...draft, name: event.target.value })} disabled={busy} />}</Field>
            <Field label="Email address">{(id) => <input id={id} type="email" autoComplete="email" value={draft.email} required onChange={(event) => update({ ...draft, email: event.target.value })} disabled={busy} />}</Field>
            <Field label="Phone (optional)">{(id) => <input id={id} type="tel" autoComplete="tel" value={draft.phone} onChange={(event) => update({ ...draft, phone: event.target.value })} disabled={busy} />}</Field>
            <Field label="Location">{(id) => <input id={id} autoComplete="address-level2" value={draft.location} onChange={(event) => update({ ...draft, location: event.target.value })} disabled={busy} />}</Field>
          </div>
          <ListField label="Evidenced skills" hint="Separate skills with commas or new lines. Do not add skills just because a job asks for them." value={draft.skills} onChange={(skills) => update({ ...draft, skills })} disabled={busy} />
          <details className="form-disclosure"><summary>Profile links <span>{Object.keys(draft.links).length} added</span></summary><RecordEditor value={draft.links} title="link" disabled={busy} onChange={(links) => update({ ...draft, links })} /></details>
        </section>

        <section className="form-section"><div className="section-heading"><div><h2>Review your facts</h2><p>Check wording, employer, official title, dates, and every metric. Editing a fact resets its confirmation.</p></div><span className="small muted">{confirmedFacts} / {draft.facts.length} confirmed</span></div>
          {!draft.facts.length && <div className="empty-inline"><Icon name="profile" /><p>No facts yet. Import your resume or add your first verified experience.</p></div>}
          <div className="facts-list">{draft.facts.map((fact, index) => <fieldset className="fact-editor" key={fact.id}><legend>Fact {index + 1}</legend>
            <div className="fact-toolbar"><Field label="Category">{(id) => <select id={id} value={fact.category} disabled={busy} onChange={(event) => updateFact(fact.id, { category: event.target.value as Fact["category"] })}><option value="experience">Experience</option><option value="education">Education</option><option value="publication">Publication</option><option value="summary">Summary</option></select>}</Field><button className="button text-button danger-text" type="button" disabled={busy} onClick={() => update({ ...draft, facts: draft.facts.filter((item) => item.id !== fact.id) })}>Remove fact</button></div>
            <Field label="Factual content">{(id) => <textarea id={id} rows={4} value={fact.text} required disabled={busy} onChange={(event) => updateFact(fact.id, { text: event.target.value })} />}</Field>
            <div className="form-grid three-columns"><Field label="Employer / institution">{(id) => <input id={id} value={fact.employer || ""} disabled={busy} onChange={(event) => updateFact(fact.id, { employer: event.target.value })} />}</Field><Field label="Official role / qualification">{(id) => <input id={id} value={fact.role || ""} disabled={busy} onChange={(event) => updateFact(fact.id, { role: event.target.value })} />}</Field><Field label="Dates">{(id) => <input id={id} value={fact.dates || ""} disabled={busy} onChange={(event) => updateFact(fact.id, { dates: event.target.value })} placeholder="As shown in your resume" />}</Field></div>
            <label className="checkbox-label fact-confirm"><input type="checkbox" checked={fact.confirmed} disabled={busy || !fact.text.trim()} onChange={(event) => updateFact(fact.id, { confirmed: event.target.checked })} />I reviewed this fact and confirm it is accurate.</label>
          </fieldset>)}</div>
          <button type="button" className="button secondary" disabled={busy} onClick={() => update({ ...draft, facts: [...draft.facts, { id: crypto.randomUUID(), category: "experience", text: "", confirmed: false }] })}><Icon name="plus" />Add a fact</button>
        </section>

        <section className="form-section"><div className="section-heading"><div><h2>Application preferences</h2><p>These starting preferences need your review. Unknown eligibility is not treated as permission.</p></div></div>
          <div className="form-grid">
            <ListField label="Role families" value={draft.preferences.roles} disabled={busy} onChange={(roles) => { update({ ...draft, preferences: { ...draft.preferences, roles } }); setPreferencesReviewed(false); }} />
            <ListField label="Target countries / regions" value={draft.preferences.countries} disabled={busy} onChange={(countries) => { update({ ...draft, preferences: { ...draft.preferences, countries } }); setPreferencesReviewed(false); }} />
            <ListField label="Authorized to work in" value={draft.preferences.authorizedCountries} disabled={busy} onChange={(authorizedCountries) => { update({ ...draft, preferences: { ...draft.preferences, authorizedCountries } }); setPreferencesReviewed(false); }} />
            <ListField label="Excluded employers and aliases" value={draft.preferences.excludedEmployers} disabled={busy} onChange={(excludedEmployers) => { update({ ...draft, preferences: { ...draft.preferences, excludedEmployers } }); setPreferencesReviewed(false); }} />
            <Field label="Annual gross base salary target (INR)" hint="A target, not a hard floor. Equity and bonus are separate.">{(id) => <input id={id} type="number" min={0} step={10000} required value={draft.preferences.salaryTargetInr} disabled={busy} onChange={(event) => { update({ ...draft, preferences: { ...draft.preferences, salaryTargetInr: Number(event.target.value) } }); setPreferencesReviewed(false); }} />}</Field>
            <Field label="Optional daily attempt cap" hint="Leave empty for no global daily or session cap. A personal daily cap resets in Asia/Kolkata; lower source limits always apply. This is separate from your campaign target.">{(id) => <input id={id} type="number" min={1} step={1} value={draft.preferences.dailyLimit ?? ""} placeholder="No global cap" disabled={busy} onChange={(event) => { update({ ...draft, preferences: { ...draft.preferences, dailyLimit: event.target.value === "" ? null : Number(event.target.value) } }); setPreferencesReviewed(false); }} />}</Field>
          </div>
          <div className="checkbox-stack"><label className="checkbox-label"><input type="checkbox" checked={draft.preferences.allowLongTermContracts} disabled={busy} onChange={(event) => { update({ ...draft, preferences: { ...draft.preferences, allowLongTermContracts: event.target.checked } }); setPreferencesReviewed(false); }} />Include long-term contracts, not short gigs</label><label className="checkbox-label"><input type="checkbox" checked={draft.preferences.needsSponsorshipAbroad} disabled={busy} onChange={(event) => { update({ ...draft, preferences: { ...draft.preferences, needsSponsorshipAbroad: event.target.checked } }); setPreferencesReviewed(false); }} />I need employer sponsorship for work abroad</label><label className="checkbox-label preference-confirm"><input type="checkbox" checked={preferencesReviewed} disabled={busy} onChange={(event) => { setPreferencesReviewed(event.target.checked); setDirty(true); }} />I reviewed these preferences, work-authorization details, and safety limits.</label></div>
        </section>

        <section className="form-section" id="profile-answers"><h2>Application answers</h2><p className="section-copy">Store only factual answers and your own narrative wording that you explicitly want to provide. Use the exact keys below for supported application fields. Nothing is filled by default. Sensitive information, consent, and legal declarations are never inferred. Required unanswered questions stop that job for your input.</p><AnswerGuide profile={draft} /><NarrativeTemplateGuide answers={draft.answers} disabled={busy} onAdd={key => update({ ...draft, answers: { ...draft.answers, [key]: "" } })} /><RecordEditor value={draft.answers} title="answer" disabled={busy} onChange={(answers) => update({ ...draft, answers })} /><RememberedAnswers busy={busy} run={run} /></section>
        {validation && <div className="feedback feedback-error" role="alert"><Icon name="info" /><p>{validation}</p></div>}
        <div className="profile-save"><p><strong>{dirty ? "Your changes need saving." : draft.confirmed ? "Your profile is ready." : "Review before preparing."}</strong><span>Saving a draft does not confirm it. Saved changes invalidate approvals and pause previous Auto Apply consent.</span></p><div className="button-row"><button className="button secondary" type="submit" value="draft" formNoValidate disabled={busy}>Save draft</button><button className="button primary" type="submit" value="confirm" disabled={busy}><Icon name="check" />Confirm profile & save</button></div></div>
      </form>
    </div>
    <aside className="profile-guide"><Icon name="shield" size={24} /><h3>Evidence, not embellishment.</h3><p>Your confirmed facts guide matching and derived resumes. Auto Apply needs at least two valid, accuracy-approved templates/originals in any of eight slots. Choose JD-specific tailoring or send original files unchanged. Template-only claims must first be confirmed as profile facts; missing keywords never become invented experience.</p><ol><li><strong>Import locally</strong><span>Bring in your existing resume. This extracts a profile; it does not populate the resume slots.</span></li><li><strong>Review every fact</strong><span>Correct extraction errors and preserve official titles and dates.</span></li><li><strong>Confirm and save</strong><span>Review preferences and factual answers. Auto Apply still needs its own explicit activation.</span></li></ol><Notice>PDF extraction can change reading order. Compare facts against your original resume before confirming. Derived resumes may use a different, clean ATS-safe layout; uploaded originals remain untouched.</Notice></aside>
  </div>;
}

function ListField({ label, value, onChange, hint, disabled }: { label: string; value: string[]; onChange: (value: string[]) => void; hint?: string; disabled?: boolean }) {
  const [text, setText] = useState(value.join(", "));
  const parse = (input: string) => input.split(/[,\n]/).map((item) => item.trim()).filter(Boolean);
  useEffect(() => { if (JSON.stringify(parse(text)) !== JSON.stringify(value)) setText(value.join(", ")); }, [value]);
  return <Field label={label} hint={hint || "Separate entries with commas or new lines."}>{(id) => <textarea id={id} rows={3} value={text} disabled={disabled} onChange={(event) => { setText(event.target.value); onChange(parse(event.target.value)); }} />}</Field>;
}
