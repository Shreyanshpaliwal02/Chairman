import { useEffect, useState, type FormEvent } from "react";
import { post } from "./api";
import { configuredAiAvailable, type RunAction, type State } from "./model";
import { Badge, Field, Notice } from "./ui";
import { DEFAULT_GEMINI_MODEL, GEMINI_FREE_MODELS } from "../../../packages/inference/gemini-policy";

/** `pick` is a model chosen on the AI page; it fills in the model (consent is asked for again before saving). */
export function InferenceSettings({ ai, busy, run, pick }: { ai: State["runtime"]["ai"]; busy: boolean; run: RunAction; pick?: { model: string; at: number } }) {
  const reportedModel = ai.provider === "gemini" && !GEMINI_FREE_MODELS.some(value => value === ai.model)
    ? DEFAULT_GEMINI_MODEL : ai.provider ? ai.model : "gpt-6-astra";
  const [provider, setProvider] = useState<"copilot" | "ollama" | "gemini">(ai.provider ?? "copilot");
  const [model, setModel] = useState(reportedModel);
  const [allowRemoteProcessing, setAllowRemoteProcessing] = useState(false);
  const [acknowledgeUsage, setAcknowledgeUsage] = useState(false);
  const [confirmFreeTier, setConfirmFreeTier] = useState(false);
  const [apiKey, setApiKey] = useState("");
  const [dirty, setDirty] = useState(false);
  const ready = configuredAiAvailable(ai);
  const copilot = provider === "copilot";
  const gemini = provider === "gemini";
  const remote = copilot || gemini;
  const signature = JSON.stringify([ai.provider, ai.model, ai.remote, ai.consentRequired, ai.keyConfigured, ai.freeTierConfirmed]);
  useEffect(() => {
    if (!dirty) { setProvider(ai.provider ?? "copilot"); setModel(reportedModel); }
  }, [ai.provider, reportedModel, dirty]);
  useEffect(() => { setAllowRemoteProcessing(false); setAcknowledgeUsage(false); setConfirmFreeTier(false); }, [signature]);
  function resetConsent() { setAllowRemoteProcessing(false); setAcknowledgeUsage(false); setConfirmFreeTier(false); setDirty(true); }
  useEffect(() => { if (pick) { setModel(pick.model); resetConsent(); } }, [pick?.at]);
  const consentMissing = remote && (!model.trim() || !allowRemoteProcessing || !acknowledgeUsage || (gemini && !confirmFreeTier));
  async function save(event: FormEvent) {
    event.preventDefault();
    if (busy || !dirty || consentMissing) return;
    await run("Saving the inference provider and your explicit processing choices…", async () => {
      await post("/api/inference/config", {
        provider, ...(model.trim() ? { model: model.trim() } : {}),
        allowRemoteProcessing: remote && allowRemoteProcessing, acknowledgeUsage: remote && acknowledgeUsage,
        ...(gemini ? { confirmFreeTier } : {}),
      });
      setDirty(false); setAllowRemoteProcessing(false); setAcknowledgeUsage(false); setConfirmFreeTier(false);
    }, "AI configuration saved. Check its reported availability before use; no generation prompt, login, or application was started.");
  }
  return <section className="setup-section inference-settings" aria-labelledby="inference-title">
    <div className="section-heading"><div><h2 id="inference-title">Configured AI</h2><p>Choose Gemini public-tag ranking, hosted Copilot or local Ollama. No silent provider or model fallback.</p></div><Badge tone={ready ? "positive" : "warning"}>{ready ? "Available" : "Unavailable"}</Badge></div>
    <dl className="detail-grid"><dt>Saved provider</dt><dd>{ai.provider === "gemini" ? "Google Gemini · hosted public-tag ranking" : ai.provider === "copilot" ? "GitHub Copilot · hosted processing" : ai.provider === "ollama" ? "Ollama · local processing" : "Provider not reported by this service"}</dd><dt>Configured model</dt><dd>{ai.model || "Not reported"}</dd><dt>Processing location</dt><dd>{ai.remote === true ? "Remote" : ai.remote === false ? "Local" : "Not reported"}</dd>
      {ai.provider === "copilot" && <><dt>SDK sign-in</dt><dd>{ai.authenticated === true ? "Signed in" : ai.authenticated === false ? "Sign-in required" : "Not verified"}</dd><dt>Exact model access</dt><dd>{ai.modelAvailable === true ? "Available to the configured SDK account" : ai.modelAvailable === false ? "Not available to the configured SDK account" : "Not verified"}</dd><dt>Remote-processing consent</dt><dd>{ai.consentRequired === false ? "Saved consent reported" : ai.consentRequired === true ? "Required before use" : "Not verified"}</dd></>}
      {ai.provider === "gemini" && <><dt>Private API key</dt><dd>{ai.keyConfigured ? "Configured locally (never displayed)" : "Not configured"}</dd><dt>Exact model metadata</dt><dd>{ai.modelAvailable ? "Verified without a generation prompt" : "Not verified"}</dd><dt>Free project confirmation</dt><dd>{ai.freeTierConfirmed ? "User-confirmed; billing tier cannot be verified by this app" : "Required; billing must be disabled in your Google project"}</dd><dt>Remote-processing consent</dt><dd>{ai.consentRequired === false ? "Saved consent reported" : "Required before use"}</dd>{ai.retryAt && <><dt>Quota pause until</dt><dd>{ai.retryAt} · no automatic retry</dd></>}</>}
    </dl>
    {!ready && <Notice tone="warning">{ai.reason || "Configured AI is unavailable. Review sign-in, model access, and processing consent, then refresh status."} A selected model name is not proof of access. Deterministic preparation is a separate, explicit choice.</Notice>}
    <form className="inference-form" onSubmit={event => void save(event)}>
      <div className="form-grid">
        <Field label="AI provider">{id => <select id={id} value={provider} disabled={busy} onChange={event => {
          const next = event.target.value as typeof provider;
          setProvider(next); setModel(next === ai.provider ? reportedModel : next === "gemini" ? DEFAULT_GEMINI_MODEL : next === "copilot" ? "gpt-6-astra" : ""); setApiKey(""); resetConsent();
        }}><option value="gemini">Google Gemini · free-eligible public-tag ranking</option><option value="copilot">GitHub Copilot · hosted</option><option value="ollama">Ollama · local</option></select>}</Field>
        <Field label="Exact AI model" hint={gemini ? "Only reviewed free-eligible Flash models. Pricing eligibility is not proof that your project has billing disabled." : copilot ? "Requested default: gpt-6-astra. The SDK must report access to this exact model." : "Use an installed Ollama model name, or leave blank to keep the service default."}>{id => gemini
          ? <select id={id} value={model} disabled={busy} onChange={event => { setModel(event.target.value); resetConsent(); }}>{GEMINI_FREE_MODELS.map(value => <option key={value} value={value}>{value}</option>)}</select>
          : <input id={id} value={model} required={copilot} disabled={busy} autoComplete="off" spellCheck={false} placeholder={copilot ? "gpt-6-astra" : "Configured local model"} onChange={event => { setModel(event.target.value); resetConsent(); }} />}</Field>
      </div>
      {gemini ? <>
        <Notice><strong>Gemini is hosted ranking, not private resume rewriting.</strong> Google prohibits sending personal, sensitive or confidential information to unpaid services; inputs may be human-reviewed and used to improve products. This app sends only anonymous positional evidence IDs and a fixed public technology vocabulary. Raw resume facts, employers, dates, contact details, links, freeform skill labels and the full JD stay local. Unrecognized evidence cannot be ranked remotely; no perfect ATS score or rewritten experience is promised.</Notice>
        <p>Create your own key in <a href="https://aistudio.google.com/api-keys" target="_blank" rel="noreferrer">Google AI Studio</a>. Verify that its project is <strong>Free with billing disabled</strong>. The app cannot determine billing tier from a key, never enables billing and does not use Copilot or browser tokens. Review <a href="https://ai.google.dev/gemini-api/terms" target="_blank" rel="noreferrer">Google's terms</a> and <a href="https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash" target="_blank" rel="noreferrer">pricing</a>.</p>
        <Field label="Gemini API key" hint="Saved only in a private file on this device, separately from profile/settings/exports. Save the key first, then grant fresh consent below. It is never returned by this dashboard.">{id => <input id={id} type="password" autoComplete="new-password" spellCheck={false} value={apiKey} disabled={busy} onChange={event => setApiKey(event.target.value)} />}</Field>
        <div className="button-row"><button className="button secondary" type="button" disabled={busy || !apiKey} onClick={() => void run("Saving the private Gemini key…", async () => {
          try { await post("/api/inference/gemini-key", { apiKey }); }
          finally { setApiKey(""); resetConsent(); }
        }, "Private key saved. Remote processing and Auto Apply authorization were revoked; grant fresh consent explicitly.")}>Save private Gemini key</button>
          <button className="button danger-quiet" type="button" disabled={busy} onClick={() => void run("Revoking the private Gemini key…", async () => {
            await post("/api/inference/gemini-key", { revoke: true }); setApiKey(""); resetConsent();
          }, "Gemini key disabled locally, including environment-key fallback. Revoke the key in AI Studio too if it must stop working elsewhere.")}>Remove Gemini key</button></div>
        <div className="checkbox-stack">
          <label className="checkbox-label"><input type="checkbox" checked={allowRemoteProcessing} disabled={busy} onChange={event => { setAllowRemoteProcessing(event.target.checked); setDirty(true); }} /><span>I allow sending only anonymous evidence IDs and fixed public technology tags to Google Gemini for hosted ranking.</span></label>
          <label className="checkbox-label"><input type="checkbox" checked={acknowledgeUsage} disabled={busy} onChange={event => { setAcknowledgeUsage(event.target.checked); setDirty(true); }} /><span>I understand Google's unpaid-service data use, human review and project-specific quotas. HTTP 429 pauses requests; there is no automatic retry or fallback.</span></label>
          <label className="checkbox-label"><input type="checkbox" checked={confirmFreeTier} disabled={busy} onChange={event => { setConfirmFreeTier(event.target.checked); setDirty(true); }} /><span>I checked that this key's Google project is Free with billing disabled. The app cannot verify this, and a billed project can incur charges.</span></label>
        </div>
        <p className="small muted">All three choices start unchecked. Copilot consent never grants Gemini access. Key/provider/model changes require fresh authorization. Refresh checks exact-model metadata only, not a paid or free generation prompt.</p>
      </> : copilot ? <>
        <Notice><strong>Copilot is hosted processing, not local inference.</strong> AI-assisted tailoring sends bounded confirmed resume-fact and job-description text to GitHub Copilot and uses your Copilot allowance. Your chat’s selected model is not automatically accessible through the SDK. Sign-in, exact model access, and explicit remote-processing consent are all required; there is no silent fallback to another model or Ollama.</Notice>
        <p>Sign in yourself with the official interactive CLI: <code>npm exec --package=@github/copilot -- copilot login</code>. This may offer to download the CLI. The SDK includes a headless runtime, not that interactive login screen. This dashboard does not collect passwords or tokens or send a test generation prompt.</p>
        <div className="checkbox-stack">
          <label className="checkbox-label"><input type="checkbox" checked={allowRemoteProcessing} disabled={busy} onChange={event => { setAllowRemoteProcessing(event.target.checked); setDirty(true); }} /><span>I allow sending bounded confirmed resume-fact and job-description text to GitHub Copilot for hosted AI processing.</span></label>
          <label className="checkbox-label"><input type="checkbox" checked={acknowledgeUsage} disabled={busy} onChange={event => { setAcknowledgeUsage(event.target.checked); setDirty(true); }} /><span>I understand that this uses my Copilot allowance and that SDK model access may differ from my chat.</span></label>
        </div>
        <p className="small muted">Both choices start unchecked. Save explicitly to grant this processing consent; selecting a provider or model alone grants nothing. Changing the model clears these choices.</p>
      </> : <><p>Ollama runs inference on this computer. Use <code>OLLAMA_NO_CLOUD=1</code> and the installed local model from your setup instructions. Saving does not install or start Ollama and does not permit a hosted fallback.</p><p className="small muted">Saving Ollama sets remote-processing permission to false. Existing documents and application outcomes are unchanged.</p></>}
      <div className="button-row"><button className="button primary" type="submit" disabled={busy || !dirty || consentMissing}>Save AI configuration</button><button className="button secondary" type="button" disabled={busy} onClick={() => void run("Refreshing configured AI status…", async () => { await post("/api/inference/refresh", {}); }, "AI status refreshed. No generation or application was requested.")}>Refresh AI status</button></div>
      {(ai.provider === "copilot" || ai.provider === "gemini") && ai.consentRequired === false && <button className="button danger-quiet" type="button" disabled={busy} onClick={() => void run("Revoking hosted processing consent…", async () => {
        await post("/api/inference/config", { provider: ai.provider, model: ai.model, allowRemoteProcessing: false, acknowledgeUsage: false, ...(ai.provider === "gemini" ? { confirmFreeTier: false } : {}) });
        setDirty(false); setAllowRemoteProcessing(false); setAcknowledgeUsage(false); setConfirmFreeTier(false);
      }, "Hosted processing is disabled. Already sent requests cannot be recalled; future inference needs fresh consent.")}>Disable remote processing</button>}
      {dirty && <p className="small muted" role="status">Unsaved AI configuration. Current actions still use the saved provider and permissions.</p>}
    </form>
    <p className="small muted">The legacy API mode is named <code>local-ai</code>; it means the configured AI provider, not a promise of local processing. Review Auto Apply’s saved authorization after changing inference configuration. Your computer and local service must remain running to coordinate application work.</p>
  </section>;
}
