let session: Promise<void> | undefined;

export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(path, {
    ...options,
    credentials: "same-origin",
    headers: {
      ...(options.body && !(options.body instanceof FormData) ? { "Content-Type": "application/json" } : {}),
      ...options.headers,
    },
  });
  if (!response.ok) {
    let message = `Request failed (${response.status}). Please try again.`;
    try {
      const body: unknown = await response.json();
      if (body && typeof body === "object" && "error" in body && typeof body.error === "string") message = body.error;
    } catch {
      message = `The local service returned an unreadable error (${response.status}). Check that it is running, then retry.`;
    }
    throw new Error(message);
  }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

export function initializeSession(): Promise<void> {
  if (!session) {
    session = api<unknown>("/api/session").then(() => undefined).finally(() => {
      session = undefined;
    });
  }
  return session;
}

export async function scanSources(sourceId?: string): Promise<void> {
  const result = await post<{ results: { sourceId: string; count?: number; error?: string }[] }>("/api/scan", sourceId ? { sourceId } : {});
  const errors = result.results.filter(item => item.error);
  if (errors.length) throw new Error(`Discovery needs attention: ${errors.map(item => `${item.sourceId}: ${item.error}`).join(" ")}`);
}

export function post<T>(path: string, body: unknown): Promise<T> {
  return api<T>(path, { method: "POST", body: JSON.stringify(body) });
}

export async function documentBlob(path: string): Promise<Blob> {
  const response = await fetch(path, { credentials: "same-origin" });
  if (!response.ok) {
    const text = await response.text();
    let message = `Download failed (${response.status}).`;
    try {
      const body: unknown = JSON.parse(text);
      if (body && typeof body === "object" && "error" in body && typeof body.error === "string") message = body.error;
    } catch {
      message += " The local service did not return a valid document.";
    }
    throw new Error(message);
  }
  return response.blob();
}

export async function download(path: string, fallbackName: string): Promise<void> {
  const blob = await documentBlob(path);
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fallbackName;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
}
