import { preparationLabel, type Packet } from "./model";
import { Notice } from "./ui";

export function PacketProvenance({ packet }: { packet: Packet }) {
  const tailoring = packet.tailoring;
  const submitted = packet.artifacts.find(artifact => artifact.sha256 === packet.submissionArtifactSha256);
  const inference = tailoring?.inference ?? packet.draft.inference;
  return <>
    {inference && <Notice><strong>AI used for this saved document</strong><p>{inference.provider === "gemini" ? "Google Gemini" : inference.provider === "copilot" ? "GitHub Copilot" : "Ollama"} · {inference.model} · {inference.remote ? "Hosted processing under consent" : "Local processing"}</p>{inference.provider === "gemini" && <p>Only anonymous IDs and fixed public technology tags were sent. Source facts and skill labels were restored locally without rewriting claims.</p>}<p className="small muted">This is the provider recorded when the document was created, not your current provider setting.</p></Notice>}
    {packet.draft.mode === "jd-tailored" && <section className="tailoring-provenance" aria-label="Tailored document provenance">
      <h3>{preparationLabel(packet.draft.mode, tailoring?.engine)}</h3>
      <p>This packet contains derived documents, not the uploaded original. The approved base is a reference; the clean ATS-safe layout may differ from the uploaded PDF. Originals remain untouched. No ATS score or hiring outcome is guaranteed.</p>
      {tailoring ? <>
        <dl className="detail-grid"><dt>Approved base</dt><dd>{tailoring.baseVariantLabel} · {tailoring.baseVariantId}</dd><dt>Base SHA-256</dt><dd className="hash-value">{tailoring.baseVariantSha256}</dd><dt>Job description SHA-256</dt><dd className="hash-value">{tailoring.jobDescriptionHash}</dd></dl>
        <h4>Supported keywords</h4><p>{tailoring.supportedKeywords.join(" · ") || "No additional supported keywords recorded."}</p>
        <h4>Missing evidence · not claimed</h4><p>{tailoring.missingKeywords.join(" · ") || "No additional gaps recorded; review the full job requirements."}</p>
        <p className="small muted">Missing keywords are not skills claims. Template-only claims must be confirmed as profile facts before they can appear in derived documents.</p>
        {tailoring.notes.length > 0 && <ul>{tailoring.notes.map((note, index) => <li key={index}>{note}</li>)}</ul>}
      </> : <Notice tone="warning">Tailoring provenance was not returned. Download the saved documents to inspect them; the base and engine cannot be verified here.</Notice>}
      <p className="small muted">{packet.approvedBy === "autopilot" ? "Prepared under standing Auto Apply authorization." : "Locally prepared; preparation alone does not authorize submission."} Authorization: {packet.authorizationId || "Not granted"}</p>
    </section>}
    {packet.submissionArtifactSha256 && <Notice><strong>Exact submission artifact SHA-256</strong><p>{submitted?.filename || "No matching filename in the loaded artifact metadata."}</p><span className="hash-value">{packet.submissionArtifactSha256}</span><p>This fingerprint identifies the exact file used for the submission attempt, not proof that the employer received it.</p></Notice>}
  </>;
}
