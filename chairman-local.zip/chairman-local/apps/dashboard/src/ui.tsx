import { useId, useState, type ReactNode } from "react";
import { safeUrl } from "./model";

const paths = {
  home: "m3 10 9-7 9 7 M5 9v12h14V9 M9 21v-8h6v8",
  autopilot: "M4 5h16v14H4z M4 9h16 M9 13l3 2-3 2 M15 15h2",
  progress: "M4 20V11 M10 20V5 M16 20v-6 M22 20H2",
  today: "M4 5h16v16H4z M4 9h16 M8 3v4 M16 3v4 M8 13h3 M8 17h6",
  resumes: "M5 3h10l4 4v14H5z M14 3v5h5 M9 12h6 M9 16h6",
  opportunities: "M3 7h18v14H3z M8 7V3h8v4 M3 12h18 M10 12v3h4v-3",
  profile: "M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0ZM4 21v-2a8 8 0 0 1 16 0v2",
  applications: "M7 3h14v18H7z M3 7v14 M11 8h6 M11 12h6 M11 16h4",
  sources: "M8 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM22 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM15 19a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM7 10l3 6 M17 10l-3 6 M8 7h8",
  ai: "M9 3v2 M15 3v2 M9 19v2 M15 19v2 M3 9h2 M3 15h2 M19 9h2 M19 15h2 M7 7h10v10H7z M10 10h4v4h-4z",
  setup: "M12 3v3 M12 18v3 M3 12h3 M18 12h3 M5.6 5.6l2.1 2.1 M16.3 16.3l2.1 2.1 M5.6 18.4l2.1-2.1 M16.3 7.7l2.1-2.1 M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z",
  search: "M16 10a6 6 0 1 1-12 0 6 6 0 0 1 12 0ZM14.5 14.5 21 21",
  arrow: "M5 12h14 M14 7l5 5-5 5",
  external: "M14 3h7v7 M21 3 10 14 M10 3H3v18h18v-7",
  check: "M5 12l4 4L19 6",
  plus: "M12 5v14 M5 12h14",
  close: "m6 6 12 12 M6 18 18 6",
  refresh: "M20 7a9 9 0 1 0 1 9 M20 2v6h-6",
  shield: "M12 2 3 6v6c0 5 9 10 9 10s9-5 9-10V6z M8 12l3 3 5-6",
  pause: "M8 5v14 M16 5v14",
  download: "M12 3v12 M7 10l5 5 5-5 M4 16v5h16v-5",
  upload: "M12 16V4 M7 9l5-5 5 5 M4 16v5h16v-5",
  location: "M19 9c0 6-7 12-7 12S5 15 5 9a7 7 0 1 1 14 0ZM14 9a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z",
  info: "M12 11v6 M12 7h.01 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0Z",
  copy: "M8 8h13v13H8z M16 8V3H3v13h5",
} as const;

export function Icon({ name, size = 18 }: { name: keyof typeof paths; size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name]} /></svg>;
}

export function Badge({ children, tone = "neutral" }: { children: ReactNode; tone?: "neutral" | "positive" | "warning" | "danger" }) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}

export function Notice({ children, tone = "info" }: { children: ReactNode; tone?: "info" | "warning" | "danger" }) {
  return <div className={`notice notice-${tone}`}><Icon name="info" /><div>{children}</div></div>;
}

export function ExternalLink({ href, children, className = "text-link" }: { href: string; children: ReactNode; className?: string }) {
  const url = safeUrl(href);
  if (!url) return <span className="muted">Destination unavailable</span>;
  return <a className={className} href={url} target="_blank" rel="noopener noreferrer">{children}<Icon name="external" size={14} /><span className="sr-only"> (opens in a new tab)</span></a>;
}

export function EmptyState({ icon = "opportunities", title, children, action }: { icon?: keyof typeof paths; title: string; children: ReactNode; action?: ReactNode }) {
  return <div className="empty-state"><div className="empty-illustration"><Icon name={icon} size={32} /></div><h2>{title}</h2><p>{children}</p>{action && <div className="empty-actions">{action}</div>}</div>;
}

export function PackageDownloads() {
  return <div className="package-downloads"><div className="button-row">
    <a className="button primary" href="/api/downloads/windows" download><Icon name="download" />Windows app ZIP</a>
    <a className="button secondary" href="/api/downloads/extension" download><Icon name="download" />Chrome extension ZIP</a>
    <a className="button secondary" href="/api/downloads/local" download><Icon name="download" />Local app ZIP</a>
  </div><p className="small muted">ZIP archives, not one-click installers. The Windows x64 folder includes Node.js, Chrome and runtime dependencies: extract all files, then open Chairman/Start Chairman.cmd. No first-launch package installation is needed. Job sites, sign-in and hosted AI still need internet.</p></div>;
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: (id: string) => ReactNode }) {
  const id = useId();
  return <div className="field"><label htmlFor={id}>{label}</label>{children(id)}{hint && <span className="field-hint">{hint}</span>}</div>;
}

export function RecordEditor({ value, onChange, title, disabled = false }: { value: Record<string, string>; onChange: (value: Record<string, string>) => void; title: string; disabled?: boolean }) {
  const [key, setKey] = useState("");
  const [error, setError] = useState("");
  function add() {
    const trimmed = key.trim();
    if (!trimmed) { setError("Enter a label first."); return; }
    if (Object.hasOwn(value, trimmed)) { setError("That label already exists. Edit its answer below."); return; }
    if (["__proto__", "constructor", "prototype"].includes(trimmed)) { setError("Choose a different label."); return; }
    onChange({ ...value, [trimmed]: "" });
    setKey("");
    setError("");
  }
  return <div className="record-editor">
    {Object.entries(value).map(([label, text]) => <div className="record-row" key={label}>
      <Field label={label}>{(id) => <textarea id={id} rows={2} value={text} disabled={disabled} onChange={(event) => onChange({ ...value, [label]: event.target.value })} />}</Field>
      <button type="button" className="button-icon" disabled={disabled} aria-label={`Remove ${label}`} onClick={() => { const next = { ...value }; delete next[label]; onChange(next); }}><Icon name="close" /></button>
    </div>)}
    <div className="inline-form">
      <Field label={`New ${title} label`}>{(id) => <input id={id} value={key} disabled={disabled} onChange={(event) => setKey(event.target.value)} placeholder={title === "answer" ? "e.g. notice_period_days" : "e.g. LinkedIn"} onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); add(); } }} />}</Field>
      <button type="button" className="button secondary" disabled={disabled} onClick={add}><Icon name="plus" />Add {title}</button>
    </div>
    {error && <p className="field-error" role="alert">{error}</p>}
  </div>;
}
