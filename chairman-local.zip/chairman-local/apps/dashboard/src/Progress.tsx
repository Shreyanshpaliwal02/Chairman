import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { api, post } from "./api";
import { errorMessage, type RunAction, type State } from "./model";
import "./progress-filters.css";
import type { ProgressCompany, ProgressStatus, ProgressView } from "../../../packages/domain/progress";
import type { RoleFamily } from "../../../packages/domain/role-families";
import { Badge, EmptyState, ExternalLink, Field, Icon, Notice } from "./ui";

const STATUS: Record<ProgressStatus, { label: string; tone: "neutral" | "positive" | "warning" | "danger" }> = {
  needs_you: { label: "Needs you", tone: "warning" }, in_progress: { label: "In progress", tone: "neutral" }, not_applied: { label: "Not applied", tone: "neutral" },
  applied: { label: "Applied ✓", tone: "positive" }, marked: { label: "Marked by you · not verified", tone: "warning" }, failed: { label: "Failed", tone: "danger" },
  not_relevant: { label: "Not relevant", tone: "neutral" },
};
const ORDER: ProgressStatus[] = ["needs_you", "in_progress", "not_applied", "marked", "applied", "failed", "not_relevant"];
type Filter = ProgressStatus | "all" | "relevant";
const SLOTS = [1, 2, 3, 4, 5, 6, 7, 8];
const list = (text: string) => text.split(/[,\n]/).map(item => item.trim()).filter(Boolean);
const when = (value?: string) => value ? new Date(value).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" }) : "—";
const FILTER_STORAGE = "chairman.progressFilters";
interface ProgressFilters { country: string; role: string; years: string; category: string }
const ANY_FILTERS: ProgressFilters = { country: "", role: "", years: "", category: "" };
const normalizeText = (text: string) => text.toLocaleLowerCase().trim();
const countryValue = (country: string) => `country:${country}`;
const parseProgressFilters = (value: unknown): ProgressFilters => {
  if (!value || typeof value !== "object") return { ...ANY_FILTERS };
  const input = value as Partial<Record<keyof ProgressFilters, unknown>>;
  return {
    country: typeof input.country === "string" ? input.country : "",
    role: typeof input.role === "string" ? input.role : "",
    years: typeof input.years === "string" ? input.years : "",
    category: typeof input.category === "string" ? input.category : "",
  };
};
const storedProgressFilters = (): ProgressFilters => {
  try { return parseProgressFilters(JSON.parse(window.localStorage.getItem(FILTER_STORAGE) ?? "null")); }
  catch { return { ...ANY_FILTERS }; }
};
const filtersActive = (filters: ProgressFilters) => !!(filters.country || filters.role.trim() || filters.years || filters.category);

export function Progress({ state, visible, busy, run }: { state: State; visible: boolean; busy: boolean; run: RunAction }) {
  const [view, setView] = useState<ProgressView | null>(null);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState<Filter>("relevant");
  const [progressFilters, setProgressFilters] = useState<ProgressFilters>(() => storedProgressFilters());
  const load = useCallback(async () => {
    try {
      const next = await api<ProgressView>("/api/progress");
      if (!next || !Array.isArray(next.companies) || !Array.isArray(next.families) || !next.totals) throw new Error("The local service did not return Progress.");
      setView(next); setError("");
    } catch (cause) { setError(errorMessage(cause)); }
  }, []);
  useEffect(() => {
    if (!visible) return;
    void load();
    const timer = window.setInterval(() => { if (document.visibilityState === "visible") void load(); }, 10_000);
    return () => window.clearInterval(timer);
  }, [visible, load]);
  useEffect(() => { window.localStorage.setItem(FILTER_STORAGE, JSON.stringify(progressFilters)); }, [progressFilters]);
  const act: RunAction = (label, action, success) => run(label, async () => { await action(); await load(); }, success);
  const allJobs = useMemo(() => view?.companies.flatMap(company => company.jobs) ?? [], [view]);
  const countryOptions = useMemo(() => [...new Set(allJobs.flatMap(job => job.countries))].sort((a, b) => a.localeCompare(b)), [allJobs]);
  const hasProgressFilters = filtersActive(progressFilters);
  const companyRows = useMemo(() => {
    if (!view) return { rows: [] as { entry: ProgressCompany; jobs: ProgressCompany["jobs"] }[], shown: 0, total: 0, hidden: 0 };
    const roleNeedle = normalizeText(progressFilters.role);
    const matchesStatus = (job: ProgressCompany["jobs"][number]) => filter === "all" ? true : filter === "relevant" ? job.status !== "not_relevant" : job.status === filter;
    const matchesCountry = (job: ProgressCompany["jobs"][number]) => {
      if (!progressFilters.country) return true;
      if (progressFilters.country === "__remote") return job.remote;
      if (progressFilters.country === "__none") return !job.countries.length;
      return progressFilters.country.startsWith("country:") && job.countries.includes(progressFilters.country.slice("country:".length));
    };
    const matchesRole = (job: ProgressCompany["jobs"][number]) => !roleNeedle || normalizeText(`${job.title} ${job.department ?? ""}`).includes(roleNeedle);
    const matchesYears = (job: ProgressCompany["jobs"][number]) => {
      const min = job.yearsRequired?.min;
      if (!progressFilters.years) return true;
      if (progressFilters.years === "fits") return view.candidateYears === undefined ? true : min === undefined || min <= view.candidateYears + 1;
      if (progressFilters.years === "not-stated") return min === undefined;
      if (min === undefined) return false;
      if (progressFilters.years === "0-2") return min <= 2;
      if (progressFilters.years === "3-5") return min >= 3 && min <= 5;
      if (progressFilters.years === "6-9") return min >= 6 && min <= 9;
      if (progressFilters.years === "10-plus") return min >= 10;
      return true;
    };
    const matchesCategory = (job: ProgressCompany["jobs"][number]) => {
      if (!progressFilters.category) return true;
      if (progressFilters.category === "__none") return !job.classification.familyId;
      return job.classification.familyId === progressFilters.category;
    };
    let shown = 0, total = 0, hidden = 0;
    const rows = view.companies.flatMap(entry => {
      const statusJobs = entry.jobs.filter(matchesStatus);
      total += statusJobs.length;
      const jobs = statusJobs.filter(job => matchesCountry(job) && matchesRole(job) && matchesYears(job) && matchesCategory(job));
      shown += jobs.length;
      if (hasProgressFilters && !jobs.length) { hidden++; return []; }
      return [{ entry, jobs }];
    });
    return { rows, shown, total, hidden };
  }, [filter, hasProgressFilters, progressFilters, view]);
  const updateProgressFilters = (patch: Partial<ProgressFilters>) => setProgressFilters(current => ({ ...current, ...patch }));

  if (error && !view) return <Notice tone="warning"><strong>Progress is unavailable.</strong> {error} Restart the updated local service, then refresh.</Notice>;
  if (!view) return <p className="quiet-empty">Loading your companies…</p>;
  const totals = view.totals;
  return <div className="progress-page">
    <div className="stats-strip progress-totals">
      <div><span>Applied</span><strong>{totals.applied}</strong><small>Proven by the employer's confirmation page, a receipt or your recorded confirmation{totals.marked ? ` · ${totals.marked} marked by you, not verified` : ""}</small></div>
      <div><span>In progress</span><strong>{totals.in_progress}</strong><small>Being filled, or submitted with an unverified outcome</small></div>
      <div><span>Needs you</span><strong>{totals.needs_you}</strong><small>CAPTCHA or questions in a parked tab</small></div>
      <div><span>Not applied</span><strong>{totals.not_applied}</strong><small>Relevant roles not started yet · {totals.not_relevant} not relevant</small></div>
    </div>
    {!!state.autopilot && !state.autopilot.enabled && <Notice>Auto Apply is paused, so relevant roles stay <strong>Not applied</strong>. Activate it in Auto Apply after reviewing companies, role families and answers.</Notice>}
    <SuggestedCompanies busy={busy} act={act} />
    <AddCompany families={view.families} busy={busy} act={act} />
    <section className="form-section"><div className="section-heading"><div><h2>Companies</h2><p>Each company's career page is checked on a schedule. Relevant roles (by role family and keywords) are applied to automatically; everything else is listed as not relevant.</p></div>
      <Field label="Show">{id => <select id={id} value={filter} onChange={event => setFilter(event.target.value as Filter)}><option value="relevant">Relevant roles</option><option value="all">All roles</option>{ORDER.map(status => <option key={status} value={status}>{STATUS[status].label}</option>)}</select>}</Field></div>
      <div className="progress-filter-bar" aria-label="Progress table filters">
        <Field label="Country">{id => <select id={id} value={progressFilters.country} onChange={event => updateProgressFilters({ country: event.target.value })}>
          <option value="">Any country</option>{countryOptions.map(country => <option key={country} value={countryValue(country)}>{country}</option>)}
          <option value="__remote">Remote (any country)</option><option value="__none">Not stated</option>
        </select>}</Field>
        <Field label="Role">{id => <input id={id} value={progressFilters.role} placeholder="Search title or department" onChange={event => updateProgressFilters({ role: event.target.value })} />}</Field>
        <Field label="Years of experience">{id => <select id={id} value={progressFilters.years === "fits" && view.candidateYears === undefined ? "" : progressFilters.years} onChange={event => updateProgressFilters({ years: event.target.value })}>
          <option value="">Any</option>{view.candidateYears !== undefined && <option value="fits">Fits my experience</option>}<option value="0-2">0–2</option><option value="3-5">3–5</option><option value="6-9">6–9</option><option value="10-plus">10+</option><option value="not-stated">Not stated</option>
        </select>}</Field>
        <Field label="Category">{id => <select id={id} value={progressFilters.category} onChange={event => updateProgressFilters({ category: event.target.value })}>
          <option value="">Any category</option>{view.families.map(family => <option key={family.id} value={family.id}>{family.label}</option>)}<option value="__none">Not in a role family</option>
        </select>}</Field>
        <button type="button" className="button secondary progress-clear-filters" disabled={!hasProgressFilters} onClick={() => setProgressFilters({ ...ANY_FILTERS })}>Clear filters</button>
      </div>
      {hasProgressFilters && <p className="small muted progress-filter-summary" aria-live="polite">Showing {companyRows.shown} of {companyRows.total} roles · {companyRows.hidden} companies hidden</p>}
      {!view.companies.length ? <EmptyState icon="opportunities" title="No companies yet">Add a company and its careers page above. Chairman finds its open roles and tracks every application here.</EmptyState>
        : companyRows.rows.map(({ entry, jobs }) => <CompanyCard key={entry.source.id} entry={entry} jobs={jobs} families={view.families} busy={busy} act={act} />)}
      {!!view.manual?.length && <div className="manual-companies"><h3>Check these yourself</h3><p className="small muted">No public job board to crawl; open their careers pages when you plan your day.</p>
        <ul>{view.manual.map(entry => <li key={entry.name}><ExternalLink href={entry.careersUrl}>{entry.name}</ExternalLink>{entry.notes && <span className="small muted"> · {entry.notes}</span>}
          <button className="button text-button compact" disabled={busy} onClick={() => void act(`Removing ${entry.name}…`, async () => { await post("/api/companies/manual/remove", { name: entry.name }); }, `${entry.name} removed.`)}>Remove</button></li>)}</ul></div>}
    </section>
    <RoleFamilies families={view.families} variants={state.resumeVariants ?? []} busy={busy} act={act} />
  </div>;
}

interface CatalogEntry { name: string; group: string; careersUrl: string; board?: string; notes?: string; crawlable: boolean; added: boolean }
function SuggestedCompanies({ busy, act }: { busy: boolean; act: RunAction }) {
  const [companies, setCompanies] = useState<CatalogEntry[] | null>(null);
  const load = useCallback(async () => { try { setCompanies((await api<{ companies: CatalogEntry[] }>("/api/companies/catalog")).companies); } catch { setCompanies([]); } }, []);
  useEffect(() => { void load(); }, [load]);
  if (!companies?.length) return null;
  const missing = companies.filter(entry => !entry.added);
  const add = (names: string[], label: string) => void act(label, async () => { await post("/api/companies/catalog/add", { names }); await load(); },
    `${names.length === 1 ? names[0] : `${names.length} companies`} added. Their boards are crawled one by one in the background (about a minute each); roles appear here and in Today.`);
  return <section className="form-section" id="suggested-companies"><div className="section-heading"><div><h2>Suggested companies</h2>
    <p>Your target list with each company's verified public job board. {companies.filter(entry => entry.crawlable).length} are crawled automatically; the rest have no public board, so they are listed for you to check.</p></div>
    <Badge tone={missing.length ? "warning" : "positive"}>{companies.length - missing.length} / {companies.length} added</Badge></div>
    {!!missing.length && <div className="button-row"><button className="button primary" disabled={busy} onClick={() => add(missing.map(entry => entry.name), `Adding ${missing.length} companies…`)}><Icon name="plus" />Add all {missing.length}</button></div>}
    <details className="form-disclosure"><summary>Companies <span>{missing.length ? `${missing.length} not added yet` : "all added"}</span></summary>
      <ul className="catalog-list">{companies.map(entry => <li key={entry.name}>
        <div><strong>{entry.name}</strong> <span className="small muted">{entry.crawlable ? new URL(entry.board!).hostname : "check yourself"}</span>{entry.notes && <div className="small muted">{entry.notes}</div>}</div>
        {entry.added ? <Badge tone="positive">Added</Badge> : <button className="button secondary compact" disabled={busy} onClick={() => add([entry.name], `Adding ${entry.name}…`)}>Add</button>}
      </li>)}</ul>
    </details>
  </section>;
}

function AddCompany({ families, busy, act }: { families: RoleFamily[]; busy: boolean; act: RunAction }) {
  const [company, setCompany] = useState(""), [url, setUrl] = useState(""), [picked, setPicked] = useState<string[]>([]);
  const always = families.filter(family => family.alwaysApply), optional = families.filter(family => !family.alwaysApply);
  async function submit(event: FormEvent) {
    event.preventDefault();
    const ok = await act(`Adding ${company}…`, async () => { await post("/api/companies", { url: url.trim(), company: company.trim(), roleFamilies: picked }); },
      `${company.trim()} added. Its careers page is resolved and scanned in the background; relevant roles appear below. Changing companies pauses Auto Apply until you activate it again.`);
    if (ok) { setCompany(""); setUrl(""); setPicked([]); }
  }
  return <section className="form-section" id="add-company"><h2>Add a company</h2>
    <form className="add-company" onSubmit={event => void submit(event)}>
      <div className="form-grid">
        <Field label="Company">{id => <input id={id} required maxLength={120} value={company} disabled={busy} placeholder="e.g. Confluent" onChange={event => setCompany(event.target.value)} />}</Field>
        <Field label="Careers page URL" hint="A company careers page or job board (Greenhouse, Lever, Ashby, Workable…).">{id => <input id={id} required type="url" value={url} disabled={busy} placeholder="https://jobs.ashbyhq.com/confluent" onChange={event => setUrl(event.target.value)} />}</Field>
      </div>
      <fieldset className="family-picker" disabled={busy}><legend>Roles to apply for here</legend>
        {always.map(family => <label className="checkbox-label" key={family.id}><input type="checkbox" checked disabled />{family.label} <span className="small muted">· always</span></label>)}
        {optional.map(family => <label className="checkbox-label" key={family.id}><input type="checkbox" checked={picked.includes(family.id)} onChange={event => setPicked(event.target.checked ? [...picked, family.id] : picked.filter(id => id !== family.id))} />{family.label}</label>)}
      </fieldset>
      <button className="button primary" type="submit" disabled={busy || !company.trim() || !url.trim()}><Icon name="plus" />Add company</button>
    </form></section>;
}

function CompanyCard({ entry, jobs, families, busy, act }: { entry: ProgressCompany; jobs: ProgressCompany["jobs"]; families: RoleFamily[]; busy: boolean; act: RunAction }) {
  const [editing, setEditing] = useState(false), [picked, setPicked] = useState(entry.roleFamilies);
  useEffect(() => { if (!editing) setPicked(entry.roleFamilies); }, [entry.roleFamilies, editing]);
  const { source } = entry, name = entry.company;
  const labels = families.filter(family => family.alwaysApply || entry.roleFamilies.includes(family.id)).map(family => family.label);
  return <article className="company-card" aria-label={name}>
    <div className="section-heading"><div><h3>{name}</h3>
      <p className="small muted"><ExternalLink href={source.target?.boardUrl ?? source.inputUrl}>{source.target?.provider ? `${source.target.provider} board` : "Careers page"}</ExternalLink> · {source.enabled ? source.status : "paused"} · last checked {when(source.lastScannedAt)}{source.message ? ` · ${source.message}` : ""}</p>
      <p className="small">Applying for: {labels.join(", ") || "no role families"}</p></div>
      <div className="button-row">
        <button className="button secondary compact" disabled={busy || !source.enabled} onClick={() => void act(`Checking ${name}…`, async () => { await post(`/api/career-links/${encodeURIComponent(source.id)}/scan`, {}); }, `${name} is being checked for new roles.`)}><Icon name="refresh" size={16} />Check now</button>
        <button className="button text-button compact" disabled={busy} onClick={() => setEditing(!editing)}>{editing ? "Close" : "Edit roles"}</button>
        <button className="button text-button compact" disabled={busy} onClick={() => void act(source.enabled ? `Pausing ${name}…` : `Resuming ${name}…`, async () => { await post(`/api/career-links/${encodeURIComponent(source.id)}/enabled`, { enabled: !source.enabled }); }, source.enabled ? `${name} paused; it is no longer checked.` : `${name} resumed.`)}>{source.enabled ? "Pause" : "Resume"}</button>
        <button className="button text-button danger-text compact" disabled={busy} onClick={() => { if (window.confirm(`Remove ${name}? Its tracked applications stay in Applications; it is no longer checked.`)) void act(`Removing ${name}…`, async () => { await post(`/api/career-links/${encodeURIComponent(source.id)}/remove`, {}); }, `${name} removed.`); }}>Remove</button>
      </div></div>
    <div className="company-meta">
      <Field label="Sponsors visas for roles abroad?" hint="Used when a posting does not say. Postings that say so always win.">{id => <select id={id} value={source.sponsorsVisas === undefined ? "" : source.sponsorsVisas ? "yes" : "no"} disabled={busy}
        onChange={event => void act(`Saving ${name}…`, async () => { await post(`/api/companies/${encodeURIComponent(source.id)}`, { sponsorsVisas: event.target.value === "" ? null : event.target.value === "yes" }); }, `Saved. Today's list uses it the next time it is built.`)}>
        <option value="">Not sure</option><option value="yes">Yes, it sponsors</option><option value="no">No sponsorship</option></select>}</Field>
      {source.crawl && <p className="small muted">Last crawl: {source.crawl.listed} open roles, {source.crawl.relevant} in your role families{source.crawl.closed ? `, ${source.crawl.closed} closed since` : ""}{source.crawl.truncated ? " (large board: searched by your keywords)" : ""}.</p>}
    </div>
    <div className="tag-group progress-counts">{ORDER.filter(status => entry.counts[status]).map(status => <Badge key={status} tone={STATUS[status].tone}>{STATUS[status].label} · {entry.counts[status]}</Badge>)}{!entry.counts.total && <span className="small muted">No roles found yet.</span>}</div>
    {editing && <fieldset className="family-picker" disabled={busy}><legend>Roles to apply for at {name}</legend>
      {families.map(family => <label className="checkbox-label" key={family.id}><input type="checkbox" checked={family.alwaysApply || picked.includes(family.id)} disabled={family.alwaysApply} onChange={event => setPicked(event.target.checked ? [...picked, family.id] : picked.filter(id => id !== family.id))} />{family.label}{family.alwaysApply && <span className="small muted"> · always</span>}</label>)}
      <button className="button secondary compact" type="button" onClick={() => void act(`Saving roles for ${name}…`, async () => { await post(`/api/companies/${encodeURIComponent(source.id)}`, { roleFamilies: picked }); setEditing(false); }, `Roles for ${name} saved. Auto Apply needs activation again for the new scope.`)}>Save roles</button>
    </fieldset>}
    {!!jobs.length && <div className="application-table-wrap" tabIndex={0} role="region" aria-label={`${name} roles`}><table className="application-table progress-table">
      <thead><tr><th>Role</th><th>Family & match</th><th>Status</th><th>Details</th><th>Updated</th></tr></thead>
      <tbody>{jobs.slice(0, 200).map(job => <tr key={job.jobId}>
        <td><ExternalLink href={job.applyUrl}>{job.title}</ExternalLink><div className="small muted">{job.location}</div></td>
        <td>{job.classification.familyLabel ?? "—"}<div className="small muted">{job.classification.relevant ? job.classification.matchedSkills.slice(0, 6).join(", ") || "Title match" : job.classification.reason}</div></td>
        <td><Badge tone={STATUS[job.status].tone}>{STATUS[job.status].label}</Badge></td>
        <td>{job.detail}{job.resume && <div className="small muted">Resume: {job.resume}</div>}{job.channel && <div className="small muted">Via {job.channel.replace("_", " ")}</div>}</td>
        <td className="small">{when(job.updatedAt ?? job.fetchedAt)}</td>
      </tr>)}</tbody></table></div>}
    {!!entry.jobs.length && !jobs.length && <p className="small muted">No roles match this filter.</p>}
  </article>;
}

function RoleFamilies({ families, variants, busy, act }: { families: RoleFamily[]; variants: NonNullable<State["resumeVariants"]>; busy: boolean; act: RunAction }) {
  const [draft, setDraft] = useState(families), [dirty, setDirty] = useState(false);
  useEffect(() => { if (!dirty) setDraft(families); }, [families, dirty]);
  const change = (index: number, patch: Partial<RoleFamily>) => { setDraft(current => current.map((family, at) => at === index ? { ...family, ...patch } : family)); setDirty(true); };
  const slug = (label: string) => label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48) || "family";
  function add() {
    const taken = new Set(draft.map(family => family.id));
    let id = "new-family", n = 2; while (taken.has(id)) id = `new-family-${n++}`;
    setDraft([...draft, { id, label: "New role family", titleKeywords: [], skillKeywords: [], excludeKeywords: ["intern", "sales"], alwaysApply: false, minSkillMatches: 1 }]); setDirty(true);
  }
  return <section className="form-section" id="role-families"><div className="section-heading"><div><h2>Role families & resumes</h2>
    <p>A job belongs to a family when its title contains one of the family's title keywords (and no exclusion), and its description has enough skill keywords. "Always apply" families are applied to at every company. Each family sends its own resume slot, so data, cloud or AI roles get the right resume.</p></div>
    <Badge tone={dirty ? "warning" : "neutral"}>{dirty ? "Unsaved changes" : `${families.length} families`}</Badge></div>
    <div className="family-list">{draft.map((family, index) => <details className="family-editor" key={index}>
      <summary><strong>{family.label || "Role family"}</strong> <span className="small muted">{family.alwaysApply ? "always apply · " : "picked per company · "}{family.resumeSlot ? `resume slot ${family.resumeSlot}` : "best matching resume"} · {family.titleKeywords.length} title keywords</span></summary>
      <fieldset disabled={busy}>
      <div className="form-grid three-columns">
        <Field label="Name">{id => <input id={id} value={family.label} maxLength={80} onChange={event => change(index, { label: event.target.value, ...(families.some(existing => existing.id === family.id) ? {} : { id: slug(event.target.value) }) })} />}</Field>
        <Field label="Resume slot" hint="Upload resumes in Auto Apply → slots 1–8.">{id => <select id={id} value={family.resumeSlot ?? ""} onChange={event => change(index, { resumeSlot: event.target.value ? Number(event.target.value) : undefined })}>
          <option value="">Best matching approved resume</option>{SLOTS.map(slot => { const variant = variants.find(item => item.slot === slot); return <option key={slot} value={slot}>Slot {slot}{variant ? ` · ${variant.label}${variant.approved ? "" : " (not approved)"}` : " · empty"}</option>; })}</select>}</Field>
        <Field label="Minimum skill matches" hint="0 means a title match is enough.">{id => <input id={id} type="number" min={0} max={20} value={family.minSkillMatches} onChange={event => change(index, { minSkillMatches: Math.max(0, Math.min(20, Number(event.target.value) || 0)) })} />}</Field>
      </div>
      <KeywordField label="Title keywords" hint="Whole words in the job title, e.g. data engineer, analytics engineer." value={family.titleKeywords} onChange={titleKeywords => change(index, { titleKeywords })} />
      <KeywordField label="Skill keywords" hint="Looked for in the job description to rank relevance." value={family.skillKeywords} onChange={skillKeywords => change(index, { skillKeywords })} />
      <KeywordField label="Exclude when the title contains" value={family.excludeKeywords} onChange={excludeKeywords => change(index, { excludeKeywords })} />
      <div className="button-row"><label className="checkbox-label"><input type="checkbox" checked={family.alwaysApply} onChange={event => change(index, { alwaysApply: event.target.checked })} />Always apply to this family at every company</label>
        <button type="button" className="button text-button danger-text compact" disabled={draft.length <= 1} onClick={() => { setDraft(draft.filter((_, at) => at !== index)); setDirty(true); }}>Remove family</button></div>
      </fieldset></details>)}</div>
    <div className="button-row">
      <button type="button" className="button secondary" disabled={busy || draft.length >= 20} onClick={add}><Icon name="plus" />Add role family</button>
      <button type="button" className="button primary" disabled={busy || !dirty} onClick={() => void act("Saving role families…", async () => { await post("/api/role-families", { families: draft }); setDirty(false); }, "Role families saved. Relevance is recalculated for every tracked role; activate Auto Apply again for the new scope.")}>Save role families</button>
      {dirty && <button type="button" className="button text-button" disabled={busy} onClick={() => { setDraft(families); setDirty(false); }}>Discard changes</button>}
      <button type="button" className="button text-button" disabled={busy} onClick={() => { if (window.confirm("Replace your role families with the defaults (data, cloud, cloud platform, software, AI/ML, forward deployed)?")) void act("Restoring default role families…", async () => { await post("/api/role-families/reset", {}); setDirty(false); }, "Default role families restored."); }}>Restore defaults</button>
    </div>
  </section>;
}

function KeywordField({ label, hint, value, onChange }: { label: string; hint?: string; value: string[]; onChange: (value: string[]) => void }) {
  const [text, setText] = useState(value.join(", "));
  useEffect(() => { if (JSON.stringify(list(text)) !== JSON.stringify(value)) setText(value.join(", ")); }, [value]);
  return <Field label={label} hint={hint ?? "Separate with commas or new lines."}>{id => <textarea id={id} rows={2} value={text} onChange={event => { setText(event.target.value); onChange(list(event.target.value)); }} />}</Field>;
}
