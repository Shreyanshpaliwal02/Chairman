import { useCallback, useEffect, useMemo, useState } from "react";
import { api, post } from "./api";
import { errorMessage, type RunAction, type State } from "./model";
import { InferenceSettings } from "./InferenceSettings";
import { Badge, Field, Notice } from "./ui";
import type { InferenceModelInventory, InferenceTestResult } from "../../local/inference-routes";
import "./ai-page.css";

const LOGIN = "npm exec --package=@github/copilot -- copilot login";

/** The AI Chairman uses: what it is used for, the models your account offers, sign-in, the model choice and a test. */
export function AiPage({ state, visible, busy, run }: { state: State; visible: boolean; busy: boolean; run: RunAction }) {
  const ai = state.runtime.ai;
  const provider = ai.provider ?? "copilot";
  const [inventory, setInventory] = useState<InferenceModelInventory | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [pick, setPick] = useState<{ model: string; at: number }>();
  const [custom, setCustom] = useState("");
  const [test, setTest] = useState<InferenceTestResult | null>(null);
  const [copied, setCopied] = useState(false);
  const load = useCallback(async (refresh = false) => {
    setLoading(true);
    try { setInventory(await api<InferenceModelInventory>(`/api/inference/models?provider=${provider}${refresh ? "&refresh=1" : ""}`)); setError(""); }
    catch (cause) { setError(errorMessage(cause)); }
    finally { setLoading(false); }
  }, [provider]);
  useEffect(() => { if (visible) void load(); }, [visible, load]);
  const models = useMemo(() => [...(inventory?.models ?? [])].sort((a, b) => Number(b.enabled) - Number(a.enabled) || a.id.localeCompare(b.id)), [inventory]);
  const choose = (model: string) => { setPick({ model, at: Date.now() }); document.getElementById("inference-title")?.scrollIntoView({ behavior: "smooth", block: "start" }); };
  return <div className="ai-page">
    <section className="setup-section" aria-labelledby="ai-uses-title">
      <div className="section-heading"><div><h2 id="ai-uses-title">What Chairman uses AI for</h2>
        <p>Your saved answers, your profile and your confirmed work history always come first. AI is asked only for what they do not cover.</p></div>
        <Badge tone={ai.available ? "positive" : "warning"}>{ai.available ? `Ready · ${ai.model}` : "Not ready"}</Badge></div>
      <ul className="ai-uses">
        <li><strong>Form questions with no saved answer:</strong> it reads the question, the job and your confirmed facts, then answers or drafts (for example "Why this company?"). AI answers are highlighted for your review before you submit.</li>
        <li><strong>Unusual wordings:</strong> it matches them to answers you saved ("Are you open to working in one of our offices?" → your onsite answer). The value still comes from your saved answer.</li>
        <li><strong>Resume tailoring</strong> for a specific job, from your confirmed facts only.</li>
        <li><strong>Never</strong> for passwords or codes, demographic or voluntary self-identification questions, or the values of visa, work-authorization and background questions: those come only from what you saved in Profile.</li>
      </ul>
    </section>
    <section className="setup-section" aria-labelledby="ai-models-title">
      <div className="section-heading"><div><h2 id="ai-models-title">Models available to you</h2>
        <p>{provider === "copilot" ? "The models your GitHub Copilot account can use through the SDK." : provider === "ollama" ? "Models installed in your local Ollama." : "Gemini models reviewed for free-tier use."}</p></div>
        <button className="button secondary" type="button" disabled={busy || loading} onClick={() => void run("Checking AI sign-in and models…", async () => { await post("/api/inference/refresh", {}); await load(true); }, undefined)}>Check again</button></div>
      {provider === "copilot" && inventory?.signedIn === false && <Notice tone="warning">
        <strong>Sign in to GitHub once.</strong> If you use the GitHub CLI, <code>gh auth login</code> is enough (Chairman uses the gh you installed, never this chat app's own). Otherwise, in Terminal, run <code>{LOGIN}</code>{" "}
        <button className="button text-button compact" type="button" onClick={() => void navigator.clipboard.writeText(LOGIN).then(() => setCopied(true)).catch(() => setCopied(false))}>{copied ? "Copied" : "Copy"}</button>
        , choose GitHub.com, and sign in in your browser with the account whose Copilot plan Chairman should use. Then press <strong>Check again</strong>. Chairman never sees your password or token.
      </Notice>}
      {error && <Notice tone="warning">{error}</Notice>}
      {models.length ? <ul className="model-list">{models.map(model => <li key={model.id}>
        <div><strong>{model.name ?? model.id}</strong> <code>{model.id}</code>{model.multiplier !== undefined && <span className="small muted"> · {model.multiplier}× premium requests</span>}</div>
        {model.id === ai.model ? <Badge tone="positive">In use</Badge>
          : <button className="button text-button compact" type="button" disabled={busy || !model.enabled} onClick={() => choose(model.id)}>{model.enabled ? "Use this model" : model.state ? `Not available (${model.state})` : "Not available"}</button>}
      </li>)}</ul> : <p className="quiet-empty">{loading ? "Loading models…" : inventory?.reason && inventory.signedIn !== false ? inventory.reason : inventory?.signedIn === false ? "Sign in to list your models." : "No models listed yet."}</p>}
      <form className="model-custom" onSubmit={event => { event.preventDefault(); if (custom.trim()) choose(custom.trim()); }}>
        <Field label="A newer model that is not listed yet? Enter its exact ID" hint="For example a model your plan just added. Chairman checks your account can use exactly this model and never falls back to another.">{id =>
          <input id={id} value={custom} autoComplete="off" spellCheck={false} placeholder="exact model ID" onChange={event => setCustom(event.target.value)} />}</Field>
        <button className="button secondary" type="submit" disabled={busy || !custom.trim()}>Use this model ID</button>
      </form>
      <p className="small muted">Choosing a model fills it in below. Save it there with your consent; nothing changes until you do.</p>
    </section>
    <InferenceSettings ai={ai} busy={busy} run={run} pick={pick} />
    <section className="setup-section" aria-labelledby="ai-test-title">
      <div className="section-heading"><div><h2 id="ai-test-title">Test the saved model</h2><p>Sends one fixed question that contains nothing about you, and shows the answer and how long it took.</p></div>
        <button className="button secondary" type="button" disabled={busy} onClick={() => void run("Sending a test question…", async () => { setTest(await post<InferenceTestResult>("/api/inference/test", {})); }, undefined)}>Send a test question</button></div>
      {test && (test.ok ? <Notice><strong>{test.model}</strong> answered in {Math.round(test.ms / 100) / 10} s: {JSON.stringify(test.answer)}. Form questions will use this model.</Notice>
        : <Notice tone="warning"><strong>The test did not work.</strong> {test.error}</Notice>)}
    </section>
  </div>;
}
