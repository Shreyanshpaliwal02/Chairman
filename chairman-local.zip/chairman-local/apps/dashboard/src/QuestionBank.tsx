import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api, post } from "./api";
import { errorMessage, type Profile, type RunAction } from "./model";
import type { BankQuestion, QuestionCategory } from "../../../packages/domain/question-bank";
import type { InboxQuestion } from "../../../packages/domain/progress";
import { Badge, Field, Icon, Notice } from "./ui";

interface BankPreferences { fillVoluntaryDisclosures: boolean; acceptRequiredAcknowledgements: boolean; authorizedCountries: string[]; needsSponsorshipAbroad: boolean }
interface BankView { questions: BankQuestion[]; categories: Record<QuestionCategory, string>; answers: Record<string, string>; inbox: InboxQuestion[]; preferences: BankPreferences }

/** Your answers to standard application questions, filled on every form by the extension and by Auto Apply. */
export function QuestionBank({ profile, profileDirty, busy, run }: { profile: Profile; profileDirty: boolean; busy: boolean; run: RunAction }) {
  const [view, setView] = useState<BankView | null>(null);
  const [error, setError] = useState("");
  const [edits, setEdits] = useState<Record<string, string>>({});
  const [switches, setSwitches] = useState<Partial<BankPreferences>>({});
  const [imported, setImported] = useState<number | null>(null);
  const importInput = useRef<HTMLInputElement>(null);
  const load = useCallback(async () => {
    try {
      const next = await api<BankView>("/api/question-bank");
      if (!next || !Array.isArray(next.questions) || !next.categories || !next.answers || !Array.isArray(next.inbox) || !next.preferences)
        throw new Error("The local service did not return them. Restart the updated local service, then refresh.");
      setView(next); setError("");
    } catch (cause) { setError(errorMessage(cause)); }
  }, []);
  useEffect(() => { void load(); }, [load, profile.version]);
  const dirty = Object.keys(edits).length > 0 || Object.keys(switches).length > 0;
  const act: RunAction = (label, action, success) => run(label, async () => { await action(); await load(); }, success);
  const grouped = useMemo(() => {
    const groups = new Map<QuestionCategory, BankQuestion[]>();
    for (const category of Object.keys(view?.categories ?? {}) as QuestionCategory[]) groups.set(category, []);
    for (const question of view?.questions ?? []) groups.set(question.category, [...(groups.get(question.category) ?? []), question]);
    return new Map([...groups].filter(([, questions]) => questions.length));
  }, [view?.questions, view?.categories]);
  if (error && !view) return <Notice tone="warning"><strong>Standard questions are unavailable.</strong> {error}</Notice>;
  if (!view) return <p className="quiet-empty">Loading standard questions…</p>;
  const value = (key: string) => Object.hasOwn(edits, key) ? edits[key]! : view.answers[key] ?? "";
  const set = (key: string, next: string) => setEdits(current => {
    const copy = { ...current };
    if (next === (view.answers[key] ?? "")) delete copy[key]; else copy[key] = next;
    return copy;
  });
  const preference = (key: keyof BankPreferences) => (Object.hasOwn(switches, key) ? switches[key] : view.preferences[key]) as boolean;
  const answerable = view.questions.filter(question => !question.profileField && !["linkedin", "github"].includes(question.key));
  const answered = answerable.filter(question => (view.answers[question.key] ?? "").trim()).length;
  const locked = busy || profileDirty;

  async function save() {
    await act("Saving your answers…", async () => { await post("/api/question-bank", { answers: edits, preferences: switches }); setEdits({}); setSwitches({}); },
      "Answers saved. They are used on every form from now on. Auto Apply needs activation again because your answers changed.");
  }
  async function importFile(file: File) {
    let body: unknown;
    try { body = JSON.parse(await file.text()); } catch { setError("That file is not valid JSON. Export your answers first to see the expected format."); return; }
    if (!window.confirm(`Import answers from ${file.name}? Matching answers are replaced; answers not in the file are kept.`)) return;
    await act("Importing answers…", async () => {
      const result = await post<{ imported: number }>("/api/question-bank/import", body);
      setError(""); setEdits({}); setSwitches({}); setImported(result.imported);
      if (importInput.current) importInput.current.value = "";
    }, "Answers imported. Review them below; Auto Apply needs activation again.");
  }

  return <section className="form-section question-bank" id="question-bank">
    <div className="section-heading"><div><h2>Standard application questions</h2><p>Answer once. The extension and Auto Apply fill these wherever a form asks, in any wording. Leave a question blank and it waits for you on the form.</p></div>
      <Badge tone={answered === answerable.length ? "positive" : "warning"}>{answered} / {answerable.length} answered</Badge></div>
    {profileDirty && <Notice tone="warning">Save or discard your profile edits above first. The profile is saved as a whole and would overwrite answers saved here.</Notice>}
    <div className="button-row bank-tools">
      <a className="button secondary compact" href="/api/question-bank/export" download><Icon name="download" size={16} />Export answers (JSON)</a>
      <label className="button secondary compact file-label">Import answers (JSON)<input ref={importInput} type="file" accept="application/json,.json" disabled={locked} onChange={event => { const file = event.target.files?.[0]; if (file) void importFile(file); }} /></label>
      <span className="small muted">{imported !== null ? `${imported} answers imported.` : <>Format: {"{"} "answers": {"{"} "notice_period_days": "30", "eeo_gender": "Male" {"}"} {"}"}</>}</span>
    </div>
    {!!view.inbox.length && <details className="form-disclosure" open><summary>Questions from real forms <span>{view.inbox.length} waiting for an answer</span></summary>
      <p className="small muted">Collected from forms Chairman filled; never your values. Answer once and it is reused everywhere.</p>
      <div className="inbox-list">{view.inbox.map(question => <InboxItem key={question.id} question={question} busy={locked} act={act} />)}</div>
    </details>}
    <div className="consent-switches">
      <label className="checkbox-label"><input type="checkbox" checked={preference("fillVoluntaryDisclosures")} disabled={locked} onChange={event => setSwitches({ ...switches, fillVoluntaryDisclosures: event.target.checked })} /><span><strong>Fill my voluntary self-identification answers</strong> (gender, race/ethnicity, veteran, disability, pronouns) from the answers below. Off: those questions are always left for you.</span></label>
      <label className="checkbox-label"><input type="checkbox" checked={preference("acceptRequiredAcknowledgements")} disabled={locked} onChange={event => setSwitches({ ...switches, acceptRequiredAcknowledgements: event.target.checked })} /><span><strong>Accept required acknowledgements in my name.</strong> Chairman ticks required "I agree / acknowledge / certify" boxes, accepts "by submitting you agree" terms, and declines optional marketing (unless you answer marketing_opt_in Yes). Each one is recorded in the application's history. You are agreeing to terms you have not read on each site.</span></label>
    </div>
    {[...grouped.entries()].map(([category, questions]) => {
      const done = questions.filter(question => (view.answers[question.key] ?? "").trim()).length;
      return <details className="form-disclosure bank-category" key={category} open={category === "eligibility" || category === "availability"}>
        <summary>{view.categories[category]} <span>{done} / {questions.length}</span></summary>
        {category === "disclosures" && <Notice>These answers are voluntary. They are sent only when the switch above is on, and only to questions that match exactly (including "I don't wish to answer").</Notice>}
        {category === "eligibility" && <p className="small muted">Work authorization and sponsorship by country come from Profile → Application preferences ("Authorized to work in", sponsorship abroad) plus explicit answers such as needs_sponsorship_US.</p>}
        <div className="bank-grid">{questions.map(question => <BankField key={question.key} question={question} profile={profile} value={value(question.key)} disabled={locked} onChange={next => set(question.key, next)} />)}</div>
      </details>;
    })}
    <div className="button-row">
      <button type="button" className="button primary" disabled={locked || !dirty} onClick={() => void save()}><Icon name="check" />Save answers</button>
      {dirty && <button type="button" className="button text-button" disabled={busy} onClick={() => { setEdits({}); setSwitches({}); }}>Discard</button>}
      {dirty && <span className="small muted">{Object.keys(edits).length} answer change{Object.keys(edits).length === 1 ? "" : "s"}{Object.keys(switches).length ? " · switch changes" : ""}</span>}
    </div>
    {error && <p className="field-error" role="alert">{error}</p>}
  </section>;
}

function BankField({ question, profile, value, disabled, onChange }: { question: BankQuestion; profile: Profile; value: string; disabled: boolean; onChange: (value: string) => void }) {
  const hint = [question.help, question.unit ? `In ${question.unit}.` : ""].filter(Boolean).join(" ") || undefined;
  if (question.profileField) {
    const current = profile[question.profileField];
    return <div className="field bank-readonly"><span className="field-label-text">{question.label}</span><p className="small">{current || <span className="muted">Not set</span>} <span className="muted">· from your profile contact details</span></p></div>;
  }
  if (question.key === "linkedin" || question.key === "github") {
    const link = Object.entries(profile.links).find(([label]) => label.toLowerCase().includes(question.key))?.[1];
    return <div className="field bank-readonly"><span className="field-label-text">{question.label}</span><p className="small">{link || <span className="muted">Add it under Profile links</span>}</p></div>;
  }
  return <Field label={question.label} hint={hint}>{id => {
    if (question.kind === "yesno") return <select id={id} value={value} disabled={disabled} onChange={event => onChange(event.target.value)}><option value="">Not answered</option><option>Yes</option><option>No</option></select>;
    if (question.kind === "choice") return <><input id={id} list={`${id}-choices`} value={value} disabled={disabled} placeholder="Choose or type" onChange={event => onChange(event.target.value)} /><datalist id={`${id}-choices`}>{question.choices?.map(choice => <option key={choice} value={choice} />)}</datalist></>;
    if (question.kind === "textarea") return <textarea id={id} rows={3} value={value} disabled={disabled} onChange={event => onChange(event.target.value)} />;
    return <input id={id} type={question.kind === "number" ? "number" : question.kind === "date" ? "date" : question.kind === "url" ? "url" : "text"} value={value} disabled={disabled} onChange={event => onChange(event.target.value)} />;
  }}</Field>;
}

function InboxItem({ question, busy, act }: { question: InboxQuestion; busy: boolean; act: RunAction }) {
  const [answer, setAnswer] = useState("");
  return <div className="inbox-item">
    <div><strong>{question.label}</strong>{question.required && <Badge tone="warning">Required</Badge>}
      <p className="small muted">Seen {question.seen}× · {question.companies.slice(0, 4).join(", ") || "unknown company"}{question.bankKey ? ` · saved as ${question.bankKey}` : ""}</p></div>
    <div className="inline-form">
      {question.options.length ? <select aria-label={`Answer for ${question.label}`} value={answer} disabled={busy} onChange={event => setAnswer(event.target.value)}><option value="">Choose…</option>{question.options.map(option => <option key={option}>{option}</option>)}</select>
        : <input aria-label={`Answer for ${question.label}`} value={answer} disabled={busy} onChange={event => setAnswer(event.target.value)} placeholder="Your answer" />}
      <button type="button" className="button secondary compact" disabled={busy || !answer.trim()} onClick={() => void act("Saving answer…", async () => { await post(`/api/question-bank/inbox/${question.id}/answer`, { value: answer }); }, `Saved. "${question.label}" is filled on future forms.`)}>Save</button>
      <button type="button" className="button text-button compact" disabled={busy} onClick={() => void act("Dismissing question…", async () => { await post(`/api/question-bank/inbox/${question.id}/dismiss`, {}); }, "Question dismissed.")}>Dismiss</button>
    </div>
  </div>;
}
