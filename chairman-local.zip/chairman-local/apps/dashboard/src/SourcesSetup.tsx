import { useState, type FormEvent } from "react";
import { download, post, scanSources } from "./api";
import { dateTime, type Page, type RunAction, type Source, type State } from "./model";
import { Badge, ExternalLink, Field, Icon, Notice, PackageDownloads } from "./ui";
import { CareerLinks } from "./CareerLinks";
import { hasAutoApply } from "./AutoApply";
import { SearchPortals } from "./SearchPortals";
import { GmailSettings } from "./GmailSettings";

const sourceModes: Record<Source["mode"], { label: string; tone: "neutral" | "positive" | "warning" | "danger" }> = {
  enabled: { label: "Enabled", tone: "positive" },
  candidate: { label: "Candidate · needs review", tone: "warning" },
  manual_only: { label: "Manual only", tone: "neutral" },
  paused: { label: "Paused", tone: "warning" },
  blocked: { label: "Blocked", tone: "danger" },
};

export function Sources({ state, busy, run }: { state: State; busy: boolean; run: RunAction }) {
  const enabled = state.sources.filter((source) => source.mode === "enabled" && source.discoveryAllowed).length;
  const [pendingPreferences, setPendingPreferences] = useState<Record<string, boolean>>({});
  return <div className="sources-view">
    <SearchPortals state={state} busy={busy} run={run} />
    <CareerLinks state={state} busy={busy} run={run} />
    <div className="sources-intro"><div><h2>Wider discovery. Clearer boundaries.</h2><p>Choose which reviewed public feeds contribute jobs. Manual websites stay on your radar without scraping. Discovery permission never implies permission to fill or submit applications.</p></div><div className="source-tally"><strong>{enabled}<span> / {state.sources.length}</span></strong><span>enabled for public discovery</span></div></div>
    <Notice>Candidate connectors stay inactive until their policy and actual endpoint are reviewed. A successful request or visible form is not permission to automate.</Notice>
    <div className="source-list">{state.sources.map((source) => {
      const mode = sourceModes[source.mode];
      const coolingDown = !!source.nextScanAt && Date.parse(source.nextScanAt) > Date.now();
      const canScan = source.mode === "enabled" && source.discoveryAllowed && !coolingDown;
      return <article className="source-row" key={source.id}>
        <div className="source-identity"><span className="source-monogram">{source.name.slice(0, 2).toUpperCase()}</span><div><h3>{source.name}</h3><Badge tone={mode.tone}>{mode.label}</Badge></div></div>
        <div className="source-content"><p>{source.notes}</p><div className="capability-list"><span><Icon name={source.discoveryAllowed ? "check" : "close"} size={13} />Public discovery {source.discoveryAllowed ? "permitted" : "not enabled"}</span><span><Icon name={source.assistanceAllowed ? "check" : "close"} size={13} />Assistance {source.assistanceAllowed ? "policy permits" : "manual"}</span><span><Icon name="info" size={13} />Submission {source.submissionAllowed && ["ashby", "greenhouse"].includes(source.kind) ? hasAutoApply(state) ? "supported forms · Auto Apply consent required" : "local service update required" : "manual / unsupported destination"}</span></div>
          {source.lastError && <div className="source-error" role="status"><Icon name="info" size={16} /><span><strong>Latest scan error:</strong> {source.lastError}</span></div>}
          <div className="source-metadata"><span>Last scan: {dateTime(source.lastScannedAt)}</span><span>{source.count !== undefined ? `${source.count} listings reported` : "Listing count not reported"}</span>{source.nextScanAt && <span>{coolingDown ? "Cooldown until" : "Next scan eligible after"} {dateTime(source.nextScanAt)}</span>}{source.policyUrl && <ExternalLink href={source.policyUrl}>Policy evidence</ExternalLink>}</div>
        </div>
        <div className="source-actions"><ExternalLink href={source.careersUrl} className="button secondary compact">Visit source</ExternalLink>{source.discoveryAllowed && source.discoveryEnabled !== undefined && <label className="checkbox-label"><input type="checkbox" aria-label={`Public discovery for ${source.name}`} checked={pendingPreferences[source.id] ?? source.discoveryEnabled} disabled={busy || pendingPreferences[source.id] !== undefined} onChange={event => {
          const enabled = event.target.checked;
          setPendingPreferences(current => ({ ...current, [source.id]: enabled }));
          void run(`Saving ${source.name} discovery preference...`, async () => { await post("/api/discovery/preferences", { sourceId: source.id, enabled }); }, "Discovery preference saved. Cooldowns and site permissions are unchanged; previous Auto Apply scope needs fresh authorization.")
            .finally(() => setPendingPreferences(current => { const next = { ...current }; delete next[source.id]; return next; }));
        }} />Use this public feed</label>}<button className="button text-button compact" disabled={busy || !canScan} onClick={() => void run(`Scanning ${source.name}…`, () => scanSources(source.id), `${source.name}: bounded source page scanned.`)}><Icon name="refresh" size={15} />Scan source</button></div>
      </article>;
    })}</div>
    <div className="source-footnotes"><p><strong>SideShift means SideShift.app.</strong> Corporate engineering vacancies only—not creator campaigns or customer demo forms.</p><p><strong>Himalayas attribution.</strong> Listings from its public feed are credited to <ExternalLink href="https://himalayas.app/">Himalayas</ExternalLink>. Check the original employer destination for application rules.</p><p><strong>No-AI requirements remain binding.</strong> Affected Canonical and other employer applications must use your own words and a manual process.</p></div>
  </div>;
}

export function Setup({ state, busy, run, onDeleted, navigate }: { state: State; busy: boolean; run: RunAction; onDeleted: (warning?: string) => void; navigate: (page: Page) => void }) {
  const [token, setToken] = useState("");
  const [revealToken, setRevealToken] = useState(false);
  const [deleteConfirmation, setDeleteConfirmation] = useState("");
  const [showDelete, setShowDelete] = useState(false);

  async function pair() {
    await run("Creating an extension pairing token…", async () => {
      const result = await post<{ token: string }>("/api/extension/pair", {});
      setToken(result.token);
      setRevealToken(false);
    }, "Pairing token created. Copy it into your extension yourself; keep it private.");
  }

  async function copyToken() {
    await run("Copying pairing token…", async () => {
      if (!navigator.clipboard?.writeText) throw new Error("Clipboard access is unavailable. Reveal the token and copy it manually, or enable clipboard access for this local page.");
      try {
        await navigator.clipboard.writeText(token);
      } catch {
        throw new Error("Clipboard permission was denied. Reveal the token and copy it manually, or allow clipboard access and retry.");
      }
    }, "Pairing token copied. Paste it only into your trusted local extension.");
  }

  async function deleteData(event: FormEvent) {
    event.preventDefault();
    if (deleteConfirmation !== "DELETE LOCAL DATA") return;
    await run("Deleting local workspace data…", async () => {
      const result = await post<{ deleted: boolean; warning?: string }>("/api/data/delete", { confirmation: deleteConfirmation });
      setToken("");
      setDeleteConfirmation("");
      setShowDelete(false);
      onDeleted(result.warning);
    });
  }

  return <div className="setup-layout"><div className="setup-main">
    <section className="setup-section">
      <h2>Your local workspace is running</h2>
      <p>You are already using the local app. Auto Apply does not require the optional extension. To move to a Windows PC, use the Windows package below. Keep the computer running Auto Apply awake and the local service running.</p>
      <button className="button primary" onClick={() => navigate("autopilot")}>Set up Auto Apply<Icon name="arrow" size={15} /></button>
    </section>
    <section className="setup-section">
      <h2>Optional installation</h2>
      <PackageDownloads />
      <p>If a download does not start in an embedded preview, open this dashboard address in a regular Chrome window and retry.</p>
      <ol className="installation-steps">
        <li><strong>Windows 10/11 x64 PC:</strong> transfer <code>chairman-windows.zip</code>, right-click it and choose <strong>Extract All</strong>, then double-click <code>Start Chairman.cmd</code> inside the extracted <code>Chairman</code> folder. Node.js, Windows runtime dependencies and Chrome for Testing are bundled; the launcher opens the homepage without an npm install. Internet is still needed for job sites, sign-in and hosted AI. Keep the launcher window open; use Ctrl+C to stop it. Native Windows execution is not yet verified; optional Copilot helpers may need Microsoft's Visual C++ runtime as described in WINDOWS.md.</li>
        <li><strong>Gemini free-tier setup:</strong> in <strong>Configured AI</strong>, choose Gemini, add your own Google AI Studio API key locally, and review the processing and free-project confirmations. Use a project with billing disabled; quotas vary and the app does not upgrade your plan. Gemini receives generic skill/role signals only, not your resume text or personal details. Upload and confirm your profile and at least two resumes on the new PC before activating Auto Apply.</li>
        <li><strong>Extension:</strong> extract <code>chairman-chrome-extension.zip</code> first. In regular Chrome, enter <code>chrome://extensions</code> in the address bar, enable <strong>Developer mode</strong>, then click <strong>Load unpacked</strong>. Select <code>chairman-chrome-extension</code>, the folder containing <code>manifest.json</code>, not the ZIP or the Downloads folder. From the Windows bundle, select <code>Chairman/dist/extension</code>; for a local source checkout, select <code>dist/extension</code>.</li>
        <li><strong>Pair the optional extension:</strong> create a local pairing token below and paste it into the extension side panel. Provider sign-ins are separate; pairing does not activate applications.</li>
        <li><strong>Source bundle on another computer:</strong> <code>chairman-local.zip</code> requires Node.js 22.13+ with npm and Google Chrome. Open a terminal in the extracted <code>chairman-local</code> folder, run <code>npm ci</code>, then <code>npm start</code>. The built dashboard is included. Open <code>http://127.0.0.1:4318</code> after startup. Do not start a second copy on the same port. Windows users can use the launcher bundle instead.</li>
      </ol>
      <Notice>Downloading, uploading, pairing, or previewing a JD-tailored resume does not activate applications. The Chrome page assistant fills only supported, permitted destinations after your explicit action; the separately authorized local runner handles Auto Apply.</Notice>
    </section>
    <section className="setup-section"><div className="section-heading"><div><h2>Dedicated local Chrome</h2><p>A separate browser for supported company portals and ATS forms, with prefilled human-review sessions when needed.</p></div><Badge tone={!hasAutoApply(state) ? "warning" : state.autopilot?.browserRunning ? "positive" : "neutral"}>{!hasAutoApply(state) ? "Service update required" : state.autopilot?.browserRunning ? "Running" : "Not running"}</Badge></div>
      <p>The local Node runner interacts with ordinary supported application forms in dedicated Chrome. It does not use your existing Chrome profile, bypass site controls, or guess answers. Sign in yourself in that dedicated browser if a specific application requires it. This dashboard never collects provider passwords or manufactures login tokens.</p>
      <button className="button secondary" disabled={busy || !hasAutoApply(state)} onClick={() => void run("Opening dedicated local Chrome…", async () => { await post("/api/autopilot/browser", {}); }, "Dedicated Chrome setup requested. Opening it does not activate Auto Apply or verify a provider login.")}>Open local Chrome setup<Icon name="external" size={15} /></button>
      <p className="small muted">The runner pauses affected jobs for login, MFA, CAPTCHA, missing factual answers, legal declarations, assessments, and unsupported fields. Follow the blocked job’s guidance in Auto Apply. Unknown submission outcomes are never automatically retried.</p>
    </section>
    <section className="setup-section"><div className="section-heading"><div><h2>Configured AI</h2><p>Choose the model Chairman uses for form questions and resume tailoring, sign in, and test it on the AI tab.</p></div>
      <Badge tone={state.runtime.ai.available ? "positive" : "warning"}>{state.runtime.ai.available ? `Ready · ${state.runtime.ai.model}` : "Not ready"}</Badge></div>
      <button className="button secondary" type="button" onClick={() => navigate("ai")}>Open the AI tab</button></section>
    <GmailSettings busy={busy} run={run} />
    <section className="setup-section"><div className="section-heading"><div><h2>Public cloud discovery</h2><p>Public job listings only. This scanner receives no personal profile; hosted AI is a separate processing choice.</p></div><Badge tone={state.runtime.cloud.configured ? "positive" : "neutral"}>{state.runtime.cloud.configured ? "Configured" : "Not configured"}</Badge></div>
      <p>{state.runtime.cloud.configured ? "A cloud discovery connection is configured. Configuration alone does not verify healthy scans; review each source’s last scan and error." : "Cloud scanning has not been configured. Permitted public sources can still be scanned from your running local service."}</p><p>When deployed and scheduled, the free-tier scanner can discover public listings while your computer is off. Free-tier quotas and source policies limit coverage. It does not generate resumes, access accounts, or submit applications.</p><ExternalLink href="https://dash.cloudflare.com/">Open Cloudflare dashboard</ExternalLink>
      {state.runtime.cloud.health?.error && <Notice tone="danger">{state.runtime.cloud.health.error}</Notice>}
      {state.runtime.cloud.health?.results?.filter(result => result.sourceId === "cloud").map(result => <Notice key={result.sourceId} tone={result.error ? "warning" : "info"}>{result.error || `${result.count ?? 0} public jobs synchronized in the latest bounded run.`}</Notice>)}
    </section>
    <section className="setup-section"><h2>Provider accounts stay with you</h2><p>LinkedIn, Indeed, Wellfound, and Naukri remain manual workflows. These links only open official websites in your normal browser; they do not connect an account to this workspace or verify login status.</p><div className="provider-links"><ExternalLink href="https://www.linkedin.com/login">LinkedIn login</ExternalLink><ExternalLink href="https://www.indeed.com/">Indeed · sign in on the official site</ExternalLink><ExternalLink href="https://wellfound.com/login">Wellfound login</ExternalLink><ExternalLink href="https://www.naukri.com/">Naukri · sign in on the official site</ExternalLink></div><Notice>Provider credentials and API tokens cannot be derived from a resume. Obtain any required Cloudflare token in your own Cloudflare account and configure it using the local setup instructions. The random local pairing token below is not a job-site login, Cloudflare token, or permission to apply.</Notice></section>
    <section className="setup-section"><div className="section-heading"><div><h2>Browser extension</h2><p>Your browser, paired explicitly.</p></div><Badge tone={state.runtime.extension.paired ? "positive" : "neutral"}>{state.runtime.extension.paired ? "Local pairing configured" : "Not paired"}</Badge></div>
      <Notice><strong>Homepage and Chrome, working together.</strong> On a permitted employer page, use the Chairman side panel to detect a job, choose your baseline, tailor and review the exact packet, then explicitly fill supported fields. Edit saved factual selections before filling. A fill is not a submission; check the actual confirmation before recording it. Restricted portals remain manual.</Notice>
      <p>Load the built extension in Chrome’s extension developer settings, then paste a pairing token into its side panel. Pairing authorizes access to the local workspace; it does not sign into a provider, confirm facts, or approve applications.</p>
      <p className="small muted">Pairing tokens are valid only for the current local-service process. After restarting the service, create a new token and pair the extension again.</p>
      <div className="button-row"><button className="button secondary" disabled={busy} onClick={() => void pair()}><Icon name="shield" />{state.runtime.extension.paired ? "Create new pairing token" : "Create pairing token"}</button></div>
      {token && <div className="pairing-token"><Field label="Private pairing token" hint="This token grants access to your local workspace. Do not share it in messages, logs, or screenshots.">{(id) => <input id={id} type={revealToken ? "text" : "password"} readOnly autoComplete="off" spellCheck={false} value={token} />}</Field><div className="button-row"><button className="button primary" disabled={busy} onClick={() => void copyToken()}><Icon name="copy" />Copy token</button><button className="button text-button" onClick={() => setRevealToken(!revealToken)}>{revealToken ? "Hide token" : "Reveal to copy manually"}</button><button className="button text-button" onClick={() => { setToken(""); setRevealToken(false); }}>Clear from view</button></div></div>}
      <p className="small muted">The extension must pause for login, MFA, CAPTCHA, unsupported fields, assessments, and legal declarations. You handle these directly. Permissions are per supported destination—not all your browsing.</p>
    </section>
    <section className="setup-section"><h2>Your data, your control</h2><p>Export a local copy of your workspace or delete its personal data. Exports contain personal information; keep them somewhere private.</p><button className="button secondary" disabled={busy} onClick={() => void run("Exporting local workspace…", async () => { await download("/api/export", "job-application-workspace.json"); }, "Workspace exported to your downloads. Keep this file private.")}><Icon name="download" />Export local data</button>
      <div className="danger-zone"><div><h3>Delete personal workspace data</h3><p>This is destructive. It does not withdraw applications or remove information already sent to employers. Anonymous current-day global and per-source attempt counts remain to enforce daily safety limits; these counters contain no candidate data.</p></div><button className="button danger-quiet" disabled={busy} aria-expanded={showDelete} onClick={() => setShowDelete(!showDelete)}>{showDelete ? "Cancel deletion" : "Delete local data…"}</button></div>
      {showDelete && <form className="delete-form" onSubmit={(event) => void deleteData(event)}><Notice tone="danger">Export anything you need first. Deletion cannot be undone by this dashboard. Anonymous daily attempt counters are retained for optional personal caps and source limits. Your original resume files are not an application database backup.</Notice><Field label='Type DELETE LOCAL DATA to confirm'>{(id) => <input id={id} autoComplete="off" value={deleteConfirmation} onChange={(event) => setDeleteConfirmation(event.target.value)} disabled={busy} />}</Field><button className="button danger" disabled={busy || deleteConfirmation !== "DELETE LOCAL DATA"} type="submit">Permanently delete personal data</button></form>}
    </section>
  </div><aside className="privacy-guide"><Icon name="shield" size={26} /><h2>Privacy is a boundary, not a badge.</h2><dl>
    <dt>On your computer</dt><dd>Resume originals and facts, personal answers, dedicated browser sessions, document files, authorizations, and application history. Ollama inference runs locally when selected. Transfer packages exclude personal data and credentials.</dd>
    <dt>At Gemini · only with consent</dt><dd>Anonymous fact references and fixed public skill/role tags only. Resume text, names, contact details and employer history stay local. Google may use unpaid API inputs and outputs for model improvement and human review. Free-tier quotas and eligibility depend on your Google project.</dd>
    <dt>At GitHub Copilot · only with consent</dt><dd>Bounded confirmed resume-fact and job-description text for hosted AI-assisted tailoring. This uses your Copilot allowance; availability depends on SDK sign-in and exact model access.</dd>
    <dt>In the public scanner</dt><dd>Public jobs, source metadata, scan history, and deduplication data only. No personal data.</dd>
    <dt>At an employer</dt><dd>The exact resume and factual answers you authorize through Auto Apply, approve per packet, or manually transmit.</dd>
  </dl><p>Local storage is not automatically encrypted. Protect your device with BitLocker, FileVault or your system's disk encryption, and keep private backups. Applications stop when the computer or local service is off.</p><div className="ceiling-note"><strong>Targets are plans.<br />Not promises.</strong><p>{state.stats.limit === null ? "No global daily or session cap is configured." : `Your optional daily cap is ${state.stats.limit.toLocaleString()} attempts per Asia/Kolkata day; there is no separate global session cap.`} Lower source limits and policy restrictions remain binding. No guarantees of applications, interviews, offers, sponsorship, or compensation.</p></div></aside></div>;
}
