import { download, post } from "./api";
import { dateTime, type Page, type ReferenceResume, type RunAction, type State } from "./model";
import { Badge, EmptyState, Icon, Notice } from "./ui";
import { useCallback, useEffect, useState } from "react";
import { VariantSlot } from "./AutoApply";
import { TailoringPreview } from "./TailoringPreview";

export function Resumes({ state, busy, run, profileDirty, setupDirty, navigate, onDirty, viewPacket }: { state: State; busy: boolean; run: RunAction; profileDirty: boolean; setupDirty: boolean; navigate: (page: Page) => void; onDirty: (dirty: boolean) => void; viewPacket: (id: string) => void }) {
  const resumes = state.referenceResumes || [];
  const [dirtyParts, setDirtyParts] = useState<Record<string, boolean>>({});
  const dirty = Object.values(dirtyParts).some(Boolean);
  const partDirty = useCallback((part: string, value: boolean) => setDirtyParts(current => current[part] === value ? current : { ...current, [part]: value }), []);
  useEffect(() => { onDirty(dirty); }, [dirty, onDirty]);
  const profileReady = state.profile.confirmed && !!state.profile.facts.length && state.profile.facts.every(fact => fact.confirmed) && !profileDirty;
  return <div className="resumes-view">
    <section className="home-section" aria-label="Baseline resume library"><div className="section-heading"><div><h2>Your baseline resume library</h2><p>Keep up to four original PDF or DOCX resumes. Choose an approved base for each job; Auto Apply requires at least two valid approved files.</p></div><button className="text-link" onClick={() => navigate("profile")}>Confirm profile<Icon name="arrow" size={14} /></button></div>
      <Notice>Uploading or approving a baseline never activates applications. Verify identity details and every claim in each original. Template-only claims must first become confirmed profile facts.</Notice>
      {state.resumeVariants ? <div className="variant-grid">{[1, 2, 3, 4, 5, 6, 7, 8].map(slot => <VariantSlot key={slot} slot={slot} variant={state.resumeVariants?.find(item => item.slot === slot)} busy={busy} run={run} onDirty={partDirty} />)}</div> : <Notice tone="warning">The updated local service is required to load your baseline library.</Notice>}
    </section>
    <section className="home-section"><h2>Choose a job. Tailor. Review.</h2><p>Select an approved baseline and an imported job description below. Your exact packet preview opens in Applications; review the documents and edit factual answers before any filling or sending. The Chrome assistant also lets you adjust fact selections for its own packets before filling.</p><button className="text-link" onClick={() => navigate("opportunities")}>Add an employer link or job description<Icon name="arrow" size={14} /></button>
      <TailoringPreview state={state} busy={busy} savedProfileReady={profileReady} setupDirty={dirty || setupDirty} run={run} viewPacket={viewPacket} />
    </section>
    <Notice><strong>Reference drafts are separate from your baselines.</strong> Nothing generated below is automatically uploaded, accuracy-approved, or selected for Auto Apply.</Notice>
    <div className="section-heading"><div><h2>Six perspectives. One factual foundation.</h2><p>Software, cloud, data, forward deployed, MLOps, and hybrid reference resumes, generated locally from your saved profile.</p></div><button className="button primary" disabled={busy} onClick={() => void run("Building six local reference drafts…", async () => { await post<{ resumes: ReferenceResume[] }>("/api/resumes/reference", {}); }, "Local reference drafts created. They remain unverified and are not approved for any application.")}><Icon name="resumes" />Create all 6 drafts</button></div>
    <Notice tone="warning"><strong>Draft / unverified · not approved for application.</strong> Reference resumes may use an unconfirmed profile. Creating or downloading one never confirms your facts, approves a packet, or sends an application. Compare every claim against your original resume before use.</Notice>
    {profileDirty && <Notice>Your profile has unsaved edits. These drafts use the last saved profile, not those edits. <button className="text-link" onClick={() => navigate("profile")}>Return to your profile</button></Notice>}
    <p className="reference-guidance">Source-specific application packets remain separate: confirm your profile, choose an eligible job, then review the exact documents, answers, and warnings. Transferable foundations and missing skills must not become claimed hands-on experience.</p>
    {resumes.length ? <div className="reference-grid">{resumes.map((resume) => <article className="reference-resume" key={resume.id}>
      <div className="tag-group"><Badge tone="warning">Draft / unverified</Badge><Badge>{resume.family}</Badge></div><h3>{resume.title}</h3><p className="small muted">Created {dateTime(resume.createdAt)} · Profile v{resume.profileVersion}</p>
      <p className="reference-warning">Not approved for application. Verify every fact before use.</p>
      {resume.profileVersion !== state.profile.version && <p className="field-error">An older profile version was used. Review against your current saved facts or create fresh drafts.</p>}
      <div className="button-row">{(["pdf", "docx"] as const).map((format) => <button key={format} className="button secondary compact" disabled={busy || !resume.artifacts.some((artifact) => artifact.format === format)} onClick={() => void run(`Downloading unverified ${format.toUpperCase()} draft…`, async () => { await download(`/api/resumes/reference/${encodeURIComponent(resume.id)}/${format}`, `reference-draft-${resume.family}-${resume.id}.${format}`); }, "Unverified reference draft downloaded locally. Verify its contents before use; nothing was sent.")}><Icon name="download" size={15} />{format.toUpperCase()}<span className="sr-only"> · {resume.title}</span></button>)}</div>
      <details className="artifact-details"><summary>Source & document fingerprints</summary><dl className="detail-grid"><dt>Source profile hash</dt><dd className="hash-value">{resume.sourceProfileHash}</dd><dt>Created</dt><dd>{dateTime(resume.createdAt)}</dd>{resume.artifacts.map((artifact) => <div className="artifact-row" key={artifact.format}><dt>{artifact.format.toUpperCase()}</dt><dd>{artifact.filename}<span className="hash-value">{artifact.sha256}</span></dd></div>)}</dl></details>
    </article>)}</div> : <EmptyState icon="resumes" title="A place to explore your resume" action={<button className="button secondary" onClick={() => navigate("profile")}>Review saved profile<Icon name="arrow" size={16} /></button>}>Create the six local reference drafts when you have saved your resume facts. You can explore these drafts before confirming your profile; they cannot be approved as application packets.</EmptyState>}
  </div>;
}
