import { useEffect, useRef, useState } from "react";
import type { State } from "./model";
import { errorMessage } from "./model";

const preferenceKey = "chairman.attention-notifications";
const seenKey = "chairman.attention-seen";

export function AttentionNotifications({ state }: { state: State }) {
  const [enabled, setEnabled] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const seen = useRef<Set<string>>(new Set());
  const supported = typeof Notification !== "undefined";
  useEffect(() => {
    try {
      setEnabled(localStorage.getItem(preferenceKey) === "true");
      const value: unknown = JSON.parse(localStorage.getItem(seenKey) || "[]");
      if (Array.isArray(value) && value.every(item => typeof item === "string")) seen.current = new Set(value);
    } catch (cause) { setError(`Notification preferences could not be loaded: ${errorMessage(cause)}`); }
  }, []);
  useEffect(() => {
    if (!enabled || !supported || Notification.permission !== "granted") return;
    const tasks = state.autopilot?.humanTasks?.filter(task => task.status === "waiting" || task.status === "session_lost") || [];
    const newTasks = tasks.filter(task => !seen.current.has(`${task.id}:${task.status}`));
    if (!newTasks.length) return;
    try {
      new Notification("Chairman needs your attention", { body: `${tasks.length} application ${tasks.length === 1 ? "task needs" : "tasks need"} your review. Open your local workspace.`, tag: "chairman-attention" });
      newTasks.forEach(task => seen.current.add(`${task.id}:${task.status}`));
      localStorage.setItem(seenKey, JSON.stringify([...seen.current].slice(-500)));
    } catch (cause) { setError(`Notification could not be delivered: ${errorMessage(cause)}. The dashboard attention count remains available.`); }
  }, [state.autopilot?.humanTasks, enabled, supported]);

  async function toggle() {
    setError("");
    if (enabled) {
      try { localStorage.setItem(preferenceKey, "false"); setEnabled(false); setMessage("Desktop notifications turned off. In-app attention remains visible."); }
      catch (cause) { setError(errorMessage(cause)); }
      return;
    }
    if (!supported) { setMessage("Desktop notifications are unavailable here. Use the dashboard attention count."); return; }
    try {
      const permission = await Notification.requestPermission();
      if (permission !== "granted") { setMessage("Notification permission was not granted. In-app attention remains visible; change your Chrome site settings to enable desktop notifications."); return; }
      localStorage.setItem(preferenceKey, "true"); setEnabled(true);
      setMessage("Desktop notifications enabled. Only task counts are shown, never your resume or employer details.");
    } catch (cause) { setError(`Notifications could not be enabled: ${errorMessage(cause)}`); }
  }
  return <div className="attention-optin"><button className="text-link" onClick={() => void toggle()}>{enabled ? "Turn off desktop notifications" : "Enable desktop notifications"}</button><span className="small muted">Optional, count-only alerts. Keep this workspace open.</span>{message && <p role="status">{message}</p>}{error && <p className="field-error" role="alert">{error}</p>}</div>;
}
