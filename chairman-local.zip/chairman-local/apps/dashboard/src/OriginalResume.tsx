import { useEffect, useState } from "react";
import { documentBlob, download } from "./api";
import type { RunAction } from "./model";
import { Icon } from "./ui";

export function OriginalResume({ path, filename, format, busy, run }: { path: string; filename: string; format: "pdf" | "docx"; busy: boolean; run: RunAction }) {
  const [preview, setPreview] = useState<{ path: string; url: string } | null>(null);
  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview.url); }, [preview]);
  const visible = preview?.path === path;
  return <div className="original-resume">
    <div className="button-row">
      <button className="button secondary compact" disabled={busy} onClick={() => void run("Downloading original resume…", () => download(path, filename), "Original, unchanged resume downloaded. Nothing was sent.")}><Icon name="download" size={15} />Download original {format.toUpperCase()}</button>
      {format === "pdf" && <button className="button text-button compact" disabled={busy} aria-expanded={visible} onClick={() => {
        if (visible) { setPreview(null); return; }
        void run("Opening original PDF preview…", async () => {
          const blob = await documentBlob(path);
          setPreview({ path, url: URL.createObjectURL(new Blob([blob], { type: "application/pdf" })) });
        });
      }}>{visible ? "Close PDF preview" : "Preview original PDF"}</button>}
    </div>
    {visible && <iframe className="original-pdf-preview" title={`Original resume preview: ${filename}`} src={preview.url} />}
    <p className="small muted">{format === "docx" ? "DOCX stays in its original format. Download and open it locally to review; a PDF is not required." : "Review the original PDF, not a reconstructed text summary. If the preview is unavailable, download and open it locally."}</p>
  </div>;
}
