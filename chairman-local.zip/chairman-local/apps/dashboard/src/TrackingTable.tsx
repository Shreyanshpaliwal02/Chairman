import { useEffect, useState, type FormEvent } from "react";
import type { TrackingKind, TrackingPage, TrackingRow, TrackingStatus } from "../../../packages/domain/application-tracker";
import type { PipelineStage } from "../../../packages/domain/types";
import { api, post } from "./api";
import { campaignToday, dateLabel, dateTime, errorMessage, pipelineLabels, type RunAction, type State } from "./model";
import { Badge, ExternalLink, Field, Notice } from "./ui";

const statusLabels: Record<TrackingStatus, string> = {
  detected: "Detected", prepared: "Prepared", fill_intent: "Fill requested · not confirmed", filled: "Filled · not applied",
  manual_required: "Manual action needed", queued: "Queued", abandoned: "Abandoned",
  approved: "Approved", executing: "Executing", awaiting_human: "Awaiting human review",
  submitted_confirmed: "Submission confirmed", submission_unknown: "Unknown outcome · do not retry",
  failed: "Failed", manual_only: "Manual handoff", withdrawn_from_queue: "Removed from queue",
  inspecting: "Inspecting form", prefilling: "Prefilling", needs_input: "Needs your answers", auth_required: "Sign-in required",
  captcha_required: "CAPTCHA requires you", unsupported: "Unsupported · manual", skipped: "Skipped", submitting: "Submitting · not confirmed",
};
const kinds: Record<TrackingKind, string> = { packet: "Packet", external: "External submission", assistance: "Chrome assistance" };

async function saveNotes(row: TrackingRow, notes: string) {
  await post(row.kind === "assistance" ? `/api/assistance/${encodeURIComponent(row.id)}` : `/api/tracking/${row.kind}/${encodeURIComponent(row.id)}/notes`, { notes });
}

export function TrackingTable({ state, busy, run, viewPacket, visible }: { state: State; busy: boolean; run: RunAction; viewPacket: (id: string) => void; visible: boolean }) {
  const [result, setResult] = useState<TrackingPage>();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [revision, setRevision] = useState(0);
  const [offset, setOffset] = useState(0);
  const [filters, setFilters] = useState({ q: "", status: "", stage: "", kind: "" });
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [bulkNote, setBulkNote] = useState("");
  const [editing, setEditing] = useState<TrackingRow>();
  useEffect(() => {
    if (!visible) return;
    const controller = new AbortController();
    setLoading(true); setError("");
    const query = new URLSearchParams({ ...filters, offset: String(offset), limit: "25" });
    void api<TrackingPage>(`/api/tracking?${query}`, { signal: controller.signal }).then(value => {
      if (!Array.isArray(value.items) || typeof value.total !== "number") throw new Error("The service did not return a tracking page. Restart the updated local service.");
      if (!controller.signal.aborted) {
        setResult(value);
        setSelected(current => current.filter(key => value.items.some(row => `${row.kind}:${row.id}` === key)));
      }
    }).catch(cause => { if (!controller.signal.aborted) setError(errorMessage(cause)); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [filters, offset, revision, visible, state]);
  const blocked = busy || loading || !!error;
  const updateFilter = (key: "status" | "stage" | "kind", value: string) => { setOffset(0); setFilters(current => ({ ...current, [key]: value })); };
  async function bulkSave(event: FormEvent) {
    event.preventDefault();
    const rows = result?.items.filter(row => selected.includes(`${row.kind}:${row.id}`)) || [];
    if (!rows.length || rows.length > 20) return;
    let saved = 0;
    const success = await run("Saving selected tracking notes...", async () => {
      for (const row of rows) {
        try { await saveNotes(row, bulkNote); saved++; }
        catch (cause) { throw new Error(`${saved} of ${rows.length} notes saved before failure: ${errorMessage(cause)}. The remaining records were not changed.`); }
      }
    }, `${rows.length} notes saved. No status, application, or submission count changed.`);
    setRevision(value => value + 1);
    if (success) { setSelected([]); setBulkNote(""); }
  }
  return <section className="home-section tracking-monitor" aria-labelledby="tracking-title">
    <div className="section-heading"><div><h2 id="tracking-title">Application monitoring</h2><p>One view of packets, Chrome assistance, and recorded external submissions. Filled is not applied.</p></div><button className="button secondary compact" disabled={busy || loading} onClick={() => setRevision(value => value + 1)}>Refresh tracking</button></div>
    <form className="filter-bar tracking-filters" onSubmit={event => { event.preventDefault(); setOffset(0); setFilters(current => ({ ...current, q: search })); }}>
      <Field label="Search company, role, portal or notes">{id => <input id={id} type="search" maxLength={100} value={search} onChange={event => setSearch(event.target.value)} />}</Field>
      <Field label="Tracking status">{id => <select id={id} value={filters.status} onChange={event => updateFilter("status", event.target.value)}><option value="">All statuses</option>{Object.entries(statusLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>}</Field>
      <Field label="Tracking hiring stage">{id => <select id={id} value={filters.stage} onChange={event => updateFilter("stage", event.target.value)}><option value="">All stages</option>{Object.entries(pipelineLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>}</Field>
      <Field label="Tracking record type">{id => <select id={id} value={filters.kind} onChange={event => updateFilter("kind", event.target.value)}><option value="">All records</option>{Object.entries(kinds).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>}</Field>
      <button className="button secondary" type="submit" disabled={busy}>Search tracking</button>
    </form>
    {error && <Notice tone="danger">Tracking could not be refreshed: {error}. Previously shown data may be stale.</Notice>}
    {loading && <p className="small muted" role="status">Loading application records...</p>}
    {result && <><div className="application-table-wrap" tabIndex={0} role="region" aria-label="Scrollable application monitoring table"><table className="application-table monitoring-table">
      <caption>Application records across your entire local workspace. Dates are confirmed submission dates when available, otherwise record creation dates.</caption>
      <thead><tr>{["Select", "Company", "Role", "Portal / where applied", "Apply URL", "Date", "Last stage", "Status", "Notes", "Actions"].map(label => <th scope="col" key={label}>{label}</th>)}</tr></thead>
      <tbody>{result.items.map(row => {
        const key = `${row.kind}:${row.id}`;
        return <tr key={key}><td><input type="checkbox" aria-label={`Select ${row.company} ${row.title}`} checked={selected.includes(key)} disabled={blocked || (!selected.includes(key) && selected.length >= 20)} onChange={event => setSelected(current => event.target.checked ? [...current, key] : current.filter(item => item !== key))} /></td><th scope="row">{row.company}</th><td>{row.title}<span>{kinds[row.kind]}</span></td><td>{state.sources.find(source => source.id === row.portal)?.name || row.portal}</td><td><ExternalLink href={row.applyUrl}>Open job<span className="sr-only"> application for {row.company}</span></ExternalLink></td><td><time dateTime={row.date}>{/^\d{4}-\d{2}-\d{2}$/.test(row.date) ? dateLabel(row.date) : dateTime(row.date)}</time></td><td>{row.stage ? pipelineLabels[row.stage] : statusLabels[row.status] || row.status}</td><td><Badge tone={row.status === "submitted_confirmed" ? "positive" : row.status === "submission_unknown" || row.status === "failed" ? "danger" : "neutral"}>{statusLabels[row.status] || row.status}</Badge></td><td className="tracking-notes">{row.notes || <span>No notes yet</span>}</td><td><div className="tracking-actions"><button className="button secondary compact" disabled={blocked} onClick={() => {
          if (editing && editing.id !== row.id && !window.confirm("Switch record editor? Any unsaved tracking edits in the open editor will be discarded.")) return;
          setEditing(row);
        }}>Edit<span className="sr-only"> {row.company} {row.title}</span></button>{row.packetId && <button className="text-link" onClick={() => viewPacket(row.packetId!)}>Review packet</button>}</div></td></tr>;
      })}</tbody>
    </table></div>
      {!result.items.length && !loading && !error && <p className="quiet-empty">No application records match these filters. Prepare a packet or use the Chrome assistant to start a record.</p>}
      <div className="tracking-pagination"><button className="button secondary compact" disabled={blocked || offset === 0} onClick={() => setOffset(value => Math.max(0, value - 25))}>Previous tracking page</button><span role="status">{result.total ? `${result.offset + (result.items.length ? 1 : 0)}-${result.offset + result.items.length} of ${result.total}` : "0 records"} · at most 25 per page</span><button className="button secondary compact" disabled={blocked || offset + result.limit >= result.total} onClick={() => setOffset(value => value + 25)}>Next tracking page</button></div>
    </>}
    {selected.length > 0 && <form className="tracking-bulk" onSubmit={event => void bulkSave(event)}><Field label={`Replace notes for ${selected.length} selected records (maximum 20)`}>{id => <textarea id={id} maxLength={4000} value={bulkNote} rows={2} disabled={blocked} onChange={event => setBulkNote(event.target.value)} />}</Field><p className="small muted">This replaces each selected record's notes with the exact text above, including clearing notes when empty. It never changes statuses or submission counts.</p><button className="button secondary" type="submit" disabled={blocked}>Save notes to selected records</button></form>}
    {editing && <TrackingEditor key={`${editing.kind}:${editing.id}`} row={editing} busy={busy} run={run} updated={() => setRevision(value => value + 1)} />}
    <p className="small muted">Record totals are not submission totals. Prepared revisions may be separate records; linked Chrome packets and external receipts are consolidated. Only receipt-backed confirmations count toward the campaign.</p>
  </section>;
}

function TrackingEditor({ row, busy, run, updated }: { row: TrackingRow; busy: boolean; run: RunAction; updated: () => void }) {
  const [notes, setNotes] = useState(row.notes);
  const [savedNotes, setSavedNotes] = useState(row.notes);
  const [stage, setStage] = useState<PipelineStage>(row.stage || "applied");
  const [status, setStatus] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [date, setDate] = useState(campaignToday);
  const [acknowledged, setAcknowledged] = useState(false);
  const [receiptRecorded, setReceiptRecorded] = useState(row.status === "submitted_confirmed");
  return <section className="tracking-editor" aria-label={`Edit tracking for ${row.company}`}>
    <h3>{row.company} · {row.title}</h3>
    <Field label="Tracking notes">{id => <textarea id={id} maxLength={4000} rows={3} value={notes} disabled={busy} onChange={event => setNotes(event.target.value)} />}</Field>
    <button className="button secondary" disabled={busy || savedNotes === notes} onClick={() => void run("Saving tracking notes...", async () => { await saveNotes(row, notes); setSavedNotes(notes); updated(); }, "Tracking notes saved. No application or status was changed.")}>Save tracking notes</button>
    {row.progress && <div className="tracking-stage"><Field label="Recorded hiring stage">{id => <select id={id} value={stage} disabled={busy} onChange={event => {
      const value = Object.keys(pipelineLabels).find(item => item === event.target.value) as PipelineStage | undefined;
      if (value) setStage(value);
    }}>{Object.entries(pipelineLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>}</Field><button className="button secondary" disabled={busy} onClick={() => void run("Saving reported hiring stage...", async () => {
      await post(`/api/${row.progress!.kind === "packet" ? "packets" : "external-applications"}/${encodeURIComponent(row.progress!.id)}/progress`, { stage, note: row.progress!.note, ...(row.progress!.nextActionDate ? { nextActionDate: row.progress!.nextActionDate } : {}) }); updated();
    }, "Hiring stage saved as your report. No message or application was sent.")}>Save hiring stage</button></div>}
    {row.runnerOwned && <Notice>This record was explicitly handed to the local runner. Review its linked packet or the Auto Apply human-attention panel to reconcile outcomes; do not create a second Chrome submission.</Notice>}
    {row.kind === "assistance" && !receiptRecorded && !row.runnerOwned && <><div className="tracking-stage"><Field label="Assistance outcome">{id => <select id={id} value={status} disabled={busy} onChange={event => setStatus(event.target.value)}><option value="">Choose a factual outcome</option><option value="filled">Filled, not submitted</option><option value="manual_required">Manual action needed</option><option value="submission_unknown">Submission outcome unknown</option><option value="abandoned">Abandoned</option></select>}</Field><button className="button secondary" disabled={busy || !status} onClick={() => void run("Recording assistance outcome...", async () => {
      await post(`/api/assistance/${encodeURIComponent(row.id)}`, { status }); updated(); setStatus("");
    }, "Assistance outcome saved. Filled and manual records are not counted as applications.")}>Save assistance outcome</button></div>
      <details className="tracking-receipt"><summary>Record an actual submission confirmation</summary><Notice tone="warning">A filled form, submit click, or email suggestion is not proof. Check the employer's actual confirmation. Unknown outcomes must be reconciled, never automatically retried.</Notice>
        <Field label="Actual confirmed submission date">{id => <input id={id} type="date" max={campaignToday()} value={date} disabled={busy} onChange={event => setDate(event.target.value)} />}</Field><Field label="Checked submission confirmation">{id => <textarea id={id} value={confirmation} maxLength={4000} disabled={busy} onChange={event => setConfirmation(event.target.value)} />}</Field>
        <label className="checkbox-label"><input type="checkbox" checked={acknowledged} disabled={busy} onChange={event => setAcknowledged(event.target.checked)} />I personally checked the actual submission confirmation, not just a filled form.</label><button className="button secondary" disabled={busy || !acknowledged || confirmation.trim().length < 10 || !date} onClick={() => void run("Recording checked submission confirmation...", async () => {
          await post(`/api/assistance/${encodeURIComponent(row.id)}/receipt`, { confirmation, submittedDate: date, confirm: true }); setReceiptRecorded(true); setAcknowledged(false); updated();
        }, "Your checked confirmation was recorded. No new application was sent.")}>Record checked confirmation</button>
      </details></>}
  </section>;
}
