import { useEffect, useState } from "react";
import { api, post } from "./api";
import { errorMessage, type RunAction } from "./model";
import { Badge, Field, Notice } from "./ui";
import type { GmailStatus } from "../../../packages/domain/gmail";

export function GmailSettings({ busy, run }: { busy: boolean; run: RunAction }) {
  const [state, setState] = useState<GmailStatus>();
  const [error, setError] = useState("");
  const [clientId, setClientId] = useState("");
  const [clientSecret, setClientSecret] = useState("");
  const [consent, setConsent] = useState(false);
  const [url, setUrl] = useState("");
  async function refresh() { setState(await api<GmailStatus>("/api/gmail/status")); }
  useEffect(() => { void refresh().catch(error => setError(errorMessage(error))); }, []);
  const working = busy || !!state?.busy;
  function action(label: string, operation: () => Promise<unknown>) {
    return run(label, async () => {
      setError("");
      try { await operation(); await refresh(); }
      catch (error) {
        try { await refresh(); }
        catch (refreshError) { throw new Error(`${errorMessage(error)} Refresh also failed: ${errorMessage(refreshError)}`); }
        throw error;
      }
    });
  }
  return <section className="setup-section" aria-labelledby="gmail-title">
    <div className="section-heading"><div><h2 id="gmail-title">Gmail status suggestions</h2><p>Optional, read-only scans. Every proposed status change needs your review.</p></div>
      <Badge tone={state?.connected ? "positive" : "neutral"}>{state?.connected ? "Connected" : "Not connected"}</Badge></div>
    <Notice>Chairman reads at most 25 recent matching messages per scan, using headers and snippets only. Email text never goes to an AI model. It cannot send, delete or mark mail as read. Suggestions match an existing confirmed application by company and role; they never count a new application.</Notice>
    <p>Enable the Gmail API in your own <a href="https://console.cloud.google.com/apis/library/gmail.googleapis.com" target="_blank" rel="noreferrer">Google Cloud project</a>, configure its consent screen and add yourself as a test user, then create a <strong>Desktop app</strong> OAuth client. Google controls access and may require app verification; testing-mode refresh tokens may expire after seven days. Do not enter your Gmail password or Gemini key.</p>
    {error && <div role="alert"><Notice tone="warning">{error}</Notice></div>}
    {state?.error && <Notice tone="warning">{state.error}</Notice>}
    {!state?.connected && <form onSubmit={event => {
      event.preventDefault();
      void action("Saving the private Google Desktop app client...", async () => {
        try { await post("/api/gmail/config", { clientId: clientId.trim(), clientSecret }); }
        finally { setClientSecret(""); setConsent(false); setUrl(""); }
      });
    }}>
      <div className="form-grid">
        <Field label="Google Desktop client ID">{id => <input id={id} autoComplete="off" spellCheck={false} value={clientId} disabled={working} onChange={event => setClientId(event.target.value)} placeholder="...apps.googleusercontent.com" required />}</Field>
        <Field label="Google Desktop client secret" hint="Stored in a private file on this device, never exported or displayed again. This is not your Google password.">{id => <input id={id} type="password" autoComplete="new-password" value={clientSecret} disabled={working} onChange={event => setClientSecret(event.target.value)} required />}</Field>
      </div>
      <button type="submit" className="button secondary" disabled={working || !clientId.trim() || !clientSecret}>Save Google client</button>
    </form>}
    {!state?.connected && state?.configured && <>
      <label className="checkbox-label"><input type="checkbox" checked={consent} disabled={working} onChange={event => setConsent(event.target.checked)} /><span>I allow read-only Gmail access for local, explicitly requested status scans. Google&apos;s scope permits reading mail; Chairman restricts itself to bounded headers and snippets. Tokens and reviewed suggestions stay on this computer.</span></label>
      <button className="button primary" disabled={working || !consent} onClick={() => void action("Starting Google sign-in...", async () => {
        const result = await post<{ url: string }>("/api/gmail/connect", { consent: true });
        const destination = new URL(result.url);
        if (destination.origin !== "https://accounts.google.com") throw new Error("Unexpected Google sign-in destination.");
        setUrl(destination.href);
      })}>Connect Gmail</button>
      {url && <p><a className="button secondary" href={url} target="_blank" rel="noreferrer">Continue to Google sign-in</a> After consent, return here and refresh Gmail status. The local callback expires after five minutes.</p>}
    </>}
    <div className="button-row">
      <button className="button secondary" disabled={busy} onClick={() => void action("Refreshing Gmail status...", refresh)}>Refresh Gmail status</button>
      {state?.connected && <button className="button primary" disabled={working || (!!state.nextScanAt && Date.parse(state.nextScanAt) > Date.now())} onClick={() => void action("Scanning recent application mail...", () => post("/api/gmail/scan", { consent: true }))}>Scan recent application mail</button>}
      {(state?.configured || state?.connected) && <button className="button danger-quiet" disabled={busy} onClick={() => void action("Disconnecting Gmail...", async () => {
        await post("/api/gmail/disconnect", { confirm: true }); setUrl(""); setConsent(false); setClientId(""); setClientSecret("");
      })}>Disconnect and remove Gmail data</button>}
    </div>
    {state?.lastScanAt && <p className="small muted">Last scan: {new Date(state.lastScanAt).toLocaleString()}. Only the latest 25 matching messages in the past 90 days are considered; this is not a complete inbox history.</p>}
    {state?.authorizing && <p role="status">Google sign-in is waiting for you. No email scan has started.</p>}
    {!!state?.suggestions?.length && <div className="table-scroll"><table><caption>Review Gmail suggestions before applying them</caption>
      <thead><tr><th scope="col">Application</th><th scope="col">Email evidence</th><th scope="col">Suggested change</th><th scope="col">Review</th></tr></thead>
      <tbody>{state.suggestions.map(item => <tr key={item.id}>
        <td>{item.company}<br />{item.title}</td>
        <td>{item.subject}<br /><span className="small muted">{item.sender} · {new Date(item.receivedAt).toLocaleDateString()}</span></td>
        <td>{item.previousStage} → {item.stage}</td>
        <td><div className="button-row"><button className="button secondary" disabled={working} onClick={() => void action("Saving your reviewed status...", () => post("/api/gmail/review", { id: item.id, action: "accept" }))}>Accept status</button><button className="button text-button" disabled={working} onClick={() => void action("Dismissing status suggestion...", () => post("/api/gmail/review", { id: item.id, action: "dismiss" }))}>Dismiss</button></div></td>
      </tr>)}</tbody>
    </table></div>}
    {state?.connected && state.lastScanAt && !state.suggestions?.length && <p>No unambiguous new status suggestions. Review unmatched or older messages in Gmail yourself.</p>}
    <p className="small muted">Access is read-only but still sensitive. Disconnect revokes locally stored credentials and requests Google revocation; you can also remove access at <a href="https://myaccount.google.com/connections" target="_blank" rel="noreferrer">Google Account connections</a>. Private files rely on your user-account permissions, not application-level encryption.</p>
  </section>;
}
