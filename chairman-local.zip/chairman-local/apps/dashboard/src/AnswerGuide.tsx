import type { Profile } from "./model";
import { Notice } from "./ui";

export const standardAnswers = [
  ["first_name", "Your given name, exactly as you use it."],
  ["last_name", "Your family name. Do not guess how a full name should be split."],
  ["city", "Your current city."],
  ["country", "Your current country."],
  ["work_location", "Your explicitly planned full work location. For location autocomplete, use the exact city, region and country suggestion; the runner never guesses a different place."],
  ["postal_code", "Your current postal or ZIP code."],
  ["notice_period_days", "Your actual notice period in days; 0 only if true."],
  ["available_start_date", "Your confirmed available date, YYYY-MM-DD."],
  ["total_years_experience", "Your actual total professional experience in years."],
  ["years_python", "Your actual Python experience in years; not inferred from skills."],
  ["expected_salary_<CURRENCY>", "Replace <CURRENCY> with the currency, for example expected_salary_INR. Enter your actual annual expectation; no automatic currency conversion."],
  ["willing_to_relocate", "Your own yes/no answer."],
  ["travel_willingness", "Your actual willingness to travel, including any limits."],
] as const;

function hasAnswer(answers: Profile["answers"], key: string) {
  return key === "expected_salary_<CURRENCY>"
    ? Object.entries(answers).some(([name, value]) => /^expected_salary_[A-Z]{3}$/.test(name) && value.trim())
    : !!answers[key]?.trim();
}

export function missingStandardAnswers(profile: Profile): string[] {
  return standardAnswers.filter(([key]) => !hasAnswer(profile.answers, key)).map(([key]) => key);
}

export function AnswerGuide({ profile }: { profile: Profile }) {
  const missing = missingStandardAnswers(profile);
  return <details className="answer-guide">
    <summary>Standard answer key guide <span>{missing.length} not provided</span></summary>
    <p className="small muted">Use these exact keys. A missing answer is not “no,” zero, consent, or permission to infer. Not every employer asks every question; required unanswered fields pause that job. Saved answers are usable only with your confirmed profile.</p>
    <dl>{standardAnswers.map(([key, explanation]) => <div key={key}><dt><code>{key}</code><span className={hasAnswer(profile.answers, key) ? "answer-present" : "muted"}>{hasAnswer(profile.answers, key) ? "Provided · verify accuracy" : "Not provided"}</span></dt><dd>{explanation}</dd></div>)}</dl>
  </details>;
}

const narrativeTemplates = [
  ["cover_letter_template", "Ordinary cover-letter fields"],
  ["motivation_template", "Ordinary “why this role / company” fields"],
] as const;

export function narrativeTemplateIssues(answers: Profile["answers"]): string[] {
  return narrativeTemplates.flatMap(([key]) => {
    const text = answers[key] || "";
    const placeholders = [...text.matchAll(/\{([^{}]*)\}/g)];
    const unknown = [...new Set(placeholders.filter(match => !["company", "role"].includes(match[1]!)).map(match => match[0]))];
    const issues = unknown.length ? [`${key}: unrecognized placeholder${unknown.length === 1 ? "" : "s"} ${unknown.join(", ")}. Only {company} and {role} are supported; no values will be guessed.`] : [];
    if (/[{}]/.test(text.replace(/\{[^{}]*\}/g, ""))) issues.push(`${key}: unmatched or nested braces. Use only the exact placeholders {company} and {role}.`);
    return issues;
  });
}

export function NarrativeTemplateGuide({ answers, onAdd, disabled = false }: { answers: Profile["answers"]; onAdd?: (key: string) => void; disabled?: boolean }) {
  const issues = narrativeTemplateIssues(answers);
  return <section className="narrative-template-guide" aria-label="Optional user-authored narrative templates">
    <h3>Optional narrative templates, in your own words</h3>
    <p>Write an answer once for ordinary cover-letter or “why this role” fields. The runner may substitute only <code>{"{company}"}</code> with the employer’s name and <code>{"{role}"}</code> with the job title. Both come from job metadata. No other wording or claims are generated.</p>
    <dl>{narrativeTemplates.map(([key, purpose]) => <div key={key}><dt><code>{key}</code><span className="muted">{answers[key]?.trim() ? "Provided · review your own wording" : "Not provided · optional"}</span></dt><dd>{purpose}{onAdd && !Object.hasOwn(answers, key) && <button className="text-link" type="button" disabled={disabled} onClick={() => onAdd(key)}>{key === "cover_letter_template" ? "Add blank cover-letter template" : "Add blank motivation template"}</button>}</dd></div>)}</dl>
    <p>These templates never answer assessments or legal declarations and never override No-AI restrictions. If a required narrative has no suitable approved answer or template, that job becomes <strong>Needs your answers</strong> (<code>needs_input</code>). Missing or unrecognized placeholders are not guessed.</p>
    {onAdd && <p className="small muted">Add a blank template, then write it in Application answers below. Nothing is prefilled. Confirm your profile and explicitly reactivate Auto Apply after saving changes.</p>}
    {!!issues.length && <div role="status"><Notice tone="warning"><strong>Template placeholders need correction</strong><ul>{issues.map(issue => <li key={issue}>{issue}</li>)}</ul><p>Replace unsupported placeholders with your own verified wording or one of the two allowed placeholders. Affected required narratives need your input; they cannot be answered by guessing.</p></Notice></div>}
  </section>;
}
