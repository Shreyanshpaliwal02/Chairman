import { useCallback, useEffect, useId, useRef, useState, type FormEvent } from "react";
import { api, post } from "./api";
import { configuredAiAvailable, configuredAiLabel, dateTime, preparationLabel, usesHostedAi, type AutopilotJobStatus, type AutopilotRules, type AutopilotView, type Page, type ReferenceFamily, type ResumeVariant, type RunAction, type State } from "./model";
import { AnswerGuide, NarrativeTemplateGuide, missingStandardAnswers } from "./AnswerGuide";
import { OriginalResume } from "./OriginalResume";
import { Badge, ExternalLink, Field, Icon, Notice } from "./ui";
import { MIN_APPROVED_RESUMES } from "../../../packages/domain/types";
import { CareerLinks } from "./CareerLinks";
import { TailoringPreview } from "./TailoringPreview";
import { HumanAttention } from "./HumanAttention";
import { LiveMonitor, type MonitorConnection } from "./LiveMonitor";

const families: { id: ReferenceFamily; label: string }[] = [
  { id: "software", label: "Software" }, { id: "cloud", label: "Cloud" },
  { id: "data", label: "Data" }, { id: "forward-deployed", label: "Forward deployed" },
  { id: "mlops", label: "MLOps" }, { id: "hybrid", label: "Hybrid" },
];

const jobStatuses: Record<AutopilotJobStatus, { label: string; tone: "neutral" | "positive" | "warning" | "danger" }> = {
  queued: { label: "Queued", tone: "neutral" }, inspecting: { label: "Inspecting form", tone: "warning" },
  prefilling: { label: "Prefilling application", tone: "warning" }, awaiting_human: { label: "Waiting for your review", tone: "warning" },
  needs_input: { label: "Needs your answers", tone: "warning" }, auth_required: { label: "Sign-in required", tone: "warning" },
  captcha_required: { label: "CAPTCHA · your action required", tone: "warning" }, unsupported: { label: "Unsupported · manual", tone: "warning" },
  skipped: { label: "Skipped", tone: "neutral" }, submitting: { label: "Submitting · not confirmed", tone: "warning" },
  submitted_confirmed: { label: "Submission confirmed", tone: "positive" }, submission_unknown: { label: "Unknown · do not retry", tone: "danger" },
  failed: { label: "Failed", tone: "danger" },
};

export function hasAutoApply(state: State): boolean {
  const view = state.autopilot;
  return Array.isArray(state.resumeVariants) && !!view && typeof view.enabled === "boolean" && typeof view.ready === "boolean"
    && typeof view.browserRunning === "boolean" && typeof view.snapshotHash === "string" && !!view.snapshotHash
    && Array.isArray(view.jobs) && Array.isArray(view.blockers) && Array.isArray(view.rules?.providers)
    && Array.isArray(view.rules.employerAllowlist) && typeof view.rules.minimumScore === "number"
    && typeof view.rules.intervalSeconds === "number" && typeof view.rules.stopAtDailyGoal === "boolean"
    && typeof view.rules.allowUnknownSalary === "boolean" && typeof view.rules.allowUnknownSponsorship === "boolean"
    && typeof view.rules.allowUnknownRemoteEligibility === "boolean";
}

interface Props {
  state: State; busy: boolean; run: RunAction; profileDirty: boolean;
  libraryDirty?: boolean;
  visible: boolean; monitor: MonitorConnection;
  navigate: (page: Page) => void; viewPacket: (id: string) => void; onDirty: (dirty: boolean) => void;
}

export function AutoApply(props: Props) {
  if (!hasAutoApply(props.state)) return <Notice tone="warning"><strong>Local service update required.</strong> Auto Apply status and the resume library were not returned. Restart the updated local service, then refresh. No automatic application controls are available until the service reports this capability. <button className="text-link" onClick={() => props.navigate("setup")}>Open setup instructions</button></Notice>;
  return <AutoApplyWorkspace {...props} view={props.state.autopilot!} variants={props.state.resumeVariants!} />;
}

function AutoApplyWorkspace({ state, view, variants, busy, run, profileDirty, libraryDirty, navigate, viewPacket, onDirty, visible, monitor }: Props & { view: AutopilotView; variants: ResumeVariant[] }) {
  const [dirtyParts, setDirtyParts] = useState<Record<string, boolean>>({});
  const [editRevision, setEditRevision] = useState(0);
  const dirty = Object.values(dirtyParts).some(Boolean);
  const setPartDirty = useCallback((part: string, value: boolean) => {
    setDirtyParts(current => current[part] === value ? current : { ...current, [part]: value });
  }, []);
  useEffect(() => { onDirty(dirty); }, [dirty, onDirty]);
  const [consent, setConsent] = useState({ snapshotHash: "", accuracy: false, submission: false, siteRules: false });
  const consentCurrent = consent.snapshotHash === view.snapshotHash;
  const approvedCount = [1, 2, 3, 4, 5, 6, 7, 8].filter(slot => variants.some(variant => variant.slot === slot && variant.approved && !variant.issues.length)).length;
  const missingAnswers = missingStandardAnswers(state.profile);
  const profileReady = state.profile.confirmed && state.profile.facts.length > 0 && state.profile.facts.every(fact => fact.confirmed) && !profileDirty;
  const usableSetup = profileReady && approvedCount >= MIN_APPROVED_RESUMES && (view.ready || view.enabled);
  const [setupOpen, setSetupOpen] = useState(!usableSetup);
  const [authorizationOpen, setAuthorizationOpen] = useState(!view.enabled);
  useEffect(() => { if (view.enabled && usableSetup) setSetupOpen(false); }, [view.enabled, usableSetup]);
  useEffect(() => { setAuthorizationOpen(!view.enabled); }, [view.enabled]);
  const tailored = (view.rules.resumeStrategy ?? "job-tailored") === "job-tailored";
  const tailoringMode = view.rules.tailoringMode ?? "deterministic";
  const aiName = configuredAiLabel(state.runtime.ai);
  const engineReady = !tailored || tailoringMode !== "local-ai" || configuredAiAvailable(state.runtime.ai);
  const pendingSlots = Object.entries(dirtyParts).filter(([part, changed]) => changed && part.startsWith("slot-")).map(([part]) => part.replace("slot-", ""));
  const activationBlockers = [...new Set([
    ...view.blockers,
    ...(!view.ready && !view.blockers.length ? ["The local service has not marked the saved setup ready. Refresh its status."] : []),
    ...(!profileReady ? [profileDirty ? "Profile has unsaved edits. Save or discard them in Profile." : "Confirm every saved profile fact before activating."] : []),
    ...(approvedCount < MIN_APPROVED_RESUMES ? [`Approve at least ${MIN_APPROVED_RESUMES} valid resumes; ${approvedCount} are ready.`] : []),
    ...(!engineReady ? [`The selected ${aiName} engine is unavailable. Review model access and consent in Setup, or explicitly save Evidence-based tailoring.`] : []),
    ...(dirtyParts.rules ? ["Matching rules have unsaved changes. Save matching rules or discard rule edits."] : []),
    ...(libraryDirty ? ["The Resumes page has unsaved library edits. Save or discard them before activation."] : []),
    ...(pendingSlots.length ? [`Resume slot ${pendingSlots.join(", ")} has unsaved edits. Upload the replacement or discard slot edits; editing an optional slot also needs resolution.`] : []),
    ...(state.stats.stopped ? ["The global queue is stopped. Resume the queue before activating."] : [])
  ])];
  const canActivate = !activationBlockers.length && !dirty && !view.enabled;
  useEffect(() => { setConsent({ snapshotHash: view.snapshotHash, accuracy: false, submission: false, siteRules: false }); }, [view.snapshotHash, dirty, profileDirty, libraryDirty, view.enabled, state.runtime.ai.provider, state.runtime.ai.model, state.runtime.ai.consentRequired]);
  const activeJob = view.jobs.find(job => ["submitting", "inspecting", "prefilling"].includes(job.status));
  const activeListing = state.jobs.find(job => job.id === activeJob?.jobId);
  const activeVariant = variants.find(variant => variant.id === activeJob?.variantId);
  const activePacket = state.packets.find(packet => packet.id === activeJob?.packetId);
  const changeConsent = (key: "accuracy" | "submission" | "siteRules", checked: boolean) => setConsent(current => ({ ...current, snapshotHash: view.snapshotHash, [key]: checked }));

  async function activate(event: FormEvent) {
    event.preventDefault();
    if (!canActivate || !consentCurrent || !consent.accuracy || !consent.submission || !consent.siteRules) return;
    await run("Authorizing Auto Apply for this exact saved setup…", async () => {
      await post("/api/autopilot/enable", { snapshotHash: consent.snapshotHash, authorizeSubmission: true, confirmAccuracy: true, confirmSiteRules: true });
    }, "Auto Apply activated for your exact saved profile, uploaded resumes, and rules. It may submit matching supported applications without per-job review.");
  }

  return <div className="auto-apply-view">
    <section className="autopilot-console" aria-labelledby="runner-title">
      <div className="section-heading"><div><h2 id="runner-title">Your local application runner</h2><p>Proactive job discovery. JD-matched resumes from your approved templates. Partial autofill with human review when needed.</p></div><Badge tone={state.stats.stopped ? "danger" : view.enabled ? "positive" : "neutral"}>{state.stats.stopped ? "Submission queue stopped" : view.enabled ? "Auto Apply active" : "Auto Apply paused"}</Badge></div>
      <div className="runner-status" role="status" aria-live="polite"><strong>{view.status || "Waiting for service status"}</strong><span>{view.browserRunning ? "Dedicated local Chrome is running" : "Dedicated local Chrome is not running"}</span>
        <p>Saved mode: {tailored ? `JD-tailored / ${tailoringMode === "local-ai" ? aiName : "deterministic"}` : "Send original unchanged"}</p>
        {tailored && tailoringMode === "local-ai" && usesHostedAi(state.runtime.ai) && <p>Hosted AI: {state.runtime.ai.provider === "gemini" ? "Google Gemini" : "GitHub Copilot"} · {state.runtime.ai.model || "Model not reported"} · {state.runtime.ai.provider === "gemini" ? "anonymous IDs and public technology tags only; separate consent and a Free Google project with billing disabled are required." : "separate processing consent and Copilot allowance apply."}</p>}
        {activeJob && <p>{activeListing ? `${activeListing.company} · ${activeListing.title}` : `Job ${activeJob.jobId}`} · {jobStatuses[activeJob.status]?.label || activeJob.status}<br />Selected base: {activePacket?.tailoring ? `${activePacket.tailoring.baseVariantLabel} · ${activePacket.tailoring.baseVariantId}` : activeVariant ? `Slot ${activeVariant.slot} · ${activeVariant.label}` : activeJob.variantId || "Not selected yet"}<br />{activePacket ? `${preparationLabel(activePacket.draft.mode, activePacket.tailoring?.engine)} · ${activePacket.artifacts.map(artifact => artifact.filename).join(", ") || "Artifact not available yet"}` : "Exact packet not loaded or not prepared yet."}</p>}
      </div>
      <div className="button-row">
        <button className="button danger-quiet" disabled={busy || !view.enabled} onClick={() => void run("Pausing Auto Apply…", async () => { await post("/api/autopilot/pause", {}); }, "Auto Apply paused. An in-flight submission may still complete. Check its receipt before taking further action.")}><Icon name="pause" />Pause Auto Apply</button>
        <button className="button danger-quiet" disabled={busy || (state.stats.stopped && !view.enabled)} onClick={() => void run("Stopping application attempts…", async () => { await Promise.all([post("/api/control", { stopped: true }), post("/api/autopilot/pause", {})]); }, "Auto Apply paused and submission queue stopped. In-flight attempts may still complete; stopping is not withdrawal.")}>Stop all submissions</button>
        <button className="button secondary" disabled={busy} onClick={() => void run("Opening dedicated local Chrome…", async () => { await post("/api/autopilot/browser", {}); }, "Dedicated Chrome setup requested. Sign in yourself only if needed; opening Chrome does not activate Auto Apply.")}><Icon name="external" />Open local Chrome</button>
        <button className="button text-button" disabled={busy || !view.enabled || state.stats.stopped} onClick={() => void run("Requesting one Auto Apply cycle…", async () => { await post("/api/autopilot/run-one", {}); }, "One cycle requested. Watch the live status; a queued cycle is not a confirmed application.")}>Run one cycle now</button>
      </div>
      <dl className="runner-times"><div><dt>Last cycle</dt><dd>{dateTime(view.lastRunAt)}</dd></div><div><dt>Next cycle</dt><dd>{view.enabled && !state.stats.stopped ? dateTime(view.nextRunAt) : "Not active"}</dd></div><div><dt>Consent expires</dt><dd>{view.authorization ? dateTime(view.authorization.expiresAt) : "Not authorized"}</dd></div></dl>
      <p className="small muted">Keep your computer awake and the local service running. This uses a dedicated Chrome profile, not your existing browser sessions. Login, MFA, CAPTCHA, legal declarations, assessments, and unknown fields require your attention; nothing bypasses them.</p>
    </section>

    <HumanAttention state={state} busy={busy} run={run} viewPacket={viewPacket} />
    <LiveMonitor state={state} visible={visible} connection={monitor} />
    <CareerLinks state={state} busy={busy} run={run} />

    <details className="auto-setup" open={setupOpen} onToggle={event => setSetupOpen(event.currentTarget.open)}>
    <summary>Profile, resumes & matching rules <span>{usableSetup ? "Saved setup ready · review or change" : "Complete your one-time setup"}</span></summary>
    <p className="small muted">Auto Apply selects an approved base and prepares matching applications for you. Manually drafting a resume for every role is not required.</p>
    <nav className="autopilot-steps" aria-label="Auto Apply setup steps"><ol>
      <li><a href="#auto-profile"><span>1</span><strong>Confirm profile</strong><small>{profileReady ? "Confirmed" : "Needs review"}</small></a></li>
      <li><a href="#auto-resumes"><span>2</span><strong>Upload at least {MIN_APPROVED_RESUMES} resumes</strong><small>{approvedCount} approved · {MIN_APPROVED_RESUMES} minimum</small></a></li>
      <li><a href="#auto-rules"><span>3</span><strong>Review rules & answers</strong><small>{dirtyParts.rules ? "Unsaved rule edits" : "Use saved facts only"}</small></a></li>
      <li><a href="#auto-activate" onClick={() => setAuthorizationOpen(true)}><span>4</span><strong>Explicitly activate</strong><small>{view.enabled ? "Active consent" : "Not automatic on upload"}</small></a></li>
    </ol></nav>

    <section className="auto-section" id="auto-profile"><div className="section-heading"><div><h2>1. Confirm your profile</h2><p>Your identity, preferences, and factual answer bank must be reviewed and saved.</p></div><button className="button secondary" onClick={() => navigate("profile")}>{profileReady ? "Review saved profile" : "Review & confirm profile"}<Icon name="arrow" size={15} /></button></div>
      <div className="profile-snapshot"><strong>{state.profile.name || "Name not provided"}</strong><span>{state.profile.email || "Email not provided"} · {state.profile.location || "Location not provided"}</span><Badge tone={profileReady ? "positive" : "warning"}>{profileDirty ? "Unsaved profile edits" : state.profile.confirmed ? `Confirmed · version ${state.profile.version}` : "Not confirmed"}</Badge></div>
      <p className="small muted">Saving profile, resume-library, or rule changes pauses the previous authorization. Review and explicitly activate the new saved setup; unsaved edits are never application inputs.</p>
    </section>

    <section className="auto-section" id="auto-resumes"><div className="section-heading"><div><h2>2. Upload at least {MIN_APPROVED_RESUMES} templates/originals</h2><p>Use any two or more of the eight slots, one per role family (assign slots in Progress → Role families). Extra slots are optional. Only approved, valid files can be selected as bases or sent unchanged in original mode; unused, unapproved, or invalid extra slots do not count or block activation.</p></div><Badge tone={approvedCount >= MIN_APPROVED_RESUMES ? "positive" : "warning"}>{approvedCount} approved · minimum {MIN_APPROVED_RESUMES}</Badge></div>
      <Notice><strong>Check identity and every claim in each file.</strong> Compare the name, email, dates, skills, and experience against your confirmed profile. Extraction checks cannot prove accuracy. Approved templates guide job-specific resumes; template-only claims must first become confirmed profile facts. Derived PDF/DOCX files use a clean ATS-safe layout that may differ from your uploaded PDF. Originals stay untouched.</Notice>
      <div className="variant-grid">{[1, 2, 3, 4, 5, 6, 7, 8].map(slot => <VariantSlot key={`${slot}:${editRevision}`} slot={slot} variant={variants.find(variant => variant.slot === slot)} busy={busy} run={run} onDirty={setPartDirty} />)}</div>
      <button className="text-link" onClick={() => navigate("resumes")}>Open resume library & reference drafts<Icon name="arrow" size={14} /></button>
      <details className="advanced-preparation"><summary>Advanced: manual resume preview</summary><TailoringPreview state={state} busy={busy} savedProfileReady={profileReady} setupDirty={dirty || !!libraryDirty} run={run} viewPacket={viewPacket} /></details>
    </section>

    <section className="auto-section" id="auto-rules"><h2>3. Review matching rules & saved answers</h2>
      <RulesEditor key={editRevision} rules={view.rules} ai={state.runtime.ai} busy={busy} run={run} onDirty={setPartDirty} />
      <div className="saved-answer-review"><h3>Factual answer bank</h3><p className="small muted">{missingAnswers.length ? `${missingAnswers.length} standard answer keys have not been provided. Missing required answers stop that job; the runner does not guess.` : "All standard answer keys have a value. Confirm their accuracy and meaning; some forms may still need other answers."}</p>
        <AnswerGuide profile={state.profile} />
        <NarrativeTemplateGuide answers={state.profile.answers} />
        <details className="saved-answers"><summary>Review saved answer values <span>{Object.keys(state.profile.answers).length} saved</span></summary>{Object.keys(state.profile.answers).length ? <dl className="detail-grid">{Object.entries(state.profile.answers).map(([key, value]) => <div className="artifact-row" key={key}><dt><code>{key}</code></dt><dd>{value.trim() || "Not answered"}</dd></div>)}</dl> : <p className="small muted">No factual answers saved. Add only answers you know to be true.</p>}</details>
        <button className="button secondary compact" onClick={() => navigate("profile")}>Edit answers in Profile</button>
      </div>
    </section>
    </details>

    <details className="authorization-details" open={authorizationOpen} onToggle={event => setAuthorizationOpen(event.currentTarget.open)}><summary>{view.enabled ? "Active authorization · review saved scope" : "Review & activate Auto Apply"}</summary>
    <section className="auto-section activation-section" id="auto-activate"><h2>Authorize this exact saved setup</h2>
      <p>One explicit activation replaces per-job packet approval only within your saved rules on selected supported providers. Uploading, approving a file, opening Chrome, or pairing the extension does not activate it.</p>
      {!!activationBlockers.length && <Notice tone="warning"><strong>What still prevents activation</strong><ul>{activationBlockers.map((blocker, index) => <li key={index}>{blocker}</li>)}</ul>
        <div className="button-row">{(!profileReady || profileDirty) && <button className="button secondary compact" onClick={() => navigate("profile")}>Review or save Profile</button>}
          {dirtyParts.rules && <a className="text-link" href="#auto-rules" onClick={() => setSetupOpen(true)}>Review unsaved matching rules</a>}
          {!!pendingSlots.length && <a className="text-link" href="#auto-resumes" onClick={() => setSetupOpen(true)}>Review unsaved resume slots</a>}
          {dirty && <button className="button secondary compact" disabled={busy} onClick={() => {
            if (!window.confirm("Discard unsaved resume-slot and matching-rule edits? Your saved profile, resumes and rules will not change.")) return;
            setDirtyParts({}); setEditRevision(value => value + 1);
          }}>Discard unsaved Auto Apply edits</button>}
          {state.stats.stopped && <button className="button secondary compact" disabled={busy} onClick={() => void run("Resuming the submission queue…", async () => { await post("/api/control", { stopped: false }); }, "Queue resumed. Review the authorization checkboxes and activate separately; no consent was granted.")}>Resume queue for activation</button>}
        </div>
      </Notice>}
      <dl className="activation-summary"><div><dt>Providers</dt><dd>{view.rules.providers.map(provider => provider === "ashby" ? "Ashby" : provider === "greenhouse" ? "Greenhouse" : "Generic career forms").join(", ") || "None selected"}</dd></div><div><dt>Minimum match</dt><dd>{view.rules.minimumScore} / 100</dd></div><div><dt>Templates/originals</dt><dd>{approvedCount} approved, valid · minimum {MIN_APPROVED_RESUMES}</dd></div><div><dt>Resume mode</dt><dd>{tailored ? "Tailor to each job description" : "Send original unchanged"}</dd></div><div><dt>Engine</dt><dd>{tailored ? tailoringMode === "local-ai" ? `${aiName} · ${state.runtime.ai.model || "Model not reported"}` : "Evidence-based · deterministic" : "None · original bytes preserved"}</dd></div><div><dt>Base selection</dt><dd>Best matching approved, valid file for each job</dd></div><div><dt>Your daily attempt cap</dt><dd>{state.stats.limit === null ? "Unlimited — no daily cap" : state.stats.limit.toLocaleString()}</dd></div><div><dt>Human-in-the-loop</dt><dd>{view.rules.humanInLoop === undefined ? "Unavailable · review updated rules" : view.rules.humanInLoop ? "Pause with prefilled tabs for your review" : "Not enabled"}</dd></div><div><dt>Proactive discovery</dt><dd>{view.rules.autoDiscover === undefined ? "Unavailable · review updated rules" : view.rules.autoDiscover ? "Enabled within saved source scope" : "Not enabled"}</dd></div></dl>
      {tailored && tailoringMode === "local-ai" && usesHostedAi(state.runtime.ai) && <Notice>Configured AI uses hosted Copilot processing for bounded confirmed resume-fact and job-description text and consumes your Copilot allowance. Application authorization below does not grant remote-processing consent. <button className="text-link" onClick={() => navigate("setup")}>Review AI provider & privacy</button></Notice>}
      {!!state.careerSources?.some(source => source.enabled) && <div className="saved-answers"><h3>Added career sources in this authorization</h3><ul>{state.careerSources.filter(source => source.enabled).map(source => <li key={source.id}><ExternalLink href={source.target?.boardUrl ?? source.inputUrl}>{source.label}</ExternalLink>{source.target?.jobId ? " · Single job" : " · Career board"}</li>)}</ul><p className="small muted">Future matching jobs from these enabled sources will be considered under the saved rules. Adding or changing a source requires a fresh activation.</p></div>}
      {state.stats.limit === null && <p className="small muted">A daily cap is optional. Unlimited mode does not block the checkboxes or activation; site limits still apply.</p>}
      <p className="small muted">These checkboxes record your review of the saved setup. They do not start applications. The activation button stays disabled until every requirement above is resolved and all three boxes are checked.</p>
      <form onSubmit={event => void activate(event)}><fieldset className="consent-checks" disabled={busy || view.enabled}><legend>Your explicit authorization</legend>
        <label className="checkbox-label"><input type="checkbox" required checked={consentCurrent && consent.accuracy} onChange={event => changeConsent("accuracy", event.target.checked)} /><span>I reviewed the approved, valid uploaded resumes, my saved profile, factual answers, and any user-authored narrative templates. I confirm their identity details and claims are accurate. Unapproved or invalid extra files are not authorized for use.</span></label>
        <label className="checkbox-label"><input type="checkbox" required checked={consentCurrent && consent.submission} onChange={event => changeConsent("submission", event.target.checked)} /><span>{tailored ? <>I authorize creating JD-specific derived PDF/DOCX resumes from my approved templates and confirmed profile facts using {tailoringMode === "local-ai" ? aiName : "the evidence-based deterministic engine"}, with only truthful, supported keywords. Originals remain untouched. I authorize automatic submission of these derived resumes</> : <>I authorize automatic submission of my approved original resumes, byte-for-byte unchanged, with no tailoring</>} and my saved answers to matching jobs on the selected supported providers, within my saved rules, <strong>without reviewing or approving each job separately</strong>. This includes my selected generic career forms, proactive discovery, and human-in-the-loop settings above. Common and multi-step forms may be partially filled; support is not a guarantee for every portal. This includes any user-authored narrative templates I saved, with only <code>{"{company}"}</code> and <code>{"{role}"}</code> substitutions from job metadata.</span></label>
        <label className="checkbox-label"><input type="checkbox" required checked={consentCurrent && consent.siteRules} onChange={event => changeConsent("siteRules", event.target.checked)} /><span>I acknowledge site terms, eligibility constraints, source limits, and No-AI restrictions still apply. This does not answer assessments or accept employer legal declarations. A goal of 500 per day is not a guarantee of applications, interviews, offers, sponsorship, or compensation.</span></label>
      </fieldset><button className="button primary" type="submit" disabled={busy || !canActivate || !consentCurrent || !consent.accuracy || !consent.submission || !consent.siteRules}><Icon name="autopilot" />{view.enabled ? "Auto Apply is active" : "Activate Auto Apply"}</button></form>
      <p className="small muted">No hard global daily or session cap unless you set one. Your optional cap, stop-at-goal rule, and lower source/site limits still apply. LinkedIn, Naukri, Wellfound, and unsupported destinations remain manual. No-AI applications use your own words and a manual workflow.</p>
      <details className="artifact-details"><summary>Saved consent fingerprint</summary><span className="hash-value">{view.snapshotHash}</span>{view.authorization && <p className="small muted">Authorization {view.authorization.id} · granted {dateTime(view.authorization.approvedAt)}</p>}</details>
    </section>
    </details>

    <section className="auto-section" aria-labelledby="auto-jobs-title"><div className="section-heading"><div><h2 id="auto-jobs-title">Application activity & receipts</h2><p>A form fill, upload, attempt, or click is not a confirmed submission. Live updates have a five-second polling fallback.</p></div><button className="text-link" onClick={() => navigate("applications")}>Complete application history<Icon name="arrow" size={14} /></button></div>
      {!view.jobs.length ? <div className="quiet-empty"><h3>No Auto Apply attempts yet</h3><p>Complete the four setup steps and activate when you are ready. Manual application history remains in Applications.</p></div> : <ul className="autopilot-job-list">{[...view.jobs].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).map(item => {
        const job = state.jobs.find(job => job.id === item.jobId);
        const variant = variants.find(variant => variant.id === item.variantId);
        const packet = state.packets.find(packet => packet.id === item.packetId);
        const status = jobStatuses[item.status] || { label: item.status, tone: "warning" as const };
        const hasHumanTask = !!item.humanTaskId || view.humanTasks?.some(task => task.jobId === item.jobId);
        const retryable = !hasHumanTask && ["needs_input", "auth_required", "captcha_required"].includes(item.status);
        return <li key={item.id} className={item.status === "submission_unknown" ? "unknown-outcome" : ""}><div className="autopilot-job-header"><div><h3>{job ? `${job.company} · ${job.title}` : `Job ${item.jobId}`}</h3><p>Selected base: {packet?.tailoring ? `${packet.tailoring.baseVariantLabel} · ${packet.tailoring.baseVariantId}` : variant ? `Slot ${variant.slot} · ${variant.label} · ${variant.originalFilename}` : item.variantId ? `Archived variant ${item.variantId}` : "Not selected yet"}</p>{packet ? <><p>{preparationLabel(packet.draft.mode, packet.tailoring?.engine)} · Exact {packet.draft.mode === "jd-tailored" ? "derived documents" : "documents"}: {packet.artifacts.map(artifact => artifact.filename).join(", ") || "Not available"}</p>{packet.submissionArtifactSha256 && <p><strong>Submission artifact SHA-256</strong><span className="hash-value">{packet.submissionArtifactSha256}</span></p>}</> : item.packetId && <p className="small muted">Exact packet metadata is not loaded. Open the packet to verify its document and provenance.</p>}</div><Badge tone={status.tone}>{status.label}</Badge></div>
          <p className="autopilot-job-reason">{item.reason || "No additional reason reported."}</p>
          {item.status === "submission_unknown" && <Notice tone="danger"><strong>Unknown outcome: never retry automatically.</strong> This application may have reached the employer. Check the actual application and any receipt yourself before reconciling its outcome in Applications.</Notice>}
          {packet?.confirmation && <p className="receipt-evidence"><strong>Recorded receipt:</strong> {packet.confirmation}</p>}
          {item.status === "submitted_confirmed" && !packet?.confirmation && <p className="small muted">The service recorded a confirmation. Open the exact packet to inspect its saved evidence.</p>}
          <div className="button-row">{job ? <ExternalLink href={job.applyUrl}>Open actual application</ExternalLink> : <button className="text-link" onClick={() => navigate("opportunities")}>Find listing in Opportunities</button>}
            {item.status === "needs_input" && <button className="button secondary compact" onClick={() => navigate("profile")}>Add factual answers in Profile</button>}
            {!hasHumanTask && ["auth_required", "captcha_required", "needs_input"].includes(item.status) && <button className="button secondary compact" disabled={busy || !job} onClick={() => void run("Opening this application in dedicated Chrome…", async () => { await post("/api/autopilot/browser", { url: job!.applyUrl }); }, "Application opened in dedicated Chrome. Address the blocker yourself; no password or login token belongs in this dashboard.")}>Open in local Chrome</button>}
            {hasHumanTask && <a className="text-link" href="#human-attention">Review existing session above</a>}
            {item.packetId && <button className="button secondary compact" onClick={() => viewPacket(item.packetId!)}>View exact packet & receipt</button>}
            {retryable && <button className="button secondary compact" disabled={busy || !view.enabled || state.stats.stopped || dirty || profileDirty} onClick={() => void run("Rechecking the addressed blocker…", async () => { await post(`/api/autopilot/jobs/${encodeURIComponent(item.id)}/retry`, {}); }, "Safe recheck requested. The server revalidates consent and form state; this is not a submission confirmation.")}>I addressed the blocker · recheck</button>}
          </div><p className="small muted">Updated {dateTime(item.updatedAt)} · Attempt {item.id}</p>
        </li>;
      })}</ul>}
    </section>
    <details className="advanced-preparation"><summary>Advanced: manual workflows & browser setup</summary><p className="small muted">The local runner handles Ashby, Greenhouse, and common generic career forms, including bounded multi-step flows. Some portals still need a manual handoff. The separate Chrome assistant helps you review and explicitly fill permitted pages without activating this runner. Public cloud discovery contains no personal data or account access.</p><div className="button-row"><button className="button secondary" onClick={() => navigate("opportunities")}>Manual preparation</button><button className="button secondary" onClick={() => navigate("resumes")}>Resume library</button><button className="button secondary" onClick={() => navigate("setup")}>Setup & privacy</button></div></details>
  </div>;
}

export function VariantSlot({ slot, variant, busy, run, onDirty }: { slot: number; variant?: ResumeVariant; busy: boolean; run: RunAction; onDirty: (part: string, dirty: boolean) => void }) {
  const titleId = useId();
  const [label, setLabel] = useState(variant?.label || "");
  const [tags, setTags] = useState<ReferenceFamily[]>(variant?.families || []);
  const [file, setFile] = useState<File | null>(null);
  const [dirty, setDirty] = useState(false);
  const [reviewed, setReviewed] = useState(false);
  const [validation, setValidation] = useState("");
  const fileInput = useRef<HTMLInputElement>(null);
  useEffect(() => { onDirty(`slot-${slot}`, dirty); }, [dirty, onDirty, slot]);
  useEffect(() => { if (!dirty) { setLabel(variant?.label || ""); setTags(variant?.families || []); } }, [variant, dirty]);
  useEffect(() => { setReviewed(false); }, [variant?.id, variant?.approved, variant?.artifact.sha256]);
  function changed() { setDirty(true); setReviewed(false); setValidation(""); }
  function discard() {
    setLabel(variant?.label || ""); setTags(variant?.families || []); setFile(null); setDirty(false); setReviewed(false); setValidation("");
    if (fileInput.current) fileInput.current.value = "";
  }
  async function upload(event: FormEvent) {
    event.preventDefault();
    if (!file || !label.trim() || !tags.length) { setValidation("Choose one original PDF or DOCX, a label, and at least one role tag."); return; }
    if (!/\.(pdf|docx)$/i.test(file.name) || file.size === 0) { setValidation("Choose a non-empty PDF or DOCX file. Plain text cannot be used as an original resume variant."); return; }
    if (variant && !window.confirm(`Replace slot ${slot} (${variant.originalFilename})? This pauses the previous Auto Apply consent. Already submitted applications are unchanged.`)) return;
    await run(`Uploading original resume to slot ${slot}…`, async () => {
      const form = new FormData();
      form.append("label", label.trim()); form.append("families", JSON.stringify(tags));
      if (reviewed) form.append("approved", "true");
      form.append("file", file);
      await api<{ variant: ResumeVariant }>(`/api/resume-variants/${slot}`, { method: "POST", body: form });
      discard();
    }, `Slot ${slot} uploaded unchanged. Review any validation issues. Uploading does not activate Auto Apply.`);
  }
  return <article className="variant-slot" aria-labelledby={titleId}><div className="section-heading"><h3 id={titleId}>Resume slot {slot}</h3><Badge tone={variant?.issues.length ? "danger" : variant?.approved ? "positive" : "neutral"}>{variant?.issues.length ? "Needs correction" : variant?.approved ? "Accuracy approved" : variant ? "Not approved" : "Empty slot"}</Badge></div>
    {variant && <div className="saved-variant"><strong>{variant.label}</strong><p className="variant-filename">{variant.originalFilename}</p><div className="tag-group">{variant.families.map(family => <Badge key={family}>{families.find(item => item.id === family)?.label || family}</Badge>)}</div>
      <p className="small muted">{variant.artifact.format.toUpperCase()} · {variant.artifact.bytes.toLocaleString()} bytes · {variant.textLength.toLocaleString()} extracted characters<br />Original file · uploaded {dateTime(variant.uploadedAt)}</p>
      {!!variant.issues.length && <Notice tone="danger"><strong>Identity / file checks need attention</strong><ul>{variant.issues.map((issue, index) => <li key={index}>{issue}</li>)}</ul><p>Correct the original file or profile and upload again. Approval cannot override these checks.</p></Notice>}
      <OriginalResume path={`/api/resume-variants/${encodeURIComponent(variant.id)}/file`} filename={variant.originalFilename} format={variant.artifact.format} busy={busy} run={run} />
      <details className="artifact-details"><summary>Original file fingerprint</summary><span className="hash-value">{variant.artifact.sha256}</span></details>
      {!variant.approved && !file && <><label className="checkbox-label variant-approval"><input type="checkbox" checked={reviewed} disabled={busy || dirty || !!variant.issues.length} onChange={event => setReviewed(event.target.checked)} />I opened this exact file and verified its identity details, dates, and every claim are accurate.</label><button className="button secondary compact" disabled={busy || dirty || !reviewed || !!variant.issues.length} onClick={() => void run(`Approving accuracy of slot ${slot}…`, async () => { await post(`/api/resume-variants/${encodeURIComponent(variant.id)}/approval`, { approved: true }); setReviewed(false); }, `Slot ${slot} accuracy approved. Auto Apply is still a separate explicit activation.`)}>Approve slot {slot} accuracy</button></>}
      <div className="button-row">{variant.approved && <button className="button text-button compact" disabled={busy} onClick={() => void run(`Revoking slot ${slot} approval…`, async () => { await post(`/api/resume-variants/${encodeURIComponent(variant.id)}/approval`, { approved: false }); setReviewed(false); }, "Resume approval revoked. Previous Auto Apply consent is paused.")}>Revoke approval</button>}
        <button className="button text-button danger-text compact" disabled={busy} onClick={() => {
          if (!window.confirm(`Remove resume slot ${slot}? This pauses Auto Apply and removes this file from the active library. It does not withdraw applications.`)) return;
          void run(`Removing resume slot ${slot}…`, async () => { await post(`/api/resume-variants/${encodeURIComponent(variant.id)}/remove`, {}); discard(); }, "Resume removed from the library. Previous consent is no longer active.");
        }}>Remove slot {slot}</button></div>
    </div>}
    <details className="variant-replacement" open={!variant}><summary>{variant ? "Replace original / edit role tags" : "Add your original file"}</summary><form onSubmit={event => void upload(event)} className="variant-upload">
      <Field label={`Slot ${slot} label`}>{id => <input id={id} value={label} required disabled={busy} placeholder="e.g. Cloud engineering resume" onChange={event => { changed(); setLabel(event.target.value); }} />}</Field>
      <fieldset className="role-tag-options" disabled={busy}><legend>Role tags · choose at least one</legend>{families.map(family => <label className="checkbox-label" key={family.id}><input type="checkbox" checked={tags.includes(family.id)} onChange={event => { changed(); setTags(event.target.checked ? [...tags, family.id] : tags.filter(tag => tag !== family.id)); }} />{family.label}</label>)}</fieldset>
      <Field label={`Original PDF or DOCX for slot ${slot}`}>{id => <input id={id} ref={fileInput} type="file" accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document" disabled={busy} onChange={event => { changed(); setFile(event.target.files?.[0] || null); }} />}</Field>
      {file && <><p className="small variant-filename">{file.name} · {file.size.toLocaleString()} bytes</p><label className="checkbox-label variant-approval"><input type="checkbox" checked={reviewed} disabled={busy} onChange={event => setReviewed(event.target.checked)} /><span>I opened this exact file and verified my name, contact details, dates, and every claim. Approve its accuracy when uploaded. <strong>This does not activate Auto Apply.</strong></span></label></>}
      {validation && <p className="field-error" role="alert">{validation}</p>}
      <div className="button-row"><button className="button secondary compact" type="submit" disabled={busy || !file || !label.trim() || !tags.length}><Icon name="upload" size={15} />{variant ? `Replace slot ${slot}` : `Upload slot ${slot}`}</button>{dirty && <button className="button text-button compact" type="button" disabled={busy} onClick={discard}>Discard slot edits</button>}</div>
      {dirty && !file && <p className="small muted">Select a file to save this slot’s label and tags. The existing original and its saved tags are unchanged until upload.</p>}
    </form></details>
  </article>;
}

function RulesEditor({ rules, ai, busy, run, onDirty }: { rules: AutopilotRules; ai: State["runtime"]["ai"]; busy: boolean; run: RunAction; onDirty: (part: string, value: boolean) => void }) {
  const defaults = (value: AutopilotRules) => ({ ...structuredClone(value), humanInLoop: value.humanInLoop ?? true, autoDiscover: value.autoDiscover ?? true,
    requireRoleFamily: value.requireRoleFamily ?? true, maxWaitingTabs: value.maxWaitingTabs ?? 10, aiAnswers: value.aiAnswers ?? "saved-only" as const });
  const [draft, setDraft] = useState(() => defaults(rules));
  const [employers, setEmployers] = useState(rules.employerAllowlist.join("\n"));
  const [dirty, setDirty] = useState(false);
  const [validation, setValidation] = useState("");
  useEffect(() => { onDirty("rules", dirty); }, [dirty, onDirty]);
  useEffect(() => { if (!dirty) { setDraft(defaults(rules)); setEmployers(rules.employerAllowlist.join("\n")); } }, [rules, dirty]);
  function update(change: Partial<AutopilotRules>) { setDraft(current => ({ ...current, ...change })); setDirty(true); setValidation(""); }
  async function save(event: FormEvent) {
    event.preventDefault();
    if (!draft.providers.length || !Number.isSafeInteger(draft.minimumScore) || draft.minimumScore < 0 || draft.minimumScore > 100 || !Number.isSafeInteger(draft.intervalSeconds) || draft.intervalSeconds < 1) {
      setValidation("Choose at least one supported provider, a whole-number score from 0 to 100, and a positive whole-number interval."); return;
    }
    if (!Number.isSafeInteger(draft.maxWaitingTabs) || draft.maxWaitingTabs! < 1 || draft.maxWaitingTabs! > 50) { setValidation("Tabs waiting for you must be a whole number from 1 to 50."); return; }
    await run("Saving Auto Apply rules…", async () => {
      await post("/api/autopilot/rules", { rules: { ...draft, employerAllowlist: employers.split(/[,\n]/).map(value => value.trim()).filter(Boolean) } });
      setDirty(false); setValidation("");
    }, "Rules saved. Previous Auto Apply consent is paused; review and explicitly activate the updated setup.");
  }
  return <form className="autopilot-rules" onSubmit={event => void save(event)}>
    <div className="form-grid">
      <Field label="Resume mode" hint="Changing mode or engine pauses previous authorization when saved. Review and authorize the new setup.">{id => <select id={id} value={draft.resumeStrategy ?? "job-tailored"} disabled={busy} onChange={event => update({ resumeStrategy: event.target.value as AutopilotRules["resumeStrategy"] })}><option value="job-tailored">Tailor to each job description (Recommended)</option><option value="original">Send original unchanged</option></select>}</Field>
      {(draft.resumeStrategy ?? "job-tailored") === "job-tailored" && <Field label="Tailoring engine">{id => <select id={id} value={draft.tailoringMode ?? "deterministic"} disabled={busy} onChange={event => update({ tailoringMode: event.target.value as AutopilotRules["tailoringMode"] })}><option value="deterministic">Evidence-based (no model/API cost)</option><option value="local-ai">{configuredAiLabel(ai)}</option></select>}</Field>}
    </div>
    {(draft.resumeStrategy ?? "job-tailored") === "job-tailored" ? <><p className="small muted">Each qualified job gets a derived resume based on an approved template, its job description, and confirmed evidence only. Missing keywords are not invented claims. The clean ATS-safe layout may differ from your original; no ATS score is promised.</p>{(draft.tailoringMode ?? "deterministic") === "local-ai" && usesHostedAi(ai) && <Notice>AI-assisted tailoring uses hosted Copilot · {ai.model || "model not reported"}. Bounded confirmed resume-fact and JD text leaves this device under separately saved consent and uses your Copilot allowance. Choosing this engine alone does not grant consent or establish SDK model access.</Notice>}{(draft.tailoringMode ?? "deterministic") === "local-ai" && !configuredAiAvailable(ai) && <Notice tone="warning">{configuredAiLabel(ai)} is unavailable. {ai.reason || "Review the provider, exact model access, and processing consent in Setup, or select the evidence-based engine."} Saving this rule does not make the runner ready; server blockers still apply.</Notice>}</> : <p className="small muted">Original mode selects an approved, valid upload and sends that file byte-for-byte unchanged, in its original PDF or DOCX format. No JD-specific derived resume is created.</p>}
    <fieldset className="provider-options" disabled={busy}><legend>Allowed form providers</legend>{(["ashby", "greenhouse", "generic"] as const).map(provider => <label className="checkbox-label" key={provider}><input type="checkbox" checked={draft.providers.includes(provider)} onChange={event => update({ providers: event.target.checked ? [...draft.providers, provider] : draft.providers.filter(item => item !== provider) })} />{provider === "ashby" ? "Ashby" : provider === "greenhouse" ? "Greenhouse" : "Generic career forms"}</label>)}</fieldset>
    <p className="small muted">Generic support covers common fields and bounded multi-step career forms, with partial autofill and human handoff. It does not promise support for every portal. Restricted sites, login, CAPTCHA, assessments, legal terms, and No-AI rules still pause or require manual work.</p>
    <div className="checkbox-stack"><label className="checkbox-label"><input type="checkbox" checked={draft.humanInLoop} disabled={busy} onChange={event => update({ humanInLoop: event.target.checked })} />Keep prefilled applications open for human review</label><label className="checkbox-label"><input type="checkbox" checked={draft.autoDiscover} disabled={busy} onChange={event => update({ autoDiscover: event.target.checked })} />Proactively discover jobs from enabled sources</label><label className="checkbox-label"><input type="checkbox" checked={draft.requireRoleFamily} disabled={busy} onChange={event => update({ requireRoleFamily: event.target.checked })} />Only apply to roles in my role families (Progress → Role families)</label></div>
    <div className="form-grid"><Field label="Tabs waiting for you" hint="1–50. Each application that needs a CAPTCHA or an answer keeps its tab open in the Chairman window; new ones start only below this number. Many tabs use a lot of memory.">{id => <input id={id} required type="number" min={1} max={50} step={1} value={draft.maxWaitingTabs} disabled={busy} onChange={event => update({ maxWaitingTabs: Number(event.target.value) })} />}</Field>
      <Field label="AI help on forms" hint="Needs Copilot (or another AI provider) signed in under Setup. Deterministic saved answers are always used first.">{id => <select id={id} value={draft.aiAnswers} disabled={busy} onChange={event => update({ aiAnswers: event.target.value as NonNullable<AutopilotRules["aiAnswers"]> })}><option value="saved-only">Match new wordings to my saved answers (Recommended)</option><option value="all">Also send AI-drafted answers checked against my confirmed facts</option><option value="off">Off: saved answers only</option></select>}</Field></div>
    {(rules.humanInLoop === undefined || rules.autoDiscover === undefined) && <Notice tone="warning">The service has not reported the new discovery and human-review settings. These recommended defaults are not saved consent. Save matching rules and explicitly reactivate before relying on them.</Notice>}
    <div className="form-grid"><Field label="Minimum match score (0–100)">{id => <input id={id} required type="number" min={0} max={100} step={1} value={draft.minimumScore} disabled={busy} onChange={event => update({ minimumScore: Number(event.target.value) })} />}</Field><Field label="Cycle interval (seconds)" hint="30 seconds by default. This is not a throughput promise or a way around site limits.">{id => <input id={id} required type="number" min={1} step={1} value={draft.intervalSeconds} disabled={busy} onChange={event => update({ intervalSeconds: Number(event.target.value) })} />}</Field></div>
    <div className="checkbox-stack"><label className="checkbox-label"><input type="checkbox" checked={draft.allowUnknownSalary} disabled={busy} onChange={event => update({ allowUnknownSalary: event.target.checked })} />Include jobs with undisclosed salary</label><label className="checkbox-label"><input type="checkbox" checked={draft.allowUnknownSponsorship} disabled={busy} onChange={event => update({ allowUnknownSponsorship: event.target.checked })} />Include jobs with unknown sponsorship availability</label><label className="checkbox-label"><input type="checkbox" checked={draft.allowUnknownRemoteEligibility} disabled={busy} onChange={event => update({ allowUnknownRemoteEligibility: event.target.checked })} />Include jobs with unknown remote-country eligibility</label><label className="checkbox-label"><input type="checkbox" checked={draft.stopAtDailyGoal} disabled={busy} onChange={event => update({ stopAtDailyGoal: event.target.checked })} />Stop at my configured daily campaign goal</label></div>
    <p className="small muted">Unknown sponsorship and remote eligibility are excluded by default. Including unknown listings never invents your work authorization, accepts terms, or supplies an unconfirmed answer.</p>
    <Field label="Employer allowlist (optional)" hint="One employer per line or separated by commas. Empty means no additional employer restriction; exclusions and all other checks still apply.">{id => <textarea id={id} rows={3} value={employers} disabled={busy} onChange={event => { setEmployers(event.target.value); setDirty(true); setValidation(""); }} />}</Field>
    {validation && <p className="field-error" role="alert">{validation}</p>}
    <div className="button-row"><button className="button secondary" type="submit" disabled={busy || (!dirty && rules.humanInLoop !== undefined && rules.autoDiscover !== undefined)}>Save matching rules</button>{dirty && <button className="button text-button" type="button" disabled={busy} onClick={() => { setDraft(defaults(rules)); setEmployers(rules.employerAllowlist.join("\n")); setDirty(false); setValidation(""); }}>Discard rule edits</button>}{dirty && <span className="small muted">Unsaved changes · saving pauses previous consent</span>}</div>
  </form>;
}
