import type { AutopilotView, CampaignStats, CareerSource, Job, KeywordAnalysis, Match, Packet, PreparationTask, Profile, ReferenceResume, ResumeVariant, Source } from "../../../packages/domain/types";
import type { ConfiguredSource } from "../../../packages/domain/discovery-settings";

export { MAX_APPROVAL_BATCH_SIZE } from "../../../packages/domain/types";
export type { ApplicationProgress, ApplicationStatus, AutomationProvider, AutopilotJob, AutopilotJobStatus, AutopilotRules, AutopilotView, CampaignConfig, Fact, Job, KeywordAnalysis, Match, Packet, PipelineStage, PreparationTask, Profile, ReferenceFamily, ReferenceResume, ResumeVariant, Source } from "../../../packages/domain/types";
export type MatchedJob = Job & { match: Match; keywords?: KeywordAnalysis };
export type Page = "home" | "today" | "autopilot" | "progress" | "opportunities" | "profile" | "resumes" | "applications" | "sources" | "ai" | "setup";

export interface State {
  profile: Profile;
  jobs: MatchedJob[];
  packets: Packet[];
  sources: ConfiguredSource[];
  careerSources?: CareerSource[];
  campaign: CampaignStats;
  referenceResumes: ReferenceResume[];
  resumeVariants?: ResumeVariant[];
  autopilot?: AutopilotView;
  preparationQueue: PreparationTask[];
  preparationSummary?: Record<PreparationTask["status"], number>;
  pagination?: { jobTotal: number; packetTotal: number; jobLimit: number; packetLimit: number };
  stats: { attemptsToday: number; attemptsSession: number; limit: number | null; submitted: number; totalJobs: number; stopped: boolean };
  runtime: {
    ai: { available: boolean; model: string; reason?: string; provider?: "ollama" | "copilot" | "gemini"; remote?: boolean; authenticated?: boolean; modelAvailable?: boolean; consentRequired?: boolean; keyConfigured?: boolean; freeTierConfirmed?: boolean; billingTierVerified?: false; retryAt?: string; retryAfterSeconds?: number };
    cloud: { configured: boolean; health?: { at?: string; error?: string; results?: { sourceId: string; count?: number; error?: string }[] } | null };
    /** `id` is the paired extension's ID, used to ask it to open an application session. */
    extension: { paired: boolean; id?: string };
  };
}

export type RunAction = (label: string, action: () => Promise<void>, success?: string) => Promise<boolean>;
export interface ResultPage<T> { items: T[]; total: number; offset: number; limit: number }
export interface HistoryItem { packet: Packet; job: Job }

export function historyJob(job: Job): MatchedJob {
  return { ...job, match: { score: 0, eligible: false, needsReview: true, matchedSkills: [], missingSkills: [], reasons: [], warnings: [], blockers: ["Current eligibility is not loaded for this historical job. Find it in the complete opportunities browser before preparing a fresh packet."] } };
}

export const pipelineLabels = {
  applied: "Applied", screening: "Screening", interview: "Interview", offer: "Offer", rejected: "Rejected", withdrawn: "Withdrawn",
} as const;

export function campaignToday(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

export function dateLabel(value?: string): string {
  if (!value) return "Not scheduled";
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isNaN(date.getTime()) ? "Unknown date" : date.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric", timeZone: "UTC" });
}

export function isFollowUpDue(packet: Packet, today = campaignToday()): boolean {
  return packet.status === "submitted_confirmed" && !!packet.progress?.nextActionDate
    && !["rejected", "withdrawn"].includes(packet.progress.stage) && packet.progress.nextActionDate <= today;
}

export function canPrepareJob(job: MatchedJob): boolean {
  return job.status === "open" && job.match.eligible && !job.match.blockers.length && job.aiPolicy !== "prohibited";
}

const requiredSources = [
  ["linkedin", "LinkedIn", "https://www.linkedin.com/jobs/"],
  ["indeed", "Indeed", "https://www.indeed.com/"],
  ["wellfound", "Wellfound", "https://wellfound.com/jobs"],
  ["naukri", "Naukri.com", "https://www.naukri.com/"],
  ["supabase", "Supabase", "https://supabase.com/careers"],
  ["automattic", "Automattic", "https://automattic.com/work-with-us/"],
  ["canonical", "Canonical / Ubuntu", "https://canonical.com/careers"],
  ["deel", "Deel", "https://www.deel.com/careers/"],
  ["safetywing", "SafetyWing", "https://safetywing.pinpointhq.com/"],
  ["toptal", "Toptal", "https://www.toptal.com/careers"],
  ["himalayas", "Himalayas", "https://himalayas.app/"],
  ["sideshift", "SideShift.app", "https://sideshift.app/"],
] as const;

export function allSources(sources: ConfiguredSource[]): ConfiguredSource[] {
  const used = new Set<string>();
  const requested = requiredSources.map(([id, name, careersUrl]) => {
    const source = sources.find((item) =>
      item.id === id || item.name.toLowerCase().replace(/[^a-z]/g, "").startsWith(id),
    );
    if (source) {
      used.add(source.id);
      return source;
    }
    return {
      id, name, careersUrl, mode: "manual_only", kind: "manual",
      discoveryAllowed: false, assistanceAllowed: false, submissionAllowed: false,
      policyUrl: "", notes: "Source configuration was not returned. Manual review only; no automated operations are authorized.",
    } satisfies Source;
  });
  return [...requested, ...sources.filter((source) => !used.has(source.id))];
}

export function safeUrl(value: string): string | undefined {
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:" ? url.href : undefined;
  } catch {
    return undefined;
  }
}

export function dateTime(value?: string): string {
  if (!value) return "Not yet";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "Unknown" : date.toLocaleString(undefined, {
    month: "short", day: "numeric", hour: "numeric", minute: "2-digit",
  });
}

export function salaryLabel(job: Job): string {
  if (!job.salary) return "Salary not disclosed";
  const { min, max, currency, period, kind } = job.salary;
  const amount = [min, max].filter((value): value is number => value !== undefined)
    .map((value) => new Intl.NumberFormat(undefined, { maximumFractionDigits: 0 }).format(value)).join(" – ");
  return `${currency || "Currency unknown"} ${amount || "Amount unknown"} · ${period || "Period unknown"} · ${kind || "Pay type unknown"}`;
}

export function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "Something went wrong. Try again.";
}

export function preparationLabel(mode: Packet["draft"]["mode"], engine?: "deterministic" | "local-ai"): string {
  if (mode === "jd-tailored") return `JD-tailored / ${engine === "local-ai" ? "AI-assisted tailoring" : engine === "deterministic" ? "deterministic" : "engine not recorded"}`;
  return mode === "uploaded-variant" ? "Original uploaded resume · unchanged" : mode === "local-ai" ? "AI-assisted preparation" : "Without AI";
}

export function usesHostedAi(ai: State["runtime"]["ai"]): boolean {
  return ai.provider === "copilot" || ai.provider === "gemini" || ai.remote === true;
}

export function configuredAiLabel(ai: State["runtime"]["ai"]): string {
  return usesHostedAi(ai) ? "Configured AI" : "Local AI";
}

export function configuredAiAvailable(ai: State["runtime"]["ai"]): boolean {
  return ai.available && (usesHostedAi(ai)
    ? ai.remote === true && ai.authenticated === true && ai.modelAvailable === true && ai.consentRequired === false
      && (ai.provider !== "gemini" || (ai.keyConfigured === true && ai.freeTierConfirmed === true))
    : ai.consentRequired !== true);
}
