import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { post, scanSources } from "./api";
import { canPrepareJob, configuredAiAvailable, configuredAiLabel, dateTime, MAX_APPROVAL_BATCH_SIZE, salaryLabel, usesHostedAi, type MatchedJob, type Packet, type Page, type RunAction, type State } from "./model";
import { Badge, EmptyState, ExternalLink, Field, Icon, Notice } from "./ui";
import { PreparationQueue } from "./PreparationQueue";
import { StoredJobs } from "./PagedBrowsers";

interface Props { state: State; ready: boolean; busy: boolean; run: RunAction; navigate: (page: Page) => void; viewPacket: (id: string) => void }

export function Opportunities({ state, ready, busy, run, navigate, viewPacket }: Props) {
  const [query, setQuery] = useState("");
  const [role, setRole] = useState("");
  const [location, setLocation] = useState("");
  const [eligible, setEligible] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);
  const [preparationSelection, setPreparationSelection] = useState<Record<string, string>>({});
  const [mode, setMode] = useState<"deterministic" | "local-ai">("deterministic");
  const [visibleCount, setVisibleCount] = useState(40);
  const [storedJobs, setStoredJobs] = useState<Record<string, MatchedJob>>({});
  const detail = useRef<HTMLElement>(null);
  const availableJobs = [...state.jobs, ...Object.values(storedJobs).filter((job) => !state.jobs.some((item) => item.id === job.id))];
  const selected = availableJobs.find((job) => job.id === selectedId);
  useEffect(() => {
    if (selectedId && detail.current) {
      detail.current.focus({ preventScroll: true });
      if (window.matchMedia("(max-width: 950px)").matches) detail.current.scrollIntoView({ block: "start" });
    }
  }, [selectedId]);
  const jobs = useMemo(() => state.jobs.filter((job) => {
    const searchable = `${job.title} ${job.company} ${job.description}`.toLowerCase();
    return (!query || searchable.includes(query.toLowerCase()))
      && (!role || job.title.toLowerCase().includes(role))
      && (!location || `${job.location} ${job.countries.join(" ")} ${job.remote ? "remote" : ""}`.toLowerCase().includes(location.toLowerCase()))
      && (!eligible || (job.match.eligible && !job.match.needsReview && job.status === "open"));
  }).sort((a, b) => b.match.score - a.match.score), [state.jobs, query, role, location, eligible]);
  const enabled = state.sources.filter((source) => source.mode === "enabled" && source.discoveryAllowed);
  const reviewCount = state.jobs.filter((job) => job.match.needsReview).length;
  const pendingJobs = new Set((state.preparationQueue || []).filter((task) => task.status === "queued" || task.status === "running").map((task) => task.jobId));
  const preparationFingerprint = (job: MatchedJob) => JSON.stringify([job, state.profile.version]);
  const chosen = availableJobs.filter((job) => ready && canPrepareJob(job) && !pendingJobs.has(job.id) && preparationSelection[job.id] === preparationFingerprint(job));
  const chosenIds = new Set(chosen.map((job) => job.id));
  useEffect(() => { setVisibleCount(40); }, [query, role, location, eligible]);

  function chooseForPreparation(job: MatchedJob, checked: boolean) {
    if (checked && (!ready || !canPrepareJob(job) || pendingJobs.has(job.id) || chosen.length >= MAX_APPROVAL_BATCH_SIZE)) return;
    if (checked) rememberJob(job);
    setPreparationSelection((current) => {
      const next = { ...current };
      if (checked) next[job.id] = preparationFingerprint(job);
      else delete next[job.id];
      return next;
    });
  }

  function rememberJob(job: MatchedJob) {
    setStoredJobs((current) => Object.fromEntries([...Object.values(current).filter((item) => item.id !== job.id && (preparationSelection[item.id] || item.id === selectedId)), job].map((item) => [item.id, item])));
  }

  function reviewStoredJob(job: MatchedJob) {
    rememberJob(job);
    setSelectedId(job.id);
    window.requestAnimationFrame(() => { detail.current?.focus(); detail.current?.scrollIntoView({ block: "start" }); });
  }

  async function prepareSelected() {
    if (!ready || !chosen.length || chosen.length > MAX_APPROVAL_BATCH_SIZE || (mode === "local-ai" && !configuredAiAvailable(state.runtime.ai))) return;
    const success = await run("Queuing your selected jobs for preparation…", async () => {
      await post("/api/preparation", { jobIds: chosen.map((job) => job.id), mode });
    }, "Selected jobs queued for preparation only, using the selected engine and saved processing permissions. Review each resulting packet before any approval; no application was submitted.");
    if (success) setPreparationSelection({});
  }

  async function prepare(job: MatchedJob, mode: "deterministic" | "local-ai") {
    if (mode === "local-ai" && !configuredAiAvailable(state.runtime.ai)) return;
    let packet: Packet | undefined;
    const success = await run(mode === "local-ai" ? `Preparing with ${configuredAiLabel(state.runtime.ai)}…` : "Preparing a factual packet…", async () => {
      const result = await post<{ packet: Packet }>("/api/packets", { jobId: job.id, mode });
      packet = result.packet;
    }, "Packet prepared, not approved. Review the exact content before sharing.");
    if (success && packet) viewPacket(packet.id);
  }

  return <>
    <section className="stats-strip" aria-label="Workspace summary">
      <div><span>Opportunities</span><strong>{state.stats.totalJobs.toLocaleString()}</strong><small>From discovered and imported listings</small></div>
      <div><span>Needs a closer look</span><strong>{reviewCount.toLocaleString()}</strong><small>Within the loaded shortlist only</small></div>
      <div><span>Confirmed submissions</span><strong>{state.stats.submitted.toLocaleString()}</strong><small>Not clicks or attempts</small></div>
      <div><span>Attempts today</span><strong>{state.stats.attemptsToday}{state.stats.limit !== null && <span className="stat-denominator"> / {state.stats.limit}</span>}</strong><small>{state.stats.limit === null ? "No global daily or session cap" : "Optional daily cap · Asia/Kolkata"} · source limits apply</small></div>
    </section>

    <section className="opportunity-section">
      <div className="section-heading"><div><h2>Your shortlist starts here</h2><p>Ranked by evidenced JD alignment—not an employer ATS score.</p></div><div className="button-row"><button className="button secondary" aria-expanded={importing} onClick={() => setImporting(!importing)}><Icon name={importing ? "close" : "plus"} />{importing ? "Close import" : "Add a job"}</button><button className="button primary" disabled={busy || !enabled.length} onClick={() => void run("Scanning permitted public sources…", () => scanSources(), "Bounded source pages scanned. Last-scan times are listed under Sources.")}><Icon name="refresh" />Scan sources</button></div></div>
      <Notice>{state.jobs.length.toLocaleString()} priority jobs loaded of {(state.pagination?.jobTotal ?? state.stats.totalJobs).toLocaleString()} stored. Filters below search this shortlist only. <a className="text-link" href="#all-stored-jobs">Browse and search every stored job<Icon name="arrow" size={14} /></a></Notice>
      {importing && <JobImport busy={busy} run={run} onComplete={() => setImporting(false)} />}
      <div className="filter-bar">
        <div className="search-field"><Icon name="search" /><label className="sr-only" htmlFor="job-search">Search opportunities</label><input id="job-search" type="search" placeholder="Search titles, companies, or skills" value={query} onChange={(event) => setQuery(event.target.value)} /></div>
        <Field label="Role family">{(id) => <select id={id} value={role} onChange={(event) => setRole(event.target.value)}><option value="">All roles</option><option value="software">Software</option><option value="cloud">Cloud</option><option value="data">Data</option><option value="forward">Forward deployed</option><option value="mlops">MLOps</option><option value="machine learning">Machine learning</option></select>}</Field>
        <Field label="Location">{(id) => <input id={id} placeholder="Country, city, or remote" value={location} onChange={(event) => setLocation(event.target.value)} />}</Field>
        <label className="checkbox-label filter-checkbox"><input type="checkbox" checked={eligible} onChange={(event) => setEligible(event.target.checked)} />Eligible, no review flags</label>
      </div>
      <div className="result-context"><span>{jobs.length} matching jobs in the {state.jobs.length}-job active shortlist</span><span>Highest alignment first</span></div>
      <section className="bulk-preparation" aria-label="Prepare selected opportunities"><div><h3>Prepare your chosen jobs</h3><p>Check individual eligible listings below. Up to {MAX_APPROVAL_BATCH_SIZE.toLocaleString()} IDs per request—not a daily limit. No selection, approval, or application is automatic.</p>{!ready && <p className="field-error">Confirm your saved profile and save pending edits to select jobs.</p>}</div><div className="bulk-controls"><Field label="Preparation method">{(id) => <select id={id} value={mode} disabled={busy} onChange={(event) => setMode(event.target.value as typeof mode)}><option value="deterministic">Without AI</option><option value="local-ai" disabled={!configuredAiAvailable(state.runtime.ai)}>{configuredAiLabel(state.runtime.ai)}{!configuredAiAvailable(state.runtime.ai) ? " · unavailable" : ""}</option></select>}</Field><button className="button primary" disabled={busy || !ready || !chosen.length || chosen.length > MAX_APPROVAL_BATCH_SIZE || (mode === "local-ai" && !configuredAiAvailable(state.runtime.ai))} onClick={() => void prepareSelected()}>Prepare {chosen.length || ""} selected{mode === "local-ai" && usesHostedAi(state.runtime.ai) ? "" : " locally"}</button></div>
        {usesHostedAi(state.runtime.ai) && <Notice>Configured AI uses hosted Copilot and your allowance. AI preparation sends bounded confirmed resume-fact and job-description text under separate remote-processing consent. “Without AI” stays deterministic; no silent fallback is used.</Notice>}
        {!!chosen.length && <details className="preparation-selection"><summary>{chosen.length} exact jobs selected <span>Selection includes listings hidden by filters</span></summary><ul>{chosen.map((job) => <li key={job.id}><span>{job.company} · {job.title}</span><button className="button-icon" disabled={busy} aria-label={`Remove ${job.title} at ${job.company} from preparation`} onClick={() => chooseForPreparation(job, false)}><Icon name="close" size={14} /></button></li>)}</ul><button className="text-link" disabled={busy} onClick={() => setPreparationSelection({})}>Clear preparation selection</button></details>}
      </section>
      {jobs.length || selected ? <div className={`job-workbench ${selected ? "has-detail" : ""}`}>
        <div className="job-list" aria-label="Job opportunities">
          {jobs.slice(0, visibleCount).map((job) => <article key={job.id} className={`job-choice ${chosenIds.has(job.id) ? "chosen-for-preparation" : ""}`}><button className={`job-card ${selectedId === job.id ? "selected" : ""}`} onClick={() => setSelectedId(job.id)} aria-pressed={selectedId === job.id}>
            <div className="job-card-top"><span className="company-monogram">{job.company.slice(0, 2).toUpperCase()}</span><div><span className="job-company">{job.company}</span><h3>{job.title}</h3></div><span className="alignment-number" title="Explainable JD alignment, not an ATS score">{job.match.score}<small>alignment</small></span></div>
            <div className="job-meta"><span><Icon name="location" size={14} />{job.location || "Location unknown"}</span><span>{job.employmentType || "Employment type unknown"}</span></div>
            <p className="job-salary">{salaryLabel(job)}</p>
            <div className="job-card-bottom"><span className="tag-group">{job.aiPolicy === "prohibited" && <Badge tone="danger">No AI · manual</Badge>}{!job.match.eligible ? <Badge tone="danger">Not eligible</Badge> : job.match.needsReview ? <Badge tone="warning">Needs review</Badge> : <Badge tone="positive">Eligible</Badge>}{job.status === "closed" && <Badge>Closed</Badge>}</span><span className="job-source">{state.sources.find((source) => source.id === job.sourceId)?.name || job.sourceId}<Icon name="arrow" size={15} /></span></div>
          </button><label className="checkbox-label preparation-checkbox"><input type="checkbox" checked={chosenIds.has(job.id)} disabled={busy || !ready || !canPrepareJob(job) || pendingJobs.has(job.id) || (!chosenIds.has(job.id) && chosen.length >= MAX_APPROVAL_BATCH_SIZE)} onChange={(event) => chooseForPreparation(job, event.target.checked)} /><span>{pendingJobs.has(job.id) ? "Already queued for local preparation" : canPrepareJob(job) ? "Select for local preparation only" : "Preparation blocked · review details"}<span className="sr-only"> · {job.title} at {job.company}</span></span></label></article>)}
          {jobs.length > visibleCount && <button className="button secondary show-more-jobs" onClick={() => setVisibleCount((count) => count + 40)}>Show more opportunities ({jobs.length - visibleCount} remaining)</button>}
        </div>
        {selected && <aside ref={detail} tabIndex={-1} className="job-detail" aria-label={`${selected.title} details`}><JobDetail job={selected} state={state} ready={ready} busy={busy} prepare={prepare} close={() => setSelectedId(null)} navigate={navigate} /></aside>}
      </div> : <EmptyState title={state.jobs.length ? "No opportunities match these filters" : "Room for the right opportunity."} action={<><button className="button primary" onClick={() => state.jobs.length ? (setQuery(""), setRole(""), setLocation(""), setEligible(false)) : setImporting(true)}>{state.jobs.length ? "Clear filters" : "Add your first job"}<Icon name={state.jobs.length ? "refresh" : "plus"} size={16} /></button><button className="button text-button" onClick={() => navigate("sources")}>Explore your sources<Icon name="arrow" size={16} /></button></>}>{state.jobs.length ? "Try a broader role or location, or include opportunities that need review." : "Scan an enabled public source or paste a job you found yourself. Only real listings you discover appear here—no sample jobs."}</EmptyState>}
    </section>
    <StoredJobs state={state} busy={busy} ready={ready} selectedIds={chosenIds} selectionFull={chosen.length >= MAX_APPROVAL_BATCH_SIZE} pendingJobs={pendingJobs} onSelect={chooseForPreparation} onReview={reviewStoredJob} />
    <PreparationQueue state={state} busy={busy} run={run} viewPacket={viewPacket} />
    <div className="source-summary"><div><Icon name="sources" /><span><strong>{enabled.length} enabled public {enabled.length === 1 ? "source" : "sources"}</strong><span className="muted"> / {state.sources.length} tracked · manual sources stay visible</span></span></div><button className="text-link" onClick={() => navigate("sources")}>View source health<Icon name="arrow" size={15} /></button></div>
  </>;
}

function JobDetail({ job, state, ready, busy, prepare, close, navigate }: { job: MatchedJob; state: State; ready: boolean; busy: boolean; prepare: (job: MatchedJob, mode: "deterministic" | "local-ai") => Promise<void>; close: () => void; navigate: (page: Page) => void }) {
  const source = state.sources.find((item) => item.id === job.sourceId);
  const prohibited = job.aiPolicy === "prohibited";
  const manual = !source?.assistanceAllowed || source.mode === "manual_only" || source.mode === "blocked" || prohibited;
  const blocked = !ready || !canPrepareJob(job) || (state.preparationQueue || []).some((task) => task.jobId === job.id && ["queued", "running"].includes(task.status));
  return <>
    <div className="detail-topline"><span>Opportunity review</span><button className="button-icon" onClick={close} aria-label="Close job detail"><Icon name="close" /></button></div>
    <div className="detail-title"><span className="job-company">{job.company}</span><h2>{job.title}</h2><p>{job.location || "Location unknown"}</p><ExternalLink href={job.applyUrl}>Open application manually</ExternalLink></div>
    {manual && <Notice tone="warning"><strong>{prohibited ? "No AI content permitted." : "Manual-only application."}</strong> {prohibited ? "Use your own words and complete this application yourself. Generated packets and automatic declarations are blocked." : "Browser form assistance is not authorized for this source. You may prepare documents, but must review the destination’s policy and complete the application yourself."}</Notice>}
    {!ready && <Notice tone="warning">Confirm your profile and save any pending edits before preparing a packet. <button className="text-link" onClick={() => navigate("profile")}>Review profile</button></Notice>}
    <section className="detail-section"><div className="alignment-heading"><h3>JD alignment</h3><strong>{job.match.score}<small> / 100</small></strong></div><p className="small muted">An explainable comparison with your facts. Not an ATS score, hiring prediction, or guarantee.</p><div className="alignment-track" aria-hidden="true"><span style={{ width: `${Math.min(100, Math.max(0, job.match.score))}%` }} /></div>
      <h4>Matched skills</h4><div className="tag-group">{job.match.matchedSkills.length ? job.match.matchedSkills.map((skill) => <Badge key={skill} tone="positive">{skill}</Badge>) : <span className="small muted">No matching skills evidenced yet.</span>}</div>
      <h4>Missing evidence</h4><div className="tag-group">{job.match.missingSkills.length ? job.match.missingSkills.map((skill) => <Badge key={skill}>{skill}</Badge>) : <span className="small muted">No additional skill gaps detected. Review the full requirements.</span>}</div>
      {!!job.match.reasons.length && <ul className="evidence-list">{job.match.reasons.map((reason, index) => <li key={index}>{reason}</li>)}</ul>}
    </section>
    {job.keywords && <section className="detail-section keyword-evidence"><h3>Keywords, with evidence</h3><p className="small muted">Application drafts may include supported direct or equivalent terms only. Foundations are not hands-on experience.</p>
      <h4>Supported or equivalent</h4>{job.keywords.supported.length ? <ul>{job.keywords.supported.map((item) => <li key={item.term}><strong>{item.term}</strong> <Badge tone="positive">{item.kind === "equivalent" ? "Equivalent evidence" : "Direct evidence"}</Badge><p>{item.explanation}</p><span className="small muted">{[item.sourceSkills.length ? `Source skills: ${item.sourceSkills.join(", ")}` : "", item.factIds.length ? `Fact IDs: ${item.factIds.join(", ")}` : ""].filter(Boolean).join(" · ")}</span></li>)}</ul> : <p className="small muted">No supported keyword evidence was found.</p>}
      <h4>Transferable foundations · not claimed skills</h4>{job.keywords.transferable.length ? <ul>{job.keywords.transferable.map((item) => <li key={item.term}><strong>{item.term}</strong><p>{item.explanation}</p><span className="small muted">Foundation: {item.sourceSkills.join(", ") || item.factIds.join(", ") || "Review original evidence"}. Not claimed as hands-on experience.</span></li>)}</ul> : <p className="small muted">No additional transferable foundations identified.</p>}
      <h4>Gaps · not claimed skills</h4><div className="tag-group">{job.keywords.gaps.length ? job.keywords.gaps.map((term) => <Badge key={term}>{term}</Badge>) : <span className="small muted">No additional gaps detected; check the full job description.</span>}</div><p className="field-hint">Gaps and transferable terms are not added as supported keyword claims.</p>
    </section>}
    <section className="detail-section"><h3>Eligibility & important details</h3><dl className="detail-grid"><dt>Compensation</dt><dd>{salaryLabel(job)}</dd><dt>Sponsorship</dt><dd>{job.sponsorship === "yes" ? "Advertised as available · verify details" : job.sponsorship === "no" ? "Not offered" : "Unknown · review required"}</dd><dt>Work location</dt><dd>{job.remote ? "Remote" : "On-site / unspecified"} · {job.countries.join(", ") || "Eligible countries unknown"}</dd><dt>Language</dt><dd>{job.language || "Not specified"}</dd><dt>AI policy</dt><dd>{prohibited ? "Prohibited · manual only" : job.aiPolicy === "allowed" ? "Writing assistance allowed; submission permission is separate" : "Unknown · verify before use"}</dd><dt>Listing status</dt><dd>{job.status} · last fetched {dateTime(job.fetchedAt)}</dd></dl>
      {!!job.match.blockers.length && <Notice tone="danger"><strong>Preparation blocked</strong><ul>{job.match.blockers.map((item, index) => <li key={index}>{item}</li>)}</ul></Notice>}
      {!!job.match.warnings.length && <Notice tone="warning"><strong>Review these uncertainties</strong><ul>{job.match.warnings.map((item, index) => <li key={index}>{item}</li>)}</ul></Notice>}
    </section>
    <section className="detail-section"><h3>Prepare, then review</h3><p className="small muted">Select confirmed facts for this role. Preparing a packet does not approve or submit an application.</p>{usesHostedAi(state.runtime.ai) && <Notice>Configured AI uses hosted Copilot · {state.runtime.ai.model}. Bounded confirmed resume-fact and JD text is processed remotely with saved consent and consumes your allowance.</Notice>}<div className="stack-buttons"><button className="button primary" disabled={busy || blocked} onClick={() => void prepare(job, "deterministic")}>Prepare without AI<Icon name="arrow" size={16} /></button><button className="button secondary" disabled={busy || blocked || !configuredAiAvailable(state.runtime.ai)} onClick={() => void prepare(job, "local-ai")}>{usesHostedAi(state.runtime.ai) ? "Prepare with Configured AI" : "Prepare with local AI"}</button></div>{!configuredAiAvailable(state.runtime.ai) && <p className="field-hint">{configuredAiLabel(state.runtime.ai)} unavailable. {state.runtime.ai.reason || "Review AI provider, model access, and consent in Setup."}</p>}</section>
    <details className="jd-disclosure" open><summary>Full job description <span>Plain text</span></summary><div className="job-description">{job.description || "No description was provided. Check the original listing before proceeding."}</div></details>
    <p className="small muted detail-attribution">Source: {source?.name || job.sourceId} · <ExternalLink href={job.canonicalUrl}>Original listing</ExternalLink>{job.sourceId === "himalayas" && <> · <ExternalLink href="https://himalayas.app/">Jobs from Himalayas</ExternalLink></>}</p>
  </>;
}

function JobImport({ busy, run, onComplete }: { busy: boolean; run: RunAction; onComplete: () => void }) {
  const [draft, setDraft] = useState({ title: "", company: "", description: "", applyUrl: "", location: "", employmentType: "" });
  async function submit(event: FormEvent) {
    event.preventDefault();
    const success = await run("Adding your job…", async () => { await post("/api/jobs/import", draft); }, "Job added for review. Importing a listing does not grant automation permission.");
    if (success) onComplete();
  }
  return <form className="inline-panel job-import" onSubmit={(event) => void submit(event)}>
    <h3>Add a listing you found</h3><p className="small muted">Paste the original plain-text description. We do not scrape restricted sites or infer permission from a URL.</p>
    <div className="form-grid">{(["title", "company", "applyUrl", "location", "employmentType"] as const).map((key) => <Field key={key} label={{ title: "Job title", company: "Company", applyUrl: "Original application URL", location: "Location (optional)", employmentType: "Employment type (optional)" }[key]}>{(id) => <input id={id} type={key === "applyUrl" ? "url" : "text"} required={["title", "company", "applyUrl"].includes(key)} value={draft[key]} onChange={(event) => setDraft({ ...draft, [key]: event.target.value })} disabled={busy} />}</Field>)}</div>
    <Field label="Full job description">{(id) => <textarea id={id} rows={7} required value={draft.description} onChange={(event) => setDraft({ ...draft, description: event.target.value })} disabled={busy} />}</Field>
    <div className="button-row"><button className="button primary" disabled={busy} type="submit">Add for review</button><button className="button text-button" type="button" disabled={busy} onClick={onComplete}>Cancel</button></div>
  </form>;
}
