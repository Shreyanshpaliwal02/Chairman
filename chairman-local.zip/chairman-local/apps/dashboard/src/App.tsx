import { AiPage } from "./AiPage";
import { useCallback, useEffect, useRef, useState } from "react";
import { api, initializeSession, post } from "./api";
import { allSources, errorMessage, type Page, type RunAction, type State } from "./model";
import { Icon, Notice } from "./ui";
import { Opportunities } from "./Opportunities";
import { ProfileEditor } from "./ProfileEditor";
import { Applications } from "./Applications";
import { Sources, Setup } from "./SourcesSetup";
import { Home } from "./Home";
import { Resumes } from "./Resumes";
import { AutoApply, hasAutoApply } from "./AutoApply";
import { useMonitorEvents } from "./LiveMonitor";
import { AttentionNotifications } from "./AttentionNotifications";
import { Progress } from "./Progress";
import { Today } from "./Today";
import { QuestionBank } from "./QuestionBank";

const pages: { id: Page; label: string; description: string }[] = [
  { id: "home", label: "Home", description: "Your next role, from first search to follow-through." },
  { id: "today", label: "Today", description: "Today's best-fitting roles across your companies: open, fill in one click, submit." },
  { id: "autopilot", label: "Auto Apply", description: "Discover matching jobs, prefill applications, and step in when needed." },
  { id: "progress", label: "Progress", description: "Companies you track, the roles that fit you, and where each application stands." },
  { id: "opportunities", label: "Opportunities", description: "Find the right next step. Apply with intention." },
  { id: "profile", label: "Your profile", description: "Your experience is the source of truth." },
  { id: "resumes", label: "Resumes", description: "Your baseline library. A reviewed resume for each opportunity." },
  { id: "applications", label: "Applications", description: "Exact documents, saved authorizations, and honest outcomes." },
  { id: "sources", label: "Sources", description: "Know where each opportunity comes from—and what is permitted." },
  { id: "ai", label: "AI", description: "The AI model Chairman uses to answer form questions and tailor resumes." },
  { id: "setup", label: "Setup & privacy", description: "A private workspace, with clear boundaries." },
];

function initialPage(): Page {
  const hash = window.location.hash.slice(1).toLowerCase();
  return pages.find(item => item.id === hash)?.id ?? "home";
}

export function App() {
  const [page, setPage] = useState<Page>(initialPage);
  const [visited, setVisited] = useState<Set<Page>>(() => new Set([initialPage(), "profile"]));
  const [state, setState] = useState<State | null>(null);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState("");
  const [dirtyProfile, setDirtyProfile] = useState(false);
  const [dirtyAutoApply, setDirtyAutoApply] = useState(false);
  const [dirtyResumes, setDirtyResumes] = useState(false);
  const [profileReset, setProfileReset] = useState(0);
  const [focusedPacket, setFocusedPacket] = useState<string | null>(null);
  const operation = useRef(false);
  const heading = useRef<HTMLHeadingElement>(null);
  const current = pages.find((item) => item.id === page)!;
  const monitor = useMonitorEvents(!!state, setState);
  const attention = state?.autopilot?.humanTasks?.filter(task => task.status === "waiting" || task.status === "session_lost").length;

  const refresh = useCallback(async () => {
    const next = await api<State>("/api/state");
    setState({ ...next, sources: allSources(next.sources) });
  }, []);

  const run: RunAction = useCallback(async (label, action, success) => {
    if (operation.current) return false;
    operation.current = true;
    setBusy(label);
    setError("");
    setMessage("");
    try {
      await action();
      await refresh();
      if (success) setMessage(success);
      return true;
    } catch (cause) {
      let message = errorMessage(cause);
      try { await refresh(); } catch (refreshError) { message += ` Refresh also failed: ${errorMessage(refreshError)}`; }
      setError(message);
      return false;
    } finally {
      operation.current = false;
      setBusy("");
    }
  }, [refresh]);

  const connect = useCallback(async () => {
    await run("Connecting to your local workspace…", async () => { await initializeSession(); });
  }, [run]);

  useEffect(() => { void connect(); }, [connect]);
  useEffect(() => {
    const timer = window.setInterval(() => {
      if (!operation.current && document.visibilityState === "visible") void refresh().catch(error => setError(errorMessage(error)));
    }, state?.autopilot?.enabled || page === "autopilot" || state?.preparationQueue?.some((task) => task.status === "queued" || task.status === "running") ? 5_000 : 60_000);
    return () => window.clearInterval(timer);
  }, [refresh, page, state?.autopilot?.enabled, state?.preparationQueue?.some((task) => task.status === "queued" || task.status === "running")]);
  useEffect(() => {
    function beforeUnload(event: BeforeUnloadEvent) {
      if (dirtyProfile || dirtyAutoApply || dirtyResumes) { event.preventDefault(); event.returnValue = ""; }
    }
    window.addEventListener("beforeunload", beforeUnload);
    return () => window.removeEventListener("beforeunload", beforeUnload);
  }, [dirtyProfile, dirtyAutoApply, dirtyResumes]);
  useEffect(() => {
    const change = () => {
      const next = pages.find(item => item.id === window.location.hash.slice(1).toLowerCase())?.id;
      if (next) { setVisited(current => new Set([...current, next])); setPage(next); }
    };
    window.addEventListener("hashchange", change);
    return () => window.removeEventListener("hashchange", change);
  }, []);

  function navigate(next: Page) {
    setVisited((current) => current.has(next) ? current : new Set([...current, next]));
    setPage(next);
    window.history.replaceState(null, "", `#${next}`);
    window.requestAnimationFrame(() => heading.current?.focus());
  }

  function viewPacket(id: string) {
    setFocusedPacket(id);
    navigate("applications");
  }

  const ready = !!state?.profile.confirmed && !!state.profile.facts.length && state.profile.facts.every((fact) => fact.confirmed);
  const initials = state?.profile.name.trim().split(/\s+/).filter(Boolean).map((part) => part[0]).slice(0, 2).join("") || "You";

  return <div className="app-shell">
    <a className="skip-link" href="#main-content">Skip to workspace</a>
    <aside className="sidebar">
      <a className="brand" href="#home" onClick={() => navigate("home")} aria-label="Chairman home">
        <span className="brand-mark"><svg viewBox="0 0 32 32" aria-hidden="true"><path d="M7 24V8h6v10l12-12v8L15 24z" fill="currentColor" /></svg></span>
        <span>Chairman<span className="brand-caption">Your application workspace</span></span>
      </a>
      <nav aria-label="Main navigation">
        {pages.map((item) => <button key={item.id} className={`nav-item ${page === item.id ? "active" : ""}`} aria-current={page === item.id ? "page" : undefined} onClick={() => navigate(item.id)}>
          <Icon name={item.id} /><span>{item.id === "profile" ? "Profile" : item.id === "setup" ? "Setup" : item.label}</span>
          {item.id === "profile" && dirtyProfile && <span className="unsaved-dot" aria-label="Unsaved changes" />}
          {item.id === "autopilot" && dirtyAutoApply && <span className="unsaved-dot" aria-label="Unsaved Auto Apply changes" />}
          {item.id === "resumes" && dirtyResumes && <span className="unsaved-dot" aria-label="Unsaved resume changes" />}
          {item.id === "applications" && !!(state?.pagination?.packetTotal ?? state?.packets.length) && <span className="nav-count">{(state?.pagination?.packetTotal ?? state?.packets.length)?.toLocaleString()}</span>}
        </button>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="local-note"><Icon name="shield" /><div><strong>Your workspace. Your choices.</strong><p>Local storage. Hosted AI processing and employer submissions require separate, explicit permission.</p></div></div>
        <button className="user-menu" onClick={() => navigate("profile")}><span className="avatar">{initials}</span><span><strong>{state?.profile.name || "Your workspace"}</strong><small>{ready ? "Profile confirmed" : "Profile needs review"}</small></span><Icon name="arrow" size={16} /></button>
      </div>
    </aside>

    <div className="workspace">
      <div className="topbar">
        <div className="connection-label"><span className={`status-dot ${state ? "online" : ""}`} />{state ? "Local workspace" : "Connecting locally"}<span className="topbar-divider">/</span><span className="muted">Hosted AI is opt-in</span></div>
        {attention !== undefined && <button className="button text-button attention-button" onClick={() => { navigate("autopilot"); window.requestAnimationFrame(() => document.getElementById("human-attention")?.scrollIntoView({ block: "start" })); }}><span aria-live="polite">Human attention: {attention}</span></button>}
        <button className={`button queue-button ${state?.stats.stopped ? "secondary" : "danger-quiet"}`} disabled={!state || !!busy} onClick={() => { if (state) void run(state.stats.stopped ? "Resuming queue…" : "Stopping queue…", async () => { await Promise.all([post("/api/control", { stopped: !state.stats.stopped }), ...(!state.stats.stopped && hasAutoApply(state) ? [post("/api/autopilot/pause", {})] : [])]); }, state.stats.stopped ? "Queue resumed. Auto Apply requires its own explicit activation; resuming does not grant consent." : "Queue stopped. Auto Apply was paused if available. An in-flight submission may still complete; check its outcome."); }}>
          <Icon name={state?.stats.stopped ? "arrow" : "pause"} size={16} />{state?.stats.stopped ? "Resume queue" : "Stop queue"}
        </button>
      </div>

      <main id="main-content" className="main-content">
        <header className="page-header"><div><h1 tabIndex={-1} ref={heading}>{current.label}</h1><p>{current.description}</p></div>
          <button className="button secondary refresh-button" disabled={!!busy} onClick={() => void connect()}><Icon name="refresh" />Refresh</button>
        </header>

        {error && <div className="feedback feedback-error" role="alert"><Icon name="info" /><div><strong>Something needs attention</strong><p>{error}</p><span>Your local edits have been kept. Refresh or retry the action when ready.</span></div><button className="button-icon" aria-label="Dismiss error" onClick={() => setError("")}><Icon name="close" /></button></div>}
        {message && <div className="feedback feedback-success" role="status"><Icon name="check" /><p>{message}</p><button className="button-icon" aria-label="Dismiss notification" onClick={() => setMessage("")}><Icon name="close" /></button></div>}
        <div className="busy-announcement" role="status" aria-live="polite">{busy && <><span className="spinner" />{busy}</>}</div>

        {!state ? <div className="connection-state"><Icon name="shield" size={36} /><h2>{busy ? "Opening your workspace" : "Your local service is not connected"}</h2><p>Start the local service, then reconnect. Hosted AI processing requires separate consent in Setup.</p><button className="button primary" disabled={!!busy} onClick={() => void connect()}>{busy ? "Connecting…" : "Reconnect"}</button></div> : <>
          {state.stats.stopped && <Notice tone="warning"><strong>Submission queue is stopped.</strong> No new submission attempts will start. An in-flight submission may still complete; stopping does not withdraw it. Cancel local preparation separately under Opportunities.</Notice>}
          {!ready && page !== "profile" && page !== "resumes" && page !== "home" && page !== "autopilot" && <div className="onboarding-banner"><div className="onboarding-symbol"><Icon name="profile" size={23} /></div><div><h2>Start with your story, not a template.</h2><p>Review your profile and at least two approved, valid templates/originals in any of the eight Auto Apply slots, or keep using reviewed manual packets. Generated reference drafts are separate and never approved automatically.</p></div><button className="button primary" onClick={() => navigate("autopilot")}>Set up Auto Apply<Icon name="arrow" size={16} /></button></div>}
          <div hidden={page !== "home"}>{visited.has("home") && <Home state={state} busy={!!busy} run={run} navigate={navigate} viewPacket={viewPacket} />}</div>
          <div hidden={page !== "autopilot"}>{visited.has("autopilot") && <AutoApply state={state} visible={page === "autopilot"} monitor={monitor} busy={!!busy} run={run} navigate={navigate} viewPacket={viewPacket} profileDirty={dirtyProfile} libraryDirty={dirtyResumes} onDirty={setDirtyAutoApply} />}</div>
          <div hidden={page !== "opportunities"}>{visited.has("opportunities") && <Opportunities state={state} ready={ready && !dirtyProfile} busy={!!busy} run={run} navigate={navigate} viewPacket={viewPacket} />}</div>
          <div hidden={page !== "today"}>{visited.has("today") && <Today state={state} visible={page === "today"} busy={!!busy} run={run} />}</div>
          <div hidden={page !== "progress"}>{visited.has("progress") && <Progress state={state} visible={page === "progress"} busy={!!busy} run={run} />}</div>
          <div hidden={page !== "profile"}><ProfileEditor key={profileReset} profile={state.profile} busy={!!busy} run={run} onDirty={setDirtyProfile} /><QuestionBank profile={state.profile} profileDirty={dirtyProfile} busy={!!busy} run={run} /></div>
          <div hidden={page !== "resumes"}>{visited.has("resumes") && <Resumes state={state} busy={!!busy} run={run} navigate={navigate} profileDirty={dirtyProfile} setupDirty={dirtyAutoApply} onDirty={setDirtyResumes} viewPacket={viewPacket} />}</div>
          <div hidden={page !== "applications"}>{visited.has("applications") && <Applications state={state} visible={page === "applications"} busy={!!busy} run={run} focusedPacket={focusedPacket} setFocusedPacket={setFocusedPacket} navigate={navigate} profileDirty={dirtyProfile} />}</div>
          <div hidden={page !== "sources"}>{visited.has("sources") && <Sources state={state} busy={!!busy} run={run} />}</div>
          <div hidden={page !== "ai"}>{visited.has("ai") && <AiPage state={state} visible={page === "ai"} busy={!!busy} run={run} />}</div>
          <div hidden={page !== "setup"}>{visited.has("setup") && <Setup state={state} busy={!!busy} run={run} navigate={navigate} onDeleted={warning => { setDirtyProfile(false); setDirtyAutoApply(false); setDirtyResumes(false); setProfileReset((value) => value + 1); setVisited(new Set(["profile"])); setFocusedPacket(null); if (warning) setError(`Personal workspace data was deleted, but a provider needs attention: ${warning}`); else setMessage("Personal workspace data deleted. Anonymous daily safety counters remain to preserve attempt limits."); navigate("profile"); }} />}</div>
          <AttentionNotifications state={state} />
        </>}
        <footer className="workspace-footer"><span>Thoughtful applications. Honest evidence.</span><span>Local workspace · optional hosted AI with consent · public cloud discovery</span></footer>
      </main>
    </div>
  </div>;
}
