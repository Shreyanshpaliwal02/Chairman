import { useState } from "react";
import { post } from "./api";
import { dateTime, usesHostedAi, type RunAction, type State } from "./model";
import { Badge, Icon, Notice } from "./ui";

export function PreparationQueue({ state, busy, run, viewPacket }: { state: State; busy: boolean; run: RunAction; viewPacket: (id: string) => void }) {
  const [showAll, setShowAll] = useState(false);
  const tasks = state.preparationQueue || [];
  const pending = tasks.filter((task) => task.status === "queued" || task.status === "running");
  const failed = tasks.filter((task) => task.status === "failed");
  const completed = tasks.filter((task) => task.status === "completed");
  const counts = state.preparationSummary;
  const ordered = tasks.toSorted((a, b) => {
    const order = { running: 0, failed: 1, queued: 2, completed: 3, cancelled: 4 };
    return order[a.status] - order[b.status] || b.createdAt.localeCompare(a.createdAt);
  });
  if (!tasks.length) return null;
  return <section className="preparation-queue" aria-label="Persistent local preparation queue"><div className="section-heading"><div><h2>Local preparation queue</h2><p>{counts ? counts.queued + counts.running : pending.length} pending · {counts?.failed ?? failed.length} failed · {counts?.completed ?? completed.length} completed. Showing up to 500 priority records; totals cover the entire queue. Preparation does not send applications.</p></div><button className="button danger-quiet compact" disabled={busy || !(counts ? counts.queued : tasks.some((task) => task.status === "queued"))} onClick={() => void run("Cancelling queued preparation…", async () => { await post("/api/preparation/cancel", {}); }, "Queued local preparation cancelled. Any running local preparation may still finish; no applications were sent.")}>Cancel all queued</button></div>
    <Notice>Tasks persist locally. Your computer and local service must be running to prepare them. Cancellation stops queued tasks only; running preparation may finish. Failed tasks are not approvals or submissions.</Notice>
    {usesHostedAi(state.runtime.ai) && <Notice>AI-assisted tasks use the configured hosted Copilot model and allowance under saved remote-processing consent. Queue storage is local; AI inference is not.</Notice>}
    <ul className="preparation-list">{(showAll ? ordered : ordered.slice(0, 8)).map((task) => {
      const job = state.jobs.find((item) => item.id === task.jobId);
      return <li key={task.id}><div><strong>{job?.company || "Job outside the loaded shortlist"} · {job?.title || task.jobId}</strong><span>{task.mode === "local-ai" ? "AI-assisted preparation" : "Without AI"} · Updated {dateTime(task.updatedAt)}</span>{task.status === "failed" && <p className="field-error">{task.error || "Preparation failed. Review profile, eligibility, and the configured provider before choosing this job again."}</p>}</div><div className="task-actions"><Badge tone={task.status === "failed" ? "danger" : ["queued", "running"].includes(task.status) ? "warning" : "neutral"}>{task.status === "completed" ? "Prepared · not approved" : task.status}</Badge>{task.status === "queued" && <button className="text-link danger-text" disabled={busy} onClick={() => void run("Cancelling selected preparation…", async () => { await post("/api/preparation/cancel", { ids: [task.id] }); }, "Cancellation requested for this task. A task already running may still finish.")}>Cancel<span className="sr-only"> {job?.title || task.jobId}</span></button>}{task.packetId && <button className="text-link" onClick={() => viewPacket(task.packetId!)}>Review packet<Icon name="arrow" size={13} /></button>}</div></li>;
    })}</ul>
    {ordered.length > 8 && <button className="button text-button" onClick={() => setShowAll(!showAll)}>{showAll ? "Show fewer tasks" : `Show ${ordered.length} loaded tasks`}</button>}
  </section>;
}
