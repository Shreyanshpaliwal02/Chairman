import { useId, useState, type FormEvent } from "react";
import { post } from "./api";
import { configuredAiAvailable, configuredAiLabel, usesHostedAi, type Packet, type RunAction, type State } from "./model";
import { Field, Notice } from "./ui";

export function TailoringPreview({ state, busy, savedProfileReady, setupDirty, run, viewPacket }: { state: State; busy: boolean; savedProfileReady: boolean; setupDirty: boolean; run: RunAction; viewPacket: (id: string) => void }) {
  const titleId = useId();
  const [baseId, setBaseId] = useState("");
  const [jobId, setJobId] = useState("");
  const [mode, setMode] = useState<"deterministic" | "local-ai">("deterministic");
  const bases = (state.resumeVariants || []).filter(variant => variant.approved && !variant.issues.length && [1, 2, 3, 4, 5, 6, 7, 8].includes(variant.slot));
  const base = bases.find(variant => variant.id === baseId);
  const job = state.jobs.find(job => job.id === jobId);
  const jobBlocked = !!job && (!job.match.eligible || job.status !== "open" || job.aiPolicy === "prohibited" || !job.description.trim()
    || job.cacheExpired || (!!job.expiresAt && Date.parse(job.expiresAt) <= Date.now()));
  const aiBlocked = mode === "local-ai" && !configuredAiAvailable(state.runtime.ai);
  const canPreview = savedProfileReady && !setupDirty && !!base && !!job && !jobBlocked && !aiBlocked;

  async function preview(event: FormEvent) {
    event.preventDefault();
    if (busy || !canPreview || !base || !job) return;
    let packet: Packet | undefined;
    const success = await run("Preparing a JD-tailored preview…", async () => {
      const result = await post<{ packet: Packet }>(`/api/resume-variants/${encodeURIComponent(base.id)}/tailor`, { jobId: job.id, mode });
      if (!result.packet?.id) throw new Error("The local service did not return a prepared packet. Refresh and try again.");
      packet = result.packet;
    }, "JD-tailored packet saved in your local workspace. The chosen AI provider may process permitted text remotely. This preview did not activate Auto Apply, approve a packet, or submit an application.");
    if (success && packet) viewPacket(packet.id);
  }

  return <section className="tailoring-preview" aria-labelledby={titleId}>
    <h3 id={titleId}>Preview before authorizing</h3>
    <p>Choose one approved template as a reference and a loaded job description. A single approved, valid base is enough for this preview; activation still needs at least two.</p>
    <form onSubmit={event => void preview(event)}>
      <div className="form-grid">
        <Field label="Approved base template">{id => <select id={id} required value={baseId} disabled={busy} onChange={event => setBaseId(event.target.value)}>
          <option value="">Choose an approved base</option>
          {baseId && !base && <option value={baseId}>Selected base is no longer approved or valid</option>}
          {bases.map(variant => <option key={variant.id} value={variant.id}>Slot {variant.slot} · {variant.label} · {variant.originalFilename}</option>)}
        </select>}</Field>
        <Field label="Loaded job description">{id => <select id={id} required value={jobId} disabled={busy} onChange={event => setJobId(event.target.value)}>
          <option value="">Choose a loaded job</option>
          {jobId && !job && <option value={jobId}>Selected job is not loaded</option>}
          {state.jobs.map(job => <option key={job.id} value={job.id}>{job.company} · {job.title}{job.status !== "open" ? " · closed" : ""}</option>)}
        </select>}</Field>
        <Field label="Preview engine">{id => <select id={id} value={mode} disabled={busy} onChange={event => setMode(event.target.value as typeof mode)}>
          <option value="deterministic">Evidence-based (no model/API cost)</option>
          <option value="local-ai">{configuredAiLabel(state.runtime.ai)}</option>
        </select>}</Field>
      </div>
      <p className="small muted">{state.jobs.length.toLocaleString()} loaded jobs available in this selector, not all {(state.pagination?.jobTotal ?? state.stats.totalJobs).toLocaleString()} stored listings. A listed job is not necessarily eligible. If your job is not loaded, refresh the shortlist or import its description in Opportunities; this preview cannot use an unloaded job.</p>
      {!savedProfileReady && <Notice tone="warning">Confirm every profile fact and save your profile before previewing.</Notice>}
      {setupDirty && <Notice tone="warning">Save or discard pending resume-slot and rule edits before previewing the saved setup.</Notice>}
      {!bases.length && <Notice tone="warning">Upload and accuracy-approve at least one valid base template to preview.</Notice>}
      {jobBlocked && <Notice tone="warning">This job is ineligible, closed, expired, missing its description, or prohibits generated content. Choose an eligible, current job that permits assistance.</Notice>}
      {mode === "local-ai" && usesHostedAi(state.runtime.ai) && <Notice>AI-assisted tailoring uses {state.runtime.ai.model || "the configured model"} through hosted {state.runtime.ai.provider === "gemini" ? "Google Gemini. Only anonymous IDs and fixed public technology tags leave this device, never raw resume facts or the full JD. Exact source facts are restored locally. Separate consent and your Free project with billing disabled are required; Google may human-review unpaid-service inputs." : "GitHub Copilot. Bounded confirmed resume-fact and job-description text is sent remotely under your saved processing consent and uses your Copilot allowance."} No silent model or provider fallback.</Notice>}
      {aiBlocked && <Notice tone="warning">{configuredAiLabel(state.runtime.ai)} is unavailable. {state.runtime.ai.reason || "Review the configured provider, model access, and consent in Setup, or explicitly choose the evidence-based engine."}</Notice>}
      <button className="button secondary" type="submit" disabled={busy || !canPreview}>Preview JD-tailored resume</button>
      <p className="small muted">The server rechecks the base, confirmed evidence, job, policy, and engine. Previewing never enables, approves, or submits. Review the resulting exact PDF or DOCX before sharing.</p>
    </form>
  </section>;
}
