import { useEffect, useState, type FormEvent } from "react";
import { searchPortalUrl, validateSearchTemplate, type SearchPortal, type SearchPortalList } from "../../../packages/domain/discovery-settings";
import { api, post } from "./api";
import { errorMessage, type RunAction, type State } from "./model";
import { Badge, ExternalLink, Field, Notice } from "./ui";

export function SearchPortals({ state, busy, run }: { state: State; busy: boolean; run: RunAction }) {
  const [portals, setPortals] = useState<SearchPortal[]>();
  const [error, setError] = useState("");
  const [revision, setRevision] = useState(0);
  const [role, setRole] = useState(state.profile.preferences.roles[0] || "");
  const [location, setLocation] = useState(state.profile.preferences.countries[0] || "");
  const [draft, setDraft] = useState({ id: "", label: "", urlTemplate: "" });
  useEffect(() => {
    const controller = new AbortController();
    void api<SearchPortalList>("/api/search-portals", { signal: controller.signal }).then(result => {
      if (!Array.isArray(result.portals)) throw new Error("Search website configuration was not returned. Restart the updated local service.");
      for (const portal of result.portals) validateSearchTemplate(portal.urlTemplate);
      setPortals(result.portals); setError("");
    }).catch(cause => { if (!controller.signal.aborted) setError(errorMessage(cause)); });
    return () => controller.abort();
  }, [revision]);

  async function save(event: FormEvent) {
    event.preventDefault();
    try { validateSearchTemplate(draft.urlTemplate); }
    catch (cause) { setError(errorMessage(cause)); return; }
    const success = await run("Saving manual search website...", async () => {
      const result = await post<SearchPortalList>("/api/search-portals", { action: "save", ...(draft.id ? { id: draft.id } : {}), label: draft.label, urlTemplate: draft.urlTemplate });
      if (!Array.isArray(result.portals)) throw new Error("The service did not return the saved search websites.");
      setPortals(result.portals);
    }, "Manual search website saved. No site was fetched, account connected, or application activated.");
    if (success) { setDraft({ id: "", label: "", urlTemplate: "" }); setError(""); }
  }
  return <section className="home-section search-portals" aria-labelledby="search-portals-title">
    <div className="section-heading"><div><h2 id="search-portals-title">Your job search websites</h2><p>Search in Chrome, sign in yourself, then use the employer's original link or import the job description.</p></div><Badge>Manual bookmarks</Badge></div>
    <Notice>LinkedIn, Indeed, Wellfound and Naukri are manual-only here. Bookmarks never authorize scraping, page extraction, filling, or submission. We do not store website passwords. Add your preferred remote-jobs website below rather than assuming which site you mean.</Notice>
    <div className="form-grid"><Field label="Search role">{id => <input id={id} value={role} maxLength={200} onChange={event => setRole(event.target.value)} placeholder="Software engineer" />}</Field><Field label="Search location">{id => <input id={id} value={location} maxLength={200} onChange={event => setLocation(event.target.value)} placeholder="Worldwide or a country" />}</Field></div>
    {error && <Notice tone="danger">{error} <button className="text-link" onClick={() => setRevision(value => value + 1)}>Reload search websites</button></Notice>}
    {portals === undefined && !error && <p role="status">Loading saved search websites...</p>}
    <ul className="portal-bookmarks">{portals?.map(portal => <li key={portal.id}>
      <div><ExternalLink href={searchPortalUrl(portal.urlTemplate, role, location)}>{portal.label}</ExternalLink><span className="small muted">{portal.builtIn ? "Official website" : "Your bookmark"} · No login status is checked</span></div>
      {!portal.builtIn && <div className="button-row"><button className="text-link" disabled={busy} onClick={() => { setDraft({ id: portal.id, label: portal.label, urlTemplate: portal.urlTemplate }); setError(""); }}>Edit<span className="sr-only"> {portal.label}</span></button><button className="text-link danger-text" disabled={busy} onClick={() => {
        if (!window.confirm(`Remove the ${portal.label} bookmark? Saved jobs and applications are unchanged.`)) return;
        void run("Removing manual bookmark...", async () => {
          const result = await post<SearchPortalList>("/api/search-portals", { action: "remove", id: portal.id });
          if (!Array.isArray(result.portals)) throw new Error("The service did not return updated search websites.");
          setPortals(result.portals); if (draft.id === portal.id) setDraft({ id: "", label: "", urlTemplate: "" });
        }, "Bookmark removed. No application records were changed.");
      }}>Remove<span className="sr-only"> {portal.label}</span></button></div>}
    </li>)}</ul>
    <form onSubmit={event => void save(event)}>
      <h3>{draft.id ? "Edit search website" : "Add a custom search website"}</h3>
      <div className="form-grid"><Field label="Website name">{id => <input id={id} required maxLength={100} value={draft.label} disabled={busy} onChange={event => setDraft({ ...draft, label: event.target.value })} />}</Field><Field label="HTTPS search URL template" hint="Optional placeholders: {role} and {location}. This URL is bookmarked, never fetched by the service.">{id => <input id={id} required maxLength={2000} value={draft.urlTemplate} disabled={busy} placeholder="https://jobs.example.com/search?q={role}&where={location}" onChange={event => setDraft({ ...draft, urlTemplate: event.target.value })} />}</Field></div>
      <div className="button-row"><button className="button secondary" disabled={busy || !draft.label.trim() || !draft.urlTemplate.trim()} type="submit">Save search website</button>{draft.id && <button className="button text-button" type="button" onClick={() => setDraft({ id: "", label: "", urlTemplate: "" })}>Cancel website edit</button>}</div>
    </form>
  </section>;
}
