import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import type { FormField, HumanTask } from "../../../packages/domain/types";
import { api, download, post } from "./api";
import { dateTime, errorMessage, type HistoryItem, type RunAction, type State } from "./model";
import { Badge, ExternalLink, Field, Notice } from "./ui";

export function protectedQuestion(field: FormField): boolean {
  const text = `${field.key} ${field.label} ${field.type}`.replace(/([a-z])([A-Z])/g, "$1 $2").replaceAll("_", " ");
  return !["text", "textarea", "email", "tel", "url", "number", "date", "select", "select-one", "radio", "checkbox"].includes(field.type.toLowerCase())
    || /password|passcode|\botp\b|one.?time|verification code|security code|\bssn\b|social security|passport|national ident|aadhaar|aadhar|pan card|tax.?id|demograph|\beeo\b|gender|pronoun|\bsex\b|race|racial|ethnic|religio|disabil|veteran|birth|\bdob\b|marital|sexual|legal|consent|terms|agree|certif|declar|attest|privacy|assessment|quiz|coding test|captcha|mfa|2fa|login|sign.?in|criminal|convict|background check|citizenship|work authori|sponsor/i.test(text);
}

export function HumanAttention({ state, busy, run, viewPacket }: { state: State; busy: boolean; run: RunAction; viewPacket: (id: string) => void }) {
  const tasks = state.autopilot?.humanTasks;
  const active = tasks?.filter(task => ["waiting", "resuming", "session_lost"].includes(task.status)) ?? [];
  const history = tasks?.filter(task => task.status === "resolved" || task.status === "abandoned") ?? [];
  return <section className="auto-section human-attention" id="human-attention" aria-labelledby="human-attention-title">
    <div className="section-heading"><div><h2 id="human-attention-title">Needs your attention</h2><p>Continue the existing prefilled application, not a new attempt.</p></div>{tasks && <Badge tone={active.length ? "warning" : "neutral"}>{active.length} attention records</Badge>}</div>
    {tasks === undefined ? <Notice tone="warning">Human review status unavailable. The local service did not return this capability; do not assume all forms can run automatically.</Notice> : !active.length ? <p className="quiet-empty">No applications waiting for you. New blockers appear here; nothing has been submitted just because this queue is empty.</p> : active.map(task => <HumanTaskCard key={task.id} task={task} state={state} busy={busy} run={run} viewPacket={viewPacket} />)}
    <p className="small muted">Up to 10 prefilled tabs can be parked at once. This is a browser resource limit, not a daily application cap. Resolve or abandon waiting applications to make room for the backlog.</p>
    {!!history.length && <details className="human-history"><summary>Human review history · {history.length}</summary><ul>{history.map(task => <li key={task.id}><strong>{task.status === "resolved" ? "Resolved" : "Abandoned"}</strong> · {task.reason} · {dateTime(task.updatedAt)} <button className="text-link" onClick={() => viewPacket(task.packetId)}>View packet outcome</button></li>)}</ul></details>}
  </section>;
}

function HumanTaskCard({ task, state, busy, run, viewPacket }: { task: HumanTask; state: State; busy: boolean; run: RunAction; viewPacket: (id: string) => void }) {
  const [detail, setDetail] = useState<HistoryItem>();
  const [detailError, setDetailError] = useState("");
  const [detailRevision, setDetailRevision] = useState(0);
  const packet = state.packets.find(packet => packet.id === task.packetId) ?? detail?.packet;
  const job = state.jobs.find(job => job.id === task.jobId) ?? detail?.job;
  useEffect(() => {
    if (packet && job) return;
    const controller = new AbortController();
    setDetailError("");
    void api<HistoryItem>(`/api/packets/${encodeURIComponent(task.packetId)}`, { signal: controller.signal }).then(item => {
      if (!item.packet || !item.job || item.packet.id !== task.packetId || item.job.id !== task.jobId) throw new Error("Exact packet details were not returned.");
      if (!controller.signal.aborted) setDetail(item);
    }).catch(cause => { if (!controller.signal.aborted) setDetailError(errorMessage(cause)); });
    return () => controller.abort();
  }, [task.packetId, task.jobId, !!packet, !!job, detailRevision]);
  const base = state.resumeVariants?.find(variant => variant.id === (packet?.tailoring?.baseVariantId ?? packet?.variantId));
  const baseIsExact = base && (!packet?.tailoring || base.artifact.sha256 === packet.tailoring.baseVariantSha256);
  const waiting = task.status === "waiting";
  const canContinue = waiting && task.canContinue !== false && !!job && !!packet
    && packet.status === "awaiting_human" && job.aiPolicy !== "prohibited";
  const editableFields = task.missingFields.filter(field => !protectedQuestion(field));
  const protectedFields = task.missingFields.filter(protectedQuestion);
  const signature = JSON.stringify([task.status, task.reason, task.step, task.missingFields, task.filledFields, task.packetId, packet?.answers, packet?.artifacts]);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [reviewed, setReviewed] = useState("");
  const [useCurrentValues, setUseCurrentValues] = useState(false);
  const [answerError, setAnswerError] = useState("");
  const [abandon, setAbandon] = useState(false);
  useEffect(() => { setAnswers({}); setReviewed(""); setUseCurrentValues(false); setAnswerError(""); }, [signature]);
  const valueFor = (field: FormField) => answers[field.key] ?? packet?.answers[field.key] ?? "";
  const reviewCurrent = reviewed === signature;
  const unfinished = editableFields.some(field => field.required && !valueFor(field).trim());

  async function continueApplication(event: FormEvent) {
    event.preventDefault();
    if (!canContinue || !reviewCurrent || busy || (!useCurrentValues && unfinished)) return;
    const supplied: Record<string, string> = {};
    for (const field of editableFields) {
      const value = valueFor(field).trim();
      if (!value || (useCurrentValues && answers[field.key] === undefined)) continue;
      if (field.options.length && !field.options.includes(value)) { setAnswerError(`Choose an actual option for ${field.label}.`); return; }
      supplied[field.key] = value;
    }
    await run("Continuing this exact prefilled application…", async () => {
      await post(`/api/hitl/${encodeURIComponent(task.id)}/continue`, { answers: supplied, useCurrentValues, confirmReview: true });
      setReviewed(""); setAnswers({}); setUseCurrentValues(false);
    }, "Continuation requested for the existing session. Watch its next step or receipt; this is not a submission confirmation.");
  }

  return <article className="human-task" aria-label={`Human review: ${job ? `${job.company} · ${job.title}` : task.jobId}`}>
    <div className="section-heading"><div><h3>{job ? `${job.company} · ${job.title}` : `Application ${task.jobId}`}</h3><p>Step {task.step} · {task.status === "session_lost" ? "Session lost" : task.status === "resuming" ? "Continuing existing session" : "Prefilled tab waiting"}</p></div><Badge tone={task.status === "session_lost" ? "danger" : "warning"}>{task.status.replaceAll("_", " ")}</Badge></div>
    <ExternalLink href={job?.applyUrl || task.url}>Actual employer application</ExternalLink>
    <p className="human-task-url">{task.url}</p>
    <p className="human-task-reason"><strong>Why it paused:</strong> {task.reason || "No reason provided by the service."}</p>
    {task.status === "waiting" && task.waitingFor === "captcha" && <Notice><strong>Only the CAPTCHA is left.</strong> Solve it in its tab in the Chairman window (the tab title starts with 🔐). Chairman notices and submits by itself; you do not need to click anything here.</Notice>}
    {task.status === "waiting" && task.waitingFor === "captcha_after_submit" && <Notice><strong>Submit opened a CAPTCHA.</strong> Solve it in its tab. Chairman then confirms the receipt; it never clicks Submit a second time.</Notice>}
    {detailError && <Notice tone="warning">{detailError} <button className="text-link" onClick={() => setDetailRevision(value => value + 1)}>Retry exact packet details</button></Notice>}
    <div className="human-fields"><div><h4>Already filled · field names only</h4>{task.filledFields.length ? <ul>{task.filledFields.map((field, index) => <li key={index}>{field}</li>)}</ul> : <p className="small muted">No filled fields reported.</p>}</div><div><h4>Pending questions</h4>{task.missingFields.length ? <ul>{task.missingFields.map(field => <li key={field.key}>{field.label}{field.required ? " · required" : " · optional"}{protectedQuestion(field) && " · browser/manual only"}{field.options.length > 0 && <span className="small muted"> — {field.options.map(option => field.optionLabels?.[option] || option).join(" / ")}</span>}</li>)}</ul> : <p className="small muted">No missing field names reported. Review the blocker in the browser.</p>}</div></div>
    <div className="human-documents"><h4>Resume for this application</h4><p className="small">{packet?.tailoring ? `Selected base: ${packet.tailoring.baseVariantLabel} · ${packet.tailoring.baseVariantId}` : base ? `Selected original: ${base.label}` : "Selected base metadata unavailable; inspect the exact packet."}</p>
      <div className="button-row">{baseIsExact && <button className="button secondary compact" disabled={busy || job?.aiPolicy === "prohibited"} onClick={() => void run("Downloading selected base…", () => download(`/api/resume-variants/${encodeURIComponent(base.id)}/file`, base.originalFilename))}>Download selected base {base.artifact.format.toUpperCase()}</button>}
        {packet?.artifacts.map(artifact => <button key={artifact.format} className="button secondary compact" disabled={busy || job?.aiPolicy === "prohibited"} onClick={() => void run("Downloading this packet’s resume…", () => download(`/api/packets/${encodeURIComponent(packet.id)}/documents/${artifact.format}`, artifact.filename))}>Download {packet.tailoring ? "derived" : "packet"} {artifact.format.toUpperCase()}</button>)}
        <button className="text-link" onClick={() => viewPacket(task.packetId)}>View exact packet & history</button></div>
    </div>
    <Notice>Login, CAPTCHA, legal declarations, assessments, and No-AI restrictions are never bypassed. Protected answers belong only in the employer’s browser form. Required legal terms are not accepted automatically. Factual answers entered here are one-off; they are not guessed or saved to your global profile.</Notice>
    {(task.canContinue === false || packet?.status === "submission_unknown") && <Notice tone="danger">A submission may already have occurred. Automatic continuation is disabled; inspect the existing tab and record only a receipt you actually verified.</Notice>}
    <p className="small muted">Already submitted yourself? <button className="text-link" onClick={() => viewPacket(task.packetId)}>Record a verified receipt in Applications</button>. Do not click Submit again just to update this tracker.</p>
    {job?.aiPolicy === "prohibited" && <Notice tone="danger">This employer prohibits AI assistance. Complete its application manually using your own words; dashboard answers and automatic continuation are unavailable.</Notice>}
    {waiting && (!job || !packet) && <p className="small muted">Exact job and packet details must load before continuation is available. You can still focus the existing tab to inspect it yourself.</p>}
    {task.status === "session_lost" ? <Notice tone="danger"><strong>This session cannot continue.</strong> Do not create a replacement attempt. Check the actual employer destination and packet history for a possible submission, then manually reconcile any unknown outcome in Applications.</Notice> : <>
      <button className="button secondary" disabled={busy || !waiting} onClick={() => void run("Focusing the existing prefilled tab…", async () => { await post(`/api/hitl/${encodeURIComponent(task.id)}/focus`, {}); }, "Existing prefilled tab focused. Review it there; no new application was opened.")}>Open existing prefilled tab</button>
      {canContinue && <form className="human-answer-form" onSubmit={event => void continueApplication(event)}>
        {editableFields.map(field => <Field key={field.key} label={`Answer: ${field.label}`} hint={field.required ? "Required unless supplied directly in the browser." : "Optional. Leave blank to omit."}>{id => {
          const common = { id, value: valueFor(field), disabled: busy, onChange: (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => { setAnswers(current => ({ ...current, [field.key]: event.target.value })); setReviewed(""); setAnswerError(""); } };
          return field.options.length ? <select {...common}><option value="">Choose an answer</option>{field.options.map(option => <option key={option} value={option}>{field.optionLabels?.[option] || option}</option>)}</select> : <textarea {...common} rows={2} autoComplete="off" />;
        }}</Field>)}
        {!!protectedFields.length && <p className="small muted">Protected questions are listed above for context only. Complete them manually in the existing browser; no protected answer will be sent from this dashboard.</p>}
        <label className="checkbox-label"><input type="checkbox" checked={useCurrentValues} disabled={busy} onChange={event => { setUseCurrentValues(event.target.checked); setReviewed(""); }} /><span>I supplied answers directly in the browser; use its current values for fields not answered here.</span></label>
        <label className="checkbox-label human-review-check"><input type="checkbox" required checked={reviewCurrent} disabled={busy} onChange={event => setReviewed(event.target.checked ? signature : "")} /><span>I checked the current prefilled form and supplied the missing answers; continue this application</span></label>
        {answerError && <p className="field-error" role="alert">{answerError}</p>}
        {!useCurrentValues && unfinished && <p className="small muted">Supply the missing required factual answers, or explicitly approve the current values you entered in the browser.</p>}
        <button className="button primary" type="submit" disabled={busy || !reviewCurrent || (!useCurrentValues && unfinished)}>Continue this application</button>
      </form>}
    </>}
    <div className="human-abandon">{abandon ? <><p>Close this owned browser session and pause its record? This does not withdraw a submitted application.</p><div className="button-row"><button className="button danger-quiet" disabled={busy || task.status === "resuming"} onClick={() => void run("Abandoning the parked session…", async () => { await post(`/api/hitl/${encodeURIComponent(task.id)}/abandon`, { confirm: true }); setAbandon(false); }, "Session abandoned. Any submitted application has not been withdrawn.")}>Confirm abandon session</button><button className="button text-button" disabled={busy} onClick={() => setAbandon(false)}>Keep session</button></div></> : <button className="button text-button danger-text" disabled={busy || task.status === "resuming"} onClick={() => setAbandon(true)}>Abandon this session</button>}</div>
  </article>;
}
