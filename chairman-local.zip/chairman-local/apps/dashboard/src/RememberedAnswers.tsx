import { useEffect, useState } from "react";
import { api, post } from "./api";
import type { RunAction } from "./model";

interface Remembered { question: string; value: string; updatedAt: string }

/** Answers you chose to remember from Chrome page assistance, plus the cache of validated AI suggestions. */
export function RememberedAnswers({ busy, run }: { busy: boolean; run: RunAction }) {
  const [items, setItems] = useState<Remembered[] | undefined>();
  const [error, setError] = useState("");
  useEffect(() => {
    api<{ items: Remembered[] }>("/api/assist-answers").then(result => setItems(result.items)).catch((value: unknown) => setError(value instanceof Error ? value.message : "Could not load remembered answers."));
  }, []);
  const forget = (question: string) => run("Forgetting remembered answer...", async () => {
    setItems((await post<{ items: Remembered[] }>("/api/assist-answers/forget", { questions: [question] })).items);
  }, "Forgotten. The next plan asks you (or your AI) again for that exact question.");
  const clearAi = () => run("Clearing cached AI suggestions...", async () => {
    const result = await post<{ cleared: number }>("/api/assist-answers/clear-ai", { confirm: true });
    setError(result.cleared ? "" : "There were no cached AI suggestions.");
  }, "Cached AI suggestions cleared. Remembered answers were kept.");
  return <section className="remembered-answers" aria-labelledby="remembered-title">
    <h3 id="remembered-title">Remembered page answers</h3>
    <p className="small muted">When you fill a page with the Chrome extension, you can remember your answer to an exact question. Chairman then reuses it word for word on any form that asks the same question, before any AI help. Your saved answers above always take precedence.</p>
    {error && <p className="small muted" role="status">{error}</p>}
    {items && !items.length && <p className="small muted">Nothing remembered yet.</p>}
    {!!items?.length && <dl>{items.map(item => <div key={item.question}>
      <dt>{item.question}</dt>
      <dd><span>{item.value}</span><button className="text-link" type="button" disabled={busy} onClick={() => void forget(item.question)}>Forget</button></dd>
    </div>)}</dl>}
    <p className="small muted">AI suggestions for page questions are cached by question, job and facts so the same form is always planned the same way. Clear the cache if you want fresh suggestions.</p>
    <button className="button secondary compact" type="button" disabled={busy} onClick={() => void clearAi()}>Clear cached AI suggestions</button>
  </section>;
}
