import { useEffect, useState, type Dispatch, type SetStateAction } from "react";
import { dateTime, errorMessage, type AutopilotView, type State } from "./model";
import { Badge, Field, Notice } from "./ui";

export type MonitorConnection = "connecting" | "live" | "reconnecting" | "unavailable" | "idle";

export function useMonitorEvents(enabled: boolean, setState: Dispatch<SetStateAction<State | null>>): MonitorConnection {
  const [connection, setConnection] = useState<MonitorConnection>("idle");
  useEffect(() => {
    if (!enabled) { setConnection("idle"); return; }
    if (!/^https?:$/.test(window.location.protocol) || typeof EventSource === "undefined") { setConnection("unavailable"); return; }
    let source: EventSource | undefined;
    let reconnect: number | undefined;
    let disposed = false;
    setConnection("connecting");
    const receive = (event: MessageEvent) => {
      try {
        const { autopilot } = JSON.parse(event.data) as { autopilot: AutopilotView };
        if (!autopilot || !Array.isArray(autopilot.jobs) || !autopilot.rules || typeof autopilot.enabled !== "boolean" || !autopilot.snapshotHash) throw new Error("Invalid monitor event");
        setState(current => current ? { ...current, autopilot } : current);
        setConnection("live");
      } catch { setConnection("unavailable"); }
    };
    function connect() {
      if (disposed) return;
      try { source = new EventSource("/api/monitor/events"); }
      catch { setConnection("unavailable"); return; }
      source.onopen = () => setConnection("live");
      source.onerror = () => {
        setConnection("reconnecting");
        if (source?.readyState === 2) {
          source.removeEventListener("monitor", receive as EventListener);
          source.close();
          window.clearTimeout(reconnect);
          reconnect = window.setTimeout(connect, 5_000);
        }
      };
      source.addEventListener("monitor", receive as EventListener);
    }
    connect();
    return () => { disposed = true; window.clearTimeout(reconnect); source?.removeEventListener("monitor", receive as EventListener); source?.close(); };
  }, [enabled, setState]);
  return connection;
}

export function LiveMonitor({ state, visible, connection }: { state: State; visible: boolean; connection: MonitorConnection }) {
  const view = state.autopilot!;
  const events = view.liveEvents?.slice(-30);
  return <section className="auto-section live-monitor" aria-labelledby="live-monitor-title">
    <div className="section-heading"><div><h2 id="live-monitor-title">Live progress</h2><p>Discovery → match → prefill → human review when needed → receipt.</p></div><Badge tone={connection === "live" ? "positive" : "warning"}>{connection === "live" ? "Live connection" : connection === "connecting" ? "Connecting to live updates" : "Polling fallback"}</Badge></div>
    {["reconnecting", "unavailable"].includes(connection) && <div role="status"><Notice tone="warning"><strong>Live updates {connection === "reconnecting" ? "disconnected; reconnecting" : "unavailable"}.</strong> Existing five-second polling continues. Refresh if the local service remains unavailable; no submission is implied by stale progress.</Notice></div>}
    <p className="discovery-status"><strong>Job discovery:</strong> {view.discoveryStatus || "Status unavailable from the local service."}</p>
    {events === undefined ? <Notice tone="warning">The service did not return live events. Timeline unavailable; this is not an empty or successful run.</Notice> : events.length ? <ol className="monitor-timeline" aria-label="Application progress timeline">{events.map(event => {
      const job = state.jobs.find(job => job.id === event.jobId);
      return <li key={event.id}><time dateTime={event.timestamp}>{dateTime(event.timestamp)}</time><div><strong>{event.phase.replaceAll("_", " ")}</strong><p>{event.message}</p>{event.jobId && <span className="small muted">{job ? `${job.company} · ${job.title}` : `Job ${event.jobId}`}</span>}</div></li>;
    })}</ol> : <p className="quiet-empty">No activity recorded yet. Discovery and applications start only within your saved settings and explicit authorization.</p>}
    <LiveBrowser view={view} visible={visible} />
    <p className="small muted">Only a recorded receipt confirms submission. A filled field, upload, or click does not. Desktop notifications are optional and requested only when you enable them below.</p>
  </section>;
}

function LiveBrowser({ view, visible }: { view: AutopilotView; visible: boolean }) {
  const [show, setShow] = useState(false);
  const [sessionId, setSessionId] = useState("");
  const [image, setImage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [documentVisible, setDocumentVisible] = useState(document.visibilityState === "visible");
  const sessions = view.humanTasks?.filter(task => task.status === "waiting" || task.status === "resuming") ?? [];
  const selectedSession = sessions.some(task => task.sessionId === sessionId) ? sessionId : "";
  const active = view.browserRunning || sessions.length > 0;
  useEffect(() => {
    const update = () => setDocumentVisible(document.visibilityState === "visible");
    document.addEventListener("visibilitychange", update);
    return () => document.removeEventListener("visibilitychange", update);
  }, []);
  useEffect(() => { if (!visible) setShow(false); }, [visible]);
  useEffect(() => {
    if (!show || !visible || !documentVisible) return;
    const controller = new AbortController();
    let fetching = false;
    let objectUrl = "";
    async function refreshImage() {
      if (fetching) return;
      fetching = true;
      setLoading(true);
      try {
        const query = new URLSearchParams({ t: String(Date.now()), ...(selectedSession ? { sessionId: selectedSession } : {}) });
        const response = await fetch(`/api/monitor/screenshot?${query}`, { credentials: "same-origin", cache: "no-store", signal: controller.signal });
        if (!response.ok) throw new Error(response.status === 404 ? "No live browser is available for this session." : `Private preview unavailable (${response.status}).`);
        if (!response.headers.get("content-type")?.startsWith("image/png")) throw new Error("The service did not return a redacted browser image.");
        const blob = await response.blob();
        if (controller.signal.aborted) return;
        const next = URL.createObjectURL(blob);
        if (objectUrl) URL.revokeObjectURL(objectUrl);
        objectUrl = next;
        setImage(next); setError("");
      } catch (cause) {
        if (!controller.signal.aborted) {
          if (objectUrl) URL.revokeObjectURL(objectUrl);
          objectUrl = ""; setImage(""); setError(errorMessage(cause));
        }
      } finally { fetching = false; if (!controller.signal.aborted) setLoading(false); }
    }
    void refreshImage();
    const timer = active ? window.setInterval(() => void refreshImage(), 2_000) : undefined;
    return () => { controller.abort(); window.clearInterval(timer); if (objectUrl) URL.revokeObjectURL(objectUrl); setImage(""); setLoading(false); };
  }, [show, visible, documentVisible, selectedSession, active]);
  return <div className="live-browser">
    <button className="button secondary" aria-expanded={show} onClick={() => setShow(value => !value)}>{show ? "Hide live browser" : "Show live browser"}</button>
    <p className="small muted">Opt-in preview from your private local endpoint. Passwords and all input values are masked by the service. Refreshes every two seconds while visible and a browser session is active.</p>
    {show && <div className="live-browser-preview">
      {!!sessions.length && <Field label="Browser session">{id => <select id={id} value={selectedSession} onChange={event => setSessionId(event.target.value)}><option value="">Current active browser</option>{sessions.map(task => <option key={task.id} value={task.sessionId}>Step {task.step} · {task.url}</option>)}</select>}</Field>}
      {error && <div role="status"><Notice tone="warning">{error} Keep the application paused and use its existing browser tab or check the local service.</Notice></div>}
      {!error && !image && <p role="status">{loading ? "Loading redacted browser view…" : "Preview paused while this page is not visible."}</p>}
      {image && <img src={image} alt="Live application browser with all input values masked" />}
    </div>}
  </div>;
}
