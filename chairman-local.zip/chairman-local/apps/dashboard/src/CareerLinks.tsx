import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import type { CareerBoardTarget, CareerLinkResolution, CareerSource } from "../../../packages/domain/types";
import { api, post } from "./api";
import { dateTime, errorMessage, type RunAction, type State } from "./model";
import { Badge, ExternalLink, Field, Icon, Notice } from "./ui";
import "./career-links.css";

const providers: Record<CareerBoardTarget["provider"], string> = { ashby: "Ashby", greenhouse: "Greenhouse", lever: "Lever", smartrecruiters: "SmartRecruiters",
  workday: "Workday", eightfold: "Eightfold", oracle: "Oracle Recruiting", rippling: "Rippling", google: "Google Careers", apple: "Apple Jobs", atlassian: "Atlassian Careers",
  nutanix: "Nutanix Careers", generic: "Generic career page" };
const statuses: Record<CareerSource["status"], { label: string; tone: "neutral" | "positive" | "warning" | "danger" }> = {
  resolving: { label: "Resolving link", tone: "neutral" },
  scanning: { label: "Scanning", tone: "neutral" },
  ready: { label: "Ready", tone: "positive" },
  paused: { label: "Paused", tone: "warning" },
  unsupported: { label: "Unsupported", tone: "warning" },
  error: { label: "Scan error", tone: "danger" },
};

function httpsUrl(value: string): string | undefined {
  if (!/^https:\/\//i.test(value.trim())) return undefined;
  try {
    const url = new URL(value.trim());
    if (url.protocol === "https:" && !url.username && !url.password) return url.href;
  } catch { /* The form shows a recoverable validation error. */ }
  return undefined;
}

async function readSources(signal?: AbortSignal): Promise<CareerSource[]> {
  const result = await api<{ sources?: CareerSource[] } | null>("/api/career-links", { signal });
  if (!Array.isArray(result?.sources)) throw new Error("The local service did not return career sources. Update the service, then retry.");
  return result.sources;
}

function destinationUrl(target: CareerBoardTarget): string | undefined {
  const board = httpsUrl(target.boardUrl);
  if (!board) return undefined;
  if (!target.jobId || !["greenhouse", "ashby"].includes(target.provider)) return board;
  const validId = target.provider === "greenhouse" ? /^[1-9]\d*$/.test(target.jobId)
    : /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(target.jobId);
  if (!validId) return undefined;
  return httpsUrl(`${board.replace(/\/$/, "")}/${target.provider === "greenhouse" ? "jobs/" : ""}${target.jobId}${target.provider === "ashby" ? "/application" : ""}`);
}

function Destination({ target }: { target: CareerBoardTarget }) {
  const url = destinationUrl(target);
  return <div className="career-destination">
    <span><strong>{providers[target.provider]}</strong> · {target.board}{target.jobId && <> · Job {target.jobId}</>}</span>
    {url && <ExternalLink href={url}>{url}</ExternalLink>}
  </div>;
}

export function CareerLinks({ state, busy, run }: { state: State; busy: boolean; run: RunAction }) {
  const id = useId();
  const [url, setUrl] = useState("");
  const [label, setLabel] = useState("");
  const [intent, setIntent] = useState(false);
  const [sources, setSources] = useState<CareerSource[]>(state.careerSources ?? []);
  const [sourcesLoaded, setSourcesLoaded] = useState(state.careerSources !== undefined);
  const [lastResult, setLastResult] = useState<{ resolution: CareerLinkResolution; inputUrl: string; label: string; saved: boolean }>();
  const [selected, setSelected] = useState("");
  const [error, setError] = useState("");
  const [invalidUrl, setInvalidUrl] = useState(false);
  const [pollError, setPollError] = useState("");
  const [pending, setPending] = useState(false);
  const [removeId, setRemoveId] = useState<string>();
  const [now, setNow] = useState(Date.now);
  const operation = useRef(false);
  const generation = useRef(0);
  const urlInput = useRef<HTMLInputElement>(null);
  const resultHeading = useRef<HTMLHeadingElement>(null);
  const removeConfirm = useRef<HTMLButtonElement>(null);
  const removeTrigger = useRef<HTMLButtonElement>(null);
  const sectionHeading = useRef<HTMLHeadingElement>(null);
  const disabled = busy || pending;
  const scanning = sources.some(source => source.status === "resolving" || source.status === "scanning");
  const missingSources = state.careerSources === undefined;

  useEffect(() => {
    generation.current += 1;
    if (state.careerSources !== undefined) {
      setSources(state.careerSources);
      setSourcesLoaded(true);
      setPollError("");
    }
  }, [state.careerSources]);

  useEffect(() => {
    if (disabled || (!scanning && !missingSources)) return;
    const controller = new AbortController();
    let fetching = false;
    async function refreshSources() {
      if (fetching || document.visibilityState !== "visible") return;
      fetching = true;
      const version = generation.current;
      try {
        const result = await readSources(controller.signal);
        if (!controller.signal.aborted && version === generation.current) {
          setSources(result);
          setSourcesLoaded(true);
          setPollError("");
        }
      } catch (cause) {
        if (!controller.signal.aborted && version === generation.current) setPollError(`Career link status could not refresh. ${errorMessage(cause)}`);
      } finally {
        fetching = false;
      }
    }
    if (missingSources) void refreshSources();
    const timer = scanning ? window.setInterval(() => void refreshSources(), 5_000) : undefined;
    return () => { controller.abort(); window.clearInterval(timer); };
  }, [disabled, scanning, missingSources]);

  useEffect(() => {
    const next = Math.min(...sources.map(source => Date.parse(source.nextScanAt ?? "")).filter(at => at > Date.now()));
    if (!Number.isFinite(next)) return;
    const timer = window.setTimeout(() => setNow(Date.now()), Math.min(next - Date.now() + 50, 2_147_483_647));
    return () => window.clearTimeout(timer);
  }, [sources, now]);

  useEffect(() => { if (removeId) removeConfirm.current?.focus(); }, [removeId]);
  useEffect(() => { if (lastResult) resultHeading.current?.focus(); }, [lastResult]);

  async function perform(actionLabel: string, action: () => Promise<void>) {
    if (disabled || operation.current) return;
    operation.current = true;
    generation.current += 1;
    setPending(true);
    setError("");
    try {
      await run(actionLabel, async () => {
        try { await action(); }
        catch (cause) { setError(errorMessage(cause)); throw cause; }
      });
    } catch (cause) {
      setError(errorMessage(cause));
    } finally {
      operation.current = false;
      setPending(false);
    }
  }

  async function add(inputUrl: string, friendlyLabel: string) {
    await perform("Resolving career link…", async () => {
      const result = await post<{ source?: CareerSource; resolution: CareerLinkResolution }>("/api/career-links", {
        url: inputUrl, ...(friendlyLabel.trim() ? { label: friendlyLabel.trim() } : {}),
      });
      setLastResult({ resolution: result.resolution, inputUrl, label: friendlyLabel, saved: !!result.source });
      setSelected("");
      if (result.source) {
        const source = result.source;
        setSources(current => [source, ...current.filter(item => item.id !== source.id)]);
        setSourcesLoaded(true);
        setUrl("");
        setLabel("");
        setIntent(false);
      }
    });
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    if (disabled) return;
    const normalized = httpsUrl(url);
    if (!normalized) {
      setInvalidUrl(true);
      setError("Enter a complete HTTPS career URL, without a username or password. For example, https://jobs.ashbyhq.com/company.");
      urlInput.current?.focus();
      return;
    }
    if (!intent) { setError("Confirm that matching jobs may be considered under your reviewed Auto Apply rules. This does not activate applications."); return; }
    setInvalidUrl(false);
    void add(normalized, label);
  }

  async function changeSource(source: CareerSource, action: "scan" | "enabled" | "remove") {
    const verb = action === "scan" ? "Scanning" : action === "remove" ? "Removing" : source.enabled ? "Pausing" : "Resuming";
    await perform(`${verb} ${source.label}…`, async () => {
      await post(`/api/career-links/${encodeURIComponent(source.id)}/${action}`, action === "enabled" ? { enabled: !source.enabled } : {});
      if (action === "remove") {
        setSources(current => current.filter(item => item.id !== source.id));
        setRemoveId(undefined);
        sectionHeading.current?.focus();
      }
      try {
        const result = await readSources();
        setSources(result);
        setSourcesLoaded(true);
        setPollError("");
      } catch (cause) {
        setPollError(`The source change was saved, but its latest status could not refresh. ${errorMessage(cause)}`);
      }
    });
  }

  function cancelRemove() {
    setRemoveId(undefined);
    removeTrigger.current?.focus();
  }

  const candidates = lastResult && !lastResult.saved && !lastResult.resolution.target ? lastResult.resolution.candidates : [];

  return <section className="career-links" aria-labelledby={`${id}-heading`}>
    <div className="section-heading">
      <div><h2 id={`${id}-heading`} ref={sectionHeading} tabIndex={-1}>Add a career link</h2><p>Find matching jobs from a company’s career board or an individual job link.</p></div>
    </div>
    <form className="career-link-form" onSubmit={submit} noValidate aria-busy={pending}>
      <div className="career-link-fields">
        <Field label="Career URL (HTTPS)">{fieldId => <input id={fieldId} ref={urlInput} type="url" inputMode="url" required autoComplete="off" spellCheck={false} placeholder="https://jobs.ashbyhq.com/company" value={url} disabled={disabled} aria-invalid={invalidUrl || undefined} aria-describedby={`${id}-supported${invalidUrl ? ` ${id}-error` : ""}`} onChange={event => { setUrl(event.target.value); setInvalidUrl(false); }} />}</Field>
        <Field label="Friendly label (optional)">{fieldId => <input id={fieldId} type="text" autoComplete="off" placeholder="e.g. Company engineering" value={label} disabled={disabled} onChange={event => setLabel(event.target.value)} />}</Field>
      </div>
      <p id={`${id}-supported`} className="small muted">Add Ashby, Greenhouse, or generic company career pages and individual jobs. Public JSON-LD listings and linked job details can be discovered in bounded scans. JavaScript-only pages or listings without a readable job description may need a direct job link or manual import. This is not support for every portal. LinkedIn, Wellfound, Naukri, and blocked destinations remain manual.</p>
      <label className="career-link-intent"><input type="checkbox" required checked={intent} disabled={disabled} aria-describedby={`${id}-authorization`} onChange={event => setIntent(event.target.checked)} /><span>I want matching jobs from this source considered for Auto Apply under my reviewed rules</span></label>
      <div className="career-link-submit"><button className="button primary" type="submit" disabled={disabled || !intent}><Icon name="plus" size={16} />{pending ? "Working…" : "Add career link"}</button><span className="small muted">Starts discovery. Does not activate applications.</span></div>
    </form>
    <div id={`${id}-authorization`} className="career-link-authorization">
      <Notice><strong>Review before applying.</strong> Adding, removing, or re-enabling a source changes your authorization scope and pauses Auto Apply. Review your sources and rules, then explicitly activate in Auto Apply. Eligible jobs from enabled links can then join the runner with your reviewed resume mode, including JD-specific tailoring. Site policies and missing required answers still block applications.</Notice>
    </div>
    {error && <div id={`${id}-error`} role="alert"><Notice tone="danger">{error}</Notice></div>}
    {lastResult && <div className="career-link-result">
      <h3 ref={resultHeading} tabIndex={-1}>{lastResult.saved ? "Career source saved" : candidates.length ? "Choose a career board" : "Link needs attention"}</h3>
      <p className="small muted career-result-url">Result for {lastResult.inputUrl}</p>
      <div role="status"><Notice tone={lastResult.saved ? "info" : "warning"}>{lastResult.resolution.message}{lastResult.saved && <> This did not activate Auto Apply.</>}</Notice></div>
      {lastResult.resolution.target && <Destination target={lastResult.resolution.target} />}
      {!!candidates.length && <>
        <p className="small muted">More than one destination was found. Nothing has been added. Choose the intended board or individual job; nothing is selected automatically.</p>
        <fieldset className="career-candidates" disabled={disabled}><legend>Select one destination</legend>
          {candidates.map((candidate, index) => {
            const normalized = destinationUrl(candidate);
            return <div className="career-candidate" key={`${candidate.boardUrl}-${index}`}>
              <label><input type="radio" name={`${id}-candidate`} value={normalized ?? ""} checked={!!normalized && selected === normalized} disabled={!normalized} onChange={() => setSelected(normalized!)} /><span><strong>{providers[candidate.provider]} · {candidate.board}{candidate.jobId && ` · Job ${candidate.jobId}`}</strong><span className="career-candidate-url">{normalized ?? "Invalid destination: a complete HTTPS URL is required."}</span></span></label>
              {normalized && <ExternalLink href={normalized}>Inspect destination</ExternalLink>}
            </div>;
          })}
        </fieldset>
        <button type="button" className="button primary" disabled={disabled || !selected || !intent} onClick={() => { if (selected && intent) void add(selected, lastResult.label); }}>Add selected board<Icon name="arrow" size={15} /></button>
      </>}
    </div>}
    {pollError && <div role="status"><Notice tone="warning">{pollError} Use Refresh to try again; your unsaved link is kept.</Notice></div>}
    <div className="career-saved-heading"><h3>Saved career links</h3><span className="small muted">{sourcesLoaded ? `${sources.length} saved` : pollError ? "Status unavailable" : "Loading…"}</span></div>
    {!sourcesLoaded ? <p className="career-links-empty">{pollError ? "Saved career links could not be loaded. Existing sources have not been removed." : "Loading saved career links…"}</p> : !sources.length ? <p className="career-links-empty">No saved career links yet. Add one above to discover jobs without authorizing an application.</p> : <div className="career-source-list">
      {sources.map(source => {
        const status = source.status === "ready" && !source.enabled ? statuses.paused : statuses[source.status];
        const activeScan = source.status === "resolving" || source.status === "scanning";
        const cooldown = !!source.nextScanAt && Date.parse(source.nextScanAt) > Math.max(now, Date.now());
        const canScan = source.enabled && !!source.target && source.status !== "unsupported" && !activeScan && !cooldown;
        const confirming = removeId === source.id;
        return <article className="career-source" key={source.id} aria-label={source.label}>
          <div className="career-source-heading"><h4>{source.label}</h4><div className="tag-group"><Badge tone={status.tone}>{status.label}</Badge>{cooldown && source.enabled && !activeScan && <Badge tone="warning">Cooling down</Badge>}</div></div>
          {source.target ? <Destination target={source.target} /> : <ExternalLink href={source.inputUrl}>{source.inputUrl}</ExternalLink>}
          {source.message && <p className={`career-source-message${source.status === "error" ? " danger-text" : ""}`}><strong className="sr-only">{source.status === "error" ? "Latest error: " : "Source status: "}</strong>{source.message}</p>}
          <dl className="career-source-meta"><div><dt>Imported jobs</dt><dd>{source.jobCount.toLocaleString()}</dd></div><div><dt>Last scan</dt><dd>{dateTime(source.lastScannedAt)}</dd></div><div><dt>Next scan allowed</dt><dd>{source.nextScanAt ? dateTime(source.nextScanAt) : source.enabled ? "Available now" : "Resume to scan"}</dd></div></dl>
          {!source.enabled && source.status !== "unsupported" && <p className="small muted">This source is paused. Resume it to discover jobs, then review and activate Auto Apply again.</p>}
          <div className="button-row career-source-actions">
            <button type="button" className="button secondary compact" disabled={disabled || !canScan} onClick={() => void changeSource(source, "scan")}><Icon name="refresh" size={15} />{activeScan ? "Scan in progress" : "Scan now"}</button>
            <button type="button" className="button secondary compact" disabled={disabled || !source.target || source.status === "unsupported"} onClick={() => void changeSource(source, "enabled")}><Icon name={source.enabled ? "pause" : "arrow"} size={15} />{source.enabled ? "Pause source" : "Resume source"}</button>
            <button type="button" className="button danger-quiet compact" disabled={disabled} aria-expanded={confirming} onClick={event => { removeTrigger.current = event.currentTarget; setRemoveId(confirming ? undefined : source.id); }}>Remove…</button>
          </div>
          {confirming && <div className="career-remove-confirm" role="group" aria-label={`Remove ${source.label}?`} onKeyDown={event => { if (event.key === "Escape" && !disabled) cancelRemove(); }}>
            <p><strong>Remove {source.label}?</strong> Future discovery from this link stops and Auto Apply pauses for a fresh review. An in-flight application may still complete.</p>
            <div className="button-row"><button type="button" ref={removeConfirm} className="button secondary compact" disabled={disabled} onClick={cancelRemove}>Keep source</button><button type="button" className="button danger compact" disabled={disabled} onClick={() => void changeSource(source, "remove")}>Confirm removal</button></div>
          </div>}
        </article>;
      })}
    </div>}
  </section>;
}
