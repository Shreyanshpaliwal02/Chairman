import { expect, test, type Page } from "@playwright/test";
import { createServer, type ViteDevServer } from "vite";
import { resolve } from "node:path";
import type { CareerBoardTarget, CareerLinkResolution, CareerSource } from "../../../packages/domain/types";
import type { State } from "../src/model";

let server: ViteDevServer;
let origin: string;
test.beforeAll(async () => {
  server = await createServer({
    configFile: resolve("apps/dashboard/vite.config.ts"),
    cacheDir: resolve("apps/dashboard/.test-cache"),
    server: { host: "127.0.0.1", port: 0, open: false },
  });
  await server.listen();
  origin = server.resolvedUrls!.local[0]!;
});
test.afterAll(async () => { await server?.close(); });

const ashby: CareerBoardTarget = { provider: "ashby", board: "synthetic-ui-board", boardUrl: "https://jobs.ashbyhq.com/synthetic-ui-board" };
const greenhouse: CareerBoardTarget = { provider: "greenhouse", board: "synthetic-second-board", boardUrl: "https://job-boards.greenhouse.io/synthetic-second-board" };
const intentLabel = "I want matching jobs from this source considered for Auto Apply under my reviewed rules";

function careerSource(overrides: Partial<CareerSource> = {}): CareerSource {
  return {
    id: "synthetic-career-source", inputUrl: ashby.boardUrl, label: "Synthetic engineering", target: ashby,
    enabled: true, status: "ready", message: "Synthetic scan complete. No real jobs or applications.",
    createdAt: "2026-09-15T10:00:00Z", updatedAt: "2026-09-15T10:00:00Z",
    jobCount: 3, lastScannedAt: "2026-09-15T10:00:00Z", ...overrides,
  };
}

function syntheticState(sources: CareerSource[] = []): State {
  return {
    profile: { name: "Synthetic Candidate", email: "candidate@example.invalid", phone: "", location: "Test City", links: {}, skills: [], facts: [], answers: {}, confirmed: false, version: 1, preferences: { roles: ["software"], countries: ["India"], excludedEmployers: [], salaryTargetInr: 0, dailyLimit: null, timezone: "Asia/Kolkata", allowLongTermContracts: false, authorizedCountries: ["India"], needsSponsorshipAbroad: true } },
    resumeVariants: [],
    autopilot: { enabled: false, ready: false, blockers: ["Synthetic profile and resumes need review."], rules: { providers: ["ashby", "greenhouse"], minimumScore: 70, allowUnknownSalary: true, allowUnknownSponsorship: false, allowUnknownRemoteEligibility: false, intervalSeconds: 30, stopAtDailyGoal: false, employerAllowlist: [] }, snapshotHash: "synthetic-snapshot", jobs: [], browserRunning: false, status: "Paused" },
    campaign: { config: { startDate: "2026-09-15", days: 45, dailyTarget: 500, timezone: "Asia/Kolkata" }, endDate: "2026-10-29", dayNumber: 1, daysRemaining: 45, totalTarget: 22500, confirmedToday: 0, confirmedTotal: 0, targetToDate: 500, remainingToGoal: 22500, interviews: 0, offers: 0, followUpsDue: 0, interviewRate: 0, untrackedSubmissionDates: 0, daily: [], sources: [] },
    jobs: [], packets: [], sources: [], careerSources: sources, referenceResumes: [], preparationQueue: [],
    stats: { attemptsToday: 0, attemptsSession: 0, limit: null, submitted: 0, totalJobs: 0, stopped: false },
    runtime: { ai: { available: false, model: "synthetic-only" }, cloud: { configured: false }, extension: { paired: false } },
  };
}

interface AddReply { source?: CareerSource; resolution: CareerLinkResolution }
interface MockOptions {
  addReplies?: AddReply[];
  careerSourcesReply?: unknown;
  failure?: { path: string; message: string; status: number };
  navigation?: "Sources" | "Auto Apply";
}

async function workspace(page: Page, state = syntheticState(), options: MockOptions = {}) {
  const writes: { path: string; body: Record<string, unknown> }[] = [];
  const errors: string[] = [];
  const reads = { careers: 0, state: 0 };
  page.on("pageerror", error => errors.push(error.message));
  await page.route("**/*", async route => {
    const request = route.request();
    const url = new URL(request.url());
    if (url.origin !== new URL(origin).origin) return route.abort();
    if (!url.pathname.startsWith("/api/")) return route.continue();
    const reply = (body: unknown, status = 200) => route.fulfill({ status, json: body });
    if (request.method() === "GET") {
      if (url.pathname === "/api/state") { reads.state++; return reply(state); }
      if (url.pathname === "/api/career-links") { reads.careers++; return reply(options.careerSourcesReply ?? { sources: state.careerSources ?? [] }); }
      if (url.pathname === "/api/session") return reply({});
      return reply({ items: [], total: 0, offset: 0, limit: 50 });
    }
    const body = request.postDataJSON() as Record<string, unknown>;
    writes.push({ path: url.pathname, body });
    if (options.failure?.path === url.pathname) return reply({ error: options.failure.message }, options.failure.status);
    if (url.pathname === "/api/career-links") {
      const result = options.addReplies?.shift() ?? {
        source: careerSource({ inputUrl: body.url as string, label: body.label as string || ashby.board }),
        resolution: { target: ashby, candidates: [], message: "Synthetic Ashby board resolved. Discovery scheduled." },
      };
      if (result.source) {
        state.careerSources = [result.source, ...(state.careerSources ?? []).filter(source => source.id !== result.source!.id)];
        state.autopilot!.enabled = false;
        state.autopilot!.snapshotHash = `synthetic-source-change-${writes.length}`;
      }
      return reply(result);
    }
    const action = url.pathname.match(/^\/api\/career-links\/([^/]+)\/(scan|enabled|remove)$/);
    if (action) {
      const id = decodeURIComponent(action[1]!);
      const source = state.careerSources?.find(source => source.id === id);
      if (!source) return reply({ error: "Synthetic source not found." }, 404);
      if (action[2] === "remove") state.careerSources = state.careerSources!.filter(source => source.id !== id);
      else if (action[2] === "enabled") { source.enabled = body.enabled as boolean; source.status = source.enabled ? "ready" : "paused"; }
      else { source.status = "scanning"; source.message = "Synthetic bounded scan in progress."; }
      if (action[2] !== "scan") { state.autopilot!.enabled = false; state.autopilot!.snapshotHash = `synthetic-source-change-${writes.length}`; }
      return reply({ source });
    }
    return reply({});
  });
  await page.goto(origin);
  await page.getByRole("button", { name: options.navigation ?? "Sources", exact: true }).click();
  const panel = page.getByRole("region", { name: "Add a career link", exact: true });
  await expect(panel).toBeVisible();
  return { panel, writes, errors, reads, state };
}

test("state-provided career sources need no initial fallback request", async ({ page }) => {
  const { panel, reads, errors } = await workspace(page, syntheticState([careerSource()]), { careerSourcesReply: {} });
  await expect(panel.getByRole("article")).toContainText("Synthetic engineering");
  expect(reads.careers).toBe(0);
  await expect(panel.getByText("Status unavailable", { exact: true })).toHaveCount(0);
  expect(errors).toEqual([]);
});

test("missing state sources fall back to the career-link endpoint", async ({ page }) => {
  const state = syntheticState();
  delete state.careerSources;
  const { panel, reads, errors } = await workspace(page, state, { careerSourcesReply: { sources: [careerSource()] } });
  await expect(panel.getByRole("article")).toContainText("Synthetic engineering");
  expect(reads.careers).toBeGreaterThanOrEqual(1);
  await expect(panel.getByText("1 saved", { exact: true })).toBeVisible();
  expect(errors).toEqual([]);
});

test("a missing career-sources response is unavailable, not a successful empty list", async ({ page }) => {
  const state = syntheticState();
  delete state.careerSources;
  const { panel, writes, errors } = await workspace(page, state, { careerSourcesReply: {} });
  await expect(panel.getByText("Status unavailable", { exact: true })).toBeVisible();
  await expect(panel.getByText("Saved career links could not be loaded.", { exact: false })).toBeVisible();
  await expect(panel.getByText("No saved career links yet.", { exact: false })).toHaveCount(0);
  await expect(panel.getByText("0 saved", { exact: true })).toHaveCount(0);
  await expect(panel.getByLabel("Career URL (HTTPS)")).toBeEnabled();
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("adding a hosted board starts discovery, not Auto Apply", async ({ page }) => {
  const { panel, writes, errors, state } = await workspace(page);
  await expect(panel.getByLabel(intentLabel)).not.toBeChecked();
  await expect(panel.getByRole("button", { name: "Add career link", exact: true })).toBeDisabled();
  await panel.getByLabel("Career URL (HTTPS)").fill(`  ${ashby.boardUrl}  `);
  await panel.getByLabel("Friendly label (optional)").fill("Synthetic engineering");
  await panel.getByLabel(intentLabel).check();
  await panel.getByRole("button", { name: "Add career link", exact: true }).click();
  await expect(panel.getByRole("heading", { name: "Career source saved" })).toBeVisible();
  const source = panel.getByRole("article", { name: "Synthetic engineering", exact: true });
  await expect(source).toContainText("Ashby");
  await expect(source.getByRole("link")).toHaveAttribute("href", ashby.boardUrl);
  await expect(source.locator("dd").first()).toHaveText("3");
  await expect(panel.getByLabel(intentLabel)).not.toBeChecked();
  await expect(panel.getByLabel("Career URL (HTTPS)")).toHaveValue("");
  expect(writes).toEqual([{ path: "/api/career-links", body: { url: ashby.boardUrl, label: "Synthetic engineering" } }]);
  expect(state.autopilot!.enabled).toBe(false);
  expect(errors).toEqual([]);
  await panel.screenshot({ path: test.info().outputPath("career-links-desktop.png") });
});

test("an individual hosted job preserves its explicit destination and omits an empty label", async ({ page }) => {
  const target = { ...greenhouse, jobId: "123456" };
  const inputUrl = `${greenhouse.boardUrl}/jobs/123456`;
  const { panel, writes, errors } = await workspace(page, syntheticState(), {
    addReplies: [{ source: careerSource({ target, inputUrl }), resolution: { target, candidates: [], message: "Synthetic individual job resolved." } }],
  });
  await panel.getByLabel("Career URL (HTTPS)").fill(inputUrl);
  await panel.getByLabel(intentLabel).check();
  await panel.getByRole("button", { name: "Add career link", exact: true }).click();
  const source = panel.getByRole("article");
  await expect(source).toContainText("Greenhouse");
  await expect(source).toContainText("Job 123456");
  await expect(source.getByRole("link")).toHaveAttribute("href", inputUrl);
  expect(writes).toEqual([{ path: "/api/career-links", body: { url: inputUrl } }]);
  expect(errors).toEqual([]);
});

test("generic company and job URLs keep their canonical destination without ATS path synthesis", async ({ page }) => {
  const canonical = "https://careers.example.invalid/engineering/custom-role";
  const target: CareerBoardTarget = { provider: "generic", board: "careers.example.invalid", boardUrl: canonical, jobId: canonical };
  const { panel, writes, errors } = await workspace(page, syntheticState(), {
    addReplies: [{ source: careerSource({ target, inputUrl: canonical }), resolution: { target, candidates: [], message: "Synthetic generic job resolved from public structured data." } }],
  });
  await panel.getByLabel("Career URL (HTTPS)").fill(canonical);
  await panel.getByLabel(intentLabel).check();
  await panel.getByRole("button", { name: "Add career link", exact: true }).click();
  await expect(panel.getByRole("article")).toContainText("Generic career page");
  await expect(panel.getByRole("article").getByRole("link")).toHaveAttribute("href", canonical);
  await expect(panel.getByText(/Public JSON-LD listings/)).toBeVisible();
  expect(writes).toEqual([{ path: "/api/career-links", body: { url: canonical } }]);
  expect(errors).toEqual([]);
});

test("choosing one job among same-board candidates does not broaden the source to the whole board", async ({ page }) => {
  const first = { ...greenhouse, jobId: "123" }, second = { ...greenhouse, jobId: "456" };
  const inputUrl = "https://example.invalid/careers";
  const specific = `${greenhouse.boardUrl}/jobs/456`;
  const { panel, writes, errors } = await workspace(page, syntheticState(), {
    addReplies: [
      { resolution: { candidates: [first, second], message: "Choose a specific job." } },
      { source: careerSource({ target: second, inputUrl: specific }), resolution: { target: second, candidates: [], message: "Selected job only." } }
    ]
  });
  await panel.getByLabel("Career URL (HTTPS)").fill(inputUrl);
  await panel.getByLabel(intentLabel).check();
  await panel.getByRole("button", { name: "Add career link", exact: true }).click();
  const selected = panel.getByRole("radio", { name: /Job 456/ });
  await selected.check();
  await expect(panel.getByRole("radio", { name: /Job 123/ })).not.toBeChecked();
  await panel.getByRole("button", { name: "Add selected board" }).click();
  expect(writes[1]!.body.url).toBe(specific);
  await expect(panel.getByRole("article").getByRole("link")).toHaveAttribute("href", specific);
  expect(errors).toEqual([]);
});

test("ambiguous pages require an explicit board choice before saving", async ({ page }) => {
  const inputUrl = "https://example.invalid/synthetic-careers";
  const { panel, writes, errors } = await workspace(page, syntheticState(), {
    addReplies: [
      { resolution: { candidates: [ashby, { ...greenhouse, boardUrl: "https://job-boards.greenhouse.io:443/synthetic-second-board" }], message: "Two synthetic ATS destinations were found." } },
      { source: careerSource({ target: greenhouse, inputUrl: greenhouse.boardUrl }), resolution: { target: greenhouse, candidates: [], message: "Synthetic Greenhouse board chosen." } },
    ],
  });
  await panel.getByLabel("Career URL (HTTPS)").fill(inputUrl);
  await panel.getByLabel("Friendly label (optional)").fill("Synthetic engineering");
  await panel.getByLabel(intentLabel).check();
  await panel.getByRole("button", { name: "Add career link", exact: true }).click();
  await expect(panel.getByRole("heading", { name: "Choose a career board" })).toBeFocused();
  await expect(panel.getByText("Two synthetic ATS destinations were found.")).toBeVisible();
  await expect(panel.getByRole("article")).toHaveCount(0);
  await expect(panel.getByRole("radio")).toHaveCount(2);
  for (const radio of await panel.getByRole("radio").all()) await expect(radio).not.toBeChecked();
  const addSelected = panel.getByRole("button", { name: "Add selected board" });
  await expect(addSelected).toBeDisabled();
  await panel.getByRole("radio", { name: /Greenhouse/ }).check();
  await addSelected.click();
  await expect(panel.getByRole("article")).toContainText("Greenhouse");
  expect(writes).toEqual([
    { path: "/api/career-links", body: { url: inputUrl, label: "Synthetic engineering" } },
    { path: "/api/career-links", body: { url: greenhouse.boardUrl, label: "Synthetic engineering" } },
  ]);
  expect(errors).toEqual([]);
});

for (const [caseName, inputUrl] of Object.entries({
  "insecure URL": "http://example.invalid/careers",
  "script URL": "javascript:alert(1)",
  "plain text": "not a URL",
  "credentials in URL": "https://user:secret@example.invalid/careers",
  "missing slashes": "https:example.invalid/careers",
})) {
  test(`rejects an invalid HTTPS career URL locally: ${caseName}`, async ({ page }) => {
    const { panel, writes, errors } = await workspace(page);
    await panel.getByLabel("Career URL (HTTPS)").fill(inputUrl);
    await panel.getByLabel("Friendly label (optional)").fill("Keep this draft");
    await panel.getByLabel(intentLabel).check();
    await panel.getByRole("button", { name: "Add career link", exact: true }).click();
    await expect(panel.getByRole("alert")).toContainText("Enter a complete HTTPS career URL");
    await expect(panel.getByLabel("Career URL (HTTPS)")).toBeFocused();
    await expect(panel.getByLabel("Career URL (HTTPS)")).toHaveAttribute("aria-invalid", "true");
    await expect(panel.getByLabel("Friendly label (optional)")).toHaveValue("Keep this draft");
    expect(writes).toEqual([]); expect(errors).toEqual([]);
  });
}

test("unsupported pages show the resolution without saving or claiming permissions", async ({ page }) => {
  const { panel, writes, errors } = await workspace(page, syntheticState(), {
    addReplies: [{ resolution: { candidates: [], message: "Synthetic custom portal is unsupported. Open the employer site and apply manually." } }],
  });
  await panel.getByLabel("Career URL (HTTPS)").fill("https://example.invalid/custom-portal");
  await panel.getByLabel(intentLabel).check();
  await panel.getByRole("button", { name: "Add career link", exact: true }).click();
  await expect(panel.getByRole("heading", { name: "Link needs attention" })).toBeVisible();
  await expect(panel.getByText("Synthetic custom portal is unsupported.", { exact: false })).toBeVisible();
  await expect(panel.getByRole("article")).toHaveCount(0);
  await expect(panel.getByLabel("Career URL (HTTPS)")).toHaveValue("https://example.invalid/custom-portal");
  expect(writes.map(write => write.path)).toEqual(["/api/career-links"]);
  expect(errors).toEqual([]);
});

test("API errors are prominent and retry keeps the original URL and label", async ({ page }) => {
  const options: MockOptions = { failure: { path: "/api/career-links", message: "Synthetic resolver unavailable. Retry shortly.", status: 503 } };
  const { panel, writes, errors } = await workspace(page, syntheticState(), options);
  await panel.getByLabel("Career URL (HTTPS)").fill(ashby.boardUrl);
  await panel.getByLabel("Friendly label (optional)").fill("Retry this source");
  await panel.getByLabel(intentLabel).check();
  await panel.getByRole("button", { name: "Add career link", exact: true }).click();
  await expect(panel.getByRole("alert")).toContainText("Synthetic resolver unavailable. Retry shortly.");
  await expect(panel.getByRole("article")).toHaveCount(0);
  await expect(panel.getByLabel("Career URL (HTTPS)")).toHaveValue(ashby.boardUrl);
  await expect(panel.getByLabel("Friendly label (optional)")).toHaveValue("Retry this source");
  delete options.failure;
  await panel.getByRole("button", { name: "Add career link", exact: true }).click();
  await expect(panel.getByRole("heading", { name: "Career source saved" })).toBeVisible();
  expect(writes).toHaveLength(2);
  expect(writes[1]!.body).toEqual(writes[0]!.body);
  expect(errors).toEqual([]);
});

test("a pending link request disables duplicate adds and source mutations", async ({ page }) => {
  const { panel, writes, errors } = await workspace(page, syntheticState([careerSource()]));
  let release!: () => void;
  const pendingRequest = new Promise<void>(resolve => { release = resolve; });
  await page.route("**/api/career-links", async route => {
    if (route.request().method() === "POST") await pendingRequest;
    await route.fallback();
  });
  await panel.getByLabel("Career URL (HTTPS)").fill(greenhouse.boardUrl);
  await panel.getByLabel(intentLabel).check();
  await panel.getByRole("button", { name: "Add career link", exact: true }).click();
  await expect(panel.getByLabel("Career URL (HTTPS)")).toBeDisabled();
  await expect(panel.getByLabel("Friendly label (optional)")).toBeDisabled();
  await expect(panel.getByLabel(intentLabel)).toBeDisabled();
  for (const button of await panel.getByRole("button").all()) await expect(button).toBeDisabled();
  release();
  await expect(panel.getByRole("heading", { name: "Career source saved" })).toBeVisible();
  expect(writes).toHaveLength(1);
  expect(errors).toEqual([]);
});

test("paused, error and cooldown states expose scan boundaries and truthful metadata", async ({ page }) => {
  const sources = [
    careerSource({ id: "paused", label: "Synthetic paused", enabled: false, status: "paused", jobCount: 0, lastScannedAt: undefined }),
    careerSource({ id: "error", label: "Synthetic error", status: "error", message: "Synthetic scan failed. Retry when available." }),
    careerSource({ id: "cooldown", label: "Synthetic cooldown", nextScanAt: new Date(Date.now() + 3_600_000).toISOString() }),
    careerSource({ id: "unsupported", label: "Synthetic unsupported", status: "unsupported", enabled: false, target: undefined, message: "Synthetic custom portal requires manual review." }),
  ];
  const { panel, writes, errors } = await workspace(page, syntheticState(sources));
  const paused = panel.getByRole("article", { name: "Synthetic paused" });
  await expect(paused.getByRole("button", { name: "Scan now" })).toBeDisabled();
  await expect(paused.getByRole("button", { name: "Resume source" })).toBeEnabled();
  await expect(paused).toContainText("Not yet");
  const failed = panel.getByRole("article", { name: "Synthetic error" });
  await expect(failed).toContainText("Scan error");
  await expect(failed).toContainText("Synthetic scan failed.");
  await expect(failed.getByRole("button", { name: "Scan now" })).toBeEnabled();
  const cooldown = panel.getByRole("article", { name: "Synthetic cooldown" });
  await expect(cooldown).toContainText("Cooling down");
  await expect(cooldown).toContainText("Next scan allowed");
  await expect(cooldown.getByRole("button", { name: "Scan now" })).toBeDisabled();
  const unsupported = panel.getByRole("article", { name: "Synthetic unsupported" });
  await expect(unsupported.getByRole("button", { name: "Resume source" })).toBeDisabled();
  await expect(unsupported.getByRole("button", { name: "Scan now" })).toBeDisabled();
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("scan, pause, resume and confirmed removal never call activation", async ({ page }) => {
  const { panel, writes, errors, state } = await workspace(page, syntheticState([careerSource()]));
  const source = panel.getByRole("article", { name: "Synthetic engineering", exact: true });
  await source.getByRole("button", { name: "Scan now" }).click();
  await expect(source.getByRole("button", { name: "Scan in progress" })).toBeDisabled();
  await source.getByRole("button", { name: "Pause source" }).click();
  await expect(source.getByRole("button", { name: "Resume source" })).toBeEnabled();
  await source.getByRole("button", { name: "Resume source" }).click();
  await expect(source.getByRole("button", { name: "Pause source" })).toBeEnabled();
  await source.getByRole("button", { name: "Remove…" }).click();
  await expect(source.getByRole("button", { name: "Keep source" })).toBeFocused();
  expect(writes).toHaveLength(3);
  await page.keyboard.press("Escape");
  await expect(source.getByRole("button", { name: "Confirm removal" })).toHaveCount(0);
  await expect(source.getByRole("button", { name: "Remove…" })).toBeFocused();
  await source.getByRole("button", { name: "Remove…" }).click();
  await source.getByRole("button", { name: "Confirm removal" }).click();
  await expect(panel.getByRole("article")).toHaveCount(0);
  expect(writes).toEqual([
    { path: "/api/career-links/synthetic-career-source/scan", body: {} },
    { path: "/api/career-links/synthetic-career-source/enabled", body: { enabled: false } },
    { path: "/api/career-links/synthetic-career-source/enabled", body: { enabled: true } },
    { path: "/api/career-links/synthetic-career-source/remove", body: {} },
  ]);
  expect(state.autopilot!.enabled).toBe(false);
  expect(errors).toEqual([]);
});

test("a scan cooldown error remains visible without inventing a successful scan", async ({ page }) => {
  const { panel, errors } = await workspace(page, syntheticState([careerSource()]), {
    failure: { path: "/api/career-links/synthetic-career-source/scan", message: "Synthetic cooldown: next scan allowed in ten minutes.", status: 429 },
  });
  await panel.getByRole("button", { name: "Scan now" }).click();
  await expect(panel.getByRole("alert")).toContainText("Synthetic cooldown: next scan allowed in ten minutes.");
  await expect(panel.getByRole("button", { name: "Scan in progress" })).toHaveCount(0);
  await expect(panel.getByRole("article").locator("dd").first()).toHaveText("3");
  expect(errors).toEqual([]);
});

test("resolving and scanning sources poll at five seconds without replacing unsaved input", async ({ page }) => {
  await page.clock.install();
  const state = syntheticState([careerSource({ status: "resolving", jobCount: 0, message: "Resolving a synthetic source." })]);
  const { panel, reads, writes, errors } = await workspace(page, state);
  await panel.getByLabel("Career URL (HTTPS)").fill("https://example.invalid/not-saved");
  await panel.getByLabel("Friendly label (optional)").fill("Unsaved label");
  await panel.getByLabel(intentLabel).check();
  state.careerSources![0]!.status = "scanning";
  state.careerSources![0]!.message = "Scanning a synthetic source.";
  await page.clock.fastForward(5_100);
  await expect.poll(() => reads.careers).toBeGreaterThanOrEqual(1);
  await expect(panel.getByRole("article")).toContainText("Scanning a synthetic source.");
  state.careerSources![0]!.status = "ready";
  state.careerSources![0]!.jobCount = 7;
  await page.clock.fastForward(5_100);
  await expect(panel.getByRole("article").locator("dd").first()).toHaveText("7");
  await expect(panel.getByLabel("Career URL (HTTPS)")).toHaveValue("https://example.invalid/not-saved");
  await expect(panel.getByLabel("Friendly label (optional)")).toHaveValue("Unsaved label");
  await expect(panel.getByLabel(intentLabel)).toBeChecked();
  const completedReads = reads.careers;
  await page.clock.fastForward(10_100);
  expect(reads.careers).toBe(completedReads);
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("a cooldown expires without needing to re-open the page", async ({ page }) => {
  await page.clock.install();
  const { panel, writes, errors } = await workspace(page, syntheticState([careerSource({ nextScanAt: new Date(Date.now() + 60_000).toISOString() })]));
  await expect(panel.getByRole("button", { name: "Scan now" })).toBeDisabled();
  await page.clock.fastForward(60_100);
  await expect(panel.getByRole("button", { name: "Scan now" })).toBeEnabled();
  await expect(panel.getByText("Cooling down", { exact: true })).toHaveCount(0);
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("mobile drafts survive state refresh without horizontal overflow", async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 812 });
  const longBoard = `${ashby.boardUrl}-${"synthetic-long-destination-".repeat(8)}`;
  const { panel, writes, errors } = await workspace(page, syntheticState([careerSource({ target: { ...ashby, boardUrl: longBoard } })]));
  await panel.getByLabel("Career URL (HTTPS)").fill("https://example.invalid/mobile-draft");
  await panel.getByLabel("Friendly label (optional)").fill("Keep my mobile label");
  await panel.getByLabel(intentLabel).check();
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await expect(panel.getByLabel("Career URL (HTTPS)")).toHaveValue("https://example.invalid/mobile-draft");
  await expect(panel.getByLabel("Friendly label (optional)")).toHaveValue("Keep my mobile label");
  await expect(panel.getByLabel(intentLabel)).toBeChecked();
  const dimensions = await page.evaluate(() => ({ width: document.documentElement.clientWidth, content: document.documentElement.scrollWidth }));
  expect(dimensions.content).toBeLessThanOrEqual(dimensions.width);
  const button = panel.getByRole("button", { name: "Add career link", exact: true });
  expect((await button.boundingBox())!.height).toBeGreaterThanOrEqual(44);
  expect(writes).toEqual([]); expect(errors).toEqual([]);
  await panel.screenshot({ path: test.info().outputPath("career-links-mobile.png") });
});

test("Auto Apply embeds discovery without silently activating applications", async ({ page }) => {
  const { panel, writes, errors } = await workspace(page, syntheticState(), { navigation: "Auto Apply" });
  await panel.getByLabel("Career URL (HTTPS)").fill(ashby.boardUrl);
  await panel.getByLabel(intentLabel).check();
  await panel.getByRole("button", { name: "Add career link", exact: true }).click();
  await expect(panel.getByRole("heading", { name: "Career source saved" })).toBeVisible();
  await expect(page.getByRole("button", { name: "Activate Auto Apply", exact: true })).toBeDisabled();
  expect(writes.map(write => write.path)).toEqual(["/api/career-links"]);
  expect(errors).toEqual([]);
});
