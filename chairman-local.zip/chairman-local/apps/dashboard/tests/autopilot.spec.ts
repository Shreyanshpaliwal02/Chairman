import { test, expect, type Page } from "@playwright/test";
import { createServer, type ViteDevServer } from "vite";
import { resolve } from "node:path";
import type { Packet, State } from "../src/model";
import type { HumanTask } from "../../../packages/domain/types";

declare global {
  interface Window {
    __monitor: {
      sources: { url: string; closed: boolean; onerror: (() => void) | null }[];
      emit: (autopilot: State["autopilot"]) => void;
      revoked: string[];
    };
  }
}

let server: ViteDevServer;
let origin: string;
test.beforeAll(async () => {
  server = await createServer({
    configFile: resolve("apps/dashboard/vite.config.ts"),
    cacheDir: resolve("apps/dashboard/.test-cache"),
    server: { host: "127.0.0.1", port: 0, open: false },
  });
  await server.listen();
  origin = server.resolvedUrls!.local[0]!;
});
test.afterAll(async () => { await server?.close(); });

function syntheticState(): State {
  return {
    profile: { name: "Synthetic Candidate", email: "candidate@example.invalid", phone: "", location: "Test City", links: {}, skills: ["Python"], facts: [{ id: "fact-test", category: "experience", text: "Synthetic experience for a UI test only.", confirmed: true }], answers: { first_name: "Synthetic", last_name: "Candidate" }, confirmed: true, version: 1, preferences: { roles: ["software"], countries: ["India"], excludedEmployers: [], salaryTargetInr: 0, dailyLimit: null, timezone: "Asia/Kolkata", allowLongTermContracts: false, authorizedCountries: ["India"], needsSponsorshipAbroad: true } },
    resumeVariants: [1, 2, 3, 4].map(slot => ({ id: `variant-${slot}`, slot, label: `Synthetic resume ${slot}`, families: ["software"], originalFilename: `synthetic-resume-${slot}.docx`, artifact: { format: "docx", filename: `synthetic-resume-${slot}.docx`, bytes: 128, sha256: `synthetic-hash-${slot}` }, uploadedAt: "2026-09-15T10:00:00Z", approved: true, textLength: 300, issues: [] })),
    autopilot: { enabled: false, ready: true, blockers: [], rules: { providers: ["ashby", "greenhouse"], minimumScore: 70, allowUnknownSalary: true, allowUnknownSponsorship: false, allowUnknownRemoteEligibility: false, intervalSeconds: 30, stopAtDailyGoal: false, employerAllowlist: [], humanInLoop: true, autoDiscover: true }, snapshotHash: "synthetic-snapshot-one", jobs: [], humanTasks: [], liveEvents: [], discoveryStatus: "Not started · paused", browserRunning: false, status: "Paused" },
    campaign: { config: { startDate: "2026-09-15", days: 45, dailyTarget: 500, timezone: "Asia/Kolkata" }, endDate: "2026-10-29", dayNumber: 1, daysRemaining: 45, totalTarget: 22500, confirmedToday: 0, confirmedTotal: 0, targetToDate: 500, remainingToGoal: 22500, interviews: 0, offers: 0, followUpsDue: 0, interviewRate: 0, untrackedSubmissionDates: 0, daily: [], sources: [] },
    jobs: [{ id: "synthetic-job", sourceId: "synthetic-source", sourceJobId: "synthetic-job", title: "Synthetic Software Engineer", company: "Synthetic Employer", location: "Test City", remote: true, countries: ["India"], employmentType: "full-time", description: "Synthetic listing; never a real application.", applyUrl: "https://example.invalid/synthetic-job", canonicalUrl: "https://example.invalid/synthetic-job", fetchedAt: "2026-09-15T10:00:00Z", salary: null, language: null, sponsorship: "unknown", aiPolicy: "allowed", status: "open", match: { score: 90, matchedSkills: ["Python"], missingSkills: [], reasons: [], warnings: [], blockers: [], eligible: true, needsReview: false } }],
    packets: [], sources: [{ id: "synthetic-source", name: "Synthetic Ashby", kind: "ashby", mode: "enabled", careersUrl: "https://example.invalid", discoveryAllowed: true, assistanceAllowed: true, submissionAllowed: true, policyUrl: "", notes: "Synthetic test source." }],
    careerSources: [], referenceResumes: [], preparationQueue: [], stats: { attemptsToday: 0, attemptsSession: 0, limit: null, submitted: 0, totalJobs: 1, stopped: false },
    runtime: { ai: { available: false, model: "test-only" }, cloud: { configured: false }, extension: { paired: false } },
  };
}

function tailoredPacket(state: State, baseId = "variant-1", engine: "deterministic" | "local-ai" = "deterministic"): Packet {
  const base = state.resumeVariants!.find(variant => variant.id === baseId)!;
  const { name, email, phone, location, links, facts, skills } = structuredClone(state.profile);
  return {
    id: "synthetic-tailored-packet", jobId: "synthetic-job", jobHash: "synthetic-job-hash", profileHash: "synthetic-profile-hash", profileVersion: state.profile.version,
    draft: { mode: "jd-tailored", factIds: facts.map(fact => fact.id), skills, keywordTerms: ["Python"], notes: ["Synthetic derived resume, not a real application."] },
    artifacts: (["pdf", "docx"] as const).map(format => ({ format, filename: `synthetic-job-tailored.${format}`, sha256: `synthetic-derived-${format}-hash`, bytes: 128 })),
    answers: { first_name: "Synthetic" }, warnings: [], status: "prepared", createdAt: "2026-09-15T10:00:00Z", variantId: baseId,
    tailoring: { baseVariantId: baseId, baseVariantLabel: base.label, baseVariantSha256: base.artifact.sha256, jobDescriptionHash: "synthetic-description-hash", engine, supportedKeywords: ["Python"], missingKeywords: ["Unevidenced Synthetic Skill"], notes: ["Only confirmed synthetic facts selected."] },
    resumeContent: { name, email, phone, location, links, facts, skills, keywordTerms: ["Python"] },
  };
}

async function mockWorkspace(page: Page, state: State, openSetup = true) {
  const writes: { path: string; body: any; raw: string }[] = [];
  const documentRequests: string[] = [];
  const reads = { state: 0, screenshots: [] as string[] };
  const errors: string[] = [];
  await page.addInitScript(() => {
    const sources: SyntheticEventSource[] = [];
    class SyntheticEventSource extends EventTarget {
      url: string;
      closed = false;
      onopen: (() => void) | null = null;
      onerror: (() => void) | null = null;
      constructor(url: string) { super(); this.url = url; sources.push(this); queueMicrotask(() => this.onopen?.()); }
      close() { this.closed = true; }
    }
    window.EventSource = SyntheticEventSource as unknown as typeof EventSource;
    window.__monitor = { sources, emit: autopilot => sources.filter(source => !source.closed).forEach(source => source.dispatchEvent(new MessageEvent("monitor", { data: JSON.stringify({ autopilot }) }))), revoked: [] };
    const revoke = URL.revokeObjectURL.bind(URL);
    URL.revokeObjectURL = url => { window.__monitor.revoked.push(url); revoke(url); };
  });
  page.on("pageerror", error => errors.push(error.message));
  await page.route("**/*", async route => {
    const request = route.request();
    const url = new URL(request.url());
    if (url.origin !== new URL(origin).origin) { await route.abort(); return; }
    if (!url.pathname.startsWith("/api/")) { await route.continue(); return; }
    const reply = (body: unknown, status = 200) => route.fulfill({ status, json: body });
    if (request.method() === "GET") {
      if (url.pathname === "/api/state") { reads.state++; return reply(state); }
      if (url.pathname === "/api/session") return reply({});
      if (url.pathname === "/api/monitor/screenshot") {
        reads.screenshots.push(`${url.pathname}${url.search}`);
        return route.fulfill({ contentType: "image/png", body: Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j4mQAAAAASUVORK5CYII=", "base64") });
      }
      if (url.pathname === "/api/history" || url.pathname === "/api/jobs" || url.pathname === "/api/external-applications") return reply({ items: [], total: 0, offset: 0, limit: 50 });
      if (/^\/api\/packets\/[^/]+\/documents\/(pdf|docx)$/.test(url.pathname)) {
        documentRequests.push(url.pathname);
        return route.fulfill({ contentType: url.pathname.endsWith("pdf") ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document", body: "Synthetic document bytes only." });
      }
      if (url.pathname.startsWith("/api/packets/")) {
        const packet = state.packets.find(packet => packet.id === decodeURIComponent(url.pathname.split("/")[3]!));
        return reply({ packet, job: state.jobs.find(job => job.id === packet?.jobId) });
      }
      return reply({});
    }
    const raw = request.postData() || "";
    const body = request.headers()["content-type"]?.includes("application/json") ? request.postDataJSON() : undefined;
    writes.push({ path: url.pathname, body, raw });
    if (url.pathname === "/api/autopilot/rules") { state.autopilot!.rules = body.rules; state.autopilot!.enabled = false; state.autopilot!.snapshotHash = "synthetic-snapshot-two"; }
    if (url.pathname === "/api/autopilot/enable") { state.autopilot!.enabled = true; state.autopilot!.status = "Active"; }
    if (url.pathname === "/api/autopilot/pause") { state.autopilot!.enabled = false; state.autopilot!.status = "Paused"; }
    if (/^\/api\/resume-variants\/[^/]+\/approval$/.test(url.pathname)) {
      const variant = state.resumeVariants?.find(variant => variant.id === decodeURIComponent(url.pathname.split("/")[3]!));
      if (variant) variant.approved = body.approved;
      state.autopilot!.snapshotHash = `synthetic-approval-change-${writes.length}`;
      state.autopilot!.enabled = false;
    }
    if (url.pathname === "/api/profile") {
      state.profile = { ...body.profile, version: state.profile.version + 1 };
      state.autopilot!.snapshotHash = `synthetic-profile-change-${writes.length}`;
      state.autopilot!.enabled = false;
      return reply({ profile: state.profile });
    }
    if (/^\/api\/resume-variants\/[^/]+\/tailor$/.test(url.pathname)) {
      const packet = tailoredPacket(state, decodeURIComponent(url.pathname.split("/")[3]!), body.mode);
      state.packets.unshift(packet);
      return reply({ packet });
    }
    if (url.pathname === "/api/control") state.stats.stopped = body.stopped;
    if (/^\/api\/hitl\/[^/]+\/(continue|abandon)$/.test(url.pathname)) {
      const task = state.autopilot!.humanTasks!.find(task => task.id === decodeURIComponent(url.pathname.split("/")[3]!))!;
      task.status = url.pathname.endsWith("/continue") ? "resolved" : "abandoned";
    }
    if (url.pathname === "/api/autopilot/browser") return reply({ error: "Synthetic browser setup failure. No browser account was accessed." }, 503);
    return reply({ autopilot: state.autopilot, variant: state.resumeVariants?.[0] });
  });
  await page.goto(`${origin}#autopilot`);
  await expect(page.getByRole("heading", { level: 1, name: "Auto Apply", exact: true })).toBeVisible();
  if (openSetup && state.autopilot && state.resumeVariants) {
    await expect(page.locator(".auto-setup")).toBeVisible();
    if (!await page.locator(".auto-setup").evaluate(node => (node as HTMLDetailsElement).open)) await page.locator(".auto-setup > summary").click();
    await page.getByText("Advanced: manual resume preview", { exact: true }).click();
  }
  return { writes, errors, documentRequests, reads };
}

test("setup distinguishes ZIP archives from installers and keeps the extension optional", async ({ page }) => {
  const { writes, errors } = await mockWorkspace(page, syntheticState(), false);
  await page.getByRole("button", { name: "Setup", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Your local workspace is running", exact: true })).toBeVisible();
  await expect(page.getByText("ZIP archives, not one-click installers.", { exact: false })).toBeVisible();
  await expect(page.locator(".installation-steps")).toContainText("Load unpacked");
  await expect(page.locator(".installation-steps")).toContainText("manifest.json");
  await expect(page.locator(".installation-steps")).toContainText("npm ci");
  await expect(page.locator(".installation-steps")).toContainText("npm start");
  await expect(page.getByRole("link", { name: "Chrome extension ZIP", exact: true })).toHaveAttribute("href", "/api/downloads/extension");
  await expect(page.getByRole("link", { name: "Local app ZIP", exact: true })).toHaveAttribute("href", "/api/downloads/local");
  await page.getByRole("button", { name: "Set up Auto Apply", exact: true }).click();
  await expect(page.getByRole("heading", { level: 1, name: "Auto Apply", exact: true })).toBeVisible();
  expect(writes).toHaveLength(0);
  expect(errors).toHaveLength(0);
});

test("old services report an update requirement, never available automation", async ({ page }) => {
  const state = syntheticState();
  delete state.autopilot; delete state.resumeVariants;
  const { writes, errors } = await mockWorkspace(page, state);
  await expect(page.getByText("Local service update required.", { exact: true })).toBeVisible();
  await expect(page.getByRole("button", { name: "Activate Auto Apply", exact: true })).toHaveCount(0);
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("activation is explicit, snapshot-bound, and unsaved rules survive refresh", async ({ page }) => {
  const state = syntheticState();
  const { writes, errors } = await mockWorkspace(page, state);
  const activate = page.getByRole("button", { name: "Activate Auto Apply", exact: true });
  await expect(activate).toBeDisabled();
  await expect(page.getByRole("button", { name: "Run one cycle now" })).toBeDisabled();
  const confirmations = page.locator(".consent-checks input");
  await expect(confirmations).toHaveCount(3);
  for (const checkbox of await confirmations.all()) await expect(checkbox).not.toBeChecked();
  await page.getByLabel("Minimum match score (0–100)").fill("88");
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await expect(page.getByLabel("Minimum match score (0–100)")).toHaveValue("88");
  await expect(activate).toBeDisabled();
  await page.getByRole("button", { name: "Save matching rules" }).click();
  await expect(page.getByRole("button", { name: "Save matching rules" })).toBeDisabled();
  for (const checkbox of await confirmations.all()) await checkbox.check();
  await expect(activate).toBeEnabled();
  state.autopilot!.snapshotHash = "synthetic-snapshot-three";
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await expect(activate).toBeDisabled();
  for (const checkbox of await confirmations.all()) {
    await expect(checkbox).not.toBeChecked();
    await checkbox.check();
  }
  await activate.click();
  await expect(page.getByText("Auto Apply active", { exact: true })).toBeVisible();
  await expect(page.locator(".auto-setup")).not.toHaveAttribute("open");
  await expect(page.locator(".authorization-details")).not.toHaveAttribute("open");
  expect(writes.find(write => write.path === "/api/autopilot/enable")?.body).toEqual({ snapshotHash: "synthetic-snapshot-three", authorizeSubmission: true, confirmAccuracy: true, confirmSiteRules: true });
  await page.getByRole("button", { name: "Pause Auto Apply", exact: true }).click();
  await expect(page.getByRole("button", { name: "Activate Auto Apply", exact: true })).toBeDisabled();
  expect(writes.map(write => write.path)).toEqual(["/api/autopilot/rules", "/api/autopilot/enable", "/api/autopilot/pause"]);
  expect(errors).toEqual([]);
});

for (const slots of [[], [4], [1, 3], [2, 4]]) {
  test(`activation needs two valid approvals in any slots: ${slots.join(",") || "none"}`, async ({ page }) => {
    const state = syntheticState();
    state.resumeVariants = state.resumeVariants!.filter(variant => slots.includes(variant.slot));
    const { writes, errors } = await mockWorkspace(page, state);
    await expect(page.locator(".variant-grid .variant-slot")).toHaveCount(8);
    await expect(page.locator(".autopilot-steps li")).toHaveCount(4);
    await expect(page.locator("#auto-resumes > .section-heading")).toContainText(`${slots.length} approved · minimum 2`);
    const activate = page.getByRole("button", { name: "Activate Auto Apply", exact: true });
    if (slots.length < 2) {
      await expect(activate).toBeDisabled();
      for (const checkbox of await page.locator(".consent-checks input").all()) {
        await expect(checkbox).toBeEnabled();
        await checkbox.check();
      }
      await expect(activate).toBeDisabled();
      expect(writes).toEqual([]);
    } else {
      for (const checkbox of await page.locator(".consent-checks input").all()) await checkbox.check();
      await expect(activate).toBeEnabled();
      await activate.click();
      expect(writes.map(write => write.path)).toEqual(["/api/autopilot/enable"]);
    }
    expect(errors).toEqual([]);
  });
}

test("unapproved and approved-invalid extras neither count nor block two valid templates", async ({ page }) => {
  const state = syntheticState();
  state.resumeVariants![0]!.approved = false;
  state.resumeVariants![2]!.issues = ["Synthetic file validation issue."];
  const { writes, errors } = await mockWorkspace(page, state);
  await expect(page.locator("#auto-resumes > .section-heading")).toContainText("2 approved · minimum 2");
  const bases = page.getByLabel("Approved base template");
  await expect(bases.locator("option")).toHaveCount(3);
  await expect(bases.locator('option[value="variant-1"]')).toHaveCount(0);
  await expect(bases.locator('option[value="variant-3"]')).toHaveCount(0);
  for (const checkbox of await page.locator(".consent-checks input").all()) await checkbox.check();
  await page.getByRole("button", { name: "Activate Auto Apply", exact: true }).click();
  expect(writes.map(write => write.path)).toEqual(["/api/autopilot/enable"]);
  expect(errors).toEqual([]);
});

test("an unset daily cap permits checkbox review and activation after explicit checks", async ({ page }) => {
  const state = syntheticState();
  state.stats.limit = null;
  const { writes, errors } = await mockWorkspace(page, state);
  await expect(page.getByText("Unlimited — no daily cap", { exact: true })).toBeVisible();
  await expect(page.getByText("A daily cap is optional.", { exact: false })).toBeVisible();
  const activate = page.getByRole("button", { name: "Activate Auto Apply", exact: true });
  for (const checkbox of await page.locator(".consent-checks input").all()) {
    await expect(checkbox).toBeEnabled(); await checkbox.check();
  }
  await expect(activate).toBeEnabled();
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  for (const checkbox of await page.locator(".consent-checks input").all()) await expect(checkbox).toBeChecked();
  await expect(activate).toBeEnabled();
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("unsaved optional-slot edits show the real blocker rather than disabling consent or requiring a cap", async ({ page }) => {
  const state = syntheticState();
  const { writes, errors } = await mockWorkspace(page, state);
  const slot = page.getByRole("article", { name: "Resume slot 4" });
  await slot.locator("summary").filter({ hasText: "Replace original / edit role tags" }).click();
  await slot.getByLabel("Slot 4 label").fill("Unsaved optional label");
  await expect(page.getByText(/Resume slot 4 has unsaved edits/)).toBeVisible();
  for (const checkbox of await page.locator(".consent-checks input").all()) await checkbox.check();
  await expect(page.getByRole("button", { name: "Activate Auto Apply", exact: true })).toBeDisabled();
  page.once("dialog", dialog => dialog.accept());
  await page.getByRole("button", { name: "Discard unsaved Auto Apply edits" }).click();
  await expect(page.getByText(/Resume slot 4 has unsaved edits/)).toHaveCount(0);
  for (const checkbox of await page.locator(".consent-checks input").all()) {
    await expect(checkbox).not.toBeChecked(); await checkbox.check();
  }
  await expect(page.getByRole("button", { name: "Activate Auto Apply", exact: true })).toBeEnabled();
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("stopped queue can be resumed next to authorization without granting submission consent", async ({ page }) => {
  const state = syntheticState();
  state.stats.stopped = true; state.autopilot!.ready = false; state.autopilot!.blockers = ["The global queue is stopped."];
  const { writes, errors } = await mockWorkspace(page, state);
  for (const checkbox of await page.locator(".consent-checks input").all()) await checkbox.check();
  await expect(page.getByRole("button", { name: "Activate Auto Apply", exact: true })).toBeDisabled();
  state.autopilot!.ready = true; state.autopilot!.blockers = [];
  await page.getByRole("button", { name: "Resume queue for activation" }).click();
  await expect(page.getByRole("button", { name: "Activate Auto Apply", exact: true })).toBeEnabled();
  expect(writes.map(write => write.path)).toEqual(["/api/control"]);
  expect(state.autopilot!.enabled).toBe(false); expect(errors).toEqual([]);
});

test("saved mode and engine changes reset consent and original mode remains distinct", async ({ page }) => {
  const state = syntheticState();
  state.runtime.ai.available = true;
  const { writes, errors } = await mockWorkspace(page, state);
  const confirmations = page.locator(".consent-checks input");
  const activate = page.getByRole("button", { name: "Activate Auto Apply", exact: true });
  await expect(page.getByLabel("Resume mode", { exact: true })).toHaveValue("job-tailored");
  await expect(page.getByLabel("Tailoring engine", { exact: true })).toHaveValue("deterministic");
  await expect(page.locator(".consent-checks")).toContainText("JD-specific derived PDF/DOCX");
  await expect(page.locator(".consent-checks")).toContainText("only truthful, supported keywords");
  for (const checkbox of await confirmations.all()) await checkbox.check();
  await page.getByLabel("Resume mode", { exact: true }).selectOption("original");
  await expect(activate).toBeDisabled();
  for (const checkbox of await confirmations.all()) await expect(checkbox).not.toBeChecked();
  await expect(page.getByLabel("Tailoring engine", { exact: true })).toHaveCount(0);
  await page.getByRole("button", { name: "Save matching rules" }).click();
  await expect(page.locator(".consent-checks")).toContainText("byte-for-byte unchanged, with no tailoring");
  await expect(page.locator(".consent-checks")).not.toContainText("JD-specific derived");
  for (const checkbox of await confirmations.all()) await checkbox.check();
  await expect(activate).toBeEnabled();
  await page.getByLabel("Resume mode", { exact: true }).selectOption("job-tailored");
  await page.getByRole("button", { name: "Save matching rules" }).click();
  for (const checkbox of await confirmations.all()) {
    await expect(checkbox).not.toBeChecked();
    await checkbox.check();
  }
  await page.getByLabel("Tailoring engine", { exact: true }).selectOption("local-ai");
  await expect(activate).toBeDisabled();
  for (const checkbox of await confirmations.all()) await expect(checkbox).not.toBeChecked();
  await page.getByRole("button", { name: "Save matching rules" }).click();
  await expect(page.locator(".consent-checks")).toContainText("using Local AI");
  expect(writes.map(write => write.path)).toEqual(["/api/autopilot/rules", "/api/autopilot/rules", "/api/autopilot/rules"]);
  expect(writes[0]!.body.rules.resumeStrategy).toBe("original");
  expect(writes[2]!.body.rules.tailoringMode).toBe("local-ai");
  expect(errors).toEqual([]);
});

for (const aiAvailable of [false, true]) {
  test(`Local AI availability ${aiAvailable} never overrides server readiness`, async ({ page }) => {
    const state = syntheticState();
    state.runtime.ai.available = aiAvailable;
    state.autopilot!.rules.tailoringMode = "local-ai";
    state.autopilot!.ready = false;
    state.autopilot!.blockers = ["Synthetic server readiness blocker."];
    const { writes, errors } = await mockWorkspace(page, state);
    await expect(page.getByText("Synthetic server readiness blocker.", { exact: true })).toBeVisible();
    await expect(page.getByRole("button", { name: "Activate Auto Apply", exact: true })).toBeDisabled();
    if (!aiAvailable) await expect(page.locator(".autopilot-rules")).toContainText("Local AI is unavailable");
    expect(writes).toEqual([]); expect(errors).toEqual([]);
  });
}

test("slot edits, approval changes, and profile edits clear previous authorization checks", async ({ page }) => {
  const state = syntheticState();
  const { writes, errors } = await mockWorkspace(page, state);
  const confirmations = page.locator(".consent-checks input");
  for (const checkbox of await confirmations.all()) await checkbox.check();
  const slot = page.getByRole("article", { name: "Resume slot 1" });
  await slot.getByText("Replace original / edit role tags", { exact: true }).click();
  await slot.getByLabel("Slot 1 label").fill("Synthetic edited label");
  for (const checkbox of await confirmations.all()) await expect(checkbox).not.toBeChecked();
  await slot.getByRole("button", { name: "Discard slot edits" }).click();
  for (const checkbox of await confirmations.all()) await checkbox.check();
  await slot.getByRole("button", { name: "Revoke approval" }).click();
  for (const checkbox of await confirmations.all()) await expect(checkbox).not.toBeChecked();
  for (const checkbox of await confirmations.all()) await checkbox.check();
  await page.getByRole("button", { name: "Profile", exact: true }).click();
  await page.getByLabel("Full name", { exact: true }).fill("Synthetic Edited Candidate");
  await page.getByRole("button", { name: "Confirm profile & save", exact: true }).click();
  await page.getByRole("button", { name: "Auto Apply", exact: true }).click();
  for (const checkbox of await confirmations.all()) await expect(checkbox).not.toBeChecked();
  expect(writes.map(write => write.path)).toEqual(["/api/resume-variants/variant-1/approval", "/api/profile"]);
  expect(errors).toEqual([]);
});

test("one approved base can preview locally, download exact documents, and never activate", async ({ page }) => {
  const state = syntheticState();
  state.resumeVariants = state.resumeVariants!.filter(variant => variant.slot === 3);
  state.autopilot!.ready = false;
  state.autopilot!.blockers = ["At least two approved valid files are needed to activate."];
  state.stats.totalJobs = 700;
  const { writes, errors, documentRequests } = await mockWorkspace(page, state);
  const preview = page.getByRole("region", { name: "Preview before authorizing" });
  await expect(preview).toContainText("1 loaded jobs");
  await expect(preview).toContainText("not all 700 stored listings");
  await preview.getByLabel("Approved base template").selectOption("variant-3");
  await preview.getByLabel("Loaded job description").selectOption("synthetic-job");
  await preview.getByRole("button", { name: "Preview JD-tailored resume" }).click();
  const review = page.getByRole("region", { name: "Exact application packet review" });
  await expect(review.getByRole("heading", { name: "Frozen resume content" })).toBeVisible();
  await expect(review.getByRole("heading", { name: "JD-tailored / deterministic" })).toBeVisible();
  await expect(review).toContainText("Synthetic resume 3");
  await expect(review).toContainText("synthetic-description-hash");
  await expect(review).toContainText("Missing evidence · not claimed");
  await expect(review.locator(".resume-paper")).not.toContainText("Unevidenced Synthetic Skill");
  for (const format of ["PDF", "DOCX"]) {
    const downloadEvent = page.waitForEvent("download");
    await review.getByRole("button", { name: `Download ${format}`, exact: true }).click();
    const downloaded = await downloadEvent;
    expect(downloaded.suggestedFilename()).toBe(`synthetic-job-tailored.${format.toLowerCase()}`);
  }
  expect(writes).toEqual([{ path: "/api/resume-variants/variant-3/tailor", body: { jobId: "synthetic-job", mode: "deterministic" }, raw: JSON.stringify({ jobId: "synthetic-job", mode: "deterministic" }) }]);
  expect(documentRequests).toEqual(["/api/packets/synthetic-tailored-packet/documents/pdf", "/api/packets/synthetic-tailored-packet/documents/docx"]);
  expect(state.autopilot!.enabled).toBe(false);
  expect(state.packets[0]!.status).toBe("prepared");
  expect(state.packets[0]!.approvedAt).toBeUndefined();
  expect(errors).toEqual([]);
});

test("preview blocks unconfirmed facts, unavailable AI, closed jobs, and removed selections", async ({ page }) => {
  const state = syntheticState();
  state.profile.facts[0]!.confirmed = false;
  const { writes, errors } = await mockWorkspace(page, state);
  const preview = page.getByRole("region", { name: "Preview before authorizing" });
  const button = preview.getByRole("button", { name: "Preview JD-tailored resume" });
  await preview.getByLabel("Approved base template").selectOption("variant-1");
  await preview.getByLabel("Loaded job description").selectOption("synthetic-job");
  await expect(button).toBeDisabled();
  await expect(preview).toContainText("Confirm every profile fact");
  state.profile.facts[0]!.confirmed = true;
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await expect(button).toBeEnabled();
  await preview.getByLabel("Preview engine").selectOption("local-ai");
  await expect(button).toBeDisabled();
  await expect(preview).toContainText("Local AI is unavailable");
  await preview.getByLabel("Preview engine").selectOption("deterministic");
  state.jobs[0]!.status = "closed";
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await expect(button).toBeDisabled();
  await expect(preview).toContainText("This job is ineligible, closed");
  state.jobs[0]!.status = "open";
  state.jobs[0]!.match.eligible = false;
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await expect(button).toBeDisabled();
  state.jobs[0]!.match.eligible = true;
  state.resumeVariants![0]!.issues = ["Synthetic validation blocker"];
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await expect(button).toBeDisabled();
  await expect(preview.getByLabel("Approved base template")).toContainText("no longer approved or valid");
  state.jobs = [];
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await expect(button).toBeDisabled();
  await expect(preview.getByLabel("Loaded job description")).toContainText("Selected job is not loaded");
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("preview server rejection is visible and cannot authorize or submit", async ({ page }) => {
  const state = syntheticState();
  const { writes, errors } = await mockWorkspace(page, state);
  await page.route("**/api/resume-variants/variant-1/tailor", route => route.fulfill({ status: 409, json: { error: "Synthetic server rejected stale template evidence." } }));
  await page.getByLabel("Approved base template").selectOption("variant-1");
  await page.getByLabel("Loaded job description").selectOption("synthetic-job");
  await page.getByRole("button", { name: "Preview JD-tailored resume" }).click();
  await expect(page.getByRole("alert")).toContainText("Synthetic server rejected stale template evidence.");
  await expect(page.getByRole("heading", { level: 1, name: "Auto Apply", exact: true })).toBeVisible();
  expect(writes).toEqual([]);
  expect(state.autopilot!.enabled).toBe(false);
  expect(state.packets).toEqual([]);
  expect(errors).toEqual([]);
});

test("missing frozen content never reconstructs a JD-tailored packet from the current profile", async ({ page }) => {
  const state = syntheticState();
  const packet = tailoredPacket(state);
  delete packet.resumeContent;
  state.packets = [packet];
  const { writes, errors } = await mockWorkspace(page, state);
  await page.getByRole("button", { name: /^Applications/ }).click();
  await page.getByRole("button", { name: "Review", exact: true }).click();
  const review = page.getByRole("region", { name: "Exact application packet review" });
  await expect(review).toContainText("The frozen resume content was not returned.");
  await expect(review.locator(".resume-paper")).toHaveCount(0);
  await expect(review.getByRole("button", { name: "Download PDF", exact: true })).toBeEnabled();
  await expect(review.getByRole("checkbox", { name: /select it for batch approval/ })).toBeDisabled();
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("tailored packet keeps frozen identity, facts, skills, provenance and submission file after profile edits", async ({ page }, testInfo) => {
  const state = syntheticState();
  state.profile.links = { Portfolio: "https://example.invalid/synthetic-original" };
  const packet = tailoredPacket(state, "variant-2", "local-ai");
  packet.status = "submitted_confirmed";
  packet.approvedBy = "autopilot";
  packet.authorizationId = "synthetic-standing-authorization";
  packet.submissionArtifactSha256 = packet.artifacts[1]!.sha256;
  state.packets = [packet];
  state.autopilot!.jobs = [{ id: "synthetic-tailored-attempt", jobId: packet.jobId, packetId: packet.id, variantId: "variant-2", status: "submitted_confirmed", reason: "Synthetic receipt only.", createdAt: packet.createdAt, updatedAt: packet.createdAt }];
  const { errors } = await mockWorkspace(page, state);
  await expect(page.locator(".autopilot-job-list")).toContainText("JD-tailored / AI-assisted tailoring");
  await expect(page.locator(".autopilot-job-list")).toContainText("synthetic-job-tailored.docx");
  await page.getByRole("button", { name: "View exact packet & receipt" }).click();
  const review = page.getByRole("region", { name: "Exact application packet review" });
  await expect(review.getByRole("heading", { name: "Frozen resume content" })).toBeVisible();
  state.profile.name = "Synthetic Current Name";
  state.profile.email = "changed@example.invalid";
  state.profile.facts = [{ id: "changed", category: "summary", confirmed: true, text: "Synthetic changed mutable profile fact." }];
  state.profile.skills = ["Synthetic Changed Skill"];
  state.profile.links = { Portfolio: "https://example.invalid/changed" };
  state.profile.version = 2;
  state.resumeVariants![1]!.label = "Synthetic renamed live base";
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  const paper = review.locator(".resume-paper");
  await expect(paper).toContainText("Synthetic Candidate");
  await expect(paper).toContainText("candidate@example.invalid");
  await expect(paper).toContainText("Synthetic experience for a UI test only.");
  await expect(paper).toContainText("Python");
  await expect(paper).toContainText("https://example.invalid/synthetic-original");
  await expect(paper).not.toContainText("Synthetic Current Name");
  await expect(paper).not.toContainText("Synthetic changed mutable profile fact");
  await expect(paper).not.toContainText("Synthetic Changed Skill");
  await expect(review).toContainText("The frozen content below and saved documents are unchanged");
  const provenance = review.getByRole("region", { name: "Tailored document provenance" });
  await expect(provenance).toContainText("Synthetic resume 2");
  await expect(provenance).not.toContainText("Synthetic renamed live base");
  await expect(review.getByText("Exact submission artifact SHA-256", { exact: true })).toBeVisible();
  await expect(review.getByText("synthetic-derived-docx-hash", { exact: true }).first()).toBeVisible();
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: 960 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
    await page.screenshot({ path: testInfo.outputPath(`synthetic-tailored-review-${width}.png`), fullPage: true });
  }
  expect(errors).toEqual([]);
});

test("DOCX originals stay unchanged, uploads do not approve or activate by default", async ({ page }) => {
  const state = syntheticState();
  state.resumeVariants = [];
  state.autopilot!.ready = false; state.autopilot!.blockers = ["Upload and approve at least two valid variants in any slots."];
  const { writes, errors } = await mockWorkspace(page, state);
  const slot = page.getByRole("article", { name: "Resume slot 1" });
  await slot.getByLabel("Slot 1 label").fill("Synthetic original");
  await slot.getByRole("checkbox", { name: "Software", exact: true }).check();
  await slot.getByLabel("Original PDF or DOCX for slot 1").setInputFiles({ name: "synthetic.docx", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", buffer: Buffer.from("Synthetic test bytes only, not a real resume.") });
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await expect(slot.getByLabel("Slot 1 label")).toHaveValue("Synthetic original");
  await expect(slot.getByRole("checkbox", { name: /I opened this exact file/ })).not.toBeChecked();
  await slot.getByRole("button", { name: "Upload slot 1", exact: true }).click();
  expect(writes).toHaveLength(1);
  expect(writes[0]!.path).toBe("/api/resume-variants/1");
  expect(writes[0]!.raw).toContain('name="families"');
  expect(writes[0]!.raw).not.toContain('name="approved"');
  expect(writes[0]!.raw).toContain('filename="synthetic.docx"');
  expect(errors).toEqual([]);
});

test("blocked jobs link to actual applications, unknown outcomes cannot retry, and API errors are explicit", async ({ page }) => {
  const state = syntheticState();
  state.autopilot!.enabled = true;
  state.autopilot!.jobs = [
    { id: "synthetic-unknown", jobId: "synthetic-job", status: "submission_unknown", variantId: "variant-1", reason: "Synthetic timeout after a submit click.", createdAt: "2026-09-15T10:00:00Z", updatedAt: "2026-09-15T10:02:00Z" },
    { id: "synthetic-input", jobId: "synthetic-job", status: "needs_input", reason: "Missing notice_period_days", createdAt: "2026-09-15T10:00:00Z", updatedAt: "2026-09-15T10:01:00Z" },
  ];
  const { writes, errors } = await mockWorkspace(page, state);
  const unknown = page.locator(".unknown-outcome");
  await expect(unknown.getByText("Unknown · do not retry", { exact: true })).toBeVisible();
  await expect(unknown.getByRole("button", { name: /recheck|retry/i })).toHaveCount(0);
  await expect(unknown.getByRole("link", { name: /Open actual application/ })).toHaveAttribute("href", "https://example.invalid/synthetic-job");
  await expect(page.getByRole("button", { name: "Add factual answers in Profile" })).toBeVisible();
  await page.getByRole("button", { name: "Open local Chrome", exact: true }).click();
  await expect(page.getByRole("alert")).toContainText("Synthetic browser setup failure");
  expect(writes.map(write => write.path)).toEqual(["/api/autopilot/browser"]);
  expect(errors).toEqual([]);
});

test("uploaded packet review accepts DOCX-only originals and retains evidence without empty fact errors", async ({ page }) => {
  const state = syntheticState();
  state.packets = [{ id: "synthetic-packet", jobId: "synthetic-job", jobHash: "synthetic-job-hash", profileHash: "synthetic-profile-hash", profileVersion: 1, draft: { mode: "uploaded-variant", factIds: [], skills: [], notes: ["Original uploaded file."] }, artifacts: [state.resumeVariants![0]!.artifact], answers: { first_name: "Synthetic" }, warnings: [], status: "submitted_confirmed", confirmation: "Synthetic receipt UI-123. Not a real application.", createdAt: "2026-09-15T10:00:00Z", variantId: "variant-1", authorizationId: "synthetic-authorization", approvedBy: "autopilot" }];
  state.packets[0]!.submissionArtifactSha256 = state.packets[0]!.artifacts[0]!.sha256;
  const { errors, documentRequests } = await mockWorkspace(page, state);
  await page.getByRole("button", { name: /^Applications/ }).click();
  await page.getByRole("button", { name: "Review", exact: true }).click();
  const review = page.getByRole("region", { name: "Exact application packet review" });
  await expect(review.getByRole("heading", { name: "Original, unchanged resume" })).toBeVisible();
  await expect(review.getByRole("button", { name: "Download original DOCX" })).toBeEnabled();
  await expect(review.getByText("No profile facts were selected.", { exact: true })).toHaveCount(0);
  await expect(review.getByText(/Synthetic receipt UI-123/)).toBeVisible();
  await expect(review.getByText("Exact submission artifact SHA-256", { exact: true })).toBeVisible();
  const downloadEvent = page.waitForEvent("download");
  await review.getByRole("button", { name: "Download original DOCX", exact: true }).click();
  expect((await downloadEvent).suggestedFilename()).toBe("synthetic-resume-1.docx");
  expect(documentRequests).toEqual(["/api/packets/synthetic-packet/documents/docx"]);
  await expect(review.getByRole("button", { name: "Download PDF", exact: true })).toHaveCount(0);
  expect(errors).toEqual([]);
});

test("accuracy approval is explicit and file issues cannot be overridden", async ({ page }) => {
  const state = syntheticState();
  state.resumeVariants![0]!.approved = false;
  state.resumeVariants![1]!.approved = false;
  state.resumeVariants![1]!.issues = ["Synthetic identity mismatch. Replace the original file."];
  state.autopilot!.ready = false;
  const { writes, errors } = await mockWorkspace(page, state);
  const first = page.getByRole("article", { name: "Resume slot 1" });
  const second = page.getByRole("article", { name: "Resume slot 2" });
  await expect(first.getByRole("button", { name: "Approve slot 1 accuracy" })).toBeDisabled();
  await first.getByRole("checkbox", { name: /I opened this exact file/ }).check();
  await first.getByRole("button", { name: "Approve slot 1 accuracy" }).click();
  expect(writes[0]?.body).toEqual({ approved: true });
  expect(writes[0]?.path).toBe("/api/resume-variants/variant-1/approval");
  await expect(second.getByRole("checkbox", { name: /I opened this exact file/ })).toBeDisabled();
  await expect(second.getByRole("button", { name: "Approve slot 2 accuracy" })).toBeDisabled();
  expect(writes).toHaveLength(1); expect(errors).toEqual([]);
});

test("Stop all pauses the runner and stops the submission queue", async ({ page }) => {
  const state = syntheticState();
  state.autopilot!.enabled = true;
  const { writes, errors } = await mockWorkspace(page, state);
  await page.getByRole("button", { name: "Stop all submissions" }).click();
  await expect(page.getByRole("button", { name: "Resume queue", exact: true })).toBeVisible();
  expect(writes.map(write => write.path).sort()).toEqual(["/api/autopilot/pause", "/api/control"]);
  expect(state.autopilot!.enabled).toBe(false);
  expect(state.stats.stopped).toBe(true);
  expect(errors).toEqual([]);
});

test("optional narrative templates stay blank until user-authored and warn about unsupported placeholders", async ({ page }) => {
  const { writes, errors } = await mockWorkspace(page, syntheticState());
  await page.getByRole("button", { name: /^Profile/, exact: true }).click();
  await page.getByRole("button", { name: "Add blank cover-letter template", exact: true }).click();
  const template = page.getByLabel("cover_letter_template", { exact: true });
  await expect(template).toHaveValue("");
  await template.fill("I would like to discuss the {role} role at {company}.");
  const guide = page.getByRole("region", { name: "Optional user-authored narrative templates" });
  await expect(guide.getByText("Template placeholders need correction", { exact: true })).toHaveCount(0);
  await template.fill("I have {years_experience} years relevant to {role} at {company}.");
  await expect(guide.getByText(/unrecognized placeholder \{years_experience\}/)).toBeVisible();
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await expect(template).toHaveValue("I have {years_experience} years relevant to {role} at {company}.");
  await template.fill("For {{company}}.");
  await expect(guide.getByText(/unmatched or nested braces/)).toBeVisible();
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("saved narrative templates surface unknown placeholders in Auto Apply without guessing", async ({ page }) => {
  const state = syntheticState();
  state.profile.answers.cover_letter_template = "My interest in {role} at {company} is described in my own words.";
  state.profile.answers.motivation_template = "My {unapproved_claim} at {Company}.";
  const { writes, errors } = await mockWorkspace(page, state);
  const guide = page.getByRole("region", { name: "Optional user-authored narrative templates" });
  await expect(guide.getByText(/unrecognized placeholders \{unapproved_claim\}, \{Company\}/)).toBeVisible();
  await expect(guide.getByText(/These templates never answer assessments or legal declarations/)).toBeVisible();
  await expect(page.locator(".consent-checks")).toContainText("only {company} and {role} substitutions");
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("desktop and mobile setup have no horizontal page overflow or browser errors", async ({ page }, testInfo) => {
  const { errors } = await mockWorkspace(page, syntheticState());
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: 960 });
    await expect(page.getByRole("heading", { name: "Your local application runner" })).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
    await page.screenshot({ path: testInfo.outputPath(`synthetic-auto-apply-${width}.png`), fullPage: true });
  }
  expect(errors).toEqual([]);
});

test("Copilot provider requires explicit remote consent and never substitutes a different model", async ({ page }) => {
  const state = syntheticState();
  state.runtime.ai = { provider: "copilot", remote: true, model: "gpt-6-astra", available: false,
    consentRequired: true, authenticated: false, modelAvailable: false, reason: "Explicit consent and sign-in are required." };
  const { writes, errors } = await mockWorkspace(page, state);
  await page.getByRole("button", { name: "AI", exact: true }).click();
  await expect(page.getByLabel("Exact AI model")).toHaveValue("gpt-6-astra");
  const save = page.getByRole("button", { name: "Save AI configuration", exact: true });
  await expect(save).toBeDisabled();
  await page.getByRole("checkbox", { name: /I allow sending bounded confirmed/ }).check();
  await expect(save).toBeDisabled();
  await page.getByRole("checkbox", { name: /I understand that this uses my Copilot/ }).check();
  await expect(save).toBeEnabled();
  await save.click();
  expect(writes.find(write => write.path === "/api/inference/config")!.body).toEqual({
    provider: "copilot", model: "gpt-6-astra", allowRemoteProcessing: true, acknowledgeUsage: true
  });
  expect(writes.some(write => /autopilot\/enable|packets|\/continue/.test(write.path))).toBe(false);
  expect(errors).toEqual([]);
});

test("hosted processing consent can be revoked without changing the selected provider", async ({ page }) => {
  const state = syntheticState();
  state.runtime.ai = { provider: "copilot", remote: true, model: "gpt-6-astra", available: true,
    consentRequired: false, authenticated: true, modelAvailable: true };
  const { writes } = await mockWorkspace(page, state);
  await page.getByRole("button", { name: "AI", exact: true }).click();
  await page.getByRole("button", { name: "Disable remote processing" }).click();
  expect(writes.find(write => write.path === "/api/inference/config")!.body).toEqual({
    provider: "copilot", model: "gpt-6-astra", allowRemoteProcessing: false, acknowledgeUsage: false
  });
});

test.describe("Gemini provider", () => {
  test("Gemini key stays masked and separate from configuration, with three fresh explicit confirmations", async ({ page }) => {
    const state = syntheticState();
    state.runtime.ai = { provider: "gemini", remote: true, model: "gemini-2.5-flash", available: false,
      consentRequired: true, keyConfigured: false, freeTierConfirmed: false, billingTierVerified: false };
    const { writes, errors } = await mockWorkspace(page, state);
    await page.getByRole("button", { name: "AI", exact: true }).click();
    const settings = page.getByRole("region", { name: "Configured AI", exact: true });
    const save = settings.getByRole("button", { name: "Save AI configuration", exact: true });
    await expect(settings.getByLabel("Exact AI model")).toHaveValue("gemini-2.5-flash");
    await expect(settings.getByLabel("Exact AI model").locator("option")).toHaveCount(1);
    await expect(settings).toContainText("Google prohibits sending personal, sensitive or confidential information");
    await expect(settings).toContainText("Raw resume facts, employers, dates, contact details, links, freeform skill labels and the full JD stay local");
    await expect(save).toBeDisabled();
    const keyInput = settings.getByLabel("Gemini API key", { exact: true });
    await expect(keyInput).toHaveAttribute("type", "password");
    const key = `AIza${"z".repeat(35)}`;
    await keyInput.fill(key);
    expect(writes).toEqual([]);
    await settings.getByRole("button", { name: "Save private Gemini key" }).click();
    await expect(keyInput).toHaveValue("");
    expect(writes.map(write => write.path)).toEqual(["/api/inference/gemini-key"]);
    expect(writes[0]!.body).toEqual({ apiKey: key });
    await settings.getByRole("checkbox", { name: /I allow sending only anonymous/ }).check();
    await settings.getByRole("checkbox", { name: /I understand Google's unpaid-service/ }).check();
    await expect(save).toBeDisabled();
    await settings.getByRole("checkbox", { name: /I checked that this key's Google project is Free/ }).check();
    await expect(save).toBeEnabled();
    await save.click();
    expect(writes[1]!.body).toEqual({
      provider: "gemini", model: "gemini-2.5-flash", allowRemoteProcessing: true, acknowledgeUsage: true, confirmFreeTier: true,
    });
    expect(writes[1]!.raw).not.toContain(key);
    await expect(settings.getByRole("checkbox", { name: /I allow sending only anonymous/ })).not.toBeChecked();
    await settings.getByRole("button", { name: "Refresh AI status" }).click();
    expect(writes[2]!.path).toBe("/api/inference/refresh");
    expect(writes.some(write => /autopilot\/enable|packets|\/continue/.test(write.path))).toBe(false);
    expect(errors).toEqual([]);
  });

  test("switching from Copilot never carries consent into Gemini and key removal revokes explicitly", async ({ page }) => {
    const state = syntheticState();
    state.runtime.ai = { provider: "copilot", remote: true, model: "gpt-6-astra", available: true,
      consentRequired: false, authenticated: true, modelAvailable: true };
    const { writes, errors } = await mockWorkspace(page, state);
    await page.getByRole("button", { name: "AI", exact: true }).click();
    const settings = page.getByRole("region", { name: "Configured AI", exact: true });
    await settings.getByRole("checkbox", { name: /I allow sending bounded confirmed/ }).check();
    await settings.getByRole("checkbox", { name: /I understand that this uses my Copilot/ }).check();
    await settings.getByLabel("AI provider", { exact: true }).selectOption("gemini");
    for (const checkbox of await settings.getByRole("checkbox").all()) await expect(checkbox).not.toBeChecked();
    await expect(settings.getByRole("button", { name: "Save AI configuration" })).toBeDisabled();
    await settings.getByRole("button", { name: "Remove Gemini key" }).click();
    expect(writes[0]!.body).toEqual({ revoke: true });
    expect(writes[0]!.path).toBe("/api/inference/gemini-key");
    expect(writes).toHaveLength(1);
    expect(errors).toEqual([]);
  });

  test("Gemini quota pause is visible and disabling hosted processing also revokes Free confirmation", async ({ page }) => {
    const state = syntheticState();
    state.runtime.ai = { provider: "gemini", remote: true, model: "gemini-2.5-flash", available: false,
      consentRequired: false, keyConfigured: true, freeTierConfirmed: true, billingTierVerified: false,
      retryAt: "2026-09-16T15:00:00.000Z", retryAfterSeconds: 120, reason: "Gemini quota exhausted (HTTP 429). No automatic retry." };
    const { writes, errors } = await mockWorkspace(page, state);
    await page.getByRole("button", { name: "AI", exact: true }).click();
    const settings = page.getByRole("region", { name: "Configured AI", exact: true });
    await expect(settings).toContainText("Quota pause until");
    await expect(settings).toContainText("Gemini quota exhausted (HTTP 429)");
    await expect(settings).toContainText("billing tier cannot be verified by this app");
    await settings.getByRole("button", { name: "Disable remote processing" }).click();
    expect(writes[0]!.body).toEqual({
      provider: "gemini", model: "gemini-2.5-flash", allowRemoteProcessing: false, acknowledgeUsage: false, confirmFreeTier: false,
    });
    for (const width of [1440, 390]) {
      await page.setViewportSize({ width, height: 960 });
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
    }
    expect(errors).toEqual([]);
  });

  test("saved Gemini provenance remains Gemini after switching the current provider to Ollama", async ({ page }) => {
    const state = syntheticState();
    state.runtime.ai = { provider: "ollama", remote: false, model: "qwen3:4b", available: true };
    const packet = tailoredPacket(state, "variant-1", "local-ai");
    packet.draft.inference = { provider: "gemini", model: "gemini-2.5-flash", remote: true };
    packet.tailoring!.inference = { ...packet.draft.inference };
    state.packets = [packet];
    const { errors } = await mockWorkspace(page, state);
    await page.getByRole("button", { name: /^Applications/ }).click();
    await page.getByRole("button", { name: "Review", exact: true }).click();
    const review = page.getByRole("region", { name: "Exact application packet review" });
    await expect(review).toContainText("AI used for this saved document");
    await expect(review).toContainText("Google Gemini");
    await expect(review).toContainText("gemini-2.5-flash");
    await expect(review).toContainText("Only anonymous IDs and fixed public technology tags were sent");
    await expect(review).not.toContainText("GitHub Copilot");
    expect(errors).toEqual([]);
  });
});

test("uncertain submissions remain visible but cannot be continued or automatically retried", async ({ page }) => {
  const state = humanState();
  state.autopilot!.humanTasks![0]!.canContinue = false;
  state.packets[0]!.status = "submission_unknown";
  const { writes } = await mockWorkspace(page, state);
  const task = page.locator(".human-task").first();
  await expect(task.getByText("A submission may already have occurred.", { exact: false })).toBeVisible();
  await expect(task.getByRole("button", { name: "Continue this application", exact: true })).toHaveCount(0);
  await expect(task.getByRole("button", { name: "Record a verified receipt in Applications" })).toBeVisible();
  expect(writes).toEqual([]);
});

function humanState(status: HumanTask["status"] = "waiting"): State {
  const state = syntheticState();
  const packet = tailoredPacket(state);
  packet.status = status === "session_lost" ? "submission_unknown" : "awaiting_human";
  packet.answers = { notice_days: "30", work_mode: "hybrid", password: "MUST-NOT-SEND", ssn: "MUST-NOT-SEND", legal: "MUST-NOT-SEND" };
  state.packets = [packet];
  state.autopilot!.browserRunning = true;
  state.autopilot!.humanTasks = [{
    id: "synthetic-human-task", jobId: packet.jobId, packetId: packet.id, sessionId: "synthetic-owned-session",
    status, reason: "A factual answer is missing on the second page.", url: "https://example.invalid/synthetic-job/application/step-2", step: 2,
    filledFields: ["First name", "Email", "Resume"], missingFields: [
      { key: "notice_days", label: "Notice period in days", type: "text", required: true, options: [] },
      { key: "work_mode", label: "Preferred working pattern", type: "select", required: true, options: ["hybrid", "office"], optionLabels: { hybrid: "Hybrid schedule", office: "Office schedule" } },
      { key: "context", label: "Anything else factual?", type: "textarea", required: false, options: [] },
      { key: "password", label: "Account password", type: "password", required: true, options: [] },
      { key: "otp", label: "One-time verification code", type: "text", required: true, options: [] },
      { key: "ssn", label: "Social security number", type: "text", required: true, options: [] },
      { key: "passport", label: "Passport number", type: "text", required: true, options: [] },
      { key: "gender", label: "Gender", type: "select", required: false, options: ["a", "b"] },
      { key: "legal", label: "Accept legal terms", type: "checkbox", required: true, options: ["yes"] },
      { key: "assessment", label: "Assessment answer", type: "textarea", required: true, options: [] },
    ], createdAt: packet.createdAt, updatedAt: packet.createdAt,
  }];
  state.autopilot!.jobs = [{ id: "synthetic-auto-job", jobId: packet.jobId, packetId: packet.id, status: "awaiting_human", humanTaskId: "synthetic-human-task", reason: "Needs review", createdAt: packet.createdAt, updatedAt: packet.createdAt }];
  return state;
}

test("SSE updates timeline, prefill phase and human queue without a reload; attention stays live across pages", async ({ page }) => {
  await page.clock.install();
  const state = syntheticState();
  const { reads, writes, errors } = await mockWorkspace(page, state, false);
  await expect(page.getByText("Live connection", { exact: true })).toBeVisible();
  const initialReads = reads.state;
  const updated = humanState().autopilot!;
  updated.jobs[0]!.status = "prefilling";
  updated.liveEvents = Array.from({ length: 33 }, (_, index) => ({ id: index, jobId: "synthetic-job", phase: "prefilling", message: `Synthetic event ${index}`, timestamp: "2026-09-15T10:00:00Z" }));
  updated.discoveryStatus = "Discovered 3 synthetic jobs; matching in progress.";
  await page.evaluate(view => window.__monitor.emit(view), updated);
  await expect(page.getByRole("list", { name: "Application progress timeline" }).locator("li")).toHaveCount(30);
  await expect(page.getByText("Synthetic event 32", { exact: true })).toBeVisible();
  await expect(page.getByText("Synthetic event 0", { exact: true })).toHaveCount(0);
  await expect(page.locator(".runner-status")).toContainText("Prefilling application");
  await expect(page.getByRole("article", { name: /Human review: Synthetic Employer/ })).toContainText("Step 2");
  await expect(page.getByRole("button", { name: "Human attention: 1", exact: true })).toBeVisible();
  expect(reads.state).toBe(initialReads);
  expect(writes).toEqual([]);
  const source = await page.evaluate(() => window.__monitor.sources.filter(source => !source.closed).map(source => source.url));
  expect(source).toEqual(["/api/monitor/events"]);
  await page.getByRole("button", { name: "Home", exact: true }).click();
  expect(await page.evaluate(() => window.__monitor.sources.filter(source => !source.closed).length)).toBe(1);
  expect(errors).toEqual([]);
});

test("live stream failure is explicit and existing polling keeps refreshing", async ({ page }) => {
  await page.clock.install();
  const state = syntheticState();
  const { reads, errors } = await mockWorkspace(page, state, false);
  await expect(page.getByText("Live connection", { exact: true })).toBeVisible();
  await page.evaluate(() => window.__monitor.sources.find(source => !source.closed)!.onerror?.());
  await expect(page.getByText("Live updates disconnected; reconnecting.", { exact: true })).toBeVisible();
  const before = reads.state;
  state.autopilot!.discoveryStatus = "Synthetic polling update";
  await page.clock.fastForward(5_100);
  await expect(page.locator(".discovery-status")).toContainText("Synthetic polling update");
  expect(reads.state).toBeGreaterThan(before);
  await page.evaluate(view => window.__monitor.emit(view), state.autopilot);
  await expect(page.getByText("Live connection", { exact: true })).toBeVisible();
  expect(errors).toEqual([]);
});

test("live browser is opt-in, private, refreshes while visible and cleans up on hide and navigation", async ({ page }) => {
  await page.clock.install();
  const state = humanState();
  const { reads, writes, errors } = await mockWorkspace(page, state, false);
  expect(reads.screenshots).toEqual([]);
  await page.getByRole("button", { name: "Show live browser", exact: true }).click();
  await expect(page.getByRole("img", { name: "Live application browser with all input values masked" })).toBeVisible();
  expect(reads.screenshots[0]).toMatch(/^\/api\/monitor\/screenshot\?t=\d+$/);
  await page.getByLabel("Browser session", { exact: true }).selectOption("synthetic-owned-session");
  await expect.poll(() => reads.screenshots.some(path => path.includes("sessionId=synthetic-owned-session"))).toBe(true);
  const count = reads.screenshots.length;
  await page.clock.fastForward(2_100);
  await expect.poll(() => reads.screenshots.length).toBeGreaterThan(count);
  await page.getByRole("button", { name: "Hide live browser", exact: true }).click();
  const hiddenCount = reads.screenshots.length;
  await page.clock.fastForward(6_100);
  expect(reads.screenshots).toHaveLength(hiddenCount);
  await expect(page.getByRole("img", { name: /Live application browser/ })).toHaveCount(0);
  expect(await page.evaluate(() => window.__monitor.revoked.length)).toBeGreaterThan(0);
  await page.getByRole("button", { name: "Show live browser", exact: true }).click();
  await expect(page.getByRole("img", { name: /Live application browser/ })).toBeVisible();
  await page.getByRole("button", { name: "Home", exact: true }).click();
  const navigatedCount = reads.screenshots.length;
  await page.clock.fastForward(6_100);
  expect(reads.screenshots).toHaveLength(navigatedCount);
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("live browser 404 reports unavailable without a fabricated image or continuous inactive requests", async ({ page }) => {
  await page.clock.install();
  const { reads, errors } = await mockWorkspace(page, syntheticState(), false);
  let count = 0;
  await page.route("**/api/monitor/screenshot?*", route => { count++; return route.fulfill({ status: 404, json: { error: "No browser" } }); });
  await page.getByRole("button", { name: "Show live browser", exact: true }).click();
  await expect(page.getByText("No live browser is available for this session.", { exact: false })).toBeVisible();
  await expect(page.getByRole("img", { name: /Live application browser/ })).toHaveCount(0);
  await page.clock.fastForward(6_100);
  expect(count).toBe(1); expect(reads.screenshots).toEqual([]); expect(errors).toEqual([]);
});

test("human review continues the exact prefilled record with real options and omits protected and blank answers", async ({ page }, testInfo) => {
  const state = humanState();
  const { writes, errors, documentRequests } = await mockWorkspace(page, state, false);
  const task = page.getByRole("article", { name: /Human review: Synthetic Employer/ });
  const review = task.getByRole("checkbox", { name: "I checked the current prefilled form and supplied the missing answers; continue this application", exact: true });
  await expect(review).not.toBeChecked();
  await expect(task.getByRole("button", { name: "Continue this application", exact: true })).toBeDisabled();
  await expect(task.getByLabel("Answer: Notice period in days", { exact: true })).toHaveValue("30");
  await expect(task.getByLabel("Answer: Preferred working pattern", { exact: true })).toHaveValue("hybrid");
  await expect(task.getByLabel("Answer: Preferred working pattern", { exact: true }).locator("option")).toHaveText(["Choose an answer", "Hybrid schedule", "Office schedule"]);
  await expect(task.getByLabel(/^Answer:/)).toHaveCount(3);
  await expect(task).not.toContainText("MUST-NOT-SEND");
  await expect(task.getByRole("link", { name: "Actual employer application" })).toHaveAttribute("href", state.jobs[0]!.applyUrl);
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: 960 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
    await task.screenshot({ path: testInfo.outputPath(`human-task-${width}.png`) });
  }
  await task.getByRole("button", { name: "Open existing prefilled tab", exact: true }).click();
  await expect(review).not.toBeChecked();
  const downloadEvent = page.waitForEvent("download");
  await task.getByRole("button", { name: "Download derived PDF", exact: true }).click();
  expect((await downloadEvent).suggestedFilename()).toBe("synthetic-job-tailored.pdf");
  await task.getByLabel("Answer: Anything else factual?", { exact: true }).fill("   ");
  await review.check();
  await task.getByRole("button", { name: "Continue this application", exact: true }).click();
  await expect(task).toHaveCount(0);
  await expect(page.getByText("Human review history · 1", { exact: true })).toBeVisible();
  expect(writes.map(write => ({ path: write.path, body: write.body }))).toEqual([
    { path: "/api/hitl/synthetic-human-task/focus", body: {} },
    { path: "/api/hitl/synthetic-human-task/continue", body: { answers: { notice_days: "30", work_mode: "hybrid" }, useCurrentValues: false, confirmReview: true } },
  ]);
  expect(documentRequests).toEqual(["/api/packets/synthetic-tailored-packet/documents/pdf"]);
  expect(state.profile.answers).toEqual({ first_name: "Synthetic", last_name: "Candidate" });
  expect(errors).toEqual([]);
});

test("browser-value approval is separate, task changes reset review, and unknown factual answers stay one-off", async ({ page }) => {
  const state = humanState();
  const { writes, errors } = await mockWorkspace(page, state, false);
  const task = page.locator(".human-task");
  const review = task.locator(".human-review-check input");
  await review.check();
  const updated = structuredClone(state.autopilot!);
  updated.humanTasks![0]!.step = 3;
  await page.evaluate(view => window.__monitor.emit(view), updated);
  await expect(task).toContainText("Step 3");
  await expect(review).not.toBeChecked();
  await task.getByRole("checkbox", { name: /I supplied answers directly in the browser/ }).check();
  await task.getByLabel("Answer: Anything else factual?", { exact: true }).fill("I can start after my current notice period.");
  await expect(review).not.toBeChecked();
  await review.check();
  await task.getByRole("button", { name: "Continue this application", exact: true }).click();
  expect(writes[0]!.body).toEqual({ answers: { context: "I can start after my current notice period." }, useCurrentValues: true, confirmReview: true });
  expect(writes).toHaveLength(1);
  expect(errors).toEqual([]);
});

test("lost sessions cannot continue or retry and abandon explicitly pauses only the owned record", async ({ page }) => {
  const state = humanState("session_lost");
  const { writes, errors } = await mockWorkspace(page, state, false);
  const task = page.locator(".human-task");
  await expect(task).toContainText("This session cannot continue.");
  await expect(task.getByRole("button", { name: /Continue|Open existing prefilled/ })).toHaveCount(0);
  await expect(page.locator(".autopilot-job-list").getByRole("button", { name: /recheck|retry/i })).toHaveCount(0);
  await task.getByRole("button", { name: "Abandon this session", exact: true }).click();
  expect(writes).toEqual([]);
  await expect(task).toContainText("This does not withdraw a submitted application.");
  await task.getByRole("button", { name: "Confirm abandon session", exact: true }).click();
  expect(writes.map(write => ({ path: write.path, body: write.body }))).toEqual([{ path: "/api/hitl/synthetic-human-task/abandon", body: { confirm: true } }]);
  await expect(task).toHaveCount(0);
  expect(errors).toEqual([]);
});

test("No-AI tasks remain manual with no dashboard answer inputs or automatic continuation", async ({ page }) => {
  const state = humanState();
  state.jobs[0]!.aiPolicy = "prohibited";
  const { writes, errors } = await mockWorkspace(page, state, false);
  const task = page.locator(".human-task");
  await expect(task).toContainText("This employer prohibits AI assistance.");
  await expect(task.getByLabel(/^Answer:/)).toHaveCount(0);
  await expect(task.getByRole("button", { name: "Continue this application", exact: true })).toHaveCount(0);
  await expect(task.getByRole("button", { name: "Open existing prefilled tab", exact: true })).toBeEnabled();
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

for (const status of ["awaiting_human", "executing"] as const) {
  test(`packet answers remain read-only during ${status}, never counting a fill as submitted`, async ({ page }) => {
    const state = humanState();
    state.packets[0]!.status = status;
    const { writes, errors } = await mockWorkspace(page, state, false);
    await page.locator(".human-task").getByRole("button", { name: "View exact packet & history", exact: true }).click();
    const review = page.getByRole("region", { name: "Exact application packet review" });
    await expect(review.getByRole("button", { name: "Save edited answers" })).toBeDisabled();
    for (const input of await review.locator(".packet-answers .record-editor textarea, .packet-answers .record-editor input").all()) await expect(input).toBeDisabled();
    await expect(page.locator(".tracker-summary")).toContainText("0All confirmed submissions");
    expect(writes).toEqual([]); expect(errors).toEqual([]);
  });
}

test("generic provider and human/discovery changes clear consent and require saved explicit authorization", async ({ page }) => {
  const state = syntheticState();
  const { writes, errors } = await mockWorkspace(page, state);
  const confirmations = page.locator(".consent-checks input");
  await expect(page.getByLabel("Keep prefilled applications open for human review")).toBeChecked();
  await expect(page.getByLabel("Proactively discover jobs from enabled sources")).toBeChecked();
  for (const checkbox of await confirmations.all()) await checkbox.check();
  await page.getByLabel("Generic career forms", { exact: true }).check();
  for (const checkbox of await confirmations.all()) await expect(checkbox).not.toBeChecked();
  await page.getByRole("button", { name: "Save matching rules" }).click();
  await expect(page.locator(".activation-summary")).toContainText("Ashby, Greenhouse, Generic career forms");
  await expect(page.getByRole("button", { name: "Activate Auto Apply", exact: true })).toBeDisabled();
  expect(writes[0]!.body.rules).toMatchObject({ providers: ["ashby", "greenhouse", "generic"], humanInLoop: true, autoDiscover: true });
  for (const checkbox of await confirmations.all()) await checkbox.check();
  await page.getByLabel("Proactively discover jobs from enabled sources").uncheck();
  for (const checkbox of await confirmations.all()) await expect(checkbox).not.toBeChecked();
  expect(writes.map(write => write.path)).toEqual(["/api/autopilot/rules"]);
  expect(errors).toEqual([]);
});

test("missing monitor fields mean unavailable rather than an empty or fully automatable queue", async ({ page }) => {
  const state = syntheticState();
  delete state.autopilot!.humanTasks;
  delete state.autopilot!.liveEvents;
  delete state.autopilot!.discoveryStatus;
  delete state.autopilot!.rules.autoDiscover;
  delete state.autopilot!.rules.humanInLoop;
  const { writes, errors } = await mockWorkspace(page, state, false);
  await expect(page.getByText("Human review status unavailable.", { exact: false })).toBeVisible();
  await expect(page.getByText("Timeline unavailable;", { exact: false })).toBeVisible();
  await expect(page.getByRole("button", { name: "Human attention: 0", exact: true })).toHaveCount(0);
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("Auto Apply hash landing stays compatible, setup collapses when usable, Home and advanced workflows remain", async ({ page }, testInfo) => {
  const state = syntheticState();
  state.jobs = []; state.stats.totalJobs = 0;
  const { writes, errors } = await mockWorkspace(page, state, false);
  await expect(page.locator(".auto-setup")).not.toHaveAttribute("open");
  await expect(page.getByText("No Auto Apply attempts yet", { exact: true })).toBeVisible();
  await expect(page.getByRole("button", { name: "Human attention: 0", exact: true })).toBeVisible();
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: 960 });
    await expect(page.getByRole("heading", { level: 1, name: "Auto Apply", exact: true })).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
    await page.screenshot({ path: testInfo.outputPath(`auto-apply-monitor-${width}.png`), fullPage: true });
  }
  await page.getByRole("button", { name: "Home", exact: true }).click();
  await expect(page.getByRole("heading", { level: 1, name: "Home", exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Auto Apply", exact: true }).click();
  await page.getByText("Advanced: manual workflows & browser setup", { exact: true }).click();
  await expect(page.getByRole("button", { name: "Manual preparation", exact: true })).toBeVisible();
  await expect(page.getByRole("button", { name: "Reference resumes", exact: true })).toBeVisible();
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test.describe("AI tab, Progress filters and Today sessions", () => {
  test("AI tab lists your Copilot models, fills a listed or newer model into the settings, explains sign-in and sends a non-personal test", async ({ page }) => {
    const state = syntheticState();
    state.runtime.ai = { provider: "copilot", remote: true, model: "gpt-6-astra", available: false, consentRequired: false, authenticated: false, reason: "Sign-in required." };
    const { writes, errors } = await mockWorkspace(page, state);
    let signedIn = false;
    await page.route("**/api/inference/models**", route => route.fulfill({ json: signedIn
      ? { provider: "copilot", signedIn: true, models: [{ id: "gpt-6-astra", name: "GPT-6 Astra", enabled: true }, { id: "claude-sonnet-5", name: "Claude Sonnet 5", enabled: true, multiplier: 1 }, { id: "grok-4.7", enabled: false, state: "disabled" }] }
      : { provider: "copilot", signedIn: false, models: [], reason: "Stored Copilot OAuth authentication is required." } }));
    await page.route("**/api/inference/test", route => route.fulfill({ json: { ok: true, ms: 1234, provider: "copilot", model: "gpt-6-astra", answer: { answer: "Python" } } }));
    await page.getByRole("button", { name: "AI", exact: true }).click();
    await expect(page.getByText("Sign in to GitHub once.")).toBeVisible();
    await expect(page.getByText("npm exec --package=@github/copilot -- copilot login").first()).toBeVisible();
    signedIn = true;
    await page.getByRole("button", { name: "Check again", exact: true }).click();
    const list = page.locator(".model-list");
    await expect(list).toContainText("Claude Sonnet 5");
    await expect(list.locator("li").filter({ hasText: "gpt-6-astra" })).toContainText("In use");
    await expect(list.getByRole("button", { name: /Not available \(disabled\)/ })).toBeDisabled();
    await list.locator("li").filter({ hasText: "claude-sonnet-5" }).getByRole("button", { name: "Use this model" }).click();
    await expect(page.getByLabel("Exact AI model")).toHaveValue("claude-sonnet-5");
    await expect(page.getByRole("button", { name: "Save AI configuration", exact: true })).toBeDisabled();
    await page.getByLabel(/A newer model that is not listed yet/).fill("gpt-7-preview");
    await page.getByRole("button", { name: "Use this model ID" }).click();
    await expect(page.getByLabel("Exact AI model")).toHaveValue("gpt-7-preview");
    await page.getByRole("checkbox", { name: /I allow sending bounded confirmed/ }).check();
    await page.getByRole("checkbox", { name: /I understand that this uses my Copilot/ }).check();
    await page.getByRole("button", { name: "Save AI configuration", exact: true }).click();
    expect(writes.find(write => write.path === "/api/inference/config")!.body).toEqual({ provider: "copilot", model: "gpt-7-preview", allowRemoteProcessing: true, acknowledgeUsage: true });
    await page.getByRole("button", { name: "Send a test question" }).click();
    await expect(page.getByText(/answered in 1\.2 s/)).toBeVisible();
    expect(errors).toEqual([]);
  });

  test("Progress filters by country, role, years of experience and category, hides empty companies and remembers the filters", async ({ page }) => {
    const state = syntheticState();
    const { errors } = await mockWorkspace(page, state);
    const family = (id: string, label: string) => ({ id, label, alwaysApply: true, titleKeywords: [], skillKeywords: [], excludeKeywords: [], minSkillMatches: 0 });
    const job = (id: string, title: string, countries: string[], familyId: string | undefined, years?: number, remote = false) => ({ jobId: id, title, location: countries.join(", ") || "Location not stated",
      countries, remote, applyUrl: "https://example.invalid/job", fetchedAt: "2026-09-28T10:00:00Z", status: "not_applied", detail: "Not applied yet.",
      classification: { relevant: true, interested: true, ...(familyId ? { familyId, familyLabel: familyId } : {}), matchedSkills: [], reason: "fixture" }, ...(years !== undefined ? { yearsRequired: { min: years } } : {}) });
    const company = (id: string, name: string, jobs: unknown[]) => ({ source: { id, label: name, inputUrl: "https://example.invalid", enabled: true, status: "ready", message: "", createdAt: "2026-09-28T10:00:00Z", updatedAt: "2026-09-28T10:00:00Z", jobCount: jobs.length },
      company: name, roleFamilies: [], counts: { applied: 0, marked: 0, in_progress: 0, needs_you: 0, not_applied: jobs.length, not_relevant: 0, failed: 0, total: jobs.length }, jobs });
    const view = { generatedAt: "2026-09-28T10:00:00Z", manual: [], candidateYears: 4, families: [family("data-engineering", "Data Engineering"), family("cloud-engineering", "Cloud Engineering")],
      totals: { applied: 0, marked: 0, in_progress: 0, needs_you: 0, not_applied: 4, not_relevant: 0, failed: 0, total: 4 },
      companies: [company("career-a", "Alpha", [job("a1", "Senior Data Engineer", ["India"], "data-engineering", 5), job("a2", "Cloud Engineer", ["United States"], "cloud-engineering", 8)]),
        company("career-b", "Beta", [job("b1", "Data Platform Engineer", [], "data-engineering", undefined, true), job("b2", "Analytics Engineer", ["India"], undefined, 2)])] };
    await page.route("**/api/progress", route => route.fulfill({ json: view }));
    await page.getByRole("button", { name: "Progress", exact: true }).click();
    await page.waitForTimeout(800);
    if (errors.length) throw new Error(`Page errors: ${errors.join(" | ")}`);
    const role = (title: string) => page.locator(".progress-page table tbody tr", { hasText: title });
    const bar = page.locator(".progress-filter-bar");
    await expect(role("Senior Data Engineer")).toHaveCount(1);
    await bar.getByLabel("Country").selectOption({ label: "United States" });
    await expect(page.getByText("Showing 1 of 4 roles · 1 companies hidden")).toBeVisible();
    await expect(role("Cloud Engineer")).toHaveCount(1);
    await expect(role("Senior Data Engineer")).toHaveCount(0);
    await bar.getByLabel("Country").selectOption({ label: "Remote (any country)" });
    await expect(page.getByText("Showing 1 of 4 roles")).toBeVisible();
    await expect(role("Data Platform Engineer")).toHaveCount(1);
    await page.getByRole("button", { name: "Clear filters" }).click();
    await bar.getByLabel("Years of experience").selectOption({ label: "Fits my experience" });
    await expect(page.getByText("Showing 3 of 4 roles")).toBeVisible();
    await expect(role("Cloud Engineer")).toHaveCount(0);
    await bar.getByLabel("Years of experience").selectOption({ label: "Any" });
    await bar.getByLabel("Category").selectOption({ label: "Data Engineering" });
    await bar.getByLabel("Role", { exact: true }).fill("platform");
    await expect(page.getByText("Showing 1 of 4 roles · 1 companies hidden")).toBeVisible();
    await page.reload();
    await page.getByRole("button", { name: "Progress", exact: true }).click();
    await expect(role("Data Platform Engineer")).toHaveCount(1);
    await expect(bar.getByLabel("Role", { exact: true })).toHaveValue("platform");
    await expect(bar.getByLabel("Category")).toHaveValue("data-engineering");
    expect(errors).toEqual([]);
  });

  test("Today starts a Chrome session of the top roles, shows only proven applications as applied, and asks before marking one yourself", async ({ page }) => {
    const state = syntheticState();
    const { writes, errors } = await mockWorkspace(page, state);
    const entry = (jobId: string, rank: number, status: string, extra: Record<string, unknown> = {}) => ({ jobId, rank, score: 90, tier: "india", label: "Bengaluru, India", sponsorship: "unknown", experience: "fits",
      skills: ["python"], reasons: [], carriedOver: false, company: `Company ${rank}`, title: `Data Engineer ${rank}`, location: "Bengaluru, India", applyUrl: "https://example.invalid/apply", aiPolicy: "unknown", autoApply: false, status, ...extra });
    const counts = { new: 1, opened: 0, filled: 0, review: 1, auto_queued: 0, needs_you: 0, applied: 1, marked: 1, skipped: 0, failed: 0, total: 4 };
    const today = { date: "2026-09-28", generatedAt: "2026-09-28T01:30:00Z", candidates: 4, excluded: {}, levels: ["mid"], companies: { total: 4, crawled: 4, stale: 0 }, autoApply: { enabled: false, reason: "Paused." },
      settings: { enabled: true, dailyCount: 100, runHour: 7, maxPerCompany: 10, priority: "abroad-first", includeIndia: true, includeRemoteGlobal: true, includeAbroadSponsored: true, includeAbroadUnknown: true, experienceYears: null, levels: null, maxAgeDays: 60, minScore: 30 },
      counts, entries: [entry("job-1", 1, "new"), entry("job-2", 2, "review", { detail: "Ready for your review: check the answers and click Submit yourself." }),
        entry("job-3", 3, "applied", { detail: 'The careers.example page said "Thank you for applying".', evidence: { kind: "confirmation_page", at: "2026-09-28T10:00:00Z", detail: "Thank you for applying" } }),
        entry("job-4", 4, "marked", { detail: "You marked this as submitted. No confirmation page or email has been seen, so it is not counted as applied." })] };
    let session: unknown = { available: 2 };
    await page.route("**/api/shortlist", route => route.fulfill({ json: today }));
    await page.route("**/api/shortlist/*/status", route => { writes.push({ path: new URL(route.request().url()).pathname, body: route.request().postDataJSON(), raw: "" }); return route.fulfill({ json: today }); });
    await page.route("**/api/apply-sessions/current", route => route.fulfill({ json: session }));
    await page.route("**/api/apply-sessions", route => {
      writes.push({ path: "/api/apply-sessions", body: route.request().postDataJSON(), raw: "" });
      session = { available: 0, session: { id: "s1", number: 1, status: "active", size: 2, concurrency: 10, createdAt: "2026-09-28T10:00:00Z", updatedAt: "2026-09-28T10:00:00Z", open: 0, finished: 0,
        counts: { queued: 2, opened: 0, working: 0, needs_you: 0, review: 0, submitted: 0, closed: 0, skipped: 0, failed: 0 },
        items: [{ jobId: "job-1", rank: 1, company: "Company 1", title: "Data Engineer 1", location: "Bengaluru", startUrl: "https://example.invalid/apply", state: "queued", updatedAt: "2026-09-28T10:00:00Z" }] } };
      return route.fulfill({ json: session });
    });
    await page.getByRole("button", { name: "Today", exact: true }).click();
    await expect(page.locator(".today-stats")).toContainText("1 marked by you, not verified");
    const rows = page.locator(".today-table tbody tr");
    await expect(rows).toHaveCount(2, { timeout: 5000 });
    await page.getByRole("tab", { name: "All (4)" }).click();
    await expect(rows.filter({ hasText: "Data Engineer 3" })).toContainText("Applied ✓");
    await expect(rows.filter({ hasText: "Data Engineer 4" })).toContainText("Marked by you · not verified");
    await expect(rows.filter({ hasText: "Data Engineer 2" })).toContainText("Ready for your review");
    page.once("dialog", dialog => void dialog.dismiss());
    await rows.filter({ hasText: "Data Engineer 1" }).getByRole("button", { name: "I submitted it" }).click();
    expect(writes.some(write => write.path.endsWith("/status"))).toBe(false);
    page.once("dialog", dialog => void dialog.accept());
    await rows.filter({ hasText: "Data Engineer 1" }).getByRole("button", { name: "I submitted it" }).click();
    await expect.poll(() => writes.find(write => write.path === "/api/shortlist/job-1/status")?.body).toEqual({ status: "applied" });
    await rows.filter({ hasText: "Data Engineer 4" }).getByRole("button", { name: "Undo" }).click();
    await expect.poll(() => writes.find(write => write.path === "/api/shortlist/job-4/status")?.body).toEqual({ status: "opened" });
    await page.getByRole("button", { name: "Auto-apply top 2 in Chrome" }).click();
    await expect.poll(() => writes.some(write => write.path === "/api/apply-sessions")).toBe(true);
    await expect(page.getByText(/Pair the Chairman extension|could not be reached/)).toBeVisible();
    await expect(page.getByRole("heading", { name: "Session 1: 0 of 2 finished" })).toBeVisible();
    await expect(page.getByRole("button", { name: "Stop session" })).toBeVisible();
    expect(errors).toEqual([]);
  });
});
