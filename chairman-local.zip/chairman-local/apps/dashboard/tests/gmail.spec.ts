import { test, expect, type Page } from "@playwright/test";
import { createServer, type ViteDevServer } from "vite";
import { resolve } from "node:path";
import type { GmailStatus } from "../../../packages/domain/gmail";

let server: ViteDevServer;
let origin: string;
const harness = `
  import React from "react";
  import {createRoot} from "react-dom/client";
  import {GmailSettings} from "./GmailSettings";
  import "./styles.css";
  function Harness() {
    const [error,setError] = React.useState("");
    const run = async (_label, action) => {
      try { setError(""); await action(); return true; }
      catch (cause) { setError(cause.message); return false; }
    };
    return React.createElement("main", {className:"main-content"},
      React.createElement("p", {role:"alert"}, error),
      React.createElement(GmailSettings, {busy:false,run}));
  }
  createRoot(document.getElementById("root")).render(React.createElement(Harness));
`;
test.beforeAll(async () => {
  server = await createServer({ configFile: resolve("apps/dashboard/vite.config.ts"), cacheDir: resolve("apps/dashboard/.gmail-test-cache"),
    plugins: [{ name: "gmail-component-harness", enforce: "pre", transform: (_code, id) => id.endsWith("/src/main.tsx") ? { code: harness, map: null } : undefined }],
    server: { host: "127.0.0.1", port: 0, open: false } });
  await server.listen(); origin = server.resolvedUrls!.local[0]!;
});
test.afterAll(async () => { await server?.close(); });

async function mount(page: Page, state: GmailStatus) {
  const writes: { path: string; body: Record<string, unknown> }[] = [];
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.route("**/api/gmail/**", async route => {
    const path = new URL(route.request().url()).pathname;
    if (route.request().method() === "GET") return route.fulfill({ json: state });
    const body = route.request().postDataJSON() as Record<string, unknown>;
    writes.push({ path, body });
    if (path.endsWith("/config")) state.configured = true;
    if (path.endsWith("/connect")) { state.authorizing = true; return route.fulfill({ json: { url: "https://accounts.google.com/o/oauth2/v2/auth?state=synthetic" } }); }
    if (path.endsWith("/review")) state.suggestions = [];
    if (path.endsWith("/disconnect")) {
      state.connected = false; state.configured = false; state.authorizing = false; state.suggestions = [];
      state.error = "Gmail disconnected locally, but Google revocation was not confirmed. Remove access in Google Account connections.";
    }
    return route.fulfill({ json: state });
  });
  await page.goto(origin);
  await expect(page.getByRole("heading", { name: "Gmail status suggestions" })).toBeVisible();
  return { writes, errors };
}

test("Gmail setup separates private client storage, explicit consent and Google sign-in without scanning automatically", async ({ page }) => {
  const state: GmailStatus = { configured: false, connected: false, authorizing: false, busy: false, suggestions: [] };
  const { writes, errors } = await mount(page, state);
  await page.getByLabel("Google Desktop client ID", { exact: true }).fill("synthetic-browser-client.apps.googleusercontent.com");
  await page.getByLabel("Google Desktop client secret", { exact: true }).fill("synthetic-secret");
  await expect(page.getByLabel("Google Desktop client secret", { exact: true })).toHaveAttribute("type", "password");
  await page.getByRole("button", { name: "Save Google client", exact: true }).click();
  await expect(page.getByRole("button", { name: "Connect Gmail", exact: true })).toBeDisabled();
  await expect(page.getByLabel("Google Desktop client secret", { exact: true })).toHaveValue("");
  await page.getByRole("checkbox", { name: /I allow read-only Gmail access/ }).check();
  await page.getByRole("button", { name: "Connect Gmail", exact: true }).click();
  await expect(page.getByRole("link", { name: "Continue to Google sign-in" })).toHaveAttribute("href", /^https:\/\/accounts\.google\.com\//);
  await expect(page.getByText("Google sign-in is waiting for you. No email scan has started.")).toBeVisible();
  expect(writes.map(item => item.path)).toEqual(["/api/gmail/config", "/api/gmail/connect"]);
  expect(writes[1]!.body).toEqual({ consent: true });
  expect(errors).toEqual([]);
});

test("Gmail suggestions require explicit acceptance and failed remote revocation is visible on mobile", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const state: GmailStatus = { configured: true, connected: true, authorizing: false, busy: false, suggestions: [{
    id: "a".repeat(64), messageId: "message1", applicationId: "application1", applicationKind: "external",
    jobId: "job1", company: "Example Company", title: "Software Engineer", sender: "Recruiter <recruiter@example.test>",
    subject: "Interview invitation", receivedAt: new Date().toISOString(), stage: "interview", previousStage: "applied",
  }] };
  const { writes, errors } = await mount(page, state);
  await expect(page.getByRole("button", { name: "Accept status", exact: true })).toBeVisible();
  expect(writes).toEqual([]);
  await page.getByRole("button", { name: "Accept status", exact: true }).click();
  await expect(page.getByRole("button", { name: "Accept status", exact: true })).toHaveCount(0);
  expect(writes[0]!.body).toEqual({ id: "a".repeat(64), action: "accept" });
  await page.getByRole("button", { name: "Disconnect and remove Gmail data" }).click();
  await expect(page.getByText(/Gmail disconnected locally, but Google revocation was not confirmed/)).toBeVisible();
  await expect(page.getByText("Not connected", { exact: true })).toBeVisible();
  expect(errors).toEqual([]);
});
