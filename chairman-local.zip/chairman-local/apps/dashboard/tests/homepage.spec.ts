import { expect, test, type Page } from "@playwright/test";
import { createServer, type ViteDevServer } from "vite";
import { resolve } from "node:path";
import type { State } from "../src/model";
import type { SearchPortal } from "../../../packages/domain/discovery-settings";
import type { TrackingRow } from "../../../packages/domain/application-tracker";

declare global {
  interface Window {
    __chairmanNotifications: { requests: number; sent: { title: string; body: string }[] };
  }
}
let server: ViteDevServer;
let origin: string;
test.beforeAll(async () => {
  server = await createServer({ configFile: resolve("apps/dashboard/vite.config.ts"), cacheDir: resolve("apps/dashboard/.test-cache"),
    server: { host: "127.0.0.1", port: 0, open: false } });
  await server.listen(); origin = server.resolvedUrls!.local[0]!;
});
test.afterAll(async () => { await server?.close(); });

function fixture(): State {
  return {
    profile: { name: "Synthetic Candidate", email: "candidate@example.invalid", phone: "", location: "India", links: {}, skills: ["Python"],
      facts: [{ id: "f1", category: "experience", text: "Built synthetic systems using Python.", confirmed: true }], answers: {}, confirmed: true, version: 1,
      preferences: { roles: ["Software engineer"], countries: ["India"], excludedEmployers: [], salaryTargetInr: 0, dailyLimit: 10, timezone: "Asia/Kolkata", allowLongTermContracts: false, authorizedCountries: ["India"], needsSponsorshipAbroad: true } },
    jobs: [{ id: "j1", sourceId: "himalayas", sourceJobId: "j1", title: "Backend Engineer", company: "Synthetic Employer", location: "India", remote: true,
      countries: ["India"], employmentType: "full-time", description: "Build synthetic backend services using Python.", applyUrl: "https://jobs.example.com/engineer",
      canonicalUrl: "https://jobs.example.com/engineer", fetchedAt: "2026-09-20T12:00:00Z", salary: null, language: "English", sponsorship: "unknown", aiPolicy: "allowed", status: "open",
      match: { score: 90, matchedSkills: ["Python"], missingSkills: [], reasons: [], warnings: [], blockers: [], eligible: true, needsReview: false } }],
    sources: [{ id: "himalayas", name: "Himalayas", kind: "himalayas", mode: "enabled", discoveryEnabled: true, nextScanAt: "2099-01-01T12:00:00Z",
      careersUrl: "https://himalayas.app/jobs", discoveryAllowed: true, assistanceAllowed: false, submissionAllowed: false, policyUrl: "https://himalayas.app/api", notes: "Reviewed public API; no form permission." }],
    packets: [], careerSources: [], referenceResumes: [], preparationQueue: [],
    resumeVariants: [1, 2].map(slot => ({ id: `v${slot}`, slot, label: `Baseline ${slot}`, families: ["software"], originalFilename: `baseline-${slot}.docx`,
      artifact: { format: "docx", filename: `baseline-${slot}.docx`, bytes: 100, sha256: `synthetic-${slot}` }, uploadedAt: "2026-09-20T12:00:00Z", approved: true, textLength: 300, issues: [] })),
    autopilot: { enabled: false, ready: true, blockers: [], rules: { providers: ["ashby"], minimumScore: 70, allowUnknownSalary: false, allowUnknownSponsorship: false,
      allowUnknownRemoteEligibility: false, intervalSeconds: 30, stopAtDailyGoal: false, employerAllowlist: [] }, snapshotHash: "synthetic-snapshot", jobs: [], humanTasks: [], liveEvents: [], browserRunning: false, status: "Paused" },
    campaign: { config: { startDate: "2026-09-20", days: 45, dailyTarget: 500, timezone: "Asia/Kolkata" }, endDate: "2026-11-03", dayNumber: 1, daysRemaining: 45,
      totalTarget: 22500, confirmedToday: 0, confirmedTotal: 0, targetToDate: 500, remainingToGoal: 22500, interviews: 0, offers: 0, followUpsDue: 0,
      interviewRate: 0, untrackedSubmissionDates: 0, daily: [], sources: [] },
    stats: { attemptsToday: 0, attemptsSession: 0, limit: 10, submitted: 0, totalJobs: 1, stopped: false },
    runtime: { ai: { available: false, provider: "gemini", model: "gemini-2.5-flash", reason: "Synthetic quota unavailable" }, cloud: { configured: false }, extension: { paired: false } },
  };
}
async function workspace(page: Page) {
  const state = fixture();
  const portals: SearchPortal[] = [{ id: "indeed", label: "Indeed", urlTemplate: "https://www.indeed.com/jobs?q={role}&l={location}", builtIn: true }];
  const rows: TrackingRow[] = Array.from({ length: 30 }, (_, i) => ({
    id: `a${i}`, kind: "assistance", jobId: `job${i}`, company: i === 0 ? "Synthetic Employer" : `Employer ${i}`,
    title: "Backend Engineer", portal: "jobs.example.com", applyUrl: "https://jobs.example.com/engineer", date: "2026-09-20T12:00:00Z",
    updatedAt: "2026-09-20T12:00:00Z", status: i === 1 ? "submitted_confirmed" : i === 2 ? "manual_required" : "filled", notes: "",
    ...(i === 1 ? { stage: "applied", progress: { kind: "external", id: "e1", note: "Preserved original progress note" } } : {}),
  }));
  const writes: { path: string; body: Record<string, unknown> }[] = [];
  const errors: string[] = [];
  const control = { failNotes: false, failTracking: false };
  await page.addInitScript(() => {
    class TestEventSource extends EventTarget { onopen: (() => void) | null = null; constructor() { super(); queueMicrotask(() => this.onopen?.()); } close() {} }
    window.EventSource = TestEventSource as unknown as typeof EventSource;
    window.__chairmanNotifications = { requests: 0, sent: [] };
    class TestNotification {
      static permission = "default";
      static async requestPermission() { window.__chairmanNotifications.requests++; TestNotification.permission = "granted"; return "granted"; }
      constructor(title: string, options?: NotificationOptions) { window.__chairmanNotifications.sent.push({ title, body: options?.body || "" }); }
    }
    window.Notification = TestNotification as unknown as typeof Notification;
  });
  page.on("pageerror", cause => errors.push(cause.message));
  await page.route("**/*", async route => {
    const request = route.request(), url = new URL(request.url());
    if (url.origin !== new URL(origin).origin) return route.abort();
    if (!url.pathname.startsWith("/api/")) return route.continue();
    const reply = (body: unknown, status = 200) => route.fulfill({ json: body, status });
    if (request.method() === "GET") {
      if (url.pathname === "/api/state") return reply(state);
      if (url.pathname === "/api/session") return reply({});
      if (url.pathname === "/api/search-portals") return reply({ portals });
      if (url.pathname === "/api/tracking") {
        if (control.failTracking) return reply({ error: "Synthetic tracking read failure" }, 503);
        const q = url.searchParams.get("q") || "", status = url.searchParams.get("status"), stage = url.searchParams.get("stage");
        const filtered = rows.filter(row => `${row.company} ${row.title} ${row.portal} ${row.notes}`.toLowerCase().includes(q.toLowerCase()) && (!status || row.status === status) && (!stage || row.stage === stage));
        const offset = Number(url.searchParams.get("offset") || 0), limit = 25;
        return reply({ items: filtered.slice(offset, offset + limit), total: filtered.length, offset, limit });
      }
      if (url.pathname.startsWith("/api/packets/")) return reply({ packet: state.packets[0], job: state.jobs[0] });
      return reply({ items: [], total: 0, offset: 0, limit: 25 });
    }
    const body = request.headers()["content-type"]?.includes("application/json") ? request.postDataJSON() as Record<string, unknown> : {};
    writes.push({ path: url.pathname, body });
    if (url.pathname === "/api/search-portals") {
      if (body.action === "remove") portals.splice(portals.findIndex(item => item.id === body.id), 1);
      else {
        const portal: SearchPortal = { id: typeof body.id === "string" ? body.id : "custom", label: String(body.label), urlTemplate: String(body.urlTemplate), builtIn: false };
        const index = portals.findIndex(item => item.id === portal.id);
        if (index < 0) portals.push(portal); else portals[index] = portal;
      }
      return reply({ portals });
    }
    if (url.pathname === "/api/discovery/preferences") { state.sources[0]!.discoveryEnabled = body.enabled === true; state.sources[0]!.mode = body.enabled ? "enabled" : "paused"; return reply({ changed: true }); }
    if (url.pathname.startsWith("/api/assistance/")) {
      const row = rows.find(row => row.id === url.pathname.split("/")[3])!;
      if (control.failNotes) return reply({ error: "Synthetic notes storage failure" }, 503);
      if (typeof body.notes === "string") row.notes = body.notes;
      if (body.status === "manual_required" || body.status === "filled" || body.status === "submission_unknown" || body.status === "abandoned") row.status = body.status;
      if (url.pathname.endsWith("/receipt")) { row.status = "submitted_confirmed"; row.stage = "applied"; state.stats.submitted++; state.campaign.confirmedTotal++; }
      return reply({ record: row });
    }
    if (url.pathname === "/api/external-applications/e1/progress") {
      rows[1]!.stage = body.stage as TrackingRow["stage"]; return reply({});
    }
    if (url.pathname === "/api/resume-variants/v1/tailor") {
      state.packets.push({ id: "preview-packet", jobId: "j1", jobHash: "j", profileHash: "p", profileVersion: 1, createdAt: "2026-09-20T12:00:00Z",
        draft: { mode: "jd-tailored", factIds: ["f1"], skills: ["Python"], notes: [] }, artifacts: [], answers: {}, warnings: [], status: "prepared", variantId: "v1",
        tailoring: { baseVariantId: "v1", baseVariantLabel: "Baseline 1", baseVariantSha256: "synthetic-1", jobDescriptionHash: "d", engine: "deterministic", supportedKeywords: [], missingKeywords: [], notes: [] },
        resumeContent: { name: state.profile.name, email: state.profile.email, phone: "", location: "India", links: {}, skills: ["Python"], facts: state.profile.facts, keywordTerms: [] } });
      return reply({ packet: state.packets[0] });
    }
    return reply({});
  });
  await page.goto(origin);
  await expect(page.getByRole("heading", { level: 1, name: "Home", exact: true })).toBeVisible();
  return { state, writes, rows, portals, errors, control };
}

test("Chairman defaults to Home, exposes all six workflow steps, and never auto-activates", async ({ page }) => {
  const { writes, errors } = await workspace(page);
  await expect(page).toHaveTitle("Chairman · Your application workspace");
  await expect(page.getByRole("link", { name: "Chairman home" })).toBeVisible();
  const workflow = page.getByRole("navigation", { name: "Application workflow" });
  await expect(workflow.getByRole("button")).toHaveCount(6);
  await workflow.getByRole("button", { name: /Confirm your profile/ }).click();
  await expect(page.getByRole("heading", { level: 1, name: "Your profile" })).toBeVisible();
  await page.getByRole("button", { name: "Home", exact: true }).click();
  await workflow.getByRole("button", { name: /Track the actual outcome/ }).click();
  await expect(page.getByRole("heading", { name: "Application monitoring", exact: true })).toBeVisible();
  await page.goto(`${origin}#autopilot`);
  await expect(page.getByRole("heading", { level: 1, name: "Auto Apply" })).toBeVisible();
  expect(writes).toEqual([]); expect(errors).toEqual([]);
});

test("Resumes exposes all baseline slots and reuses the exact packet preview without sending", async ({ page }) => {
  const { state, writes, errors } = await workspace(page);
  await page.getByRole("button", { name: "Open your resume library", exact: true }).click();
  await expect(page.getByRole("region", { name: "Baseline resume library" }).getByRole("article")).toHaveCount(8);
  await expect(page.getByLabel("Original PDF or DOCX for slot 3")).toBeVisible();
  await page.getByLabel("Slot 3 label").fill("Unsaved baseline");
  await page.getByLabel("Approved base template").selectOption("v1");
  await page.getByLabel("Loaded job description").selectOption("j1");
  await expect(page.getByRole("button", { name: "Preview JD-tailored resume" })).toBeDisabled();
  await page.getByRole("button", { name: "Discard slot edits", exact: true }).click();
  await page.getByRole("button", { name: "Preview JD-tailored resume" }).click();
  await expect(page.getByRole("region", { name: "Exact application packet review" })).toContainText("Frozen resume content");
  expect(writes.map(item => item.path)).toEqual(["/api/resume-variants/v1/tailor"]);
  expect(state.autopilot!.enabled).toBe(false);
  expect(state.stats.submitted).toBe(0); expect(errors).toEqual([]);
});

test("manual portal templates validate, persist, edit, and never grant discovery or login", async ({ page }) => {
  const { writes, portals, state, errors } = await workspace(page);
  await page.getByRole("button", { name: "Search job websites", exact: true }).click();
  const panel = page.getByRole("region", { name: "Your job search websites" });
  await panel.getByLabel("Website name").fill("My remote jobs");
  await panel.getByLabel("HTTPS search URL template").fill("http://localhost/search?role={role}");
  await panel.getByRole("button", { name: "Save search website" }).click();
  await expect(panel).toContainText("Use an HTTPS URL");
  expect(writes).toEqual([]);
  await panel.getByLabel("HTTPS search URL template").fill("https://jobs.example.com/search?q={role}&where={location}");
  await panel.getByRole("button", { name: "Save search website" }).click();
  await expect(panel.getByRole("link", { name: /My remote jobs/ })).toHaveAttribute("href", "https://jobs.example.com/search?q=Software%20engineer&where=India");
  await panel.getByRole("button", { name: "Edit My remote jobs" }).click();
  await panel.getByLabel("Website name").fill("Reviewed bookmark");
  await panel.getByRole("button", { name: "Save search website" }).click();
  await expect(panel.getByRole("link", { name: /Reviewed bookmark/ })).toBeVisible();
  expect(portals.at(-1)!.builtIn).toBe(false);
  await page.getByLabel("Public discovery for Himalayas").uncheck();
  await expect(page.getByLabel("Public discovery for Himalayas")).not.toBeChecked();
  expect(state.sources[0]!.nextScanAt).toBe("2099-01-01T12:00:00Z");
  expect(state.autopilot!.enabled).toBe(false);
  expect(writes.map(write => write.path)).toEqual(["/api/search-portals", "/api/search-portals", "/api/discovery/preferences"]);
  expect(errors).toEqual([]);
});

test("monitoring has accessible columns, bounded pagination, factual stages and recoverable note failures", async ({ page }) => {
  const { writes, rows, state, control, errors } = await workspace(page);
  await page.getByRole("button", { name: "Application monitoring", exact: true }).click();
  const table = page.getByRole("table", { name: /Application records across/ });
  await expect(table.getByRole("columnheader")).toHaveText(["Select", "Company", "Role", "Portal / where applied", "Apply URL", "Date", "Last stage", "Status", "Notes", "Actions"]);
  await expect(table.getByRole("row")).toHaveCount(26);
  await page.getByRole("button", { name: "Next tracking page" }).click();
  await expect(table.getByRole("row")).toHaveCount(6);
  await page.getByRole("button", { name: "Previous tracking page" }).click();
  await page.getByRole("button", { name: "Edit Synthetic Employer Backend Engineer" }).click();
  await page.getByLabel("Tracking notes").fill("Follow up next week.");
  control.failNotes = true;
  await page.getByRole("button", { name: "Save tracking notes" }).click();
  await expect(page.getByRole("alert")).toContainText("Synthetic notes storage failure");
  await expect(page.getByLabel("Tracking notes")).toHaveValue("Follow up next week.");
  expect(rows[0]!.notes).toBe("");
  control.failNotes = false;
  await page.getByRole("button", { name: "Save tracking notes" }).click();
  await expect(table.getByText("Follow up next week.", { exact: true })).toBeVisible();
  await page.getByLabel("Assistance outcome").selectOption("manual_required");
  await page.getByRole("button", { name: "Save assistance outcome" }).click();
  await expect(table.getByRole("row").filter({ hasText: "Synthetic Employer" })).toContainText("Manual action needed");
  expect(state.stats.submitted).toBe(0);
  page.once("dialog", dialog => dialog.accept());
  await page.getByRole("button", { name: "Edit Employer 1 Backend Engineer", exact: true }).click();
  await page.getByLabel("Recorded hiring stage").selectOption("interview");
  await page.getByRole("button", { name: "Save hiring stage" }).click();
  await expect(table.getByRole("row").filter({ has: page.getByRole("rowheader", { name: "Employer 1", exact: true }) })).toContainText("Interview");
  expect(writes.find(write => write.path.endsWith("/progress"))!.body.note).toBe("Preserved original progress note");
  await page.getByLabel("Tracking status").selectOption("filled");
  await expect(table.getByText("Submission confirmed", { exact: true })).toHaveCount(0);
  expect(errors).toEqual([]);
});

test("bulk notes are bounded and tracking read failures never appear as successful empty results", async ({ page }) => {
  const { rows, control, errors } = await workspace(page);
  await page.getByRole("button", { name: "Application monitoring", exact: true }).click();
  await page.getByLabel("Select Synthetic Employer Backend Engineer").check();
  await page.getByLabel("Select Employer 2 Backend Engineer", { exact: true }).check();
  await page.getByLabel("Replace notes for 2 selected records (maximum 20)").fill("Reviewed in today's session");
  await page.getByRole("button", { name: "Save notes to selected records" }).click();
  await expect(page.getByRole("status").filter({ hasText: "2 notes saved" })).toBeVisible();
  expect(rows[0]!.notes).toBe("Reviewed in today's session"); expect(rows[2]!.notes).toBe("Reviewed in today's session");
  expect(rows[0]!.status).toBe("filled"); expect(rows[2]!.status).toBe("manual_required");
  control.failTracking = true;
  await page.getByRole("button", { name: "Refresh tracking" }).click();
  await expect(page.getByRole("region", { name: "Application monitoring", exact: true })).toContainText("Previously shown data may be stale");
  await expect(page.getByRole("button", { name: "Edit Synthetic Employer Backend Engineer" })).toBeDisabled();
  expect(errors).toEqual([]);
});

test("desktop notifications require a user gesture and contain counts, never personal or employer details", async ({ page }) => {
  const { state, errors } = await workspace(page);
  expect(await page.evaluate(() => window.__chairmanNotifications.requests)).toBe(0);
  state.autopilot!.humanTasks = [{ id: "synthetic-task", packetId: "p1", jobId: "j1", sessionId: "s1", reason: "login", url: "https://jobs.example.com", step: 1,
    status: "waiting", missingFields: [], filledFields: [], createdAt: "2026-09-20T12:00:00Z", updatedAt: "2026-09-20T12:00:00Z" }];
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await expect(page.getByRole("button", { name: "Human attention: 1" })).toBeVisible();
  expect(await page.evaluate(() => window.__chairmanNotifications.sent)).toEqual([]);
  await page.getByRole("button", { name: "Enable desktop notifications" }).click();
  await expect.poll(() => page.evaluate(() => window.__chairmanNotifications.sent.length)).toBe(1);
  const notices = await page.evaluate(() => window.__chairmanNotifications);
  expect(notices.requests).toBe(1);
  expect(JSON.stringify(notices.sent)).not.toMatch(/Synthetic Employer|candidate@example|Synthetic Candidate/);
  await page.reload();
  await expect(page.getByRole("button", { name: "Turn off desktop notifications" })).toBeVisible();
  expect(await page.evaluate(() => window.__chairmanNotifications.requests)).toBe(0);
  expect(errors).toEqual([]);
});

test("Chairman Home and monitoring retain the teal layout without mobile overflow", async ({ page }, testInfo) => {
  const { errors } = await workspace(page);
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: 960 });
    await page.getByRole("button", { name: "Home", exact: true }).click();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await page.screenshot({ path: testInfo.outputPath(`chairman-home-${width}.png`), fullPage: true });
    await page.getByRole("button", { name: "Application monitoring", exact: true }).click();
    await expect(page.getByRole("table", { name: /Application records across/ })).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await page.screenshot({ path: testInfo.outputPath(`chairman-monitoring-${width}.png`), fullPage: true });
  }
  expect(errors).toEqual([]);
});
