import { defineConfig } from "@playwright/test";
import { mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";

const scratch = fileURLToPath(new URL("./.browser-tmp/", import.meta.url));
mkdirSync(scratch, { recursive: true });
process.env.TMPDIR = scratch;

export default defineConfig({
  testDir: "./tests",
  outputDir: "./.test-results",
  workers: 1,
  reporter: "list",
  timeout: 45_000,
  use: { channel: "chrome", headless: true, screenshot: "only-on-failure" },
});
