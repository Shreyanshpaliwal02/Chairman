/// <reference types="chrome" />
import type { PendingRun } from "./contracts";
import { ExtensionController } from "./controller";
import { assertExactDestination, isFixture, isFixtureReceipt, localApiOrigin, permissionFor } from "./safety";
import { readFixtureReceipt } from "./receipt";
import { installAssistanceWorker } from "./assist-worker";

const TOKEN = "jaa.token";
const PENDING = "jaa.pending";
const PORT = "jaa.port";
const sessionReady = chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
// Callers await sessionReady and see its failure; this only prevents an unhandled-rejection report at startup.
sessionReady.catch(() => {});

async function token(): Promise<string> {
  await sessionReady;
  const value = (await chrome.storage.session.get(TOKEN))[TOKEN];
  if (typeof value !== "string" || !value) throw new Error("Pair the extension with the local service first.");
  return value;
}

async function apiOrigin(): Promise<string> {
  await sessionReady;
  const port = (await chrome.storage.session.get(PORT))[PORT];
  return localApiOrigin(typeof port === "number" ? port : 4318);
}

async function api<T>(path: string, body?: unknown): Promise<T> {
  const bearer = await token();
  const origin = await apiOrigin();
  let response: Response;
  try {
    response = await fetch(`${origin}${path}`, {
      method: body === undefined ? "GET" : "POST",
      headers: { Authorization: `Bearer ${bearer}`, ...(body === undefined ? {} : { "Content-Type": "application/json" }) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      credentials: "omit", redirect: "error", cache: "no-store", referrerPolicy: "no-referrer",
      signal: AbortSignal.timeout(/^\/api\/extension\/assist\/(?:prepare|edit|plan|report)$/.test(path) ? 150_000 : /^\/api\/extension\/assist\/grant$/.test(path) ? 30_000 : 10_000)
    });
  } catch {
    throw new Error(`The local service is unavailable or timed out. Keep it running on ${origin}.`);
  }
  if (!response.ok) {
    const detail: unknown = response.headers.get("content-type")?.includes("application/json") ? await response.json() : undefined;
    const error = detail && typeof detail === "object" && "error" in detail && typeof detail.error === "string"
      ? detail.error.replace(/[\u0000-\u001f\u007f]/g, " ").slice(0, 1800) : `Local service rejected this operation (HTTP ${response.status}).`;
    throw new Error(error);
  }
  if (!response.headers.get("content-type")?.includes("application/json")) throw new Error("The local service did not return JSON.");
  return response.json() as Promise<T>;
}

async function activeTab(url: string, tabId?: number): Promise<number> {
  if (!await chrome.permissions.contains({ origins: [permissionFor(url)] })) {
    throw new Error("Grant access to this exact destination using Open job.");
  }
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab?.id || (tabId !== undefined && tab.id !== tabId)) throw new Error("Keep the approved application tab active.");
  assertExactDestination(tab.url, url);
  if (tab.status !== "complete") throw new Error("Wait for the application page to finish loading.");
  return tab.id;
}

async function bounded<T>(operation: Promise<T>, milliseconds: number): Promise<T> {
  let timeout: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([operation, new Promise<never>((_, reject) => {
      timeout = setTimeout(() => reject(new Error("The page stopped responding. Check the application manually.")), milliseconds);
    })]);
  } finally { clearTimeout(timeout); }
}

const controller = new ExtensionController({
  api, apiOrigin,
  getPending: async () => {
    await sessionReady;
    return (await chrome.storage.session.get(PENDING))[PENDING] as PendingRun | undefined;
  },
  setPending: async (pending) => { await sessionReady; await chrome.storage.session.set({ [PENDING]: pending }); },
  clearPending: async () => { await chrome.storage.session.remove(PENDING); },
  hasToken: async () => { try { return !!await token(); } catch { return false; } },
  activeTab,
  open: async (url) => {
    if (!await chrome.permissions.contains({ origins: [permissionFor(url)] })) throw new Error("Destination access was not granted.");
    await chrome.tabs.create({ url, active: true });
  },
  inject: async (tabId, url) => {
    await activeTab(url, tabId);
    const results = await chrome.scripting.executeScript({
      target: { tabId, frameIds: [0] }, files: ["content.js"], world: "ISOLATED"
    });
    const documentId = results.find((result) => result.frameId === 0)?.documentId;
    if (!documentId) throw new Error("The top-level application document is unavailable.");
    await activeTab(url, tabId);
    return documentId;
  },
  page: async (tabId, documentId, command) => {
    await activeTab(command.url, tabId);
    const response = await bounded(chrome.tabs.sendMessage(tabId, {
      channel: "jaa:page", command: { ...command, expiresAt: Date.now() + 12_000 }
    }, { documentId }), 15_000);
    if (!response?.ok) throw new Error(response?.error || "The application page disconnected.");
    return response.result;
  },
  fixtureConfirmation: async (tabId, approvedUrl) => {
    if (!isFixture(approvedUrl)) return undefined;
    const deadline = Date.now() + 8_000;
    while (Date.now() < deadline) {
      const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (active?.id !== tabId || !active.url) return undefined;
      if (isFixtureReceipt(active.url, approvedUrl) && active.status === "complete") {
        const results = await chrome.scripting.executeScript({
          target: { tabId, frameIds: [0] }, world: "ISOLATED", func: readFixtureReceipt, args: [approvedUrl]
        });
        const receipt = results.find((result) => result.frameId === 0)?.result;
        if (receipt) return receipt;
      } else if (active.url !== approvedUrl && !isFixtureReceipt(active.url, approvedUrl)) {
        return undefined;
      }
      await new Promise((resolve) => setTimeout(resolve, 250));
    }
    return undefined;
  }
});

const recovered = sessionReady.then(() => controller.recover());
recovered.catch(() => {});
const assistance = installAssistanceWorker(api, apiOrigin, () => actionActive || pairing);
function ensurePanelBehavior(attempt = 0): void {
  // The toolbar click is handled by the page assistant: it opens the panel and asks Chrome for this site's access in one gesture.
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {
    // Chrome rejects with "No SW" while it is still registering a just-reloaded worker; retry shortly.
    if (attempt < 4) setTimeout(() => ensurePanelBehavior(attempt + 1), 500 * (attempt + 1));
  });
}
ensurePanelBehavior();
chrome.runtime.onInstalled.addListener(() => ensurePanelBehavior());

let pairing = false;
let actionActive = false;
chrome.runtime.onMessage.addListener((message: unknown, sender, respond) => {
  if (sender.id !== chrome.runtime.id || sender.tab || sender.url !== chrome.runtime.getURL("sidepanel.html") ||
      !message || typeof message !== "object" || (message as { channel?: unknown }).channel !== "jaa:panel") return;
  const request = message as { action?: string; token?: unknown; packetId?: unknown; port?: unknown };
  (async () => {
    await recovered;
    const mutating = request.action !== "state";
    if (mutating && (actionActive || assistance.busy())) throw new Error("Another operation is active. Wait for its result.");
    if (mutating) actionActive = true;
    try {
    if (request.action === "pair") {
      if (pairing) throw new Error("Pairing is already in progress.");
      if ((await chrome.storage.session.get(PENDING))[PENDING]) throw new Error("Reconcile the existing execution before changing the pairing token.");
      if (typeof request.token !== "string" || !/^[\x21-\x7e]{16,512}$/.test(request.token)) throw new Error("Paste a valid pairing token from the local service.");
      const port = request.port === undefined ? 4318 : request.port;
      if (typeof port !== "number") throw new Error("Choose the numeric port used by the local service.");
      const assistPending = (await chrome.storage.session.get("chairman.assistPending"))["chairman.assistPending"];
      if (assistPending && port !== ((await chrome.storage.session.get(PORT))[PORT] ?? 4318))
        throw new Error("Re-pair the same service and reconcile the interrupted fill before changing ports.");
      localApiOrigin(port);
      pairing = true;
      const previous = await chrome.storage.session.get([TOKEN, PORT]);
      try {
        await chrome.storage.session.set({ [TOKEN]: request.token, [PORT]: port });
        await api("/api/extension/connect", {});
      } catch (error) {
        await chrome.storage.session.remove([TOKEN, PORT]);
        await chrome.storage.session.set(previous);
        throw error;
      } finally { pairing = false; }
    } else if (request.action === "recover") {
      await controller.recover();
    } else if (["open", "preflight", "execute"].includes(request.action ?? "")) {
      if (pairing) throw new Error("Wait for pairing to finish.");
      if (typeof request.packetId !== "string" || !request.packetId || request.packetId.length > 200) throw new Error("Select a valid packet.");
      if (request.action === "open") await controller.open(request.packetId);
      if (request.action === "preflight") await controller.preflight(request.packetId);
      if (request.action === "execute") await controller.execute(request.packetId);
    } else if (request.action !== "state") {
      throw new Error("Unknown extension action.");
    }
    return controller.state();
    } finally { if (mutating) actionActive = false; }
  })().then(
    (state) => respond({ ok: true, state }),
    (error: unknown) => respond({ ok: false, error: error instanceof Error ? error.message : "The operation failed." })
  );
  return true;
});
