/// <reference types="chrome" />
import { API_ORIGIN, type PanelState, type QueueItem } from "./contracts";
import { permissionFor } from "./safety";

const element = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;
const errorBox = element("error");
let latest: PanelState | undefined;
let busy = false;

function showError(error: unknown): void {
  errorBox.hidden = false;
  errorBox.textContent = error instanceof Error ? error.message : "The operation failed. Refresh and review the local dashboard.";
}

async function request(action: string, extra: Record<string, unknown> = {}): Promise<PanelState> {
  const result = await chrome.runtime.sendMessage({ channel: "jaa:panel", action, ...extra });
  if (!result?.ok) throw new Error(result?.error || "The extension worker did not respond.");
  return result.state;
}

async function perform(action: string, extra: Record<string, unknown> = {}): Promise<void> {
  if (busy) return;
  busy = true;
  errorBox.hidden = true;
  element("status").textContent = action === "execute"
    ? "Revalidating and executing the approved packet. Keep the job tab active. Do not edit its form."
    : "Checking the local service…";
  document.querySelectorAll<HTMLButtonElement>("button").forEach((button) => { button.disabled = true; });
  try { latest = await request(action, extra); } catch (error) { showError(error); }
  finally {
    busy = false;
    document.querySelectorAll<HTMLButtonElement>("button").forEach((button) => { button.disabled = false; });
    if (latest) render(latest);
    else element("status").textContent = "Not connected. Start the local service and pair this extension.";
  }
}

function text<K extends keyof HTMLElementTagNameMap>(tag: K, value: string, className?: string): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  node.textContent = value;
  if (className) node.className = className;
  return node;
}

function packetRow(item: QueueItem, state: PanelState): HTMLLIElement {
  const row = document.createElement("li");
  row.append(text("h3", item.job.title), text("p", item.job.company, "company"));
  row.append(text("p", `${item.packet.status.replaceAll("_", " ")} · ${item.job.applyUrl}`, "metadata"));
  const attribution = text("p", "", "metadata");
  const sourceName = item.job.sourceId === "himalayas" ? "Himalayas" : item.job.sourceId;
  try {
    const canonical = new URL(item.job.canonicalUrl);
    if (canonical.protocol !== "https:" || canonical.username || canonical.password) throw new Error("Unsupported source link.");
    const link = text("a", `Source: ${sourceName}`);
    link.href = canonical.href;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    attribution.append(link);
  } catch {
    attribution.textContent = `Source: ${sourceName}`;
  }
  row.append(attribution);
  const blocked = !item.automationAllowed || state.queue?.stopped || !!state.pending;
  if (item.reason) row.append(text("p", item.reason, "blocker"));
  if (item.packet.formSnapshot) {
    const form = item.packet.formSnapshot;
    const blockers = [...form.unsupported, ...(form.hasCaptcha ? ["CAPTCHA requires you."] : []), ...(form.hasLegal ? ["Declarations require manual review."] : [])];
    if (blockers.length) row.append(text("p", blockers.join(" "), "blocker"));
  }
  const actions = document.createElement("div");
  actions.className = "packet-actions";
  const open = text("button", "Open job", "quiet");
  open.type = "button";
  open.disabled = blocked;
  open.addEventListener("click", () => {
    if (busy) return;
    let origin: string;
    try { origin = permissionFor(item.job.applyUrl); } catch (error) { showError(error); return; }
    // Permission requests must begin in the click gesture, before messaging the worker.
    chrome.permissions.request({ origins: [origin] }).then((granted) => {
      if (!granted) throw new Error("Host access was declined. Continue manually or choose Open job again.");
      return perform("open", { packetId: item.packet.id });
    }).catch(showError);
  });
  const preflight = text("button", "Inspect form", "quiet");
  preflight.type = "button";
  preflight.disabled = blocked || !["prepared", "approved"].includes(item.packet.status);
  preflight.addEventListener("click", () => { void perform("preflight", { packetId: item.packet.id }); });
  const execute = text("button", "Execute approved packet", "execute");
  execute.type = "button";
  execute.disabled = blocked || item.packet.status !== "approved" || !item.packet.formSnapshot ||
    !!item.packet.formSnapshot.hasCaptcha || !!item.packet.formSnapshot.hasLegal || !!item.packet.formSnapshot.unsupported.length;
  execute.addEventListener("click", () => { void perform("execute", { packetId: item.packet.id }); });
  actions.append(open, preflight, execute);
  row.append(actions);
  return row;
}

function render(state: PanelState): void {
  const origin = new URL(state.apiOrigin ?? API_ORIGIN);
  element("endpoint").textContent = `${origin.host} · No remote service`;
  element<HTMLAnchorElement>("dashboard-link").href = origin.href;
  element<HTMLInputElement>("port").value = origin.port;
  element("connection-state").textContent = state.paired ? "Paired for this session" : "Not paired";
  element("status").textContent = state.message;
  element("queue-state").textContent = state.queue?.stopped
    ? "Stopped. Resume the queue in the dashboard before inspecting or executing."
    : "Open job → inspect form → approve in dashboard → execute.";
  element("recover").hidden = !state.pending;
  element<HTMLButtonElement>("refresh").disabled = busy;
  element<HTMLButtonElement>("pair-form").querySelector<HTMLButtonElement>("button")!.disabled = busy || !!state.pending;
  const packets = element("packets");
  packets.replaceChildren(...(state.queue?.items ?? []).map((item) => packetRow(item, state)));
  element("empty").hidden = !!state.queue?.items.length;
  element("empty").textContent = state.paired
    ? "No application packets yet. Prepare one in the local dashboard, then refresh."
    : "No packets loaded. Pair the local service, then prepare a packet in your dashboard.";
}

element<HTMLFormElement>("pair-form").addEventListener("submit", (event) => {
  event.preventDefault();
  if (busy) return;
  const input = element<HTMLInputElement>("token");
  const token = input.value.trim();
  const port = Number(element<HTMLInputElement>("port").value);
  input.value = "";
  chrome.permissions.request({ origins: [`${new URL(API_ORIGIN).protocol}//${new URL(API_ORIGIN).hostname}/*`] })
    .then((granted) => {
      if (!granted) throw new Error("Local service access was declined. Pair again to grant loopback access.");
      return perform("pair", { token, port });
    }).catch(showError);
});
element("refresh").addEventListener("click", () => { void perform("state"); });
element("recover").addEventListener("click", () => { void perform("recover"); });
void perform("state");
