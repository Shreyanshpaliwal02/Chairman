import type { FormSnapshot, Job, Packet } from "../../packages/domain/types";

export const API_ORIGIN = "http://127.0.0.1:4318";
export interface QueueItem {
  packet: Packet;
  job: Job;
  automationAllowed: boolean;
  reason?: string;
}
export interface QueueResponse {
  items: QueueItem[];
  stopped: boolean;
}
export interface ResumeFile {
  base64: string;
  mime: string;
  filename: string;
}
export interface Claim {
  packet: Packet;
  job: Job;
  fields: Record<string, string>;
  resume: ResumeFile;
  runToken: string;
}
export interface RunReport {
  packetId: string;
  runToken: string;
  outcome: "submitted_confirmed" | "submission_unknown" | "failed";
  confirmation?: string;
  error?: string;
}
export interface PendingRun {
  packetId: string;
  tabId: number;
  url: string;
  phase: "claiming" | "claimed" | "submitting";
  runToken?: string;
}
export type PageCommand = (
  | { action: "snapshot"; url: string }
  | { action: "fill"; url: string; fingerprint: string; key: string; value: string }
  | { action: "attach"; url: string; fingerprint: string; resume: ResumeFile }
  | { action: "verify"; url: string; fingerprint: string; fields: Record<string, string>; resume: ResumeFile }
  | { action: "submit"; url: string; fingerprint: string; fields: Record<string, string>; resume: ResumeFile }
) & { expiresAt?: number };

export interface PageResult {
  snapshot?: FormSnapshot;
  confirmation?: string;
}
export interface PanelState {
  paired: boolean;
  apiOrigin?: string;
  pending?: PendingRun;
  message: string;
  queue?: QueueResponse;
}
