import type { FormSnapshot } from "../../packages/domain/types";
import type { ResumeFile } from "./contracts";

const blockedDomains = ["linkedin.com", "lnkd.in", "wellfound.com", "angel.co", "naukri.com", "indeed.com", "indeed.jobs"];
export function localApiOrigin(port: number = 4318): string {
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error("Use a loopback service port between 1024 and 65535.");
  return `http://127.0.0.1:${port}`;
}

export function destination(raw: string): URL {
  const url = new URL(raw);
  const host = url.hostname.toLowerCase().replace(/\.$/, "");
  if (blockedDomains.some((domain) => host === domain || host.endsWith(`.${domain}`)) || /(^|\.)indeed\.[a-z.]+$/.test(host)) {
    throw new Error("This site is manual-only. No extension inspection or automation is permitted.");
  }
  if (url.username || url.password || url.hash || host !== url.hostname) {
    throw new Error("Unsupported destination URL.");
  }
  if (url.protocol !== "https:" && !isFixture(raw)) {
    throw new Error("Only HTTPS destinations or the controlled local fixture are supported.");
  }
  if (url.protocol === "https:" && (
    host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") ||
    !host.includes(".") || /^[\d.]+$/.test(host) || host.includes(":") ||
    (url.port !== "" && url.port !== "443")
  )) throw new Error("Private or nonstandard destination hosts are unsupported.");
  return url;
}

export function permissionFor(raw: string): string {
  const url = destination(raw);
  return `${url.protocol}//${url.hostname}/*`;
}

export function isFixture(raw: string): boolean {
  const url = new URL(raw);
  return url.protocol === "http:" && url.hostname === "127.0.0.1" && Number(url.port) >= 1024 &&
    url.pathname === "/fixture/application" && !url.hash && !url.username && !url.password;
}

export function isFixtureReceipt(raw: string, approvedUrl: string): boolean {
  if (!isFixture(approvedUrl)) return false;
  const url = new URL(raw);
  const approved = new URL(approvedUrl);
  const parameters = [...url.searchParams.entries()];
  return url.origin === approved.origin && url.pathname === "/fixture/confirmation" && !url.hash &&
    !url.username && !url.password && parameters.length === 1 && parameters[0][0] === "id" &&
    /^[A-Za-z0-9_-]{1,100}$/.test(parameters[0][1]);
}

export function assertExactDestination(actual: string | undefined, expected: string): void {
  const approved = destination(expected).href;
  if (!actual || actual !== approved) throw new Error("Activate the exact approved job page. Redirects and other tabs are not supported.");
}

export function snapshotPayload(snapshot: Omit<FormSnapshot, "fingerprint"> | FormSnapshot): string {
  return JSON.stringify({
    url: snapshot.url,
    fields: snapshot.fields.map((field) => ({
      key: field.key, label: field.label, type: field.type, required: field.required, options: field.options
    })),
    hasCaptcha: snapshot.hasCaptcha,
    hasLegal: snapshot.hasLegal,
    unsupported: snapshot.unsupported
  });
}

export async function fingerprint(snapshot: Omit<FormSnapshot, "fingerprint"> | FormSnapshot): Promise<string> {
  const bytes = new TextEncoder().encode(snapshotPayload(snapshot));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function assertApprovedSnapshot(current: FormSnapshot, approved: FormSnapshot | undefined): Promise<void> {
  if (!approved || approved.fingerprint !== await fingerprint(approved) ||
      current.fingerprint !== await fingerprint(current) ||
      snapshotPayload(current) !== snapshotPayload(approved)) {
    throw new Error("The form changed or has not been approved. Run preflight and approve a new packet.");
  }
  if (current.hasCaptcha || current.hasLegal || current.unsupported.length) {
    throw new Error("This form needs manual review; CAPTCHA, declarations, or unsupported controls prevent automation.");
  }
}

export function assertFillPlan(snapshot: FormSnapshot, fields: Record<string, string>, resume: ResumeFile): void {
  const keys = new Set(snapshot.fields.map((field) => field.key));
  if (keys.size !== snapshot.fields.length || Object.keys(fields).some((key) => !keys.has(key))) {
    throw new Error("The approved answer mapping does not match the form.");
  }
  let fileCount = 0;
  for (const field of snapshot.fields) {
    if (field.type === "file") {
      fileCount++;
      if (!/\b(resume|cv|curriculum vitae)\b/i.test(`${field.label} ${field.key}`) || Object.hasOwn(fields, field.key)) {
        throw new Error("Only one explicitly identified resume upload is supported.");
      }
      continue;
    }
    if (!Object.hasOwn(fields, field.key) || typeof fields[field.key] !== "string") {
      throw new Error(`A confirmed answer is required for: ${field.label || field.key}.`);
    }
    if (field.type === "select" && !field.options.includes(fields[field.key])) {
      throw new Error(`The approved option is not available for: ${field.label || field.key}.`);
    }
    if (!["text", "email", "tel", "url", "number", "date", "textarea", "select"].includes(field.type)) {
      throw new Error("An unsupported field cannot be filled.");
    }
  }
  if (fileCount !== 1) throw new Error("Exactly one resume file input is required.");
  decodeResume(resume);
}

export function decodeResume(resume: ResumeFile): Uint8Array<ArrayBuffer> {
  if (!resume || !["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"].includes(resume.mime) ||
      typeof resume.filename !== "string" || !/^[^/\\\x00-\x1f]{1,150}\.(pdf|docx)$/i.test(resume.filename) ||
      typeof resume.base64 !== "string" || resume.base64.length > 14_000_000 ||
      !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(resume.base64)) {
    throw new Error("The approved resume is invalid or exceeds the 10 MB limit.");
  }
  const bytes = Uint8Array.from(atob(resume.base64), (char) => char.charCodeAt(0));
  if (!bytes.length || bytes.length > 10_000_000) throw new Error("The approved resume is empty or too large.");
  const pdf = resume.mime === "application/pdf";
  if (pdf ? !resume.filename.toLowerCase().endsWith(".pdf") || new TextDecoder().decode(bytes.slice(0, 5)) !== "%PDF-"
    : !resume.filename.toLowerCase().endsWith(".docx") || bytes[0] !== 0x50 || bytes[1] !== 0x4b) {
    throw new Error("The resume content does not match its approved file type.");
  }
  return bytes;
}
