/// <reference types="chrome" />
import { pageDifference, type AssistanceFillResult, type AssistanceGrant, type AssistancePage, type AssistanceRecord, type AssistanceReview, type AssistDebugStep,
  type AssistPlan, type AssistRepair } from "../../packages/domain/extension-assist";
import type { PageNavigation } from "./assist-page";
import { assistanceDestination, assistancePermission } from "./assist-safety";
import { applicationStartUrl } from "../../packages/domain/apply-start";

type Review = AssistanceReview & { packetHash?: string };
export interface FillSummary {
  url: string;
  at: string;
  filled: number;
  preserved: number;
  errors: { label: string; message: string }[];
  skipped: { label: string; reason: string }[];
  newFields: number;
  repairs: number;
  remembered: number;
  blockers: string[];
}
/** One traced panel action. Steps are value-free: labels, counts, timings and errors, never answers or files. */
export interface DebugStep { t: number; source: "worker" | "page" | "service"; step: string; detail?: string; ok?: false }
export interface DebugRun { id: number; action: string; at: string; page?: string; ms?: number; failedAt?: string; error?: string; steps: DebugStep[] }
/** Where Chairman left a tab it opened for your application session ("manual" tabs are driven by you from the panel). */
export type TabStage = "manual" | "working" | "needs_you" | "review" | "submitted" | "paused";
export interface SessionTab { tabId: number; jobId: string; company: string; title: string; stage: TabStage; message: string }
export interface SessionOverview {
  id: string; number: number; status: "active" | "complete" | "stopped"; size: number; finished: number; open: number; queued: number;
  submitted: number; available: number; tabs: SessionTab[];
}
export interface AssistState {
  page?: AssistancePage;
  plan?: AssistPlan;
  review?: Review;
  result?: FillSummary;
  url?: string;
  message: string;
  busy: boolean;
  activity?: string;
  /** Your tracked companies' application sites (`https://host/*`) and those Chrome has not allowed yet. */
  sites?: { origins: string[]; missing: string[]; at: number };
  debug: { verbose: boolean; runs: DebugRun[] };
  /** Present when Chairman is driving this tab through the application (a session role, or a tab where you chose Fill everything). */
  tab?: { jobId: string; company: string; title: string; stage: TabStage; steps: number; needs: string[]; session: boolean };
  /** Your current application session (up to 50 roles, 10 tabs at a time), as last seen by this browser. */
  session?: SessionOverview;
}
/** One tab's own application: its page, plan, record and pending fill never mix with another tab's. */
interface TabSession {
  id: number;
  view: AssistState;
  recordId?: string;
  pending?: { id: string; grantId: string };
  job?: { jobId: string; company: string; title: string };
  /** Chairman drives this tab step by step (fill, Next) up to the final review. */
  auto: boolean;
  /** Opened for a role in your application session (finishing it opens the next role). */
  session: boolean;
  stage: TabStage;
  steps: number;
  needs: string[];
  lastAdvance?: { fingerprint: string; text: string; at: number; repeats: number };
  /** The direct application link Chairman opened for this role, so a site sending you back to the job page is not reopened in a loop. */
  started?: string;
  /** Times in a row this tab's page did not answer in time (Chrome slows background tabs); retried a few times before asking you. */
  slow?: number;
  scanning: boolean;
  lastPassive: number;
  useAi: boolean;
  timer?: ReturnType<typeof setTimeout>;
}
type Saved = Pick<TabSession, "recordId" | "pending" | "job" | "auto" | "session" | "stage" | "steps" | "needs" | "lastAdvance"> & { message: string };
interface ServiceSession {
  session?: { id: string; number: number; status: SessionOverview["status"]; size: number; finished: number; open: number;
    counts: Record<string, number>; items: { jobId: string; company: string; title: string; state: string; startUrl: string }[] };
  available: number;
}
type Api = <T>(path: string, body?: unknown) => Promise<T>;
const PENDING = "chairman.assistPending", SITES = "chairman.assistSites", VERBOSE = "chairman.debugVerbose", TABS = "chairman.tabs", SESSION = "chairman.session";
const INTRO = "Allow Chairman on this career site to plan answers for its application form. Visiting never fills or submits anything.";
/** Steps a session tab may take on its own before it waits for you (sign-in pages, Apply, Next). */
const MAX_STEPS = 25;
/** The side panel's "Use AI for questions without a saved answer" choice (stored by the panel). */
const AI_SETTING = "chairman.assistAi";
const messageOf = (error: unknown) => error instanceof Error ? error.message : "The assistance operation failed.";
const pagePath = (raw?: string) => { try { const url = new URL(raw ?? ""); return `${url.origin}${url.pathname}`; } catch { return undefined; } };

export function installAssistanceWorker(api: Api, apiOrigin: () => Promise<string>, legacyBusy: () => boolean = () => false): { busy: () => boolean } {
  const debug: AssistState["debug"] = { verbose: false, runs: [] };
  const tabs = new Map<number, TabSession>();
  let sites: AssistState["sites"];
  let session: SessionOverview | undefined, sessionWindow: number | undefined;
  let lastNotice = "", run: DebugRun | undefined, runStarted = 0, runs = 0, working = 0, opening = false;
  let queue: Promise<unknown> = Promise.resolve();
  void chrome.storage.local.get(VERBOSE).then(value => { debug.verbose = value[VERBOSE] === true; }).catch(() => undefined);

  const fresh = (id: number): TabSession => ({ id, view: { message: INTRO, busy: false, debug }, auto: false, session: false, stage: "manual", steps: 0, needs: [], scanning: false, lastPassive: 0, useAi: true });
  function tabOf(id: number): TabSession {
    let entry = tabs.get(id);
    if (!entry) { entry = fresh(id); tabs.set(id, entry); }
    return entry;
  }
  async function restore(): Promise<void> {
    const saved = (await chrome.storage.session.get(TABS))[TABS] as Record<string, Saved> | undefined;
    for (const [key, value] of Object.entries(saved ?? {})) {
      const entry = tabOf(Number(key));
      Object.assign(entry, { recordId: value.recordId, pending: value.pending, job: value.job, auto: value.auto === true, session: value.session === true, stage: value.stage ?? "manual",
        steps: value.steps ?? 0, needs: value.needs ?? [], lastAdvance: value.lastAdvance });
      entry.view.message = value.message || entry.view.message;
    }
    const kept = (await chrome.storage.session.get(SESSION))[SESSION] as { overview?: SessionOverview; windowId?: number } | undefined;
    session = kept?.overview; sessionWindow = kept?.windowId;
  }
  const restored = restore().catch(() => undefined);
  async function persist(): Promise<void> {
    const value: Record<string, Saved> = {};
    for (const [id, entry] of tabs) if (entry.recordId || entry.auto || entry.pending)
      value[id] = { recordId: entry.recordId, pending: entry.pending, job: entry.job, auto: entry.auto, session: entry.session, stage: entry.stage, steps: entry.steps, needs: entry.needs,
        lastAdvance: entry.lastAdvance, message: entry.view.message };
    await chrome.storage.session.set({ [TABS]: value });
    await chrome.storage.session.set({ [SESSION]: { overview: session, windowId: sessionWindow } });
  }
  /** Page work runs one operation at a time across all tabs, so two applications never interleave. */
  function exclusive<T>(work: () => Promise<T>): Promise<T> {
    const next = queue.then(async () => { working++; try { return await work(); } finally { working--; } });
    queue = next.catch(() => undefined);
    return next;
  }

  function begin(action: string): void {
    run = { id: ++runs, action, at: new Date().toISOString(), steps: [] };
    runStarted = Date.now();
    debug.runs = [run, ...debug.runs].slice(0, 6);
  }
  function step(source: DebugStep["source"], name: string, detail = "", ok = true): void {
    if (debug.verbose) (ok ? console.debug : console.warn)(`[Chairman ${source}] ${name}`, detail);
    if (!run || run.steps.length >= 500) return;
    run.steps.push({ t: Date.now() - runStarted, source, step: name, ...(detail ? { detail: detail.slice(0, 600) } : {}), ...(ok ? {} : { ok: false as const }) });
  }
  function fail(name: string, error: unknown): void {
    if (run && !run.failedAt) { run.failedAt = name; run.error = messageOf(error); }
  }
  function finish(entry: TabSession | undefined, error?: unknown): void {
    if (!run) return;
    run.ms = Date.now() - runStarted;
    run.page = pagePath(entry?.view.page?.url ?? entry?.view.url);
    if (error && !run.failedAt) { run.failedAt = "action"; run.error = messageOf(error); }
    run = undefined;
  }
  /** Runs one named stage; a thrown error marks the run as failed at exactly this stage. */
  async function stage<T>(name: string, work: () => Promise<T>, describe?: (value: T) => string): Promise<T> {
    const started = Date.now();
    try {
      const value = await work();
      step("worker", name, `${Date.now() - started} ms${describe ? ` · ${describe(value)}` : ""}`);
      return value;
    } catch (error) {
      step("worker", name, `${Date.now() - started} ms · ${messageOf(error)}`, false);
      fail(name, error);
      throw error;
    }
  }
  /** Follow-up work (like refreshing the plan after a fill) is recorded but never marks a completed action as failed. */
  async function nonFatal(name: string, work: () => Promise<unknown>): Promise<boolean> {
    const before = run ? { failedAt: run.failedAt, error: run.error } : undefined;
    try { await work(); return true; } catch (error) {
      if (run && before) { run.failedAt = before.failedAt; run.error = before.error; }
      step("worker", name, `not critical: ${messageOf(error)}`, false);
      return false;
    }
  }
  /** Calls the local service as a traced stage and folds its own diagnostic steps into the run. */
  async function service<T>(name: string, path: string, body: unknown, describe?: (value: T) => string): Promise<T> {
    return stage(name, async () => {
      const value = await api<T & { debug?: AssistDebugStep[] }>(path, body);
      for (const entry of value?.debug ?? []) step("service", entry.step, entry.detail, entry.ok !== false);
      if (value && typeof value === "object" && "debug" in value) delete (value as { debug?: unknown }).debug;
      return value as T;
    }, describe);
  }
  async function notice(entry: TabSession | undefined, message: string): Promise<void> {
    if (entry) entry.view.message = message;
    await chrome.action.setBadgeText({ text: "!", ...(entry?.auto ? { tabId: entry.id } : {}) });
    await chrome.action.setBadgeBackgroundColor({ color: "#9b3b1c" });
    if (message !== lastNotice && await chrome.permissions.contains({ permissions: ["notifications"] })) {
      lastNotice = message;
      await chrome.notifications.create(entry?.auto ? `chairman-attention-${entry.id}` : "chairman-attention", {
        type: "basic", iconUrl: chrome.runtime.getURL("icon.png"), title: "Chairman needs your attention",
        message: entry?.auto ? "One of your application tabs is waiting for you. Open the Chairman side panel to see which." : "Open the Chairman side panel to review the current step. No application submission is implied."
      });
    }
  }
  /** The tab to work in: the one you are looking at, or (for a session tab) that exact tab. */
  async function tabContext(passive = false, id?: number): Promise<{ id: number; url: string }> {
    const tab = id === undefined ? (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0] : await chrome.tabs.get?.(id).catch(() => undefined);
    if (!tab?.id) throw new Error(id === undefined ? "Open a job application tab, then click the Chairman extension icon." : "This application tab was closed.");
    // Chrome hides a tab's address until Chairman has access to that site (or you clicked Chairman's toolbar icon on it).
    if (!tab.url) throw new Error("Chairman can't see this tab yet. Click the Chairman icon in Chrome's toolbar while this tab is open, then choose Allow when Chrome asks.");
    tabOf(tab.id).view.url = tab.url;
    const url = assistanceDestination(tab.url).href, permission = assistancePermission(url);
    if (!await chrome.permissions.contains({ origins: [permission] })) throw new Error("Chairman is not allowed on this site yet. Use Allow on this site; this never grants Submit permission.");
    const allowed = (await chrome.storage.local.get(SITES))[SITES] as string[] | undefined;
    // Session tabs were opened by you starting a session; any other tab is inspected only on a site you allowed for it.
    if (passive && id === undefined && !allowed?.includes(permission)) throw new Error("This site has not been allowed for inspection.");
    if (tab.status !== "complete") throw new Error("Wait for the current page to finish loading.");
    return { id: tab.id, url };
  }
  async function exact(entry: TabSession, url: string): Promise<void> {
    const current = await tabContext(true, entry.auto ? entry.id : undefined);
    if (current.id !== entry.id || current.url !== url) throw new Error("The active page changed. Return to the application page and plan again.");
  }
  async function inject(entry: TabSession, url: string): Promise<string> {
    await exact(entry, url);
    const results = await chrome.scripting.executeScript({ target: { tabId: entry.id, frameIds: [0] }, files: ["assist-content.js"], world: "ISOLATED" });
    const documentId = results.find(result => result.frameId === 0)?.documentId;
    if (!documentId) throw new Error("The top-level application document is unavailable.");
    await exact(entry, url); return documentId;
  }
  async function page<T>(entry: TabSession, documentId: string, url: string, action: string, extra: Record<string, unknown> = {}): Promise<T> {
    await exact(entry, url);
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      const response = await Promise.race([
        chrome.tabs.sendMessage(entry.id, { channel: "chairman:page", action, debug: debug.verbose, ...extra }, { documentId }),
        // Chrome gives background tabs little CPU time, so a tab Chairman works through in the background gets longer.
        new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error("The page stopped responding. Inspect the actual page; do not assume data was sent.")), action === "fill" ? 95_000 : entry.auto ? 45_000 : 20_000); })
      ]) as { ok?: boolean; error?: string; result?: unknown; trace?: { step: string; detail?: string; ok?: false }[] } | undefined;
      for (const item of response?.trace ?? []) step("page", item.step, item.detail, item.ok !== false);
      if (!response?.ok) throw new Error(response?.error || "The page disconnected.");
      return response.result as T;
    } finally { clearTimeout(timer); }
  }
  function planIsCurrent(entry: TabSession): boolean {
    const view = entry.view;
    return !!view.plan && !!view.page && view.plan.url === view.page.url && view.plan.pageFingerprint === view.page.fingerprint;
  }
  async function scan(entry: TabSession | undefined, passive = false): Promise<TabSession | undefined> {
    // A passive rescan only refreshes the panel; it waits for any running page work instead of interleaving with it.
    if (entry?.scanning || (passive && (entry?.view.busy || working > 0))) return entry;
    let target = entry;
    try {
      const tab = passive ? await tabContext(true, entry?.auto ? entry.id : undefined) : await stage("tab", () => tabContext(true, entry?.auto ? entry.id : undefined), value => pagePath(value.url) ?? "");
      target = tabOf(tab.id);
      if (target.scanning) return target;
      target.scanning = true;
      const documentId = passive ? await inject(target, tab.url) : await stage("inject", () => inject(target!, tab.url));
      const result = passive ? await page<AssistancePage>(target, documentId, tab.url, "scan")
        : await stage("page-scan", () => page<AssistancePage>(target!, documentId, tab.url, "scan"),
          value => `${value.snapshot.fields.length} questions, ${value.occupied.length} with values, kind ${value.kind}${value.embedded ? `, embedded ${value.embedded.host}` : ""}`);
      await exact(target, tab.url);
      const view = target.view;
      view.page = result;
      const questions = result.snapshot.fields.length;
      if (!target.auto || target.stage === "manual") view.message = planIsCurrent(target) ? "Your reviewed plan still matches this page."
        : result.embedded ? `The application form is embedded from ${result.embedded.host}. Open it directly to fill it.`
          : questions ? `${questions} application question${questions === 1 ? "" : "s"} found. Plan answers when you are ready; nothing is sent until then.`
            : result.job ? `${result.job.title}: job description captured. Open the application form (Apply) to fill it.`
              : "No application questions on this page yet. Open the application form, then plan answers.";
      if (!target.auto) await chrome.action.setBadgeText({ text: questions ? String(Math.min(questions, 99)) : result.job ? "JD" : "" });
      // A tab you filled with Chairman: its "application received" page is the proof that you applied.
      if (!target.auto && target.recordId && view.result) await watchOutcome(target, documentId, tab.url).catch(() => undefined);
      return target;
    } catch (error) {
      if (target) target.view.page = undefined;
      if (passive) { if (target) target.view.message = messageOf(error); if (!target?.auto) await chrome.action.setBadgeText({ text: "" }); return target; }
      throw error;
    } finally { if (target) target.scanning = false; }
  }
  async function plan(entry: TabSession, ai: boolean): Promise<void> {
    const target = (await scan(entry)) ?? entry;
    const view = target.view;
    if (!view.page) throw new Error("Open an application page first.");
    target.useAi = ai;
    const questions = view.page.snapshot.fields.length;
    view.activity = ai && questions ? "Planning answers; questions without a saved answer may be sent to your configured AI…" : "Planning answers…";
    try {
      const next = await service<AssistPlan>("service-plan", "/api/extension/assist/plan", { ...(target.recordId ? { id: target.recordId } : {}), page: view.page, ai,
        ...(target.auto && target.job ? { jobId: target.job.jobId } : {}) },
        value => `${value.items.filter(item => item.include && item.value !== undefined).length} ready of ${value.items.length}; AI asked ${value.ai.asked}, reused ${value.ai.cached}${value.ai.reason ? `; ${value.ai.reason}` : ""}`);
      delete next.debug;
      view.plan = next;
      await refreshSites();
      target.recordId = next.recordId;
      await persist();
      const ready = next.items.filter(item => item.include && item.value !== undefined).length, resume = next.resume?.selected ? " and a resume" : "";
      const needs = next.items.filter(item => item.source === "manual" && item.required && !/^Already answered/.test(item.reason ?? "")).length;
      view.message = ready || resume ? `${ready} answer${ready === 1 ? "" : "s"}${resume} ready to review${needs ? `; ${needs} question${needs === 1 ? "" : "s"} need you` : ""}. Check them, then fill.`
        : needs ? `${needs} question${needs === 1 ? "" : "s"} need your answer. Type them in the plan or on the page.` : "Nothing to fill on this page. Existing answers are kept.";
    } finally { view.activity = undefined; }
  }
  async function reviewed(entry: TabSession): Promise<Review> {
    if (!entry.recordId || !entry.view.page) throw new Error("Plan or import this job first.");
    const review = await service<Review>("service-review", "/api/extension/assist/review", { id: entry.recordId, page: entry.view.page });
    entry.view.review = review; return review;
  }
  async function recover(entry: TabSession): Promise<void> {
    const legacy = (await chrome.storage.session.get(PENDING))[PENDING] as { id: string; grantId: string } | undefined;
    const pending = entry.pending ?? legacy;
    if (!pending) { step("worker", "recover", "no interrupted fill"); return; }
    await service("service-recover", "/api/extension/assist/recover", pending);
    entry.pending = undefined;
    if (legacy) await chrome.storage.session.remove(PENDING);
    await persist();
  }
  /** Fills the reviewed rows of `reviewedPlan` on the tab's page, reports the outcome, then re-plans for anything left. */
  async function fillReviewed(entry: TabSession, reviewedPlan: AssistPlan, expected: AssistancePage, include: string[], edits: Record<string, string>, resume: string | null, remember: string[]): Promise<FillSummary> {
    const view = entry.view;
    const tab = await stage("tab", () => tabContext(true, entry.auto ? entry.id : undefined), value => pagePath(value.url) ?? "");
    const documentId = await stage("inject", () => inject(entry, tab.url));
    const current = await stage("page-rescan", () => page<AssistancePage>(entry, documentId, tab.url, "scan"), value => `${value.snapshot.fields.length} questions`);
    await stage("compare-page", async () => {
      if (current.fingerprint === expected.fingerprint && reviewedPlan.pageFingerprint === current.fingerprint) return;
      const difference = pageDifference(expected, current);
      view.page = current; view.plan = undefined;
      throw new Error(`The page changed after you reviewed the plan (${difference}). Plan answers again before filling.`);
    }, () => "page matches the reviewed plan");
    await exact(entry, tab.url);
    view.activity = "Filling this page…";
    const grant = await service<AssistanceGrant>("service-grant", "/api/extension/assist/grant", { id: reviewedPlan.recordId, page: current, planHash: reviewedPlan.planHash,
      include, edits, resume, confirm: true },
      value => `${Object.keys(value.fields).length} fields${value.resume ? " + resume" : ""}`);
    entry.pending = { id: reviewedPlan.recordId, grantId: grant.id };
    await persist();
    let result: AssistanceFillResult & { selected?: Record<string, string> };
    try {
      result = await stage("page-fill", () => page<AssistanceFillResult & { selected?: Record<string, string> }>(entry, documentId, tab.url, "fill", { grant }),
        value => `${value.filled.length} filled, ${value.preserved.length} kept, ${value.errors.length} errors, ${value.skipped.length} skipped, ${value.newFields} new`);
    } catch (error) { result = { filled: [], preserved: [], skipped: [], errors: [], newFields: 0, blockers: [messageOf(error), "Inspect actual fields yourself before any further action."] }; }
    const reported = await service<{ record: AssistanceRecord; repairs: AssistRepair[] }>("service-report", "/api/extension/assist/report", { id: reviewedPlan.recordId, grantId: grant.id,
      filled: result.filled, preserved: result.preserved, skipped: result.skipped, errors: result.errors, newFields: result.newFields,
      blockers: result.blockers, selected: result.selected ?? {} }, value => `status ${value.record.status}, ${value.repairs.length} fixes`);
    entry.pending = undefined;
    await persist();
    const label = (key: string) => reviewedPlan.items.find(item => item.key === key)?.label ?? (key === reviewedPlan.resume?.key ? "Resume" : key);
    let remembered = 0, rememberError = "";
    const items = remember.map(key => ({ key, value: edits[key] ?? reviewedPlan.items.find(item => item.key === key)?.value ?? "" }))
      .filter(item => item.value.trim() && result.filled.includes(item.key));
    if (items.length) {
      await nonFatal("remember", async () => {
        try { remembered = (await service<{ remembered: number }>("service-remember", "/api/extension/assist/remember", { id: reviewedPlan.recordId, page: current, items, confirm: true })).remembered; }
        catch (error) { rememberError = ` Answers were not remembered: ${messageOf(error)}`; throw error; }
      });
    }
    view.result = { url: tab.url, at: new Date().toISOString(), filled: result.filled.length, preserved: result.preserved.length,
      errors: result.errors.map(error => ({ label: label(error.key), message: error.message })), skipped: result.skipped.map(item => ({ label: label(item.key), reason: item.reason })),
      newFields: result.newFields, repairs: reported.repairs.length, remembered, blockers: result.blockers };
    view.activity = "Checking the page after filling…";
    if (!await nonFatal("replan-after-fill", () => plan(entry, entry.useAi))) { view.plan = undefined; await nonFatal("rescan-after-fill", () => scan(entry)); }
    view.message = `Filled ${result.filled.length}; kept ${result.preserved.length} existing answer${result.preserved.length === 1 ? "" : "s"}.`
      + (result.errors.length ? ` ${result.errors.length} need${result.errors.length === 1 ? "s" : ""} attention${reported.repairs.length ? "; suggested fixes are in the refreshed plan" : ""}.` : "")
      + (result.newFields ? ` ${result.newFields} new question${result.newFields === 1 ? "" : "s"} appeared.` : "")
      + (entry.auto ? "" : " Review the page, click Next or Submit yourself, then plan again on the next page. Filled is not applied.") + rememberError;
    view.activity = undefined;
    if (!entry.auto && (result.errors.length || result.skipped.length || result.blockers.length)) await notice(entry, view.message);
    return view.result!;
  }
  /** One click: plan, fill every ready answer and the resume for this role, then fill questions that appear, up to three passes. */
  async function quickFill(entry: TabSession, ai: boolean): Promise<{ filled: number; drafted: number; errors: FillSummary["errors"] }> {
    await plan(entry, ai);
    const view = entry.view;
    let filled = 0, passes = 0, drafted = 0;
    const errors: FillSummary["errors"] = [];
    while (view.plan && view.page && passes < 3) {
      const current = view.plan;
      const include = current.items.filter(item => item.include && item.value !== undefined).map(item => item.key);
      const resume = current.resume?.selected ?? null;
      if (!include.length && !resume) break;
      passes++;
      step("worker", "quick-fill", `pass ${passes}: ${include.length} answers${resume ? " + resume" : ""}`);
      drafted += current.items.filter(item => include.includes(item.key) && item.source.startsWith("ai_")).length;
      const result = await fillReviewed(entry, current, view.page, include, {}, resume, []);
      filled += result.filled; errors.push(...result.errors);
      if (!result.newFields) break;
    }
    const needs = view.plan?.items.filter(item => item.source === "manual" && item.required && !/^Already answered/.test(item.reason ?? "")) ?? [];
    if (!entry.auto) view.message = !passes ? `Nothing could be filled automatically${needs.length ? `; ${needs.length} required question${needs.length === 1 ? "" : "s"} need you (below)` : ""}. Answer on the page, then click Submit yourself.`
      : `Filled ${filled} answer${filled === 1 ? "" : "s"} in one pass${passes > 1 ? ` (+${passes - 1} for questions that appeared)` : ""}.`
        + (drafted ? ` ${drafted} ${drafted === 1 ? "is an AI suggestion" : "are AI suggestions"} from your facts: read ${drafted === 1 ? "it" : "them"} before submitting.` : "")
        + (errors.length ? ` ${errors.length} need${errors.length === 1 ? "s" : ""} attention: ${errors.slice(0, 3).map(item => item.label).join("; ")}.` : "")
        + (needs.length ? ` ${needs.length} required question${needs.length === 1 ? "" : "s"} need you: ${needs.slice(0, 3).map(item => item.label).join("; ")}.` : "")
        + " Check the page, solve any CAPTCHA, then click Submit yourself.";
    return { filled, drafted, errors };
  }
  /**
   * Application sites of your tracked companies, and which of them Chrome has not allowed yet. Asked only after you act
   * (plan, fill or start a session), at most every 10 minutes: opening the panel or scanning a page never contacts the service.
   */
  let sitesAskedAt = 0;
  async function refreshSites(force = false): Promise<void> {
    if (!force && Date.now() - sitesAskedAt < 10 * 60_000) return;
    sitesAskedAt = Date.now();
    try {
      const { origins } = await api<{ origins: string[] }>("/api/extension/assist/sites", {});
      const granted = new Set((await chrome.permissions.getAll()).origins ?? []);
      sites = { origins, missing: origins.filter(origin => !granted.has(origin)), at: Date.now() };
    } catch { /* Unpaired or offline: the button stays hidden. */ }
  }

  // ---------- Application sessions: 10 tabs at a time, each filled step by step up to your final review ----------
  function adopt(result: ServiceSession): void {
    const current = result.session;
    if (!current) { session = undefined; return; }
    const count = (state: string) => current.counts[state] ?? 0;
    session = { id: current.id, number: current.number, status: current.status, size: current.size, finished: current.finished, open: current.open,
      queued: count("queued"), submitted: count("submitted"), available: result.available,
      tabs: [...tabs.values()].filter(entry => entry.session && entry.job && current.items.some(item => item.jobId === entry.job!.jobId))
        .map(entry => ({ tabId: entry.id, jobId: entry.job!.jobId, company: entry.job!.company, title: entry.job!.title, stage: entry.stage, message: entry.view.message })) };
  }
  function overview(): SessionOverview | undefined {
    if (!session) return undefined;
    return { ...session, tabs: [...tabs.values()].filter(entry => entry.session && entry.job)
      .map(entry => ({ tabId: entry.id, jobId: entry.job!.jobId, company: entry.job!.company, title: entry.job!.title, stage: entry.stage, message: entry.view.message })) };
  }
  async function progress(entry: TabSession, state: "working" | "needs_you" | "review" | "closed" | "skipped" | "failed", detail: string): Promise<void> {
    if (!entry.job && !entry.recordId) return;
    try {
      // The application's stage is shown on Today and Progress; session roles also update their session.
      const result = entry.recordId && ["working", "needs_you", "review"].includes(state)
        ? await api<{ record: AssistanceRecord }>("/api/extension/assist/stage", { id: entry.recordId, stage: state, detail: detail.slice(0, 300) }).then(() => undefined)
        : entry.session && entry.job ? await api<ServiceSession>("/api/extension/assist/session/progress", { jobId: entry.job.jobId, state, detail: detail.slice(0, 300) }) : undefined;
      if (result) adopt(result);
    } catch (error) { step("worker", "session-progress", messageOf(error), false); }
  }
  /** Where a session tab stands; the badge and (optionally) a notification tell you when a tab waits for you. */
  async function settle(entry: TabSession, stageName: TabStage, message: string): Promise<void> {
    entry.slow = 0;
    const changed = entry.stage !== stageName || entry.view.message !== message;
    entry.stage = stageName; entry.view.message = message;
    await persist();
    if (!changed) return;
    if (stageName === "needs_you" || stageName === "review") {
      await chrome.action.setBadgeText({ tabId: entry.id, text: stageName === "review" ? "✓" : "!" }).catch(() => undefined);
      await notice(entry, message).catch(() => undefined);
    } else await chrome.action.setBadgeText({ tabId: entry.id, text: stageName === "submitted" ? "" : "…" }).catch(() => undefined);
    if (stageName === "working" || stageName === "needs_you" || stageName === "review") await progress(entry, stageName, message);
    if (stageName === "review") watchReview(entry);
  }
  async function openNext(): Promise<number> {
    if (opening) return 0;
    opening = true;
    try {
      const result = await api<ServiceSession & { open: { jobId: string; company: string; title: string; startUrl: string }[] }>("/api/extension/assist/session/next", {});
      const anyActive = (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
      let first = !(anyActive?.id !== undefined && tabs.get(anyActive.id)?.auto);
      const opened: number[] = [];
      for (const item of result.open) {
        const where = sessionWindow !== undefined ? { windowId: sessionWindow } : {};
        const created = await chrome.tabs.create({ url: item.startUrl, active: first, ...where }).catch(() => chrome.tabs.create({ url: item.startUrl, active: first }));
        if (!created?.id) continue;
        await keep(created.id);
        const entry = tabOf(created.id);
        Object.assign(entry, { auto: true, session: true, stage: "working", steps: 0, needs: [], job: { jobId: item.jobId, company: item.company, title: item.title }, recordId: undefined, lastAdvance: undefined, started: item.startUrl });
        entry.view.message = `Opening ${item.company}: ${item.title}. Sign in or complete a check if the site asks; Chairman fills the application and stops before Submit.`;
        opened.push(created.id); first = false;
      }
      if (opened.length && chrome.tabs.group) {
        try {
          const groupId = await chrome.tabs.group({ tabIds: opened as [number, ...number[]], ...(sessionWindow !== undefined ? { createProperties: { windowId: sessionWindow } } : {}) });
          await chrome.tabGroups?.update(groupId, { title: `Chairman · session ${result.session?.number ?? ""}`.trim(), color: "green" });
        } catch { /* Grouping is cosmetic. */ }
      }
      adopt(result);
      await persist();
      return opened.length;
    } finally { opening = false; }
  }
  async function reportOutcome(entry: TabSession, url: string, text: string): Promise<void> {
    if (!entry.recordId) {
      // Submitted before Chairman planned this tab: bind it to its role first so the proof is recorded against it.
      if (!entry.job) return;
      try { const planned = await api<AssistPlan>("/api/extension/assist/plan", { page: entry.view.page, ai: false, jobId: entry.job.jobId }); entry.recordId = planned.recordId; } catch { return; }
    }
    await service("service-outcome", "/api/extension/assist/outcome", { id: entry.recordId, url, text });
    await settle(entry, "submitted", `Applied ✓ The employer's page confirmed it: "${text.slice(0, 120)}". You can close this tab.`);
    if (entry.session) await openNext().catch(() => 0);
  }
  async function watchOutcome(entry: TabSession, documentId: string, url: string): Promise<boolean> {
    const navigation = await page<PageNavigation>(entry, documentId, url, "navigation");
    if (!navigation?.confirmation) return false;
    await reportOutcome(entry, url, navigation.confirmation);
    return true;
  }
  /** Answers you typed on the page for questions Chairman could not answer, remembered for the next form (ordinary questions only). */
  async function learn(entry: TabSession, documentId: string, url: string): Promise<void> {
    if (!entry.needs.length || !entry.recordId || !entry.view.page) return;
    const typed = await page<Record<string, string>>(entry, documentId, url, "read", { keys: entry.needs });
    const current = await page<AssistancePage>(entry, documentId, url, "scan");
    let remembered = 0;
    for (const [key, value] of Object.entries(typed ?? {})) {
      try { remembered += (await api<{ remembered: number }>("/api/extension/assist/remember", { id: entry.recordId, page: current, items: [{ key, value }], confirm: true })).remembered; }
      catch { /* Sensitive or unusual questions are never remembered. */ }
    }
    if (remembered) step("worker", "learn", `remembered ${remembered} answer${remembered === 1 ? "" : "s"} you typed`);
    entry.needs = [];
  }
  /**
   * One step of a session tab, run whenever its page loads or changes: record a confirmation, wait for your sign-in or
   * verification, press Apply on a job page, fill the step, then press Next. It stops for your review at the step with
   * Submit and never presses Submit.
   */
  async function drive(entry: TabSession): Promise<void> {
    if (!entry.auto || entry.stage === "paused" || entry.stage === "submitted" || !tabs.has(entry.id)) return;
    if (entry.lastAdvance && Date.now() - entry.lastAdvance.at < 1500) { schedule(entry, 1500); return; }
    begin(`session-step · ${entry.job?.company ?? "role"}`);
    try {
      const tab = await chrome.tabs.get?.(entry.id).catch(() => undefined);
      if (!tab?.url || tab.status !== "complete") return;
      let url: string;
      try { url = assistanceDestination(tab.url).href; } catch {
        await settle(entry, "needs_you", "Sign in or finish this step in the tab (Chairman does not read sign-in or account pages). It continues on the application form.");
        return;
      }
      if (!await chrome.permissions.contains({ origins: [assistancePermission(url)] })) {
        await settle(entry, "needs_you", `Allow Chairman on ${new URL(url).hostname}: click the Chairman icon in Chrome's toolbar while this tab is open. It continues right after.`);
        return;
      }
      const documentId = await stage("inject", () => inject(entry, url));
      const navigation = await stage("navigation", () => page<PageNavigation>(entry, documentId, url, "navigation"),
        value => `next "${value.next?.text ?? ""}", submit "${value.submit?.text ?? ""}", apply "${value.apply?.text ?? ""}", sign-in ${value.signIn}, ${value.fields} fields`);
      if (navigation.confirmation) { await reportOutcome(entry, url, navigation.confirmation); return; }
      if (entry.stage === "review") { watchReview(entry); return; }
      if (navigation.signIn) { await settle(entry, "needs_you", "Sign in or create your account in this tab. Chairman continues when the application form appears."); return; }
      let scanned: AssistancePage;
      try { scanned = await stage("page-scan", () => page<AssistancePage>(entry, documentId, url, "scan"), value => `${value.snapshot.fields.length} questions`); }
      catch (error) {
        const reason = messageOf(error);
        await settle(entry, "needs_you", /credential/i.test(reason) ? "Sign in in this tab. Chairman continues on the application form." : reason);
        return;
      }
      entry.view.page = scanned;
      if (scanned.snapshot.hasCaptcha) { await settle(entry, "needs_you", "Complete the verification check in this tab. Chairman continues right after."); return; }
      if (entry.steps >= MAX_STEPS) { await settle(entry, "needs_you", "Chairman has taken many steps in this application; continue it yourself."); return; }
      // A job description page (or a dialog asking how to start) starts the application first, even when the page has stray inputs.
      const openStart = !!navigation.apply && startChoice(navigation.apply.text);
      const startPage = !!navigation.apply && !navigation.submit && !navigation.next && (!!scanned.job || openStart);
      if (!scanned.snapshot.fields.length || startPage) {
        if (navigation.submit && !navigation.next) {
          await settle(entry, "review", `Ready for your review${navigation.step ? ` (${navigation.step})` : ""}: check the answers (use the form's Back button for earlier steps), then press "${navigation.submit.text}" yourself. Chairman records the confirmation page.`);
          return;
        }
        // A job you opened yourself: remember it, so its application pages get this role's resume and answers.
        if (scanned.job && !entry.job) await nonFatal("record-job", async () => {
          const recorded = await service<AssistPlan>("service-record-job", "/api/extension/assist/plan", { ...(entry.recordId ? { id: entry.recordId } : {}), page: scanned, ai: false },
            value => `application ${value.recordId.slice(0, 8)}`);
          entry.recordId = recorded.recordId; await persist();
        });
        // Job pages whose site has a direct application link (Workday /job/… pages, Lever, Ashby) open it straight away.
        const direct = applicationStartUrl(url);
        if (direct !== url && entry.started !== direct) {
          entry.started = direct;
          entry.steps++;
          await chrome.tabs.update(entry.id, { url: direct });
          await settle(entry, "working", new URL(direct).pathname.endsWith("/autofillWithResume")
            ? "Opening the application with Autofill with Resume. Sign in or create your account if Workday asks; Chairman uploads your resume and continues."
            : "Opening the application form…");
          return;
        }
        if (navigation.apply && (scanned.job || !navigation.next || openStart)) {
          const pressed = await stage("advance-apply", () => page<{ clicked: string; href?: string }>(entry, documentId, url, "advance", { which: "apply", expected: navigation.apply!.text }));
          entry.steps++;
          if (pressed.href) {
            try { assistanceDestination(pressed.href); await chrome.tabs.update(entry.id, { url: pressed.href }); }
            catch { await settle(entry, "needs_you", `Open the application yourself ("${pressed.clicked}"); Chairman continues on its form.`); return; }
          }
          await settle(entry, "working", `Pressed "${pressed.clicked}". Sign in if the site asks; Chairman continues on the form.`);
          schedule(entry, 4000);
          return;
        }
        if (navigation.next && !navigation.submit) {
          // A step without questions (for example a notice): press its Next once, and stop if the site does not move on.
          const key = `${scanned.fingerprint}|${navigation.step ?? ""}`;
          const repeated = entry.lastAdvance && entry.lastAdvance.fingerprint === key && Date.now() - entry.lastAdvance.at < 120_000;
          if (repeated && (navigation.errors.length || entry.lastAdvance!.repeats >= 1)) {
            await settle(entry, "needs_you", `The site did not move past this step${navigation.errors.length ? `: ${navigation.errors.slice(0, 2).join(" · ")}` : ""}. Fix it in the tab, then press "${navigation.next.text}" or Continue below.`);
            return;
          }
          const pressed = await stage("advance-next", () => page<{ clicked: string }>(entry, documentId, url, "advance", { which: "next", expected: navigation.next!.text }));
          entry.steps++;
          entry.lastAdvance = { fingerprint: key, text: pressed.clicked, at: Date.now(), repeats: repeated ? entry.lastAdvance!.repeats + 1 : 0 };
          const moved = await waitForChange(entry, documentId, url, scanned.fingerprint);
          await settle(entry, "working", `Pressed "${pressed.clicked}".`);
          schedule(entry, moved ? 800 : 2500);
          return;
        }
        if (scanned.embedded && await chrome.permissions.contains({ origins: [assistancePermission(scanned.embedded.url)] })) {
          entry.steps++; await chrome.tabs.update(entry.id, { url: scanned.embedded.url });
          await settle(entry, "working", `Opening the application form on ${scanned.embedded.host}…`); return;
        }
        await settle(entry, "needs_you", "Open the application form in this tab; Chairman continues there.");
        return;
      }
      // Fill this step: saved and derived answers, AI help for the rest, the resume for this role, then any questions that appear.
      entry.view.activity = "Filling this step…";
      const withResume = !!scanned.snapshot.fields.some(field => field.type === "file");
      const filled = await quickFill(entry, entry.useAi);
      entry.view.activity = undefined;
      if (withResume && filled.filled) await new Promise(resolveWait => setTimeout(resolveWait, 2500));
      const view = entry.view;
      const waiting = (view.plan?.items ?? []).filter(item => item.required && item.source === "manual" && !/^Already answered/.test(item.reason ?? "") && !view.page?.occupied.includes(item.key));
      if (waiting.length) {
        entry.needs = waiting.map(item => item.key);
        await settle(entry, "needs_you", `Answer ${waiting.length} question${waiting.length === 1 ? "" : "s"} in this tab or below: ${waiting.slice(0, 3).map(item => item.label).join("; ")}${waiting.length > 3 ? "; …" : ""}. Chairman remembers your answers and continues.`);
        return;
      }
      const after = await stage("navigation-after-fill", () => page<PageNavigation>(entry, documentId, url, "navigation"),
        value => `next "${value.next?.text ?? ""}", submit "${value.submit?.text ?? ""}", ${value.errors.length} errors`);
      const finalStep = !!after.submit && !after.next || /(?:^|[^a-z])review\b/i.test(after.step ?? "");
      if (finalStep) {
        await settle(entry, "review", `Ready for your review${after.step ? ` (${after.step})` : ""}: check every answer${filled.drafted ? `, especially the ${filled.drafted} AI-written one${filled.drafted === 1 ? "" : "s"}` : ""}, then click ${after.submit ? `"${after.submit.text}"` : "Submit"} yourself. Chairman records the confirmation page.`);
        return;
      }
      if (!after.next) { await settle(entry, "needs_you", "Chairman can't find this step's Next button. Continue to the next step yourself; it picks up from there."); return; }
      const fingerprint = view.page?.fingerprint ?? "";
      const repeated = entry.lastAdvance && entry.lastAdvance.fingerprint === fingerprint && Date.now() - entry.lastAdvance.at < 120_000;
      if (repeated && (after.errors.length || entry.lastAdvance!.repeats >= 1)) {
        await settle(entry, "needs_you", `The site did not move past this step${after.errors.length ? `: ${after.errors.slice(0, 2).join(" · ")}` : ""}. Fix it in the tab, then press "${after.next.text}" or Continue below.`);
        return;
      }
      await nonFatal("learn", () => learn(entry, documentId, url));
      const pressed = await stage("advance-next", () => page<{ clicked: string }>(entry, documentId, url, "advance", { which: "next", expected: after.next!.text }));
      entry.steps++;
      entry.lastAdvance = { fingerprint, text: pressed.clicked, at: Date.now(), repeats: repeated ? entry.lastAdvance!.repeats + 1 : 0 };
      const moved = await stage("wait-for-next-step", () => waitForChange(entry, documentId, url, fingerprint), value => value ? "the step changed" : "the page did not change");
      await settle(entry, "working", `Step ${entry.steps}: filled ${filled.filled} answer${filled.filled === 1 ? "" : "s"} and pressed "${pressed.clicked}".`);
      schedule(entry, moved ? 800 : 2500);
    } catch (error) {
      fail("session-step", error);
      // A background tab's page that answered too slowly (no fill was in progress) is simply asked again, a few times.
      if (tabs.has(entry.id) && /The page stopped responding/.test(messageOf(error)) && !entry.pending && (entry.slow ?? 0) < 3) {
        entry.slow = (entry.slow ?? 0) + 1;
        entry.view.message = "Waiting for this tab's page to respond (Chrome runs background tabs slowly)…";
        schedule(entry, 4000 * entry.slow);
      } else if (tabs.has(entry.id)) await settle(entry, "needs_you", `${messageOf(error)} Continue in the tab, or press Continue below to let Chairman try again.`).catch(() => undefined);
    } finally { entry.view.activity = undefined; finish(entry); }
  }
  /** Chrome's memory saver must not discard a tab Chairman is working through: it would reload and lose the step's answers. */
  const keep = (tabId: number) => chrome.tabs.update(tabId, { autoDiscardable: false }).then(() => undefined, () => undefined);
  const startChoice = (text: string) => /^(?:autofill|apply) with (?:my )?(?:resume|cv)$|^upload (?:my |your )?(?:resume|cv)$|^apply manually$|^use my last application$/i.test(text.trim());
  /** After pressing a button, waits until the step actually changes (new questions, new page) so it is never pressed twice. */
  async function waitForChange(entry: TabSession, documentId: string, url: string, fingerprint: string, timeout = 10_000): Promise<boolean> {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      await new Promise(resolve => setTimeout(resolve, 700));
      try {
        const current = await page<AssistancePage>(entry, documentId, url, "scan");
        if (current.fingerprint !== fingerprint) return true;
      } catch { return true; /* The page navigated away (or reloaded): the step changed. */ }
    }
    return false;
  }
  /** A tab waiting for your Submit is checked every few seconds for the employer's confirmation page (no service calls until it appears). */
  function watchReview(entry: TabSession): void {
    clearTimeout(entry.timer);
    entry.timer = setTimeout(() => {
      void exclusive(async () => {
        if (entry.stage !== "review" || !tabs.has(entry.id)) return;
        try {
          const tab = await chrome.tabs.get?.(entry.id).catch(() => undefined);
          if (tab?.url && tab.status === "complete") {
            const url = assistanceDestination(tab.url).href;
            if (await chrome.permissions.contains({ origins: [assistancePermission(url)] })) {
              const documentId = await inject(entry, url);
              if (await watchOutcome(entry, documentId, url)) return;
            }
          }
        } catch { /* Still reviewing, or on a page Chairman does not read. */ }
        if (entry.stage === "review" && tabs.has(entry.id)) watchReview(entry);
      }).catch(() => undefined);
    }, 4000);
  }
  function schedule(entry: TabSession, delay: number): void {
    if (!entry.auto) return;
    clearTimeout(entry.timer);
    entry.timer = setTimeout(() => { void exclusive(() => drive(entry)).catch(() => undefined); }, delay);
  }

  chrome.tabs.onActivated.addListener(activated => {
    void restored.then(() => {
      const entry = tabs.get(activated.tabId);
      if (entry?.auto) { if (entry.stage === "needs_you") schedule(entry, 400); return; }
      return scan(entry, true);
    }).catch(() => undefined);
  });
  chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
    void restored.then(() => {
      const entry = tabs.get(tabId);
      if (entry?.auto) { if (change.status === "complete" || change.url) schedule(entry, change.status === "complete" ? 900 : 2000); return; }
      if (tab.active && (change.status === "complete" || change.url)) return scan(tabOf(tabId), true);
    }).catch(() => undefined);
  });
  chrome.tabs.onRemoved?.addListener(tabId => {
    void restored.then(async () => {
      const entry = tabs.get(tabId);
      tabs.delete(tabId);
      if (entry?.session && entry.job && entry.stage !== "submitted") {
        await api<ServiceSession>("/api/extension/assist/session/progress", { jobId: entry.job.jobId, state: "closed", detail: "You closed the tab without submitting." }).then(adopt).catch(() => undefined);
        await openNext().catch(() => 0);
      }
      await persist();
    }).catch(() => undefined);
  });
  async function allowSite(permission: string): Promise<void> {
    const allowed = (await chrome.storage.local.get(SITES))[SITES] as string[] | undefined;
    if (!allowed?.includes(permission)) await chrome.storage.local.set({ [SITES]: [...new Set([...(allowed ?? []), permission])] });
  }
  chrome.action.onClicked.addListener(tab => {
    // A toolbar click is the user gesture that lets Chrome reveal this tab and show its standard site-access dialog.
    // Both calls run synchronously inside the gesture; nothing is read or filled until you allow and act in the panel.
    if (tab.windowId !== undefined) chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => undefined);
    let permission: string | undefined;
    try { permission = tab.url ? assistancePermission(tab.url) : undefined; } catch { permission = undefined; }
    if (!permission) return;
    const origin = permission;
    chrome.permissions.request({ origins: [origin] }).then(async granted => {
      const entry = tab.id !== undefined ? tabOf(tab.id) : undefined;
      if (!granted) { if (entry) entry.view.message = "Site access was not granted. Nothing was inspected or filled."; return; }
      await allowSite(origin);
      if (entry?.auto) { schedule(entry, 200); return; }
      if (entry) entry.view.message = `Chairman can read ${origin.slice(8, -2)}. Plan answers when you are ready.`;
      await scan(entry, true);
    }).catch(() => { if (tab.id !== undefined) tabOf(tab.id).view.message = "Click Allow on this site to let Chrome ask for access to this page."; });
  });
  chrome.permissions.onAdded.addListener(permissions => {
    // Access granted through Chrome's own request or site-access menu counts as allowing the site.
    const origins = (permissions.origins ?? []).filter(origin => /^https:\/\/[^*/]+\/\*$/.test(origin));
    if (!origins.length) return;
    void chrome.storage.local.get(SITES).then(async value => {
      const allowed = value[SITES] as string[] | undefined;
      await chrome.storage.local.set({ [SITES]: [...new Set([...(allowed ?? []), ...origins])] });
      for (const entry of tabs.values()) if (entry.auto && entry.stage === "needs_you") schedule(entry, 300);
      const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      const entry = active?.id !== undefined ? tabOf(active.id) : undefined;
      if (entry && !entry.auto) { entry.view.message = `Chairman can now read ${origins.map(origin => origin.slice(8, -2)).join(", ")}. Plan answers when you are ready.`; await scan(entry, true); }
    }).catch(() => undefined);
  });
  chrome.permissions.onRemoved.addListener(() => {
    for (const entry of tabs.values()) { entry.view.page = undefined; entry.view.plan = undefined; entry.view.review = undefined; entry.view.message = "Permissions changed. Allow and inspect the current site again."; }
  });
  chrome.runtime.onMessage.addListener((message: unknown, sender) => {
    // Content-script signal that questions appeared, disappeared or were answered; it can only trigger a bounded local rescan or the next session step.
    if (sender.id !== chrome.runtime.id || !sender.tab?.id || sender.frameId !== 0 || !message || typeof message !== "object"
      || (message as { channel?: unknown }).channel !== "chairman:page-changed") return;
    const tabId = sender.tab.id;
    void restored.then(async () => {
      const entry = tabs.get(tabId);
      if (entry?.auto) { if (entry.stage !== "paused" && entry.stage !== "submitted") schedule(entry, 1200); return; }
      const target = tabOf(tabId);
      if (Date.now() - target.lastPassive < 1500) return;
      target.lastPassive = Date.now();
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab?.id === tabId) await scan(target, true);
    }).catch(() => undefined);
  });
  chrome.runtime.onMessage.addListener((message: unknown, sender, respond) => {
    if (sender.id !== chrome.runtime.id || sender.tab || sender.url !== chrome.runtime.getURL("sidepanel.html") || !message || typeof message !== "object") return;
    const request = message as { channel?: string; action?: string; url?: string; company?: string; variantId?: string; mode?: string;
      factIds?: string[]; skills?: string[]; format?: string; confirmation?: string; submittedDate?: string; confirm?: boolean; ai?: boolean;
      planHash?: string; include?: string[]; edits?: Record<string, string>; resume?: string | null; remember?: string[]; verbose?: boolean; tabId?: number; windowId?: number; drive?: boolean };
    if (request.channel !== "chairman:panel") return;
    let entry: TabSession | undefined;
    const current = async (): Promise<TabSession> => {
      await restored;
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      entry = tab?.id !== undefined ? tabOf(tab.id) : entry ?? fresh(-1);
      return entry;
    };
    const reply = (target: TabSession) => ({ state: { ...target.view, busy: target.view.busy || working > 0, sites, session: overview(),
      ...(target.auto ? { tab: { jobId: target.job?.jobId ?? "", company: target.job?.company ?? target.view.page?.job?.company ?? "", title: target.job?.title ?? target.view.page?.job?.title ?? target.view.page?.title ?? "this application",
        stage: target.stage, steps: target.steps, needs: target.needs, session: target.session } } : {}) } });
    (async () => {
      const target = await current();
      if (request.action === "state") return reply(target);
      if (request.action === "sites-allowed") { await refreshSites(true); await scan(target, true).catch(() => undefined); return reply(target); }
      if (request.action === "debug") {
        debug.verbose = request.verbose === true;
        await chrome.storage.local.set({ [VERBOSE]: debug.verbose });
        return reply(target);
      }
      if (request.action === "debug-clear") { debug.runs = []; return reply(target); }
      if (request.action === "go-to-tab" && typeof request.tabId === "number" && tabs.get(request.tabId)?.auto) {
        await chrome.tabs.update(request.tabId, { active: true }); return reply(tabs.get(request.tabId)!);
      }
      if (legacyBusy()) throw new Error("Another extension action is running.");
      if (target.view.busy) throw new Error("Chairman is already working on this tab.");
      target.view.busy = true;
      try {
        return await exclusive(async () => {
          begin(request.action ?? "unknown");
          try {
            const result = await panelAction(target, request);
            return result ?? reply(target);
          } catch (error) {
            step("worker", "error", messageOf(error), false);
            finish(target, error);
            throw error;
          } finally { finish(target); }
        });
      } finally { target.view.busy = false; target.view.activity = undefined; }
    })().then(result => respond({ ok: true, ...result }), (error: unknown) => {
      const target = entry;
      void notice(target && !target.auto ? target : undefined, messageOf(error)).catch(() => { if (target) target.view.message = messageOf(error); });
      respond({ ok: false, error: messageOf(error), ...(target ? reply(target) : {}) });
    });
    return true;
  });
  async function panelAction(target: TabSession, request: { action?: string; url?: string; company?: string; variantId?: string; mode?: string; factIds?: string[];
    skills?: string[]; format?: string; confirmation?: string; submittedDate?: string; confirm?: boolean; ai?: boolean; planHash?: string; include?: string[];
    edits?: Record<string, string>; resume?: string | null; remember?: string[]; windowId?: number; drive?: boolean }): Promise<Record<string, unknown> | undefined> {
    const view = target.view;
    if (request.action === "home") { await chrome.tabs.create({ url: `${await apiOrigin()}/#today` }); return undefined; }
    if (request.action === "session-start") {
      sessionWindow = request.windowId ?? sessionWindow;
      const started = await service<ServiceSession>("service-session-start", "/api/extension/assist/session/start", {});
      adopt(started);
      await refreshSites(true);
      const opened = await stage("open-tabs", () => openNext(), value => `${value} tabs opened`);
      view.message = opened ? `Session ${session?.number ?? ""} started: ${opened} tab${opened === 1 ? "" : "s"} opened. Sign in or solve checks where asked; Chairman fills each application and stops before Submit.`
        : session?.open ? "Your session's tabs are already open." : "No roles to open. Rebuild today's list in the dashboard.";
      return undefined;
    }
    if (request.action === "session-next") { const opened = await openNext(); view.message = opened ? `Opened ${opened} more role${opened === 1 ? "" : "s"}.` : "No more tabs can open yet: 10 are open, or the session is finished."; return undefined; }
    if (request.action === "session-stop") {
      adopt(await service<ServiceSession>("service-session-stop", "/api/extension/assist/session/stop", {}));
      for (const entry of tabs.values()) if (entry.auto && entry.stage !== "submitted") { entry.stage = "paused"; entry.view.message = "Session stopped. This tab is yours to finish or close."; }
      await persist();
      view.message = "Session stopped. Open tabs stay open; nothing more is filled automatically.";
      return undefined;
    }
    if (request.action === "tab-continue") {
      if (!target.auto) throw new Error("Chairman is not driving this tab. Use Fill everything to start.");
      if (target.stage === "submitted") throw new Error("This role is already applied.");
      target.stage = "working"; target.lastAdvance = undefined;
      view.message = "Continuing…";
      await persist();
      await drive(target);
      return undefined;
    }
    if (request.action === "tab-pause") { if (!target.auto) throw new Error("Chairman is not driving this tab."); await settle(target, "paused", "Paused. Chairman does nothing more here until you press Continue."); return undefined; }
    if (request.action === "tab-skip") {
      if (!target.session || !target.job) throw new Error("Only roles in your application session can be skipped here; close this tab instead.");
      target.stage = "paused";
      await api<ServiceSession>("/api/extension/assist/session/progress", { jobId: target.job.jobId, state: "skipped", detail: "You skipped it in the side panel." }).then(adopt);
      view.message = "Skipped. It will not be opened again in this session; close the tab when you like.";
      await persist();
      await openNext().catch(() => 0);
      return undefined;
    }
    if (request.action === "authorize") {
      const tab = await stage("tab", () => tabContext(), value => pagePath(value.url) ?? "");
      if (request.url !== tab.url) throw new Error("The tab changed during the permission request. Allow the current page again.");
      const permission = assistancePermission(tab.url);
      await allowSite(permission);
      step("worker", "site-allowed", permission);
      await scan(target); return undefined;
    }
    if (request.action === "scan") { await scan(target); return undefined; }
    if (request.action === "recover") { await recover(target); await scan(target); view.message = "Interrupted fill marked for manual review. Inspect the actual page."; return undefined; }
    if (request.action === "open-embedded") {
      const embedded = view.page?.embedded, tab = await stage("tab", () => tabContext());
      if (!embedded || view.page?.url !== tab.url) throw new Error("Rescan the page first.");
      if (!await chrome.permissions.contains({ origins: [assistancePermission(embedded.url)] })) throw new Error(`Allow Chairman on ${embedded.host} first.`);
      await allowSite(assistancePermission(embedded.url));
      await chrome.tabs.update(tab.id, { url: embedded.url });
      step("worker", "open-embedded", embedded.host);
      view.page = undefined; view.plan = undefined;
      view.message = `Opening the form on ${embedded.host}. Plan answers once it has loaded.`;
      return undefined;
    }
    if (target.pending || (await chrome.storage.session.get(PENDING))[PENDING]) throw new Error("An interrupted fill needs reconciliation. Use Reconcile fill under More.");
    if (request.action === "plan") { await plan(target, request.ai !== false); return undefined; }
    if (request.action === "fill") {
      const reviewedPlan = view.plan, expected = view.page;
      if (!reviewedPlan || !expected || request.confirm !== true || request.planHash !== reviewedPlan.planHash || !Array.isArray(request.include))
        throw new Error("Review the plan and confirm it before filling.");
      step("worker", "request", `${request.include.length} rows selected, ${Object.keys(request.edits ?? {}).length} edited, resume ${request.resume ? request.resume.split(":")[0] : "none"}, remember ${request.remember?.length ?? 0}`);
      await fillReviewed(target, reviewedPlan, expected, request.include, request.edits ?? {}, request.resume ?? null, request.remember ?? []);
      // In a session tab, answering the questions that needed you lets Chairman carry on to the next step.
      if (target.auto && target.stage === "needs_you") { target.stage = "working"; schedule(target, 800); }
      return undefined;
    }
    if (request.action === "quick-fill") {
      if (request.drive === true) {
        // From here Chairman works this tab step by step: Apply, each step's answers and Next, up to your final review.
        Object.assign(target, { auto: true, stage: "working", steps: 0, needs: [], lastAdvance: undefined, started: undefined, slow: 0, useAi: request.ai !== false });
        await keep(target.id);
        view.message = "Working through this application: filling each step and pressing Next. It stops before Submit for your review.";
        await persist();
        schedule(target, 50);
        return undefined;
      }
      await quickFill(target, request.ai !== false);
      return undefined;
    }
    if (request.action === "import") {
      if (!view.page || request.confirm !== true) throw new Error("Explicitly review and confirm this captured job before import.");
      const review = await service<Review>("service-import", "/api/extension/assist/import", { page: view.page, company: request.company || undefined, confirm: true });
      target.recordId = review.record.id; await persist(); await reviewed(target);
      view.message = "Job imported. Select a baseline, then prepare and review a job-specific resume.";
    } else if (request.action === "review") {
      if (request.confirm !== true) throw new Error("Confirm this page belongs to the same job.");
      await reviewed(target); view.message = "Review the tailored resume options for this job.";
    } else if (request.action === "prepare" || request.action === "edit") {
      if (!view.review || !view.page || request.confirm !== true) throw new Error("Import and review the job first.");
      const id = view.review.record.id;
      view.activity = "Preparing the job-specific resume…";
      try {
        await service(`service-${request.action}`, `/api/extension/assist/${request.action}`, { id, page: view.page, confirm: true,
          ...(request.action === "prepare" ? { variantId: request.variantId, mode: request.mode } : { factIds: request.factIds, skills: request.skills }) });
      } finally { view.activity = undefined; }
      await reviewed(target);
      if (view.plan && !await nonFatal("replan-with-new-resume", () => plan(target, target.useAi))) view.plan = undefined;
      view.message = "New immutable PDF/DOCX ready. It is now offered as the resume to attach in the plan.";
    } else if (request.action === "artifact") {
      if (!view.review || !["pdf", "docx"].includes(request.format ?? "")) throw new Error("Choose a prepared PDF or DOCX.");
      return { artifact: await service("service-artifact", "/api/extension/assist/artifact", { id: view.review.record.id, format: request.format }) };
    } else if (request.action === "queue" || request.action === "receipt") {
      const id = view.review?.record.id ?? view.plan?.recordId;
      if (!id || request.confirm !== true) throw new Error("Plan or review the tracked job first.");
      await service(`service-${request.action}`, `/api/extension/assist/${request.action}`, { id, confirm: true,
        ...(request.action === "receipt" ? { confirmation: request.confirmation, submittedDate: request.submittedDate } : {}) });
      if (view.review) await nonFatal("refresh-review", () => reviewed(target));
      view.message = request.action === "receipt" ? "Your explicit submission receipt is recorded." : "Sent to the separate local runner for evaluation under its own authorization. Chrome has not submitted.";
    } else throw new Error("Unknown assistance action.");
    return undefined;
  }
  // The local dashboard asks the paired extension to open the session's tabs in the window you started it from.
  chrome.runtime.onMessageExternal?.addListener((message: unknown, sender, respond) => {
    (async () => {
      await restored;
      const origin = await apiOrigin();
      if (sender.origin !== origin || !message || typeof message !== "object" || (message as { channel?: unknown }).channel !== "chairman:session")
        throw new Error("Only your paired Chairman dashboard can start a session.");
      const action = (message as { action?: unknown }).action;
      if (action === "status") return { ok: true, session: overview() };
      if (action === "open-job") {
        // One role from the dashboard, in its own tab: Chairman starts the application and works through it to Review.
        const jobId = (message as { jobId?: unknown }).jobId;
        if (typeof jobId !== "string" || !jobId || jobId.length > 300) throw new Error("Unknown role.");
        const item = await api<{ jobId: string; company: string; title: string; startUrl: string }>("/api/extension/assist/job-start", { jobId });
        assistanceDestination(item.startUrl);
        const where = sender.tab?.windowId !== undefined ? { windowId: sender.tab.windowId } : {};
        const created = await chrome.tabs.create({ url: item.startUrl, active: true, ...where });
        if (created.id === undefined) throw new Error("Chrome did not open the tab.");
        await keep(created.id);
        const entry = tabOf(created.id);
        const ai = (await chrome.storage.local.get(AI_SETTING))[AI_SETTING] !== false;
        Object.assign(entry, { auto: true, session: false, stage: "working", steps: 0, needs: [], job: { jobId: item.jobId, company: item.company, title: item.title },
          recordId: undefined, lastAdvance: undefined, started: item.startUrl, useAi: ai });
        entry.view.message = `Opening ${item.company}: ${item.title}. Sign in or complete a check if the site asks; Chairman fills each step and stops before Submit.`;
        await persist();
        if (sender.tab?.windowId !== undefined) chrome.sidePanel.open?.({ windowId: sender.tab.windowId }).catch(() => undefined);
        return { ok: true, opened: 1 };
      }
      if (action !== "open") throw new Error("Unknown session request.");
      if (sender.tab?.windowId !== undefined) sessionWindow = sender.tab.windowId;
      await refreshSites(true);
      const opened = await openNext();
      if (sender.tab?.windowId !== undefined) chrome.sidePanel.open?.({ windowId: sender.tab.windowId }).catch(() => undefined);
      return { ok: true, opened, missingSites: sites?.missing.length ?? 0, session: overview() };
    })().then(respond, (error: unknown) => respond({ ok: false, error: messageOf(error) }));
    return true;
  });
  chrome.runtime.onMessage.addListener((message: unknown, sender, respond) => {
    // The page script's waits (Chrome throttles timers in background tabs, not this service worker's): answer after the wait.
    if (sender.id !== chrome.runtime.id || !sender.tab || !message || typeof message !== "object" || (message as { channel?: unknown }).channel !== "chairman:tick") return;
    const milliseconds = Math.min(Math.max(Number((message as { ms?: unknown }).ms) || 0, 0), 2000);
    setTimeout(() => respond({ ok: true }), milliseconds);
    return true;
  });
  return { busy: () => working > 0 };
}
