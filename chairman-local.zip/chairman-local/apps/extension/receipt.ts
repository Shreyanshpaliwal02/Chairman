// Self-contained because Chrome serializes this function into the authorized top-level receipt document.
export function readFixtureReceipt(approvedUrl: string, suppliedDocument?: Document): string | undefined {
  const doc = suppliedDocument ?? document;
  const approved = new URL(approvedUrl);
  const current = new URL(doc.location.href);
  if (approved.protocol !== "http:" || approved.hostname !== "127.0.0.1" || Number(approved.port) < 1024 || approved.pathname !== "/fixture/application" ||
      approved.username || approved.password || approved.hash ||
      current.origin !== approved.origin || current.pathname !== "/fixture/confirmation" || current.hash ||
      current.username || current.password || doc.defaultView?.top !== doc.defaultView) return undefined;
  const params = [...current.searchParams.entries()];
  if (params.length !== 1 || params[0][0] !== "id" || !/^[A-Za-z0-9_-]{1,100}$/.test(params[0][1])) return undefined;
  const markers = doc.querySelectorAll('main[data-jaa-submitted="true"][data-confirmation-id]');
  if (markers.length !== 1) return undefined;
  const marker = markers[0];
  const style = doc.defaultView!.getComputedStyle(marker);
  if (marker.getAttribute("data-confirmation-id") !== params[0][1] ||
      marker.closest('[hidden], [inert], [aria-hidden="true"]') ||
      style.display === "none" || style.visibility === "hidden" || !marker.getClientRects().length) return undefined;
  return `Controlled fixture receipt: ${params[0][1]}`;
}
