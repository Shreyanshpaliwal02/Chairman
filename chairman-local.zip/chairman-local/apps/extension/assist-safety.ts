import { destination, isFixture } from "./safety";

// Greenhouse's embedded application form names its public numeric job id `token`; nothing else is exempt.
function publicJobToken(url: URL, key: string, value: string): boolean {
  return key === "token" && /^\d{1,20}$/.test(value) && ["boards.greenhouse.io", "job-boards.greenhouse.io"].includes(url.hostname.toLowerCase())
    && url.pathname === "/embed/job_app";
}

export function assistanceDestination(raw: string): URL {
  const url = new URL(raw);
  const hash = url.hash;
  url.hash = "";
  destination(url.href);
  const host = url.hostname.toLowerCase();
  if (/(^|\.)indeed\.[a-z.]+$/.test(host) || host === "indeed.jobs" || host.endsWith(".indeed.jobs"))
    throw new Error("Indeed is manual-only; Chairman does not inspect or automate it.");
  if (/(?:^|\/)(?:login|signin|sign-in|auth|oauth|account|accounts|register|signup)(?:\/|$)/i.test(url.pathname))
    throw new Error("Account and sign-in pages are manual-only. Sign in yourself, then return to the public application.");
  if ([...url.searchParams.entries()].some(([key, value]) => /password|secret|token|code|session|auth|email/i.test(key) && !publicJobToken(url, key, value)))
    throw new Error("Pages with credential/session parameters cannot be inspected. Open the public job URL.");
  if (!isFixture(url.href) && /(^|\.)indeed\./.test(host)) throw new Error("This platform is manual-only.");
  url.hash = hash;
  return url;
}

export function assistancePermission(raw: string): string {
  const url = assistanceDestination(raw);
  return `${url.protocol}//${url.hostname}/*`;
}
