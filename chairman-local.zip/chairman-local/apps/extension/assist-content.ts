/// <reference types="chrome" />
import { advance, fillAssistancePage, inspectAssistancePage, inspectNavigation, readAnswers, startTrace, takeTrace, useTicker } from "./assist-page";
import { assistanceDestination } from "./assist-safety";
import type { AssistanceGrant } from "../../packages/domain/extension-assist";

const state = globalThis as typeof globalThis & { __chairmanAssistInstalled?: boolean };
const controlCount = () => document.querySelectorAll('input,select,textarea,[role="combobox"],[role="radiogroup"],button[aria-haspopup="listbox"]').length;
/** False once the extension was reloaded, updated or removed: this copy of the script can no longer reach it. */
const connected = () => { try { return !!chrome.runtime?.id; } catch { return false; } };
try {
  assistanceDestination(location.href);
  if (window.top === window && !state.__chairmanAssistInstalled) {
    state.__chairmanAssistInstalled = true;
    // Waits are timed by the extension's service worker: Chrome would stall this page's own timers while the tab is in the background.
    useTicker(milliseconds => chrome.runtime.sendMessage({ channel: "chairman:tick", ms: milliseconds }).then(() => undefined));
    let busy = false, count = controlCount(), timer: ReturnType<typeof setTimeout> | undefined;
    chrome.runtime.onMessage.addListener((message: unknown, sender, respond) => {
      if (sender.id !== chrome.runtime.id || sender.tab || !message || typeof message !== "object") return;
      const request = message as { channel?: string; action?: string; grant?: AssistanceGrant; debug?: boolean; which?: "next" | "apply"; expected?: string; keys?: string[] };
      if (request.channel !== "chairman:page") return;
      if (busy) { respond({ ok: false, error: "Another page operation is running." }); return; }
      busy = true;
      startTrace(request.debug === true);
      (async () => {
        if (request.action === "scan") return inspectAssistancePage(document);
        if (request.action === "fill" && request.grant) return fillAssistancePage(document, request.grant);
        if (request.action === "navigation") return inspectNavigation(document);
        if (request.action === "advance" && (request.which === "next" || request.which === "apply") && typeof request.expected === "string") return advance(document, request.which, request.expected);
        if (request.action === "read" && Array.isArray(request.keys)) return readAnswers(document, request.keys.filter((key): key is string => typeof key === "string"));
        throw new Error("Unsupported page action. Page scripts cannot command Chairman.");
      })().then(result => respond({ ok: true, result, trace: takeTrace() }), (error: unknown) =>
        respond({ ok: false, error: error instanceof Error ? error.message : "Page operation failed.", trace: takeTrace() }))
        .finally(() => { busy = false; count = controlCount(); });
      return true;
    });
    // Tell the extension (never the page) when questions appear or disappear, e.g. after you click Next in a single-page form.
    // It only triggers a local rescan; nothing is sent to the local service or filled.
    const observer = new MutationObserver(() => {
      // A page left open while the extension reloads keeps this old copy; it stops quietly instead of throwing.
      if (!connected()) { observer.disconnect(); clearTimeout(timer); return; }
      if (busy) return;
      clearTimeout(timer);
      timer = setTimeout(() => {
        const next = controlCount();
        if (next === count || busy) return;
        count = next;
        if (!connected()) { observer.disconnect(); return; }
        try { chrome.runtime.sendMessage({ channel: "chairman:page-changed" }).catch(() => { /* The worker may be restarting. */ }); }
        catch { observer.disconnect(); }
      }, 800);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    // An answer you give on the page (a choice, or text you leave) lets a waiting application tab continue. No value is sent.
    let answered: ReturnType<typeof setTimeout> | undefined;
    document.addEventListener("change", () => {
      if (busy) return;
      clearTimeout(answered);
      answered = setTimeout(() => {
        if (!connected()) return;
        try { chrome.runtime.sendMessage({ channel: "chairman:page-changed" }).catch(() => { /* The worker may be restarting. */ }); } catch { /* Extension reloaded. */ }
      }, 1500);
    }, true);
  }
} catch {
  // Restricted destinations receive no listener or DOM inspection.
}
