/// <reference types="chrome" />
import type { PageCommand } from "./contracts";
import { handlePageCommand } from "./form";
import { destination } from "./safety";

const state = globalThis as typeof globalThis & { __jaaContentInstalled?: boolean };
try {
  destination(location.href);
  if (window.top === window && !state.__jaaContentInstalled) {
    state.__jaaContentInstalled = true;
    let busy = false;
    chrome.runtime.onMessage.addListener((message: unknown, sender, respond) => {
      if (sender.id !== chrome.runtime.id || sender.tab || !message || typeof message !== "object" ||
          (message as { channel?: unknown }).channel !== "jaa:page") return;
      const command = (message as { command: PageCommand }).command;
      if (!command || !["snapshot", "fill", "attach", "verify", "submit"].includes(command.action) || typeof command.url !== "string") {
        respond({ ok: false, error: "Invalid page operation." });
        return;
      }
      if (busy) {
        respond({ ok: false, error: "Another page operation is active." });
        return;
      }
      busy = true;
      handlePageCommand(document, command).then(
        (result) => respond({ ok: true, result }),
        (error: unknown) => respond({ ok: false, error: error instanceof Error ? error.message : "The page operation failed." })
      ).finally(() => { busy = false; });
      return true;
    });
  }
} catch {
  // A restricted or redirected page receives no listener and no DOM inspection.
}
