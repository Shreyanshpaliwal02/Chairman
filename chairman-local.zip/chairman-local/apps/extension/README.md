# Chairman for Chrome

Chairman is a Manifest V3 extension for **page-assisted filling**: open any company application form, let Chairman plan answers from your confirmed profile, review them in the side panel, and fill the page with one click. With **Continue through every step** on, it also starts the application from a job page and presses Next / Save and Continue after each step, up to the review step. **It never presses Submit.** Importing a job description and tailoring a resume are optional extras under **More**. A separate, unchanged controlled-fixture workflow remains available for development.

LinkedIn (including `lnkd.in`), Indeed (including regional domains), Wellfound/AngelList and Naukri are always blocked, including their subdomains and pages opened by the user. Sign-in/account pages, credential/session query URLs, and pages with a visible password form are not inspected. A supplied URL is not permission to automate; neither site grants nor preparing a resume authorize submission. No stealth, CAPTCHA bypass, anti-bot evasion or no-AI-rule bypass is provided.

**This extension is optional and complements the homepage.** Use the homepage's Auto Apply and dedicated local
Chrome runner for separately authorized supported company applications. Installing or pairing this
extension does not activate applications, sign into job sites, or grant hosted AI
consent.

## Load and pair

1. Extract `job-application-assistant-extension.zip` if you downloaded it. This ZIP already contains the built extension; no build or Node.js installation is needed just to load it. From a source checkout instead, use the project's installed dependencies and run `node scripts/build-extension.mjs`.
2. In regular Google Chrome 120+, enter `chrome://extensions` in the address bar, enable **Developer mode**, and choose **Load unpacked**. Select the extracted `job-application-assistant-extension` folder that directly contains `manifest.json`, not the ZIP or its parent Downloads folder. From a source checkout, select `dist/extension`.
3. Open the running local service at `http://127.0.0.1:4318`. In **Setup > Browser extension**, click **Create pairing token**. If the dashboard is already open, do not start a second service on the same port.
4. Click the extension's toolbar action. Paste the local service's pairing token into the side panel and choose **Pair local service**. If using `JAA_PORT`, enter that same port (1024–65535). The host is always `127.0.0.1`; a remote API host cannot be configured.

## Fill a page

1. Open a company application form in ordinary Chrome and click the **Chairman icon in Chrome's toolbar** while that tab is open. The click opens the side panel and Chrome asks once to allow Chairman on that exact host, never every site; choose **Allow**. (Chrome hides a site's pages from extensions until you allow it, so the side panel's **Allow on this site** button can only ask after that toolbar click has revealed the tab.) Afterwards Chairman inspects that site's pages locally when you open them (no browser history, cookies or current field values are read, and nothing is sent anywhere just by visiting).
2. Choose **Fill everything** to plan and fill in one click (saved answers, remembered answers, checked AI suggestions and the resume for this role, then any questions that appear), or **Plan answers for this page** to review each row first.
   With **Continue through every step automatically** ticked (the default), Fill everything works through the whole application in that tab: on a job page it opens the application (Workday: straight to **Autofill with Resume**; in Workday's "Start Your Application" dialog it picks Autofill with Resume), uploads the resume for this role (it recognizes Workday's hidden "Upload a file" input under **Resume/CV** and keeps a file Workday already lists), fills each step and presses **Next**, **Continue** or **Save and Continue**, until the step with **Submit** (for example Workday's Review). It waits for you on sign-in, verification checks and questions it has no answer for, then carries on once you have answered on the page. It never presses Submit. Untick it to fill only the current page.
   **Allow on all company sites** (shown after your first plan or fill) asks Chrome once for every application site of your tracked companies, so roles opened from the homepage's **Today** list fill without a per-site prompt.
   Plan answers for this page: Chairman sends the page's *structure* (question labels, field types and options, never what is typed on the page) to the local service, which proposes an answer per question:
   - **Profile / Saved answer**: your confirmed contact details, links, answers (homepage → Profile → *Standard application questions*, which recognizes many wordings of each question) and facts (current employer, school, degree), matched by the question, the site's `autocomplete` attribute, or saved link names. Questions with no saved answer are collected under *Questions from real forms* so you can answer them once.
   - **Remembered**: an answer you chose to remember for that exact question on an earlier form.
   - **AI-matched saved answer / AI choice / AI draft** (highlighted): see *AI help* below.
   - **Suggested fix**: a reviewed correction after the site rejected a value.
   - **Needs you**: nothing trustworthy is known. Type an answer in the panel (and optionally remember it) or answer on the page.
3. Review every row. Untick anything you do not want filled and edit any value; edited rows can be remembered for the same exact question on future forms. Pick the resume to attach: a job-specific packet prepared under **More** is preferred, otherwise the approved original that best matches the job (only formats the upload accepts are listed).
4. Tick the confirmation and choose **Fill this page (never submits)**. Only ticked rows are filled; anything already on the page (including anything you typed after planning) is kept. Chairman then rescans, reports what it filled, what the site rejected and any new questions that appeared, and refreshes the plan with suggested fixes.
5. Without **Continue through every step**, check the page, click **Next** yourself, and plan the next page (the panel notices new questions on single-page forms). Click the final **Submit** yourself. A fill is tracked as filled/manual-required, **not applied**. Record an actual receipt under **More** only after a real submission.

Every fill needs your fresh confirmation, bound to the exact URL, the page's structural fingerprint and the reviewed plan's hash. The budget is 30 authorized fills per tracked application. **Queue for separate local Auto Apply** (under More) hands an unfilled job to the dedicated runner under that runner's existing standing authorization and rules; it does not submit from your current Chrome tab. Jobs owned by browser assistance cannot simultaneously be picked by the runner.

Use **Enable private alerts** to opt into notifications from a direct click. Without that permission, reasons remain in the side panel and toolbar badge. Notifications contain no job, resume or applicant details. **Open homepage / setup** opens the local setup view. A daily target such as 500 is an aspiration, not guaranteed volume or a reason to bypass controls.

The token is in `chrome.storage.session`, accessible only to trusted extension contexts, not a content script. It is not logged, kept in sync/local storage, or sent to employers. Session storage is not an encrypted secret vault and is cleared on browser restart/extension reload. Re-pair when needed. Site permissions persist until revoked in Chrome extension settings.

## Application sessions

Start a session from the dashboard's Today page (**Auto-apply top 50 in Chrome**) or from the side panel
(**Start a session**). The extension opens up to 10 roles at a time as tabs in that window and works each tab on
its own: it presses Apply on a job page, waits while you sign in or complete a check, fills every step, presses
Next, and stops before Submit (*Ready for your review*). The side panel lists the session's tabs with where each
stands (Filling, Needs you, Ready for your review, Applied ✓) and a **Go to tab** button; for the current tab it
offers **Continue automatically**, **Pause this tab** and **Skip this role**. After you submit, the employer's
confirmation page is recorded as the proof that you applied, and the next role opens.

## How pages are read

- **Application form, not the whole page.** Chairman scores forms and known ATS containers (Greenhouse, Ashby, Lever, Workable and similar) and fills only the best application form. Header search boxes, newsletter sign-ups, cookie banners and other page chrome are never touched.
- **Stable identity.** Each question gets a key derived from stable attributes (`id`, `name`, `data-*` field paths) or its label, never its position, so rescans, reloads and hidden inputs do not change keys. The page waits for single-page forms to finish rendering before reading them.
- **Questions and requiredness.** Labels come from ARIA, native labels, fieldset legends and the field's own container text (placeholders only as a fallback). Required fields are detected from `required`, `aria-required` and asterisks.
- **Controls.** Native text/email/tel/URL/number/date fields, textareas, single selects (placeholder options are ignored), native and ARIA radio groups, ARIA comboboxes including React-Select style typeaheads (Chairman opens the list, and selects only a unique exact or uniquely matching option), Yes/No button pairs (only explicit `type="button"` buttons are ever clicked) and styled upload widgets whose native file input is hidden.
- **Yours unless you switch it on.** Required consent and "I agree / acknowledge" boxes are ticked only when Profile → *Accept required acknowledgements* is on (optional marketing is then declined), shown as **Acknowledged for you** so you can untick them. Voluntary self-identification (gender, race/ethnicity, veteran, disability, pronouns) is filled only from your saved answers when *Fill my voluntary self-identification answers* is on. Credentials and ID numbers, signatures, criminal history, date of birth, multi-selects, rich-text editors and non-resume uploads are never filled. Chairman never presses Enter (implicit submission) or clicks Next/Submit.
- **CAPTCHA.** A passive invisible reCAPTCHA badge is not a challenge. A visible CAPTCHA widget is left for you to solve before you submit. An open challenge pauses filling. Nothing is ever solved or bypassed.
- **Embedded forms.** When the application form is an embedded ATS frame, Chairman offers **Open the form directly** (after you allow that host) instead of filling a frame blind. Controls inside shadow DOM or other frames are not read.
- **Verification.** Values are set through native setters with `input`/`change`/`blur` events for framework state, re-read after the page settles, and checked against the browser's own validity and `aria-invalid` messages. Conditional questions that appear mid-fill do not stop the remaining fields; they are reported for the next plan. Resume bytes are SHA-256 checked before and after attachment. Native file attachment proves attachment, not remote upload acceptance or application receipt.

## AI help for unknown questions and site errors

When **Ask my configured AI** is ticked, questions with no saved answer are sent to the AI configured in the homepage, in one batched request:

- **Providers.** Local Ollama, or GitHub Copilot with your explicit hosted-processing consent. Gemini mode is excluded because it only ever receives anonymous public tags. There is no provider or model fallback.
- **What is sent.** The questions (labels, options, hints), the job title/company/description, your confirmed facts and skills, and the *names* of your saved answer keys. Never your contact details, links, answer values, or anything typed on the page. Demographic, eligibility/immigration and background questions are never sent.
- **What comes back** is constrained by a strict JSON schema and then validated locally: an answer-key match is resolved from *your* saved value (with unit/currency checks); an option must be one of the listed options and cite your facts; a draft (for open questions such as "Why do you want to work here?") must cite your facts and may not contain numbers or technologies that are not in them, links, contact details, placeholders or instruction-like text. Anything else becomes **Needs you** with the reason.
- **Determinism.** Every validated outcome is cached by the question, job and facts, so the same form is always planned the same way, and authorizing a fill replays the reviewed plan from the cache without a new model call. Remembered answers make repeated questions fully deterministic without AI. Clear cached suggestions in the homepage (Profile → Application answers) if you want fresh ones.
- **Site errors.** After a fill, rejected values get format-only fixes where possible (phone number formats, `https://` for links, date patterns such as `MM/DD/YYYY`, plain numbers), a list of the site's own options for typeahead questions, or (for your AI drafts only) an AI-shortened version that adds no new facts. Fixes replace only a value Chairman itself filled and that is still unchanged; your own typing is never overwritten.
- If the posting restricts AI, no AI suggestions are made. AI drafts are proposals from your facts; edit them so they read as your own.

## Debugging a real page

Open **Debug: what happened, step by step** at the bottom of the side panel. Every action (allow, scan, plan, fill) is recorded as a run of named steps from three sources:

- **worker**: the extension's own stages, in order: `tab` (active tab and site permission), `inject` (page script), `page-scan`, `service-plan`, `page-rescan`, `compare-page`, `service-grant`, `page-fill`, `service-report`, then non-critical follow-ups such as `replan-after-fill`.
- **page**: what the page script saw and did: `settle` (how long the form took to render), `form-root` (which form was chosen, its score and how many candidate forms existed), one `field` line per question (label, control kind, required, options count, whether it already had a value), `manual-only` questions, `captcha`, `job`, and for fills one `fill` line per field plus `combobox-open/-search/-match/-verify`, `site-validation` and `fill-summary`.
- **service**: how the local service planned: which tracked application was used (`record`), saved-answer counts by source, questions without a saved answer, AI status and every AI decision (accepted or rejected, and why), resume options, and for fills `plan-check`, `include`, `result` and any suggested `fix`.

A failed step is marked ✗, and the error shown at the top names it, for example `Failed at step "compare-page": The page changed after you reviewed the plan (new question "Visa details"; "Country" changed (options))`. A plan that no longer matches at fill time is explained per question (`"Email" answer changed`) without revealing any value. **Copy debug report** copies the recorded runs as JSON for sharing; it contains labels, counts, timings and errors only, never your answers, contact details or files. Tick **verbose logs** to also mirror every step to the page's DevTools console (`[Chairman page]`) and the extension's service-worker console (`[Chairman worker]`, `[Chairman service]`). The local service prints the same service steps to its console when started with `JAA_DEBUG=1`.

## Testing with a demo applicant

`npm run demo` starts a separate **demo instance** on port 4319 with its own data folder (`<your data folder> Demo`) and a clearly fictional applicant (`demo.candidate@example.com`, two approved demo resumes, a demo answer bank and `JAA_DEBUG=1`). Your real workspace and data are never touched, and your normal service can keep running on 4318. Pair the extension to port 4319 (demo dashboard → Setup → Browser extension → Create pairing token), test on real career pages, and pair back to 4318 when you are done. Use `npm run demo -- --reset` to recreate the demo data. **Never submit the demo applicant to a real employer**; Chairman never clicks Submit, so stop at review.

## Tailoring (optional, under More)

On a job-description page, **Import captured job** records the actual JD (confirm the employer if it is not in public metadata). **Prepare job-specific PDF + DOCX** tailors a factual resume from an approved baseline; optional configured AI ranking uses existing homepage consent. Review the inline resume, open the hash-verified PDF/DOCX, and optionally select/reorder existing confirmed facts and JD-supported skills. **Save factual selection as new packet** regenerates immutable, content-addressed documents; it never rewrites your global profile, original templates or previous packet. The prepared packet then becomes the default resume in the fill plan. A packet whose profile or baseline changed is never offered.

## Installation troubleshooting

- If a download does not start inside an embedded preview, open the dashboard
  address in regular Chrome and download there. An embedded browser is not the
  Chrome extension manager.
- If Chrome reports a missing manifest, select the folder immediately containing
  `manifest.json`. Keep that folder on disk after loading; moving or deleting it
  breaks the extension.
- If your organization disables Developer mode or unpacked extensions, use the
  local dashboard instead. Do not bypass your organization's browser policy.
- If pairing fails after restarting the local service, create a new pairing token
  in Setup. Tokens are valid only for the current service process.

## Durable tracking and recovery

Short-lived one-use fill grants bind the tracked application, exact URL, page fingerprint, reviewed plan hash, the chosen fields and values, and the resume bytes. A durable fill intent is saved before any bytes are returned to the extension. The record keeps only SHA-256 hashes of what was filled (so a later fix can replace Chairman's own value), never the values. Revocation, expired grants, changed profiles, stale snapshots, service restarts and lost reports require review; they never create submitted counts or automatic retries. The homepage's assistance tracker retains source URL, packet, timestamps, actual fill state, blockers, notes and explicit user-reported receipts.

## Legacy controlled-fixture compatibility

- One visible, reviewed fixture multipart POST form in the top-level document; no embedded/cross-origin frames, shadow DOM, custom controls, assessments, multiple steps, CAPTCHA or legal/own-words/AI-prohibition declarations.
- Accessible labels and unique raw `name` keys, falling back to raw `id` only when name is absent. Duplicates and cross-field key collisions stop the flow.
- Standard text, email, telephone, URL, number, date, textarea and single select controls. Native prototype setters dispatch bubbling `input` and `change` events for controlled form state. Missing confirmed answers are never guessed, including optional questions.
- One clearly labelled resume file input. The backend-provided PDF/DOCX must match an approved artifact's SHA-256, byte length and filename. The extension verifies actual `File` bytes, name, MIME and the native form's serialized file payload after change events; merely assigning a `FileList` is not success. If a fixture provides a React/application upload-acknowledgement marker, that state must also match.
- Extra constraints (`pattern`, min/max, multi-value controls, etc.), disabled/read-only/hidden application controls, consent checkboxes, radios and additional form actions stop automation.
- Every step checks local Stop and packet state again. Conditional questions or other snapshot changes abort. Final field values, file acceptance, native validation and form snapshot are checked again before the unique labelled submit button is clicked.
- Only the local fixture has a reviewed receipt and upload-acceptance adapter. Explicit external per-employer server policy and `automationAllowed` permit inspection, but this extension still reports real-site forms unsupported until an employer-specific adapter is reviewed. A public Greenhouse/Ashby listing feed or permission to read a job is **not** permission or technical verification for automated submission.

Use the dashboard's approved downloads and manual checklist for unsupported sites. A paused flow can already have transmitted an approved field via autosave or an approved file via upload; it does not imply nothing reached the site.

## API and canonical hash

Real assistance additionally requires the exact paired extension Origin. Website content cannot command Chrome operations: only the extension's own side panel may command the worker, which injects in the isolated top-level document. No remote JavaScript is loaded.

Real assistance routes are additive under `/api/extension/assist/`: `plan`, `grant`, `report`, `remember`, `recover`, and the optional `import`, `review`, `prepare`, `edit`, `artifact`, `queue`, `receipt`. Each accepts strict validated input; arbitrary selectors and credentials are never accepted as a browser action plan. `plan` returns reviewable per-question proposals, resume choices and a `planHash`. `grant` recomputes the plan from local data and cached AI decisions only, requires the identical `planHash`, binds your included keys and edits (options must be listed; lengths and sensitive labels are enforced), persists intent, and returns the values plus the chosen hash-verified resume. `report` records actual filled controls and site errors (never values or a submitted receipt) and returns reviewed fixes. `remember` stores your answers for exact, non-sensitive questions. Dashboard-cookie routes `GET /api/assistance?limit=100&offset=0`, `POST /api/assistance/:id` (notes/manual status), `POST /api/assistance/:id/receipt`, `GET /api/assist-answers`, `POST /api/assist-answers/forget` and `POST /api/assist-answers/clear-ai` expose durable tracking and remembered answers. Shared types live in `packages/domain/extension-assist.ts`; deterministic matching and repair helpers shared by the page and service live in `packages/domain/assist-match.ts`.

The following legacy fixture API is unchanged.

All calls use `Authorization: Bearer <session token>` and omit cookies. No redirects are followed. The local backend must enforce the exact extension origin and its source policy, approval, lease, daily/source limits and Stop state.

| Endpoint | Contract |
| --- | --- |
| `POST /api/extension/connect` | `{}`; authenticate/pair the explicitly allowed extension origin. |
| `GET /api/extension/jobs` | `{items: [{packet, job, automationAllowed, reason?}], stopped: boolean}`. Missing Stop state fails closed. |
| `POST /api/extension/preflight` | `{packetId, snapshot}` → `{packet}`. Backend persists this **before** approval. |
| `POST /api/extension/claim` | `{packetId}` → `{packet, job, fields, resume: {base64,mime,filename}, runToken}`. Packet has status `executing` and preserves its approval hash. |
| `POST /api/extension/report` | `{packetId,runToken,outcome,confirmation?,error?}`; outcome is `submitted_confirmed`, `submission_unknown`, or `failed`. |

`fingerprint()` in `safety.ts` exports the exact canonical algorithm: lowercase SHA-256 of UTF-8 `JSON.stringify({url,fields,hasCaptcha,hasLegal,unsupported})`. Properties are emitted in that order. Each field is reconstructed in order `{key,label,type,required,options}`. Fields are in DOM/form-elements order; options are the configured values of enabled choices in DOM order; unsupported reasons are insertion-ordered and deduplicated. No sorting, Unicode normalization, whitespace or trailing newline is added. The fingerprint itself is excluded. Snapshots have exactly those five structural properties plus `fingerprint`; they never contain current input values, files, passwords, form HTML or body text.

## Controlled fixture protocol

The parent local service exposes `/fixture/application` only when explicitly started with `JAA_FIXTURE_MODE=1`. Tests use local-only fixtures, never synthetic applications on real websites.

- The application page is `/fixture/application`; its form posts multipart data to `/fixture/submit` on that **same paired loopback origin**. Fields are `full_name`, `email`, `phone`, `experience` (textarea), and `resume` (file). Its sole submit is a standard `<button>` labelled `Submit application` (also accepted: `Submit`, `Send application`, `Apply now`).
- File acceptance is verified through the actual input and native `FormData` bytes/name/type. React test fixtures may additionally expose a visible `#jaa-resume-accepted` with matching `data-filename` and `data-bytes`; an inconsistent marker blocks submission.
- After the backend accepts the POST, it redirects to `/fixture/confirmation?id=<receipt-id>` and renders a visible `<main data-jaa-submitted="true" data-confirmation-id="<receipt-id>">`. Only this marker on this exact paired fixture origin/path can confirm receipt, and its ID must match the URL. Body keywords such as “success” do not count.
- The worker can inspect only that expected top-level fixture confirmation document after the POST destroys the original content-script context. It never fills, clicks, or submits again during reconciliation. Other redirects—including an identical marker on an external host or another loopback port—remain unknown.
- A pre-existing receipt marker on the application form prevents a new click. No real site's marker is interpreted by this fixture adapter.

## Legacy fixture interruptions and Stop

Only one operation executes at a time. A pending claim/run (IDs and phase, not resume/answers) is stored before actions and retained until the backend acknowledges its report. Worker restart reports a recoverable pending run as `submission_unknown`, never repeats form operations, and blocks execution if reporting fails. **Reconcile interrupted execution** retries reporting only.

A claim response lost before its run token is stored cannot be safely reported with an invented token. It remains blocked for dashboard reconciliation; the backend must expire/reconcile its durable lease conservatively. Once an authenticated queue refresh establishes that the packet is terminal or no longer present in the executable queue, **Reconcile interrupted execution** can clear the local interruption without retrying. A full Chrome restart clears session storage: durable backend `executing`/unknown states and leases remain authoritative and must not become automatically approved again.

Unexpected navigation, context loss without the explicitly reviewed fixture receipt, missing receipts, and timeouts after possible submit are unknown outcomes, not success and not an automatic retry. A worker restart always uses the conservative pending-run recovery above; it does not restart receipt browsing or submission. Stop prevents the next operation but cannot withdraw information already sent or an in-flight application.
