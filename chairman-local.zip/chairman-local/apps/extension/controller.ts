import type { FormSnapshot, Packet } from "../../packages/domain/types";
import { API_ORIGIN, type Claim, type PageCommand, type PageResult, type PanelState, type PendingRun, type QueueItem, type QueueResponse, type RunReport } from "./contracts";
import { assertApprovedSnapshot, assertExactDestination, assertFillPlan, decodeResume, destination, fingerprint, isFixture } from "./safety";

export interface ControllerPorts {
  api<T>(path: string, body?: unknown): Promise<T>;
  apiOrigin?(): Promise<string>;
  getPending(): Promise<PendingRun | undefined>;
  setPending(pending: PendingRun): Promise<void>;
  clearPending(): Promise<void>;
  hasToken(): Promise<boolean>;
  activeTab(url: string, tabId?: number): Promise<number>;
  open(url: string): Promise<void>;
  inject(tabId: number, url: string): Promise<string>;
  page(tabId: number, documentId: string, command: PageCommand): Promise<PageResult>;
  fixtureConfirmation?(tabId: number, approvedUrl: string): Promise<string | undefined>;
}

export function recoveryReport(pending: PendingRun): RunReport | undefined {
  return pending.runToken ? {
    packetId: pending.packetId, runToken: pending.runToken, outcome: "submission_unknown",
    error: "The browser worker was interrupted. A prior action may have transmitted data; no automatic retry was made."
  } : undefined;
}

export class ExtensionController {
  private busy = false;
  private message = "Pair with the local service to load application packets.";
  constructor(private readonly ports: ControllerPorts) {}

  private async exclusive<T>(operation: () => Promise<T>): Promise<T> {
    if (this.busy) throw new Error("Another operation is active. Wait for its result.");
    this.busy = true;
    try { return await operation(); } finally { this.busy = false; }
  }

  async recover(): Promise<void> {
    return this.exclusive(() => this.recoverPending());
  }

  private async recoverPending(): Promise<void> {
    const pending = await this.ports.getPending();
    if (!pending) return;
    const report = recoveryReport(pending);
    if (!report) {
      if (await this.serverReconciled(pending)) return;
      this.message = "Claim interrupted before its receipt was stored. Reconcile the executing packet in the dashboard; never rerun it automatically.";
      return;
    }
    try {
      await this.ports.api("/api/extension/report", report);
      await this.ports.clearPending();
      this.message = "Interrupted execution recorded as unknown. Check the destination and dashboard manually.";
    } catch {
      if (await this.serverReconciled(pending)) return;
      this.message = "Interrupted execution is unresolved. Reconnect the local service to report it; no further execution is allowed.";
    }
  }

  private async serverReconciled(pending: PendingRun): Promise<boolean> {
    try {
      const queue = await this.queue();
      const item = queue.items.find((entry) => entry.packet.id === pending.packetId);
      if (item && !["submission_unknown", "submitted_confirmed", "failed", "withdrawn_from_queue"].includes(item.packet.status)) return false;
      await this.ports.clearPending();
      this.message = "The interrupted packet is no longer executable in the server queue. Review its final state in the dashboard; no application was retried.";
      return true;
    } catch {
      return false;
    }
  }

  async state(): Promise<PanelState> {
    const paired = await this.ports.hasToken();
    return {
      paired, apiOrigin: await this.ports.apiOrigin?.() ?? API_ORIGIN, pending: await this.ports.getPending(), message: paired && this.message === "Pair with the local service to load application packets."
        ? "Connected locally. Open a permitted job and inspect its form before approving a packet."
        : this.message,
      ...(paired ? { queue: await this.queue() } : {})
    };
  }

  private async queue(): Promise<QueueResponse> {
    const result = await this.ports.api<QueueResponse>("/api/extension/jobs");
    if (!result || !Array.isArray(result.items) || result.items.length > 1_000 || typeof result.stopped !== "boolean") {
      throw new Error("The local service returned an invalid queue or missing Stop state.");
    }
    return result;
  }

  private async permitted(packetId: string, status?: Packet["status"]): Promise<QueueItem> {
    const queue = await this.queue();
    if (queue.stopped) throw new Error("The queue is stopped. Resume it in the dashboard before continuing.");
    const matches = queue.items.filter((item) => item.packet?.id === packetId);
    if (matches.length !== 1) throw new Error("The packet is unavailable or ambiguous. Refresh the dashboard.");
    const item = matches[0];
    if (item.automationAllowed !== true) throw new Error(item.reason || "This destination has not been permitted by the local service.");
    if (item.packet.jobId !== item.job.id || item.job.status !== "open" || item.job.aiPolicy === "prohibited" ||
        (status !== undefined && item.job.aiPolicy !== "allowed" && !isFixture(item.job.applyUrl))) {
      throw new Error("The job or its AI policy no longer permits this operation.");
    }
    const target = destination(item.job.applyUrl);
    if (isFixture(item.job.applyUrl) && target.origin !== (await this.ports.apiOrigin?.() ?? API_ORIGIN)) {
      throw new Error("The controlled fixture must be hosted by the paired local service.");
    }
    if (status && item.packet.status !== status) throw new Error(`This operation requires a ${status} packet.`);
    return item;
  }

  async open(packetId: string): Promise<void> {
    await this.exclusive(async () => {
      const item = await this.permitted(packetId);
      await this.ports.open(destination(item.job.applyUrl).href);
      this.message = "Job opened. Complete login yourself, then run preflight on this exact page.";
    });
  }

  async preflight(packetId: string): Promise<void> {
    await this.exclusive(async () => {
      if (await this.ports.getPending()) throw new Error("Resolve the interrupted execution before inspecting another packet.");
      const item = await this.permitted(packetId);
      if (!["prepared", "approved"].includes(item.packet.status)) throw new Error("Only a prepared or approved packet can be inspected.");
      const url = destination(item.job.applyUrl).href;
      const tabId = await this.ports.activeTab(url);
      const documentId = await this.ports.inject(tabId, url);
      await this.permitted(packetId);
      await this.ports.activeTab(url, tabId);
      const { snapshot } = await this.ports.page(tabId, documentId, { action: "snapshot", url });
      if (!snapshot || snapshot.url !== url || snapshot.fingerprint !== await fingerprint(snapshot)) throw new Error("The page returned an invalid preflight snapshot.");
      await this.permitted(packetId);
      await this.ports.api<{ packet: Packet }>("/api/extension/preflight", { packetId, snapshot });
      this.message = snapshot.hasCaptcha || snapshot.hasLegal || snapshot.unsupported.length
        ? "Preflight saved with blockers. Use the dashboard's manual checklist; nothing was filled or uploaded."
        : "Preflight attached. Review the exact packet and approve it in the dashboard before execution.";
    });
  }

  async execute(packetId: string): Promise<void> {
    await this.exclusive(async () => {
      if (await this.ports.getPending()) throw new Error("An interrupted execution must be reconciled first.");
      const approved = await this.permitted(packetId, "approved");
      const url = destination(approved.job.applyUrl).href;
      const tabId = await this.ports.activeTab(url);
      const documentId = await this.ports.inject(tabId, url);
      await this.permitted(packetId, "approved");
      await this.ports.activeTab(url, tabId);
      const { snapshot } = await this.ports.page(tabId, documentId, { action: "snapshot", url });
      if (!snapshot) throw new Error("No preflight snapshot was returned.");
      await assertApprovedSnapshot(snapshot, approved.packet.formSnapshot);
      assertExactDestination(snapshot.url, url);
      let pending: PendingRun = { packetId, tabId, url, phase: "claiming" };
      await this.ports.setPending(pending);
      let claim: Claim | undefined;
      let report: RunReport | undefined;
      try {
        await this.permitted(packetId, "approved");
        await this.ports.activeTab(url, tabId);
        claim = await this.ports.api<Claim>("/api/extension/claim", { packetId });
        if (!claim || typeof claim.runToken !== "string" || !claim.runToken || claim.runToken.length > 500) {
          throw new Error("The execution receipt is missing; reconcile this attempt in the dashboard.");
        }
        pending = { ...pending, phase: "claimed", runToken: claim.runToken };
        await this.ports.setPending(pending);
        if (claim.packet?.id !== packetId || claim.packet.status !== "executing" ||
            claim.job?.id !== approved.job.id || claim.job.applyUrl !== approved.job.applyUrl ||
            !approved.packet.approvalHash || claim.packet.approvalHash !== approved.packet.approvalHash) {
          throw new Error("The claimed packet is not the exact approved application.");
        }
        await assertApprovedSnapshot(snapshot, claim.packet.formSnapshot);
        assertFillPlan(snapshot, claim.fields, claim.resume);
        const bytes = decodeResume(claim.resume);
        const digest = [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))]
          .map((byte) => byte.toString(16).padStart(2, "0")).join("");
        if (!approved.packet.artifacts.some((artifact) => artifact.filename === claim!.resume.filename &&
            artifact.sha256 === digest && artifact.bytes === bytes.length)) {
          throw new Error("The resume is not an exact approved artifact.");
        }
        const next = async (command: PageCommand) => {
          const live = await this.permitted(packetId, "executing");
          if (live.job.applyUrl !== approved.job.applyUrl || live.packet.approvalHash !== approved.packet.approvalHash) {
            throw new Error("The packet or destination changed during execution.");
          }
          await assertApprovedSnapshot(snapshot, live.packet.formSnapshot);
          await this.ports.activeTab(url, tabId);
          return this.ports.page(tabId, documentId, command);
        };
        const current = await next({ action: "snapshot", url });
        if (!current.snapshot) throw new Error("The current form is unavailable.");
        await assertApprovedSnapshot(current.snapshot, snapshot);
        for (const [key, value] of Object.entries(claim.fields)) {
          await next({ action: "fill", url, fingerprint: snapshot.fingerprint, key, value });
        }
        await next({ action: "attach", url, fingerprint: snapshot.fingerprint, resume: claim.resume });
        const verification = { url, fingerprint: snapshot.fingerprint, fields: claim.fields, resume: claim.resume };
        await next({ action: "verify", ...verification });
        pending = { ...pending, phase: "submitting" };
        await this.ports.setPending(pending);
        let confirmation: string | undefined;
        let submitIssued = false;
        try {
          const live = await this.permitted(packetId, "executing");
          if (live.job.applyUrl !== approved.job.applyUrl || live.packet.approvalHash !== approved.packet.approvalHash) {
            throw new Error("The packet or destination changed before submission.");
          }
          await assertApprovedSnapshot(snapshot, live.packet.formSnapshot);
          await this.ports.activeTab(url, tabId);
          submitIssued = true;
          confirmation = (await this.ports.page(tabId, documentId, { action: "submit", ...verification })).confirmation;
        } catch (error) {
          if (!submitIssued || !isFixture(url) || !this.ports.fixtureConfirmation) throw error;
        }
        if (!confirmation && submitIssued && isFixture(url)) {
          confirmation = await this.ports.fixtureConfirmation?.(tabId, url);
        }
        report = {
          packetId, runToken: claim.runToken,
          outcome: confirmation ? "submitted_confirmed" : "submission_unknown",
          ...(confirmation ? { confirmation } : {
            error: "No trustworthy receipt was observed. Check the destination manually; do not retry automatically."
          })
        };
      } catch (error) {
        if (!pending.runToken) {
          this.message = "Claim outcome unknown. Reconcile the packet in the dashboard; automatic retry is blocked.";
          throw new Error(this.message);
        }
        report = {
          packetId, runToken: pending.runToken,
          outcome: pending.phase === "submitting" ? "submission_unknown" : "failed",
          error: error instanceof Error ? error.message : "Execution stopped unexpectedly."
        };
      }
      if (report) {
        // Persisted pending state is deliberately retained until the local service acknowledges the report.
        await this.ports.api("/api/extension/report", report);
        await this.ports.clearPending();
        this.message = report.outcome === "submitted_confirmed"
          ? "The controlled fixture confirmed receipt. This is not a real employer submission."
          : `${report.outcome === "failed" ? "Paused" : "Submission outcome unknown"}: ${report.error}`;
      }
    });
  }
}
