-- Public listing data only. Never add profiles, resumes, application answers, tokens or prompts here.
CREATE TABLE IF NOT EXISTS public_jobs (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL,
  source_job_id TEXT NOT NULL,
  revision INTEGER NOT NULL UNIQUE,
  data TEXT NOT NULL CHECK(json_valid(data)),
  fetched_at INTEGER NOT NULL,
  UNIQUE(source_id, source_job_id)
);
CREATE INDEX IF NOT EXISTS idx_public_jobs_fetched_at ON public_jobs(fetched_at);
CREATE INDEX IF NOT EXISTS idx_public_jobs_source ON public_jobs(source_id);

CREATE TABLE IF NOT EXISTS sync_meta (
  id INTEGER PRIMARY KEY CHECK(id = 1),
  revision INTEGER NOT NULL DEFAULT 0,
  retention_floor INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO sync_meta(id) VALUES (1);

CREATE TABLE IF NOT EXISTS source_state (
  source_id TEXT PRIMARY KEY,
  cursor TEXT,
  last_started_at INTEGER NOT NULL DEFAULT 0,
  last_success_at INTEGER,
  next_scan_at INTEGER NOT NULL DEFAULT 0,
  failures INTEGER NOT NULL DEFAULT 0,
  last_error_code TEXT,
  last_count INTEGER NOT NULL DEFAULT 0,
  total_scanned INTEGER NOT NULL DEFAULT 0,
  cycle_started_at INTEGER NOT NULL DEFAULT 0,
  cycle_pages INTEGER NOT NULL DEFAULT 0,
  cycle_limited INTEGER NOT NULL DEFAULT 0,
  lease_token TEXT,
  lease_until INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO source_state(source_id) VALUES
  ('linkedin'), ('wellfound'), ('naukri'), ('supabase'), ('automattic'),
  ('canonical'), ('safetywing'), ('deel'), ('toptal'), ('himalayas'), ('sideshift');
