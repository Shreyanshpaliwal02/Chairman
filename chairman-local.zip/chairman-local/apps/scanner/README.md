# Public-only scanner — Cloudflare Free

This optional Worker scans permitted public feeds while the Mac is off. It **does not** rank against a candidate, host a resume, generate AI content, open a browser, log in or apply to anything. D1 contains only public jobs, source cursors and operational health. The sync bearer token belongs in a Worker secret, **never D1 or source control**.

## Actual coverage

The original 11 requested sources plus three additional public APIs are in `packages/adapters/sources.ts`, with separate discovery, browser-assistance and submission permissions. **No source currently grants automated form assistance/submission.**

| Source | Discovery interface | Cloud default |
| --- | --- | --- |
| Himalayas | Documented `https://himalayas.app/jobs/api?limit=1&cursor=…` | Enabled, bounded partial coverage |
| Supabase | Ashby public GET, board `supabase`, `includeCompensation=true`, listed jobs only | Deferred: whole-board payload |
| Automattic | Greenhouse public board `automatticcareers`, then one public job detail | Deferred: unpaginated index |
| Canonical / Ubuntu | Greenhouse `canonical`, with public question labels checked | Deferred: unpaginated index; all applications have a conservative no-AI hold |
| SafetyWing | Published `https://safetywing.pinpointhq.com/jobs.rss` | Deferred: whole-feed payload |
| Remotive | Official free GET, fixed `software-dev` category, complete snapshot | Deferred: unpaginated category and six-hour retrieval cooldown |
| Arbeitnow | Official free GET, one numeric `page` at a time, up to 250 jobs | Deferred: provider page can exceed 1 MiB |
| Remote OK | Official public JSON feed, metadata/legal record plus complete snapshot | Deferred: unpaginated feed, conservative daily retrieval |
| LinkedIn, Wellfound, Naukri | Manual-only | Never fetched |
| Deel | Manual pending verified current custom-portal interface | Never fetched |
| Toptal | Manual corporate/network distinction | Never fetched |
| SideShift.app | Corporate engineering watch; **not creator/UGC gigs or SideShift.ai** | Never fetched |

Local `scanSource` supports eight permitted adapters. Supabase/RSS use stable-ID continuation over a newly fetched, bounded whole feed; Greenhouse uses a newly fetched index and one detail per call. Newly added earlier IDs are picked up on the next cycle. There is no arbitrary-URL crawler, private ATS API, HTML-page fallback, authenticated source scraping or redirect following.

Himalayas' current API documents opaque `nextCursor` pagination (offset is deprecated), up to 20 jobs/request and daily-refreshed data. Every normalized description retains **“Original source: Himalayas” plus the original job URL**. Display the named source and clickable `canonicalUrl` in the local dashboard. Do not redistribute to job boards or publicly republish this cache. Its API/OpenAPI expressly permits internal dashboards and licenses attribution-based use; general site terms are more restrictive, so review both before any expanded use.

Remote does **not** mean India-eligible. Country restrictions and timezone restrictions are preserved when supplied; unspecified countries stay unknown. Salary periods are not guessed/annualized; Himalayas salary is not labelled base without evidence. Ashby only uses one explicit summary salary component, not equity/bonus or merged location tiers. Posting language is not working-language evidence. Sponsorship and language remain unknown absent verified structured evidence. Disappearing/stale jobs are not falsely marked closed; explicit expiry is retained for local revalidation.

### Additional API policy and coverage limits

Official evidence was reviewed on **2026-09-14**. All three additions are discovery only and remain **outside the Worker default `SCAN_SOURCES`**. They send only a fixed category/page or no query, never candidate profiles, preferences, account tokens or cookies. Links from responses are not fetched. Apply links retain the provider listing so attribution is not bypassed.

- **Remotive:** [publisher documentation and API terms](https://github.com/remotive-com/remote-jobs-api), linked by the [official helpdesk](https://support.remotive.com/en/article/list-remote-jobs-public-api-105pww2/). Use `https://remotive.com/api/remote-jobs?category=software-dev`. This category is useful for software roles but is not comprehensive engineering coverage. Jobs are delayed **24 hours**. Publisher recommends **at most four retrievals/day**, and blocks excessive requests above two/minute. `getSourceCooldownMs("remotive")` returns **21,600,000** (six hours). Keep the **Remotive name and original job URL**; no redistribution to other job boards and no signup/email harvesting. The documented `limit` parameter is deliberately unused: it is a latest-results cap, **not pagination**. A complete snapshot is returned or an explicit error, never a fabricated continuation.
- **Arbeitnow:** [official API announcement](https://www.arbeitnow.com/blog/job-board-api), its [linked Postman docs](https://documenter.getpostman.com/view/18545278/UVJbJdKh), and [terms, especially sections 2, 11 and 13](https://www.arbeitnow.com/terms). Use `https://www.arbeitnow.com/api/job-board-api?page=1`. Feed metadata documents **hourly updates and numeric `?page=` pagination**. Next URLs must match the known API hosts/path and exactly the following page; only the page number is retained and the request URL is reconstructed. The older example has 100 jobs/page; one read-only live check returned **250 jobs and 1,757,017 bytes**, explicitly exceeding 1 MiB. The source-specific local default is therefore **250 entries / 2 MiB**, still a hard bounded page, never slicing away jobs. Any larger page fails. The observed rate-limit header was 50 (historical example: 3), **without a defined window**; neither authorizes requests/second. The observed `Cache-Control: private, max-age=432000` can make responses stale despite hourly-update metadata. The application chooses at least **one hour between attempts** (`3,600,000` ms); that is not a provider quota or freshness guarantee. Preserve an **Arbeitnow.com backlink**. Jobs are predominantly Germany/Europe; a remote flag is not India eligibility, and sponsorship stays unknown unless an explicit boolean is supplied.
- **Remote OK:** the [official JSON endpoint](https://remoteok.com/api) publishes API terms in its first metadata record. It requires the **Remote OK name plus a follow (not `nofollow`) link** to each original listing; do not use its logo without written permission. The adapter validates that metadata and does not treat it as a job. No numeric quota, refresh SLA, pagination or retention duration was verified in the current official feed. **Once/day** (`86,400,000` ms) is an application-selected conservative cooldown, not a published allowance. Snapshot/history completeness is not promised; no guessed paging or private endpoint is used. The general site/legal page was not independently retrievable (redirect loop), so recheck current terms before wider use.

**Caller obligations:** persist attempts before network access and honor the greater of `getSourceCooldownMs(id)`, backoff and `Retry-After`, including failed attempts. The adapter has no cross-process/IP-wide rate counter. Do not repeatedly re-fetch an unpaginated snapshot to simulate pages. For Arbeitnow, continue its next provider page on a later due attempt. Do not opt these feeds into the 10 ms Free Worker merely because a local Node test passes.

**Retention is not permission to archive:** none of these reviewed API documents specifies a numeric retention allowance. Keep only a private, bounded discovery cache and remove it upon revocation; no public redistribution or signup gate. Arbeitnow's general terms additionally require transitory personal viewing and deletion when viewing/license ends, and prohibit server mirroring. Its adapter does not grant permission for indefinite local storage or D1 replication. The caller must implement suitable cleanup before persistent use; the Worker's existing 30-day retention is **not** a new-source license. Adapters themselves retain no response bodies or cache between calls.

Remotive salary strings are preserved verbatim as normalized plain text in the description, with structured salary left unknown rather than guessed USD/year/base. Remote OK numeric fields are retained in the description and structured ranges have no guessed period or currency; zero bounds are treated as unspecified. Original country restriction text is retained; exclusions are not converted into positive country eligibility. No feed guarantees **500 suitable discoveries/day**, and none authorizes **500 applications/day**.

### Candidate authentication is separate

A resume contains claims, not provider credentials; account tokens cannot legitimately be derived from it. [LinkedIn's official OIDC documentation](https://learn.microsoft.com/en-us/linkedin/consumer/integrations/self-serve/sign-in-with-linkedin-v2) requires provider OAuth authentication and provisioned scopes; sign-in is not a jobs/application automation grant. [MyGreenhouse](https://support.greenhouse.io/hc/en-us/articles/43418495049499-MyGreenhouse-FAQ-for-Candidates) uses emailed single-use security codes. Many employer-hosted ATS forms can be completed without a candidate account; the [optional Greenhouse Quick Apply button](https://support.greenhouse.io/hc/en-us/articles/35746094035099-MyGreenhouse-Quick-Apply) adds account-based autofill, not a requirement to invent credentials.

The [Greenhouse Job Board API](https://docs.greenhouse.io/job-board.html) documents public GET and an **authenticated application POST requiring an employer Job Board API key**. That is not an open candidate-submission entitlement. Arbeitnow's partner processing/JOIN references similarly do not document a public candidate submission interface. No generally available candidate auto-submission API permission was verified for the new feeds; no employer keys, account sessions or private APIs are implemented.

## User-owned setup

No deployment, login or credentials have been performed by the implementation. Run the following yourself from the repository root, only after reviewing the account's **Workers Free** and **D1 Free** limits. Do not accept a paid upgrade.

1. Use the installed Wrangler (`npx wrangler login`) and complete the provider login yourself.
2. Create an isolated **public-only** D1 database:
   ```sh
   npx wrangler d1 create job-application-public --config apps/scanner/wrangler.jsonc
   ```
3. Replace the all-zero `database_id` in `wrangler.jsonc` with that database ID. It is not a secret. Do not use an existing database containing candidate data.
4. Apply the public migration:
   ```sh
   npx wrangler d1 migrations apply job-application-public --remote --config apps/scanner/wrangler.jsonc
   ```
5. Generate a random sync token with at least 32 ASCII characters using your password manager. Set it with the interactive secret prompt; **do not place its value in a command argument, transcript, URL or committed `.dev.vars` file**:
   ```sh
   npx wrangler secret put SYNC_TOKEN --config apps/scanner/wrangler.jsonc
   ```
6. Deploy:
   ```sh
   npm run scanner:deploy
   ```
7. Check `https://job-application-scanner.<your-account>.workers.dev/health`. Configure that exact base URL and the same token in the private local app. A placeholder database ID, missing migration or absent token produces a safe error rather than a fake successful scan.

For local Wrangler development, use `npm run scanner:dev`. Apply the migration with `--local` rather than `--remote`. Use a disposable development secret entered through a local, ignored secret file/provider configuration. The production sync helper intentionally refuses localhost, custom domains, arbitrary Workers and preview URLs.

## Budget, failures and limitations

- Cron: once per 15 minutes, at most **96 invocations/day**. One due source selected fairly by oldest attempt, with an atomic two-minute D1 lease. Each invocation performs one page, **one job**, at most two public fetches, each with an eight-second wall timeout and **64 KiB decompressed** body cap. There are at most 12 D1 statements; no internal retry loop and no recursive pagination.
- Default cloud opt-in is **Himalayas only**. Other supported sources are visibly deferred in `/health`, not represented as a successful empty scan. To opt in a source, measure its real payload and CPU on Free, then add its exact registry ID to `SCAN_SOURCES`. A payload over budget remains an explicit `TOO_LARGE` failure; do not increase the plan or remove safeguards.
- **10 ms CPU cannot be proved by wall-clock or local Node tests.** The source parser, JSON serialization and D1 orchestration must be measured in your own authorized deployment. The implementation is deliberately small but has not been validated against production Free CPU. If Cloudflare reports CPU exhaustion, set `SCAN_ENABLED` to `"false"` and redeploy, or keep that source local-only. No paid-plan CPU override is configured.
- The scheduler processes at most 96 pages in a source cycle and resets to the head after 24 hours. This is a **recent-listing sample**, not full coverage of the enormous Himalayas feed. `cyclePages`/`cycleLimited` make this visible. An unfinished daily cursor is deliberately superseded by the fresh-head cycle; a *failed write* never advances it.
- Every page and cursor are committed together in a D1 transaction. IDs/requisitions are unique and repeat scans update instead of duplicating records. All SQL is parameterized; the incremental revision and retention timestamp are indexed. A rate limit honors the greater of `Retry-After` and exponential backoff; payload/validation errors pause that source for a day. No account or anti-bot bypass.
- D1 availability is tested by acquiring the lease **before** any public request. D1 quota errors stop that tick. If platform termination prevents the error handler running, `/health` reports the abandoned lease as `INTERRUPTED_OR_CPU_LIMIT` after it expires. This is an operational symptom, not a CPU diagnosis.
- The cache targets **30-day retention**, pruning at most five old records per successful tick. If scanning is paused or D1 is unavailable, cleanup also pauses; delete the public database yourself to remove the entire cache. Pruning is not proof the employer closed a job. Syncs behind retention get `409 CURSOR_EXPIRED`; restart without a cursor and locally revalidate stale records. The API does not issue fabricated “closed” tombstones.
- With defaults, the scan path makes at most 192 public fetches/day and a small fraction of Free D1's daily write budget, excluding user-requested sync traffic. Observe account-wide consumption: other Workers share quotas, and public `/health` requests and authenticated sync still consume Free reads/requests. No cost, coverage or uptime guarantee.
- No conditional caching headers are assumed for these APIs. Each scheduled page has a different cursor; whole-board adapters remain deferred by default rather than repeatedly downloading oversized payloads.

## Integration contract

```ts
SOURCES: Source[]
getSource(id: string): Source | undefined
getSourceCooldownMs(id: string): number // Minimum between attempts for new feeds; 0 for unchanged sources.
scanSource(id: string, cursor?: string, fetcher?: typeof fetch, options?: ScanOptions): Promise<ScanResult>
syncCloudJobs(baseUrl: string, token: string, cursor?: string, fetcher?: typeof fetch): Promise<ScanResult>
```

`ScanOptions` permits bounded `pageSize` (1–20 for original adapters; Arbeitnow up to/default 250; Remotive/Remote OK up to/default 1,000), `maxResponseBytes` (hard maximum 8 MiB; original defaults 1 MiB, Arbeitnow 2 MiB, complete Remotive/Remote OK snapshots 8 MiB) and `timeoutMs` (default 10 seconds, maximum 15 seconds). Explicit caller byte/entry budgets always win; the Worker remains constrained by its explicit 64 KiB budget. Greenhouse always returns at most one detail. For the new fixed-page/snapshot feeds, `pageSize` is an **entry budget**, not a request to truncate: exceeding it raises `TOO_LARGE`. Remotive/Remote OK reject any cursor because no pagination was verified. `DiscoveryError` carries a stable `code`, optional `httpStatus` and `retryAfterMs`, never upstream response bodies. `validatePublicJob` accepts the new source IDs and enforces/restores original-source attribution and provider hosts; the local sync service refuses local-only sources from a cloud response.

- `GET /health`: public operational status only; no token, cursor or candidate data.
- `GET /jobs?cursor=<revision>`: `Authorization: Bearer <token>` required. Returns `{ jobs, nextCursor }`, at most five jobs in revision order. Persist the returned cursor **only after durable local upserts**. Keep it even on an empty response. Fetch another page while receiving jobs, then poll later. This updates existing jobs as well as inserts; it is not an offset into a changing array.
- `401`: missing/wrong token; `503`: unset token/storage unavailable; `400`: invalid cursor; `409`: expired cursor (restart a full refresh). Neither endpoint accepts writes or candidate payloads. No wildcard CORS or browser-direct sync.
- The helper validates the exact `job-application-scanner.<account>.workers.dev` pattern, HTTPS, root path, bounded replies, normalized job shape and cursor monotonicity, and refuses redirects. It never forwards a token to another host.

## Validation and evidence

Offline fixture tests: `node --import tsx --test tests/discovery.test.ts tests/additional-feeds.test.ts tests/scanner.test.ts`. They use synthetic public listings and in-memory SQLite; no real applications or network. Worker deploy bundling can be checked with the existing Wrangler dry-run command without deploying. Neither proves deployed Cron/CPU behavior.

Expanded-source validation: 48 fixture tests pass and repository TypeScript checking passes. The original Worker validation bundled for the browser platform without Node built-ins (approximately 179 KiB uncompressed). Its warmed local Node CPU probe of 100 single-job scans with a 40,944-byte synthetic Himalayas response measured p50 **0.960 ms**, p95 **1.865 ms**, maximum **5.484 ms**. These historical measurements do not include the new feeds, D1, cold startup, or the Workers runtime; they are **not** proof of the production 10 ms budget.

References reviewed during implementation:
- [Himalayas public API](https://himalayas.app/api), [OpenAPI/license](https://himalayas.app/docs/openapi.json), [general terms](https://himalayas.app/terms)
- [Ashby public job-posting API](https://developers.ashbyhq.com/docs/public-job-posting-api)
- [Greenhouse public GET versus authenticated application POST](https://docs.greenhouse.io/job-board.html)
- [Canonical official RSS](https://canonical.com/careers/feed), [public no-AI question evidence](https://boards-api.greenhouse.io/v1/boards/canonical/jobs/6448444?questions=true)
- [SafetyWing published RSS](https://safetywing.pinpointhq.com/jobs.rss)
- [Workers limits](https://developers.cloudflare.com/workers/platform/limits/), [D1 Free pricing](https://developers.cloudflare.com/d1/platform/pricing/)

These are evidence for specific public interfaces, not legal advice or a blanket automation grant. Recheck current policies before expansion.
