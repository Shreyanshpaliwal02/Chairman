import type { D1Database } from "@cloudflare/workers-types";
import { DiscoveryError, scanSource, type ScanOptions } from "../../../packages/adapters/discovery";
import { SOURCES, LOCAL_ONLY_SOURCE_IDS } from "../../../packages/adapters/sources";
import type { ScanResult } from "../../../packages/domain/types";

export interface Env {
  DB: D1Database;
  SYNC_TOKEN?: string;
  SCAN_ENABLED?: string;
  SCAN_SOURCES?: string;
}

interface SourceState {
  source_id: string;
  cursor: string | null;
  last_started_at: number;
  last_success_at: number | null;
  next_scan_at: number;
  failures: number;
  last_error_code: string | null;
  last_count: number;
  total_scanned: number;
  cycle_started_at: number;
  cycle_pages: number;
  cycle_limited: number;
  lease_token: string | null;
  lease_until: number;
}

const MINUTE = 60_000;
const DAY = 86_400_000;
const MAX_CYCLE_PAGES = 96;
const CLOUD_BUDGET: ScanOptions = { maxResponseBytes: 65_536, timeoutMs: 8_000, pageSize: 1 };

function configuredSources(env: Env): string[] {
  const requested = (env.SCAN_SOURCES ?? "himalayas").split(",").map((id) => id.trim()).filter(Boolean);
  return [...new Set(requested)].filter((id) => !LOCAL_ONLY_SOURCE_IDS.some(local => local === id)
    && SOURCES.some((source) => source.id === id && source.mode === "enabled" && source.discoveryAllowed)).slice(0, 5);
}

function response(value: unknown, status = 200): Response {
  return Response.json(value, { status, headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
}

function authenticated(request: Request, secret: string): boolean {
  const authorization = request.headers.get("authorization") ?? "";
  const candidate = authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
  if (candidate.length > 512) return false;
  let difference = candidate.length ^ secret.length;
  for (let index = 0; index < 512; index++) difference |= (candidate.charCodeAt(index) || 0) ^ (secret.charCodeAt(index) || 0);
  return difference === 0;
}

async function health(env: Env): Promise<Response> {
  const states = await env.DB.prepare("SELECT * FROM source_state ORDER BY source_id LIMIT 11").all<SourceState>();
  const configured = configuredSources(env);
  const now = Date.now();
  return response({
    status: env.SCAN_ENABLED === "true" ? "enabled" : "paused",
    scope: "public listings only",
    sources: SOURCES.map((source) => {
      const state = states.results.find((entry) => entry.source_id === source.id);
      const cloudEnabled = source.discoveryAllowed && configured.includes(source.id) && env.SCAN_ENABLED === "true";
      const interrupted = state?.lease_token && state.lease_until <= now;
      return {
        id: source.id, name: source.name, mode: source.mode, cloudEnabled,
        cloudNote: LOCAL_ONLY_SOURCE_IDS.some(id => id === source.id) ? "Local-only source; cloud mirroring is not enabled by configuration."
          : !source.discoveryAllowed ? "Manual-only; never fetched."
          : !configured.includes(source.id) ? "Cloud deferred: whole-feed/index CPU and byte budget must be measured before opt-in. Local discovery supported."
          : "One bounded page per fair scheduled tick; partial daily coverage, not a complete market crawl.",
        lastScannedAt: state?.last_success_at ? new Date(state.last_success_at).toISOString() : null,
        lastAttemptAt: state?.last_started_at ? new Date(state.last_started_at).toISOString() : null,
        lastError: interrupted ? "INTERRUPTED_OR_CPU_LIMIT" : state?.last_error_code ?? null,
        nextScanAt: state?.next_scan_at ? new Date(state.next_scan_at).toISOString() : null,
        failures: state?.failures ?? 0, lastCount: state?.last_count ?? 0,
        cyclePages: state?.cycle_pages ?? 0, cycleLimited: Boolean(state?.cycle_limited),
        inProgress: Boolean(state?.lease_token && state.lease_until > now)
      };
    })
  });
}

export async function handleRequest(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  if (request.method !== "GET") return response({ error: "METHOD_NOT_ALLOWED" }, 405);
  if (url.pathname !== "/health" && url.pathname !== "/jobs") return response({ error: "NOT_FOUND" }, 404);
  try {
    if (url.pathname === "/health") return await health(env);
    if (!env.SYNC_TOKEN || env.SYNC_TOKEN.length < 32 || env.SYNC_TOKEN.length > 512 || /[^\x21-\x7e]/.test(env.SYNC_TOKEN)) return response({ error: "SYNC_NOT_CONFIGURED" }, 503);
    if (!authenticated(request, env.SYNC_TOKEN)) return response({ error: "UNAUTHORIZED" }, 401);
    const raw = url.searchParams.get("cursor");
    if ([...url.searchParams.keys()].some((key) => key !== "cursor") || url.searchParams.getAll("cursor").length > 1
      || (raw !== null && (!/^(0|[1-9]\d{0,15})$/.test(raw) || !Number.isSafeInteger(Number(raw))))) {
      return response({ error: "INVALID_CURSOR" }, 400);
    }
    const position = Number(raw ?? 0);
    const meta = await env.DB.prepare("SELECT revision, retention_floor FROM sync_meta WHERE id = 1").first<{ revision: number; retention_floor: number }>();
    if (!meta) return response({ error: "DATABASE_NOT_INITIALIZED" }, 503);
    if (raw !== null && position < meta.retention_floor) return response({ error: "CURSOR_EXPIRED", action: "Restart sync without a cursor; recheck local stale records." }, 409);
    if (position > meta.revision) return response({ error: "INVALID_CURSOR" }, 400);
    const page = await env.DB.prepare("SELECT revision, data FROM public_jobs WHERE revision > ? ORDER BY revision LIMIT 5").bind(position).all<{ revision: number; data: string }>();
    // A continuation is also a checkpoint: retain it when caught up or when the result is empty.
    return response({
      jobs: page.results.map((entry) => JSON.parse(entry.data) as unknown),
      nextCursor: String(page.results.at(-1)?.revision ?? meta.revision)
    });
  } catch {
    // Never return database messages, upstream bodies, authorization values or account details.
    return response({ error: "STORAGE_UNAVAILABLE" }, 503);
  }
}

interface TickDependencies {
  now?: number;
  fetcher?: typeof fetch;
  scan?: (sourceId: string, cursor?: string, fetcher?: typeof fetch, options?: ScanOptions) => Promise<ScanResult>;
}

function errorCode(error: unknown): string {
  if (error instanceof DiscoveryError) return error.code;
  return "PERSISTENCE_OR_SCAN_FAILED";
}

function backoff(error: unknown, failures: number): number {
  const basic = error instanceof DiscoveryError && ["TOO_LARGE", "INVALID_DATA", "REDIRECT", "INVALID_CURSOR"].includes(error.code)
    ? DAY : Math.min(6 * 60 * MINUTE, 15 * MINUTE * 2 ** Math.min(failures, 5));
  return Math.max(basic, error instanceof DiscoveryError ? error.retryAfterMs ?? 0 : 0);
}

/** Atomic lease + page/cursor commit. One source, <=2 network requests and <=12 D1 statements per tick. */
export async function runScanTick(env: Env, dependencies: TickDependencies = {}): Promise<void> {
  if (env.SCAN_ENABLED !== "true") return;
  const ids = configuredSources(env);
  if (!ids.length) return;
  const now = dependencies.now ?? Date.now();
  const token = crypto.randomUUID();
  const placeholders = ids.map(() => "?").join(",");
  let state: SourceState | null;
  try {
    state = await env.DB.prepare(`
      UPDATE source_state SET lease_token = ?, lease_until = ?, last_started_at = ?
      WHERE source_id = (
        SELECT source_id FROM source_state
        WHERE source_id IN (${placeholders}) AND next_scan_at <= ? AND lease_until <= ?
        ORDER BY last_started_at, source_id LIMIT 1
      ) AND lease_until <= ?
      RETURNING *
    `).bind(token, now + 2 * MINUTE, now, ...ids, now, now, now).first<SourceState>();
  } catch {
    return; // D1 quota/unavailability: do not fetch data that cannot be durably persisted.
  }
  if (!state) return;
  const restart = !state.cycle_started_at || now - state.cycle_started_at >= DAY;
  const cursor = restart ? undefined : state.cursor ?? undefined;
  try {
    const result = await (dependencies.scan ?? scanSource)(state.source_id, cursor, dependencies.fetcher ?? fetch, CLOUD_BUDGET);
    if (result.jobs.length > 1 || result.jobs.some((job) => job.sourceId !== state.source_id)) throw new DiscoveryError("INVALID_DATA", "Cloud page exceeded its configured scope.");
    const cyclePages = (restart ? 0 : state.cycle_pages) + 1;
    const cycleStarted = restart ? now : state.cycle_started_at;
    const limited = Boolean(result.nextCursor && cyclePages >= MAX_CYCLE_PAGES);
    const finished = !result.nextCursor || limited;
    const batch = [];
    for (const job of result.jobs) {
      const data = JSON.stringify(job);
      if (new TextEncoder().encode(data).byteLength > 65_536) throw new DiscoveryError("TOO_LARGE", "Normalized job exceeds cloud storage budget.");
      batch.push(env.DB.prepare(`
        UPDATE sync_meta SET revision = revision + 1 WHERE id = 1
        AND EXISTS (SELECT 1 FROM source_state WHERE source_id = ? AND lease_token = ?)
      `).bind(state.source_id, token));
      batch.push(env.DB.prepare(`
        INSERT INTO public_jobs (id, source_id, source_job_id, revision, data, fetched_at)
        SELECT ?, ?, ?, (SELECT revision FROM sync_meta WHERE id = 1), ?, ?
        FROM source_state WHERE source_id = ? AND lease_token = ?
        ON CONFLICT(id) DO UPDATE SET
          revision = excluded.revision, data = excluded.data, fetched_at = excluded.fetched_at
        WHERE public_jobs.data <> excluded.data
      `).bind(job.id, job.sourceId, job.sourceJobId, data, now, state.source_id, token));
    }
    batch.push(env.DB.prepare(`
      UPDATE source_state SET cursor = ?, last_success_at = ?, next_scan_at = ?, failures = 0,
      last_error_code = NULL, last_count = ?, total_scanned = total_scanned + ?,
      cycle_started_at = ?, cycle_pages = ?, cycle_limited = ?, lease_token = NULL, lease_until = 0
      WHERE source_id = ? AND lease_token = ?
    `).bind(
      finished ? null : result.nextCursor ?? null, now,
      finished ? Math.max(now + 15 * MINUTE, cycleStarted + DAY) : now + 15 * MINUTE,
      result.jobs.length, result.jobs.length, cycleStarted, cyclePages, limited ? 1 : 0, state.source_id, token
    ));
    // D1 batch is transactional: failed writes never acknowledge the upstream continuation.
    await env.DB.batch(batch);
  } catch (error) {
    try {
      await env.DB.prepare(`
        UPDATE source_state SET failures = failures + 1, last_error_code = ?, next_scan_at = ?,
          lease_token = NULL, lease_until = 0 WHERE source_id = ? AND lease_token = ?
      `).bind(errorCode(error), Math.min(8.64e15, now + backoff(error, state.failures)), state.source_id, token).run();
    } catch {
      // An abandoned lease is visible as INTERRUPTED_OR_CPU_LIMIT and expires without losing its cursor.
    }
    return;
  }
  // A small indexed retention pass, not a full-table scan. Pruning is not evidence a listing closed.
  try {
    await env.DB.batch([
      env.DB.prepare(`
        UPDATE sync_meta SET retention_floor = MAX(retention_floor, COALESCE((
          SELECT MAX(revision) FROM (SELECT revision FROM public_jobs WHERE fetched_at < ? ORDER BY fetched_at LIMIT 5)
        ), 0)) WHERE id = 1
      `).bind(now - 30 * DAY),
      env.DB.prepare("DELETE FROM public_jobs WHERE id IN (SELECT id FROM public_jobs WHERE fetched_at < ? ORDER BY fetched_at LIMIT 5)").bind(now - 30 * DAY)
    ]);
  } catch {
    // The page is already committed. A retention failure must not rewind an acknowledged page.
  }
}

export default {
  fetch: handleRequest,
  async scheduled(_controller: unknown, env: Env, context: { waitUntil(promise: Promise<unknown>): void }): Promise<void> {
    context.waitUntil(runScanTick(env));
  }
};
