import { link, writeFile } from "node:fs/promises";

const unavailableHardLinks = new Set(["EXDEV", "ENOTSUP", "EOPNOTSUPP", "ENOSYS", "EMLINK", "EPERM"]);

export async function linkOrCopyArtifact(
  source: string,
  destination: string,
  verifiedBytes: Buffer,
  linkFile: typeof link = link,
): Promise<"linked" | "copied"> {
  try {
    await linkFile(source, destination);
    return "linked";
  } catch (error) {
    if (!(error instanceof Error) || !("code" in error) || !unavailableHardLinks.has(String(error.code))) throw error;
  }
  // FAT/exFAT, cross-volume storage and exhausted NTFS link counts still need exact bytes.
  await writeFile(destination, verifiedBytes, { flag: "wx", mode: 0o600 });
  return "copied";
}
