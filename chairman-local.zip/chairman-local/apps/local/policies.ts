import { readFileSync } from "node:fs";
import { z } from "zod";
import type { Job } from "../../packages/domain/types.js";
import { prohibitsAi } from "../../packages/domain/matching.js";

const schema = z.array(z.object({
  employer: z.string().min(1), host: z.string().min(1), pathPrefix: z.string().startsWith("/"),
  policyUrl: z.url(), reviewedAt: z.iso.datetime(),
  allowFill: z.literal(true), allowSubmit: z.boolean(), dailyLimit: z.number().int().min(1).max(Number.MAX_SAFE_INTEGER)
}).strict());
export type ReviewedPolicy = z.infer<typeof schema>[number];
export const loadPolicies = (file?: string): ReviewedPolicy[] => file ? schema.parse(JSON.parse(readFileSync(file, "utf8"))) : [];

export function automationPolicy(job: Job, policies: ReviewedPolicy[], fixtureMode: boolean, localOrigin: string): { allowed: boolean; canSubmit: boolean; reason: string; limit: number | null } {
  const deny = (reason: string) => ({ allowed: false, canSubmit: false, reason, limit: 0 });
  if (job.aiPolicy === "prohibited" || prohibitsAi(job.description)) return deny("This application restricts AI-generated content.");
  const url = new URL(job.applyUrl);
  if (fixtureMode && url.origin === localOrigin && url.pathname === "/fixture/application")
    return { allowed: true, canSubmit: true, reason: "Local controlled fixture only; not a real employer.", limit: null };
  if (url.protocol !== "https:" || /(^|\.)(linkedin\.com|wellfound\.com|naukri\.com|sideshift\.app|toptal\.com)$/.test(url.hostname))
    return deny("This destination is manual-only.");
  const supported = ["jobs.ashbyhq.com", "job-boards.greenhouse.io", "boards.greenhouse.io"].includes(url.hostname)
    || /^[a-z0-9-]+\.pinpointhq\.com$/.test(url.hostname);
  if (!supported) return deny("The legacy extension cannot operate this destination. Check Auto Apply provider support or use manual handoff.");
  const policy = policies.find(p => p.host === url.hostname && p.employer.toLowerCase() === job.company.toLowerCase()
    && (url.pathname === p.pathPrefix || url.pathname.startsWith(p.pathPrefix.replace(/\/$/, "") + "/")));
  if (!policy) return deny("This manual packet is not authorized for extension submission. Auto Apply uses a separate reviewed profile/resume-library authorization.");
  if (Date.now() - Date.parse(policy.reviewedAt) > 30 * 86400_000) return deny("The employer policy review is stale; refresh it before automation.");
  if (!policy.policyUrl.startsWith("https://")) return deny("Policy evidence must reference an HTTPS source.");
  return deny("The legacy extension direct-form driver remains fixture-only. Use the dedicated Auto Apply browser runner for supported real forms.");
}
