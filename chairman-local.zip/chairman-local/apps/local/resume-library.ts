import { createHash, randomUUID } from "node:crypto";
import { mkdir, readFile, rm, writeFile, chmod } from "node:fs/promises";
import { basename, extname, join } from "node:path";
import mammoth from "mammoth";
import { extractPdfText } from "../../packages/documents/index.js";
import type { FormSnapshot, Job, Profile, ReferenceFamily, ResumeVariant } from "../../packages/domain/types.js";
import { MIN_APPROVED_RESUMES } from "../../packages/domain/types.js";
import { MAX_RESUME_SLOTS, type JobClassification } from "../../packages/domain/role-families.js";
import { Store } from "./store.js";

interface StoredVariant extends ResumeVariant { text: string; }
export interface VariantChoice { variant: ResumeVariant; score: number; reason: string; }
const normalized = (text: string) => text.normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}@.+]+/gu, " ").replace(/\s+/g, " ").trim();
const stopWords = new Set(["the", "and", "with", "your", "you", "for", "our", "that", "this", "will", "from", "have", "are", "years", "team", "work", "experience"]);
const terms = (text: string) => new Set((normalized(text).match(/[\p{L}\p{N}][\p{L}\p{N}+#.-]{1,}/gu) ?? []).filter(term => !stopWords.has(term)));
function familyFor(job: Job): ReferenceFamily[] {
  const title = job.title.toLowerCase(), result: ReferenceFamily[] = [];
  if (/software|developer|backend|front.?end|full.?stack/.test(title)) result.push("software");
  if (/cloud|platform|devops|infrastructure|site reliability|\bsre\b/.test(title)) result.push("cloud");
  if (/data|analytics|streaming/.test(title)) result.push("data");
  if (/forward|solutions|customer/.test(title)) result.push("forward-deployed");
  if (/mlops|machine learning|\bml\b|\bai\b/.test(title)) result.push("mlops");
  return result;
}

export class ResumeLibrary {
  constructor(readonly store: Store, readonly dataDir: string) {
    store.db.exec("CREATE TABLE IF NOT EXISTS resume_variants(id TEXT PRIMARY KEY,slot INTEGER NOT NULL,active INTEGER NOT NULL,json TEXT NOT NULL); CREATE UNIQUE INDEX IF NOT EXISTS resume_variant_slot ON resume_variants(slot) WHERE active=1");
  }
  private stored(id: string): StoredVariant | undefined {
    const row = this.store.db.prepare("SELECT json FROM resume_variants WHERE id=?").get(id);
    return row ? JSON.parse(String(row.json)) as StoredVariant : undefined;
  }
  private validateIdentity(text: string, profile: Profile): string[] {
    const issues: string[] = [];
    if (/REFERENCE\s+DRAFT|verify facts before use|Sample Applicant|applicant@example\.test/i.test(text)) issues.push("This appears to be a reference/sample draft. Upload a finalized personal resume.");
    if (!profile.email.trim() || !profile.name.trim()) issues.push("Save your own name and email in Profile first.");
    else {
      const emails: string[] = text.toLowerCase().match(/[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9.-]+\.[a-z]{2,}/g) ?? [];
      if (!emails.includes(profile.email.toLowerCase().trim())) issues.push("The resume email does not match your saved profile, or could not be extracted.");
      const name = normalized(profile.name);
      if (name.length > 2 && !normalized(text).includes(name)) issues.push("Your saved name could not be matched in this resume. Check the file and profile.");
    }
    if (text.trim().length < 80) issues.push("The resume has too little extractable text for reliable selection.");
    return issues;
  }
  private publicVariant(record: StoredVariant): ResumeVariant {
    const { text, ...variant } = record;
    return { ...variant, issues: this.validateIdentity(text, this.store.profile()) };
  }
  list(): ResumeVariant[] {
    return this.store.db.prepare("SELECT json FROM resume_variants WHERE active=1 ORDER BY slot").all()
      .map(row => this.publicVariant(JSON.parse(String(row.json)) as StoredVariant));
  }
  get(id: string): ResumeVariant {
    const record = this.stored(id);
    if (!record) throw new Error("Resume variant not found.");
    return this.publicVariant(record);
  }
  path(id: string): string {
    if (!/^[a-f0-9-]{36}$/.test(id)) throw new Error("Invalid variant identifier.");
    const record = this.stored(id);
    if (!record || basename(record.artifact.filename) !== record.artifact.filename) throw new Error("Invalid resume artifact.");
    return join(this.dataDir, "resume-variants", id, record.artifact.filename);
  }
  async bytes(id: string): Promise<Buffer> {
    const record = this.get(id), bytes = await readFile(this.path(id));
    if (bytes.length !== record.artifact.bytes || createHash("sha256").update(bytes).digest("hex") !== record.artifact.sha256)
      throw new Error("A resume variant changed on disk. Upload and approve the correct file again.");
    return bytes;
  }
  async upload(slot: number, filename: string, bytes: Buffer, label: string, families: ReferenceFamily[], approved: boolean): Promise<ResumeVariant> {
    if (!Number.isInteger(slot) || slot < 1 || slot > MAX_RESUME_SLOTS) throw new Error(`Choose a resume slot from 1 to ${MAX_RESUME_SLOTS}.`);
    if (!bytes.length || bytes.length > 10 * 1024 * 1024) throw new Error("Resume files must be nonempty and at most 10 MiB.");
    const extension = extname(filename).toLowerCase();
    if (extension !== ".pdf" && extension !== ".docx") throw new Error("Upload a PDF or DOCX resume.");
    const text = extension === ".pdf" ? await extractPdfText(bytes)
      : (await mammoth.extractRawText({ buffer: bytes })).value;
    if (text.length > 200000) throw new Error("Resume text exceeds the supported size.");
    const issues = this.validateIdentity(text, this.store.profile());
    if (approved && issues.length) throw new Error(issues.join(" "));
    const id = randomUUID(), sha256 = createHash("sha256").update(bytes).digest("hex");
    const directory = join(this.dataDir, "resume-variants", id);
    await mkdir(directory, { recursive: true, mode: 0o700 });
    const artifact = { format: extension === ".pdf" ? "pdf" as const : "docx" as const, filename: `${sha256}${extension}`, sha256, bytes: bytes.length };
    await writeFile(join(directory, artifact.filename), bytes, { flag: "wx", mode: 0o600 });
    await chmod(join(directory, artifact.filename), 0o400);
    const originalFilename = basename(filename).replace(/[\u0000-\u001f\u007f]/g, "").slice(0, 240);
    const record: StoredVariant = { id, slot, label, families: [...new Set(families)], originalFilename, artifact, uploadedAt: new Date().toISOString(), approved, textLength: text.length, issues, text };
    this.store.transaction(() => {
      this.store.db.prepare("UPDATE resume_variants SET active=0 WHERE slot=? AND active=1").run(slot);
      this.store.db.prepare("INSERT INTO resume_variants VALUES (?,?,1,?)").run(id, slot, JSON.stringify(record));
      this.store.event(null, "variant_uploaded", `Resume slot ${slot} replaced; existing standing authorization is invalid.`);
    });
    return this.publicVariant(record);
  }
  approve(id: string, approved: boolean): ResumeVariant {
    const record = this.stored(id);
    if (!record || !this.list().some(item => item.id === id)) throw new Error("Choose an active resume variant.");
    const issues = this.validateIdentity(record.text, this.store.profile());
    if (approved && issues.length) throw new Error(issues.join(" "));
    record.approved = approved;
    this.store.db.prepare("UPDATE resume_variants SET json=? WHERE id=?").run(JSON.stringify(record), id);
    return this.publicVariant(record);
  }
  async remove(id: string): Promise<void> {
    const path = this.path(id), record = this.stored(id)!;
    record.approved = false; record.text = "";
    this.store.db.prepare("UPDATE resume_variants SET active=0,json=? WHERE id=?").run(JSON.stringify(record), id);
    await rm(path, { force: true });
  }
  approvedVariants(): ResumeVariant[] {
    return this.list().filter(variant => variant.approved && variant.issues.length === 0);
  }
  readiness(): string[] {
    const count = this.approvedVariants().length;
    return count >= MIN_APPROVED_RESUMES ? []
      : [`Upload and approve at least ${MIN_APPROVED_RESUMES} valid resumes (${count} ready). Any slots may be used; extra slots are optional.`];
  }
  async verifyApproved(): Promise<void> { for (const variant of this.approvedVariants()) await this.bytes(variant.id); }
  /**
   * The resume for a job: the slot assigned to the job's role family when that resume is approved and accepted by
   * the form; otherwise the approved resume with the most description-term overlap.
   */
  choose(job: Job, snapshot?: FormSnapshot, classification?: JobClassification, familySlots: Record<string, number> = {}): VariantChoice | undefined {
    const wanted = terms(`${job.title} ${job.description}`.slice(0, 50000)), families = familyFor(job);
    const resumeField = snapshot?.fields.find(field => field.type === "file" && /resume|résumé|\bcv\b/i.test(`${field.key} ${field.label}`));
    const accept = resumeField?.accept?.map(value => value.toLowerCase()) ?? [];
    const acceptable = (variant: ResumeVariant) => {
      const extension = `.${variant.artifact.format}`;
      const mime = variant.artifact.format === "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
      return !accept.length || accept.includes(extension) || accept.includes(mime) || accept.includes("*/*") || accept.includes("application/*");
    };
    const slot = classification?.familyId ? familySlots[classification.familyId] : undefined;
    const assigned = slot ? this.approvedVariants().find(variant => variant.slot === slot && acceptable(variant)) : undefined;
    if (assigned) return { variant: assigned, score: 1000, reason: `${assigned.label} (slot ${slot}) is your resume for ${classification!.familyLabel} roles. Uploaded bytes are unchanged.` };
    const choices: VariantChoice[] = [];
    for (const variant of this.approvedVariants()) {
      if (!acceptable(variant)) continue;
      const overlap = [...terms(this.stored(variant.id)!.text)].filter(term => wanted.has(term));
      const familyMatch = variant.families.some(family => families.includes(family));
      const score = overlap.length + (familyMatch ? 20 : variant.families.includes("hybrid") ? 5 : 0);
      choices.push({ variant, score, reason: `${variant.label}: ${overlap.length} text-term overlaps${familyMatch ? ", matching role family" : ""}. Uploaded bytes are unchanged.` });
    }
    return choices.sort((a, b) => b.score - a.score || a.variant.slot - b.variant.slot)[0];
  }
}
