import { DatabaseSync } from "node:sqlite";
import { mkdirSync, chmodSync } from "node:fs";
import { dirname } from "node:path";
import { randomUUID } from "node:crypto";
import type { Job, Packet, Profile, PreparationTask, ExternalApplication } from "../../packages/domain/types.js";
import { emptyProfile } from "../../packages/domain/types.js";

export function jobIdentity(job: Job): string {
  const application = new URL(job.applyUrl);
  const greenhouseHost = ["boards.greenhouse.io", "job-boards.greenhouse.io", "boards.eu.greenhouse.io", "job-boards.eu.greenhouse.io"].includes(application.hostname);
  const greenhouseId = (greenhouseHost || ["automattic.com", "canonical.com"].includes(application.hostname) ? application.searchParams.get("gh_jid") : undefined)
    ?? (greenhouseHost ? application.pathname.match(/\/jobs\/(\d+)/)?.[1] : undefined);
  if (greenhouseId && /^\d+$/.test(greenhouseId)) return `greenhouse:${greenhouseId}`;
  const ashby = application.hostname === "jobs.ashbyhq.com" ? application.pathname.match(/^\/([^/]+)\/([a-f0-9-]{36})(?:\/application)?\/?$/i) : null;
  if (ashby) return `ashby:${ashby[1]!.toLowerCase()}:${ashby[2]!.toLowerCase()}`;
  const lever = /^(jobs|jobs\.eu)\.lever\.co$/.test(application.hostname) ? application.pathname.match(/^\/([^/]+)\/([a-f0-9-]{36})(?:\/apply)?\/?$/i) : null;
  if (lever) return `lever:${application.hostname}:${lever[1]!.toLowerCase()}:${lever[2]!.toLowerCase()}`;
  // A posting page and its application page (or a board's own apply host) are one job.
  for (const raw of [job.applyUrl, job.canonicalUrl]) {
    const url = new URL(raw), host = url.hostname, path = url.pathname;
    const smart = host === "jobs.smartrecruiters.com" ? path.match(/^\/([^/]+)\/(\d{6,20})(?:-[^/]*)?\/?$/) : null;
    if (smart) return `smartrecruiters:${smart[1]!.toLowerCase()}:${smart[2]}`;
    const workday = /\.myworkdayjobs\.com$|^wd\d+\.myworkdaysite\.com$/.test(host) ? path.match(/\/job\/(?:[^/]+\/)*[^/]*_([A-Za-z0-9-]{3,40})(?:\/apply(?:\/.*)?)?\/?$/) : null;
    if (workday) return `workday:${host}:${workday[1]!.toUpperCase()}`;
    const eightfold = host.endsWith(".eightfold.ai") ? path.match(/^\/careers\/job\/(\d{3,20})/) : null;
    if (eightfold) return `eightfold:${host}:${eightfold[1]}`;
    const oracle = host.endsWith(".oraclecloud.com") ? path.match(/\/sites\/([A-Za-z0-9_-]+)\/job\/(\d{1,20})/) : null;
    if (oracle) return `oracle:${host}:${oracle[1]}:${oracle[2]}`;
    const rippling = host === "ats.rippling.com" ? path.match(/^\/([^/]+)\/jobs\/([a-f0-9-]{36})/i) : null;
    if (rippling) return `rippling:${rippling[1]!.toLowerCase()}:${rippling[2]!.toLowerCase()}`;
    const google = host === "www.google.com" ? path.match(/^\/about\/careers\/applications\/jobs\/results\/(\d{5,25})(?:-|\/|$)/) : null;
    if (google) return `google:${google[1]}`;
    const apple = host === "jobs.apple.com" ? path.match(/^\/(?:app\/)?(?:[a-z]{2}-[a-z]{2}\/)?(?:details|apply)\/(\d{6,12})(?:-\d{1,6})?(?:\/|$)/i) : null;
    if (apple) return `apple:${apple[1]}`;
    const icims = host.endsWith(".icims.com") ? path.match(/^\/jobs\/(\d{1,12})(?:\/|$)/) : null;
    if (icims) return `icims:${host.split(".")[0]!.replace(/^(?:careers|globalcareers|jobs)-(?:[a-z]{2,6}-)?/, "")}:${icims[1]}`;
    const atlassian = host === "www.atlassian.com" ? path.match(/^\/company\/careers\/details\/(\d{1,12})/) : null;
    if (atlassian) return `icims:atlassian:${atlassian[1]}`;
    const nutanix = host === "careers.nutanix.com" ? path.match(/\/jobs\/(\d{1,12})(?:\/|$)/) : null;
    if (nutanix) return `nutanix:${nutanix[1]}`;
  }
  const url = new URL(job.canonicalUrl);
  for (const key of [...url.searchParams.keys()]) if (/^utm_|^(ref|source|gh_src|lever-source)$/.test(key)) url.searchParams.delete(key);
  url.searchParams.sort(); url.hash = "";
  return `${job.company.trim().toLowerCase()}|${url.toString()}`;
}

export class Store {
  readonly db: DatabaseSync;
  readonly sessionId = randomUUID();
  constructor(path: string) {
    if (path !== ":memory:") mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
    this.db = new DatabaseSync(path);
    this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
      CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, identity TEXT UNIQUE NOT NULL, json TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS packets(id TEXT PRIMARY KEY, job_id TEXT NOT NULL, json TEXT NOT NULL);
      CREATE INDEX IF NOT EXISTS packets_job ON packets(job_id);
      CREATE TABLE IF NOT EXISTS runs(packet_id TEXT PRIMARY KEY, job_id TEXT UNIQUE NOT NULL, source_id TEXT NOT NULL, token TEXT NOT NULL, day TEXT NOT NULL, status TEXT NOT NULL);
      CREATE INDEX IF NOT EXISTS runs_day ON runs(day);
      CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, packet_id TEXT, type TEXT NOT NULL, detail TEXT NOT NULL, created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS preparation(id TEXT PRIMARY KEY, job_id TEXT NOT NULL, profile_hash TEXT NOT NULL, mode TEXT NOT NULL, status TEXT NOT NULL, json TEXT NOT NULL);
      CREATE INDEX IF NOT EXISTS preparation_pending ON preparation(status);
      CREATE INDEX IF NOT EXISTS preparation_job ON preparation(job_id,profile_hash,mode);
      CREATE INDEX IF NOT EXISTS packets_status ON packets(json_extract(json,'$.status'));
      CREATE INDEX IF NOT EXISTS events_packet_type ON events(packet_id,type);
      CREATE TABLE IF NOT EXISTS external_applications(id TEXT PRIMARY KEY,job_id TEXT UNIQUE NOT NULL,json TEXT NOT NULL);
    `);
    const runColumns = new Set(this.db.prepare("PRAGMA table_info(runs)").all().map(column => String(column.name)));
    if (!runColumns.has("session_id")) this.db.exec("ALTER TABLE runs ADD COLUMN session_id TEXT NOT NULL DEFAULT 'legacy'");
    if (!runColumns.has("started_at")) this.db.exec("ALTER TABLE runs ADD COLUMN started_at TEXT");
    this.db.exec("CREATE INDEX IF NOT EXISTS runs_session ON runs(session_id)");
    if (!this.value("migration:uncapped-v2", false)) {
      this.transaction(() => {
        const profile = this.value<Profile | null>("profile", null);
        if (profile?.preferences.dailyLimit === 200) {
          profile.preferences.dailyLimit = null;
          profile.version++;
          this.set("profile", profile);
          this.event(null, "limit_removed", "Removed the old default daily ceiling. Existing profile-bound approvals require review.");
        }
        this.set("migration:uncapped-v2", true);
      });
    }
    if (path !== ":memory:") chmodSync(path, 0o600);
  }
  value<T>(key: string, fallback: T): T {
    const row = this.db.prepare("SELECT value FROM settings WHERE key=?").get(key);
    return row ? JSON.parse(String(row.value)) as T : fallback;
  }
  set(key: string, value: unknown): void {
    this.db.prepare("INSERT INTO settings VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(key, JSON.stringify(value));
  }
  profile(): Profile { return this.value("profile", emptyProfile()); }
  jobs(limit?: number): Job[] {
    const rows = limit === undefined ? this.db.prepare("SELECT json FROM jobs ORDER BY rowid DESC").all()
      : this.db.prepare("SELECT json FROM jobs ORDER BY rowid DESC LIMIT ?").all(limit);
    return rows.map(r => JSON.parse(String(r.json)) as Job);
  }
  jobCount(): number { return Number(this.db.prepare("SELECT count(*) AS n FROM jobs").get()?.n ?? 0); }
  job(id: string): Job | undefined {
    const row = this.db.prepare("SELECT json FROM jobs WHERE id=?").get(id);
    return row ? JSON.parse(String(row.json)) as Job : undefined;
  }
  saveJob(job: Job): Job {
    const identity = jobIdentity(job);
    const existing = this.db.prepare("SELECT id,json FROM jobs WHERE identity=? OR id=?").get(identity, job.id);
    const previous = existing ? JSON.parse(String(existing.json)) as Job : undefined;
    const careerSourceIds = [...new Set([...(previous?.careerSourceIds ?? []), ...(job.careerSourceIds ?? [])])];
    const preserveBuiltin = job.sourceId.startsWith("career-") && previous && !previous.sourceId.startsWith("career-");
    const persisted = {
      ...job, ...(existing ? { id: String(existing.id) } : {}),
      ...(preserveBuiltin ? { sourceId: previous.sourceId, sourceJobId: previous.sourceJobId, company: previous.company } : {}),
      ...(careerSourceIds.length ? { careerSourceIds } : {})
    };
    this.db.prepare("INSERT INTO jobs VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET json=excluded.json,identity=excluded.identity")
      .run(persisted.id, identity, JSON.stringify(persisted));
    return persisted;
  }
  packets(limit?: number): Packet[] {
    const rows = limit === undefined ? this.db.prepare("SELECT json FROM packets ORDER BY rowid DESC").all()
      : this.db.prepare("SELECT json FROM packets ORDER BY rowid DESC LIMIT ?").all(limit);
    return rows.map(r => JSON.parse(String(r.json)) as Packet);
  }
  packetCount(): number { return Number(this.db.prepare("SELECT count(*) AS n FROM packets").get()?.n ?? 0); }
  packetsForJob(id: string): Packet[] {
    return this.db.prepare("SELECT json FROM packets WHERE job_id=? ORDER BY rowid DESC").all(id).map(row => JSON.parse(String(row.json)) as Packet);
  }
  packetsWithStatus(status: string): Packet[] {
    return this.db.prepare("SELECT json FROM packets WHERE json_extract(json,'$.status')=? ORDER BY rowid DESC").all(status).map(row => JSON.parse(String(row.json)) as Packet);
  }
  hasConflictingApplication(jobId: string, excludedId = ""): boolean {
    return Boolean(this.db.prepare("SELECT 1 FROM packets WHERE job_id=? AND id!=? AND json_extract(json,'$.status') IN ('executing','awaiting_human','submitted_confirmed','submission_unknown') LIMIT 1").get(jobId, excludedId))
      || Boolean(this.db.prepare("SELECT 1 FROM external_applications WHERE job_id=? AND id!=?").get(jobId, excludedId));
  }
  externalApplications(limit?: number, offset = 0): ExternalApplication[] {
    const rows = limit === undefined ? this.db.prepare("SELECT json FROM external_applications ORDER BY rowid DESC").all()
      : this.db.prepare("SELECT json FROM external_applications ORDER BY rowid DESC LIMIT ? OFFSET ?").all(limit, offset);
    return rows.map(row => JSON.parse(String(row.json)) as ExternalApplication);
  }
  externalApplication(id: string): ExternalApplication | undefined {
    const row = this.db.prepare("SELECT json FROM external_applications WHERE id=?").get(id);
    return row ? JSON.parse(String(row.json)) as ExternalApplication : undefined;
  }
  externalCount(): number { return Number(this.db.prepare("SELECT count(*) AS n FROM external_applications").get()?.n ?? 0); }
  extensionPackets(): Packet[] {
    return this.db.prepare(`SELECT json FROM packets WHERE json_extract(json,'$.status') IN ('prepared','approved','manual_only','executing','submission_unknown')
      ORDER BY CASE json_extract(json,'$.status') WHEN 'executing' THEN 0 WHEN 'approved' THEN 1 WHEN 'submission_unknown' THEN 2 WHEN 'prepared' THEN 3 ELSE 4 END,rowid LIMIT 1000`)
      .all().map(row => JSON.parse(String(row.json)) as Packet);
  }
  putExternal(application: ExternalApplication): void {
    this.db.prepare("INSERT INTO external_applications VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET json=excluded.json").run(application.id, application.jobId, JSON.stringify(application));
  }
  confirmedCount(): number {
    return Number(this.db.prepare("SELECT count(*) AS n FROM (SELECT job_id FROM packets WHERE json_extract(json,'$.status')='submitted_confirmed' UNION SELECT job_id FROM external_applications)").get()?.n ?? 0);
  }
  packetSummaries(): { id: string; jobId: string; status: string; submittedAt?: string; stage?: string; nextActionDate?: string; sourceId: string }[] {
    const packets = this.db.prepare(`SELECT p.id,p.job_id,json_extract(p.json,'$.status') AS status,
      json_extract(p.json,'$.submittedAt') AS submitted_at,json_extract(p.json,'$.progress.stage') AS stage,
      json_extract(p.json,'$.progress.nextActionDate') AS next_action,
      COALESCE(json_extract(p.json,'$.sourceId'),json_extract(j.json,'$.sourceId')) AS source_id FROM packets p LEFT JOIN jobs j ON j.id=p.job_id`).all().map(row => ({
      id: String(row.id), jobId: String(row.job_id), status: String(row.status),
      ...(typeof row.submitted_at === "string" ? { submittedAt: row.submitted_at } : {}),
      ...(typeof row.stage === "string" ? { stage: row.stage } : {}),
      ...(typeof row.next_action === "string" ? { nextActionDate: row.next_action } : {}),
      sourceId: typeof row.source_id === "string" ? row.source_id : "unknown"
    }));
    const external = this.db.prepare(`SELECT id,job_id,json_extract(json,'$.submittedDate') AS submitted_date,
      json_extract(json,'$.progress.stage') AS stage,json_extract(json,'$.progress.nextActionDate') AS next_action,
      json_extract(json,'$.sourceId') AS source_id FROM external_applications`).all().map(row => ({
      id: String(row.id), jobId: String(row.job_id), status: "submitted_confirmed", submittedAt: String(row.submitted_date),
      stage: String(row.stage), ...(typeof row.next_action === "string" ? { nextActionDate: row.next_action } : {}),
      sourceId: String(row.source_id)
    }));
    return [...packets, ...external];
  }
  packet(id: string): Packet | undefined {
    const row = this.db.prepare("SELECT json FROM packets WHERE id=?").get(id);
    return row ? JSON.parse(String(row.json)) as Packet : undefined;
  }
  putPacket(packet: Packet): void {
    this.db.prepare("INSERT INTO packets VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET json=excluded.json").run(packet.id, packet.jobId, JSON.stringify(packet));
  }
  event(packetId: string | null, type: string, detail: string): void {
    this.db.prepare("INSERT INTO events(packet_id,type,detail,created_at) VALUES (?,?,?,?)").run(packetId, type, detail, new Date().toISOString());
  }
  attempts(day: string, sourceId?: string): number {
    const row = sourceId
      ? this.db.prepare("SELECT count(*) AS n FROM runs WHERE day=? AND source_id=?").get(day, sourceId)
      : this.db.prepare("SELECT count(*) AS n FROM runs WHERE day=?").get(day);
    const carry = this.value<{ day: string; total: number; sources: Record<string, number> }>("attemptCarry", { day: "", total: 0, sources: {} });
    return Number(row?.n ?? 0) + (carry.day === day ? (sourceId ? carry.sources[sourceId] ?? 0 : carry.total) : 0);
  }
  attemptsSession(): number {
    return Number(this.db.prepare("SELECT count(*) AS n FROM runs WHERE session_id=?").get(this.sessionId)?.n ?? 0);
  }
  preparationTasks(limit = 500): PreparationTask[] {
    return this.db.prepare("SELECT json FROM preparation ORDER BY CASE status WHEN 'running' THEN 0 WHEN 'failed' THEN 1 WHEN 'queued' THEN 2 ELSE 3 END,rowid DESC LIMIT ?").all(limit).map(row => JSON.parse(String(row.json)) as PreparationTask);
  }
  preparationSummary(): Record<PreparationTask["status"], number> {
    const result = { queued: 0, running: 0, completed: 0, failed: 0, cancelled: 0 };
    for (const row of this.db.prepare("SELECT status,count(*) AS n FROM preparation GROUP BY status").all()) {
      const status = String(row.status);
      if (status === "queued" || status === "running" || status === "completed" || status === "failed" || status === "cancelled") result[status] = Number(row.n);
    }
    return result;
  }
  preparationForJob(jobId: string, hash: string, mode: string): PreparationTask[] {
    return this.db.prepare("SELECT json FROM preparation WHERE job_id=? AND profile_hash=? AND mode=? ORDER BY rowid DESC LIMIT 20")
      .all(jobId, hash, mode).map(row => JSON.parse(String(row.json)) as PreparationTask);
  }
  nextPreparation(): PreparationTask | undefined {
    const row = this.db.prepare("SELECT json FROM preparation WHERE status='queued' ORDER BY rowid LIMIT 1").get();
    return row ? JSON.parse(String(row.json)) as PreparationTask : undefined;
  }
  preparationWithStatus(status: string): PreparationTask[] {
    return this.db.prepare("SELECT json FROM preparation WHERE status=? ORDER BY rowid").all(status).map(row => JSON.parse(String(row.json)) as PreparationTask);
  }
  putPreparation(task: PreparationTask): void {
    this.db.prepare("INSERT INTO preparation VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,json=excluded.json")
      .run(task.id, task.jobId, task.profileHash, task.mode, task.status, JSON.stringify(task));
  }
  transaction<T>(fn: () => T): T {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const result = fn();
      this.db.exec("COMMIT");
      return result;
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }
  recover(): void {
    for (const packet of [...this.packetsWithStatus("executing"), ...this.packetsWithStatus("awaiting_human")]) {
      if (packet.status === "executing" || packet.status === "awaiting_human") {
        packet.status = "submission_unknown";
        packet.error = "Local service restarted during execution. Reconcile before any further action.";
        this.putPacket(packet);
        this.db.prepare("UPDATE runs SET status='submission_unknown' WHERE packet_id=?").run(packet.id);
        this.event(packet.id, "submission_unknown", packet.error);
      }
    }
  }
  close(): void { this.db.close(); }
}
