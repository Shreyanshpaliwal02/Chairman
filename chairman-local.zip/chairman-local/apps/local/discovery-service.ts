import { SOURCES, getSourceCooldownMs, LOCAL_ONLY_SOURCE_IDS } from "../../packages/adapters/sources.js";
import { DiscoveryError, scanSource, syncCloudJobs } from "../../packages/adapters/discovery.js";
import type { ScanResult, Source } from "../../packages/domain/types.js";
import { Store } from "./store.js";
import { scanPreferredJobs } from "../../packages/adapters/preferred-search.js";
import { digest } from "../../packages/domain/matching.js";
import type { Preferences } from "../../packages/domain/types.js";
import type { ConfiguredSource } from "../../packages/domain/discovery-settings.js";
import { z } from "zod";

interface Result { sourceId: string; count?: number; error?: string; }
interface DiscoveryOptions {
  cloudUrl?: string;
  cloudToken?: string;
  scanner?: typeof scanSource;
  cloudSync?: typeof syncCloudJobs;
}
export class DiscoveryService {
  private busy = false;
  private timer?: ReturnType<typeof setInterval>;
  private initial?: ReturnType<typeof setTimeout>;
  private pending?: Promise<void>;
  private preferredPending = false;
  constructor(private store: Store, private options: DiscoveryOptions = {}) {}
  sources(): ConfiguredSource[] {
    const health = this.store.value<Record<string, Partial<Source>>>("sourceHealth", {});
    const preferences = this.store.value<Record<string, boolean>>("discoveryPreferences", {});
    return SOURCES.map(source => {
      const status = health[source.id];
      const discoveryEnabled = source.discoveryAllowed && source.mode === "enabled" && preferences[source.id] !== false;
      const nextScan = this.store.value(`nextScan:${source.id}`, 0);
      return {
        ...source, discoveryEnabled,
        mode: status?.mode === "blocked" ? "blocked" : source.mode === "enabled" && !discoveryEnabled ? "paused" : source.mode,
        lastScannedAt: status?.lastScannedAt, lastError: status?.lastError, count: status?.count,
        ...(nextScan > 0 ? { nextScanAt: new Date(nextScan).toISOString() } : {}),
      };
    });
  }
  preferences() {
    return { sources: this.sources().filter(source => source.discoveryAllowed && SOURCES.find(base => base.id === source.id)?.mode === "enabled")
      .map(source => ({ sourceId: source.id, enabled: source.discoveryEnabled === true })) };
  }
  setPreference(body: unknown) {
    const input = z.object({ sourceId: z.string().min(1), enabled: z.boolean() }).strict().parse(body);
    const source = SOURCES.find(source => source.id === input.sourceId);
    if (!source?.discoveryAllowed || source.mode !== "enabled") throw new Error("This source has no reviewed public discovery interface. Manual portals cannot be enabled.");
    const preferences = this.store.value<Record<string, boolean>>("discoveryPreferences", {});
    const changed = (preferences[source.id] !== false) !== input.enabled;
    if (changed) {
      this.store.set("discoveryPreferences", { ...preferences, [source.id]: input.enabled });
      this.store.event(null, "discovery_preference_changed", `${source.id}: public discovery ${input.enabled ? "enabled" : "paused"}. Source permissions and cooldowns unchanged.`);
    }
    return { ...this.preferences(), changed };
  }
  private savePage(sourceId: string, page: ScanResult, checkpoint: string) {
    this.store.transaction(() => {
      for (const job of page.jobs) this.store.saveJob({
        ...job, cacheExpired: false,
        cacheExpiresAt: new Date(Date.now() + (job.sourceId === "arbeitnow" ? 86400_000 : 30 * 86400_000)).toISOString()
      });
      this.store.set(checkpoint, page.nextCursor ?? null);
      const health = this.store.value<Record<string, Partial<Source>>>("sourceHealth", {});
      health[sourceId] = { lastScannedAt: new Date().toISOString(), count: page.jobs.length };
      this.store.set("sourceHealth", health);
    });
  }
  private fail(sourceId: string, error: unknown): string {
    const message = error instanceof Error ? error.message : "Discovery failed unexpectedly.";
    const detail = error instanceof DiscoveryError ? `${error.code}${error.httpStatus ? ` (${error.httpStatus})` : ""}: ${message}` : message;
    const health = this.store.value<Record<string, Partial<Source>>>("sourceHealth", {});
    const permissionBlocked = SOURCES.some(source => source.id === sourceId) && error instanceof DiscoveryError && [401, 403].includes(error.httpStatus ?? 0);
    health[sourceId] = { ...health[sourceId], lastError: detail, ...(permissionBlocked ? { mode: "blocked" as const } : {}) };
    this.store.set("sourceHealth", health);
    if (permissionBlocked) this.cleanupCache(sourceId);
    const delay = error instanceof DiscoveryError && error.code === "TOO_LARGE" ? 86400_000
      : Math.max(300_000, error instanceof DiscoveryError ? error.retryAfterMs ?? 0 : 0);
    this.store.set(`nextScan:${sourceId}`, Math.max(this.store.value(`nextScan:${sourceId}`, 0), Date.now() + delay, Date.now() + getSourceCooldownMs(sourceId)));
    return detail;
  }
  private async cloud(): Promise<Result> {
    const { cloudUrl, cloudToken } = this.options;
    if (!cloudUrl || !cloudToken) throw new Error("Both cloud scanner URL and sync token are required.");
    const checkpoint = `cloudCursor:${cloudUrl}`;
    let count = 0, restarted = false;
    for (let n = 0; n < 10; n++) {
      if (!this.sources().some(source => source.discoveryEnabled && source.mode === "enabled")) break;
      const cursor = this.store.value<string | null>(checkpoint, null) ?? undefined;
      let page: ScanResult;
      try {
        page = await (this.options.cloudSync ?? syncCloudJobs)(cloudUrl, cloudToken, cursor);
      } catch (error) {
        if (error instanceof DiscoveryError && error.httpStatus === 409 && !restarted) {
          this.store.set(checkpoint, null);
          this.store.event(null, "cloud_cursor_reset", "Public scanner retention invalidated the old checkpoint; restarting sync.");
          restarted = true; continue;
        }
        throw error;
      }
      if (page.jobs.some(job => LOCAL_ONLY_SOURCE_IDS.some(id => id === job.sourceId)))
        throw new DiscoveryError("INVALID_DATA", "A local-only source was returned by the cloud scanner; refusing to mirror it.");
      const enabled = new Set(this.sources().filter(source => source.discoveryEnabled && source.mode === "enabled").map(source => source.id));
      const permitted = page.jobs.filter(job => enabled.has(job.sourceId));
      this.savePage("cloud", { ...page, jobs: permitted }, checkpoint);
      count += permitted.length;
      if (!page.jobs.length) break;
    }
    return { sourceId: "cloud", count };
  }
  async scan(sourceId?: string): Promise<{ results: Result[] }> {
    if (this.busy) throw new Error("A discovery scan is already running.");
    const effectiveSources = this.sources();
    const sources = sourceId ? effectiveSources.filter(s => s.id === sourceId) : effectiveSources.filter(s => s.mode === "enabled" && s.discoveryAllowed);
    if (!sources.length) {
      if (sourceId) throw new Error("No source matched. Review source coverage.");
      return { results: [{ sourceId: "discovery", count: 0, error: "No public feeds are enabled. Review source preferences; no request was made." }] };
    }
    this.busy = true;
    const results: Result[] = [];
    try {
      if (!sourceId && (this.options.cloudUrl || this.options.cloudToken)) {
        if (this.store.value("nextScan:cloud", 0) > Date.now()) results.push({ sourceId: "cloud", error: "Cloud synchronization is in backoff; see source health." });
        else {
          try { results.push(await this.cloud()); }
          catch (error) { results.push({ sourceId: "cloud", error: this.fail("cloud", error) }); }
        }
      }
      for (const source of sources) {
        const current = this.sources().find(item => item.id === source.id);
        if (!current?.discoveryAllowed || current.mode !== "enabled" || !current.discoveryEnabled) {
          results.push({ sourceId: source.id, error: "This source is manual-only or not enabled. No request was made." }); continue;
        }
        const reserved = this.store.transaction(() => {
          const now = Date.now(), next = this.store.value(`nextScan:${source.id}`, 0);
          if (next > now) return { allowed: false, next };
          const cooldown = Math.max(60_000, getSourceCooldownMs(source.id));
          this.store.set(`nextScan:${source.id}`, now + cooldown);
          return { allowed: true, next: now + cooldown };
        });
        if (!reserved.allowed) { results.push({ sourceId: source.id, error: `Source cooldown: next scan after ${new Date(reserved.next).toISOString()}.` }); continue; }
        try {
          const checkpoint = `cursor:${source.id}`;
          const cursor = this.store.value<string | null>(checkpoint, null) ?? undefined;
          const page = await (this.options.scanner ?? scanSource)(source.id, cursor, undefined, { timeoutMs: 15_000 });
          if (!this.sources().some(item => item.id === source.id && item.discoveryEnabled && item.mode === "enabled")) {
            results.push({ sourceId: source.id, error: "Source was paused while its request was in flight. Response discarded; cooldown retained." }); continue;
          }
          this.savePage(source.id, page, checkpoint);
          results.push({ sourceId: source.id, count: page.jobs.length });
        } catch (error) { results.push({ sourceId: source.id, error: this.fail(source.id, error) }); }
      }
      this.store.set("lastDiscovery", { at: new Date().toISOString(), results });
      this.cleanupCache();
      return { results };
    } finally { this.busy = false; }
  }
  async scanPreferred(preferences: Pick<Preferences, "roles" | "countries">): Promise<string> {
    const source = this.sources().find(source => source.id === "himalayas");
    if (!source?.discoveryEnabled || source.mode !== "enabled") return "Preferred-job search is paused because Himalayas public discovery is disabled or blocked.";
    if (this.preferredPending) return "A role-preference search is already running.";
    const now = Date.now(), next = this.store.value("nextScan:preferred-search", 0);
    if (next > now) return `Preferred-job search is cooling down until ${new Date(next).toISOString()}.`;
    this.preferredPending = true; this.store.set("nextScan:preferred-search", now + 15 * 60_000);
    const checkpoint = `preferredCursor:${digest(preferences)}`;
    try {
      const result = await scanPreferredJobs(preferences, this.store.value<string | null>(checkpoint, null) ?? undefined);
      if (!this.sources().some(source => source.id === "himalayas" && source.discoveryEnabled && source.mode === "enabled"))
        return "Himalayas was paused during the preferred-job search. Response discarded; cooldown retained.";
      this.savePage("himalayas-preferred", result, checkpoint);
      return `Imported ${result.jobs.length} jobs from a bounded public API search for your role preferences. Other sources and career pages continue on their own schedules.`;
    } catch (error) {
      const message = this.fail("preferred-search", error);
      throw new Error(`Preferred-job search: ${message}`);
    } finally { this.preferredPending = false; }
  }
  start(): void {
    const run = () => {
      if (this.busy) return;
      this.pending = this.scan().then(() => undefined).catch(error => {
        this.store.set("lastDiscovery", { at: new Date().toISOString(), error: this.fail("scheduler", error) });
      });
    };
    this.initial = setTimeout(run, 1000); this.initial.unref();
    this.timer = setInterval(run, 15 * 60_000); this.timer.unref();
  }
  cleanupCache(sourceId?: string): void {
    const now = new Date().toISOString(), cutoff = new Date(Date.now() - 30 * 86400_000).toISOString();
    const condition = sourceId
      ? "json_extract(json,'$.sourceId')=?"
      : "(json_extract(json,'$.cacheExpiresAt')<=? OR json_extract(json,'$.fetchedAt')<?)";
    const args = sourceId ? [sourceId] : [now, cutoff];
    this.store.transaction(() => {
      this.store.db.prepare(`DELETE FROM jobs WHERE ${condition} AND NOT EXISTS (SELECT 1 FROM packets WHERE packets.job_id=jobs.id) AND NOT EXISTS (SELECT 1 FROM external_applications WHERE external_applications.job_id=jobs.id)`).run(...args);
      this.store.db.prepare(`UPDATE jobs SET json=json_set(json,'$.description','','$.cacheExpired',json('true')) WHERE ${condition} AND COALESCE(json_extract(json,'$.cacheExpired'),0)=0`).run(...args);
    });
  }
  async stop(): Promise<void> {
    clearTimeout(this.initial); clearInterval(this.timer); await this.pending;
    this.cleanupCache("arbeitnow");
  }
}
