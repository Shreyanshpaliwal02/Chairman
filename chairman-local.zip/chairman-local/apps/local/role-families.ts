import { z } from "zod";
import { classifyJob, DEFAULT_ROLE_FAMILIES, MAX_RESUME_SLOTS, type JobClassification, type RoleFamily } from "../../packages/domain/role-families.js";
import type { Job } from "../../packages/domain/types.js";
import type { CareerSourceService } from "./career-sources.js";
import { Store } from "./store.js";

const keywords = z.array(z.string().trim().min(1).max(80)).max(60).transform(list => [...new Set(list.map(item => item.toLowerCase()))]);
export const roleFamilySchema = z.object({
  id: z.string().trim().regex(/^[a-z0-9][a-z0-9-]{0,47}$/, "Use lowercase letters, digits and dashes for the family id."),
  label: z.string().trim().min(1).max(80),
  titleKeywords: keywords.refine(list => list.length > 0, "Add at least one title keyword."),
  skillKeywords: keywords, excludeKeywords: keywords,
  alwaysApply: z.boolean(),
  resumeSlot: z.number().int().min(1).max(MAX_RESUME_SLOTS).optional(),
  minSkillMatches: z.number().int().min(0).max(20),
}).strict();
export const roleFamiliesSchema = z.array(roleFamilySchema).min(1).max(20)
  .refine(list => new Set(list.map(family => family.id)).size === list.length, "Each role family needs a unique id.");

export class RoleFamilyService {
  constructor(readonly store: Store, readonly careerSources?: CareerSourceService) {}
  list(): RoleFamily[] { return this.store.value<RoleFamily[]>("role-families", DEFAULT_ROLE_FAMILIES); }
  save(input: unknown): RoleFamily[] {
    const families = roleFamiliesSchema.parse(input);
    this.store.set("role-families", families);
    this.store.event(null, "role_families_saved", `Role families updated (${families.length}); Auto Apply must be re-authorized for the new scope.`);
    return families;
  }
  reset(): RoleFamily[] { return this.save(DEFAULT_ROLE_FAMILIES); }
  /** Families you apply to for this job: always-apply families plus those picked for the job's companies. */
  interest(job: Job): Set<string> {
    const ids = new Set(this.list().filter(family => family.alwaysApply).map(family => family.id));
    const sources = job.careerSourceIds ?? (job.sourceId.startsWith("career-") ? [job.sourceId] : []);
    if (sources.length && this.careerSources) for (const source of this.careerSources.list())
      if (sources.includes(source.id)) for (const id of source.roleFamilies ?? []) ids.add(id);
    return ids;
  }
  classify(job: Job): JobClassification { return classifyJob(job, this.list(), this.interest(job)); }
  /** Title-only check used while crawling: the title matches one of your role families and none of its exclusions. */
  titleRelevant(title: string): boolean { return classifyJob({ title, description: "" }, this.list()).relevant; }
  /** Search phrases for boards too large to list fully: your families' title keywords, most specific first. */
  queries(): string[] {
    return [...new Set(this.list().flatMap(family => family.titleKeywords).map(keyword => keyword.toLowerCase().trim()).filter(keyword => keyword.length >= 3))]
      .sort((a, b) => b.split(" ").length - a.split(" ").length || b.length - a.length).slice(0, 30);
  }
}
