import { randomUUID, randomBytes, createHash } from "node:crypto";
import { chmod, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { linkOrCopyArtifact } from "./artifact-storage.js";
import { join, basename } from "node:path";
import { digest, jobHash, matchJob, prohibitsAi } from "../../packages/domain/matching.js";
import type { Artifact, FormSnapshot, Job, Packet, ResumeVariant } from "../../packages/domain/types.js";
import { MAX_APPROVAL_BATCH_SIZE } from "../../packages/domain/types.js";
import { localDate as today } from "../../packages/domain/dates.js";
import { createDocuments, createTailoredResume, selectResume, validateTailoredContent } from "../../packages/documents/index.js";
import { automationPolicy, type ReviewedPolicy } from "./policies.js";
import { Store } from "./store.js";
import { hasNoAiRestriction } from "../../packages/documents/safety.js";

export { today };
export function snapshotHash(snapshot: FormSnapshot): string {
  return digest({ url: snapshot.url, fields: snapshot.fields, hasCaptcha: snapshot.hasCaptcha, hasLegal: snapshot.hasLegal, unsupported: snapshot.unsupported });
}
export function packetHash(packet: Packet): string {
  return digest({ jobId: packet.jobId, jobHash: packet.jobHash, profileHash: packet.profileHash, profileVersion: packet.profileVersion,
    draft: packet.draft, artifacts: packet.artifacts, answers: packet.answers, formSnapshot: packet.formSnapshot,
    variantId: packet.variantId, authorizationId: packet.authorizationId, approvedBy: packet.approvedBy,
    tailoring: packet.tailoring, resumeContent: packet.resumeContent, submissionArtifactSha256: packet.submissionArtifactSha256,
    workflowSteps: packet.workflowSteps });
}
export interface ExecutionPermit {
  authorizationId: string;
  sourceLimit: number | null;
  assert: () => void;
  workflow?: boolean;
}

export class Engine {
  constructor(readonly store: Store, readonly dataDir: string, readonly policies: ReviewedPolicy[], readonly fixtureMode: boolean, readonly origin: string) {}
  policy(job: Job) { return automationPolicy(job, this.policies, this.fixtureMode, this.origin); }
  get(id: string): Packet {
    const packet = this.store.packet(id);
    if (!packet) throw new Error("Application packet not found.");
    return packet;
  }
  directory(id: string): string {
    if (!/^[a-zA-Z0-9-]+$/.test(id)) throw new Error("Invalid packet identifier.");
    return join(this.dataDir, "documents", id);
  }
  validate(packet: Packet): Job {
    const job = this.store.job(packet.jobId);
    if (!job) throw new Error("Job not found.");
    const profile = this.store.profile();
    if (!profile.confirmed || !profile.name.trim() || !profile.email) throw new Error("Confirm your complete factual profile first.");
    if (digest(profile) !== packet.profileHash || profile.version !== packet.profileVersion) throw new Error("Profile changed. Prepare a new packet and approve it again.");
    if (jobHash(job) !== packet.jobHash) throw new Error("Job changed. Prepare and approve a new packet.");
    if (job.aiPolicy === "prohibited" || prohibitsAi(job.description)) throw new Error("AI-restricted application: use human-authored material and apply manually.");
    if (packet.draft.mode === "jd-tailored") validateTailoredContent(profile, job, packet);
    const match = matchJob(profile, job);
    if (!match.eligible) throw new Error(match.blockers.join(" "));
    if (this.store.hasConflictingApplication(packet.jobId, packet.id))
      throw new Error("This job already has a submitted, executing or unresolved application. Reconcile it instead of applying again.");
    return job;
  }
  async prepareTailored(jobId: string, variant: ResumeVariant, bytes: Buffer, mode: "deterministic" | "local-ai", answers: Record<string, string> = {}, snapshot?: FormSnapshot): Promise<Packet> {
    const profile = this.store.profile(), job = this.store.job(jobId);
    if (!job || !profile.confirmed || !variant.approved || variant.issues.length) throw new Error("Confirm your profile and approve a valid base resume before tailoring.");
    const match = matchJob(profile, job);
    if (!match.eligible) throw new Error(match.blockers.join(" "));
    if (this.store.hasConflictingApplication(jobId)) throw new Error("An application already exists for this job; resolve it before preparing another.");
    if (createHash("sha256").update(bytes).digest("hex") !== variant.artifact.sha256 || bytes.length !== variant.artifact.bytes)
      throw new Error("The base template bytes changed after approval.");
    const cached = this.store.packetsForJob(jobId).find(packet => packet.status === "prepared" && packet.draft.mode === "jd-tailored"
      && packet.profileHash === digest(profile) && packet.jobHash === jobHash(job)
      && packet.tailoring?.baseVariantId === variant.id && packet.tailoring.baseVariantSha256 === variant.artifact.sha256
      && packet.tailoring.engine === mode && digest(packet.formSnapshot ?? null) === digest(snapshot ?? null)
      && digest(packet.answers) === digest({ ...profile.answers, ...answers }));
    if (cached) { this.validate(cached); await this.checkArtifacts(cached); return cached; }
    const id = randomUUID();
    try {
      const result = await createTailoredResume(profile, job, {
        id: variant.id, label: variant.label, sha256: variant.artifact.sha256,
        format: variant.artifact.format, bytes, approved: variant.approved
      }, this.directory(id), mode);
      const packet: Packet = {
        id, jobId, sourceId: job.sourceId, profileHash: digest(profile), profileVersion: profile.version, jobHash: jobHash(job),
        variantId: variant.id, draft: result.draft, artifacts: result.artifacts,
        tailoring: result.tailoring, resumeContent: result.content,
        answers: { ...profile.answers, ...answers }, formSnapshot: snapshot,
        warnings: [...match.warnings, ...result.tailoring.notes],
        status: "prepared", createdAt: new Date().toISOString()
      };
      this.validate(packet);
      this.store.transaction(() => {
        this.store.putPacket(packet);
        this.store.event(id, "jd_tailored", "Created job-specific PDF/DOCX from confirmed facts and an approved base template; no application sent.");
      });
      return packet;
    } catch (error) {
      await rm(this.directory(id), { recursive: true, force: true });
      throw error;
    }
  }
  submissionArtifact(packet: Packet): Artifact {
    const selected = packet.submissionArtifactSha256
      ? packet.artifacts.find(artifact => artifact.sha256 === packet.submissionArtifactSha256)
      : packet.artifacts.find(artifact => artifact.format === "pdf") ?? packet.artifacts[0];
    if (!selected) throw new Error("The packet has no valid selected submission artifact.");
    return selected;
  }
  private selectSubmissionArtifact(packet: Packet): void {
    const accepts = packet.formSnapshot?.fields.find(field => field.type === "file" && /resume|résumé|\bcv\b/i.test(`${field.key} ${field.label}`))?.accept?.map(value => value.toLowerCase()) ?? [];
    const compatible = packet.artifacts.filter(artifact => !accepts.length || accepts.includes(`.${artifact.format}`)
      || accepts.includes(artifact.format === "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
      || accepts.includes("*/*") || accepts.includes("application/*"));
    const selected = compatible.find(artifact => artifact.format === "pdf") ?? compatible[0];
    if (!selected) throw new Error("The form does not accept the generated/approved resume formats.");
    packet.submissionArtifactSha256 = selected.sha256;
  }
  async checkArtifacts(packet: Packet): Promise<void> {
    for (const artifact of packet.artifacts) {
      if (artifact.filename !== basename(artifact.filename)) throw new Error("Invalid document filename.");
      const bytes = await readFile(join(this.directory(packet.id), artifact.filename));
      if (bytes.byteLength !== artifact.bytes || createHash("sha256").update(bytes).digest("hex") !== artifact.sha256)
        throw new Error("Document bytes changed. Generate and approve a new packet.");
    }
    if (packet.draft.mode === "uploaded-variant") {
      if (!packet.variantId || packet.artifacts.length !== 1) throw new Error("The uploaded-variant packet must contain its one exact approved file.");
    } else if (!packet.artifacts.some(a => a.format === "pdf") || !packet.artifacts.some(a => a.format === "docx")) throw new Error("The packet is missing resume artifacts.");
  }
  async prepareUploaded(jobId: string, variant: ResumeVariant, bytes: Buffer, answers: Record<string, string>, snapshot: FormSnapshot, libraryPath?: string): Promise<Packet> {
    const profile = this.store.profile(), job = this.store.job(jobId);
    if (!job || !variant.approved || variant.issues.length) throw new Error("An eligible job and approved valid resume variant are required.");
    if (createHash("sha256").update(bytes).digest("hex") !== variant.artifact.sha256 || bytes.length !== variant.artifact.bytes)
      throw new Error("The selected variant bytes do not match the approved file.");
    const id = randomUUID(), directory = this.directory(id);
    await mkdir(directory, { recursive: true, mode: 0o700 });
    const artifact = { ...variant.artifact };
    if (libraryPath) {
      if (libraryPath !== join(this.dataDir, "resume-variants", variant.id, artifact.filename)) throw new Error("Unexpected library artifact path.");
      const storage = await linkOrCopyArtifact(libraryPath, join(directory, artifact.filename), bytes);
      if (storage === "copied") this.store.event(id, "artifact_copied", "Filesystem hard links were unavailable. Stored a separate immutable copy of the exact approved resume.");
    } else await writeFile(join(directory, artifact.filename), bytes, { flag: "wx", mode: 0o600 });
    await chmod(join(directory, artifact.filename), 0o400);
    const packet: Packet = {
      id, jobId, sourceId: job.sourceId, profileHash: digest(profile), profileVersion: profile.version, jobHash: jobHash(job),
      variantId: variant.id, draft: { mode: "uploaded-variant", factIds: [], skills: [], notes: [`Unchanged uploaded resume: ${variant.label} (slot ${variant.slot}). No claims or file content were generated.`] },
      artifacts: [artifact], answers, formSnapshot: snapshot, warnings: matchJob(profile, job).warnings,
      status: "prepared", createdAt: new Date().toISOString()
    };
    this.validate(packet);
    this.store.putPacket(packet);
    this.store.event(id, "variant_prepared", "Prepared an exact uploaded variant and factual answer plan. Nothing transmitted.");
    return packet;
  }
  async prepare(jobId: string, mode: "local-ai" | "deterministic", extraAnswers: Record<string, string> = {}): Promise<Packet> {
    const profile = this.store.profile(), job = this.store.job(jobId);
    if (!job) throw new Error("Job not found.");
    if (!profile.confirmed || !profile.name.trim() || !profile.email) throw new Error("Import and confirm your factual profile first.");
    const match = matchJob(profile, job);
    if (!match.eligible) throw new Error(match.blockers.join(" "));
    if (this.store.hasConflictingApplication(jobId))
      throw new Error("An application already exists for this job. Resolve its outcome before further action.");
    const draft = await selectResume(profile, job, mode);
    const id = randomUUID();
    const out = this.directory(id);
    await mkdir(out, { recursive: true, mode: 0o700 });
    const artifacts = await createDocuments(profile, job, draft, out);
    const packet: Packet = { id, jobId, sourceId: job.sourceId, profileVersion: profile.version, profileHash: digest(profile), jobHash: jobHash(job), draft, artifacts,
      answers: { ...profile.answers, ...extraAnswers }, warnings: [...match.warnings, ...draft.notes], status: "prepared", createdAt: new Date().toISOString() };
    this.validate(packet);
    this.store.putPacket(packet);
    this.store.event(id, "prepared", `Prepared ${mode} packet. No data sent to an employer.`);
    return packet;
  }
  preflight(id: string, snapshot: FormSnapshot): Packet {
    const packet = this.get(id), job = this.validate(packet);
    if (!["prepared", "approved", "manual_only", "withdrawn_from_queue"].includes(packet.status)) throw new Error("Packet cannot be preflighted in its current state.");
    if (!this.policy(job).allowed) throw new Error(this.policy(job).reason);
    if (snapshot.url !== job.applyUrl || snapshotHash(snapshot) !== snapshot.fingerprint) throw new Error("Form destination or structural fingerprint is invalid.");
    if (new Set(snapshot.fields.map(f => f.key)).size !== snapshot.fields.length) throw new Error("Form field identifiers are not unique.");
    const profile = this.store.profile();
    for (const field of snapshot.fields) {
      if (packet.answers[field.key] !== undefined || field.type === "file") continue;
      const label = `${field.key} ${field.label}`.toLowerCase().replace(/[_-]/g, " ");
      if (/\bemail\b/.test(label)) packet.answers[field.key] = profile.email;
      else if (/\b(?:full name|your name)\b/.test(label)) packet.answers[field.key] = profile.name;
      else if (/\bfirst name\b/.test(label)) packet.answers[field.key] = profile.name.split(/\s+/)[0] ?? "";
      else if (/\blast name\b/.test(label)) packet.answers[field.key] = profile.name.split(/\s+/).slice(1).join(" ");
      else if (/\b(?:phone|mobile)\b/.test(label)) packet.answers[field.key] = profile.phone;
      else if (/\blinkedin\b/.test(label) && profile.links.linkedin) packet.answers[field.key] = profile.links.linkedin;
      else if (/\bgithub\b/.test(label) && profile.links.github) packet.answers[field.key] = profile.links.github;
    }
    packet.formSnapshot = snapshot;
    packet.status = "prepared";
    delete packet.approvedAt; delete packet.approvalHash;
    packet.warnings = [...matchJob(profile, job).warnings, ...packet.draft.notes, ...snapshot.unsupported];
    if (snapshot.hasCaptcha) packet.warnings.push("CAPTCHA requires manual action.");
    if (snapshot.hasLegal) packet.warnings.push("Legal or own-words declarations require manual action.");
    for (const f of snapshot.fields)
      if (f.required && f.type !== "file" && !packet.answers[f.key]?.trim()) packet.warnings.push(`Answer required: ${f.label || f.key} (${f.key}).`);
    this.store.putPacket(packet);
    return packet;
  }
  updateAnswers(id: string, answers: Record<string, string>): Packet {
    const packet = this.get(id);
    if (!["prepared", "approved", "manual_only", "withdrawn_from_queue"].includes(packet.status)) throw new Error("Answers are locked after execution begins.");
    packet.answers = answers;
    packet.status = "prepared";
    delete packet.approvedAt; delete packet.approvalHash;
    this.store.putPacket(packet);
    return packet;
  }
  validateForm(packet: Packet): void {
    const form = packet.formSnapshot;
    if (!form) throw new Error("Preflight the actual form before approving automation.");
    if (snapshotHash(form) !== form.fingerprint) throw new Error("Form fingerprint changed.");
    if (form.hasCaptcha || form.hasLegal || form.unsupported.length) throw new Error("This form requires manual steps; automated submission is blocked.");
    const uploaded = packet.draft.mode === "uploaded-variant" || packet.draft.mode === "jd-tailored";
    const files = form.fields.filter(f => f.type === "file");
    if (uploaded ? files.filter(f => /resume|résumé|\bcv\b/i.test(`${f.key} ${f.label}`)).length !== 1 : files.length !== 1)
      throw new Error("Only one unambiguous resume upload is currently supported.");
    for (const field of form.fields) {
      if (field.type === "file") {
        if (uploaded && !field.required && !/resume|résumé|\bcv\b/i.test(`${field.key} ${field.label}`)) continue;
        if (!/resume|résumé|cv/i.test(`${field.key} ${field.label}`)) throw new Error("Unrecognized upload purpose; manual review required.");
        continue;
      }
      const answer = packet.answers[field.key];
      if (field.required && !answer?.trim()) throw new Error(`A confirmed answer is required for ${field.label || field.key}.`);
      if (uploaded && !field.required && !answer) continue;
      if (answer && field.options.length && !field.options.includes(answer)) throw new Error(`Answer does not match an allowed option for ${field.label}.`);
      const supported = uploaded ? ["text", "email", "tel", "url", "number", "textarea", "select", "select-one", "radio", "combobox", "autocomplete", "date"] : ["text", "email", "tel", "url", "number", "textarea", "select", "select-one"];
      if (!supported.includes(field.type)) throw new Error(`Unsupported field type: ${field.type}.`);
    }
  }
  async approve(ids: string[], acknowledgeWarnings: boolean): Promise<Packet[]> {
    if (!ids.length || ids.length > MAX_APPROVAL_BATCH_SIZE || new Set(ids).size !== ids.length)
      throw new Error(`Choose between 1 and ${MAX_APPROVAL_BATCH_SIZE} unique packets per request; this is not a daily or session limit.`);
    if (new Set(ids.map(id => this.get(id).jobId)).size !== ids.length) throw new Error("Select only one resume packet per job.");
    for (const id of ids) await this.checkArtifacts(this.get(id));
    return this.store.transaction(() => ids.map(id => {
      const packet = this.get(id), job = this.validate(packet), policy = this.policy(job);
      if (!["prepared", "withdrawn_from_queue"].includes(packet.status)) throw new Error("Only prepared packets can be approved.");
      if (packet.warnings.length && !acknowledgeWarnings) throw new Error("Review and explicitly acknowledge packet warnings before approval.");
      if (policy.allowed && policy.canSubmit) this.validateForm(packet);
      packet.approvedBy = "user";
      packet.approvalHash = packetHash(packet);
      packet.approvedAt = new Date().toISOString();
      packet.status = policy.allowed && policy.canSubmit ? "approved" : "manual_only";
      this.store.putPacket(packet);
      this.store.event(id, packet.status, packet.status === "manual_only" ? policy.reason : "User approved exact packet and transmission.");
      return packet;
    }));
  }
  async approveAutomatic(id: string, permit: ExecutionPermit): Promise<Packet> {
    await this.checkArtifacts(this.get(id));
    return this.store.transaction(() => {
      permit.assert();
      const packet = this.get(id);
      this.validate(packet);
      if (packet.status !== "prepared" || !["uploaded-variant", "jd-tailored"].includes(packet.draft.mode)) throw new Error("Only a fresh approved-template packet can be approved by standing authorization.");
      if (!permit.workflow) this.validateForm(packet);
      this.selectSubmissionArtifact(packet);
      if (permit.workflow) packet.workflowSteps = [];
      packet.authorizationId = permit.authorizationId; packet.approvedBy = "autopilot";
      packet.approvedAt = new Date().toISOString(); packet.approvalHash = packetHash(packet); packet.status = "approved";
      this.store.putPacket(packet);
      this.store.event(id, "autopilot_approved", `Standing authorization ${permit.authorizationId} approved the exact variant and answer plan.`);
      return packet;
    });
  }
  async claim(id: string, permit?: ExecutionPermit) {
    const before = this.get(id);
    await this.checkArtifacts(before);
    const resume = this.submissionArtifact(before);
    const bytes = await readFile(join(this.directory(id), resume.filename));
    if (createHash("sha256").update(bytes).digest("hex") !== resume.sha256) throw new Error("Resume changed before execution.");
    this.expireExecutions();
    const result = this.store.transaction(() => {
      const packet = this.get(id), job = this.validate(packet);
      let policy = this.policy(job);
      if (permit) {
        permit.assert();
        if (packet.authorizationId !== permit.authorizationId || packet.approvedBy !== "autopilot" || !["uploaded-variant", "jd-tailored"].includes(packet.draft.mode))
          throw new Error("The execution permit does not authorize this packet.");
        policy = { allowed: true, canSubmit: true, reason: "Current standing authorization.", limit: permit.sourceLimit };
      } else if (packet.approvedBy === "autopilot") throw new Error("Standing-authorized packets can only be executed by their authorized runner.");
      if (this.store.value("stopped", false)) throw new Error("Queue is stopped.");
      if (packet.status !== "approved" || packet.approvalHash !== packetHash(packet)) throw new Error("The exact packet is not approved.");
      if (!policy.allowed || !policy.canSubmit) throw new Error(policy.reason);
      if (!permit?.workflow) this.validateForm(packet);
      if (Date.now() - Date.parse(job.fetchedAt) > 86400_000 || !Number.isFinite(Date.parse(job.fetchedAt))) throw new Error("Listing freshness is unknown or stale. Refresh and review it first.");
      if (this.store.db.prepare("SELECT packet_id FROM runs WHERE status='executing'").get()) throw new Error("Another application is currently executing.");
      const day = today(), limit = this.store.profile().preferences.dailyLimit;
      if (limit !== null && this.store.attempts(day) >= limit) throw new Error("Your optional daily submission cap has been reached.");
      if (policy.limit !== null && this.store.attempts(day, job.sourceId) >= policy.limit) throw new Error("Source submission ceiling reached.");
      if (this.store.db.prepare("SELECT packet_id FROM runs WHERE job_id=?").get(job.id)) throw new Error("This job has an existing attempt. No automatic duplicate retry is permitted.");
      const runToken = randomBytes(32).toString("hex");
      this.store.db.prepare("INSERT INTO runs(packet_id,job_id,source_id,token,day,status,session_id,started_at) VALUES (?,?,?,?,?,?,?,?)")
        .run(id, job.id, job.sourceId, runToken, day, "executing", this.store.sessionId, new Date().toISOString());
      packet.status = "executing";
      this.store.putPacket(packet);
      this.store.set(`executionDeadline:${id}`, Date.now() + 300_000);
      this.store.event(id, "executing", "Reserved one submission attempt.");
      return { packet, job, runToken };
    });
    return { ...result, fields: result.packet.answers, resume: { base64: bytes.toString("base64"), mime: resume.format === "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document", filename: resume.filename } };
  }
  authorizeWorkflowStep(id: string, permit: ExecutionPermit, snapshot: FormSnapshot, answers: Record<string, string>, humanSupplied: boolean): void {
    this.store.transaction(() => {
      permit.assert();
      const packet = this.get(id);
      if (!permit.workflow || packet.authorizationId !== permit.authorizationId || packet.status !== "executing")
        throw new Error("This workflow step is not authorized.");
      if (snapshotHash(snapshot) !== snapshot.fingerprint) throw new Error("Workflow form snapshot changed.");
      if (hasNoAiRestriction(snapshot.fields.map(field => field.label).join("\n"))) throw new Error("This form requires a manual, human-authored application.");
      for (const key of Object.keys(answers)) {
        const field = snapshot.fields.find(field => field.key === key);
        if (!field || field.type === "password" || /password|passcode|one.?time|verification.?code|social.security|passport|access.?token/i.test(`${field.key} ${field.label}`))
          throw new Error("Credentials or unsupported fields cannot be recorded as workflow answers.");
      }
      packet.workflowSteps ??= [];
      const entry = { url: snapshot.url, fingerprint: snapshot.fingerprint, answers: { ...answers }, humanSupplied, recordedAt: new Date().toISOString() };
      const last = packet.workflowSteps.at(-1);
      if (!last || last.fingerprint !== entry.fingerprint || digest(last.answers) !== digest(entry.answers) || last.humanSupplied !== humanSupplied) {
        if (packet.workflowSteps.length >= 100) throw new Error("Workflow step record budget exceeded. Continue manually.");
        packet.workflowSteps.push(entry);
      }
      packet.formSnapshot = snapshot;
      packet.answers = { ...packet.answers, ...answers };
      packet.approvalHash = packetHash(packet);
      this.store.putPacket(packet);
    });
  }
  selectWorkflowArtifact(id: string, sha256: string, permit: ExecutionPermit): void {
    permit.assert();
    const packet = this.get(id);
    if (packet.status !== "executing" || !packet.artifacts.some(artifact => artifact.sha256 === sha256))
      throw new Error("The selected workflow document is not an approved artifact.");
    packet.submissionArtifactSha256 = sha256;
    packet.approvalHash = packetHash(packet); this.store.putPacket(packet);
  }
  holdForHuman(id: string, token: string, reason: string): void {
    this.store.transaction(() => {
      const row = this.store.db.prepare("SELECT token FROM runs WHERE packet_id=?").get(id);
      if (!row || row.token !== token) throw new Error("Invalid workflow token.");
      const packet = this.get(id);
      if (packet.status !== "executing") throw new Error("Only an executing application can await human input.");
      packet.status = "awaiting_human"; packet.error = reason; this.store.putPacket(packet);
      this.store.db.prepare("UPDATE runs SET status='awaiting_human' WHERE packet_id=?").run(id);
      this.store.event(id, "awaiting_human", reason);
    });
  }
  resumeWorkflowRun(id: string, token: string, permit: ExecutionPermit): void {
    this.store.transaction(() => {
      permit.assert();
      const row = this.store.db.prepare("SELECT token FROM runs WHERE packet_id=?").get(id);
      const packet = this.get(id);
      if (!row || row.token !== token || packet.status !== "awaiting_human" || packet.authorizationId !== permit.authorizationId)
        throw new Error("The paused workflow cannot be resumed under this authorization.");
      if (this.store.db.prepare("SELECT 1 FROM runs WHERE status='executing'").get()) throw new Error("Another application is executing; wait before resuming.");
      this.validate(packet);
      packet.status = "executing"; delete packet.error; this.store.putPacket(packet);
      this.store.db.prepare("UPDATE runs SET status='executing' WHERE packet_id=?").run(id);
      this.store.set(`executionDeadline:${id}`, Date.now() + 300_000);
    });
  }
  expireExecutions(now = Date.now()): void {
    for (const packet of this.store.packetsWithStatus("executing")) {
      if (packet.status === "executing" && this.store.value(`executionDeadline:${packet.id}`, 0) <= now) {
        packet.status = "submission_unknown";
        packet.error = "Execution lease expired without a confirmed outcome. Do not retry; reconcile manually.";
        this.store.putPacket(packet);
        this.store.db.prepare("UPDATE runs SET status='submission_unknown' WHERE packet_id=?").run(packet.id);
        this.store.event(packet.id, "submission_unknown", packet.error);
      }
    }
  }
  report(id: string, token: string, outcome: "submitted_confirmed" | "submission_unknown" | "failed", confirmation?: string, error?: string): Packet {
    return this.store.transaction(() => {
      const row = this.store.db.prepare("SELECT token FROM runs WHERE packet_id=?").get(id);
      if (!row || row.token !== token) throw new Error("Invalid execution token.");
      const packet = this.get(id);
      if (!["executing", "awaiting_human", "submission_unknown"].includes(packet.status)) throw new Error("Execution has already been resolved.");
      if (outcome === "submitted_confirmed" && !confirmation?.trim()) throw new Error("Trustworthy confirmation evidence is required.");
      packet.status = outcome;
      if (outcome === "submitted_confirmed") {
        packet.submittedAt ??= new Date().toISOString();
        packet.progress ??= { stage: "applied", note: "", updatedAt: packet.submittedAt };
      }
      packet.confirmation = confirmation;
      packet.error = error;
      this.store.putPacket(packet);
      this.store.db.prepare("UPDATE runs SET status=? WHERE packet_id=?").run(outcome, id);
      this.store.event(id, outcome, outcome === "submitted_confirmed" ? "Browser reported explicit confirmation evidence." : "Execution requires review; no automatic retry.");
      return packet;
    });
  }
  stop(stopped: boolean): void {
    this.store.transaction(() => {
      this.store.set("stopped", stopped);
      if (stopped) for (const packet of this.store.packetsWithStatus("approved")) {
        if (packet.status === "approved") { packet.status = "withdrawn_from_queue"; this.store.putPacket(packet); }
      }
      this.store.event(null, stopped ? "stopped" : "resumed", "In-flight submissions may still complete; queued work needs fresh approval.");
    });
  }
}
