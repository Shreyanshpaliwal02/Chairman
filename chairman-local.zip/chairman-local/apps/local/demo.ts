import { mkdtemp, readFile, rm } from "node:fs/promises";
import { join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createDocuments } from "../../packages/documents/index.js";
import { DEFAULT_PREFERENCES, type Job, type Profile } from "../../packages/domain/types.js";
import { defaultDataDirectory } from "../../packages/platform/paths.js";
import { profileSchema } from "./schemas.js";
import type { ResumeLibrary } from "./resume-library.js";
import type { Store } from "./store.js";

/**
 * Clearly fictional applicant for testing page assistance on real career sites without exposing your own data.
 * example.com is a reserved domain; nothing here belongs to a real person. Never submit it to an employer.
 */
export const DEMO_EMAIL = "demo.candidate@example.com";
export function demoProfile(): Profile {
  return {
    name: "Demo Candidate", email: DEMO_EMAIL, phone: "+91 90000 00000", location: "Bengaluru, Karnataka, India",
    links: { LinkedIn: "https://www.linkedin.com/in/demo-candidate-example", GitHub: "https://github.com/demo-candidate-example", Portfolio: "https://demo-candidate.example.com" },
    skills: ["Python", "SQL", "Apache Spark", "Apache Kafka", "Apache Airflow", "AWS", "Docker", "Kubernetes", "Terraform", "PostgreSQL", "Git", "Linux"],
    facts: [
      { id: "demo-exp-1", category: "experience", employer: "Example Analytics Pvt Ltd", role: "Data Engineer", dates: "2022 - Present", confirmed: true,
        text: "Built Python and SQL batch pipelines on AWS that process 2 TB of event data daily, with automated data-quality checks." },
      { id: "demo-exp-2", category: "experience", employer: "Example Analytics Pvt Ltd", role: "Data Engineer", dates: "2022 - Present", confirmed: true,
        text: "Moved nightly Apache Spark jobs to Apache Airflow orchestration, cutting pipeline failures by 40%." },
      { id: "demo-exp-3", category: "experience", employer: "Placeholder Tech Solutions", role: "Software Engineer", dates: "2020 - 2022", confirmed: true,
        text: "Developed REST APIs in Python with PostgreSQL and containerized them with Docker and Kubernetes." },
      { id: "demo-edu-1", category: "education", employer: "Demo Institute of Technology", role: "Bachelor of Technology in Computer Science", dates: "2016 - 2020", confirmed: true,
        text: "Completed a Bachelor of Technology in Computer Science." },
      { id: "demo-summary", category: "summary", confirmed: true, text: "Data engineer with 4 years of experience building reliable batch and streaming pipelines on AWS." },
    ],
    answers: {
      first_name: "Demo", last_name: "Candidate", city: "Bengaluru", country: "India", postal_code: "560001",
      notice_period_days: "30", available_start_date: "2026-11-02", total_years_experience: "4",
      years_python: "4", years_sql: "4", years_aws: "3", years_spark: "3", years_kafka: "2",
      expected_salary_INR_annual: "2400000", willing_to_relocate: "Yes", travel_willingness: "Yes, up to 20% of the time",
      "How did you hear about this job?": "Company careers page",
      motivation_template: "I'm interested in the {role} role at {company} because it matches the data platform work I do today: building reliable Python, SQL and Spark pipelines on AWS and making them easier to operate.",
    },
    confirmed: true, version: 1, preferences: structuredClone(DEFAULT_PREFERENCES),
  };
}
function demoJob(): Job {
  return { id: "demo-render-job", sourceId: "demo", sourceJobId: "demo-render-job", title: "Data Engineer", company: "Demo Employer", location: "India",
    remote: false, countries: ["India"], employmentType: "Full-time", description: "Build reliable data pipelines using Python, SQL, Apache Spark, Apache Kafka and AWS.",
    applyUrl: "https://careers.example.com/jobs/demo", canonicalUrl: "https://careers.example.com/jobs/demo", fetchedAt: new Date().toISOString(),
    salary: null, language: "English", sponsorship: "unknown", aiPolicy: "allowed", status: "open" };
}

/** Seeds the demo profile and two approved resumes (PDF and DOCX) generated from it. Refuses to touch a non-demo profile. */
export async function seedDemo(store: Store, library: ResumeLibrary, dataDir: string, reset = false): Promise<"seeded" | "kept"> {
  const current = store.profile();
  if (current.email && current.email !== DEMO_EMAIL) throw new Error("This data folder holds a non-demo profile. Demo data is only written to its own demo folder.");
  if (!reset && current.email === DEMO_EMAIL && library.approvedVariants().length >= 2) return "kept";
  const profile = profileSchema.parse(demoProfile());
  store.set("profile", { ...profile, version: Math.max(1, current.version + (current.email ? 1 : 0)) });
  const directory = await mkdtemp(join(dataDir, ".demo-resumes-"));
  try {
    const artifacts = await createDocuments(profile, demoJob(), { mode: "deterministic", factIds: profile.facts.map(fact => fact.id), skills: profile.skills, notes: [] }, directory);
    const pdf = artifacts.find(artifact => artifact.format === "pdf")!, docx = artifacts.find(artifact => artifact.format === "docx")!;
    await library.upload(1, "Demo_Candidate_Data_Engineer.pdf", await readFile(join(directory, pdf.filename)), "Demo · Data Engineer", ["data"], true);
    await library.upload(2, "Demo_Candidate_Software_Engineer.docx", await readFile(join(directory, docx.filename)), "Demo · Software Engineer", ["software"], true);
  } finally { await rm(directory, { recursive: true, force: true }); }
  return "seeded";
}

export function demoDataDirectory(): string { return `${defaultDataDirectory()} Demo`; }

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const option = (name: string) => { const index = args.indexOf(name); return index >= 0 ? args[index + 1] : undefined; };
  const port = Number(option("--port") ?? 4319);
  const dataDir = resolve(option("--data") ?? demoDataDirectory());
  const real = [resolve(defaultDataDirectory()), ...(process.env.JAA_DATA_DIR ? [resolve(process.env.JAA_DATA_DIR)] : [])];
  if (real.includes(dataDir)) throw new Error("Refusing to put demo data in your real Chairman data folder. Choose a separate --data folder.");
  const reset = args.includes("--reset");
  if (reset) await rm(dataDir, { recursive: true, force: true });
  process.env.JAA_DEBUG ??= "1";
  const { createApp } = await import("./server.js");
  const runtime = await createApp({ dataDir, port });
  const seeded = await seedDemo(runtime.store, runtime.library, dataDir, reset);
  await runtime.app.listen({ host: "127.0.0.1", port });
  // Companies you add in the demo are crawled and ranked like the real workspace; Auto Apply stays off unless you activate it.
  runtime.careerSources.start();
  runtime.shortlist.start();
  console.log([
    `Chairman DEMO instance: ${runtime.origin} (${seeded === "seeded" ? "demo profile and 2 approved resumes created" : "existing demo data kept"})`,
    `Demo data folder: ${dataDir}`,
    "Your real workspace and data are untouched; its service can keep running on its own port.",
    `Pair the extension to port ${port}: open ${runtime.origin} > Setup > Browser extension > Create pairing token, then use port ${port} in the side panel.`,
    "Verbose service diagnostics are printed below (JAA_DEBUG=1). Never submit the demo applicant to a real employer.",
  ].join("\n"));
  const close = async () => { await runtime.app.close(); process.exit(0); };
  process.once("SIGINT", close); process.once("SIGTERM", close);
}
