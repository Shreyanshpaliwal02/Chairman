import { randomUUID } from "node:crypto";
import type { FastifyInstance } from "fastify";
import { z } from "zod";
import type { Job } from "../../packages/domain/types.js";
import { applicationStartUrl } from "../../packages/domain/apply-start.js";
import type { ShortlistService } from "./shortlist.js";
import type { Store } from "./store.js";

/**
 * Application sessions in your own Chrome: up to 50 of today's to-do roles, opened 10 tabs at a time. The extension fills
 * each one step by step and stops before Submit for your review; the next tab opens as each one finishes (you submit it,
 * skip it or close it). When all are finished, a new session offers the next roles.
 */
export type SessionItemState = "queued" | "opened" | "working" | "needs_you" | "review" | "submitted" | "closed" | "skipped" | "failed";
export const OPEN_STATES: readonly SessionItemState[] = ["opened", "working", "needs_you", "review"];
export const FINISHED_STATES: readonly SessionItemState[] = ["submitted", "closed", "skipped", "failed"];
export interface ApplySessionItem {
  jobId: string; rank: number; company: string; title: string; location: string;
  /** Where the tab opens: straight into the application where the site allows it. */
  startUrl: string;
  state: SessionItemState; detail?: string; updatedAt: string; openedAt?: string; finishedAt?: string;
}
export interface ApplySession {
  id: string; number: number; createdAt: string; updatedAt: string; status: "active" | "complete" | "stopped";
  size: number; concurrency: number; items: ApplySessionItem[];
}
export interface ApplySessionView extends ApplySession {
  counts: Record<SessionItemState, number>; open: number; finished: number;
}
export const SESSION_SIZE = 50, SESSION_CONCURRENCY = 10;

/** The page where a role's application starts, skipping job-description pages where the site has a direct link. */
export function sessionStartUrl(job: Pick<Job, "applyUrl" | "canonicalUrl">): string {
  return applicationStartUrl(job.applyUrl || job.canonicalUrl);
}

export class ApplySessionService {
  /** Roles you opened one at a time from the dashboard; their tabs are driven like session tabs. */
  private readonly direct = new Set<string>();
  constructor(readonly store: Store, readonly shortlist: ShortlistService) {
    store.db.exec("CREATE TABLE IF NOT EXISTS apply_sessions(id TEXT PRIMARY KEY, created_at TEXT NOT NULL, json TEXT NOT NULL)");
  }
  private save(session: ApplySession): void {
    this.store.db.prepare("INSERT INTO apply_sessions VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET json=excluded.json").run(session.id, session.createdAt, JSON.stringify(session));
  }
  /** The latest session (active, complete or stopped). */
  current(): ApplySession | undefined {
    const row = this.store.db.prepare("SELECT json FROM apply_sessions ORDER BY created_at DESC, rowid DESC LIMIT 1").get();
    return row ? JSON.parse(String(row.json)) as ApplySession : undefined;
  }
  active(): ApplySession | undefined {
    const session = this.current();
    return session?.status === "active" ? session : undefined;
  }
  /** One role opened from the dashboard in its own driven tab: where its application starts. */
  startFor(jobId: string): { jobId: string; company: string; title: string; startUrl: string } {
    const job = this.store.job(jobId);
    if (!job) throw new Error("That role is no longer in Chairman. Rebuild today's list.");
    this.direct.add(jobId);
    return { jobId, company: job.company, title: job.title, startUrl: sessionStartUrl(job) };
  }
  /** Whether a role's tab is driven by the extension: in the active session, or opened on its own from the dashboard. */
  driven(jobId: string): boolean {
    return this.direct.has(jobId) || !!this.active()?.items.some(item => item.jobId === jobId);
  }
  view(session = this.current()): ApplySessionView | undefined {
    if (!session) return undefined;
    const counts = Object.fromEntries((["queued", "opened", "working", "needs_you", "review", "submitted", "closed", "skipped", "failed"] as SessionItemState[])
      .map(state => [state, session.items.filter(item => item.state === state).length])) as Record<SessionItemState, number>;
    return { ...session, counts, open: session.items.filter(item => OPEN_STATES.includes(item.state)).length,
      finished: session.items.filter(item => FINISHED_STATES.includes(item.state)).length };
  }
  /**
   * Today's to-do roles that a new session would take, best first: never one an earlier session already opened (you
   * submitted, skipped or closed it; open it from Today yourself if you change your mind). Roles a stopped session never
   * opened stay available.
   */
  available(): { jobId: string; rank: number; company: string; title: string; location: string; applyUrl: string }[] {
    const taken = new Set(this.active()?.items.map(item => item.jobId) ?? []);
    for (const row of this.store.db.prepare("SELECT json FROM apply_sessions").all())
      for (const item of (JSON.parse(String(row.json)) as ApplySession).items) if (item.state !== "queued") taken.add(item.jobId);
    return this.shortlist.view().entries.filter(entry => ["new", "opened", "filled"].includes(entry.status) && !taken.has(entry.jobId))
      .sort((a, b) => a.rank - b.rank);
  }
  create(size = SESSION_SIZE): ApplySessionView {
    if (this.active()) throw new Error("A session is already running. Finish it or stop it first.");
    const picked = this.available().slice(0, Math.max(1, Math.min(SESSION_SIZE, size)));
    if (!picked.length) throw new Error("No to-do roles are left on today's list. Rebuild the list or wait for tomorrow's.");
    const now = new Date().toISOString();
    const items: ApplySessionItem[] = picked.map(entry => {
      const job = this.store.job(entry.jobId);
      return { jobId: entry.jobId, rank: entry.rank, company: entry.company, title: entry.title, location: entry.location,
        startUrl: job ? sessionStartUrl(job) : entry.applyUrl, state: "queued", updatedAt: now };
    });
    const number = Number(this.store.db.prepare("SELECT count(*) AS n FROM apply_sessions").get()?.n ?? 0) + 1;
    const session: ApplySession = { id: randomUUID(), number, createdAt: now, updatedAt: now, status: "active", size: items.length, concurrency: SESSION_CONCURRENCY, items };
    this.save(session);
    this.store.event(null, "apply_session_started", `Session ${number}: ${items.length} roles, ${SESSION_CONCURRENCY} tabs at a time. Nothing is submitted without you.`);
    return this.view(session)!;
  }
  /** The roles to open now, so that at most `concurrency` are open; marks them opened. */
  next(): ApplySessionItem[] {
    const session = this.active();
    if (!session) return [];
    const open = session.items.filter(item => OPEN_STATES.includes(item.state)).length;
    const now = new Date().toISOString();
    const picked = session.items.filter(item => item.state === "queued").slice(0, Math.max(0, session.concurrency - open));
    for (const item of picked) {
      Object.assign(item, { state: "opened", openedAt: now, updatedAt: now, detail: "Opened in your Chrome." });
      try { this.shortlist.mark(item.jobId, "opened"); } catch { /* The role left today's list; the session keeps it. */ }
    }
    if (picked.length) { session.updatedAt = now; this.save(session); }
    return picked;
  }
  /** Progress reported by the extension for one role. Finished roles stay finished; the session completes when all are. */
  update(jobId: string, state: SessionItemState, detail?: string): ApplySessionView {
    const session = this.active();
    if (!session) throw new Error("No application session is running.");
    const item = session.items.find(entry => entry.jobId === jobId);
    if (!item) throw new Error("That role is not part of the current session.");
    const now = new Date().toISOString();
    if (FINISHED_STATES.includes(item.state) && state !== "submitted") return this.view(session)!;
    if (state === "queued") throw new Error("A role cannot be put back in the queue.");
    Object.assign(item, { state, updatedAt: now, ...(detail ? { detail: detail.slice(0, 300) } : {}), ...(FINISHED_STATES.includes(state) ? { finishedAt: now } : {}) });
    if (state === "skipped") { try { this.shortlist.mark(jobId, "skipped"); } catch { /* Not on today's list any more. */ } }
    if (session.items.every(entry => FINISHED_STATES.includes(entry.state))) {
      session.status = "complete";
      const submitted = session.items.filter(entry => entry.state === "submitted").length;
      this.store.event(null, "apply_session_complete", `Session ${session.number} finished: ${submitted} submitted of ${session.items.length}.`);
    }
    session.updatedAt = now; this.save(session);
    return this.view(session)!;
  }
  stop(): ApplySessionView | undefined {
    const session = this.active();
    if (!session) return this.view();
    session.status = "stopped"; session.updatedAt = new Date().toISOString();
    this.save(session);
    this.store.event(null, "apply_session_stopped", `Session ${session.number} stopped by you; roles not yet opened stay on today's list.`);
    return this.view(session);
  }
}

const itemStates = z.enum(["opened", "working", "needs_you", "review", "submitted", "closed", "skipped", "failed"]);
export function registerApplySessions(app: FastifyInstance, service: ApplySessionService): void {
  const summary = () => ({ session: service.view(), available: service.available().length });
  // Dashboard (session cookie).
  app.get("/api/apply-sessions/current", async () => summary());
  app.post("/api/apply-sessions", async request => {
    const { size } = z.object({ size: z.number().int().min(1).max(SESSION_SIZE).optional() }).strict().parse(request.body ?? {});
    service.create(size);
    return summary();
  });
  app.post("/api/apply-sessions/current/stop", async () => { service.stop(); return summary(); });
  // Paired extension (token + paired origin).
  app.get("/api/extension/assist/session", async () => summary());
  app.post("/api/extension/assist/session/start", async request => {
    const { size } = z.object({ size: z.number().int().min(1).max(SESSION_SIZE).optional() }).strict().parse(request.body ?? {});
    if (!service.active()) service.create(size);
    return summary();
  });
  app.post("/api/extension/assist/session/next", async () => ({ open: service.next(), ...summary() }));
  app.post("/api/extension/assist/job-start", async request => {
    const { jobId } = z.object({ jobId: z.string().min(1).max(300) }).strict().parse(request.body);
    return service.startFor(jobId);
  });
  app.post("/api/extension/assist/session/progress", async request => {
    const { jobId, state, detail } = z.object({ jobId: z.string().min(1).max(300), state: itemStates, detail: z.string().max(300).optional() }).strict().parse(request.body);
    service.update(jobId, state, detail);
    return summary();
  });
  app.post("/api/extension/assist/session/stop", async () => { service.stop(); return summary(); });
}
