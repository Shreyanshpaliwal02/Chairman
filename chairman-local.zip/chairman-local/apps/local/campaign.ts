import type { CampaignConfig, CampaignStats } from "../../packages/domain/types.js";
import { daysBetween, localDate, shiftDate, validDate } from "../../packages/domain/dates.js";
import { campaignSchema } from "./schemas.js";
import { Store } from "./store.js";

export function campaignConfig(store: Store, now = new Date()): CampaignConfig {
  const existing = store.value<CampaignConfig | null>("campaign", null);
  if (existing) return campaignSchema.parse(existing);
  const config: CampaignConfig = { startDate: localDate(now), days: 45, dailyTarget: 500, timezone: "Asia/Kolkata" };
  store.set("campaign", config);
  return config;
}
export function campaignStats(store: Store, now = new Date()): CampaignStats {
  const config = campaignConfig(store, now), current = localDate(now);
  const endDate = shiftDate(config.startDate, config.days - 1);
  const dayNumber = Math.max(0, Math.min(config.days, daysBetween(config.startDate, current) + 1));
  const summaries = store.packetSummaries();
  const submitted = summaries.filter(packet => packet.status === "submitted_confirmed");
  const stages = new Map<string, Set<string>>();
  for (const row of store.db.prepare("SELECT packet_id,type FROM events WHERE type IN ('progress:interview','progress:offer')").all()) {
    const id = String(row.packet_id);
    const set = stages.get(id) ?? new Set<string>(); set.add(String(row.type).slice("progress:".length)); stages.set(id, set);
  }
  const dates = new Map<string, string>();
  for (const row of store.db.prepare("SELECT packet_id,min(created_at) AS created_at FROM events WHERE type IN ('submitted_confirmed','user_confirmed') GROUP BY packet_id").all()) {
    if (typeof row.created_at === "string" && Number.isFinite(Date.parse(row.created_at))) dates.set(String(row.packet_id), row.created_at);
  }
  const daily = Array.from({ length: config.days }, (_, index) => ({ date: shiftDate(config.startDate, index), confirmed: 0, target: config.dailyTarget }));
  const dayMap = new Map(daily.map(day => [day.date, day]));
  const sources = new Map<string, CampaignStats["sources"][number]>();
  const seen = new Set<string>();
  let interviews = 0, offers = 0, confirmedToday = 0, confirmedTotal = 0, followUpsDue = 0, untrackedSubmissionDates = 0;
  for (const packet of submitted) {
    if (seen.has(packet.jobId)) continue;
    seen.add(packet.jobId);
    const submittedAt = packet.submittedAt ?? dates.get(packet.id);
    if (!submittedAt || !Number.isFinite(Date.parse(submittedAt))) { untrackedSubmissionDates++; continue; }
    const date = localDate(new Date(submittedAt));
    if (date === current) confirmedToday++;
    if (date < config.startDate || date > endDate) continue;
    const day = dayMap.get(date)!; day.confirmed++; confirmedTotal++;
    const stageHistory = stages.get(packet.id);
    const interviewed = packet.stage === "interview" || Boolean(stageHistory?.has("interview"));
    const offered = packet.stage === "offer" || Boolean(stageHistory?.has("offer"));
    if (interviewed) interviews++;
    if (offered) offers++;
    if (packet.nextActionDate && validDate(packet.nextActionDate) && packet.nextActionDate <= current && !["rejected", "withdrawn"].includes(packet.stage ?? "")) followUpsDue++;
    const source = sources.get(packet.sourceId) ?? { sourceId: packet.sourceId, submitted: 0, interviews: 0, offers: 0 };
    source.submitted++; source.interviews += Number(interviewed); source.offers += Number(offered); sources.set(packet.sourceId, source);
  }
  return {
    config, endDate, dayNumber, daysRemaining: Math.max(0, Math.min(config.days, daysBetween(current, endDate) + 1)),
    totalTarget: config.days * config.dailyTarget, confirmedToday, confirmedTotal, targetToDate: dayNumber * config.dailyTarget,
    remainingToGoal: Math.max(0, config.days * config.dailyTarget - confirmedTotal), interviews, offers, followUpsDue,
    interviewRate: confirmedTotal ? Math.round(interviews / confirmedTotal * 10000) / 100 : 0,
    untrackedSubmissionDates, daily, sources: [...sources.values()].sort((a, b) => b.interviews - a.interviews || b.submitted - a.submitted)
  };
}
