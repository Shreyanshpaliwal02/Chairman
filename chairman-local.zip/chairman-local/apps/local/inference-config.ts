import { z } from "zod";
import { Store } from "./store.js";
import { DEFAULT_GEMINI_MODEL, GEMINI_FREE_MODELS, geminiInference } from "../../packages/inference/gemini.js";

export const inferenceConfigSchema = z.object({
  provider: z.enum(["copilot", "ollama", "gemini"]),
  model: z.string().trim().min(1).max(128).regex(/^[a-zA-Z0-9][a-zA-Z0-9._:-]*$/)
    .refine((value) => !/^AIza[A-Za-z0-9_-]{35}$/.test(value), "API keys belong in the private key control, not the model setting.").optional(),
  allowRemoteProcessing: z.boolean(),
  acknowledgeUsage: z.boolean(),
  confirmFreeTier: z.boolean().optional(),
}).strict().superRefine((config, context) => {
  if (config.provider === "gemini" && config.model && !GEMINI_FREE_MODELS.some((model) => model === config.model)) {
    context.addIssue({ code: "custom", path: ["model"], message: "Choose an exact allowlisted free-eligible Gemini model." });
  }
});
export type InferenceConfig = z.infer<typeof inferenceConfigSchema>;
export function applyInferenceConfig(config: InferenceConfig): void {
  config = inferenceConfigSchema.parse(config);
  geminiInference.invalidate();
  process.env.JAA_AI_PROVIDER = config.provider;
  process.env.JAA_ALLOW_COPILOT_REMOTE = "0";
  process.env.JAA_ALLOW_GEMINI_REMOTE = "0";
  process.env.JAA_GEMINI_FREE_TIER_CONFIRMED = "0";
  if (config.provider === "copilot") {
    process.env.JAA_COPILOT_MODEL = config.model ?? "gpt-6-astra";
    process.env.JAA_ALLOW_COPILOT_REMOTE = config.allowRemoteProcessing && config.acknowledgeUsage ? "1" : "0";
  } else if (config.provider === "gemini") {
    process.env.JAA_GEMINI_MODEL = config.model ?? DEFAULT_GEMINI_MODEL;
    process.env.JAA_GEMINI_FREE_TIER_CONFIRMED = config.confirmFreeTier === true ? "1" : "0";
    process.env.JAA_ALLOW_GEMINI_REMOTE = config.allowRemoteProcessing && config.acknowledgeUsage && config.confirmFreeTier ? "1" : "0";
  } else {
    process.env.JAA_OLLAMA_MODEL = config.model ?? "qwen3:4b";
    process.env.JAA_ALLOW_COPILOT_REMOTE = "0";
  }
}
export function restoreInferenceConfig(store: Store): void {
  const config = store.value<unknown>("inference", null);
  if (config !== null) applyInferenceConfig(inferenceConfigSchema.parse(config));
}
