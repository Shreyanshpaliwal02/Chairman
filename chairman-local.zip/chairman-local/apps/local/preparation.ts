import { randomUUID } from "node:crypto";
import { digest, jobHash, matchJob } from "../../packages/domain/matching.js";
import { MAX_APPROVAL_BATCH_SIZE, type PreparationTask } from "../../packages/domain/types.js";
import { Engine } from "./engine.js";
import { Store } from "./store.js";

export class PreparationService {
  private timer?: ReturnType<typeof setInterval>;
  private running?: Promise<void>;
  private stopping = false;
  constructor(readonly store: Store, readonly engine: Engine) {}
  enqueue(jobIds: string[], mode: PreparationTask["mode"]): PreparationTask[] {
    if (!jobIds.length || jobIds.length > MAX_APPROVAL_BATCH_SIZE || new Set(jobIds).size !== jobIds.length)
      throw new Error(`Choose 1-${MAX_APPROVAL_BATCH_SIZE} distinct jobs per preparation request; this is not a daily limit.`);
    const profile = this.store.profile();
    if (!profile.confirmed) throw new Error("Confirm your profile before preparing application packets. Unapproved reference drafts remain available separately.");
    const hash = digest(profile);
    return this.store.transaction(() => jobIds.map(jobId => {
      const job = this.store.job(jobId);
      if (!job) throw new Error("A selected job no longer exists.");
      const match = matchJob(profile, job);
      if (!match.eligible) throw new Error(`${job.title}: ${match.blockers.join(" ")}`);
      if (this.store.hasConflictingApplication(jobId)) throw new Error(`${job.title} already has a submitted or unresolved application.`);
      const existing = this.store.preparationForJob(jobId, hash, mode).find(task =>
        task.status === "queued" || task.status === "running"
        || (task.status === "completed" && task.packetId && this.store.packet(task.packetId)?.jobHash === jobHash(job)));
      if (existing) return existing;
      const timestamp = new Date().toISOString();
      const task: PreparationTask = { id: randomUUID(), jobId, mode, profileHash: hash, status: "queued", createdAt: timestamp, updatedAt: timestamp };
      this.store.putPreparation(task);
      return task;
    }));
  }
  recover(): void {
    for (const task of this.store.preparationWithStatus("running")) {
      task.status = "queued"; task.updatedAt = new Date().toISOString(); this.store.putPreparation(task);
    }
  }
  async processNext(): Promise<boolean> {
    if (this.stopping || this.store.value("stopped", false)) return false;
    const task = this.store.transaction(() => {
      const next = this.store.nextPreparation();
      if (!next) return undefined;
      next.status = "running"; next.updatedAt = new Date().toISOString(); this.store.putPreparation(next); return next;
    });
    if (!task) return false;
    try {
      if (digest(this.store.profile()) !== task.profileHash) throw new Error("Your profile changed after this job was queued. Review and enqueue it again.");
      const job = this.store.job(task.jobId);
      if (!job) throw new Error("The queued job no longer exists.");
      let packet = this.store.packetsForJob(task.jobId).find(candidate =>
        candidate.profileHash === task.profileHash && candidate.jobHash === jobHash(job)
        && candidate.draft.mode === task.mode && ["prepared", "approved", "manual_only"].includes(candidate.status));
      if (packet) { this.engine.validate(packet); await this.engine.checkArtifacts(packet); }
      else packet = await this.engine.prepare(task.jobId, task.mode);
      task.packetId = packet.id; task.status = "completed"; delete task.error;
    } catch (error) {
      task.status = "failed"; task.error = error instanceof Error ? error.message : "Local preparation failed.";
    }
    task.updatedAt = new Date().toISOString(); this.store.putPreparation(task);
    return true;
  }
  cancel(ids?: string[]): number {
    const wanted = ids ? new Set(ids) : undefined; let count = 0;
    for (const task of this.store.preparationWithStatus("queued")) if (!wanted || wanted.has(task.id)) {
      task.status = "cancelled"; task.updatedAt = new Date().toISOString(); this.store.putPreparation(task); count++;
    }
    return count;
  }
  start(): void {
    this.stopping = false; this.recover();
    this.timer = setInterval(() => {
      if (this.running || this.stopping) return;
      this.running = this.processNext().then(() => undefined).catch(error => {
        this.store.event(null, "preparation_error", error instanceof Error ? error.message : "Preparation queue persistence failed.");
      }).finally(() => { this.running = undefined; });
    }, 750);
    this.timer.unref();
  }
  async stop(): Promise<void> { this.stopping = true; clearInterval(this.timer); await this.running; }
}
