import { join } from "node:path";
import type { ApplicationBrowserDriver, HumanContinuation, PagePlan, WaitingSignal, WorkflowInput, WorkflowProgress, WorkflowResult } from "../../packages/automation/contracts.js";
import type { AutopilotAuthorization, AutopilotJob, AutopilotRules, Job, Packet, ResumeVariant } from "../../packages/domain/types.js";
import type { AssistancePage } from "../../packages/domain/extension-assist.js";
import { profileResolveOptions, resolveAnswers } from "../../packages/automation/answers.js";
import { Engine, snapshotHash, type ExecutionPermit } from "./engine.js";
import { ResumeLibrary } from "./resume-library.js";
import { Store } from "./store.js";
import { LiveMonitor, type StoredHumanTask } from "./live-monitor.js";

interface Callbacks {
  authorization: () => AutopilotAuthorization;
  permit: (job: Job, variant: ResumeVariant, authorization: AutopilotAuthorization) => ExecutionPermit;
  record: (job: Job, status: AutopilotJob["status"], reason: string, extra?: Partial<Pick<AutopilotJob, "packetId" | "variantId" | "humanTaskId">>) => void;
  /** The extension's page engine plan for a page the runner opened (saved answers, remembered answers, validated AI mapping). */
  planPage?: (job: Job, page: AssistancePage) => Promise<PagePlan>;
}
const SIGNALS: Record<WaitingSignal["signal"], string> = {
  captcha_solved: "CAPTCHA solved; continuing the prefilled application automatically.",
  receipt_visible: "A confirmation appeared in the parked tab; checking it against the observed submission.",
  challenge_cleared: "The post-Submit challenge closed; checking the outcome once (never a second Submit).",
};
interface RunningWorkflow {
  job: Job;
  packet: Packet;
  variant: ResumeVariant;
  authorization: AutopilotAuthorization;
  token: string;
  submissionStarted: boolean;
}

export class WorkflowRunner {
  private readonly active = new Map<string, RunningWorkflow>();
  constructor(readonly store: Store, readonly engine: Engine, readonly library: ResumeLibrary, readonly browser: ApplicationBrowserDriver,
    readonly monitor: LiveMonitor, readonly callbacks: Callbacks) {}
  async run(job: Job, variant: ResumeVariant, authorization: AutopilotAuthorization, rules: AutopilotRules): Promise<void> {
    if (!this.browser.runWorkflow) throw new Error("This browser does not support monitored workflows.");
    const bytes = await this.library.bytes(variant.id);
    const snapshot = { url: job.applyUrl, fields: [], fingerprint: "", hasCaptcha: false, hasLegal: false, unsupported: [] };
    snapshot.fingerprint = snapshotHash(snapshot);
    const packet = rules.resumeStrategy === "original"
      ? await this.engine.prepareUploaded(job.id, variant, bytes, {}, snapshot, this.library.path(variant.id))
      : await this.engine.prepareTailored(job.id, variant, bytes, rules.tailoringMode ?? "deterministic");
    const permit = { ...this.callbacks.permit(job, variant, authorization), workflow: true };
    await this.engine.approveAutomatic(packet.id, permit);
    const claim = await this.engine.claim(packet.id, permit);
    const running: RunningWorkflow = { job, packet: claim.packet, variant, authorization, token: claim.runToken, submissionStarted: false };
    this.active.set(packet.id, running);
    const input = this.input(running, permit, rules);
    try {
      const result = await this.browser.runWorkflow(input);
      this.finish(running, result);
    } catch (error) {
      this.finish(running, { status: running.submissionStarted ? "submission_unknown" : "failed", reason: error instanceof Error ? error.message : "Workflow failed." });
    }
  }
  private input(run: RunningWorkflow, permit: ExecutionPermit, rules: AutopilotRules): WorkflowInput {
    const artifact = this.engine.submissionArtifact(run.packet), planPage = this.callbacks.planPage;
    const uploaded = run.packet.draft.mode === "uploaded-variant";
    const path = (filename: string) => join(this.engine.directory(run.packet.id), filename);
    return {
      job: run.job, resumePath: path(artifact.filename), resumeFilename: uploaded ? run.variant.originalFilename : `resume-${run.packet.id}.${artifact.format}`, resumeSha256: artifact.sha256,
      resumeAlternatives: run.packet.artifacts.filter(item => item.sha256 !== artifact.sha256).map(item => ({
        path: path(item.filename), filename: `resume-${run.packet.id}.${item.format}`, sha256: item.sha256
      })),
      onResumeSelected: async sha256 => this.engine.selectWorkflowArtifact(run.packet.id, sha256, permit),
      allowHuman: rules.humanInLoop !== false,
      resolveAnswers: async (snapshot, overrides = {}) => {
        const profile = this.store.profile();
        return resolveAnswers({ ...profile, answers: { ...profile.answers, ...overrides } }, run.job, snapshot, profileResolveOptions(profile));
      },
      checkAuthorization: async () => { try { permit.assert(); return true; } catch { return false; } },
      beforeTransmit: async (snapshot, answers, humanSupplied) => this.engine.authorizeWorkflowStep(run.packet.id, permit, snapshot, answers, humanSupplied),
      beforeSubmit: async () => {
        permit.assert();
        if (run.submissionStarted) throw new Error("A final submission already began; no automatic repeat is allowed.");
        run.submissionStarted = true;
        this.store.event(run.packet.id, "submit_started", "Final submit boundary persisted by the monitored workflow.");
      },
      onProgress: async progress => this.progress(run, progress),
      ...(planPage ? { planPage: (page: AssistancePage) => planPage(run.job, page) } : {}),
      acceptAcknowledgements: this.store.profile().preferences.acceptRequiredAcknowledgements === true,
      onAcknowledge: async labels => {
        const message = `Handled in your name (Profile → Accept required acknowledgements / marketing_opt_in): ${labels.join("; ")}`.slice(0, 2000);
        this.store.event(run.packet.id, "acknowledgement", message);
        this.monitor.event("acknowledgement", message, run.job.id);
      },
    };
  }
  private progress(run: RunningWorkflow, progress: WorkflowProgress): void {
    this.store.set(`executionDeadline:${run.packet.id}`, Date.now() + 300_000);
    const status = progress.phase === "prefilling" || progress.phase === "uploading" || progress.phase === "advancing" ? "prefilling"
      : progress.phase === "submitting" || progress.phase === "confirming" ? "submitting"
        : progress.phase === "awaiting_human" ? "awaiting_human" : "inspecting";
    this.callbacks.record(run.job, status, progress.message, { packetId: run.packet.id, variantId: run.variant.id });
    this.monitor.event(progress.phase, `Step ${progress.step}: ${progress.message}`, run.job.id);
  }
  private finish(run: RunningWorkflow, result: WorkflowResult, previousTask?: StoredHumanTask): void {
    if (result.retryAfterMs !== undefined) {
      this.store.set(`autopilotBackoff:${new URL(run.job.applyUrl).hostname}`, Math.min(Number.MAX_SAFE_INTEGER, Date.now() + Math.max(60_000, result.retryAfterMs)));
    }
    // A challenge raised by Submit parks the tab too; its continuation only checks the receipt and never submits again.
    if (result.status === "human_required" && result.sessionId && result.progress && (!run.submissionStarted || result.waitingFor === "captcha_after_submit")) {
      this.engine.holdForHuman(run.packet.id, run.token, result.reason);
      const payload = {
        jobId: run.job.id, packetId: run.packet.id, sessionId: result.sessionId, reason: result.reason, url: result.progress.url, step: result.progress.step,
        filledFields: result.progress.filledFields, missingFields: result.progress.missingFields, waitingFor: result.waitingFor ?? "answers" as const,
        runToken: run.token, variantId: run.variant.id, authorizationId: run.authorization.id, authorizationSnapshot: run.authorization.snapshotHash
      };
      const task = previousTask ? { ...previousTask, ...payload, status: "waiting" as const } : this.monitor.create(payload);
      delete task.continuation; this.monitor.put(task);
      this.callbacks.record(run.job, "awaiting_human", result.reason, { packetId: run.packet.id, variantId: run.variant.id, humanTaskId: task.id });
      this.monitor.event(result.waitingFor === "answers" || !result.waitingFor ? "awaiting_human" : "captcha", `Prefilled application is parked: ${result.reason}`, run.job.id);
      return;
    }
    const confirmed = result.status === "submitted_confirmed" && run.submissionStarted && Boolean(result.evidence);
    const outcome = confirmed ? "submitted_confirmed" : run.submissionStarted || result.status === "submission_unknown" ? "submission_unknown" : "failed";
    const reason = result.status === "submitted_confirmed" && !confirmed ? "A reliable final-submit boundary and confirmation were not both observed; reconcile manually." : result.reason;
    this.engine.report(run.packet.id, run.token, outcome, confirmed ? result.evidence : undefined, reason);
    this.callbacks.record(run.job, outcome, reason, { packetId: run.packet.id, variantId: run.variant.id, ...(previousTask ? { humanTaskId: previousTask.id } : {}) });
    this.monitor.event(outcome, reason, run.job.id);
    if (outcome === "submission_unknown" && result.sessionId && result.progress) {
      const payload = { jobId: run.job.id, packetId: run.packet.id, sessionId: result.sessionId, reason, url: result.progress.url, step: result.progress.step,
        filledFields: result.progress.filledFields, missingFields: [], runToken: run.token, variantId: run.variant.id, canContinue: false,
        authorizationId: run.authorization.id, authorizationSnapshot: run.authorization.snapshotHash };
      const task = previousTask ? { ...previousTask, ...payload, status: "waiting" as const } : this.monitor.create(payload);
      delete task.continuation; this.monitor.put(task);
      this.callbacks.record(run.job, "submission_unknown", reason, { packetId: run.packet.id, variantId: run.variant.id, humanTaskId: task.id });
    } else if (previousTask) {
      previousTask.status = "resolved"; previousTask.reason = reason; delete previousTask.continuation; this.monitor.put(previousTask);
    }
    this.active.delete(run.packet.id);
  }
  /** Continues parked tabs whose CAPTCHA you solved, or whose receipt appeared, without a click in Chairman. */
  async watch(): Promise<number> {
    if (!this.browser.watchWaiting) return 0;
    let queued = 0;
    for (const signal of await this.browser.watchWaiting()) {
      const task = this.monitor.tasks().find(item => item.sessionId === signal.sessionId && item.status === "waiting");
      if (!task || task.canContinue === false) continue;
      try { this.queueContinuation(task.id, { answers: {}, useCurrentValues: false }, SIGNALS[signal.signal]); queued++; }
      catch (error) { this.monitor.event("human_review", `Could not continue automatically: ${error instanceof Error ? error.message : "unknown error"}`, task.jobId); }
    }
    return queued;
  }
  queueContinuation(id: string, continuation: HumanContinuation, automatic?: string): void {
    const task = this.monitor.task(id), authorization = this.callbacks.authorization();
    if (task.status !== "waiting" || task.canContinue === false) throw new Error("This task cannot continue automatically; verify and record the existing submission outcome manually.");
    if (!this.active.has(task.packetId) || task.authorizationSnapshot !== authorization.snapshotHash || task.authorizationId !== authorization.id)
      throw new Error("This form belongs to an older or lost authorization. Open it for manual completion/reconciliation; do not restart the application.");
    task.status = "resuming"; task.continuation = continuation; this.monitor.put(task);
    this.monitor.event(automatic ? "captcha" : "human_review", automatic ?? "User requested continuation of the existing prefilled application.", task.jobId);
  }
  async resumePending(): Promise<boolean> {
    const task = this.monitor.pending();
    if (!task) return false;
    const run = this.active.get(task.packetId);
    if (!run || !this.browser.resumeWorkflow || !task.continuation) {
      task.status = "session_lost"; task.reason = "The prefilled browser session is no longer available. Reconcile manually."; this.monitor.put(task);
      return true;
    }
    const permit = { ...this.callbacks.permit(run.job, run.variant, run.authorization), workflow: true };
    try {
      this.engine.resumeWorkflowRun(run.packet.id, run.token, permit);
      const result = await this.browser.resumeWorkflow(task.sessionId, task.continuation);
      this.finish(run, result, task);
    } catch (error) {
      const reason = error instanceof Error ? error.message : "Human continuation failed.";
      if (this.store.packet(run.packet.id)?.status === "awaiting_human") {
        task.status = "waiting"; task.reason = reason; delete task.continuation; this.monitor.put(task);
      } else this.finish(run, { status: run.submissionStarted ? "submission_unknown" : "failed", reason }, task);
    }
    return true;
  }
  async focus(id: string): Promise<void> {
    const task = this.monitor.task(id);
    if (!this.browser.focusWorkflow) throw new Error("The workflow browser is unavailable.");
    await this.browser.focusWorkflow(task.sessionId);
    this.monitor.event("manual_control", "User opened the existing prefilled browser tab for direct review.", task.jobId);
  }
  async abandon(id: string): Promise<void> {
    const task = this.monitor.task(id);
    if (!["waiting", "resuming"].includes(task.status)) throw new Error("Only pending human tasks can be abandoned.");
    if (this.store.packet(task.packetId)?.status === "executing") throw new Error("Wait for the current continuation to stop before abandoning it.");
    await this.browser.abandonWorkflow?.(task.sessionId);
    const uncertain = this.active.get(task.packetId)?.submissionStarted || this.store.packet(task.packetId)?.status === "submission_unknown";
    this.engine.report(task.packetId, task.runToken, uncertain ? "submission_unknown" : "failed", undefined, "User abandoned the prefilled workflow. This does not withdraw data already sent.");
    task.status = "abandoned"; task.reason = "Abandoned by you; not an employer withdrawal."; delete task.continuation; this.monitor.put(task);
    this.active.delete(task.packetId);
    const job = this.store.job(task.jobId);
    if (job) this.callbacks.record(job, uncertain ? "submission_unknown" : "failed", task.reason, { packetId: task.packetId, humanTaskId: task.id });
  }
  async resolveManually(packetId: string): Promise<void> {
    for (const publicTask of this.monitor.tasks().filter(task => task.packetId === packetId && ["waiting", "resuming"].includes(task.status))) {
      const task = this.monitor.task(publicTask.id);
      task.status = "resolved"; task.reason = "User recorded a verified manual submission confirmation."; delete task.continuation; this.monitor.put(task);
      this.active.delete(packetId);
      await this.browser.abandonWorkflow?.(task.sessionId);
      const job = this.store.job(task.jobId);
      if (job) this.callbacks.record(job, "submitted_confirmed", task.reason, { packetId, humanTaskId: task.id });
    }
  }
  clear(): void { this.active.clear(); }
}
