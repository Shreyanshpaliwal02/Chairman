import { randomUUID } from "node:crypto";
import { join } from "node:path";
import { z } from "zod";
import { ApplicationBrowser, providerForUrl, sameApplication } from "../../packages/automation/browser.js";
import { PortalBrowser, canUsePortal } from "../../packages/automation/portal-browser.js";
import { profileResolveOptions, resolveAnswers } from "../../packages/automation/answers.js";
import type { ApplicationBrowserDriver, HumanContinuation, PagePlan } from "../../packages/automation/contracts.js";
import type { AssistancePage } from "../../packages/domain/extension-assist.js";
import type { AutopilotAuthorization, AutopilotJob, AutopilotRules, AutopilotView, Job, ResumeVariant } from "../../packages/domain/types.js";
import { MIN_APPROVED_RESUMES } from "../../packages/domain/types.js";
import { digest, jobHash, matchJob } from "../../packages/domain/matching.js";
import { hasNoAiRestriction } from "../../packages/documents/safety.js";
import { getAiStatus } from "../../packages/documents/index.js";
import { localDate, shiftDate } from "../../packages/domain/dates.js";
import { campaignConfig, campaignStats } from "./campaign.js";
import { Engine, type ExecutionPermit } from "./engine.js";
import { ResumeLibrary } from "./resume-library.js";
import { Store } from "./store.js";
import type { CareerSourceService } from "./career-sources.js";
import type { RoleFamilyService } from "./role-families.js";
import type { QuestionInbox } from "./progress.js";
import type { JobClassification } from "../../packages/domain/role-families.js";
import { LiveMonitor } from "./live-monitor.js";
import { WorkflowRunner } from "./workflow-runner.js";
import { geminiInference, DEFAULT_GEMINI_MODEL } from "../../packages/inference/gemini.js";

export const autopilotRulesSchema = z.object({
  providers: z.array(z.enum(["ashby", "greenhouse", "generic"])).min(1).max(3),
  minimumScore: z.number().min(0).max(100),
  allowUnknownSalary: z.boolean(), allowUnknownSponsorship: z.boolean(), allowUnknownRemoteEligibility: z.boolean(),
  intervalSeconds: z.number().int().min(10).max(3600), stopAtDailyGoal: z.boolean(),
  employerAllowlist: z.array(z.string().trim().min(1).max(300)).max(1000),
  resumeStrategy: z.enum(["job-tailored", "original"]).default("job-tailored"),
  tailoringMode: z.enum(["deterministic", "local-ai"]).default("deterministic"),
  humanInLoop: z.boolean().default(true), autoDiscover: z.boolean().default(true),
  requireRoleFamily: z.boolean().default(true), maxWaitingTabs: z.number().int().min(1).max(50).default(10),
  aiAnswers: z.enum(["off", "saved-only", "all"]).default("saved-only")
}).strict();
const DEFAULT_RULES: AutopilotRules = {
  providers: ["ashby", "greenhouse", "generic"], minimumScore: 70, allowUnknownSalary: true,
  allowUnknownSponsorship: false, allowUnknownRemoteEligibility: false,
  intervalSeconds: 30, stopAtDailyGoal: false, employerAllowlist: [],
  resumeStrategy: "job-tailored", tailoringMode: "deterministic", humanInLoop: true, autoDiscover: true,
  requireRoleFamily: true, maxWaitingTabs: 10, aiAnswers: "saved-only"
};
interface Configuration {
  enabled: boolean;
  rules: AutopilotRules;
  authorization?: AutopilotAuthorization;
  status: string;
  lastRunAt?: string;
  nextRunAt?: string;
}
export interface AutopilotOptions {
  browser?: ApplicationBrowserDriver; allowTestJobs?: boolean; careerSources?: CareerSourceService; discover?: () => Promise<string>;
  families?: RoleFamilyService; inbox?: QuestionInbox;
  /** Plans a page with the same scanner/answers as the browser extension (used by the assisted runner). */
  planPage?: (job: Job, page: AssistancePage) => Promise<PagePlan>;
}
const country = (value: string) => {
  const text = value.toLowerCase().trim();
  return ({ us: "united states", usa: "united states", in: "india", ind: "india", uk: "united kingdom", gb: "united kingdom", sg: "singapore", jp: "japan", au: "australia", ch: "switzerland" } as Record<string, string>)[text] ?? text;
};

export class AutopilotService {
  readonly browser: ApplicationBrowserDriver;
  private timer?: ReturnType<typeof setInterval>;
  private pending?: Promise<void>;
  private closing = false;
  readonly monitor: LiveMonitor;
  readonly workflows: WorkflowRunner;
  private discoveryPending?: Promise<void>;
  private watching?: Promise<unknown>;
  constructor(readonly store: Store, readonly engine: Engine, readonly library: ResumeLibrary, readonly dataDir: string, readonly options: AutopilotOptions = {}) {
    // Hard cap for parked tabs; Auto Apply → "Tabs waiting for you" (maxWaitingTabs) is the configured limit.
    this.browser = options.browser ?? new PortalBrowser({ userDataDir: join(dataDir, "portal-browser"), headless: false, maxHumanSessions: 50 });
    this.monitor = new LiveMonitor(store);
    this.workflows = new WorkflowRunner(store, engine, library, this.browser, this.monitor, {
      authorization: () => this.authorized(), permit: (job, variant, auth) => this.permit(job, variant, auth),
      record: (job, status, reason, extra) => { this.record(job, status, reason, extra); },
      ...(options.planPage ? { planPage: options.planPage } : {}),
    });
    store.db.exec("CREATE TABLE IF NOT EXISTS autopilot_jobs(id TEXT PRIMARY KEY,job_id TEXT UNIQUE NOT NULL,status TEXT NOT NULL,json TEXT NOT NULL); CREATE INDEX IF NOT EXISTS autopilot_job_status ON autopilot_jobs(status)");
    const previous = store.value<Configuration | null>("autopilot", null);
    if (!store.value("migration:portal-workflows-v1", false)) {
      if (previous) {
        previous.enabled = false;
        previous.rules = { ...previous.rules, providers: [...new Set([...previous.rules.providers, "generic" as const])], humanInLoop: true, autoDiscover: true };
        previous.status = "Generic career workflows, human review and proactive discovery are ready to configure. Review the expanded scope and activate explicitly.";
        this.save(previous);
      }
      store.set("migration:portal-workflows-v1", true);
    }
    if (previous && !previous.enabled && [
      "Paused. Complete your profile, four resume slots and explicit authorization.",
      "Resume library is being changed. Review the four current files and enable again.",
      "A resume slot was removed. Four approved files are required."
    ].includes(previous.status)) {
      previous.status = `Paused. Review your profile and at least ${MIN_APPROVED_RESUMES} approved, valid resumes, then explicitly activate.`;
      this.save(previous);
    }
  }
  private config(): Configuration {
    const config = this.store.value<Configuration>("autopilot", { enabled: false, rules: structuredClone(DEFAULT_RULES), status: `Paused. Complete your profile, at least ${MIN_APPROVED_RESUMES} approved resumes and explicit authorization.` });
    return { ...config, rules: { ...config.rules, resumeStrategy: config.rules.resumeStrategy ?? "job-tailored", tailoringMode: config.rules.tailoringMode ?? "deterministic",
      humanInLoop: config.rules.humanInLoop ?? true, autoDiscover: config.rules.autoDiscover ?? true,
      requireRoleFamily: config.rules.requireRoleFamily ?? true, maxWaitingTabs: config.rules.maxWaitingTabs ?? 10, aiAnswers: config.rules.aiAnswers ?? "saved-only" } };
  }
  rules(): AutopilotRules { return this.config().rules; }
  private save(config: Configuration): void { this.store.set("autopilot", config); }
  private updateStatus(status: string, delayMs?: number): void {
    const config = this.config(); config.status = status;
    if (delayMs !== undefined) config.nextRunAt = new Date(Date.now() + delayMs).toISOString();
    this.save(config);
  }
  private row(jobId: string): AutopilotJob | undefined {
    const row = this.store.db.prepare("SELECT json FROM autopilot_jobs WHERE job_id=?").get(jobId);
    return row ? JSON.parse(String(row.json)) as AutopilotJob : undefined;
  }
  private record(job: Job, status: AutopilotJob["status"], reason: string, extra: Partial<Pick<AutopilotJob, "packetId" | "variantId" | "humanTaskId" | "priority">> = {}): AutopilotJob {
    const existing = this.row(job.id), now = new Date().toISOString();
    const row: AutopilotJob = { id: existing?.id ?? randomUUID(), jobId: job.id, createdAt: existing?.createdAt ?? now, updatedAt: now, status, reason, ...existing, ...extra };
    row.status = status; row.reason = reason; row.updatedAt = now; row.seenFetchedAt = job.fetchedAt;
    this.store.db.prepare("INSERT INTO autopilot_jobs VALUES (?,?,?,?) ON CONFLICT(job_id) DO UPDATE SET status=excluded.status,json=excluded.json").run(row.id, job.id, status, JSON.stringify(row));
    return row;
  }
  snapshotHash(): string {
    return digest({ engine: "real-browser-v4-generic-hitl", minimumApprovedResumes: MIN_APPROVED_RESUMES, profile: this.store.profile(), campaign: campaignConfig(this.store),
      inference: this.store.value("inference", { provider: process.env.JAA_AI_PROVIDER ?? "ollama",
        model: process.env.JAA_AI_PROVIDER === "gemini" ? process.env.JAA_GEMINI_MODEL ?? DEFAULT_GEMINI_MODEL : process.env.JAA_AI_PROVIDER === "copilot" ? process.env.JAA_COPILOT_MODEL ?? "gpt-6-astra" : process.env.JAA_OLLAMA_MODEL ?? "qwen3:4b",
        allowRemoteProcessing: process.env.JAA_AI_PROVIDER === "gemini" ? process.env.JAA_ALLOW_GEMINI_REMOTE === "1" : process.env.JAA_ALLOW_COPILOT_REMOTE === "1",
        ...(process.env.JAA_AI_PROVIDER === "gemini" ? { confirmFreeTier: process.env.JAA_GEMINI_FREE_TIER_CONFIRMED === "1" } : {}),
      }),
      ...(process.env.JAA_AI_PROVIDER === "gemini" ? { geminiCredentialRevision: geminiInference.credentialRevision() } : {}),
      careerSources: this.options.careerSources?.scope() ?? [],
      careerInterests: this.options.careerSources?.list().map(source => ({ id: source.id, roleFamilies: source.roleFamilies ?? [] })) ?? [],
      roleFamilies: this.options.families?.list() ?? [],
      rules: this.config().rules, variants: this.library.list().map(variant => ({
        id: variant.id, slot: variant.slot, label: variant.label, families: variant.families,
        sha256: variant.artifact.sha256, bytes: variant.artifact.bytes, approved: variant.approved, issues: variant.issues
      })) });
  }
  blockers(): string[] {
    const profile = this.store.profile(), result = this.library.readiness();
    if (!profile.confirmed || !profile.facts.length || profile.facts.some(fact => !fact.confirmed)) result.unshift("Review and confirm every saved profile fact.");
    if (!profile.name || !profile.email) result.unshift("Save your name and email.");
    if (this.store.value("stopped", false)) result.push("The global queue is stopped. Resume it before activating automatic applications.");
    const campaign = campaignConfig(this.store);
    if (localDate() > shiftDate(campaign.startDate, campaign.days - 1)) result.push("The campaign has ended. Review its dates before enabling a new authorization.");
    return result;
  }
  view(): AutopilotView {
    const config = this.config(), blockers = this.blockers(), snapshotHash = this.snapshotHash();
    if (config.enabled && (!config.authorization || config.authorization.snapshotHash !== snapshotHash || Date.parse(config.authorization.expiresAt) <= Date.now())) {
      this.invalidate("Profile, resume files, rules, career sources or campaign authorization changed/expired. Review and enable again.");
      return this.view();
    }
    return { enabled: config.enabled, ready: blockers.length === 0, blockers, rules: config.rules, authorization: config.authorization,
      snapshotHash, jobs: this.store.db.prepare("SELECT json FROM autopilot_jobs ORDER BY rowid DESC LIMIT 300").all().map(row => JSON.parse(String(row.json)) as AutopilotJob),
      lastRunAt: config.lastRunAt, nextRunAt: config.nextRunAt, browserRunning: this.browser.isRunning(), status: config.status,
      humanTasks: this.monitor.tasks(), liveEvents: this.monitor.events(), discoveryStatus: this.store.value("automaticDiscoveryStatus", "Not started in this session.") };
  }
  setRules(rules: AutopilotRules): void {
    const checked = autopilotRulesSchema.parse(rules);
    if (new Set(checked.providers).size !== checked.providers.length) throw new Error("Choose each provider only once.");
    this.save({ ...this.config(), enabled: false, rules: checked, status: "Rules changed. Review the new scope and enable again." });
  }
  invalidate(reason: string): void {
    const config = this.config(); config.enabled = false; config.status = reason; this.save(config);
  }
  async enable(snapshotHash: string): Promise<void> {
    const blockers = this.blockers();
    if (blockers.length) throw new Error(blockers.join(" "));
    await this.library.verifyApproved();
    if (this.config().rules.resumeStrategy === "job-tailored" && this.config().rules.tailoringMode === "local-ai") {
      const status = await getAiStatus();
      if (!status.available) throw new Error(`Configured AI tailoring is unavailable. ${status.reason ?? "Connect the selected provider or explicitly choose evidence-based tailoring."}`);
    }
    if (snapshotHash !== this.snapshotHash()) throw new Error("The reviewed profile/resume/rule snapshot changed. Refresh and authorize the current version.");
    const campaign = campaignConfig(this.store), config = this.config(), now = new Date().toISOString();
    const endDate = shiftDate(campaign.startDate, campaign.days - 1);
    config.authorization = config.authorization?.snapshotHash === snapshotHash && Date.parse(config.authorization.expiresAt) > Date.now()
      ? config.authorization : { id: randomUUID(), snapshotHash, approvedAt: now, expiresAt: new Date(`${endDate}T23:59:59.999+05:30`).toISOString() };
    config.enabled = true; config.status = "Authorized. The local browser runner will select eligible supported jobs."; config.nextRunAt = now;
    this.save(config);
    this.store.event(null, "autopilot_enabled", `User granted standing authorization ${config.authorization.id} for the reviewed profile, ${this.library.approvedVariants().length} usable approved resumes and rules.`);
    // Re-evaluate unsent jobs under the newly reviewed scope, never attempted/unknown jobs.
    this.store.db.prepare("DELETE FROM autopilot_jobs WHERE status NOT IN ('submitting','submitted_confirmed','submission_unknown') AND job_id NOT IN (SELECT job_id FROM runs)").run();
    this.kick();
    this.discover();
  }
  pause(): void {
    this.invalidate("Paused by you. In-flight transmissions cannot be recalled; outcomes will be reconciled.");
    this.store.event(null, "autopilot_paused", "Automatic applications paused.");
  }
  private authorized(): AutopilotAuthorization {
    const config = this.config();
    if (this.closing || !config.enabled || this.store.value("stopped", false)) throw new Error("Automatic applications are paused.");
    if (!config.authorization || config.authorization.snapshotHash !== this.snapshotHash() || Date.parse(config.authorization.expiresAt) <= Date.now())
      throw new Error("Standing authorization is missing, changed or expired.");
    if (this.blockers().length) throw new Error("Profile or resume prerequisites are no longer satisfied.");
    return config.authorization;
  }
  private browserAssistanceOwns(job: Job): boolean {
    if (!this.store.db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='assistance_records'").get()) return false;
    return !!this.store.db.prepare("SELECT 1 FROM assistance_records WHERE json_extract(json,'$.jobId')=? AND COALESCE(json_extract(json,'$.status'),'')!='queued' LIMIT 1").get(job.id);
  }
  /**
   * Why a job may not run now. A role you picked yourself skips the rule-based filters (score, role family, employer
   * allowlist, salary, location and experience rules) but never the safety checks.
   */
  private candidateReason(job: Job, picked = false): string | undefined {
    if (this.browserAssistanceOwns(job)) return "You are filling this role in your own Chrome; finish it there (or clear it under Applications) before Auto-apply.";
    const profile = this.store.profile(), rules = this.config().rules;
    const match = matchJob(profile, job);
    const blockers = picked ? match.blockers.filter(blocker => blocker !== "Title is outside your requested engineering role families.") : match.blockers;
    if (blockers.length) return blockers.join(" ");
    if (job.sourceId.startsWith("career-") && !this.options.careerSources?.allowsJob(job)) return "This added career source is paused or removed. Its jobs are not authorized for automatic applications.";
    if (job.aiPolicy === "prohibited" || hasNoAiRestriction(`${job.title}\n${job.description}`)) return "This posting requires a human-led/no-AI application.";
    const provider = this.provider(job);
    if ((!provider || !rules.providers.includes(provider)) && !this.options.allowTestJobs) return "Application destination is not a selected supported provider; use manual handoff or its original supported employer URL.";
    if (picked) {
      if (this.store.hasConflictingApplication(job.id) || this.store.db.prepare("SELECT 1 FROM runs WHERE job_id=?").get(job.id)) return "This job has a prior submission or attempt; automatic duplicate retries are prohibited.";
      if (!Number.isFinite(Date.parse(job.fetchedAt)) || Date.now() - Date.parse(job.fetchedAt) > 2 * 86400_000) return "Refresh this stale listing before automatically applying.";
      return undefined;
    }
    if (rules.employerAllowlist.length && !rules.employerAllowlist.some(employer => employer.toLowerCase().trim() === job.company.toLowerCase().trim())) return "Employer is outside your standing allowlist.";
    if (rules.requireRoleFamily !== false && this.options.families) {
      const role = this.options.families.classify(job);
      if (!role.relevant || !role.interested) return `Not a role you apply to here. ${role.reason}`;
    }
    if (match.score < rules.minimumScore) return `JD alignment ${match.score} is below your configured ${rules.minimumScore}.`;
    if (!job.salary && !rules.allowUnknownSalary) return "Salary is undisclosed and your rules exclude unknown compensation.";
    const authorized = profile.preferences.authorizedCountries.map(country);
    const local = authorized.some(value => job.countries.map(country).includes(value) || job.location.toLowerCase().includes(value));
    const location = `${job.location} ${job.countries.join(" ")}`;
    const worldwide = /\bworldwide\b|\banywhere in the world\b/i.test(location)
      && !/\bexcept\b|\bexcluding\b|\bnot (?:available|eligible)\b/i.test(location);
    if (job.remote && !local && !worldwide && !rules.allowUnknownRemoteEligibility) return "Working remotely from your authorized country is unverified; your rules require explicit eligibility.";
    if (!local && !(job.remote && worldwide) && job.sponsorship === "unknown" && !rules.allowUnknownSponsorship) return "Overseas sponsorship is unverified; your rules exclude unknown sponsorship.";
    if (match.warnings.some(warning => warning.includes("another language"))) return "The role may mandate another language. Review language eligibility before automatic submission.";
    const requirement = job.description.match(/(?:at least|minimum(?: of)?|must have)\s+(\d{1,2})\+?\s+years?[^.\n]{0,50}\bexperience\b/i);
    const years = Number(profile.answers.total_years_experience);
    if (requirement && profile.answers.total_years_experience && Number.isFinite(years) && years < Number(requirement[1])) return "An explicit experience minimum exceeds your saved total experience.";
    if (this.store.hasConflictingApplication(job.id) || this.store.db.prepare("SELECT 1 FROM runs WHERE job_id=?").get(job.id)) return "This job has a prior submission or attempt; automatic duplicate retries are prohibited.";
    if (!Number.isFinite(Date.parse(job.fetchedAt)) || Date.now() - Date.parse(job.fetchedAt) > 86400_000) return "Refresh this stale listing before automatically applying.";
    return undefined;
  }
  private permit(job: Job, variant: ResumeVariant, authorization: AutopilotAuthorization): ExecutionPermit {
    return { authorizationId: authorization.id, sourceLimit: null, assert: () => {
      if (this.browserAssistanceOwns(job)) throw new Error("Browser assistance owns this job; explicitly queue it or finish manually.");
      const current = this.authorized();
      if (current.id !== authorization.id) throw new Error("Authorization changed during execution.");
      const active = this.library.list().find(item => item.id === variant.id);
      if (!active?.approved || active.issues.length || active.artifact.sha256 !== variant.artifact.sha256) throw new Error("Selected resume changed or was revoked.");
      const provider = this.provider(job);
      if ((!provider || !this.config().rules.providers.includes(provider)) && !this.options.allowTestJobs) throw new Error("Provider is outside the authorized scope.");
      const latestJob = this.store.job(job.id);
      if (!latestJob || jobHash(latestJob) !== jobHash(job) || !matchJob(this.store.profile(), latestJob).eligible) throw new Error("Job details or eligibility changed during execution.");
      if (latestJob.sourceId.startsWith("career-") && !this.options.careerSources?.allowsJob(latestJob)) throw new Error("The career source is no longer enabled.");
    } };
  }
  /** The job's role family decides the resume slot; otherwise the best text match among approved resumes. */
  chooseResume(job: Job, snapshot?: Parameters<ResumeLibrary["choose"]>[1]) {
    const families = this.options.families;
    const classification: JobClassification | undefined = families?.classify(job);
    const slots = Object.fromEntries((families?.list() ?? []).filter(family => family.resumeSlot).map(family => [family.id, family.resumeSlot!]));
    return this.library.choose(job, snapshot, classification, slots);
  }
  private nextDay(): string { return new Date(`${shiftDate(localDate(), 1)}T00:00:00+05:30`).toISOString(); }
  /** Whether the Chairman window can run this job's application at all (a supported, allowed provider). */
  supports(job: Job): boolean {
    const provider = this.provider(job);
    return !!provider && (this.config().rules.providers.includes(provider) || !!this.options.allowTestJobs);
  }
  private provider(job: Job) {
    return providerForUrl(job.applyUrl) ?? (canUsePortal(job.applyUrl) ? "generic" : undefined);
  }
  private discover(): void {
    if (this.discoveryPending || this.config().rules.autoDiscover === false || !this.config().enabled || !this.options.discover) return;
    if (this.store.value("nextAutomaticDiscovery", 0) > Date.now()) return;
    this.store.set("nextAutomaticDiscovery", Date.now() + 15 * 60_000);
    this.store.set("automaticDiscoveryStatus", "Searching permitted public job feeds and configured career pages for your preferences.");
    this.monitor.event("discovery", "Searching public job sources; resume and application answers are not sent to discovery services.");
    this.discoveryPending = this.options.discover().then(message => {
      this.store.set("automaticDiscoveryStatus", message); this.monitor.event("discovery", message);
    }).catch(error => {
      const message = error instanceof Error ? error.message : "Automatic discovery failed.";
      this.store.set("automaticDiscoveryStatus", message); this.monitor.event("discovery_error", message);
    }).finally(() => { this.discoveryPending = undefined; });
  }
  async cycle(): Promise<void> {
    const authorization = this.authorized(), config = this.config();
    this.discover();
    await this.workflows.watch().catch(() => 0);
    if (await this.workflows.resumePending()) return;
    if (config.nextRunAt && Date.parse(config.nextRunAt) > Date.now()) return;
    const waitingLimit = config.rules.maxWaitingTabs ?? 10;
    if (this.monitor.pendingCount() >= waitingLimit) { this.updateStatus(`${waitingLimit} prefilled applications are waiting for you (CAPTCHA or answers). Finish or abandon one to open another.`, 15_000); return; }
    const profile = this.store.profile(), campaign = campaignStats(this.store);
    if ((profile.preferences.dailyLimit !== null && this.store.attempts(localDate()) >= profile.preferences.dailyLimit)
      || (config.rules.stopAtDailyGoal && campaign.confirmedToday >= campaign.config.dailyTarget)) {
      this.save({ ...config, nextRunAt: this.nextDay(), status: "Configured daily cap/goal reached. Waiting for the next reporting day." }); return;
    }
    if (localDate() < campaign.config.startDate) { this.updateStatus("Campaign has not started.", 60_000); return; }
    // Roles you picked run first (oldest request first); the pacing interval and waiting-tab limit still apply.
    const picked = this.store.db.prepare(`SELECT j.json FROM autopilot_jobs a JOIN jobs j ON j.id=a.job_id
      WHERE a.status='queued' AND json_extract(a.json,'$.priority')=1 ORDER BY json_extract(a.json,'$.updatedAt') LIMIT 20`).all().map(row => JSON.parse(String(row.json)) as Job);
    const pickedJob = picked.find(job => {
      const reason = this.candidateReason(job, true);
      if (reason) this.record(job, this.provider(job) ? "skipped" : "unsupported", reason, { priority: false });
      return !reason;
    });
    const candidates = pickedJob ? [] : this.store.db.prepare(`SELECT j.json FROM jobs j LEFT JOIN autopilot_jobs a ON a.job_id=j.id
      WHERE a.id IS NULL OR a.status='queued' OR (a.status IN ('skipped','unsupported')
      AND COALESCE(json_extract(a.json,'$.seenFetchedAt'),'')!=json_extract(j.json,'$.fetchedAt'))
      ORDER BY j.rowid DESC LIMIT 500`).all().map(row => JSON.parse(String(row.json)) as Job)
      .map(job => ({ job, score: matchJob(profile, job).score })).sort((a, b) => b.score - a.score).map(item => item.job);
    let selected: Job | undefined = pickedJob, examined = 0;
    for (const job of candidates) {
      if (examined++ >= 200) break;
      const reason = this.candidateReason(job);
      if (reason) { this.record(job, this.provider(job) ? "skipped" : "unsupported", reason); continue; }
      const backoff = this.store.value(`autopilotBackoff:${new URL(job.applyUrl).hostname}`, 0);
      if (backoff > Date.now()) continue;
      selected = job; break;
    }
    if (!selected) {
      this.updateStatus(examined >= 200 ? "Screened a bounded candidate batch; continuing shortly." : "No eligible unattempted supported jobs are ready. Discovery continues independently.", examined >= 200 ? 5000 : 60_000);
      return;
    }
    const job = selected;
    this.save({ ...this.config(), lastRunAt: new Date().toISOString(), status: `Inspecting ${job.company} - ${job.title}.` });
    this.record(job, "inspecting", "Reading form structure; no applicant data transmitted.");
    if (this.browser.runWorkflow) {
      const choice = this.chooseResume(job);
      if (!choice) { this.record(job, "needs_input", "No approved resume template is available."); return; }
      try {
        await this.workflows.run(job, choice.variant, authorization, config.rules);
      } catch (error) {
        const reason = error instanceof Error ? error.message : "Monitored workflow could not be started.";
        this.record(job, "failed", reason); this.monitor.event("failed", reason, job.id);
      } finally {
        const latest = this.config(), state = this.row(job.id);
        if (latest.enabled) latest.status = `${job.company}: ${state?.status ?? "finished"} - ${state?.reason ?? ""}`;
        latest.nextRunAt = new Date(Date.now() + latest.rules.intervalSeconds * 1000).toISOString(); this.save(latest);
      }
      return;
    }
    let packetId: string | undefined, runToken: string | undefined, submissionStarted = false;
    try {
      const inspection = await this.browser.inspect(job);
      this.authorized();
      if (inspection.retryAfterMs !== undefined) this.store.set(`autopilotBackoff:${new URL(job.applyUrl).hostname}`, Number.isFinite(inspection.retryAfterMs) ? Math.min(Number.MAX_SAFE_INTEGER, Date.now() + Math.max(60_000, inspection.retryAfterMs)) : Number.MAX_SAFE_INTEGER);
      if (inspection.status !== "ready" || !inspection.snapshot) {
        const status = inspection.status === "job_closed" ? "skipped" : inspection.status === "ready" ? "unsupported" : inspection.status;
        this.record(job, status, inspection.reason); return;
      }
      if (!sameApplication(job.applyUrl, inspection.snapshot.url) && !this.options.allowTestJobs) throw new Error("The form does not belong to the selected application.");
      const plan = resolveAnswers(profile, job, inspection.snapshot, profileResolveOptions(profile));
      if (plan.blockers.length || plan.missing.length) {
        this.record(job, "needs_input", [...plan.blockers, ...plan.missing].join(" ")); return;
      }
      const tailoring = config.rules.resumeStrategy === "job-tailored";
      const choice = this.chooseResume(job, tailoring ? undefined : inspection.snapshot);
      if (!choice) { this.record(job, "needs_input", "No approved compatible resume is available for this form."); return; }
      const bytes = await this.library.bytes(choice.variant.id), permit = this.permit(job, choice.variant, authorization);
      permit.assert();
      const packet = tailoring
        ? await this.engine.prepareTailored(job.id, choice.variant, bytes, config.rules.tailoringMode ?? "deterministic", plan.answers, inspection.snapshot)
        : await this.engine.prepareUploaded(job.id, choice.variant, bytes, plan.answers, inspection.snapshot, this.library.path(choice.variant.id));
      permit.assert();
      packetId = packet.id;
      this.record(job, "inspecting", tailoring ? "JD-specific PDF/DOCX and factual answer plan prepared; checking standing authorization." : "Exact original variant and answer plan prepared; checking standing authorization.", { packetId, variantId: choice.variant.id });
      await this.engine.approveAutomatic(packet.id, permit);
      const claim = await this.engine.claim(packet.id, permit); runToken = claim.runToken;
      const submissionArtifact = this.engine.submissionArtifact(claim.packet);
      const reason = tailoring ? `${choice.variant.label}: generated a ${submissionArtifact.format.toUpperCase()} matched to this job's description from confirmed facts.` : choice.reason;
      this.record(job, "submitting", reason, { packetId, variantId: choice.variant.id });
      const result = await this.browser.submit({
        job, snapshot: inspection.snapshot, answers: plan.answers,
        resumePath: join(this.engine.directory(packet.id), submissionArtifact.filename),
        resumeFilename: tailoring ? `resume-${packet.id}.${submissionArtifact.format}` : choice.variant.originalFilename,
        resumeSha256: submissionArtifact.sha256,
        checkAuthorization: async () => { try { permit.assert(); return true; } catch { return false; } },
        beforeSubmit: async () => {
          permit.assert(); submissionStarted = true;
          this.store.event(packet.id, "submit_started", "Final submit action is about to be issued; a lost outcome must not be retried.");
        }
      });
      if (result.retryAfterMs !== undefined) this.store.set(`autopilotBackoff:${new URL(job.applyUrl).hostname}`, Number.isFinite(result.retryAfterMs) ? Math.min(Number.MAX_SAFE_INTEGER, Date.now() + Math.max(60_000, result.retryAfterMs)) : Number.MAX_SAFE_INTEGER);
      if (result.status === "submitted_confirmed" && !submissionStarted) throw new Error("The browser did not persist the submit boundary; a receipt cannot be accepted.");
      const outcome = result.status === "submitted_confirmed" ? "submitted_confirmed"
        : result.status === "submission_unknown" || submissionStarted ? "submission_unknown" : "failed";
      this.engine.report(packet.id, runToken, outcome, result.evidence, result.reason);
      this.record(job, outcome, result.reason, { packetId, variantId: choice.variant.id });
    } catch (error) {
      const reason = error instanceof Error ? error.message : "Automatic application failed.";
      if (packetId && runToken) {
        const outcome = submissionStarted ? "submission_unknown" : "failed";
        const current = this.store.packet(packetId);
        if (current?.status === "executing" || current?.status === "submission_unknown") this.engine.report(packetId, runToken, outcome, undefined, reason);
        this.record(job, current?.status === "submitted_confirmed" ? "submitted_confirmed" : outcome, reason, { packetId });
      } else {
        if (packetId) {
          const packet = this.store.packet(packetId);
          if (packet?.approvedBy === "autopilot" && packet.status === "approved") {
            packet.status = "withdrawn_from_queue"; packet.error = reason; this.store.putPacket(packet);
          }
        }
        this.record(job, "failed", reason, packetId ? { packetId } : {});
      }
    } finally {
      const latest = this.config();
      const state = this.row(job.id);
      latest.status = latest.enabled ? `${job.company}: ${state?.status ?? "finished"}${state?.reason ? ` - ${state.reason}` : ""}` : latest.status;
      latest.nextRunAt = new Date(Date.now() + latest.rules.intervalSeconds * 1000).toISOString(); this.save(latest);
    }
  }
  kick(): void {
    if (this.pending || this.closing || !this.config().enabled) return;
    this.pending = this.cycle().catch(error => {
      this.invalidate(error instanceof Error ? error.message : "Autopilot stopped after an unexpected error.");
    }).finally(() => { this.pending = undefined; });
  }
  /** Queues roles you picked (Today → Auto-apply) ahead of everything else, under your standing Auto Apply authorization. */
  prioritize(jobIds: string[]): { queued: string[]; skipped: { jobId: string; reason: string }[] } {
    if (!this.config().enabled) throw new Error("Auto Apply is paused. Activate it under Auto Apply first; it is what lets the Chairman window fill and submit for you.");
    this.authorized();
    const queued: string[] = [], skipped: { jobId: string; reason: string }[] = [];
    for (const jobId of [...new Set(jobIds)].slice(0, 300)) {
      const job = this.store.job(jobId);
      if (!job) { skipped.push({ jobId, reason: "This role is no longer tracked." }); continue; }
      const current = this.row(job.id);
      if (current && !["queued", "skipped", "unsupported", "failed", "needs_input"].includes(current.status)) { skipped.push({ jobId, reason: `Already ${current.status.replaceAll("_", " ")}.` }); continue; }
      const reason = this.candidateReason(job, true);
      if (reason) { skipped.push({ jobId, reason }); continue; }
      this.record(job, "queued", "You picked this role from today's list; it runs next.", { priority: true });
      queued.push(jobId);
    }
    if (queued.length) {
      // Run soon: only the pacing interval since the last application applies, not an idle "nothing to do" wait.
      const config = this.config(), earliest = config.lastRunAt ? Date.parse(config.lastRunAt) + config.rules.intervalSeconds * 1000 : 0;
      this.save({ ...config, nextRunAt: new Date(Math.max(Date.now(), earliest)).toISOString() });
      this.monitor.event("queued", `${queued.length} role${queued.length === 1 ? "" : "s"} you picked will be filled next.`);
      this.kick();
    }
    return { queued, skipped };
  }
  retry(id: string): void {
    const row = this.store.db.prepare("SELECT json FROM autopilot_jobs WHERE id=?").get(id);
    if (!row) throw new Error("Automatic job record not found.");
    const record = JSON.parse(String(row.json)) as AutopilotJob;
    if (["submitted_confirmed", "submission_unknown", "submitting"].includes(record.status)
      || this.store.db.prepare("SELECT 1 FROM runs WHERE job_id=?").get(record.jobId))
      throw new Error("This job has a submission attempt or uncertain outcome. Reconcile manually; it cannot be automatically retried.");
    const job = this.store.job(record.jobId);
    if (!job) throw new Error("Job no longer exists.");
    this.record(job, "queued", "User requested a fresh preflight after resolving the blocker."); this.kick();
  }
  async openBrowser(url?: string): Promise<void> { await this.browser.openForSetup(url); }
  continueHuman(id: string, input: HumanContinuation): void { this.workflows.queueContinuation(id, input); this.kick(); }
  async focusHuman(id: string): Promise<void> { await this.workflows.focus(id); }
  async abandonHuman(id: string): Promise<void> { await this.workflows.abandon(id); }
  async resolveHumanPacket(packetId: string): Promise<void> { await this.workflows.resolveManually(packetId); }
  async screenshot(sessionId?: string): Promise<Buffer | undefined> { return this.browser.screenshotWorkflow?.(sessionId); }
  async pauseAndDrain(): Promise<void> { this.pause(); await this.browser.close(); await this.pending; this.workflows.clear(); }
  start(): void {
    this.closing = false;
    this.monitor.recover();
    for (const row of this.store.db.prepare("SELECT json FROM autopilot_jobs WHERE status IN ('inspecting','prefilling','submitting','awaiting_human')").all()) {
      const record = JSON.parse(String(row.json)) as AutopilotJob, job = this.store.job(record.jobId);
      if (!job) continue;
      const attempted = this.store.db.prepare("SELECT 1 FROM runs WHERE job_id=?").get(job.id);
      if (!attempted) for (const packet of this.store.packetsForJob(job.id)) {
        if (packet.approvedBy === "autopilot" && packet.status === "approved") {
          packet.status = "withdrawn_from_queue";
          packet.error = "Interrupted before transmission; a fresh authorization check is required.";
          this.store.putPacket(packet);
        }
      }
      this.record(job, attempted ? "submission_unknown" : "queued", attempted ? "Service restarted during an attempt. Reconcile before any retry." : "Restarted before data transmission; safe to re-inspect.");
    }
    this.timer = setInterval(() => { this.view(); this.watchParked(); this.kick(); }, 5000); this.timer.unref();
  }
  /** Notices solved CAPTCHAs while another application is being filled, so they continue right after it. */
  private watchParked(): void {
    if (this.watching || this.closing || !this.config().enabled) return;
    this.watching = this.workflows.watch().catch(() => 0).finally(() => { this.watching = undefined; });
  }
  async close(): Promise<void> { this.closing = true; clearInterval(this.timer); await this.pending; await this.watching; await this.discoveryPending; await this.browser.close(); this.workflows.clear(); }
}
