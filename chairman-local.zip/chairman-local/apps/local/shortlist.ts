import type { FastifyInstance } from "fastify";
import { z } from "zod";
import type { Job } from "../../packages/domain/types.js";
import type { ApplicationEvidence } from "../../packages/domain/progress.js";
import { localDate, shiftDate } from "../../packages/domain/dates.js";
import { candidateYears, defaultLevels, jobFit, SENIORITIES, type ExclusionKind, type FitPolicy, type JobFit, type LocationTier, type Seniority, type Sponsorship } from "../../packages/domain/job-fit.js";
import type { AutopilotService } from "./autopilot.js";
import type { CareerSourceService } from "./career-sources.js";
import type { ProgressService } from "./progress.js";
import type { RoleFamilyService } from "./role-families.js";
import { Store } from "./store.js";

/** Your daily list: how many roles, when it is built, and which locations and levels count. */
export interface ShortlistSettings {
  enabled: boolean;
  dailyCount: number;
  /** Hour of day (India time) the list is built, after a fresh crawl of every company. */
  runHour: number;
  maxPerCompany: number;
  priority: "abroad-first" | "india-first";
  includeIndia: boolean;
  includeRemoteGlobal: boolean;
  includeAbroadSponsored: boolean;
  includeAbroadUnknown: boolean;
  /** Years used for matching; null uses Profile (total_years_experience, or your confirmed experience dates). */
  experienceYears: number | null;
  /** Levels you target; null derives them from your years. */
  levels: Seniority[] | null;
  maxAgeDays: number;
  minScore: number;
}
export const DEFAULT_SHORTLIST: ShortlistSettings = {
  enabled: true, dailyCount: 100, runHour: 7, maxPerCompany: 10, priority: "abroad-first",
  includeIndia: true, includeRemoteGlobal: true, includeAbroadSponsored: true, includeAbroadUnknown: true,
  experienceYears: null, levels: null, maxAgeDays: 60, minScore: 30,
};
export const shortlistSettingsSchema = z.object({
  enabled: z.boolean(), dailyCount: z.number().int().min(1).max(300), runHour: z.number().int().min(0).max(23), maxPerCompany: z.number().int().min(1).max(100),
  priority: z.enum(["abroad-first", "india-first"]), includeIndia: z.boolean(), includeRemoteGlobal: z.boolean(), includeAbroadSponsored: z.boolean(),
  includeAbroadUnknown: z.boolean(), experienceYears: z.number().min(0).max(60).nullable(), levels: z.array(z.enum(SENIORITIES as [Seniority, ...Seniority[]])).min(1).max(8).nullable(),
  maxAgeDays: z.number().int().min(1).max(365), minScore: z.number().int().min(0).max(100),
}).strict();

/** "applied" always has proof (a confirmation page, receipt or email); "marked" is your own unverified "I submitted it". */
export type ShortlistStatus = "new" | "opened" | "filled" | "review" | "auto_queued" | "needs_you" | "applied" | "marked" | "skipped" | "failed";
interface StoredEntry {
  jobId: string; rank: number; score: number; tier: LocationTier; label: string; sponsorship: Sponsorship; experience: string;
  family?: string; skills: string[]; reasons: string[]; carriedOver: boolean;
}
interface Snapshot { date: string; generatedAt: string; entries: StoredEntry[]; candidates: number; excluded: Partial<Record<ExclusionKind | "score" | "cap", number>>; years?: number; levels: Seniority[] }
export interface ShortlistEntry extends StoredEntry {
  company: string; title: string; location: string; applyUrl: string; postedAt?: string; aiPolicy: Job["aiPolicy"];
  /** The Chairman window can apply here (a supported provider, no-AI rules permitting); otherwise use your own Chrome. */
  autoApply: boolean;
  status: ShortlistStatus; detail?: string; updatedAt?: string;
  /** Why it counts as applied: only present when status is "applied". */
  evidence?: ApplicationEvidence;
}
export interface ShortlistView {
  date: string; generatedAt?: string; settings: ShortlistSettings; entries: ShortlistEntry[];
  counts: Record<ShortlistStatus, number> & { total: number }; candidates: number; excluded: Snapshot["excluded"];
  years?: number; levels: Seniority[]; companies: { total: number; crawled: number; stale: number };
  autoApply: { enabled: boolean; reason?: string }; nextBuildAt?: string;
}
const STATUSES: ShortlistStatus[] = ["new", "opened", "filled", "review", "auto_queued", "needs_you", "applied", "marked", "skipped", "failed"];
const emptyCounts = () => Object.fromEntries([...STATUSES.map(status => [status, 0]), ["total", 0]]) as ShortlistView["counts"];
const hourInIndia = (now = new Date()) => Number(new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Kolkata", hour: "2-digit", hourCycle: "h23" }).format(now));

export class ShortlistService {
  private timer?: ReturnType<typeof setInterval>;
  private refreshed?: { date: string; at: number };
  constructor(readonly store: Store, readonly careerSources: CareerSourceService, readonly families: RoleFamilyService,
    readonly progress: ProgressService, readonly autopilot: AutopilotService) {
    store.db.exec(`CREATE TABLE IF NOT EXISTS shortlists(date TEXT PRIMARY KEY, json TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS shortlist_state(job_id TEXT PRIMARY KEY, status TEXT NOT NULL, updated_at TEXT NOT NULL)`);
  }
  settings(): ShortlistSettings { return { ...DEFAULT_SHORTLIST, ...this.store.value<Partial<ShortlistSettings>>("shortlist-settings", {}) }; }
  saveSettings(input: unknown): ShortlistSettings {
    const settings = shortlistSettingsSchema.parse(input);
    this.store.set("shortlist-settings", settings);
    return settings;
  }
  private snapshot(date: string): Snapshot | undefined {
    const row = this.store.db.prepare("SELECT json FROM shortlists WHERE date=?").get(date);
    return row ? JSON.parse(String(row.json)) as Snapshot : undefined;
  }
  private marks(): Map<string, { status: ShortlistStatus; updatedAt: string }> {
    return new Map(this.store.db.prepare("SELECT job_id,status,updated_at FROM shortlist_state").all()
      .map(row => [String(row.job_id), { status: String(row.status) as ShortlistStatus, updatedAt: String(row.updated_at) }]));
  }
  mark(jobId: string, status: "opened" | "skipped" | "applied" | "new" | "auto_queued"): void {
    if (!this.store.job(jobId)) throw new Error("That role is no longer tracked.");
    if (status === "new") this.store.db.prepare("DELETE FROM shortlist_state WHERE job_id=?").run(jobId);
    else this.store.db.prepare("INSERT INTO shortlist_state VALUES (?,?,?) ON CONFLICT(job_id) DO UPDATE SET status=excluded.status,updated_at=excluded.updated_at")
      .run(jobId, status, new Date().toISOString());
  }
  /** The policy used for fit, with your years and levels resolved. */
  policy(settings = this.settings()): FitPolicy & { years?: number } {
    const years = settings.experienceYears ?? candidateYears(this.store.profile());
    return { priority: settings.priority, includeIndia: settings.includeIndia, includeRemoteGlobal: settings.includeRemoteGlobal,
      includeAbroadSponsored: settings.includeAbroadSponsored, includeAbroadUnknown: settings.includeAbroadUnknown,
      ...(years !== undefined ? { years } : {}), levels: settings.levels ?? defaultLevels(years), maxAgeDays: settings.maxAgeDays };
  }
  /** Scores every open role at your tracked companies and keeps the best `dailyCount`, at most `maxPerCompany` per company. */
  build(date = localDate(), now = new Date()): ShortlistView {
    const settings = this.settings(), policy = this.policy(settings), profile = this.store.profile();
    const sources = new Map(this.careerSources.list().filter(source => source.enabled).map(source => [source.id, source]));
    const marks = this.marks(), previous = new Set(this.snapshot(shiftDate(date, -1))?.entries.map(entry => entry.jobId) ?? []);
    const excluded: Snapshot["excluded"] = {};
    const count = (kind: keyof Snapshot["excluded"]) => { excluded[kind] = (excluded[kind] ?? 0) + 1; };
    const seen = new Set<string>(), scored: { job: Job; fit: JobFit }[] = [];
    for (const row of this.store.db.prepare("SELECT j.json, c.source_id FROM jobs j JOIN career_source_jobs c ON c.job_id=j.id").all()) {
      const job = JSON.parse(String(row.json)) as Job, source = sources.get(String(row.source_id));
      if (!source || seen.has(job.id)) continue;
      seen.add(job.id);
      if (job.status === "closed" || job.cacheExpired) continue;
      const mark = marks.get(job.id)?.status;
      if (mark === "skipped" || mark === "applied") continue;
      const classification = this.families.classify(job);
      const state = this.progress.statusFor(job, classification).status;
      if (state === "applied" || state === "marked" || state === "in_progress" || state === "needs_you") continue;
      const fit = jobFit(job, profile, classification, policy, source.sponsorsVisas);
      if (!fit.eligible) { count(fit.excludedKind ?? "blocked"); continue; }
      if (fit.score < settings.minScore) { count("score"); continue; }
      scored.push({ job, fit });
    }
    // Your priority is a strict order of tiers; within a tier, the best fit (then the newest posting) comes first.
    const tier = (fit: JobFit) => {
      const abroad = fit.location.tier === "abroad" || fit.location.tier === "unknown";
      if (abroad && fit.location.sponsorship !== "available") return 2;
      return abroad === (settings.priority === "abroad-first") ? 0 : 1;
    };
    scored.sort((a, b) => tier(a.fit) - tier(b.fit) || b.fit.score - a.fit.score || (b.job.postedAt ?? "").localeCompare(a.job.postedAt ?? ""));
    const perCompany = new Map<string, number>(), entries: StoredEntry[] = [];
    for (const { job, fit } of scored) {
      if (entries.length >= settings.dailyCount) break;
      const company = job.company.toLowerCase().trim(), used = perCompany.get(company) ?? 0;
      if (used >= settings.maxPerCompany) { count("cap"); continue; }
      perCompany.set(company, used + 1);
      entries.push({ jobId: job.id, rank: entries.length + 1, score: fit.score, tier: fit.location.tier, label: fit.location.label, sponsorship: fit.location.sponsorship,
        experience: fit.experience.reason, ...(fit.familyLabel ? { family: fit.familyLabel } : {}), skills: fit.matchedSkills.slice(0, 8), reasons: fit.reasons,
        carriedOver: previous.has(job.id) });
    }
    const snapshot: Snapshot = { date, generatedAt: now.toISOString(), entries, candidates: scored.length, excluded,
      ...(policy.years !== undefined ? { years: policy.years } : {}), levels: policy.levels };
    this.store.db.prepare("INSERT INTO shortlists VALUES (?,?) ON CONFLICT(date) DO UPDATE SET json=excluded.json").run(date, JSON.stringify(snapshot));
    this.store.db.prepare("DELETE FROM shortlists WHERE date < ?").run(shiftDate(date, -60));
    this.store.event(null, "shortlist_built", `Daily list for ${date}: ${entries.length} roles from ${scored.length} eligible.`);
    return this.view(date);
  }
  view(date = localDate()): ShortlistView {
    const settings = this.settings(), snapshot = this.snapshot(date), marks = this.marks();
    const counts = emptyCounts();
    const entries: ShortlistEntry[] = [];
    for (const entry of snapshot?.entries ?? []) {
      const job = this.store.job(entry.jobId);
      if (!job) continue;
      const progress = this.progress.statusFor(job, this.families.classify(job));
      const mark = marks.get(job.id);
      const status: ShortlistStatus = progress.status === "applied" ? "applied" : progress.status === "marked" ? "marked"
        : progress.status === "needs_you" ? "needs_you" : progress.status === "failed" ? "failed"
          : progress.status === "in_progress" ? progress.channel === "auto_apply" ? "auto_queued" : progress.step ?? "opened"
            : mark?.status === "applied" ? "marked" : mark?.status ?? "new";
      counts[status]++; counts.total++;
      entries.push({ ...entry, company: job.company, title: job.title, location: job.location, applyUrl: job.applyUrl, ...(job.postedAt ? { postedAt: job.postedAt } : {}),
        aiPolicy: job.aiPolicy, autoApply: job.aiPolicy !== "prohibited" && this.autopilot.supports(job), status, ...(progress.status !== "not_applied" && progress.status !== "not_relevant" ? { detail: progress.detail } : {}),
        ...(progress.evidence ? { evidence: progress.evidence } : {}),
        ...(progress.updatedAt ?? mark?.updatedAt ? { updatedAt: progress.updatedAt ?? mark!.updatedAt } : {}) });
    }
    const sources = this.careerSources.list().filter(source => source.enabled && source.target);
    const stale = sources.filter(source => !source.lastScannedAt || Date.now() - Date.parse(source.lastScannedAt) > 26 * 3600_000).length;
    const auto = this.autopilot.view();
    const policy = this.policy(settings), years = snapshot ? snapshot.years : policy.years;
    return { date, ...(snapshot ? { generatedAt: snapshot.generatedAt } : {}), settings, entries, counts, candidates: snapshot?.candidates ?? 0, excluded: snapshot?.excluded ?? {},
      ...(years !== undefined ? { years } : {}), levels: snapshot?.levels ?? policy.levels,
      companies: { total: sources.length, crawled: sources.length - stale, stale },
      autoApply: auto.enabled ? { enabled: true } : { enabled: false, reason: "Auto Apply is paused. Activate it under Auto Apply to let the Chairman window fill and submit roles you pick." },
      ...(settings.enabled && !snapshot ? { nextBuildAt: `${settings.runHour.toString().padStart(2, "0")}:00 India time` } : {}) };
  }
  /**
   * Morning routine: refresh every company's roles, then build the list once the crawls are in (or after 45 minutes).
   * A list you built earlier today, before the morning hour, is provisional and is rebuilt once after it.
   */
  tick(now = new Date()): void {
    const settings = this.settings(), date = localDate(now);
    if (!settings.enabled || hourInIndia(now) < settings.runHour) return;
    const built = this.snapshot(date)?.generatedAt;
    const morning = Date.parse(`${date}T${String(settings.runHour).padStart(2, "0")}:00:00+05:30`);
    if (built && Date.parse(built) >= morning) return;
    if (this.refreshed?.date !== date) { this.careerSources.refreshAll(12 * 3600_000); this.refreshed = { date, at: now.getTime() }; return; }
    const pending = this.careerSources.list().filter(source => source.enabled && source.target
      && (!source.lastScannedAt || now.getTime() - Date.parse(source.lastScannedAt) > 12 * 3600_000) && source.status !== "error").length;
    if (pending && now.getTime() - this.refreshed.at < 45 * 60_000) return;
    this.build(date, now);
  }
  start(): void { this.timer = setInterval(() => { try { this.tick(); } catch (error) { this.store.event(null, "shortlist_error", error instanceof Error ? error.message : "Daily list failed."); } }, 60_000); this.timer.unref(); }
  close(): void { clearInterval(this.timer); }
}

export function registerShortlist(app: FastifyInstance, service: ShortlistService): void {
  const jobParam = (params: unknown) => z.object({ jobId: z.string().min(1).max(300) }).parse(params).jobId;
  app.get("/api/shortlist", async request => {
    const { date } = z.object({ date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional() }).parse(request.query);
    return service.view(date);
  });
  app.post("/api/shortlist/rebuild", async () => service.build());
  app.post("/api/shortlist/refresh", async () => ({ due: service.careerSources.refreshAll(0), view: service.view() }));
  app.post("/api/shortlist/settings", async request => {
    const { settings } = z.object({ settings: z.unknown() }).strict().parse(request.body);
    service.saveSettings(settings);
    return service.build();
  });
  app.post("/api/shortlist/:jobId/status", async request => {
    const { status } = z.object({ status: z.enum(["opened", "skipped", "applied", "new"]) }).strict().parse(request.body);
    service.mark(jobParam(request.params), status);
    return service.view();
  });
  app.post("/api/shortlist/:jobId/auto-apply", async request => {
    const result = service.autopilot.prioritize([jobParam(request.params)]);
    if (!result.queued.length) throw new Error(result.skipped[0]?.reason ?? "This role cannot be auto-applied.");
    for (const id of result.queued) service.mark(id, "auto_queued");
    return { ...service.view(), queued: result.queued.length };
  });
  app.post("/api/shortlist/auto-apply", async request => {
    const { jobIds } = z.object({ jobIds: z.array(z.string().min(1).max(300)).max(300).optional() }).strict().parse(request.body ?? {});
    const view = service.view();
    const ids = jobIds ?? view.entries.filter(entry => entry.status === "new" && entry.autoApply).map(entry => entry.jobId);
    const result = service.autopilot.prioritize(ids);
    for (const id of result.queued) service.mark(id, "auto_queued");
    return { ...service.view(), queued: result.queued.length, skipped: result.skipped };
  });
}
