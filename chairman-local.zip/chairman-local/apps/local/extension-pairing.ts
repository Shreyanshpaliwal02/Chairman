import { createHash, randomUUID } from "node:crypto";
import { lstat, mkdir, open, readFile, rename, rm } from "node:fs/promises";
import { join } from "node:path";
import { z } from "zod";

/**
 * The extension pairing, kept across service restarts so open application tabs keep working: only a SHA-256 hash of the
 * pairing token (never the token), the paired extension's origin, and whether its side panel connected. Owner-only file.
 */
export interface Pairing { tokenHash: string; origin: string; paired: boolean }
const pairingSchema = z.object({
  tokenHash: z.string().regex(/^[a-f0-9]{64}$/),
  origin: z.string().regex(/^(?:chrome-extension:\/\/[a-p]{32})?$/),
  paired: z.boolean(),
}).strict();
export const hashPairingToken = (token: string) => createHash("sha256").update(token, "utf8").digest("hex");

export function createPairingStore(dataDir: string) {
  const directory = join(dataDir, "private");
  const path = join(directory, "extension-pairing.json");
  const privateOnly = (mode: number) => process.platform === "win32" || (mode & 0o077) === 0;
  return {
    /** The saved pairing, or undefined when none is saved or the file is not private (it is then ignored, not trusted). */
    async load(): Promise<Pairing | undefined> {
      try {
        const dir = await lstat(directory);
        if (!dir.isDirectory() || dir.isSymbolicLink() || !privateOnly(dir.mode)) return undefined;
        const info = await lstat(path);
        if (!info.isFile() || info.isSymbolicLink() || info.size > 1024 || !privateOnly(info.mode)) return undefined;
        const parsed = pairingSchema.safeParse(JSON.parse(await readFile(path, "utf8")));
        return parsed.success ? parsed.data : undefined;
      } catch {
        // Missing, unreadable or malformed: start unpaired rather than trusting it.
        return undefined;
      }
    },
    async save(pairing: Pairing | undefined): Promise<void> {
      if (!pairing) { await rm(path, { force: true }); return; }
      const value = pairingSchema.parse(pairing);
      const temporary = join(directory, `extension-pairing-${randomUUID()}.tmp`);
      try {
        await mkdir(directory, { recursive: true, mode: 0o700 });
        const dir = await lstat(directory);
        if (!dir.isDirectory() || dir.isSymbolicLink() || !privateOnly(dir.mode)) throw new Error("Invalid private directory permissions.");
        const handle = await open(temporary, "wx", 0o600);
        try { await handle.writeFile(JSON.stringify(value), "utf8"); await handle.sync(); } finally { await handle.close(); }
        await rename(temporary, path);
      } finally { await rm(temporary, { force: true }); }
    },
  };
}
