import { randomUUID } from "node:crypto";
import type { HumanTask, LiveEvent } from "../../packages/domain/types.js";
import type { HumanContinuation } from "../../packages/automation/contracts.js";
import { Store } from "./store.js";

export interface StoredHumanTask extends HumanTask {
  runToken: string;
  variantId: string;
  authorizationId: string;
  authorizationSnapshot: string;
  continuation?: HumanContinuation;
}
export class LiveMonitor {
  constructor(readonly store: Store) {
    store.db.exec(`CREATE TABLE IF NOT EXISTS human_tasks(id TEXT PRIMARY KEY,packet_id TEXT NOT NULL,status TEXT NOT NULL,json TEXT NOT NULL);
      CREATE INDEX IF NOT EXISTS human_task_status ON human_tasks(status);
      CREATE TABLE IF NOT EXISTS live_events(id INTEGER PRIMARY KEY AUTOINCREMENT,job_id TEXT,phase TEXT NOT NULL,message TEXT NOT NULL,timestamp TEXT NOT NULL)`);
  }
  event(phase: string, message: string, jobId?: string): void {
    this.store.db.prepare("INSERT INTO live_events(job_id,phase,message,timestamp) VALUES (?,?,?,?)")
      .run(jobId ?? null, phase.slice(0, 80), message.slice(0, 3000), new Date().toISOString());
    this.store.db.prepare("DELETE FROM live_events WHERE id <= (SELECT COALESCE(max(id),0)-1000 FROM live_events)").run();
  }
  events(): LiveEvent[] {
    return this.store.db.prepare("SELECT id,job_id,phase,message,timestamp FROM live_events ORDER BY id DESC LIMIT 60").all().map(row => ({
      id: Number(row.id), ...(row.job_id ? { jobId: String(row.job_id) } : {}), phase: String(row.phase), message: String(row.message), timestamp: String(row.timestamp)
    })).reverse();
  }
  tasks(): HumanTask[] {
    return this.store.db.prepare("SELECT json FROM human_tasks ORDER BY rowid DESC LIMIT 100").all().map(row => {
      const { runToken: _token, variantId: _variant, authorizationId: _auth, authorizationSnapshot: _snapshot, continuation: _continuation, ...task } = JSON.parse(String(row.json)) as StoredHumanTask;
      return task;
    });
  }
  task(id: string): StoredHumanTask {
    const row = this.store.db.prepare("SELECT json FROM human_tasks WHERE id=?").get(id);
    if (!row) throw new Error("Human-review task not found.");
    return JSON.parse(String(row.json)) as StoredHumanTask;
  }
  pending(): StoredHumanTask | undefined {
    const row = this.store.db.prepare("SELECT json FROM human_tasks WHERE status='resuming' ORDER BY rowid LIMIT 1").get();
    return row ? JSON.parse(String(row.json)) as StoredHumanTask : undefined;
  }
  create(input: Omit<StoredHumanTask, "id" | "status" | "createdAt" | "updatedAt">): StoredHumanTask {
    const now = new Date().toISOString();
    const task: StoredHumanTask = { ...input, id: randomUUID(), status: "waiting", createdAt: now, updatedAt: now };
    this.put(task); return task;
  }
  put(task: StoredHumanTask): void {
    task.updatedAt = new Date().toISOString();
    this.store.db.prepare("INSERT INTO human_tasks VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,json=excluded.json")
      .run(task.id, task.packetId, task.status, JSON.stringify(task));
  }
  pendingCount(): number {
    return Number(this.store.db.prepare("SELECT count(*) AS n FROM human_tasks WHERE status IN ('waiting','resuming')").get()?.n ?? 0);
  }
  recover(): void {
    for (const row of this.store.db.prepare("SELECT json FROM human_tasks WHERE status IN ('waiting','resuming')").all()) {
      const task = JSON.parse(String(row.json)) as StoredHumanTask;
      task.status = "session_lost"; task.reason = "The browser/service restarted. The old prefilled session cannot be safely replayed. Reconcile the application manually.";
      delete task.continuation; this.put(task);
    }
  }
}
