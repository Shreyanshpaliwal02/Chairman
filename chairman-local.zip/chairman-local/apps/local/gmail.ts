import { createHash, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import { createServer, type Server } from "node:http";
import { lstat, mkdir, open, readFile, rename, rm } from "node:fs/promises";
import { join } from "node:path";
import type { FastifyInstance } from "fastify";
import { z } from "zod";
import type { GmailStatus, GmailSuggestion } from "../../packages/domain/gmail.js";
import type { PipelineStage } from "../../packages/domain/types.js";
import { Store } from "./store.js";

const SCOPE = "https://www.googleapis.com/auth/gmail.readonly";
const TOKEN_URL = "https://oauth2.googleapis.com/token";
const API = "https://gmail.googleapis.com/gmail/v1/users/me";
const clientSchema = z.object({
  clientId: z.string().regex(/^[a-zA-Z0-9_-]{8,200}\.apps\.googleusercontent\.com$/, "Use a Google Desktop app OAuth client ID."),
  clientSecret: z.string().min(8).max(512).regex(/^[\x21-\x7e]+$/, "Use the client secret from the same Desktop app OAuth client."),
}).strict();
const privateSchema = z.object({
  client: clientSchema.optional(),
  refreshToken: z.string().min(1).max(4096).optional(),
}).strict().refine(value => !value.refreshToken || !!value.client);
type Credentials = z.infer<typeof privateSchema>;
const tokenSchema = z.object({
  access_token: z.string().min(1).max(8192),
  token_type: z.string().refine(value => value.toLowerCase() === "bearer"),
  expires_in: z.number().positive().max(86400),
  refresh_token: z.string().min(1).max(4096).optional(),
  scope: z.string().optional(),
});
const messageId = z.string().regex(/^[a-zA-Z0-9_-]{1,128}$/);
const messageSchema = z.object({
  id: messageId, internalDate: z.string().regex(/^\d{10,16}$/),
  snippet: z.string().max(10000).optional(),
  payload: z.object({ headers: z.array(z.object({ name: z.string().max(200), value: z.string().max(10000) })).max(200) }),
});
const missing = (error: unknown) => error instanceof Error && "code" in error && error.code === "ENOENT";
const clean = (value: string, max = 300) => value.replace(/[\u0000-\u001f\u007f]/g, " ").slice(0, max);
const normalized = (value: string) => ` ${value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim()} `;

class GmailError extends Error {}
const safeError = (error: unknown) => error instanceof GmailError ? error.message : "Gmail operation failed. Check your connection and Google consent, then retry; private provider errors were not logged.";

export function suggestGmailStage(text: string): PipelineStage | undefined {
  if (/\b(?:not (?:been )?selected|not (?:be )?moving forward|unsuccessful|other candidates|regret to inform|position (?:has been )?filled)\b/i.test(text)) return "rejected";
  if (/\b(?:offer letter|pleased to offer|offer of employment)\b/i.test(text)) return "offer";
  if (/\b(?:schedule (?:an? |your )?interview|interview invitation|invite you to (?:an? )?interview|interview availability)\b/i.test(text)) return "interview";
  if (/\b(?:screening call|phone screen|recruiter call|online assessment)\b/i.test(text)) return "screening";
  return undefined;
}

/** Optional, explicit scans only. No email content is sent to any inference provider. */
export class GmailService {
  private credentials: Credentials = {};
  private access?: { value: string; expires: number };
  private flow?: { server: Server; timer: ReturnType<typeof setTimeout>; state: string; verifier: string; redirect: string; epoch: number };
  private epoch = 0;
  private controller = new AbortController();
  private work?: Promise<unknown>;
  private error?: string;
  private modifying = false;
  private readonly directory: string;
  private readonly path: string;
  constructor(private store: Store, dataDir: string, private fetcher: typeof fetch = fetch) {
    this.directory = join(dataDir, "private");
    this.path = join(this.directory, "gmail.json");
  }
  async load(): Promise<void> {
    try {
      await this.checkDirectory();
      const info = await lstat(this.path);
      if (!info.isFile() || info.isSymbolicLink() || info.size > 16384 || (process.platform !== "win32" && (info.mode & 0o077)))
        throw new GmailError("Invalid private Gmail file permissions or size.");
      this.credentials = privateSchema.parse(JSON.parse(await readFile(this.path, "utf8")));
    } catch (error) {
      if (missing(error)) return;
      throw new GmailError("Private Gmail configuration could not be loaded. Repair its format and owner-only permissions.");
    }
  }
  private async checkDirectory(): Promise<void> {
    const info = await lstat(this.directory);
    if (!info.isDirectory() || info.isSymbolicLink() || (process.platform !== "win32" && (info.mode & 0o077)))
      throw new GmailError("The private Gmail directory must have owner-only permissions and must not be a symbolic link.");
  }
  private async save(value: Credentials): Promise<void> {
    await mkdir(this.directory, { recursive: true, mode: 0o700 });
    await this.checkDirectory();
    const temporary = join(this.directory, `gmail-${randomUUID()}.tmp`);
    try {
      const handle = await open(temporary, "wx", 0o600);
      try { await handle.writeFile(JSON.stringify(value)); await handle.sync(); }
      finally { await handle.close(); }
      await rename(temporary, this.path);
      this.credentials = value;
    } finally { await rm(temporary, { force: true }); }
  }
  status(): GmailStatus {
    return {
      configured: !!this.credentials.client, connected: !!this.credentials.refreshToken, authorizing: !!this.flow,
      busy: !!this.work || this.modifying, error: this.error,
      lastScanAt: this.store.value<string | undefined>("gmail:lastScanAt", undefined),
      nextScanAt: this.store.value<string | undefined>("gmail:nextScanAt", undefined),
      suggestions: this.store.value<GmailSuggestion[]>("gmail:suggestions", []),
    };
  }
  private cancelFlow(): void {
    if (!this.flow) return;
    clearTimeout(this.flow.timer);
    this.flow.server.close();
    this.flow = undefined;
  }
  private async exclusive<T>(task: () => Promise<T>): Promise<T> {
    if (this.work || this.modifying) throw new GmailError("Another Gmail operation is in progress.");
    const work = task();
    this.work = work;
    try { return await work; }
    finally { if (this.work === work) this.work = undefined; }
  }
  async configure(input: unknown): Promise<void> {
    const value = clientSchema.safeParse(input);
    if (!value.success) throw new GmailError("Enter the client ID and client secret from your Google Desktop app OAuth client. Unknown fields are not accepted.");
    await this.exclusive(async () => {
      if (this.credentials.refreshToken) throw new GmailError("Disconnect Gmail before replacing the OAuth client.");
      this.cancelFlow(); this.epoch++;
      await this.save({ client: value.data });
      this.error = undefined;
    });
  }
  private async json(url: string, init: RequestInit = {}): Promise<unknown> {
    const response = await this.fetcher(url, {
      ...init, redirect: "error", credentials: "omit", cache: "no-store", referrerPolicy: "no-referrer",
      signal: AbortSignal.any([this.controller.signal, AbortSignal.timeout(20_000)]),
    });
    if (!response.ok) {
      await response.body?.cancel();
      if (response.status === 429) {
        const retry = response.headers.get("retry-after") ?? "";
        const deadline = /^\d+$/.test(retry) ? Date.now() + Number(retry) * 1000 : Date.parse(retry);
        const next = Math.max(Date.now() + 60000, Number.isFinite(deadline) ? deadline : 0);
        this.store.set("gmail:nextScanAt", new Date(Math.min(next, 8640000000000000)).toISOString());
      }
      throw new GmailError(response.status === 401 || response.status === 403
        ? "Google denied Gmail access. Check that Gmail API is enabled and reconnect with read-only consent."
        : `Google request failed (HTTP ${response.status}). No automatic retry was made.`);
    }
    if (!response.body) throw new GmailError("Google returned an empty response.");
    const reader = response.body.getReader(), chunks: Uint8Array[] = [];
    let length = 0;
    try {
      for (;;) {
        const part = await reader.read();
        if (part.done) break;
        length += part.value.byteLength;
        if (length > 256 * 1024) { await reader.cancel(); throw new GmailError("Google response exceeded the read-only scan budget."); }
        chunks.push(part.value);
      }
    } finally { reader.releaseLock(); }
    try { return JSON.parse(Buffer.concat(chunks).toString("utf8")) as unknown; }
    catch { throw new GmailError("Google returned an invalid JSON response."); }
  }
  private async exchange(fields: Record<string, string>): Promise<z.infer<typeof tokenSchema>> {
    const client = this.credentials.client;
    if (!client) throw new GmailError("Configure a Google Desktop app OAuth client first.");
    const body = new URLSearchParams({ client_id: client.clientId, client_secret: client.clientSecret, ...fields });
    const parsed = tokenSchema.safeParse(await this.json(TOKEN_URL, { method: "POST", body, headers: { "Content-Type": "application/x-www-form-urlencoded" } }));
    if (!parsed.success || (parsed.data.scope !== undefined && !parsed.data.scope.split(" ").includes(SCOPE)))
      throw new GmailError("Google did not grant the required read-only Gmail token.");
    return parsed.data;
  }
  async connect(): Promise<{ url: string }> {
    return this.exclusive(async () => {
      if (!this.credentials.client) throw new GmailError("Save a Google Desktop app OAuth client before connecting.");
      if (this.credentials.refreshToken) throw new GmailError("Gmail is already connected. Disconnect before changing accounts.");
      this.cancelFlow(); this.error = undefined;
      const epoch = ++this.epoch, state = randomBytes(32).toString("base64url"), verifier = randomBytes(48).toString("base64url");
      const server = createServer((request, response) => {
        response.setHeader("Cache-Control", "no-store");
        response.setHeader("Content-Type", "text/plain; charset=utf-8");
        response.setHeader("X-Content-Type-Options", "nosniff");
        response.setHeader("Referrer-Policy", "no-referrer");
        const flow = this.flow;
        if (!flow || request.method !== "GET" || request.headers.host !== new URL(flow.redirect).host) {
          response.writeHead(403).end("Invalid authorization callback."); return;
        }
        const url = new URL(request.url ?? "/", flow.redirect);
        const supplied = url.searchParams.get("state") ?? "";
        if (url.pathname !== "/oauth/callback" || supplied.length !== state.length || !timingSafeEqual(Buffer.from(supplied), Buffer.from(state))) {
          response.writeHead(403).end("Invalid authorization state. Return to Chairman."); return;
        }
        this.cancelFlow();
        const code = url.searchParams.get("code");
        if (url.searchParams.has("error") || !code || code.length > 8192) {
          this.error = "Google authorization was declined or incomplete. No Gmail connection was saved.";
          response.writeHead(400).end(this.error); return;
        }
        void this.exclusive(async () => {
          const result = await this.exchange({ grant_type: "authorization_code", code, code_verifier: verifier, redirect_uri: flow.redirect });
          if (epoch !== this.epoch || this.controller.signal.aborted) throw new GmailError("Gmail authorization was cancelled.");
          if (!result.refresh_token || !result.scope?.split(" ").includes(SCOPE))
            throw new GmailError("Google did not return read-only offline consent. Reconnect and review the Google consent screen.");
          await this.save({ client: this.credentials.client, refreshToken: result.refresh_token });
          this.access = { value: result.access_token, expires: Date.now() + result.expires_in * 1000 };
          this.error = undefined;
        }).then(
          () => response.end("Gmail connected to Chairman. You may close this tab and refresh Gmail status in Setup. No email was sent or scanned."),
          (error: unknown) => { this.error = safeError(error); response.writeHead(400).end(this.error); },
        );
      });
      server.requestTimeout = 25000;
      server.headersTimeout = 10000;
      await new Promise<void>((resolve, reject) => {
        server.once("error", reject);
        server.listen(0, "127.0.0.1", () => { server.removeListener("error", reject); resolve(); });
      });
      const address = server.address();
      if (!address || typeof address === "string") { server.close(); throw new GmailError("Could not open the local Google authorization callback."); }
      const redirect = `http://127.0.0.1:${address.port}/oauth/callback`;
      const timer = setTimeout(() => {
        this.cancelFlow(); this.error = "Google sign-in timed out. Choose Connect Gmail to start again.";
      }, 5 * 60_000);
      timer.unref();
      this.flow = { server, timer, state, verifier, redirect, epoch };
      const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
      url.search = new URLSearchParams({
        client_id: this.credentials.client.clientId, redirect_uri: redirect, response_type: "code", scope: SCOPE,
        access_type: "offline", prompt: "consent", state,
        code_challenge: createHash("sha256").update(verifier).digest("base64url"), code_challenge_method: "S256",
      }).toString();
      return { url: url.href };
    });
  }
  private async accessToken(): Promise<string> {
    if (!this.credentials.refreshToken) throw new GmailError("Connect Gmail with read-only consent first.");
    if (this.access && this.access.expires > Date.now() + 60000) return this.access.value;
    const result = await this.exchange({ grant_type: "refresh_token", refresh_token: this.credentials.refreshToken });
    this.access = { value: result.access_token, expires: Date.now() + result.expires_in * 1000 };
    return this.access.value;
  }
  private targets() {
    const packets = this.store.packetsWithStatus("submitted_confirmed").map(packet => ({
      id: packet.id, kind: "packet" as const, jobId: packet.jobId, stage: packet.progress?.stage ?? "applied" as PipelineStage,
      submittedAt: packet.submittedAt ?? packet.createdAt,
    }));
    const external = this.store.externalApplications().map(application => ({
      id: application.id, kind: "external" as const, jobId: application.jobId,
      stage: application.progress.stage, submittedAt: application.submittedDate,
    }));
    return [...packets, ...external].flatMap(target => {
      const job = this.store.job(target.jobId);
      return job ? [{ ...target, company: job.company, title: job.title }] : [];
    });
  }
  async scan(): Promise<void> {
    await this.exclusive(async () => {
      const next = this.store.value("gmail:nextScanAt", "");
      if (Date.parse(next) > Date.now()) throw new GmailError(`Gmail scans are paused until ${next}.`);
      const targets = this.targets();
      if (!targets.length) throw new GmailError("Record an actual application confirmation first. Gmail suggestions match existing confirmed applications only.");
      const epoch = this.epoch, token = await this.accessToken();
      this.store.set("gmail:nextScanAt", new Date(Date.now() + 60000).toISOString());
      const headers = { Authorization: `Bearer ${token}` };
      const query = new URLSearchParams({
        q: 'newer_than:90d -in:spam -in:trash {application interview "offer letter" "screening call" "phone screen" assessment}',
        maxResults: "25", fields: "messages(id),nextPageToken",
      });
      const list = z.object({ messages: z.array(z.object({ id: messageId })).max(25).optional() }).safeParse(await this.json(`${API}/messages?${query}`, { headers }));
      if (!list.success) throw new GmailError("Google returned an invalid message list.");
      const ignored = new Set(this.store.value<string[]>("gmail:reviewed", []));
      const suggestions = new Map(this.status().suggestions.map(item => [item.id, item]));
      for (const message of list.data.messages ?? []) {
        if (epoch !== this.epoch) throw new GmailError("Gmail scan was cancelled.");
        const parameters = new URLSearchParams({ format: "metadata", fields: "id,internalDate,snippet,payload(headers)" });
        for (const name of ["Subject", "From"]) parameters.append("metadataHeaders", name);
        const parsed = messageSchema.safeParse(await this.json(`${API}/messages/${message.id}?${parameters}`, { headers }));
        if (!parsed.success || parsed.data.id !== message.id) throw new GmailError("Google returned invalid message metadata.");
        const item = parsed.data;
        const subject = clean(item.payload.headers.find(header => header.name.toLowerCase() === "subject")?.value ?? "");
        const sender = clean(item.payload.headers.find(header => header.name.toLowerCase() === "from")?.value ?? "");
        const text = `${subject} ${item.snippet ?? ""}`, stage = suggestGmailStage(text), normalizedText = normalized(`${text} ${sender}`);
        if (!stage) continue;
        const timestamp = Number(item.internalDate);
        if (!Number.isFinite(timestamp) || timestamp > Date.now() + 86400000 || timestamp < Date.now() - 91 * 86400000) continue;
        const matches = targets.filter(target =>
          target.company.trim().length >= 3 && normalizedText.includes(normalized(target.company)) &&
          normalizedText.includes(normalized(target.title)) && timestamp >= Date.parse(target.submittedAt) - 86400000,
        );
        // Ambiguous employer/role matches remain manual instead of updating the wrong application.
        if (matches.length !== 1) continue;
        const target = matches[0]!, id = createHash("sha256").update(`${message.id}:${target.kind}:${target.id}`).digest("hex");
        if (ignored.has(id) || stage === target.stage) continue;
        suggestions.set(id, {
          id, messageId: message.id, applicationId: target.id, applicationKind: target.kind, jobId: target.jobId,
          company: target.company, title: target.title, subject, sender, receivedAt: new Date(timestamp).toISOString(),
          stage, previousStage: target.stage,
        });
      }
      if (epoch !== this.epoch || this.controller.signal.aborted) throw new GmailError("Gmail scan was cancelled.");
      this.store.set("gmail:suggestions", [...suggestions.values()].sort((a, b) => b.receivedAt.localeCompare(a.receivedAt)).slice(0, 100));
      this.store.set("gmail:lastScanAt", new Date().toISOString());
      this.error = undefined;
    }).catch((error: unknown) => { this.error = safeError(error); throw new GmailError(this.error); });
  }
  review(input: unknown): void {
    if (this.work || this.modifying) throw new GmailError("Wait for the current Gmail operation to finish before reviewing suggestions.");
    const { id, action } = z.object({ id: z.string().regex(/^[a-f0-9]{64}$/), action: z.enum(["accept", "dismiss"]) }).strict().parse(input);
    const suggestions = this.status().suggestions, suggestion = suggestions.find(value => value.id === id);
    if (!suggestion) throw new GmailError("This suggestion is no longer available. Refresh Gmail status.");
    this.store.transaction(() => {
      if (action === "accept") {
        const application = suggestion.applicationKind === "packet" ? this.store.packet(suggestion.applicationId) : this.store.externalApplication(suggestion.applicationId);
        if (!application || application.jobId !== suggestion.jobId || ("status" in application && application.status !== "submitted_confirmed"))
          throw new GmailError("The application has changed. Review it manually; no status was updated.");
        if ((application.progress?.stage ?? "applied") !== suggestion.previousStage)
          throw new GmailError("A newer application status is already saved. Dismiss this suggestion or update the tracker manually.");
        application.progress = { ...application.progress, note: application.progress?.note ?? "", stage: suggestion.stage, updatedAt: new Date().toISOString() };
        if ("status" in application) this.store.putPacket(application);
        else this.store.putExternal(application);
        this.store.event(suggestion.applicationKind === "packet" ? application.id : null, "gmail_status_reviewed", "User accepted a local Gmail status suggestion. No new application, confirmation or email was sent.");
      }
      this.store.set("gmail:reviewed", [...this.store.value<string[]>("gmail:reviewed", []), id].slice(-500));
      this.store.set("gmail:suggestions", suggestions.filter(value => value.id !== id));
    });
  }
  async disconnect(forgetClient = false): Promise<void> {
    if (this.modifying) throw new GmailError("Gmail disconnect is already in progress.");
    this.modifying = true;
    this.epoch++; this.cancelFlow(); this.controller.abort();
    try {
      if (this.work) await this.work.catch((error: unknown) => { this.error = safeError(error); });
      this.controller = new AbortController();
      const token = this.credentials.refreshToken;
      await this.save(forgetClient ? {} : { client: this.credentials.client });
      this.access = undefined;
      this.store.db.prepare("DELETE FROM settings WHERE key LIKE 'gmail:%'").run();
      this.error = undefined;
      if (token) {
        try {
          const result = await this.fetcher("https://oauth2.googleapis.com/revoke", {
            method: "POST", body: new URLSearchParams({ token }), redirect: "error", credentials: "omit",
            signal: AbortSignal.timeout(10000), headers: { "Content-Type": "application/x-www-form-urlencoded" },
          });
          await result.body?.cancel();
          if (!result.ok) throw new GmailError("Google revocation failed.");
        } catch {
          this.error = "Gmail disconnected locally, but Google revocation was not confirmed. Remove Chairman access at myaccount.google.com/connections.";
        }
      }
    } finally { this.modifying = false; }
  }
  async close(): Promise<void> {
    this.epoch++; this.cancelFlow(); this.controller.abort();
    if (this.work) await this.work.catch((error: unknown) => { this.error = safeError(error); });
    this.access = undefined;
  }
}

export function registerGmail(app: FastifyInstance, gmail: GmailService): void {
  app.get("/api/gmail/status", async () => gmail.status());
  app.post("/api/gmail/config", async request => { await gmail.configure(request.body); return gmail.status(); });
  app.post("/api/gmail/connect", async request => {
    z.object({ consent: z.literal(true) }).strict().parse(request.body);
    return gmail.connect();
  });
  app.post("/api/gmail/scan", async request => {
    z.object({ consent: z.literal(true) }).strict().parse(request.body);
    await gmail.scan(); return gmail.status();
  });
  app.post("/api/gmail/review", async request => { gmail.review(request.body); return gmail.status(); });
  app.post("/api/gmail/disconnect", async request => {
    z.object({ confirm: z.literal(true) }).strict().parse(request.body);
    await gmail.disconnect(true); return gmail.status();
  });
}
