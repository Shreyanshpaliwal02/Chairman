import { z } from "zod";
import { Store } from "./store.js";
import type { TrackingPage, TrackingRow } from "../../packages/domain/application-tracker.js";

const querySchema = z.object({
  offset: z.coerce.number().int().min(0).max(1_000_000).default(0),
  limit: z.coerce.number().int().min(1).max(100).default(25),
  q: z.string().trim().max(100).default(""),
  status: z.string().max(40).default(""),
  stage: z.enum(["", "applied", "screening", "interview", "offer", "rejected", "withdrawn"]).default(""),
  kind: z.enum(["", "packet", "external", "assistance"]).default(""),
}).strict();

export class ApplicationTracker {
  constructor(private store: Store) {}
  list(query: unknown = {}): TrackingPage {
    const input = querySchema.parse(query);
    const assistanceExists = !!this.store.db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='assistance_records'").get();
    const runnerExists = !!this.store.db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='autopilot_jobs'").get();
    const cte = `WITH assists AS (${assistanceExists ? "SELECT id,json FROM assistance_records" : "SELECT NULL AS id,NULL AS json WHERE 0"}),
      runners AS (${runnerExists ? "SELECT job_id,json FROM autopilot_jobs" : "SELECT NULL AS job_id,NULL AS json WHERE 0"}),
      records AS (
        SELECT p.id,'packet' AS kind,p.job_id AS jobId,p.id AS packetId,
          COALESCE(json_extract(j.json,'$.company'),'Listing unavailable') AS company,
          COALESCE(json_extract(j.json,'$.title'),p.job_id) AS title,
          COALESCE(json_extract(j.json,'$.sourceId'),'unknown') AS portal,
          COALESCE(json_extract(j.json,'$.applyUrl'),'') AS applyUrl,
          COALESCE(json_extract(p.json,'$.submittedAt'),json_extract(p.json,'$.createdAt')) AS date,
          COALESCE(json_extract(p.json,'$.progress.updatedAt'),json_extract(p.json,'$.submittedAt'),json_extract(p.json,'$.createdAt')) AS updatedAt,
          json_extract(p.json,'$.status') AS status,
          CASE WHEN json_extract(p.json,'$.status')='submitted_confirmed' THEN COALESCE(json_extract(p.json,'$.progress.stage'),'applied') END AS stage,
          COALESCE(json_extract(n.value,'$.notes'),json_extract(p.json,'$.progress.note'),'') AS notes,
          CASE WHEN json_extract(p.json,'$.status')='submitted_confirmed' THEN 'packet' END AS progressKind,
          p.id AS progressId,json_extract(p.json,'$.progress.note') AS progressNote,json_extract(p.json,'$.progress.nextActionDate') AS nextActionDate,0 AS runnerOwned
        FROM packets p LEFT JOIN jobs j ON j.id=p.job_id LEFT JOIN settings n ON n.key='trackingNote:packet:'||p.id
        WHERE NOT EXISTS(SELECT 1 FROM assists a LEFT JOIN runners r ON r.job_id=json_extract(a.json,'$.jobId')
          WHERE json_extract(a.json,'$.packetId')=p.id OR (json_extract(a.json,'$.status')='queued' AND json_extract(r.json,'$.packetId')=p.id))
        UNION ALL
        SELECT e.id,'external',e.job_id,NULL,COALESCE(json_extract(j.json,'$.company'),'Listing unavailable'),
          COALESCE(json_extract(j.json,'$.title'),e.job_id),COALESCE(json_extract(e.json,'$.sourceId'),'manual'),
          COALESCE(json_extract(j.json,'$.applyUrl'),''),json_extract(e.json,'$.submittedDate'),
          COALESCE(json_extract(e.json,'$.progress.updatedAt'),json_extract(e.json,'$.createdAt')),'submitted_confirmed',
          COALESCE(json_extract(e.json,'$.progress.stage'),'applied'),COALESCE(json_extract(n.value,'$.notes'),json_extract(e.json,'$.progress.note'),''),
          'external',e.id,json_extract(e.json,'$.progress.note'),json_extract(e.json,'$.progress.nextActionDate'),0
        FROM external_applications e LEFT JOIN jobs j ON j.id=e.job_id LEFT JOIN settings n ON n.key='trackingNote:external:'||e.id
        WHERE NOT EXISTS(SELECT 1 FROM assists a WHERE json_extract(a.json,'$.jobId')=e.job_id)
        UNION ALL
        SELECT a.id,'assistance',json_extract(a.json,'$.jobId'),COALESCE(json_extract(r.json,'$.packetId'),json_extract(a.json,'$.packetId')),
          json_extract(a.json,'$.company'),json_extract(a.json,'$.title'),json_extract(a.json,'$.portal'),
          COALESCE(json_extract(j.json,'$.applyUrl'),json_extract(a.json,'$.sourceUrl')),
          COALESCE(json_extract(a.json,'$.submittedAt'),json_extract(e.json,'$.submittedDate'),json_extract(p.json,'$.submittedAt'),json_extract(a.json,'$.createdAt')),
          COALESCE(json_extract(r.json,'$.updatedAt'),json_extract(a.json,'$.updatedAt'),json_extract(a.json,'$.createdAt')),
          CASE WHEN e.id IS NOT NULL OR json_extract(p.json,'$.status')='submitted_confirmed' THEN 'submitted_confirmed'
            WHEN json_extract(p.json,'$.status')='submission_unknown' THEN 'submission_unknown'
            WHEN json_extract(r.json,'$.status')='submitted_confirmed' THEN 'submission_unknown'
            ELSE COALESCE(json_extract(r.json,'$.status'),json_extract(a.json,'$.status')) END,
          CASE WHEN e.id IS NOT NULL THEN COALESCE(json_extract(e.json,'$.progress.stage'),'applied')
            WHEN json_extract(p.json,'$.status')='submitted_confirmed' THEN COALESCE(json_extract(p.json,'$.progress.stage'),'applied') END,
          COALESCE(json_extract(a.json,'$.notes'),''),
          CASE WHEN e.id IS NOT NULL THEN 'external' WHEN json_extract(p.json,'$.status')='submitted_confirmed' THEN 'packet' END,
          COALESCE(e.id,p.id),COALESCE(json_extract(e.json,'$.progress.note'),json_extract(p.json,'$.progress.note')),
          COALESCE(json_extract(e.json,'$.progress.nextActionDate'),json_extract(p.json,'$.progress.nextActionDate')),
          json_extract(a.json,'$.status')='queued'
        FROM assists a LEFT JOIN jobs j ON j.id=json_extract(a.json,'$.jobId')
          LEFT JOIN runners r ON r.job_id=json_extract(a.json,'$.jobId') AND json_extract(a.json,'$.status')='queued'
          LEFT JOIN packets p ON p.id=COALESCE(json_extract(r.json,'$.packetId'),json_extract(a.json,'$.packetId'))
          LEFT JOIN external_applications e ON e.job_id=json_extract(a.json,'$.jobId')
      )`;
    const where = "WHERE (?='' OR instr(lower(company||' '||title||' '||portal||' '||notes),lower(?))>0) AND (?='' OR status=?) AND (?='' OR stage=?) AND (?='' OR kind=?)";
    const params = [input.q, input.q, input.status, input.status, input.stage, input.stage, input.kind, input.kind];
    const total = Number(this.store.db.prepare(`${cte} SELECT count(*) AS n FROM records ${where}`).get(...params)?.n ?? 0);
    const rows = this.store.db.prepare(`${cte} SELECT * FROM records ${where} ORDER BY date DESC,kind,id LIMIT ? OFFSET ?`).all(...params, input.limit, input.offset);
    const items: TrackingRow[] = rows.map(row => ({
      id: String(row.id), kind: row.kind as TrackingRow["kind"], jobId: String(row.jobId),
      ...(typeof row.packetId === "string" ? { packetId: row.packetId } : {}),
      company: String(row.company), title: String(row.title), portal: String(row.portal), applyUrl: String(row.applyUrl),
      date: String(row.date), updatedAt: String(row.updatedAt), status: row.status as TrackingRow["status"], notes: String(row.notes),
      ...(row.runnerOwned ? { runnerOwned: true } : {}),
      ...(typeof row.stage === "string" ? { stage: row.stage as TrackingRow["stage"] } : {}),
      ...(row.progressKind === "packet" || row.progressKind === "external" ? { progress: {
        kind: row.progressKind, id: String(row.progressId), note: typeof row.progressNote === "string" ? row.progressNote : "",
        ...(typeof row.nextActionDate === "string" ? { nextActionDate: row.nextActionDate } : {}),
      } } : {}),
    }));
    return { items, total, offset: input.offset, limit: input.limit };
  }
  setNote(kind: unknown, id: unknown, body: unknown) {
    const recordKind = z.enum(["packet", "external"]).parse(kind);
    const recordId = z.string().min(1).max(200).parse(id);
    const { notes } = z.object({ notes: z.string().max(4000) }).strict().parse(body);
    if (!(recordKind === "packet" ? this.store.packet(recordId) : this.store.externalApplication(recordId))) throw new Error("Tracking record not found.");
    this.store.set(`trackingNote:${recordKind}:${recordId}`, { notes, updatedAt: new Date().toISOString() });
    return { saved: true };
  }
}
