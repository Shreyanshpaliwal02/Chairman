import { createHash } from "node:crypto";
import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { normalizeQuestion, questionKey } from "../../packages/automation/answers.js";
import { QUESTION_BANK, QUESTION_CATEGORIES } from "../../packages/domain/question-bank.js";
import { COMPANY_CATALOG } from "../../packages/domain/company-catalog.js";
import { candidateYears, requiredYears } from "../../packages/domain/job-fit.js";
import { parseCareerTarget } from "../../packages/adapters/career-links.js";
import type { AnswerBankExport, ApplicationEvidence, InboxQuestion, ProgressCompany, ProgressJob, ProgressStatus, ProgressView } from "../../packages/domain/progress.js";
import type { AutopilotJob, FormField, Job, Packet, Profile } from "../../packages/domain/types.js";
import type { AutopilotService } from "./autopilot.js";
import type { CareerSourceService } from "./career-sources.js";
import { RoleFamilyService } from "./role-families.js";
import { Store } from "./store.js";

const MAX_INBOX = 500;
const unsafeKey = /password|secret|otp|verification.?code|passcode|token/i;
const inboxId = (label: string) => createHash("sha256").update(normalizeQuestion(label)).digest("hex").slice(0, 24);
const emptyCounts = (): Record<ProgressStatus, number> & { total: number } =>
  ({ applied: 0, marked: 0, in_progress: 0, needs_you: 0, not_applied: 0, not_relevant: 0, failed: 0, total: 0 });

/** Questions seen on real forms that none of your saved answers covers. */
export class QuestionInbox {
  constructor(readonly store: Store) {
    store.db.exec("CREATE TABLE IF NOT EXISTS question_inbox(id TEXT PRIMARY KEY,json TEXT NOT NULL)");
  }
  list(): InboxQuestion[] {
    return this.store.db.prepare("SELECT json FROM question_inbox").all().map(row => JSON.parse(String(row.json)) as InboxQuestion)
      .sort((a, b) => Number(b.required) - Number(a.required) || b.seen - a.seen || b.lastSeenAt.localeCompare(a.lastSeenAt));
  }
  /** Records unanswered questions (labels and option labels only; never values). */
  harvest(fields: Pick<FormField, "label" | "type" | "options" | "optionLabels" | "required">[], company: string): number {
    let added = 0;
    const now = new Date().toISOString();
    this.store.transaction(() => {
      for (const field of fields) {
        const label = field.label.replace(/\s+/g, " ").trim().slice(0, 500);
        if (!label || label.length < 3 || unsafeKey.test(label) || field.type === "file") continue;
        const id = inboxId(label);
        const row = this.store.db.prepare("SELECT json FROM question_inbox WHERE id=?").get(id);
        const existing = row ? JSON.parse(String(row.json)) as InboxQuestion : undefined;
        if (!existing && Number(this.store.db.prepare("SELECT count(*) AS n FROM question_inbox").get()!.n) >= MAX_INBOX) continue;
        const options = field.options.map(value => field.optionLabels?.[value] ?? value).filter(value => value && value !== "true" && value !== "false").slice(0, 50);
        const question: InboxQuestion = existing
          ? { ...existing, seen: existing.seen + 1, lastSeenAt: now, required: existing.required || field.required,
            companies: [...new Set([...existing.companies, company].filter(Boolean))].slice(-10), options: existing.options.length ? existing.options : options }
          : { id, label, type: field.type, options, required: field.required, seen: 1, companies: company ? [company] : [], firstSeenAt: now, lastSeenAt: now,
            ...(questionKey(label) ? { bankKey: questionKey(label) } : {}) };
        this.store.db.prepare("INSERT INTO question_inbox VALUES (?,?) ON CONFLICT(id) DO UPDATE SET json=excluded.json").run(id, JSON.stringify(question));
        if (!existing) added++;
      }
    });
    return added;
  }
  get(id: string): InboxQuestion {
    const row = this.store.db.prepare("SELECT json FROM question_inbox WHERE id=?").get(id);
    if (!row) throw new Error("That question is no longer in the inbox.");
    return JSON.parse(String(row.json)) as InboxQuestion;
  }
  remove(id: string): void { this.store.db.prepare("DELETE FROM question_inbox WHERE id=?").run(id); }
  /** Drops questions your saved answers now cover. */
  prune(covered: (question: InboxQuestion) => boolean): void {
    for (const question of this.list()) if (covered(question)) this.remove(question.id);
  }
}

export class ProgressService {
  constructor(readonly store: Store, readonly careerSources: CareerSourceService, readonly families: RoleFamilyService) {
    store.db.exec("CREATE TABLE IF NOT EXISTS application_evidence(job_id TEXT PRIMARY KEY, json TEXT NOT NULL)");
  }
  /** Proof that this job's application was submitted, if any was seen. */
  evidence(jobId: string): ApplicationEvidence | undefined {
    const row = this.store.db.prepare("SELECT json FROM application_evidence WHERE job_id=?").get(jobId);
    return row ? JSON.parse(String(row.json)) as ApplicationEvidence : undefined;
  }
  /** Keeps the first proof seen: a later page view of the same confirmation does not move the submitted time. */
  recordEvidence(jobId: string, evidence: ApplicationEvidence): ApplicationEvidence {
    const existing = this.evidence(jobId);
    if (existing) return existing;
    this.store.db.prepare("INSERT INTO application_evidence VALUES (?,?)").run(jobId, JSON.stringify(evidence));
    this.store.event(null, "application_evidence", `${evidence.kind}: ${evidence.detail}`.slice(0, 500));
    return evidence;
  }
  /**
   * Where this job's application stands, from every channel (manual record, packet, Auto Apply, extension, your mark in Today).
   * "applied" is returned only with proof; your own "I submitted it" click is "marked" until a confirmation is seen.
   */
  statusFor(job: Job, classification: ProgressJob["classification"]): Pick<ProgressJob, "status" | "detail" | "updatedAt" | "channel" | "resume" | "evidence" | "step"> {
    const db = this.store.db;
    const seen = this.evidence(job.id);
    if (seen) return { status: "applied", detail: seen.detail, updatedAt: seen.at, channel: seen.kind === "runner_receipt" ? "auto_apply" : "extension", evidence: seen };
    const external = db.prepare("SELECT json FROM external_applications WHERE job_id=?").get(job.id);
    if (external) {
      const record = JSON.parse(String(external.json)) as { submittedDate: string; createdAt: string; confirmation?: string };
      const detail = `You recorded it as submitted on ${record.submittedDate}${record.confirmation?.trim() ? ` (confirmation: ${record.confirmation.trim().slice(0, 120)})` : ""}.`;
      return { status: "applied", detail, updatedAt: record.createdAt, channel: "manual", evidence: { kind: "recorded_receipt", at: record.createdAt, detail } };
    }
    const packets = db.prepare("SELECT json FROM packets WHERE job_id=? ORDER BY rowid DESC").all(job.id).map(row => JSON.parse(String(row.json)) as Packet);
    const auto = db.prepare("SELECT json FROM autopilot_jobs WHERE job_id=?").get(job.id);
    const run = auto ? JSON.parse(String(auto.json)) as AutopilotJob : undefined;
    const used = (run?.packetId ? packets.find(packet => packet.id === run.packetId) : undefined) ?? packets[0];
    const resume = used ? used.tailoring?.baseVariantLabel ? `${used.tailoring.baseVariantLabel} (tailored)` : used.artifacts[0]?.filename : undefined;
    const via = resume ? { resume } : {};
    const confirmed = packets.find(packet => packet.status === "submitted_confirmed");
    if (confirmed || run?.status === "submitted_confirmed") {
      const detail = run?.status === "submitted_confirmed" ? `Submitted by Auto Apply. ${run.reason}` : `Submitted; confirmation recorded${confirmed?.confirmation ? `: ${String(confirmed.confirmation).slice(0, 120)}` : ""}.`;
      const at = run?.updatedAt ?? confirmed?.submittedAt ?? new Date(0).toISOString();
      return { status: "applied", detail, updatedAt: at, channel: run ? "auto_apply" : "packet", ...via,
        evidence: { kind: run?.status === "submitted_confirmed" ? "runner_receipt" : "recorded_receipt", at, detail } };
    }
    const assisted = db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='assistance_records'").get()
      ? db.prepare("SELECT json FROM assistance_records WHERE json_extract(json,'$.jobId')=? ORDER BY rowid DESC LIMIT 1").get(job.id) : undefined;
    const record = assisted ? JSON.parse(String(assisted.json)) as { status: string; updatedAt: string; confirmation?: string; stage?: { name: string; detail: string; at: string } } : undefined;
    if (record?.status === "submitted_confirmed") {
      const detail = `Filled with the browser extension; you recorded the confirmation${record.confirmation ? `: ${record.confirmation.slice(0, 120)}` : ""}.`;
      return { status: "applied", detail, updatedAt: record.updatedAt, channel: "extension", evidence: { kind: "recorded_receipt", at: record.updatedAt, detail } };
    }
    if (run) {
      if (["queued", "inspecting", "prefilling", "submitting"].includes(run.status)) return { status: "in_progress", detail: run.reason, updatedAt: run.updatedAt, channel: "auto_apply", ...via };
      if (["awaiting_human", "needs_input", "auth_required", "captcha_required", "submission_unknown"].includes(run.status))
        return { status: "needs_you", detail: run.status === "submission_unknown" ? `Check whether it was submitted: ${run.reason}` : run.reason, updatedAt: run.updatedAt, channel: "auto_apply", ...via };
      if (run.status === "failed") return { status: "failed", detail: run.reason, updatedAt: run.updatedAt, channel: "auto_apply", ...via };
      if (run.status === "skipped" || run.status === "unsupported")
        return { status: classification.relevant && classification.interested ? "not_applied" : "not_relevant", detail: run.reason, updatedAt: run.updatedAt, channel: "auto_apply" };
    }
    const marked = db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='shortlist_state'").get()
      ? db.prepare("SELECT status,updated_at FROM shortlist_state WHERE job_id=?").get(job.id) : undefined;
    if (marked?.status === "applied") return { status: "marked", updatedAt: String(marked.updated_at), channel: record ? "extension" : "manual",
      detail: `You marked this as submitted on ${new Date(String(marked.updated_at)).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", dateStyle: "medium", timeStyle: "short" })}. No confirmation page or email has been seen, so it is not counted as applied.` };
    if (record?.stage?.name === "review")
      return { status: "in_progress", step: "review", detail: record.stage.detail || "Ready for your review: check the answers and click Submit yourself.", updatedAt: record.stage.at, channel: "extension" };
    if (record?.stage?.name === "working")
      return { status: "in_progress", detail: record.stage.detail || "Chairman is filling it in your Chrome.", updatedAt: record.stage.at, channel: "extension" };
    if (record?.stage?.name === "needs_you")
      return { status: "needs_you", detail: record.stage.detail || "Waiting for you in its Chrome tab.", updatedAt: record.stage.at, channel: "extension" };
    if (record && ["filled", "fill_intent", "prepared", "detected", "manual_required", "submission_unknown"].includes(record.status))
      return { status: record.status === "submission_unknown" ? "needs_you" : "in_progress", ...(record.status === "filled" ? { step: "filled" as const } : {}),
        detail: record.status === "filled" ? "Filled with the extension, not submitted yet. Submit it in its tab; the confirmation page is recorded automatically." : "Started with the browser extension; not submitted.", updatedAt: record.updatedAt, channel: "extension" };
    if (packets.some(packet => ["executing", "awaiting_human", "submission_unknown", "approved", "prepared"].includes(packet.status)))
      return { status: "in_progress", detail: "An application packet is prepared or running.", channel: "packet" };
    if (!classification.relevant || !classification.interested) return { status: "not_relevant", detail: classification.reason };
    return { status: "not_applied", detail: `Not applied yet. ${classification.reason}` };
  }
  view(): ProgressView {
    const families = this.families.list(), totals = emptyCounts();
    const settingsYears = this.store.value<{ experienceYears?: number | null }>("shortlist-settings", {}).experienceYears;
    const years = settingsYears ?? candidateYears(this.store.profile());
    const companies: ProgressCompany[] = this.careerSources.list().map(source => {
      const jobs = this.store.db.prepare("SELECT j.json FROM jobs j JOIN career_source_jobs c ON c.job_id=j.id WHERE c.source_id=? ORDER BY j.rowid DESC LIMIT 1000")
        .all(source.id).map(row => JSON.parse(String(row.json)) as Job).map(job => {
          const classification = this.families.classify(job);
          const required = requiredYears(job.description);
          return { jobId: job.id, title: job.title, location: job.location, countries: job.countries, remote: job.remote, ...(job.department ? { department: job.department } : {}),
            ...(required.min !== undefined ? { yearsRequired: { min: required.min, ...(required.max !== undefined ? { max: required.max } : {}) } } : {}),
            applyUrl: job.applyUrl, fetchedAt: job.fetchedAt, classification, ...this.statusFor(job, classification) };
        });
      const order: ProgressStatus[] = ["needs_you", "in_progress", "not_applied", "marked", "applied", "failed", "not_relevant"];
      jobs.sort((a, b) => order.indexOf(a.status) - order.indexOf(b.status) || (b.updatedAt ?? b.fetchedAt).localeCompare(a.updatedAt ?? a.fetchedAt));
      const counts = emptyCounts();
      for (const job of jobs) { counts[job.status]++; counts.total++; totals[job.status]++; totals.total++; }
      return { source, company: source.company ?? source.label, roleFamilies: source.roleFamilies ?? [], counts, jobs };
    });
    const manual = this.store.value<string[]>("manual-companies", []).map(name => COMPANY_CATALOG.find(entry => entry.name === name))
      .filter((entry): entry is (typeof COMPANY_CATALOG)[number] => !!entry).map(entry => ({ name: entry.name, careersUrl: entry.careersUrl, ...(entry.notes ? { notes: entry.notes } : {}) }));
    return { companies, manual, families, ...(years !== undefined ? { candidateYears: years } : {}), totals, generatedAt: new Date().toISOString() };
  }
}

interface Phase2Options { store: Store; careerSources: CareerSourceService; autopilot: AutopilotService; families: RoleFamilyService; inbox: QuestionInbox }
const answerValue = z.string().max(20_000);
const answerKey = z.string().trim().min(1).max(300).refine(key => !unsafeKey.test(key), "Do not store passwords or verification codes in the answer bank.");
const bankPreferences = z.object({ fillVoluntaryDisclosures: z.boolean().optional(), acceptRequiredAcknowledgements: z.boolean().optional(),
  authorizedCountries: z.array(z.string().trim().min(1).max(100)).max(50).optional(), needsSponsorshipAbroad: z.boolean().optional() }).strict();

/** Saves answers into your profile (empty values remove the answer) and bumps the profile version. */
export function saveAnswers(store: Store, answers: Record<string, string>, preferences: z.infer<typeof bankPreferences> = {}): Profile {
  const profile = store.profile();
  const next: Profile = { ...profile, answers: { ...profile.answers }, preferences: { ...profile.preferences, ...preferences }, version: profile.version + 1 };
  for (const [key, value] of Object.entries(answers)) {
    if (value.trim()) next.answers[key] = value.trim(); else delete next.answers[key];
  }
  if (Object.keys(next.answers).length > 2000) throw new Error("The answer bank supports up to 2000 answers.");
  store.set("profile", next);
  store.event(null, "answer_bank_updated", `${Object.keys(answers).length} saved answers changed; existing packet approvals require regeneration.`);
  return next;
}

export function registerPhase2(app: FastifyInstance, options: Phase2Options): ProgressService {
  const { store, careerSources, autopilot, families, inbox } = options;
  const progress = new ProgressService(store, careerSources, families);
  const covered = (profile: Profile) => (question: InboxQuestion) => {
    const normalized = normalizeQuestion(question.label);
    return Object.keys(profile.answers).some(key => normalizeQuestion(key) === normalized) || !!question.bankKey && Object.hasOwn(profile.answers, question.bankKey);
  };
  const bankView = () => {
    const profile = store.profile();
    inbox.prune(covered(profile));
    return { questions: QUESTION_BANK, categories: QUESTION_CATEGORIES, answers: profile.answers, inbox: inbox.list(),
      preferences: { fillVoluntaryDisclosures: profile.preferences.fillVoluntaryDisclosures === true, acceptRequiredAcknowledgements: profile.preferences.acceptRequiredAcknowledgements === true,
        authorizedCountries: profile.preferences.authorizedCountries, needsSponsorshipAbroad: profile.preferences.needsSponsorshipAbroad } };
  };
  app.get("/api/question-bank", async () => bankView());
  app.post("/api/question-bank", async request => {
    const value = z.object({ answers: z.record(answerKey, answerValue).default({}), preferences: bankPreferences.optional() }).strict().parse(request.body);
    autopilot.invalidate("Saved answers changed. Review and activate Auto Apply again.");
    saveAnswers(store, value.answers, value.preferences);
    return bankView();
  });
  app.post("/api/question-bank/inbox/:id/answer", async request => {
    const { id } = z.object({ id: z.string().regex(/^[a-f0-9]{24}$/) }).parse(request.params);
    const value = z.object({ value: z.string().trim().min(1).max(20_000), key: answerKey.optional() }).strict().parse(request.body);
    const question = inbox.get(id);
    autopilot.invalidate("Saved answers changed. Review and activate Auto Apply again.");
    // Saved under the bank key when the wording maps to one (reused for every wording); otherwise under the exact question.
    saveAnswers(store, { [value.key ?? question.bankKey ?? question.label]: value.value });
    inbox.remove(id);
    return bankView();
  });
  app.post("/api/question-bank/inbox/:id/dismiss", async request => {
    const { id } = z.object({ id: z.string().regex(/^[a-f0-9]{24}$/) }).parse(request.params);
    inbox.remove(id); return bankView();
  });
  app.get("/api/question-bank/export", async (_request, reply) => {
    const profile = store.profile();
    const body: AnswerBankExport = { format: "chairman-answers", version: 1, exportedAt: new Date().toISOString(), answers: profile.answers,
      preferences: { authorizedCountries: profile.preferences.authorizedCountries, needsSponsorshipAbroad: profile.preferences.needsSponsorshipAbroad,
        fillVoluntaryDisclosures: profile.preferences.fillVoluntaryDisclosures === true, acceptRequiredAcknowledgements: profile.preferences.acceptRequiredAcknowledgements === true } };
    return reply.header("Content-Disposition", 'attachment; filename="chairman-answers.json"').type("application/json").send(JSON.stringify(body, null, 2));
  });
  app.post("/api/question-bank/import", async request => {
    const value = z.object({ format: z.literal("chairman-answers").optional(), version: z.literal(1).optional(), exportedAt: z.string().optional(),
      answers: z.record(answerKey, z.union([answerValue, z.number(), z.boolean()]).transform(item => String(item))),
      preferences: bankPreferences.optional() }).strict().parse(request.body);
    autopilot.invalidate("Imported answers. Review them and activate Auto Apply again.");
    const answers = Object.fromEntries(Object.entries(value.answers).filter(([, item]) => item.trim()));
    saveAnswers(store, answers, value.preferences);
    return { imported: Object.keys(answers).length, ...bankView() };
  });

  app.get("/api/role-families", async () => ({ families: families.list() }));
  app.post("/api/role-families", async request => {
    const value = z.object({ families: z.unknown() }).strict().parse(request.body);
    autopilot.invalidate("Role families changed. Review the new scope and activate Auto Apply again.");
    return { families: families.save(value.families) };
  });
  app.post("/api/role-families/reset", async () => {
    autopilot.invalidate("Role families were reset. Review the scope and activate Auto Apply again.");
    return { families: families.reset() };
  });

  const familyIds = z.array(z.string().regex(/^[a-z0-9][a-z0-9-]{0,47}$/)).max(20).refine(ids => ids.every(id => families.list().some(family => family.id === id)), "Choose role families from your list.");
  app.post("/api/companies", async request => {
    const value = z.object({ url: z.url().max(2048), company: z.string().trim().min(1).max(120), roleFamilies: familyIds.default([]) }).strict().parse(request.body);
    autopilot.invalidate("A company was added. Review your companies and activate Auto Apply again.");
    return careerSources.add(value.url, value.company, { company: value.company, roleFamilies: value.roleFamilies });
  });
  const catalogView = () => {
    const sources = careerSources.list(), manual = new Set(store.value<string[]>("manual-companies", []));
    return { companies: COMPANY_CATALOG.map(entry => {
      const target = entry.board ? parseCareerTarget(entry.board) : undefined;
      const source = target && sources.find(item => item.target?.provider === target.provider && item.target.board === target.board);
      return { ...entry, crawlable: !!target, added: !!source || manual.has(entry.name), ...(source ? { sourceId: source.id } : {}) };
    }) };
  };
  app.get("/api/companies/catalog", async () => catalogView());
  app.post("/api/companies/catalog/add", async request => {
    const { names } = z.object({ names: z.array(z.string().min(1).max(120)).min(1).max(200) }).strict().parse(request.body);
    const picked = COMPANY_CATALOG.filter(entry => names.includes(entry.name));
    if (!picked.length) throw new Error("Choose companies from the list.");
    let added = 0;
    const manual = new Set(store.value<string[]>("manual-companies", []));
    for (const entry of picked) {
      const target = entry.board ? parseCareerTarget(entry.board) : undefined;
      if (!target) { if (!manual.has(entry.name)) { manual.add(entry.name); added++; } continue; }
      const known = careerSources.list().some(item => item.target?.provider === target.provider && item.target.board === target.board);
      if (careerSources.addTarget(target, entry.name, { company: entry.name }).source && !known) added++;
    }
    store.set("manual-companies", [...manual]);
    autopilot.invalidate("Companies were added. Review your companies and activate Auto Apply again.");
    return { added, ...catalogView() };
  });
  app.post("/api/companies/manual/remove", async request => {
    const { name } = z.object({ name: z.string().min(1).max(120) }).strict().parse(request.body);
    store.set("manual-companies", store.value<string[]>("manual-companies", []).filter(item => item !== name));
    return { removed: true };
  });
  app.post("/api/companies/:id", async request => {
    const { id } = z.object({ id: z.string().regex(/^career-[a-f0-9-]{36}$/) }).parse(request.params);
    const value = z.object({ company: z.string().trim().min(1).max(120).optional(), roleFamilies: familyIds.optional(), sponsorsVisas: z.boolean().nullable().optional() }).strict().parse(request.body);
    // A sponsorship note only changes ranking in your daily list; scope changes pause Auto Apply.
    if (value.company !== undefined || value.roleFamilies !== undefined) autopilot.invalidate("Company roles changed. Review the scope and activate Auto Apply again.");
    return { source: careerSources.setInterests(id, value) };
  });
  app.get("/api/progress", async () => progress.view());
  return progress;
}
