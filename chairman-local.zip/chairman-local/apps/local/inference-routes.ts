import { z } from "zod";
import type { FastifyInstance } from "fastify";
import { configuredFieldAi, type FieldAi } from "./assist-ai.js";
import { DEFAULT_GEMINI_MODEL, GEMINI_FREE_MODELS } from "../../packages/inference/gemini.js";
import { listCopilotModels, type CopilotModelInventory } from "../../packages/inference/index.js";

export interface InferenceModelEntry { id: string; name?: string; enabled: boolean; state?: string; multiplier?: number }
export interface InferenceModelInventory {
  provider: "copilot" | "ollama" | "gemini";
  signedIn?: boolean;
  models: InferenceModelEntry[];
  reason?: string;
}
export interface InferenceTestResult {
  ok: boolean;
  ms: number;
  provider: string;
  model: string;
  answer?: unknown;
  error?: string;
}

const querySchema = z.object({
  provider: z.enum(["copilot", "ollama", "gemini"]).optional(),
  refresh: z.string().optional(),
}).passthrough();
const ollamaTags = z.object({
  models: z.array(z.object({ name: z.string().min(1), model: z.string().optional() }).passthrough()).max(500),
}).passthrough();

function selectedProvider(value?: string): "copilot" | "ollama" | "gemini" {
  if (value === "copilot" || value === "ollama" || value === "gemini") return value;
  return process.env.JAA_AI_PROVIDER === "copilot" || process.env.JAA_AI_PROVIDER === "gemini" ? process.env.JAA_AI_PROVIDER : "ollama";
}

async function ollamaModels(fetchImpl: typeof fetch): Promise<InferenceModelInventory> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 2_500);
    timer.unref();
    try {
      const response = await fetchImpl("http://127.0.0.1:11434/api/tags", { headers: { accept: "application/json" }, redirect: "error", signal: controller.signal });
      if (!response.ok) {
        await response.body?.cancel();
        return { provider: "ollama", models: [], reason: `Ollama model inventory returned HTTP ${response.status}.` };
      }
      const parsed = ollamaTags.safeParse(await response.json());
      if (!parsed.success) return { provider: "ollama", models: [], reason: "Ollama did not return a valid installed-model inventory." };
      return { provider: "ollama", models: parsed.data.models.map(model => ({ id: model.model || model.name, name: model.name, enabled: true })) };
    } finally { clearTimeout(timer); }
  } catch {
    return { provider: "ollama", models: [], reason: "Local Ollama could not be reached at http://127.0.0.1:11434/api/tags." };
  }
}

export function registerInferenceRoutes(app: FastifyInstance, options: {
  fieldAi?: FieldAi;
  copilotModels?: (refresh: boolean) => Promise<CopilotModelInventory>;
  fetch?: typeof fetch;
} = {}) {
  const fetchImpl = options.fetch ?? fetch;
  app.get("/api/inference/models", async request => {
    const query = querySchema.parse(request.query);
    const provider = selectedProvider(query.provider);
    if (provider === "copilot") return (options.copilotModels ?? listCopilotModels)(query.refresh === "1");
    if (provider === "gemini") return {
      provider,
      models: GEMINI_FREE_MODELS.map(id => ({ id, name: id === DEFAULT_GEMINI_MODEL ? `${id} · default` : id, enabled: true })),
    } satisfies InferenceModelInventory;
    return ollamaModels(fetchImpl);
  });

  app.post("/api/inference/test", async (): Promise<InferenceTestResult> => {
    const ai = options.fieldAi ?? configuredFieldAi();
    const started = Date.now();
    const status = await ai.status();
    if (!status.available) return { ok: false, ms: Date.now() - started, provider: status.provider, model: status.model, error: status.reason || "Configured AI is unavailable or not consented." };
    try {
      const answer = await ai.call({
        system: "Answer a tiny non-personal capability test. Return strict JSON only.",
        user: "Which option is a programming language: Python or Pancake?",
        schema: { type: "object", additionalProperties: false, required: ["answer"], properties: { answer: { enum: ["Python", "Pancake"] } } },
      });
      return { ok: true, ms: Date.now() - started, provider: status.provider, model: status.model, answer };
    } catch (error) {
      return { ok: false, ms: Date.now() - started, provider: status.provider, model: status.model, error: error instanceof Error ? error.message : "Configured AI test failed." };
    }
  });
}
