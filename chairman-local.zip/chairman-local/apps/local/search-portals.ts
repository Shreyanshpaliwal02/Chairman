import { randomUUID } from "node:crypto";
import { z } from "zod";
import { Store } from "./store.js";
import { validateSearchTemplate, type SearchPortal, type SearchPortalList } from "../../packages/domain/discovery-settings.js";

const builtIns: readonly SearchPortal[] = [
  { id: "linkedin", label: "LinkedIn", urlTemplate: "https://www.linkedin.com/jobs/search/?keywords={role}&location={location}", builtIn: true },
  { id: "indeed", label: "Indeed", urlTemplate: "https://www.indeed.com/jobs?q={role}&l={location}", builtIn: true },
  { id: "wellfound", label: "Wellfound", urlTemplate: "https://wellfound.com/jobs", builtIn: true },
  { id: "naukri", label: "Naukri", urlTemplate: "https://www.naukri.com/", builtIn: true },
  { id: "himalayas", label: "Himalayas", urlTemplate: "https://himalayas.app/jobs", builtIn: true },
  { id: "remotive", label: "Remotive", urlTemplate: "https://remotive.com/remote-jobs", builtIn: true },
  { id: "remoteok", label: "Remote OK", urlTemplate: "https://remoteok.com/", builtIn: true },
];
const change = z.discriminatedUnion("action", [
  z.object({ action: z.literal("save"), id: z.string().min(1).max(100).optional(), label: z.string().trim().min(1).max(100), urlTemplate: z.string() }).strict(),
  z.object({ action: z.literal("remove"), id: z.string().min(1).max(100) }).strict(),
]);

export class SearchPortalService {
  constructor(private store: Store) {}
  list(): SearchPortalList {
    return { portals: [...builtIns.map(portal => ({ ...portal })), ...this.store.value<SearchPortal[]>("manualSearchPortals", [])] };
  }
  update(body: unknown): SearchPortalList {
    const input = change.parse(body);
    const custom = this.store.value<SearchPortal[]>("manualSearchPortals", []);
    if (input.id && !custom.some(portal => portal.id === input.id)) throw new Error("Custom search portal not found. Built-in portals cannot be edited or removed.");
    if (input.action === "remove") this.store.set("manualSearchPortals", custom.filter(portal => portal.id !== input.id));
    else {
      if (!input.id && custom.length >= 30) throw new Error("Keep at most 30 custom search websites. Remove one before adding another.");
      const portal: SearchPortal = { id: input.id ?? randomUUID(), label: input.label, urlTemplate: validateSearchTemplate(input.urlTemplate), builtIn: false };
      this.store.set("manualSearchPortals", [...custom.filter(item => item.id !== portal.id), portal]);
    }
    return this.list();
  }
}
