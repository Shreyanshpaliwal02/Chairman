import { z } from "zod";
import { validDate } from "../../packages/domain/dates.js";
export const factSchema = z.object({
  id: z.string().min(1).max(100), category: z.enum(["experience", "education", "publication", "summary"]),
  text: z.string().min(1).max(10000), employer: z.string().max(300).optional(),
  role: z.string().max(300).optional(), dates: z.string().max(200).optional(), confirmed: z.boolean()
}).strict();
const record = z.record(z.string().max(300), z.string().max(20000));
export const profileSchema = z.object({
  name: z.string().max(200), email: z.union([z.email(), z.literal("")]), phone: z.string().max(100), location: z.string().max(300),
  links: record, skills: z.array(z.string().min(1).max(300)).max(400), facts: z.array(factSchema).max(300),
  answers: record, confirmed: z.boolean(), version: z.number().int().positive(),
  preferences: z.object({
    roles: z.array(z.string().max(100)).max(20), countries: z.array(z.string().max(100)).max(50),
    excludedEmployers: z.array(z.string().min(1).max(200)).max(100),
    salaryTargetInr: z.number().nonnegative().max(1e9), dailyLimit: z.number().int().min(1).max(Number.MAX_SAFE_INTEGER).nullable(),
    timezone: z.literal("Asia/Kolkata"), allowLongTermContracts: z.boolean(),
    authorizedCountries: z.array(z.string().max(100)).max(50), needsSponsorshipAbroad: z.boolean(),
    fillVoluntaryDisclosures: z.boolean().optional(), acceptRequiredAcknowledgements: z.boolean().optional()
  }).strict()
}).strict();
export const dateSchema = z.string().refine(validDate, "Use a valid YYYY-MM-DD date.");
export const campaignSchema = z.object({
  startDate: dateSchema, days: z.number().int().min(1).max(366),
  dailyTarget: z.number().int().min(1).max(100000), timezone: z.literal("Asia/Kolkata")
}).strict();
export const progressSchema = z.object({
  stage: z.enum(["applied", "screening", "interview", "offer", "rejected", "withdrawn"]),
  note: z.string().max(4000), nextActionDate: dateSchema.optional()
}).strict();
export const answersSchema = z.object({ answers: record }).strict();
export const formSchema = z.object({
  url: z.url().max(2000),
  fields: z.array(z.object({
    key: z.string().min(1).max(200), label: z.string().max(1000), type: z.string().max(60),
    required: z.boolean(), options: z.array(z.string().max(1000)).max(300),
    optionLabels: z.record(z.string().max(1000), z.string().max(1000)).optional(),
    accept: z.array(z.string().max(200)).max(30).optional(),
    hint: z.string().max(500).optional(), placeholder: z.string().max(200).optional(),
    autocomplete: z.string().max(100).optional(), pattern: z.string().max(500).optional(),
    maxLength: z.number().int().min(0).max(1_000_000).optional(), minLength: z.number().int().min(0).max(1_000_000).optional(),
    sensitivity: z.enum(["disclosure", "acknowledgement"]).optional()
  }).strict()).max(100),
  fingerprint: z.string().regex(/^[a-f0-9]{64}$/),
  hasCaptcha: z.boolean(), hasLegal: z.boolean(), unsupported: z.array(z.string().max(2000)).max(100)
}).strict();
