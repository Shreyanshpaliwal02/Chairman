import { randomUUID } from "node:crypto";
import type { CareerBoardTarget, CareerLinkResolution, CareerSource, Job, Source } from "../../packages/domain/types.js";
import { resolveCareerLink, scanCareerBoard } from "../../packages/adapters/career-links.js";
import { crawlBoard, crawls } from "../../packages/adapters/boards.js";
import { DiscoveryError } from "../../packages/adapters/discovery.js";
import { Store } from "./store.js";

const MIN_SCAN_DELAY = 5 * 60_000;
const COMPLETE_SCAN_DELAY = 6 * 60 * 60_000;
/** Hosted boards are crawled whole about once a day. */
const CRAWL_DELAY = 20 * 60 * 60_000;
const MAX_SOURCES = 150;
export interface CareerOptions {
  resolve?: typeof resolveCareerLink;
  scan?: typeof scanCareerBoard;
  crawl?: typeof crawlBoard;
}
/** Which titles are worth storing, and what to search on boards too large to list. */
export interface CrawlRelevance { keep: (title: string) => boolean; queries: () => string[] }
export class CareerSourceService {
  private running?: Promise<void>;
  private readonly crawling = new Set<AbortController>();
  private timer?: ReturnType<typeof setInterval>;
  private closing = false;
  private generation = 0;
  relevance?: CrawlRelevance;
  constructor(readonly store: Store, readonly options: CareerOptions = {}) {
    store.db.exec(`CREATE TABLE IF NOT EXISTS career_sources(id TEXT PRIMARY KEY,identity TEXT UNIQUE NOT NULL,json TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS career_source_jobs(source_id TEXT NOT NULL,job_id TEXT NOT NULL,PRIMARY KEY(source_id,job_id));
      CREATE INDEX IF NOT EXISTS career_jobs_job ON career_source_jobs(job_id)`);
  }
  list(): CareerSource[] {
    return this.store.db.prepare("SELECT json FROM career_sources ORDER BY rowid DESC").all().map(row => JSON.parse(String(row.json)) as CareerSource);
  }
  get(id: string): CareerSource {
    const row = this.store.db.prepare("SELECT json FROM career_sources WHERE id=?").get(id);
    if (!row) throw new Error("Career source not found.");
    return JSON.parse(String(row.json)) as CareerSource;
  }
  private put(source: CareerSource): void {
    const identity = `${source.target?.provider}:${source.target?.provider === "generic" ? source.target.boardUrl : source.target?.board}:${source.target?.jobId ?? "*"}`;
    this.store.db.prepare("INSERT INTO career_sources VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET json=excluded.json").run(source.id, identity, JSON.stringify(source));
  }
  scope(): unknown {
    return this.list().filter(source => source.enabled).map(source => ({ id: source.id, target: source.target })).sort((a, b) => a.id.localeCompare(b.id));
  }
  allowsJob(job: Job): boolean {
    if (!job.sourceId.startsWith("career-")) return true;
    const ids = job.careerSourceIds ?? [job.sourceId];
    return this.list().some(source => ids.includes(source.id) && source.enabled && Boolean(source.target));
  }
  asSources(): Source[] {
    return this.list().map(source => ({
      id: source.id, name: source.label, mode: source.enabled ? source.status === "error" ? "paused" : "enabled" : "paused",
      kind: source.target?.provider ?? "manual", careersUrl: source.target?.boardUrl ?? source.inputUrl,
      discoveryAllowed: source.enabled && Boolean(source.target), assistanceAllowed: false, submissionAllowed: false,
      policyUrl: source.target?.provider === "ashby" ? "https://developers.ashbyhq.com/docs/public-job-posting-api" : source.target?.provider === "greenhouse" ? "https://docs.greenhouse.io/job-board.html" : source.inputUrl,
      notes: `Added career link. ${source.message} Application sending requires Auto Apply activation and your matching rules; public listing access is not submission permission.`,
      count: source.jobCount, lastScannedAt: source.lastScannedAt, ...(source.status === "error" ? { lastError: source.message } : {})
    }));
  }
  /** Company name and role families you apply to at this company (always-apply families are added automatically). */
  setInterests(id: string, input: { company?: string; roleFamilies?: string[]; sponsorsVisas?: boolean | null }): CareerSource {
    const source = this.get(id);
    if (input.company !== undefined) source.company = input.company.trim().slice(0, 120) || undefined;
    if (input.roleFamilies !== undefined) source.roleFamilies = [...new Set(input.roleFamilies)].slice(0, 20);
    if (input.sponsorsVisas === null) delete source.sponsorsVisas;
    else if (input.sponsorsVisas !== undefined) source.sponsorsVisas = input.sponsorsVisas;
    source.updatedAt = new Date().toISOString();
    this.put(source);
    return source;
  }
  async add(url: string, label?: string, interests: { company?: string; roleFamilies?: string[] } = {}): Promise<{ source?: CareerSource; resolution: CareerLinkResolution }> {
    if (this.closing) throw new Error("The career scanner is stopping.");
    const generation = this.generation;
    const resolution = await (this.options.resolve ?? resolveCareerLink)(url);
    if (this.closing || generation !== this.generation) throw new Error("Career-link resolution was cancelled while the scanner stopped.");
    if (!resolution.target) return { resolution };
    return this.register(url, resolution.target, label, interests, resolution);
  }
  /** Adds a company from a board you (or the catalog) already identified; no page is fetched to resolve it. */
  addTarget(target: CareerBoardTarget, label: string, interests: { company?: string; roleFamilies?: string[]; sponsorsVisas?: boolean } = {}): { source?: CareerSource; resolution: CareerLinkResolution } {
    if (this.closing) throw new Error("The career scanner is stopping.");
    // A board is tracked as a whole: a single-posting link becomes its company board.
    const { jobId: _job, ...board } = target;
    return this.register(board.boardUrl, crawls(board as CareerBoardTarget) ? board as CareerBoardTarget : target, label, interests,
      { target, candidates: [], message: "Known public board. Its open roles are crawled daily; applying still needs your action." });
  }
  private register(url: string, target: CareerBoardTarget, label: string | undefined, interests: { company?: string; roleFamilies?: string[]; sponsorsVisas?: boolean },
    resolution: CareerLinkResolution): { source?: CareerSource; resolution: CareerLinkResolution } {
    const identity = `${target.provider}:${target.provider === "generic" ? target.boardUrl : target.board}:${target.jobId ?? "*"}`;
    const existing = this.store.db.prepare("SELECT json FROM career_sources WHERE identity=?").get(identity);
    if (existing) return { source: JSON.parse(String(existing.json)) as CareerSource, resolution: { ...resolution, message: "This career board/job is already registered. Its existing scan schedule and enabled state were preserved." } };
    if (this.list().length >= MAX_SOURCES) throw new Error(`This personal scanner supports up to ${MAX_SOURCES} career sources. Remove an unused source before adding another.`);
    const timestamp = new Date().toISOString();
    const source: CareerSource = {
      id: `career-${randomUUID()}`, inputUrl: url, target, label: label?.trim() || `${target.board} (${target.provider})`,
      ...(interests.company?.trim() ? { company: interests.company.trim().slice(0, 120) } : {}),
      ...(interests.roleFamilies?.length ? { roleFamilies: [...new Set(interests.roleFamilies)].slice(0, 20) } : {}),
      ...(interests.sponsorsVisas !== undefined ? { sponsorsVisas: interests.sponsorsVisas } : {}),
      enabled: true, status: "ready", message: "Added. A public listing scan is queued; review and re-enable Auto Apply to include matching jobs.",
      createdAt: timestamp, updatedAt: timestamp, jobCount: 0, nextScanAt: timestamp
    };
    this.store.transaction(() => {
      if (this.list().length >= MAX_SOURCES) throw new Error("The maximum number of career sources has been reached.");
      this.put(source);
    });
    this.store.event(null, "career_source_added", "User added a career source. No application or personal data was sent.");
    this.kick();
    return { source, resolution };
  }
  setEnabled(id: string, enabled: boolean): CareerSource {
    const source = this.get(id);
    source.enabled = enabled; source.status = enabled ? "ready" : "paused";
    source.message = enabled ? "Public scanning enabled. Existing source cooldown remains in effect." : "Paused by you; no new jobs will be scanned from this source.";
    source.updatedAt = new Date().toISOString();
    this.put(source);
    if (enabled) this.kick();
    return source;
  }
  remove(id: string): void {
    this.get(id);
    this.store.transaction(() => {
      this.store.db.prepare("DELETE FROM career_source_jobs WHERE source_id=?").run(id);
      this.store.db.prepare("DELETE FROM career_sources WHERE id=?").run(id);
    });
  }
  requestScan(id: string): CareerSource {
    const source = this.get(id);
    if (!source.enabled) throw new Error("Resume this career source before scanning.");
    if (source.nextScanAt && Date.parse(source.nextScanAt) > Date.now()) throw new Error(`Career source cooldown: next scan after ${source.nextScanAt}.`);
    this.kick(id);
    return source;
  }
  async scanOne(id?: string): Promise<void> {
    if (this.closing) return;
    const source = id ? this.get(id) : this.list().filter(source => source.enabled && (!source.nextScanAt || Date.parse(source.nextScanAt) <= Date.now()))
      .sort((a, b) => (a.nextScanAt ?? "").localeCompare(b.nextScanAt ?? ""))[0];
    if (!source?.enabled || !source.target || (source.nextScanAt && Date.parse(source.nextScanAt) > Date.now())) return;
    const reserved = this.store.transaction(() => {
      const current = this.get(source.id);
      const identity = `${current.target!.provider}:${current.target!.board}`;
      const now = Date.now(), next = this.store.value(`career-board-cooldown:${identity}`, 0);
      if (next > now) {
        current.nextScanAt = new Date(next).toISOString(); this.put(current); return false;
      }
      current.status = "scanning"; current.message = "Reading a bounded page of public listings.";
      current.nextScanAt = new Date(now + MIN_SCAN_DELAY).toISOString(); current.updatedAt = new Date(now).toISOString();
      this.store.set(`career-board-cooldown:${identity}`, now + MIN_SCAN_DELAY);
      this.put(current); return true;
    });
    if (!reserved) return;
    if (!this.options.scan && crawls(source.target)) { await this.crawlOne(source); return; }
    try {
      const cursor = this.store.value<string | null>(`career-cursor:${source.id}`, null) ?? undefined;
      const result = await (this.options.scan ?? scanCareerBoard)(source.target, source.id, source.label, cursor);
      if (result.jobs.some(job => job.sourceId !== source.id)) throw new Error("Career adapter returned a job outside its registered source.");
      const stillPresent = this.list().find(item => item.id === source.id);
      if (!stillPresent?.enabled) return;
      this.store.transaction(() => {
        const now = new Date().toISOString();
        for (const job of result.jobs) {
          const saved = this.store.saveJob({ ...job, careerSourceIds: [source.id], cacheExpired: false, cacheExpiresAt: new Date(Date.now() + 30 * 86400_000).toISOString() });
          this.store.db.prepare("INSERT OR IGNORE INTO career_source_jobs VALUES (?,?)").run(source.id, saved.id);
        }
        this.store.set(`career-cursor:${source.id}`, result.nextCursor ?? null);
        stillPresent.status = "ready";
        stillPresent.jobCount = Number(this.store.db.prepare("SELECT count(*) AS n FROM career_source_jobs WHERE source_id=?").get(source.id)?.n ?? 0);
        stillPresent.lastScannedAt = now; stillPresent.updatedAt = now;
        stillPresent.message = `${result.jobs.length} listings imported in this page. ${result.nextCursor ? "More pages will be scanned automatically." : "Current listing pass complete; future scans will refresh it."} Matching jobs require your active Auto Apply authorization.`;
        stillPresent.nextScanAt = new Date(Date.now() + (result.nextCursor ? MIN_SCAN_DELAY : COMPLETE_SCAN_DELAY)).toISOString();
        this.put(stillPresent);
      });
    } catch (error) {
      const current = this.list().find(item => item.id === source.id);
      if (!current) return;
      const retryAfter = error instanceof DiscoveryError ? error.retryAfterMs ?? 0 : 0;
      const delay = Math.max(MIN_SCAN_DELAY, Number.isFinite(retryAfter) ? retryAfter : COMPLETE_SCAN_DELAY);
      const safeDelay = Math.min(delay, 8.64e15 - Date.now());
      current.status = "error"; current.message = error instanceof Error ? error.message : "Career source scan failed.";
      current.updatedAt = new Date().toISOString(); current.nextScanAt = new Date(Date.now() + safeDelay).toISOString();
      if (error instanceof DiscoveryError && [401, 403].includes(error.httpStatus ?? 0)) current.enabled = false;
      this.store.transaction(() => {
        this.store.set(`career-board-cooldown:${source.target!.provider}:${source.target!.board}`, Date.now() + safeDelay);
        this.put(current);
      });
    }
  }
  /** One whole-board crawl: store roles whose title fits your role families, and close roles the board no longer lists. */
  private async crawlOne(source: CareerSource): Promise<void> {
    const keep = this.relevance?.keep ?? (() => true);
    const crawling = new AbortController();
    this.crawling.add(crawling);
    try {
      const result = await (this.options.crawl ?? crawlBoard)(source.target!, source.id, source.label, {
        keep: title => keep(title), queries: this.relevance?.queries() ?? [], company: source.company ?? source.label, signal: crawling.signal });
      // Stopped by a shutdown: the board stays "scanning", so the next start marks it interrupted and it is crawled again shortly.
      if (crawling.signal.aborted) return;
      if (result.jobs.some(job => job.sourceId !== source.id)) throw new Error("Career crawler returned a job outside its registered source.");
      const current = this.list().find(item => item.id === source.id);
      if (!current?.enabled) return;
      this.store.transaction(() => {
        const now = new Date().toISOString(), seen = new Set<string>();
        for (const job of result.jobs) {
          const saved = this.store.saveJob({ ...job, careerSourceIds: [source.id], cacheExpired: false, cacheExpiresAt: new Date(Date.now() + 30 * 86400_000).toISOString() });
          this.store.db.prepare("INSERT OR IGNORE INTO career_source_jobs VALUES (?,?)").run(source.id, saved.id);
          seen.add(saved.id);
        }
        let closed = 0;
        if (!result.truncated) {
          for (const row of this.store.db.prepare("SELECT job_id FROM career_source_jobs WHERE source_id=?").all(source.id)) {
            const id = String(row.job_id);
            if (seen.has(id)) continue;
            const job = this.store.job(id);
            if (job && job.status === "open" && keep(job.title)) { this.store.saveJob({ ...job, status: "closed" }); closed++; }
          }
        }
        current.crawl = { at: now, listed: result.listed, relevant: result.kept, closed, truncated: result.truncated };
        current.status = "ready";
        current.jobCount = Number(this.store.db.prepare("SELECT count(*) AS n FROM career_source_jobs WHERE source_id=?").get(source.id)?.n ?? 0);
        current.lastScannedAt = now; current.updatedAt = now;
        current.message = `${result.listed} open role${result.listed === 1 ? "" : "s"} on the board; ${result.kept} match your role families`
          + `${result.truncated ? " (large board: searched with your role keywords)" : ""}${closed ? `; ${closed} no longer listed` : ""}. Next check in about a day.`;
        current.nextScanAt = new Date(Date.now() + CRAWL_DELAY).toISOString();
        this.put(current);
      });
    } catch (error) {
      if (crawling.signal.aborted) return;
      const current = this.list().find(item => item.id === source.id);
      if (!current) return;
      const retryAfter = error instanceof DiscoveryError ? error.retryAfterMs ?? 0 : 0;
      const delay = Math.min(Math.max(30 * 60_000, Number.isFinite(retryAfter) ? retryAfter : COMPLETE_SCAN_DELAY), 8.64e15 - Date.now());
      current.status = "error"; current.message = `Crawl failed: ${error instanceof Error ? error.message : "unknown error"} Retrying later.`;
      current.updatedAt = new Date().toISOString(); current.nextScanAt = new Date(Date.now() + delay).toISOString();
      this.store.transaction(() => {
        this.store.set(`career-board-cooldown:${source.target!.provider}:${source.target!.board}`, Date.now() + delay);
        this.put(current);
      });
    } finally { this.crawling.delete(crawling); }
  }
  /** Due every enabled board now (used by the daily list's morning refresh); cooldowns still apply per board. */
  refreshAll(olderThanMs = 12 * 60 * 60_000): number {
    let due = 0;
    for (const source of this.list()) {
      if (!source.enabled || !source.target || source.status === "scanning") continue;
      if (source.lastScannedAt && Date.now() - Date.parse(source.lastScannedAt) < olderThanMs) continue;
      if (source.nextScanAt && Date.parse(source.nextScanAt) > Date.now()) { source.nextScanAt = new Date().toISOString(); this.put(source); }
      due++;
    }
    this.kick();
    return due;
  }
  kick(id?: string): void {
    if (this.running || this.closing) return;
    this.running = this.scanOne(id).catch(error => {
      this.store.event(null, "career_scan_error", error instanceof Error ? error.message : "Career scanner persistence failed.");
    }).finally(() => { this.running = undefined; });
  }
  start(): void {
    this.closing = false;
    for (const source of this.list()) if (source.enabled && source.status === "scanning") {
      source.status = "error"; source.message = "The previous scan was interrupted. It will resume after the existing cooldown; its cursor was not advanced.";
      source.updatedAt = new Date().toISOString(); this.put(source);
    }
    this.kick();
    this.timer = setInterval(() => this.kick(), 15_000); this.timer.unref();
  }
  async close(): Promise<void> { this.closing = true; this.generation++; clearInterval(this.timer); for (const crawl of this.crawling) crawl.abort(); await this.running; }
}
