import { lstat, mkdir, open, readFile, rename, rm } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { join } from "node:path";
import { z } from "zod";

const apiKey = z.string().regex(/^AIza[A-Za-z0-9_-]{35}$/, "Enter a valid Google AI Studio API key.");
export const geminiKeyRequestSchema = z.union([
  z.object({ apiKey }).strict(),
  z.object({ revoke: z.literal(true) }).strict(),
]);
const storedKeySchema = z.object({ apiKey: apiKey.nullable() }).strict();
const missing = (error: unknown): boolean => error instanceof Error && "code" in error && error.code === "ENOENT";

/** Separate from SQLite/settings/exports. A null marker also disables environment-key fallback. */
export function createGeminiKeyStore(dataDir: string, environment: () => NodeJS.ProcessEnv = () => process.env) {
  const directory = join(dataDir, "private");
  const path = join(directory, "gemini-key.json");
  let stored: string | null | undefined;
  async function load(): Promise<void> {
    try {
      const dir = await lstat(directory);
      if (!dir.isDirectory() || dir.isSymbolicLink()
        || (process.platform !== "win32" && (dir.mode & 0o077) !== 0)) throw new Error("Invalid private key directory permissions.");
      const info = await lstat(path);
      if (!info.isFile() || info.isSymbolicLink() || info.size > 1024
        || (process.platform !== "win32" && (info.mode & 0o077) !== 0)) throw new Error("Invalid private key file permissions or size.");
      const parsed = storedKeySchema.safeParse(JSON.parse(await readFile(path, "utf8")));
      if (!parsed.success) throw new Error("Invalid private key file.");
      stored = parsed.data.apiKey;
    } catch (error) {
      if (missing(error)) { stored = undefined; return; }
      throw new Error("The private Gemini key file could not be loaded. Repair its format and owner-only permissions before starting.");
    }
  }
  async function write(value: string | null): Promise<void> {
    const temporary = join(directory, `gemini-key-${randomUUID()}.tmp`);
    try {
      await mkdir(directory, { recursive: true, mode: 0o700 });
      const dir = await lstat(directory);
      if (!dir.isDirectory() || dir.isSymbolicLink()
        || (process.platform !== "win32" && (dir.mode & 0o077) !== 0)) throw new Error("Invalid private key directory permissions.");
      const handle = await open(temporary, "wx", 0o600);
      try { await handle.writeFile(JSON.stringify({ apiKey: value }), "utf8"); await handle.sync(); }
      finally { await handle.close(); }
      await rename(temporary, path);
      stored = value;
    } catch {
      throw new Error("The private Gemini key could not be saved. Check the local data directory and owner-only permissions.");
    } finally { await rm(temporary, { force: true }); }
  }
  return {
    load,
    get: (): string | undefined => stored === null ? undefined : stored ?? environment().JAA_GEMINI_API_KEY ?? environment().GEMINI_API_KEY,
    save: async (value: string): Promise<void> => {
      const parsed = apiKey.safeParse(value);
      if (!parsed.success) throw new Error("Enter a valid Google AI Studio API key.");
      await write(parsed.data);
    },
    revoke: (): Promise<void> => write(null),
  };
}
