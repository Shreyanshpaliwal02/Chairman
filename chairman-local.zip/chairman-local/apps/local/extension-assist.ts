import type { ProgressService } from "./progress.js";
import type { ApplySessionService } from "./apply-sessions.js";
import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { createHash, randomUUID } from "node:crypto";
import { readFile, rm } from "node:fs/promises";
import { join } from "node:path";
import { assistancePagePayload, assistanceSnapshotPayload, type AssistanceGrant, type AssistancePage, type AssistanceRecord, type AssistanceReview,
  type AssistDebugStep, type AssistPlan, type AssistPlanItem, type AssistRepair, type AssistResumeOption } from "../../packages/domain/extension-assist.js";
import type { Fact, FormField, Job, Packet, Profile } from "../../packages/domain/types.js";
import { ASSIST_KEY, adaptToField, autocompleteMeaning, canonicalJson, comparableValue, formatDateLike, matchChoice, normalizeText } from "../../packages/domain/assist-match.js";
import { analyzeKeywords } from "../../packages/domain/keywords.js";
import { digest } from "../../packages/domain/matching.js";
import { normalizeQuestion, profileResolveOptions, questionKey, resolveAnswers } from "../../packages/automation/answers.js";
import type { AnswerPlan, PagePlan } from "../../packages/automation/contracts.js";
import type { QuestionInbox } from "./progress.js";
import type { RoleFamilyService } from "./role-families.js";
import { bankQuestion } from "../../packages/domain/question-bank.js";
import { CONFIRMATION_TEXT } from "../../packages/domain/extension-assist.js";
import { createDocuments, hasNoAiRestriction, validateResumeSelection } from "../../packages/documents/index.js";
import { addSelectedKeywords } from "../../packages/documents/keywords.js";
import { assistanceDestination } from "../extension/assist-safety.js";
import { formSchema, dateSchema } from "./schemas.js";
import { Engine, packetHash, today } from "./engine.js";
import { Store, jobIdentity } from "./store.js";
import { ResumeLibrary } from "./resume-library.js";
import type { AutopilotService } from "./autopilot.js";
import { AssistIntelligence, type AiDecision, type AiQuestion, type AnswerKeyEntry, type FieldAi } from "./assist-ai.js";

const hash = (value: string | Buffer) => createHash("sha256").update(value).digest("hex");
const normalizeSpace = (value: string) => value.normalize("NFKC").replace(/\s+/g, " ").trim();
const controls = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]/u;
const idSchema = z.string().uuid();
const keySchema = z.string().regex(ASSIST_KEY);
const pageSchema = z.object({
  url: z.url().max(2000), kind: z.enum(["job", "form", "listing", "unsupported"]), title: z.string().max(300),
  job: z.object({ title: z.string().max(300), company: z.string().max(300), location: z.string().max(300),
    description: z.string().min(100).max(50_000), evidence: z.enum(["JobPosting", "visible-description"]) }).strict().optional(),
  snapshot: formSchema, occupied: z.array(keySchema).max(100),
  fingerprint: z.string().regex(/^[a-f0-9]{64}$/), blockers: z.array(z.string().max(2000)).max(120),
  embedded: z.object({ url: z.url().max(2000), host: z.string().max(300) }).strict().optional()
}).strict();
const withPage = z.object({ id: idSchema, page: pageSchema }).strict();
// A strict subset of what the page script already excludes; anything matching here indicates a forged snapshot.
const neverField = /\b(?:password|passcode|otp|secret|token|verification code|credit card|social security|national id|signature|own words)\b/i;
const consentWords = /\b(?:consent|certify|declaration|agree|privacy)\b/i;
// Consent wording is accepted only on fields the page tagged as acknowledgements (filled from your explicit Profile switch).
const unsafeField = (field: Pick<FormField, "label" | "sensitivity">) => neverField.test(field.label) || consentWords.test(field.label) && field.sensitivity !== "acknowledgement";
// Never sent to a model: demographics, eligibility/immigration and background questions stay deterministic or manual.
// Known education/experience questions may be matched to your confirmed facts with AI (validated by cited fact); every other known key needs your saved answer.
const factGrounded = (key: string | undefined) => !!key && ["education", "experience"].includes(bankQuestion(key)?.category ?? "");
const aiExcluded = /\b(?:gender|sex|sexual|pronouns?|ethnic(?:ity)?|race|racial|disabilit(?:y|ies)|veteran|religio(?:n|us)|marital|nationality|citizenship|citizen|date of birth|birth ?date|age|visa|sponsor(?:ship)?|authori[sz](?:ed|ation)|right to work|work permit|immigration|criminal|convict(?:ed|ion)|background)\b/i;
const MAX_FILLS_PER_RECORD = 30;
const DERIVED_ANSWERS = ["Current employer", "Current company", "Current job title", "School", "University", "Institution", "Degree", "Education summary"];
const ISO_CURRENCIES = new Set("AED AUD BDT BRL CAD CHF CNY CZK DKK EGP EUR GBP HKD IDR ILS INR JPY KRW MXN MYR NOK NZD PHP PKR PLN QAR RON SAR SEK SGD THB TRY TWD UAH USD VND ZAR".split(" "));
const STATIC_KEYS: readonly { key: string; meaning: string; label: string }[] = [
  { key: "name", meaning: "full name", label: "full name" },
  { key: "first_name", meaning: "first or given name", label: "first name" },
  { key: "last_name", meaning: "last or family name", label: "last name" },
  { key: "email", meaning: "email address", label: "email" },
  { key: "phone", meaning: "phone number", label: "phone" },
  { key: "location", meaning: "current location (city and country)", label: "location" },
  { key: "city", meaning: "current city of residence", label: "city" },
  { key: "country", meaning: "current country of residence", label: "country" },
  { key: "postal_code", meaning: "postal, ZIP or PIN code", label: "postal code" },
  { key: "linkedin", meaning: "LinkedIn profile URL", label: "linkedin url" },
  { key: "github", meaning: "GitHub profile URL", label: "github url" },
  { key: "work_location", meaning: "planned work location", label: "work location" },
  { key: "notice_period_days", meaning: "notice period in days", label: "notice period (days)" },
  { key: "available_start_date", meaning: "earliest available start date", label: "available start date" },
  { key: "total_years_experience", meaning: "total years of professional experience", label: "total years of experience" },
  { key: "willing_to_relocate", meaning: "willing to relocate (yes/no)", label: "willing to relocate" },
  { key: "travel_willingness", meaning: "willingness to travel", label: "willingness to travel" },
  { key: "current_employer", meaning: "current employer or company", label: "Current employer" },
  { key: "current_title", meaning: "current job title", label: "Current job title" },
  { key: "school", meaning: "university or school attended", label: "School" },
  { key: "degree", meaning: "degree earned", label: "Degree" },
  // Saved-answer keys the AI may map unusual wordings to; the value still comes from your saved answer or your confirmed profile.
  ...["open_to_onsite", "work_arrangement", "relocation_locations", "how_did_you_hear", "previously_employed_here", "interviewed_here_before", "referred_by_employee",
    "currently_employed", "highest_degree", "field_of_study", "graduation_year", "timezone", "state_province", "street_address", "address_line_2", "preferred_name",
    "portfolio_url", "phone_country_code", "phone_device_type", "alternate_phone", "non_compete"].flatMap(key => {
    const entry = bankQuestion(key);
    return entry ? [{ key, meaning: `${entry.label}${entry.choices ? ` (one of: ${entry.choices.join(", ")})` : ""}`, label: entry.label }] : [];
  }),
];
type CatalogEntry = AnswerKeyEntry & { link?: string };
type Options = { store: Store; engine: Engine; library: ResumeLibrary; autopilot?: AutopilotService; ai?: FieldAi; inbox?: QuestionInbox; families?: RoleFamilyService;
  progress?: ProgressService; sessions?: ApplySessionService };
type GrantState = {
  recordId: string; packetId?: string; packetHash?: string; profileHash: string; expiresAt: number; url: string;
  keys: string[]; resumeKey?: string; values: Record<string, string>; fields: Record<string, FormField>; drafts: Set<string>;
};
type Remembered = Record<string, { question: string; value: string; updatedAt: string }>;
type Log = (step: string, detail?: string, ok?: boolean) => void;
type PlanMaterial = { page: string; items: { key: string; label: string; value: string; source: string; overwrite: boolean }[]; resume: string[] };
/** Collects value-free diagnostic steps for the extension's debug view; mirrors them to stderr when JAA_DEBUG=1. */
function debugLog(sink: AssistDebugStep[], scope: string): Log {
  return (step, detail = "", ok = true) => {
    if (sink.length < 200) sink.push({ step, ...(detail ? { detail: detail.slice(0, 500) } : {}), ...(ok ? {} : { ok: false as const }) });
    if (process.env.JAA_DEBUG === "1") console.error(`[assist ${scope}] ${ok ? "" : "FAILED "}${step}${detail ? `: ${detail}` : ""}`);
  };
}
const quiet: Log = () => {};
export interface FillReport {
  filled: string[]; preserved: string[]; skipped: { key: string; reason: string }[];
  errors: { key: string; message: string; options?: string[] }[]; newFields: number; blockers: string[]; selected: Record<string, string>;
}

function unitsCompatible(label: string, key: string): boolean {
  const text = normalizeText(label);
  if ((key.startsWith("years_") || key === "total_years_experience") && /\b(?:months?|weeks?|days?)\b/.test(text)) return false;
  if (key === "notice_period_days" && /\b(?:months?|weeks?|years?)\b/.test(text)) return false;
  const salary = key.match(/^expected_salary_([A-Z]{3})(?:_(annual|monthly|hourly))?$/);
  if (salary) {
    const named = (label.toUpperCase().match(/\b[A-Z]{3}\b/g) ?? []).filter(code => ISO_CURRENCIES.has(code));
    const symbols = [["₹", "INR"], ["€", "EUR"], ["£", "GBP"], ["¥", "JPY"]].filter(([symbol]) => label.includes(symbol)).map(([, code]) => code);
    if ([...named, ...symbols].some(code => code !== salary[1])) return false;
    if (label.includes("$") && !["USD", "CAD", "AUD", "SGD", "NZD", "HKD"].includes(salary[1])) return false;
    const periods = [...text.matchAll(/\b(annual(?:ly)?|yearly|per year|monthly|per month|hourly|per hour)\b/g)]
      .map(match => /annual|year/.test(match[1]) ? "annual" : /month/.test(match[1]) ? "monthly" : "hourly");
    if (periods.length && (!salary[2] || periods.some(period => period !== salary[2]))) return false;
  }
  return true;
}
function companyFromUrl(url: URL): string {
  const host = url.hostname.toLowerCase(), segment = url.pathname.split("/").filter(Boolean)[0] ?? "";
  if (/^[\d.]+$|:/.test(host)) return host;
  const pathHosted = /(?:^|\.)(?:greenhouse\.io|lever\.co|ashbyhq\.com|smartrecruiters\.com)$/.test(host) || host === "apply.workable.com";
  const raw = pathHosted && segment && !/^(?:embed|jobs?|careers?|o|j)$/i.test(segment) ? segment
    : /(?:^|\.)(?:workable\.com|myworkdayjobs\.com|bamboohr\.com|recruitee\.com|breezy\.hr|teamtailor\.com|applytojob\.com)$/.test(host) ? host.split(".")[0]
      : host.replace(/^(?:www|careers|jobs|apply|boards|job-boards)\./, "").split(".")[0];
  return raw.replace(/[-_]+/g, " ").replace(/\b\p{L}/gu, letter => letter.toUpperCase()).slice(0, 120) || host;
}
/** Same application: same origin and, when both URLs carry job ids, a shared id; otherwise the same first path segment (tenant). */
export function sameApplication(recordUrl: string, pageUrl: string): boolean {
  const a = new URL(recordUrl), b = new URL(pageUrl);
  if (a.origin !== b.origin) return false;
  const ids = (url: URL) => [...url.pathname.matchAll(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|\d{5,}/gi)].map(match => match[0].toLowerCase())
    .concat(["gh_jid", "token", "jobId", "job_id"].map(name => url.searchParams.get(name) ?? "").filter(Boolean));
  const left = ids(a), right = ids(b);
  if (left.length && right.length) return left.some(id => right.includes(id));
  const tenant = (url: URL) => url.pathname.split("/").filter(Boolean)[0]?.toLowerCase() ?? "";
  return tenant(a) === tenant(b);
}
function messageFor(plan: AnswerPlan, key: string): string | undefined {
  const marker = `[${key}]: `;
  const message = [...plan.blockers, ...plan.missing].find(item => item.includes(marker));
  return message ? message.slice(message.indexOf(marker) + marker.length) : undefined;
}
function optionItems(field: FormField): { value: string; label: string }[] | undefined {
  return field.options.length ? field.options.map(value => ({ value, label: field.optionLabels?.[value] ?? value })) : undefined;
}
function displayOf(field: FormField, value: string): string { return field.optionLabels?.[value] ?? value; }
function factSummary(facts: Fact[]): string {
  return facts.map(fact => [fact.role, fact.employer].filter(Boolean).join(" at ") || fact.text.slice(0, 60)).slice(0, 3).join("; ");
}

export class ExtensionAssistService {
  private grants = new Map<string, GrantState>();
  private generation = 0;
  private closed = false;
  private busy = new Set<string>();
  private pending = new Set<Promise<unknown>>();
  // Recent plans' hashed material, in memory only, to explain (without values) why a reviewed plan no longer matches.
  private recentPlans = new Map<string, PlanMaterial>();
  readonly intelligence: AssistIntelligence;
  constructor(readonly options: Options) {
    options.store.db.exec("CREATE TABLE IF NOT EXISTS assistance_records(id TEXT PRIMARY KEY,json TEXT NOT NULL); CREATE INDEX IF NOT EXISTS assistance_job ON assistance_records(json_extract(json,'$.jobId'))");
    this.intelligence = new AssistIntelligence(options.store, options.ai);
    for (const record of this.export().filter(item => item.status === "fill_intent")) {
      record.status = "manual_required"; record.blockers = ["The service restarted during a fill. Inspect the actual page; no submission is implied."]; this.save(record);
    }
  }
  invalidate(): void {
    this.generation++;
    for (const grant of this.grants.values()) {
      const record = this.get(grant.recordId);
      if (record.status === "fill_intent") { record.status = "manual_required"; record.blockers = ["Fill authorization was revoked. Inspect the actual page; nothing is counted as submitted."]; this.save(record); }
    }
    this.grants.clear();
  }
  async close(): Promise<void> {
    this.invalidate(); this.closed = true;
    await Promise.allSettled([...this.pending]);
  }
  clear(): void {
    if (this.busy.size) throw new Error("Wait for current resume preparation or page authorization to finish before deleting local data.");
    this.invalidate(); this.options.store.db.exec("DELETE FROM assistance_records");
  }
  export(): AssistanceRecord[] { return this.options.store.db.prepare("SELECT json FROM assistance_records ORDER BY rowid DESC").all().map(row => JSON.parse(String(row.json)) as AssistanceRecord); }
  list(limit = 100, offset = 0): { items: AssistanceRecord[]; total: number } {
    this.expire();
    return {
      items: this.options.store.db.prepare("SELECT json FROM assistance_records ORDER BY json_extract(json,'$.updatedAt') DESC LIMIT ? OFFSET ?").all(limit, offset).map(row => JSON.parse(String(row.json)) as AssistanceRecord),
      total: Number(this.options.store.db.prepare("SELECT count(*) AS n FROM assistance_records").get()!.n)
    };
  }
  private expire(): void {
    for (const [id, grant] of this.grants) if (Date.now() >= grant.expiresAt) {
      this.grants.delete(id);
      const record = this.get(grant.recordId);
      if (record.status === "fill_intent") { record.status = "manual_required"; record.blockers = ["Fill report was not received. Inspect the page before continuing; not counted as submitted."]; this.save(record); }
    }
  }
  get(id: string): AssistanceRecord {
    if (this.closed) throw new Error("The assistance service is closed.");
    const row = this.options.store.db.prepare("SELECT json FROM assistance_records WHERE id=?").get(id);
    if (!row) throw new Error("Assistance record not found.");
    return JSON.parse(String(row.json)) as AssistanceRecord;
  }
  private save(record: AssistanceRecord): void {
    record.updatedAt = new Date().toISOString();
    this.options.store.db.prepare("INSERT INTO assistance_records VALUES (?,?) ON CONFLICT(id) DO UPDATE SET json=excluded.json").run(record.id, JSON.stringify(record));
  }
  private validatePage(input: AssistancePage): AssistancePage {
    const page = pageSchema.parse(input);
    assistanceDestination(page.url);
    if (page.embedded) assistanceDestination(page.embedded.url);
    if (page.url !== page.snapshot.url || page.fingerprint !== hash(assistancePagePayload(page)) || page.snapshot.fingerprint !== hash(assistanceSnapshotPayload(page.snapshot)))
      throw new Error("Page or form fingerprint changed. Inspect again.");
    if (new Set(page.snapshot.fields.map(field => field.key)).size !== page.snapshot.fields.length
      || page.snapshot.fields.some(field => !ASSIST_KEY.test(field.key) || unsafeField(field)
        || !["text", "email", "tel", "url", "number", "date", "textarea", "select", "radio", "combobox", "checkbox", "file"].includes(field.type))
      || page.occupied.some(key => !page.snapshot.fields.some(field => field.key === key))) throw new Error("Unsupported or sensitive page field metadata.");
    if (page.job && hasNoAiRestriction(page.job.description)) throw new Error("This posting prohibits AI assistance. Continue manually.");
    return page;
  }
  private job(record: AssistanceRecord, page?: AssistancePage): Job {
    const job = this.options.store.job(record.jobId);
    if (!job) throw new Error("The imported job no longer exists.");
    assistanceDestination(job.applyUrl);
    if (page) {
      this.validatePage(page);
      if (new URL(page.url).origin !== new URL(record.sourceUrl).origin) throw new Error("The application changed origin. Plan the destination page separately.");
      if (page.job && (normalizeSpace(page.job.title) !== normalizeSpace(job.title) || normalizeSpace(page.job.description) !== normalizeSpace(job.description)))
        throw new Error("This page has a different job or changed description. Import it again instead of using a stale packet.");
    }
    return job;
  }
  private assertMutable(record: AssistanceRecord): void {
    if (["submitted_confirmed", "submission_unknown", "fill_intent", "queued", "abandoned"].includes(record.status))
      throw new Error("Resolve the existing assistance state before preparing or filling again.");
    if (this.options.store.hasConflictingApplication(record.jobId)) throw new Error("This job already has a submitted or unresolved application.");
  }
  private recordForJob(job: Job, url: string, blockers: string[]): AssistanceRecord {
    const old = this.options.store.db.prepare("SELECT json FROM assistance_records WHERE json_extract(json,'$.jobId')=?").get(job.id);
    if (old) return JSON.parse(String(old.json)) as AssistanceRecord;
    const now = new Date().toISOString();
    const record: AssistanceRecord = { id: randomUUID(), jobId: job.id, sourceUrl: url, company: job.company, title: job.title, portal: new URL(url).hostname,
      status: "detected", notes: "", blockers, createdAt: now, updatedAt: now };
    this.save(record);
    return record;
  }
  /**
   * A tab opened for a role in your application session: its record is that role's, on whichever page of the application
   * the tab now is (sign-in redirects, another ATS the posting hands over to). Only roles in the running session bind this way.
   */
  private recordForSessionJob(jobId: string, page: AssistancePage, log: Log): AssistanceRecord | undefined {
    const job = this.options.store.job(jobId);
    if (!job || !this.options.sessions?.driven(jobId)) return undefined;
    const record = this.recordForJob(job, page.url.replace(/#.*$/, ""), page.blockers);
    const url = new URL(page.url);
    if (new URL(record.sourceUrl).origin !== url.origin && !["submitted_confirmed", "submission_unknown", "fill_intent", "queued"].includes(record.status)) {
      record.sourceUrl = page.url.replace(/#.*$/, ""); record.portal = url.hostname; record.updatedAt = new Date().toISOString(); this.save(record);
      log("record", `session role now continues on ${url.hostname}`);
    }
    log("record", `session role ${job.company}: ${job.title} (${record.status})`);
    return record;
  }
  /**
   * The employer's "application received" page, seen in the tab you applied in. This is the proof that makes a role
   * "Applied"; it must come from the application's own site and use submission wording.
   */
  outcome(id: string, input: { url: string; text: string }): AssistanceRecord {
    const record = this.get(id);
    if (record.status === "queued") throw new Error("The dedicated runner owns this job; its own receipt decides the outcome.");
    // The same destination rules as every assisted page (HTTPS employer pages; never sign-in or account pages).
    const url = assistanceDestination(input.url), text = normalizeSpace(input.text).slice(0, 240);
    url.hash = "";
    if (!CONFIRMATION_TEXT.test(text)) throw new Error("That text does not confirm a submitted application.");
    const site = (host: string) => host.split(".").slice(-2).join(".");
    if (url.hostname !== new URL(record.sourceUrl).hostname && site(url.hostname) !== site(new URL(record.sourceUrl).hostname))
      throw new Error("The confirmation came from a different site than the application.");
    const at = new Date().toISOString();
    const detail = `The ${url.hostname} page said "${text}" right after you submitted it in Chrome.`;
    this.options.progress?.recordEvidence(record.jobId, { kind: "confirmation_page", at, detail, url: `${url.origin}${url.pathname}` });
    if (record.status !== "submitted_confirmed") {
      Object.assign(record, { status: "submitted_confirmed", submittedAt: at.slice(0, 10), confirmation: text, updatedAt: at, stage: { name: "submitted", detail, at } });
      delete record.repairs;
      this.save(record);
      this.options.store.event(record.packetId ?? record.id, "assist_confirmation_page", detail.slice(0, 500));
    }
    try { this.options.sessions?.update(record.jobId, "submitted", "Applied: the confirmation page was seen."); } catch { /* Not a session role. */ }
    return record;
  }
  /** Where the extension left this application (filling, waiting for you, ready for your review); mirrored into the session. */
  stage(id: string, input: { stage: "working" | "needs_you" | "review"; detail: string }): AssistanceRecord {
    const record = this.get(id);
    if (record.status === "submitted_confirmed") return record;
    record.stage = { name: input.stage, detail: normalizeSpace(input.detail).slice(0, 300), at: new Date().toISOString() };
    this.save(record);
    try { this.options.sessions?.update(record.jobId, input.stage, record.stage.detail); } catch { /* Not a session role. */ }
    return record;
  }
  /**
   * The tracked application for a page: the current record for same-site steps of one application, otherwise the job
   * identified by this page (created from public page metadata when it has no job description).
   */
  private recordFor(page: AssistancePage, id?: string, log: Log = quiet): AssistanceRecord {
    if (id) {
      const row = this.options.store.db.prepare("SELECT json FROM assistance_records WHERE id=?").get(id);
      const current = row ? JSON.parse(String(row.json)) as AssistanceRecord : undefined;
      const job = current ? this.options.store.job(current.jobId) : undefined;
      const withoutHash = (value: string) => value.replace(/#.*$/, "");
      const terminal = !!current && ["submitted_confirmed", "submission_unknown", "abandoned", "queued"].includes(current.status);
      // A finished application is shown again only on its own page; it never captures a different job on the same site.
      if (current && job && sameApplication(current.sourceUrl, page.url) && !(page.job && normalizeSpace(page.job.title) !== normalizeSpace(job.title))
        && (!terminal || withoutHash(page.url) === withoutHash(current.sourceUrl))) { log("record", `continuing the current application (${current.company}: ${current.title}, ${current.status})`); return current; }
      if (current) log("record", `not continuing ${current.company}: ${current.title} (${!sameApplication(current.sourceUrl, page.url) ? "different application URL" : terminal ? `finished as ${current.status}` : "different job on this page"})`);
    }
    const url = new URL(page.url); url.hash = "";
    const captured = page.job;
    const candidate: Job = { id: randomUUID(), sourceId: "extension", sourceJobId: hash(url.href), title: normalizeSpace(captured?.title || page.title || url.hostname).slice(0, 300),
      company: normalizeSpace(captured?.company || companyFromUrl(url)).slice(0, 300), location: captured?.location ?? "", remote: /\bremote\b/i.test(captured?.location ?? ""),
      countries: [], employmentType: "unknown", description: captured?.description ?? "", applyUrl: url.href, canonicalUrl: url.href,
      fetchedAt: new Date().toISOString(), salary: null, language: null, sponsorship: "unknown", aiPolicy: "unknown", status: "open" };
    const existing = this.options.store.db.prepare("SELECT json FROM jobs WHERE identity=?").get(jobIdentity(candidate));
    const job = existing ? JSON.parse(String(existing.json)) as Job : this.options.store.saveJob(candidate);
    const record = this.recordForJob(job, url.href, page.blockers);
    log("record", `${existing ? "existing" : "new"} job "${job.title}" at ${job.company}${captured ? " (from the page's job description)" : " (from page metadata; no job description captured)"}`);
    return record;
  }
  import(pageInput: AssistancePage, company?: string): AssistanceReview {
    const page = this.validatePage(pageInput), captured = page.job;
    if (!captured || page.kind !== "job") throw new Error("No actual job description was captured. Open an individual public job, not a listing or sign-in page.");
    const organization = company?.trim() || captured.company;
    if (!organization || !captured.title.trim()) throw new Error("Confirm the employer name and job title before importing.");
    const job: Job = { id: randomUUID(), sourceId: "extension", sourceJobId: hash(page.url), title: captured.title, company: organization,
      location: captured.location, remote: /\bremote\b/i.test(captured.location), countries: [], employmentType: "unknown",
      description: captured.description, applyUrl: page.url, canonicalUrl: page.url, fetchedAt: new Date().toISOString(),
      salary: null, language: null, sponsorship: "unknown", aiPolicy: "unknown", status: "open" };
    const existing = this.options.store.db.prepare("SELECT json FROM jobs WHERE identity=?").get(jobIdentity(job));
    const prior = existing ? JSON.parse(String(existing.json)) as Job : undefined;
    if (prior && this.options.store.hasConflictingApplication(prior.id)) throw new Error("This job already has a submitted or unresolved application. Reconcile it in the homepage.");
    // Do not mutate provenance beneath existing prepared/submitted packets.
    if (prior && normalizeSpace(prior.description) !== normalizeSpace(job.description) && this.options.store.packetsForJob(prior.id).length)
      throw new Error("This job's description changed. Refresh/reconcile its existing packets in the homepage before importing again.");
    const saved = prior ? normalizeSpace(prior.description) === normalizeSpace(job.description) ? prior
      : this.options.store.saveJob({ ...prior, description: job.description, title: job.title, company: organization, fetchedAt: job.fetchedAt })
      : this.options.store.saveJob(job);
    const record = this.recordForJob(saved, page.url, page.blockers);
    return this.review(record.id, page);
  }
  private profileForAnswers(): Profile {
    const profile = structuredClone(this.options.store.profile());
    const current = profile.facts.filter(fact => fact.confirmed && fact.category === "experience" && /\bpresent|current\b/i.test(fact.dates ?? ""));
    const education = profile.facts.filter(fact => fact.confirmed && fact.category === "education");
    const dateLike = /^(?:(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?|\d{1,2}[/-]\d{2,4}|(?:19|20)\d{2}|present|current)(?:[\s,/-]+(?:(?:19|20)\d{2}|present|current))*$/i;
    const add = (names: string[], values: (string | undefined)[]) => {
      const unique = [...new Set(values.map(value => value?.replace(/\s+/g, " ").trim()).filter((value): value is string => !!value && !dateLike.test(value)))];
      if (unique.length === 1) for (const name of names) if (!Object.hasOwn(profile.answers, name)) profile.answers[name] = unique[0];
    };
    add(["Current employer", "Current company"], current.map(fact => fact.employer));
    add(["Current job title"], current.map(fact => fact.role));
    add(["School", "University", "Institution"], education.map(fact => fact.employer));
    add(["Degree"], education.map(fact => fact.role));
    add(["Education summary"], education.map(fact => fact.text));
    return profile;
  }
  /** Profile answers plus exact questions you explicitly chose to remember; your saved profile answers always win. */
  private answerProfile(): { profile: Profile; remembered: Set<string> } {
    const profile = this.profileForAnswers(), remembered = new Set<string>();
    const taken = new Set(Object.keys(profile.answers).map(normalizeQuestion));
    for (const entry of Object.values(this.rememberedStore())) {
      const normalized = normalizeQuestion(entry.question);
      if (!normalized || taken.has(normalized)) continue;
      profile.answers[entry.question] = entry.value; remembered.add(entry.question); taken.add(normalized);
    }
    return { profile, remembered };
  }
  review(id: string, input: AssistancePage): AssistanceReview {
    this.expire();
    const record = this.get(id), page = this.validatePage(input), job = this.job(record, page);
    const { profile } = this.answerProfile();
    const snapshot = { ...page.snapshot, fields: page.snapshot.fields.filter(field => !page.occupied.includes(field.key)) };
    const plan = resolveAnswers(profile, job, snapshot);
    const fields = Object.fromEntries(Object.entries(plan.answers).filter(([key]) => snapshot.fields.some(field => field.key === key && !unsafeField(field))));
    const choice = this.options.library.choose(job);
    return { record, ...(record.packetId ? { packet: this.options.engine.get(record.packetId) } : {}),
      variants: this.options.library.approvedVariants(), suggestedVariantId: choice?.variant.id, suggestion: choice?.reason,
      factOptions: profile.facts.filter(fact => fact.confirmed).map(fact => ({ id: fact.id, text: fact.text, category: fact.category })),
      skillOptions: analyzeKeywords({ ...profile, facts: [] }, job).supported.flatMap(item => item.sourceSkills),
      fields, blockers: [...new Set([...page.blockers, ...plan.blockers, ...plan.missing])] };
  }

  private resolveAs(field: FormField, label: string, profile: Profile, job: Job): string | undefined {
    const synthetic: FormField = { ...field, label, type: field.type === "combobox" && !field.options.length ? "text" : field.type };
    return resolveAnswers(profile, job, { url: "", fields: [synthetic], fingerprint: "", hasCaptcha: false, hasLegal: false, unsupported: [] },
      { fuzzyOptions: true, ...profileResolveOptions(this.options.store.profile()) }).answers[field.key];
  }
  private catalog(profile: Profile, job: Job): CatalogEntry[] {
    const bank = Object.keys(profile.answers);
    const entries: CatalogEntry[] = [
      ...STATIC_KEYS.map(entry => ({ ...entry, hasValue: false })),
      ...bank.filter(key => /^years_[a-z0-9_]+$/.test(key) && questionKey(key) === key)
        .map(key => ({ key, meaning: `years of experience with ${key.slice(6).replace(/_/g, " ")}`, label: key, hasValue: false })),
      ...bank.filter(key => /^expected_salary_[A-Z]{3}(?:_(?:annual|monthly|hourly))?$/.test(key)).map(key => {
        const [, currency, period] = key.match(/^expected_salary_([A-Z]{3})(?:_(annual|monthly|hourly))?$/)!;
        return { key, meaning: `expected salary in ${currency}${period ? `, ${period}` : ", period not stated"}`, label: key, hasValue: false };
      }),
      ...Object.entries(profile.links).filter(([name, url]) => url && !/linkedin|github/i.test(name)).slice(0, 10)
        .map(([name, url]) => ({ key: `link:${name.slice(0, 60)}`, meaning: `${name} link`, label: "", hasValue: true, link: url })),
    ];
    const probe: FormField = { key: "probe", label: "", type: "text", required: false, options: [] };
    for (const entry of entries) if (!entry.link) entry.hasValue = this.resolveAs(probe, entry.label, profile, job) !== undefined;
    return entries;
  }
  private catalogValue(entry: CatalogEntry, field: FormField, profile: Profile, job: Job): string | undefined {
    if (entry.link) return !field.options.length && ["text", "url", "textarea"].includes(field.type) ? entry.link : undefined;
    const value = this.resolveAs(field, entry.label, profile, job);
    // A bare day count is ambiguous in an open text box; say what it means.
    if (value && entry.key === "notice_period_days" && ["text", "textarea"].includes(field.type) && /^\d+$/.test(value)) return `${value} days`;
    return value;
  }
  private deterministicExtra(field: FormField, profile: Profile, job: Job): Pick<AssistPlanItem, "value" | "display" | "source" | "detail"> | undefined {
    const meaning = autocompleteMeaning(field.autocomplete);
    const entry = meaning ? STATIC_KEYS.find(item => item.key === meaning) : undefined;
    if (entry) {
      const value = this.resolveAs(field, entry.label, profile, job);
      if (value !== undefined) return { value, display: displayOf(field, value), source: "profile", detail: `Matched by the site's autocomplete="${field.autocomplete}" attribute.` };
    }
    if (field.options.length || !["text", "url", "textarea"].includes(field.type)) return undefined;
    const label = normalizeText(field.label);
    if (field.type !== "url" && !/\b(?:url|link|profile|website|site|portfolio|page|handle)\b/.test(label)) return undefined;
    const links = Object.entries(profile.links).filter(([name, url]) => url && normalizeText(name).length >= 3 && label.includes(normalizeText(name)));
    return links.length === 1 ? { value: links[0][1], display: links[0][1], source: "profile", detail: `Your saved ${links[0][0]} link.` } : undefined;
  }
  private fromDecision(field: FormField, base: AssistPlanItem, decision: AiDecision, catalog: CatalogEntry[], profile: Profile, job: Job): AssistPlanItem {
    const manual = (reason: string): AssistPlanItem => ({ ...base, source: "manual", review: false, include: false, reason });
    const facts = (ids: string[]) => ids.map(id => profile.facts.find(fact => fact.id === id)).filter((fact): fact is Fact => !!fact);
    if (decision.decision === "answer_key") {
      const entry = catalog.find(item => item.key === decision.answerKey);
      if (!entry) return manual("The AI suggestion referred to an unknown saved answer.");
      if (!unitsCompatible(field.label, entry.key)) return manual(`The question's units differ from your saved "${entry.key}" answer; answer it yourself.`);
      const value = this.catalogValue(entry, field, profile, job);
      if (value === undefined) return manual(entry.hasValue ? `Your saved "${entry.key}" answer does not match this question's options.`
        : `This asks for "${entry.key}", which you have not saved. Add it in Profile → Application answers to reuse it everywhere.`);
      return { ...base, value, display: displayOf(field, value), source: "ai_mapped", detail: `AI matched this question to your saved "${entry.key}" answer.`, review: true, include: true };
    }
    if (decision.decision === "option") {
      const value = field.options.find(option => (field.optionLabels?.[option] ?? option) === decision.option);
      if (value === undefined) return manual("The AI choice is no longer listed.");
      return { ...base, value, display: decision.option, source: "ai_option", detail: `AI choice based on: ${factSummary(facts(decision.factIds))}.`, review: true, include: true };
    }
    if (decision.decision === "draft")
      return { ...base, value: decision.text, display: decision.text, source: "ai_draft", detail: `AI draft from your confirmed facts: ${factSummary(facts(decision.factIds))}. Edit it so it reads as yours.`, review: true, include: true };
    return manual(decision.reason.startsWith("Rejected: ") ? `AI suggestion not used: ${decision.reason.slice(10)}` : decision.reason);
  }
  private resumeChoices(record: AssistanceRecord, job: Job, page: AssistancePage): AssistPlan["resume"] {
    const uploads = page.snapshot.fields.filter(item => item.type === "file");
    const field = uploads.find(item => item.required) ?? uploads[0];
    if (!field) return undefined;
    const accept = field.accept ?? [];
    const accepts = (format: "pdf" | "docx") => !accept.length || accept.some(value => [`.${format}`,
      format === "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/*", "*/*"].includes(value.toLowerCase()));
    const options: AssistResumeOption[] = [];
    const notes: string[] = [];
    if (record.packetId) {
      try {
        const packet = this.options.engine.get(record.packetId);
        this.options.engine.validate(packet);
        if (!this.options.library.approvedVariants().some(variant => variant.id === packet.variantId && variant.artifact.sha256 === packet.tailoring?.baseVariantSha256))
          throw new Error("baseline changed");
        for (const artifact of packet.artifacts.filter(item => accepts(item.format)).sort((a, b) => a.format.localeCompare(b.format) * -1))
          options.push({ id: `packet:${packet.id}:${artifact.format}`, label: `Tailored for this job (${artifact.format.toUpperCase()})`, format: artifact.format, sha256: artifact.sha256, source: "packet" });
      } catch { notes.push("The tailored resume is out of date; prepare it again under More to use it."); }
    }
    for (const variant of this.options.library.approvedVariants().filter(item => accepts(item.artifact.format)))
      options.push({ id: `variant:${variant.id}`, label: `${variant.label} (${variant.artifact.format.toUpperCase()}, approved original)`, format: variant.artifact.format, sha256: variant.artifact.sha256, source: "baseline" });
    // The resume slot you assigned to this role's family (Progress → Role families) comes first.
    const families = this.options.families;
    const slots = Object.fromEntries((families?.list() ?? []).filter(family => family.resumeSlot).map(family => [family.id, family.resumeSlot!]));
    const suggested = this.options.library.choose(job, page.snapshot, families?.classify(job), slots)?.variant.id;
    const attached = page.occupied.includes(field.key);
    const selected = attached ? undefined : options.find(option => option.source === "packet")?.id ?? options.find(option => option.id === `variant:${suggested}`)?.id ?? options[0]?.id;
    if (attached) notes.push("A file is already attached on the page; Chairman keeps it.");
    return { key: field.key, label: field.label, required: field.required, options, ...(selected ? { selected } : {}),
      ...(!options.length ? { reason: accept.length ? "This upload does not accept PDF or DOCX; upload yourself." : "Approve a resume in the homepage (Resumes) to attach it here." }
        : notes.length ? { reason: notes.join(" ") } : {}) };
  }

  private async buildPlan(record: AssistanceRecord, job: Job, page: AssistancePage, aiMode: "ask" | "cache-only" | "off", log: Log = quiet): Promise<AssistPlan> {
    const { profile, remembered } = this.answerProfile();
    const saved = this.options.store.profile();
    const fields = page.snapshot.fields, occupied = new Set(page.occupied);
    // The plan never depends on which fields currently hold values, so typing or attaching after review keeps it valid;
    // occupied fields are simply kept by the page.
    const repairs = record.lastFill?.url === page.url ? (record.repairs ?? []).filter(repair => fields.some(field => field.key === repair.key)) : [];
    const repairFor = new Map(repairs.map(repair => [repair.key, repair]));
    const pending = fields.filter(field => field.type !== "file" && !repairFor.has(field.key));
    const deterministic = resolveAnswers(profile, job, { ...page.snapshot, hasCaptcha: false, hasLegal: false, unsupported: [],
      fields: pending.map(field => field.type === "combobox" && !field.options.length ? { ...field, type: "text" } : field) },
      { fuzzyOptions: true, provenance: true, ...profileResolveOptions(saved) });
    log("page", `${fields.length} questions, ${occupied.size} already answered on the page, ${repairs.length} pending fixes, ${fields.some(field => field.type === "file") ? "has" : "no"} upload field`);
    if (!profile.confirmed) log("profile", "profile is not confirmed; answers cannot be planned", false);
    const items = new Map<string, AssistPlanItem>(), unknown: FormField[] = [];
    const base = (field: FormField): AssistPlanItem => ({ key: field.key, label: field.label, type: field.type, required: field.required, source: "manual",
      review: false, include: false, ...(optionItems(field) ? { options: optionItems(field) } : {}), ...(field.maxLength ? { maxLength: field.maxLength } : {}) });
    for (const field of pending) {
      const value = deterministic.answers[field.key];
      if (value !== undefined) {
        const source = deterministic.sources?.[field.key] ?? "profile";
        if (source === "acknowledgement:auto" || source === "marketing:declined") {
          items.set(field.key, { ...base(field), value, display: displayOf(field, value), source: "acknowledgement", include: true, review: true,
            detail: source === "marketing:declined" ? "Optional marketing consent declined for you (Profile → marketing_opt_in changes this)."
              : "Required acknowledgement accepted in your name because Profile → Accept required acknowledgements is on. Untick to handle it yourself." });
          continue;
        }
        const bankKey = source.startsWith("answers:") ? source.slice(8) : undefined;
        const kind = bankKey && remembered.has(bankKey) ? "remembered" : bankKey && !(DERIVED_ANSWERS.includes(bankKey) && !Object.hasOwn(saved.answers, bankKey)) ? "answers" : "profile";
        items.set(field.key, { ...base(field), value, display: displayOf(field, value), source: kind, include: true,
          detail: kind === "remembered" ? "Answer you chose to remember from an earlier form." : kind === "answers" ? `Your saved answer "${bankKey}".`
            : bankKey ? `From your confirmed facts (${bankKey.toLowerCase()}).`
              : source.startsWith("derived:") ? `Worked out from ${source.slice(8)}. Save your own answer in Profile to change it.`
                : `From your profile (${source.slice(8) || "contact details"}).` });
        continue;
      }
      if (field.sensitivity) {
        const preferences = saved.preferences;
        items.set(field.key, { ...base(field), reason: field.sensitivity === "disclosure"
          ? preferences.fillVoluntaryDisclosures ? "Voluntary disclosure with no saved answer that fits. Add it in Profile → Voluntary disclosures, or answer it yourself."
            : "Voluntary disclosure. Answer it yourself, or save your answers in Profile → Voluntary disclosures and turn on filling them."
          : !field.required ? "Optional consent or opt-in; Chairman leaves it for you."
            : preferences.acceptRequiredAcknowledgements ? "Chairman found no single \"I agree\" choice here; answer it yourself."
              : "Consent or acknowledgement. Tick it yourself, or turn on \"Accept required acknowledgements\" in Profile." });
        continue;
      }
      const problem = messageFor(deterministic, field.key);
      const known = questionKey(field.label, job.company);
      // Narrative keys without your template are exactly what drafting is for; factual keys need your saved answer.
      const narrative = known === "cover_letter" || known === "motivation", grounded = factGrounded(known);
      if (problem && !problem.startsWith("Add an explicit approved answer")) { items.set(field.key, { ...base(field), reason: problem }); continue; }
      const extra = this.deterministicExtra(field, profile, job);
      if (extra) { items.set(field.key, { ...base(field), ...extra, include: true }); continue; }
      // An optional question without an answer is left blank (AI may still draft one); it never blocks the next step.
      items.set(field.key, { ...base(field), reason: (field.required ? "" : "Optional; left blank unless you answer it. ") + (narrative ? `Write your own answer here, or save a ${known}_template in Profile → Application answers.`
        : known ? `No saved "${known}" answer. Add it in Profile → Application answers to reuse it everywhere${grounded ? ", or plan with AI help to match it to your confirmed facts" : ""}.`
          : ["text", "textarea"].includes(field.type) && !aiExcluded.test(field.label) ? "No saved answer matches this question. Type your own, or plan with AI help to draft one from your confirmed facts."
            : "No saved answer matches this question.") });
      if ((!known || narrative || grounded) && !aiExcluded.test(field.label)) unknown.push(field);
    }
    const counts = [...items.values()].reduce<Record<string, number>>((all, item) => ({ ...all, [item.value !== undefined ? item.source : "no answer"]: (all[item.value !== undefined ? item.source : "no answer"] ?? 0) + 1 }), {});
    log("saved-answers", Object.entries(counts).map(([source, count]) => `${source}: ${count}`).join(", ") || "no questions");
    if (unknown.length) log("unknown", `${unknown.length} without a saved answer: ${unknown.map(field => field.label).join(" | ")}`);
    const noAi = job.aiPolicy === "prohibited" || hasNoAiRestriction(`${job.title}\n${job.description}`);
    const ai: AssistPlan["ai"] = { enabled: aiMode === "ask", available: false, asked: 0, cached: 0 };
    if (aiMode !== "off" && unknown.length && profile.confirmed && !noAi) {
      const catalog = this.catalog(profile, job);
      const questions: AiQuestion[] = unknown.map(field => ({ key: field.key, label: field.label, type: field.type,
        options: field.options.map(value => field.optionLabels?.[value] ?? value), ...(field.maxLength ? { maxLength: field.maxLength } : {}),
        ...(field.hint ? { hint: field.hint } : {}), ...(field.placeholder ? { placeholder: field.placeholder } : {}) }));
      const run = await this.intelligence.decide({ profile, job, questions, catalog, askable: new Set(unknown.filter(field => !occupied.has(field.key)).map(field => field.key)) },
        aiMode === "ask" ? "ask" : "cache-only");
      for (const [key, decision] of run.decisions) {
        const field = unknown.find(item => item.key === key)!;
        items.set(key, this.fromDecision(field, items.get(key)!, decision, catalog, profile, job));
      }
      Object.assign(ai, { available: run.status?.available ?? run.cached > 0, asked: run.asked, cached: run.cached,
        ...(run.status ? { provider: run.status.provider, model: run.status.model, remote: run.status.remote } : {}),
        ...(run.error ? { reason: run.error } : run.status && !run.status.available ? { reason: run.status.reason } : {}) });
      log("ai", `${aiMode}: ${run.status ? `${run.status.provider}${run.status.model ? ` ${run.status.model}` : ""} ${run.status.available ? "available" : "unavailable"}; ` : ""}asked ${run.asked}, reused ${run.cached}${ai.reason ? `; ${ai.reason}` : ""}`, !run.error && (run.status?.available ?? true));
      for (const [key, decision] of run.decisions) {
        const label = unknown.find(field => field.key === key)?.label ?? key, planned = items.get(key)!;
        log("ai-decision", `${label}: ${decision.decision}${planned.value !== undefined ? ` → ${planned.source}` : planned.reason ? ` → needs you (${planned.reason})` : ""}`, planned.value !== undefined || decision.decision === "manual" && !decision.reason.startsWith("Rejected:"));
      }
    } else if (aiMode !== "off" && unknown.length) {
      ai.reason = noAi ? "This job restricts AI assistance, so no AI suggestions are made." : "Confirm your profile before AI suggestions are made.";
      log("ai", ai.reason, false);
    } else log("ai", aiMode === "off" ? "AI help is off for this plan" : "not needed");
    for (const repair of repairs) {
      const field = fields.find(item => item.key === repair.key)!;
      items.set(repair.key, { ...base(field), ...(repair.value ? { value: repair.value, display: repair.display ?? displayOf(field, repair.value) } : {}),
        ...(repair.options?.length ? { options: repair.options.map(label => ({ value: label, label })) } : {}),
        source: "repair", detail: repair.reason, review: true, include: !!repair.value, ...(record.lastFill?.values[repair.key] ? { overwrite: true } : {}) });
    }
    for (const item of items.values()) {
      if (item.value === undefined || item.source === "repair") continue;
      const field = fields.find(entry => entry.key === item.key)!;
      if (/^\d{4}-\d{2}-\d{2}$/.test(item.value) && field.type !== "date" && field.placeholder) {
        const formatted = formatDateLike(item.value, field.placeholder);
        if (formatted) { item.value = item.display = formatted; item.detail = `${item.detail ?? ""} Formatted as ${field.placeholder}.`.trim(); }
      }
      const adapted = ["text", "tel", "url", "email", "number"].includes(field.type) ? adaptToField(item.value, field) : undefined;
      if (adapted) { item.value = item.display = adapted.value; item.detail = `${item.detail ?? ""} ${adapted.reason}`.trim(); }
      if (field.maxLength && item.value.length > field.maxLength) {
        item.include = false; item.review = true;
        item.reason = `Longer than this field's ${field.maxLength}-character limit; shorten it before filling.`;
      }
    }
    for (const field of fields) if (occupied.has(field.key) && field.type !== "file" && !repairFor.has(field.key))
      Object.assign(items.get(field.key)!, { include: false, review: false, reason: "Already answered on the page; kept as is." });
    const ordered = fields.filter(field => items.has(field.key)).map(field => items.get(field.key)!);
    const unanswered = fields.filter(field => field.type !== "file" && !field.sensitivity && !occupied.has(field.key) && items.get(field.key)?.value === undefined);
    if (unanswered.length && this.options.inbox) log("inbox", `${this.options.inbox.harvest(unanswered, job.company)} new question(s) saved for you to answer in Profile → Standard application questions`);
    const resume = this.resumeChoices(record, job, page);
    const blockers = [...page.blockers];
    if (!profile.confirmed) blockers.unshift("Confirm your profile in the homepage (Profile) before Chairman plans answers.");
    if (this.options.store.hasConflictingApplication(record.jobId)) blockers.unshift("This job already has a submitted or unresolved application. Reconcile it in the homepage.");
    else if (["submitted_confirmed", "submission_unknown", "queued", "abandoned"].includes(record.status)) blockers.unshift("This application's tracked state no longer allows filling. Review it in the homepage.");
    if (this.options.store.value("stopped", false)) blockers.unshift("The global queue is stopped. Resume it in the homepage before filling.");
    if (!fields.length && !page.embedded) blockers.push("No fillable application questions were found. Open the application form (for example with Apply), then plan again.");
    if (noAi) blockers.push("This job restricts AI-generated material; only your own saved answers are proposed.");
    const planHash = hash(canonicalJson({ v: 1, recordId: record.id, url: page.url, page: page.fingerprint,
      items: ordered.filter(item => item.value !== undefined).map(item => ({ key: item.key, value: item.value, source: item.source, overwrite: !!item.overwrite })),
      resume: resume ? { key: resume.key, options: resume.options.map(option => [option.id, option.sha256]) } : null }));
    this.recentPlans.delete(planHash);
    this.recentPlans.set(planHash, { page: page.fingerprint, resume: resume?.options.map(option => option.id) ?? [],
      items: ordered.filter(item => item.value !== undefined).map(item => ({ key: item.key, label: item.label, value: item.value!, source: item.source, overwrite: !!item.overwrite })) });
    while (this.recentPlans.size > 40) this.recentPlans.delete(this.recentPlans.keys().next().value!);
    log("resume", resume ? `${resume.options.length} option(s)${resume.selected ? `, default ${resume.selected.split(":")[0]}` : ", none selected"}${resume.reason ? `; ${resume.reason}` : ""}` : "no upload field on this page");
    log("plan", `${ordered.filter(item => item.include && item.value !== undefined).length} ready, ${ordered.filter(item => item.source === "manual" && !/^Already answered/.test(item.reason ?? "")).length} need you; hash ${planHash.slice(0, 12)}`);
    return { recordId: record.id, url: page.url, pageFingerprint: page.fingerprint, items: ordered, ...(resume ? { resume } : {}),
      blockers: [...new Set(blockers)], ai, planHash };
  }

  /**
   * The dedicated runner's plan for a page it opened itself: the same scanner output, saved answers and (cached or
   * live) AI mapping as the extension, reduced to what may be sent without review. AI options/drafts need allowAi.
   */
  async autoPlan(job: Job, input: AssistancePage, options: { ai: "ask" | "cache-only" | "off"; allowAi: boolean }): Promise<PagePlan> {
    const debug: AssistDebugStep[] = [], log = debugLog(debug, "runner");
    const page = this.validatePage(input);
    const now = new Date().toISOString();
    const record = { id: `runner-${job.id}`, jobId: job.id, sourceUrl: page.url, status: "detected", createdAt: now, updatedAt: now } as unknown as AssistanceRecord;
    const plan = await this.buildPlan(record, job, page, options.ai, log);
    const unattended = new Set(["profile", "answers", "remembered", "acknowledgement", "ai_mapped", ...(options.allowAi ? ["ai_option", "ai_draft"] : [])]);
    const fill: Record<string, string> = {}, sources: Record<string, string> = {}, needs: PagePlan["needs"] = [];
    for (const item of plan.items) {
      if (page.occupied.includes(item.key)) continue;
      if (item.value !== undefined && item.include && unattended.has(item.source)) { fill[item.key] = item.value; sources[item.key] = item.source; continue; }
      if (item.required) needs.push({ key: item.key, label: item.label, required: true,
        reason: item.value !== undefined && !unattended.has(item.source) ? "AI suggested an answer; Auto Apply only sends AI answers when you allow it." : item.reason ?? "No saved answer." });
    }
    const resume = plan.resume && !page.occupied.includes(plan.resume.key) ? plan.resume.key : undefined;
    return { fill, sources, needs, ...(resume ? { resumeKey: resume } : {}), notes: [...(plan.ai.reason ? [plan.ai.reason] : [])], debug: debug.map(step => `${step.step}: ${step.detail ?? ""}`) };
  }

  /** Reviewable plan for the current page: deterministic answers first, then cached/validated AI help for what remains. */
  async plan(input: AssistancePage, options: { id?: string; ai?: boolean; jobId?: string } = {}): Promise<AssistPlan> {
    this.expire();
    const debug: AssistDebugStep[] = [], log = debugLog(debug, "plan");
    const page = this.validatePage(input);
    log("validate", `page ${new URL(page.url).host}${new URL(page.url).pathname} accepted (${page.kind})`);
    const record = (options.jobId ? this.recordForSessionJob(options.jobId, page, log) : undefined) ?? this.recordFor(page, options.id, log);
    const plan = await this.buildPlan(record, this.job(record), page, options.ai === false ? "off" : "ask", log);
    return { ...plan, debug };
  }
  private planDifference(reviewedHash: string, current: string): string {
    const before = this.recentPlans.get(reviewedHash), after = this.recentPlans.get(current);
    if (!before || !after) return "the service restarted or the plan is too old to compare";
    const changes: string[] = [];
    if (before.page !== after.page) changes.push("the page structure");
    const left = new Map(before.items.map(item => [item.key, item])), right = new Map(after.items.map(item => [item.key, item]));
    for (const [key, item] of right) {
      const old = left.get(key);
      if (!old) changes.push(`"${item.label}" now has a ${item.source} answer`);
      else if (old.value !== item.value) changes.push(`"${item.label}" answer changed`);
      else if (old.source !== item.source || old.overwrite !== item.overwrite) changes.push(`"${item.label}" source changed (${old.source} to ${item.source})`);
    }
    for (const [key, item] of left) if (!right.has(key)) changes.push(`"${item.label}" no longer has an answer (was ${item.source})`);
    if (canonicalJson(before.resume) !== canonicalJson(after.resume)) changes.push("the resume options");
    return changes.slice(0, 8).join("; ") || "an unknown difference";
  }

  private async exclusive<T>(id: string, work: (epoch: number) => Promise<T>): Promise<T> {
    if (this.busy.has(id)) throw new Error("Another operation is active for this job.");
    this.busy.add(id);
    const task = work(this.generation); this.pending.add(task);
    try { return await task; } finally { this.busy.delete(id); this.pending.delete(task); }
  }
  private active(epoch: number): void {
    if (this.closed || epoch !== this.generation) throw new Error("Assistance was cleared or stopped during this operation.");
  }
  async prepare(id: string, input: AssistancePage, variantId?: string, mode: "deterministic" | "local-ai" = "deterministic"): Promise<AssistanceReview> {
    return this.exclusive(id, async epoch => {
      const record = this.get(id); this.assertMutable(record);
      const page = this.validatePage(input), job = this.job(record, page);
      if (!job.description.trim()) throw new Error("Open the job description page and import it before tailoring a resume.");
      const choice = variantId ? this.options.library.get(variantId) : this.options.library.choose(job)?.variant;
      if (!choice || !this.options.library.approvedVariants().some(variant => variant.id === choice.id)) throw new Error("Upload and approve a valid resume in the homepage first.");
      const bytes = await this.options.library.bytes(choice.id); this.active(epoch);
      // Form structure does not change the resume, so the same job/profile/baseline reuses one immutable packet.
      const packet = await this.options.engine.prepareTailored(job.id, choice, bytes, mode, {});
      this.active(epoch);
      record.packetId = packet.id; record.status = "prepared"; record.blockers = page.blockers; this.save(record);
      return this.review(id, page);
    });
  }
  async edit(id: string, input: AssistancePage, factIds: string[], skills: string[]): Promise<AssistanceReview> {
    return this.exclusive(id, async epoch => {
      const record = this.get(id); this.assertMutable(record);
      const page = this.validatePage(input), job = this.job(record, page);
      if (!record.packetId) throw new Error("Prepare a tailored packet first.");
      const previous = this.options.engine.get(record.packetId); this.options.engine.validate(previous);
      if (!previous.tailoring) throw new Error("This editor requires a JD-tailored packet.");
      const profile = this.options.store.profile();
      const selected = addSelectedKeywords(profile, job, validateResumeSelection(profile, { factIds, skills }, "deterministic"));
      const packet: Packet = { ...structuredClone(previous), id: randomUUID(), draft: { ...selected, mode: "jd-tailored" }, artifacts: [],
        resumeContent: { name: profile.name, email: profile.email, phone: profile.phone, location: profile.location,
          links: { ...profile.links }, facts: selected.factIds.map(factId => structuredClone(profile.facts.find(fact => fact.id === factId)!)),
          skills: [...selected.skills], keywordTerms: [...selected.keywordTerms ?? []] },
        status: "prepared", createdAt: new Date().toISOString() };
      delete packet.approvedAt; delete packet.approvalHash; delete packet.approvedBy; delete packet.authorizationId;
      delete packet.submissionArtifactSha256; delete packet.workflowSteps;
      const analysis = analyzeKeywords({ ...profile, facts: packet.resumeContent!.facts, skills: packet.draft.skills }, job);
      packet.tailoring = { ...previous.tailoring, engine: "deterministic", supportedKeywords: analysis.supported.map(item => item.term),
        missingKeywords: [...analysis.gaps, ...analysis.transferable.map(item => item.term)],
        notes: ["User selected and ordered confirmed facts and skills for this job. Original templates and prior packets are unchanged."] };
      delete packet.tailoring.inference;
      try {
        packet.artifacts = await createDocuments(profile, job, selected, this.options.engine.directory(packet.id));
        this.active(epoch); this.options.engine.validate(packet);
        this.options.store.putPacket(packet); record.packetId = packet.id; record.status = "prepared"; this.save(record);
      } catch (error) { await rm(this.options.engine.directory(packet.id), { recursive: true, force: true }); throw error; }
      return this.review(id, page);
    });
  }
  async artifact(id: string, format: "pdf" | "docx"): Promise<{ filename: string; mime: string; base64: string; sha256: string }> {
    const record = this.get(id);
    if (!record.packetId) throw new Error("Prepare a packet first.");
    const packet = this.options.engine.get(record.packetId);
    this.options.engine.validate(packet); await this.options.engine.checkArtifacts(packet);
    const artifact = packet.artifacts.find(item => item.format === format);
    if (!artifact) throw new Error("This resume format is unavailable.");
    const bytes = await readFile(join(this.options.engine.directory(packet.id), artifact.filename));
    if (hash(bytes) !== artifact.sha256 || bytes.length !== artifact.bytes) throw new Error("Resume byte hash changed.");
    return { filename: artifact.filename, mime: format === "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      base64: bytes.toString("base64"), sha256: artifact.sha256 };
  }
  private async resumeBytes(optionId: string): Promise<{ filename: string; mime: string; base64: string; sha256: string }> {
    const mime = (format: string) => format === "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    const packetOption = optionId.match(/^packet:([0-9a-f-]{36}):(pdf|docx)$/);
    if (packetOption) {
      const packet = this.options.engine.get(packetOption[1]);
      this.options.engine.validate(packet); await this.options.engine.checkArtifacts(packet);
      const artifact = packet.artifacts.find(item => item.format === packetOption[2]);
      if (!artifact) throw new Error("This resume format is unavailable.");
      const bytes = await readFile(join(this.options.engine.directory(packet.id), artifact.filename));
      if (hash(bytes) !== artifact.sha256 || bytes.length !== artifact.bytes) throw new Error("Resume byte hash changed.");
      return { filename: artifact.filename, mime: mime(artifact.format), base64: bytes.toString("base64"), sha256: artifact.sha256 };
    }
    const variantOption = optionId.match(/^variant:([0-9a-f-]{36})$/);
    const variant = variantOption ? this.options.library.approvedVariants().find(item => item.id === variantOption[1]) : undefined;
    if (!variant) throw new Error("The chosen resume is no longer approved.");
    const bytes = await this.options.library.bytes(variant.id);
    const filename = /^[^/\\\x00-\x1f]{1,150}\.(pdf|docx)$/i.test(variant.originalFilename) && variant.originalFilename.toLowerCase().endsWith(`.${variant.artifact.format}`)
      ? variant.originalFilename : `resume.${variant.artifact.format}`;
    return { filename, mime: mime(variant.artifact.format), base64: bytes.toString("base64"), sha256: variant.artifact.sha256 };
  }
  /**
   * Authorizes one fill of the exact reviewed plan. The plan is recomputed from local data and cached AI decisions only
   * (never a new model call) and must hash identically; your per-field choices and edits are then bound to the grant.
   */
  async grant(id: string, input: AssistancePage, request: { planHash: string; include: string[]; edits?: Record<string, string>; resume?: string | null }): Promise<AssistanceGrant & { debug: AssistDebugStep[] }> {
    return this.exclusive(id, async epoch => {
      this.expire();
      const debug: AssistDebugStep[] = [], log = debugLog(debug, "grant");
      const record = this.get(id);
      try { this.assertMutable(record); } catch (error) { log("record", `${record.status}: ${error instanceof Error ? error.message : ""}`, false); throw error; }
      const page = this.validatePage(input);
      if (new URL(page.url).origin !== new URL(record.sourceUrl).origin) throw new Error("The application changed origin. Plan the destination page separately.");
      if (this.options.store.value("stopped", false)) throw new Error("The global queue is stopped. Resume it before transmitting data.");
      if (page.snapshot.hasCaptcha) throw new Error("A verification challenge is open. Complete it yourself, then plan again.");
      const job = this.job(record);
      const plan = await this.buildPlan(record, job, page, "cache-only");
      this.active(epoch);
      if (plan.planHash !== request.planHash) {
        const difference = this.planDifference(request.planHash, plan.planHash);
        log("plan-check", `reviewed ${request.planHash.slice(0, 12)} vs now ${plan.planHash.slice(0, 12)}: ${difference}`, false);
        throw new Error(`The plan changed after review (${difference}). Plan again and review the refreshed answers before filling.`);
      }
      log("plan-check", `reviewed plan ${plan.planHash.slice(0, 12)} still matches`);
      const used = Number(this.options.store.db.prepare("SELECT count(*) AS n FROM events WHERE type='assist_fill_intent' AND packet_id IN (?,?)").get(record.id, record.packetId ?? record.id)!.n);
      if (used >= MAX_FILLS_PER_RECORD) throw new Error(`The ${MAX_FILLS_PER_RECORD}-fill assistance budget for this application is exhausted. Continue manually.`);
      const edits = request.edits ?? {};
      const fields: Record<string, string> = {}, overwrite: Record<string, string> = {}, meta: Record<string, FormField> = {}, drafts = new Set<string>();
      for (const key of new Set(request.include)) {
        const item = plan.items.find(entry => entry.key === key), field = page.snapshot.fields.find(entry => entry.key === key);
        if (!item || !field || field.type === "file") throw new Error("The fill request contains an unknown field.");
        const value = Object.hasOwn(edits, key) ? edits[key] : item.value;
        if (value === undefined || !value.trim()) continue;
        if (value.length > 20_000 || controls.test(value.replace(/[\n\t]/g, " "))) throw new Error(`Unsupported characters or length for ${field.label}.`);
        if (unsafeField(field)) throw new Error("Sensitive questions are never filled by Chairman.");
        if (field.options.length && !field.options.includes(value)) throw new Error(`Choose one of the listed options for ${field.label}.`);
        if (field.maxLength && value.length > field.maxLength) throw new Error(`${field.label} allows at most ${field.maxLength} characters.`);
        if (page.occupied.includes(key)) {
          const previous = record.lastFill?.url === page.url ? record.lastFill.values[key] : undefined;
          if (!item.overwrite || !previous) continue;
          overwrite[key] = previous;
        }
        fields[key] = value; meta[key] = field;
        if (item.source === "ai_draft" && !Object.hasOwn(edits, key)) drafts.add(key);
      }
      if (Object.keys(edits).some(key => !plan.items.some(item => item.key === key))) throw new Error("The fill request edits an unknown field.");
      let resume: AssistanceGrant["resume"];
      if (request.resume) {
        if (!plan.resume?.options.some(option => option.id === request.resume)) throw new Error("Choose one of the listed resumes.");
        resume = { key: plan.resume.key, ...await this.resumeBytes(request.resume) };
        this.active(epoch);
      }
      log("include", `${Object.keys(fields).length} of ${new Set(request.include).size} selected fields will be filled (${Object.keys(edits).length} edited, ${Object.keys(overwrite).length} replacements)${resume ? `; resume ${request.resume!.split(":")[0]} ${resume.filename.split(".").pop()} ${Math.round(resume.base64.length * 0.75 / 1024)} KB` : ""}`);
      if (!Object.keys(fields).length && !resume) { log("include", "nothing to fill", false); throw new Error("Nothing is selected to fill. Existing answers are preserved."); }
      const packetId = request.resume?.startsWith("packet:") ? request.resume.split(":")[1] : undefined;
      const grant: AssistanceGrant = { id: randomUUID(), recordId: id, ...(packetId ? { packetId } : {}), url: page.url, pageFingerprint: page.fingerprint,
        expiresAt: Date.now() + 90_000, fields, ...(Object.keys(overwrite).length ? { overwrite } : {}), ...(resume ? { resume } : {}) };
      record.status = "fill_intent"; record.blockers = plan.blockers;
      this.options.store.transaction(() => {
        this.save(record);
        this.options.store.event(record.id, "assist_fill_intent", `Authorized filling ${Object.keys(fields).length} fields${resume ? " and one resume" : ""} only on ${page.url}; no submit permission.`);
      });
      this.grants.set(grant.id, { recordId: id, ...(packetId ? { packetId, packetHash: packetHash(this.options.engine.get(packetId)) } : {}),
        profileHash: digest(this.options.store.profile()), expiresAt: grant.expiresAt, url: page.url,
        keys: [...Object.keys(fields), ...(resume ? [resume.key] : [])], ...(resume ? { resumeKey: resume.key } : {}), values: fields, fields: meta, drafts });
      log("intent", `saved; grant expires in 90 s`);
      return { ...grant, debug };
    });
  }
  private async repairs(grant: GrantState, result: FillReport): Promise<AssistRepair[]> {
    const repairs: AssistRepair[] = [];
    const profile = this.options.store.profile(), job = this.options.store.job(this.get(grant.recordId).jobId);
    for (const error of result.errors) {
      const field = grant.fields[error.key], value = grant.values[error.key];
      if (!field || value === undefined) continue;
      if (field.type === "combobox" && error.options?.length) {
        const match = matchChoice(value, error.options.map(label => ({ value: label, label })));
        repairs.push("value" in match ? { key: error.key, value: match.label, reason: `Use the site's listed option "${match.label}".`, source: "repair" }
          : { key: error.key, value: "", options: error.options.slice(0, 50), reason: "Pick one of the options the site listed for this question.", source: "repair" });
        continue;
      }
      const adapted = adaptToField(value, field, error.message);
      if (adapted) { repairs.push({ key: error.key, value: adapted.value, reason: adapted.reason, source: "repair" }); continue; }
      const tooLong = /too long|at most|maximum|max(?:imum)? length|characters? (?:or less|max)|limit/i.test(error.message) || (!!field.maxLength && value.length > field.maxLength);
      if (grant.drafts.has(error.key) && tooLong) {
        const limit = Math.max(40, Math.min(field.maxLength ?? Math.floor(value.length * 0.7), value.length - 1));
        const shorter = await this.intelligence.shorten(value, limit, { facts: profile.facts.filter(fact => fact.confirmed), skills: profile.skills, jobTitle: job?.title ?? "" });
        if (shorter.text) repairs.push({ key: error.key, value: shorter.text, reason: `AI shortened your drafted answer to fit ${limit} characters without new facts.`, source: "ai_repair" });
      }
    }
    return repairs;
  }
  async report(id: string, grantId: string, result: FillReport): Promise<{ record: AssistanceRecord; repairs: AssistRepair[]; debug: AssistDebugStep[] }> {
    const debug: AssistDebugStep[] = [], log = debugLog(debug, "report");
    const grant = this.grants.get(grantId);
    if (!grant || grant.recordId !== id) {
      log("grant", "unknown, expired or already reported", false);
      throw new Error("Fill grant is unknown or already reported. Inspect the tracker; never infer submission.");
    }
    const reported = [...result.filled, ...result.preserved, ...result.skipped.map(item => item.key), ...result.errors.map(item => item.key), ...Object.keys(result.selected)];
    if (reported.some(key => !grant.keys.includes(key)) || Object.keys(result.selected).some(key => !result.filled.includes(key)))
      throw new Error("The fill report contains unauthorized fields.");
    this.grants.delete(grantId);
    const record = this.get(id);
    const changed = digest(this.options.store.profile()) !== grant.profileHash
      || (!!grant.packetId && packetHash(this.options.engine.get(grant.packetId)) !== grant.packetHash);
    const labels = (key: string) => grant.fields[key]?.label ?? (key === grant.resumeKey ? "Resume" : key);
    record.status = result.errors.length || result.blockers.length || changed || !result.filled.length ? "manual_required" : "filled";
    record.blockers = [...result.errors.map(error => `${labels(error.key)}: ${error.message}`), ...result.skipped.map(item => `${labels(item.key)}: ${item.reason}`),
      ...result.blockers, ...(changed ? ["Profile or resume changed during fill. Review the data already on the page."] : [])].slice(0, 150);
    const filledValues = Object.fromEntries(result.filled.filter(key => key !== grant.resumeKey && grant.fields[key])
      .map(key => [key, hash(comparableValue(grant.fields[key].type, result.selected[key] ?? grant.values[key]))]));
    record.lastFill = { url: grant.url, at: new Date().toISOString(),
      values: { ...(record.lastFill?.url === grant.url ? record.lastFill.values : {}), ...filledValues } };
    if (result.filled.length) record.filledAt = new Date().toISOString();
    log("result", `${result.filled.length} filled, ${result.preserved.length} kept, ${result.errors.length} site errors, ${result.skipped.length} skipped, ${result.newFields} new questions → ${record.status}`, !result.errors.length && !result.skipped.length);
    const repairs = await this.repairs(grant, result);
    for (const repair of repairs) log("fix", `${grant.fields[repair.key]?.label ?? repair.key}: ${repair.reason}`);
    for (const error of result.errors) if (!repairs.some(repair => repair.key === error.key))
      log("no-fix", `${grant.fields[error.key]?.label ?? (error.key === grant.resumeKey ? "Resume" : error.key)}: ${error.message}`, false);
    record.repairs = repairs;
    this.save(record);
    this.options.store.event(record.id, "assist_fill_report", `Actually filled ${result.filled.length} controls; ${result.errors.length} site errors; ${repairs.length} format fixes suggested. Final submission remains manual and unconfirmed.`);
    return { record, repairs, debug };
  }
  async recover(id: string, grantId: string): Promise<AssistanceRecord> {
    this.expire();
    if (this.grants.get(grantId)?.recordId === id)
      return (await this.report(id, grantId, { filled: [], preserved: [], skipped: [], errors: [], newFields: 0, selected: {},
        blockers: ["The extension was interrupted. Inspect all actual page values; no application receipt is implied."] })).record;
    const record = this.get(id);
    if (record.status === "fill_intent") throw new Error("Another fill is still active. Wait for its report or expiration.");
    return record;
  }

  private rememberedStore(): Remembered { return this.options.store.value<Remembered>("assistAnswers", {}); }
  rememberedAnswers(): { question: string; value: string; updatedAt: string }[] {
    return Object.values(this.rememberedStore()).sort((a, b) => a.question.localeCompare(b.question));
  }
  /** Saves answers you typed or approved for exact page questions, so the same question is answered identically next time. */
  remember(id: string, input: AssistancePage, items: { key: string; value: string }[]): number {
    this.get(id);
    const page = this.validatePage(input);
    const store = this.rememberedStore();
    let saved = 0;
    for (const item of items) {
      const field = page.snapshot.fields.find(entry => entry.key === item.key);
      if (!field || field.type === "file" || field.sensitivity || unsafeField(field) || aiExcluded.test(field.label)) throw new Error("Only ordinary, non-sensitive questions can be remembered.");
      const value = item.value.normalize("NFC");
      if (!value.trim() || value.length > 4_000 || controls.test(value.replace(/[\n\t]/g, " "))) throw new Error(`Unsupported answer for ${field.label}.`);
      if (field.options.length && !field.options.includes(value)) throw new Error(`Remember one of the listed options for ${field.label}.`);
      const normalized = normalizeQuestion(field.label);
      if (!normalized) continue;
      store[normalized] = { question: field.label, value: field.optionLabels?.[value] ?? value, updatedAt: new Date().toISOString() };
      saved++;
    }
    const entries = Object.entries(store).sort((a, b) => b[1].updatedAt.localeCompare(a[1].updatedAt)).slice(0, 500);
    this.options.store.set("assistAnswers", Object.fromEntries(entries));
    return saved;
  }
  forget(questions: string[]): number {
    const store = this.rememberedStore();
    let removed = 0;
    for (const question of questions) { const key = normalizeQuestion(question); if (Object.hasOwn(store, key)) { delete store[key]; removed++; } }
    this.options.store.set("assistAnswers", store);
    return removed;
  }

  update(id: string, input: { notes?: string; status?: "manual_required" | "filled" | "submission_unknown" | "abandoned" }): AssistanceRecord {
    const record = this.get(id);
    if (input.status && record.status === "queued") throw new Error("The dedicated runner owns this job. Reconcile it through its packet or human-intervention controls.");
    if (input.status && record.status === "submitted_confirmed") throw new Error("A confirmed receipt cannot be downgraded through an assistance note.");
    if (record.status === "fill_intent" && input.status) throw new Error("Wait for the active fill to finish or expire before changing its status.");
    if (input.notes !== undefined) record.notes = input.notes;
    if (input.status) {
      record.status = input.status;
      if (input.status === "filled" && !record.filledAt) record.filledAt = new Date().toISOString();
    }
    this.save(record); return record;
  }
  receipt(id: string, confirmation: string, submittedDate: string): AssistanceRecord {
    const record = this.get(id), job = this.job(record);
    if (record.status === "queued") throw new Error("The dedicated runner owns this job. Record/reconcile its outcome through the runner packet.");
    if (submittedDate > today()) throw new Error("An application receipt cannot be dated in the future.");
    if (record.status === "submitted_confirmed") return record;
    if (record.status === "fill_intent" || this.options.store.hasConflictingApplication(job.id)) throw new Error("Resolve the existing active, submitted or unknown application before recording a receipt.");
    this.options.store.transaction(() => {
      this.options.store.putExternal({ id: randomUUID(), jobId: job.id, sourceId: job.sourceId, submittedDate, confirmation,
        createdAt: new Date().toISOString(), progress: { stage: "applied", note: "User explicitly reported an actual submission receipt from the browser.", updatedAt: new Date().toISOString() } });
      record.status = "submitted_confirmed"; record.confirmation = confirmation; record.submittedAt = submittedDate; delete record.repairs; this.save(record);
      this.options.store.event(record.packetId ?? record.id, "assist_receipt", "User reported an actual receipt; this was not an extension auto-submission.");
    });
    return record;
  }
  queue(id: string): AssistanceRecord {
    const record = this.get(id); this.assertMutable(record);
    const job = this.job(record), autopilot = this.options.autopilot;
    if (!autopilot?.view().enabled) throw new Error("Enable the dedicated local Auto Apply runner with its own standing consent in the homepage first.");
    if (record.filledAt || record.status === "filled") throw new Error("Data was already filled in Chrome. Finish/reconcile that page manually instead of launching a duplicate runner.");
    record.status = "queued"; record.blockers = ["Queued for local runner evaluation; Chrome has not submitted anything."];
    this.options.store.transaction(() => {
      this.save(record);
      this.options.store.db.prepare("DELETE FROM autopilot_jobs WHERE job_id=? AND status NOT IN ('submitting','submitted_confirmed','submission_unknown') AND job_id NOT IN (SELECT job_id FROM runs)").run(job.id);
    });
    autopilot.kick(); return record;
  }
}

export function registerExtensionAssist(app: FastifyInstance, options: Options): ExtensionAssistService {
  const service = new ExtensionAssistService(options);
  const id = (params: unknown) => z.object({ id: idSchema }).parse(params).id;
  app.get("/api/assistance", request => {
    const query = z.object({ limit: z.coerce.number().int().min(1).max(500).default(100), offset: z.coerce.number().int().min(0).default(0) }).parse(request.query);
    return service.list(query.limit, query.offset);
  });
  const updateSchema = z.object({ notes: z.string().max(4000).optional(), status: z.enum(["manual_required", "filled", "submission_unknown", "abandoned"]).optional() }).strict();
  const receiptSchema = z.object({ confirmation: z.string().trim().min(8).max(4000), submittedDate: dateSchema, confirm: z.literal(true) }).strict();
  app.post("/api/assistance/:id", request => ({ record: service.update(id(request.params), updateSchema.parse(request.body)) }));
  app.post("/api/assistance/:id/receipt", request => { const input = receiptSchema.parse(request.body); return { record: service.receipt(id(request.params), input.confirmation, input.submittedDate) }; });
  app.get("/api/assist-answers", () => ({ items: service.rememberedAnswers() }));
  app.post("/api/assist-answers/forget", request => {
    const value = z.object({ questions: z.array(z.string().min(1).max(1000)).min(1).max(500) }).strict().parse(request.body);
    return { removed: service.forget(value.questions), items: service.rememberedAnswers() };
  });
  app.post("/api/assist-answers/clear-ai", request => {
    z.object({ confirm: z.literal(true) }).strict().parse(request.body);
    return { cleared: service.intelligence.clearCache() };
  });
  const prefix = "/api/extension/assist";
  /** Sites where your tracked companies' applications open, so the extension can ask Chrome for access to all of them at once. */
  app.post(`${prefix}/sites`, async () => {
    const hosts = new Set<string>();
    for (const row of options.store.db.prepare(`SELECT DISTINCT json_extract(j.json,'$.applyUrl') AS url FROM jobs j JOIN career_source_jobs c ON c.job_id=j.id
      WHERE json_extract(j.json,'$.status')='open' LIMIT 5000`).all()) {
      try {
        const url = new URL(String(row.url));
        if (url.protocol === "https:" && !url.port) { assistanceDestination(url.href); hosts.add(url.hostname); }
      } catch { /* Restricted or malformed destinations are never requested. */ }
    }
    return { origins: [...hosts].sort().slice(0, 120).map(host => `https://${host}/*`) };
  });
  app.post(`${prefix}/plan`, async request => {
    const value = z.object({ id: idSchema.optional(), page: pageSchema, ai: z.boolean().default(true), jobId: z.string().min(1).max(300).optional() }).strict().parse(request.body);
    return service.plan(value.page, { id: value.id, ai: value.ai, jobId: value.jobId });
  });
  app.post(`${prefix}/outcome`, request => {
    const value = z.object({ id: idSchema, url: z.string().url().max(2000), text: z.string().min(8).max(500) }).strict().parse(request.body);
    return { record: service.outcome(value.id, value) };
  });
  app.post(`${prefix}/stage`, request => {
    const value = z.object({ id: idSchema, stage: z.enum(["working", "needs_you", "review"]), detail: z.string().max(300).default("") }).strict().parse(request.body);
    return { record: service.stage(value.id, value) };
  });
  app.post(`${prefix}/import`, request => {
    const value = z.object({ page: pageSchema, company: z.string().trim().min(1).max(300).optional(), confirm: z.literal(true) }).strict().parse(request.body);
    return service.import(value.page, value.company);
  });
  app.post(`${prefix}/review`, request => { const value = withPage.parse(request.body); const review = service.review(value.id, value.page); return { ...review, packetHash: review.packet ? packetHash(review.packet) : undefined }; });
  app.post(`${prefix}/prepare`, async request => {
    const value = withPage.extend({ variantId: idSchema.optional(), mode: z.enum(["deterministic", "local-ai"]).default("deterministic"), confirm: z.literal(true) }).parse(request.body);
    return service.prepare(value.id, value.page, value.variantId, value.mode);
  });
  app.post(`${prefix}/edit`, async request => {
    const value = withPage.extend({ factIds: z.array(z.string().max(100)).min(1).max(100), skills: z.array(z.string().max(300)).max(24), confirm: z.literal(true) }).parse(request.body);
    return service.edit(value.id, value.page, value.factIds, value.skills);
  });
  app.post(`${prefix}/artifact`, request => {
    const value = z.object({ id: idSchema, format: z.enum(["pdf", "docx"]) }).strict().parse(request.body);
    return service.artifact(value.id, value.format);
  });
  app.post(`${prefix}/grant`, request => {
    const value = withPage.extend({ planHash: z.string().regex(/^[a-f0-9]{64}$/), include: z.array(keySchema).max(100),
      edits: z.record(keySchema, z.string().max(20_000)).default({}), resume: z.string().max(200).nullable().optional(), confirm: z.literal(true) }).parse(request.body);
    return service.grant(value.id, value.page, { planHash: value.planHash, include: value.include, edits: value.edits, resume: value.resume });
  });
  app.post(`${prefix}/report`, async request => {
    const value = z.object({ id: idSchema, grantId: idSchema, filled: z.array(keySchema).max(100), preserved: z.array(keySchema).max(100).default([]),
      skipped: z.array(z.object({ key: keySchema, reason: z.string().max(500) }).strict()).max(100).default([]),
      errors: z.array(z.object({ key: keySchema, message: z.string().max(500), options: z.array(z.string().max(300)).max(50).optional() }).strict()).max(100).default([]),
      newFields: z.number().int().min(0).max(1000).default(0), blockers: z.array(z.string().max(2000)).max(150), selected: z.record(keySchema, z.string().max(300)).default({})
    }).strict().parse(request.body);
    return service.report(value.id, value.grantId, value);
  });
  app.post(`${prefix}/remember`, request => {
    const value = withPage.extend({ items: z.array(z.object({ key: keySchema, value: z.string().max(4000) }).strict()).min(1).max(100), confirm: z.literal(true) }).parse(request.body);
    return { remembered: service.remember(value.id, value.page, value.items) };
  });
  app.post(`${prefix}/recover`, async request => {
    const value = z.object({ id: idSchema, grantId: idSchema }).strict().parse(request.body);
    return { record: await service.recover(value.id, value.grantId) };
  });
  app.post(`${prefix}/receipt`, request => {
    const value = receiptSchema.extend({ id: idSchema }).parse(request.body);
    return { record: service.receipt(value.id, value.confirmation, value.submittedDate) };
  });
  app.post(`${prefix}/queue`, request => {
    const value = z.object({ id: idSchema, confirm: z.literal(true) }).strict().parse(request.body);
    return { record: service.queue(value.id) };
  });
  return service;
}
