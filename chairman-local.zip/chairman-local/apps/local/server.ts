import Fastify from "fastify";
import multipart from "@fastify/multipart";
import staticFiles from "@fastify/static";
import { z, ZodError } from "zod";
import { createHash, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import { mkdir, readFile, rm } from "node:fs/promises";
import { existsSync } from "node:fs";
import { basename, extname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { Store } from "./store.js";
import { Engine, today } from "./engine.js";
import { profileSchema, answersSchema, formSchema, campaignSchema, progressSchema, dateSchema } from "./schemas.js";
import { loadPolicies } from "./policies.js";
import { digest, jobHash, matchJob, prohibitsAi } from "../../packages/domain/matching.js";
import { analyzeKeywords } from "../../packages/domain/keywords.js";
import { MAX_APPROVAL_BATCH_SIZE, type AutopilotRules, type Job, type Profile, type ReferenceResume, type Match, type KeywordAnalysis, type ExternalApplication } from "../../packages/domain/types.js";
import { importResume, getAiStatus, createReferenceDocuments } from "../../packages/documents/index.js";
import { DiscoveryService } from "./discovery-service.js";
import { campaignConfig, campaignStats } from "./campaign.js";
import { PreparationService } from "./preparation.js";
import { ResumeLibrary } from "./resume-library.js";
import { MAX_RESUME_SLOTS } from "../../packages/domain/role-families.js";
import { RoleFamilyService } from "./role-families.js";
import { QuestionInbox, registerPhase2 } from "./progress.js";
import { registerShortlist, ShortlistService } from "./shortlist.js";
import { ApplySessionService, registerApplySessions } from "./apply-sessions.js";
import type { PagePlan } from "../../packages/automation/contracts.js";
import { AutopilotService, autopilotRulesSchema, type AutopilotOptions } from "./autopilot.js";
import { CareerSourceService, type CareerOptions } from "./career-sources.js";
import { applyInferenceConfig, inferenceConfigSchema, restoreInferenceConfig } from "./inference-config.js";
import type { ServerResponse } from "node:http";
import { refreshCopilotStatus } from "../../packages/inference/index.js";
import { defaultDataDirectory } from "../../packages/platform/paths.js";
import { createGeminiKeyStore, geminiKeyRequestSchema } from "./gemini-key.js";
import { createPairingStore, hashPairingToken } from "./extension-pairing.js";
import { geminiInference, refreshGeminiStatus } from "../../packages/inference/gemini.js";
import { GmailService, registerGmail } from "./gmail.js";
import { registerExtensionAssist } from "./extension-assist.js";
import { SearchPortalService } from "./search-portals.js";
import { ApplicationTracker } from "./application-tracker.js";

const projectRoot = resolve(dirnameOf(import.meta.url), "../..");
function dirnameOf(url: string): string { return fileURLToPath(new URL(".", url)); }
const secretEqual = (a: string, b: string) => a.length === b.length && timingSafeEqual(Buffer.from(a), Buffer.from(b));
const errorText = (e: unknown) => e instanceof Error ? e.message : "An unexpected operation error occurred.";

export interface AppOptions { dataDir?: string; port?: number; fixtureMode?: boolean; policyFile?: string; autopilotOptions?: AutopilotOptions; careerOptions?: CareerOptions; }
export async function createApp(options: AppOptions = {}) {
  const port = options.port ?? Number(process.env.JAA_PORT ?? 4318);
  const origin = `http://127.0.0.1:${port}`;
  const dataDir = options.dataDir ?? process.env.JAA_DATA_DIR ?? defaultDataDirectory();
  await mkdir(dataDir, { recursive: true, mode: 0o700 });
  const geminiKeys = createGeminiKeyStore(dataDir);
  await geminiKeys.load();
  // The extension stays paired across restarts of this service (only a hash of its token is kept, in a private file).
  const pairings = createPairingStore(dataDir);
  const savedPairing = await pairings.load();
  geminiInference.setApiKeyProvider(geminiKeys.get);
  const store = new Store(join(dataDir, "assistant.sqlite"));
  const gmail = new GmailService(store, dataDir);
  try { await gmail.load(); } catch (error) { store.close(); throw error; }
  restoreInferenceConfig(store);
  store.recover();
  const fixtureMode = options.fixtureMode ?? process.env.JAA_FIXTURE_MODE === "1";
  const engine = new Engine(store, dataDir, loadPolicies(options.policyFile ?? process.env.JAA_POLICY_FILE), fixtureMode, origin);
  const preparation = new PreparationService(store, engine);
  const library = new ResumeLibrary(store, dataDir);
  const careerSources = new CareerSourceService(store, options.careerOptions);
  const discovery = new DiscoveryService(store, { cloudUrl: process.env.JAA_CLOUD_URL, cloudToken: process.env.JAA_CLOUD_TOKEN });
  const searchPortals = new SearchPortalService(store);
  const tracker = new ApplicationTracker(store);
  const families = new RoleFamilyService(store, careerSources);
  // Crawls store only roles whose title fits one of your role families; huge boards are searched with their keywords.
  careerSources.relevance = { keep: title => families.titleRelevant(title), queries: () => families.queries() };
  const inbox = new QuestionInbox(store);
  let assistanceRef: ReturnType<typeof registerExtensionAssist> | undefined;
  const autopilot: AutopilotService = new AutopilotService(store, engine, library, dataDir, { families, inbox,
    planPage: async (job, page): Promise<PagePlan> => {
      if (!assistanceRef) throw new Error("Page planning is not ready yet.");
      const rules: AutopilotRules = autopilot.rules();
      return assistanceRef.autoPlan(job, page, { ai: rules.aiAnswers === "off" ? "off" : "ask", allowAi: rules.aiAnswers === "all" });
    },
    ...options.autopilotOptions, careerSources, discover: options.autopilotOptions?.discover ?? (options.autopilotOptions?.browser ? undefined : async () => {
    careerSources.kick();
    return discovery.scanPreferred(store.profile().preferences);
  }) });
  preparation.recover();
  campaignConfig(store);
  const app = Fastify({ logger: false, bodyLimit: 2 * 1024 * 1024, requestTimeout: 120_000 });
  const session = randomBytes(32).toString("hex");
  let extensionTokenHash = savedPairing?.tokenHash ?? "", extensionOrigin = savedPairing?.origin ?? "", paired = savedPairing?.paired ?? false;
  const savePairing = () => pairings.save(extensionTokenHash ? { tokenHash: extensionTokenHash, origin: extensionOrigin, paired } : undefined).catch(() => undefined);
  let deletingData = false;
  let aiCache: Awaited<ReturnType<typeof getAiStatus>> | undefined, aiChecked = 0;
  const liveStreams = new Map<ServerResponse, ReturnType<typeof setInterval>>();
  const apiId = z.object({ id: z.string().uuid() });
  const packetId = (params: unknown) => apiId.parse(params).id;
  const rankingCache = new Map<string, { key: string; match: Match; keywords: KeywordAnalysis }>();
  const ranked = (job: Job, profile: Profile, profileHash: string) => {
    const key = `${profileHash}:${jobHash(job)}:${Boolean(job.expiresAt && Date.parse(job.expiresAt) <= Date.now())}`;
    let analysis = rankingCache.get(job.id);
    if (!analysis || analysis.key !== key) {
      analysis = { key, match: matchJob(profile, job), keywords: analyzeKeywords(profile, job) };
      if (rankingCache.size >= 5000) rankingCache.delete(rankingCache.keys().next().value!);
      rankingCache.set(job.id, analysis);
    }
    return { ...job, match: analysis.match, keywords: analysis.keywords };
  };
  const orderRanked = (a: { match: Match }, b: { match: Match }) => Number(b.match.eligible) - Number(a.match.eligible) || b.match.score - a.match.score;
  const referenceList = () => store.value<ReferenceResume[]>("referenceResumes", []);
  const referenceFamilies = z.enum(["software", "cloud", "data", "forward-deployed", "mlops", "hybrid"]);

  app.addHook("onRequest", async (request, reply) => {
    const requestOrigin = request.headers.origin;
    const pathname = request.url.split("?")[0]!;
    if (request.headers.host !== `127.0.0.1:${port}`) return reply.code(403).send({ error: "Unexpected local host." });
    if (request.headers["sec-fetch-site"] === "cross-site" && !requestOrigin?.startsWith("chrome-extension://"))
      return reply.code(403).send({ error: "Cross-site requests are not allowed." });
    if (requestOrigin && requestOrigin !== origin) {
      if (!/^chrome-extension:\/\/[a-p]{32}$/.test(requestOrigin) || (extensionOrigin && requestOrigin !== extensionOrigin))
        return reply.code(403).send({ error: "Origin is not paired with this application." });
      reply.header("Access-Control-Allow-Origin", requestOrigin).header("Vary", "Origin");
      reply.header("Access-Control-Allow-Headers", "Authorization, Content-Type");
      reply.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    }
    if (request.method === "OPTIONS") return reply.code(204).send();
    if (deletingData && request.method !== "GET") return reply.code(409).send({ error: "Local data deletion is in progress. Wait before changing the workspace." });
    reply.header("Cache-Control", "no-store").header("X-Content-Type-Options", "nosniff");
    if (!pathname.startsWith("/api/")) return;
    if (pathname === "/api/session") {
      if (requestOrigin && requestOrigin !== origin) return reply.code(403).send({ error: "Use the local dashboard to establish a session." });
      return;
    }
    if (pathname.startsWith("/api/extension/") && pathname !== "/api/extension/pair") {
      if (pathname.startsWith("/api/extension/assist/") &&
          (!paired || !extensionOrigin || requestOrigin !== extensionOrigin))
        return reply.code(403).send({ error: "Use the paired Chairman Chrome side panel for current-page assistance." });
      const token = request.headers.authorization?.replace(/^Bearer /, "") ?? "";
      if (!extensionTokenHash || !secretEqual(hashPairingToken(token), extensionTokenHash)) return reply.code(401).send({ error: "Pair the extension from the local dashboard." });
      if (requestOrigin && requestOrigin !== origin && !extensionOrigin) { extensionOrigin = requestOrigin; await savePairing(); }
      return;
    }
    if (requestOrigin && requestOrigin !== origin) return reply.code(403).send({ error: "This endpoint is dashboard-only." });
    const cookie = request.headers.cookie?.split(";").map(c => c.trim()).find(c => c.startsWith("jaa_session="))?.slice(12) ?? "";
    if (!secretEqual(cookie, session)) return reply.code(401).send({ error: "Open the local dashboard to establish a session." });
  });
  app.setErrorHandler((error, _request, reply) => {
    if (error instanceof ZodError) return reply.code(400).send({ error: error.issues.map(i => `${i.path.join(".")}: ${i.message}`).join("; ") });
    const status = typeof error === "object" && error !== null && "statusCode" in error && typeof error.statusCode === "number" ? error.statusCode : 400;
    return reply.code(status >= 400 && status < 600 ? status : 400).send({ error: errorText(error) });
  });
  await app.register(multipart, { limits: { fileSize: 10 * 1024 * 1024, files: 1, fields: 5 } });
  registerGmail(app, gmail);
  const progress = registerPhase2(app, { store, careerSources, autopilot, families, inbox });
  const shortlist = new ShortlistService(store, careerSources, families, progress, autopilot);
  registerShortlist(app, shortlist);
  const sessions = new ApplySessionService(store, shortlist);
  registerApplySessions(app, sessions);
  const assistance = assistanceRef = registerExtensionAssist(app, { store, engine, library, autopilot, inbox, families, progress, sessions });
  (await import("./inference-routes.js")).registerInferenceRoutes(app);
  app.get("/api/search-portals", async () => searchPortals.list());
  app.post("/api/search-portals", async request => searchPortals.update(request.body));
  app.get("/api/discovery/preferences", async () => discovery.preferences());
  app.post("/api/discovery/preferences", async request => {
    const result = discovery.setPreference(request.body);
    if (result.changed) autopilot.invalidate("Discovery source preferences changed. Review and re-enable automatic applications.");
    return result;
  });
  app.get("/api/tracking", async request => tracker.list(request.query));
  app.post("/api/tracking/:kind/:id/notes", async request => {
    const { kind, id } = z.object({ kind: z.string(), id: z.string() }).parse(request.params);
    return tracker.setNote(kind, id, request.body);
  });
  app.get("/api/session", async (_request, reply) => {
    reply.header("Set-Cookie", `jaa_session=${session}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400`);
    return { ready: true };
  });
  app.get("/api/state", async () => {
    engine.expireExecutions();
    discovery.cleanupCache();
    if (!aiCache || Date.now() - aiChecked > 15_000) { aiCache = await getAiStatus(); aiChecked = Date.now(); }
    const profile = store.profile(), hash = digest(profile), packets = store.packets(500), automatic = autopilot.view();
    const jobs = new Map(store.jobs(500).map(job => [job.id, job]));
    for (const packet of packets) if (!jobs.has(packet.jobId)) {
      const job = store.job(packet.jobId); if (job) jobs.set(job.id, job);
    }
    for (const item of automatic.jobs) if (!jobs.has(item.jobId)) {
      const job = store.job(item.jobId); if (job) jobs.set(job.id, job);
    }
    return { profile, jobs: [...jobs.values()].map(job => ranked(job, profile, hash)).sort(orderRanked), packets, sources: [...discovery.sources(), ...careerSources.asSources()],
      campaign: campaignStats(store), referenceResumes: referenceList(), preparationQueue: store.preparationTasks(), preparationSummary: store.preparationSummary(),
      resumeVariants: library.list(), autopilot: automatic,
      careerSources: careerSources.list(),
      pagination: { jobTotal: store.jobCount(), packetTotal: store.packetCount(), jobLimit: 500, packetLimit: 500 },
      stats: { attemptsToday: store.attempts(today()), attemptsSession: store.attemptsSession(), limit: profile.preferences.dailyLimit, submitted: store.confirmedCount(), totalJobs: store.jobCount(), stopped: store.value("stopped", false) },
      runtime: { ai: aiCache, cloud: { configured: Boolean(process.env.JAA_CLOUD_URL && process.env.JAA_CLOUD_TOKEN), health: store.value("lastDiscovery", null) }, extension: { paired, ...(paired && extensionOrigin ? { id: extensionOrigin.slice("chrome-extension://".length) } : {}) } } };
  });
  app.post("/api/campaign", async request => {
    autopilot.invalidate("Campaign scope changed. Review and re-enable automatic applications.");
    store.set("campaign", campaignSchema.parse(request.body));
    return { campaign: campaignStats(store) };
  });
  app.get("/api/autopilot/status", async () => autopilot.view());
  app.post("/api/inference/config", async request => {
    const config = inferenceConfigSchema.parse(request.body);
    autopilot.invalidate("Inference provider or data-processing consent changed. Review the settings and activate again.");
    store.set("inference", config); applyInferenceConfig(config); aiCache = undefined; aiChecked = 0;
    return { configured: true, ai: await getAiStatus() };
  });
  app.post("/api/inference/refresh", async () => {
    aiCache = process.env.JAA_AI_PROVIDER === "copilot" ? await refreshCopilotStatus()
      : process.env.JAA_AI_PROVIDER === "gemini" ? await refreshGeminiStatus() : await getAiStatus();
    aiChecked = Date.now(); return { ai: aiCache };
  });
  app.post("/api/inference/gemini-key", async request => {
    const body = geminiKeyRequestSchema.parse(request.body);
    autopilot.invalidate("Gemini credentials changed. Review processing choices and activate again.");
    geminiInference.invalidate();
    const saved = store.value<unknown>("inference", null);
    const config = saved === null ? undefined : inferenceConfigSchema.parse(saved);
    if (config?.provider === "gemini") {
      const disabled = { ...config, allowRemoteProcessing: false, acknowledgeUsage: false, confirmFreeTier: false };
      store.set("inference", disabled);
      applyInferenceConfig(disabled);
    } else {
      process.env.JAA_ALLOW_GEMINI_REMOTE = "0";
      process.env.JAA_GEMINI_FREE_TIER_CONFIRMED = "0";
    }
    aiCache = undefined; aiChecked = 0;
    if ("apiKey" in body) await geminiKeys.save(body.apiKey);
    else await geminiKeys.revoke();
    return { ok: true };
  });
  app.get("/api/monitor/events", async (request, reply) => {
    reply.hijack();
    const response = reply.raw;
    response.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-store", Connection: "keep-alive", "X-Accel-Buffering": "no" });
    const send = () => {
      if (response.destroyed || response.writableEnded) return;
      const view = autopilot.view();
      response.write(`event: monitor\ndata: ${JSON.stringify({ autopilot: { ...view, jobs: view.jobs.slice(0, 50), humanTasks: view.humanTasks?.filter(task => ["waiting", "resuming", "session_lost"].includes(task.status)).slice(0, 20) } })}\n\n`);
    };
    send();
    const timer = setInterval(() => {
      try { send(); } catch {
        response.write('event: monitor-error\ndata: {"error":"Live monitor could not read current state."}\n\n');
        response.end();
      }
    }, 1000);
    timer.unref(); liveStreams.set(response, timer);
    response.on("close", () => { clearInterval(timer); liveStreams.delete(response); });
  });
  app.get("/api/monitor/screenshot", async (request, reply) => {
    const { sessionId } = z.object({ sessionId: z.string().max(200).optional(), t: z.string().optional() }).parse(request.query);
    const image = await autopilot.screenshot(sessionId);
    if (!image) return reply.code(404).send({ error: "No live application page is available." });
    return reply.type("image/png").send(image);
  });
  app.post("/api/hitl/:id/focus", async request => { await autopilot.focusHuman(packetId(request.params)); return { focused: true }; });
  app.post("/api/hitl/:id/continue", async request => {
    const value = z.object({ answers: z.record(z.string().min(1).max(200), z.string().max(10000)),
      useCurrentValues: z.boolean(), confirmReview: z.literal(true) }).strict().parse(request.body);
    if (Object.keys(value.answers).length > 100 || Object.keys(value.answers).some(key => ["__proto__", "constructor", "prototype"].includes(key)
      || /password|passcode|otp|secret|access.?token|verification.?code/i.test(key))) throw new Error("Sensitive credentials must be entered directly in the browser, not through this dashboard.");
    autopilot.continueHuman(packetId(request.params), { answers: value.answers, useCurrentValues: value.useCurrentValues });
    return { autopilot: autopilot.view() };
  });
  app.post("/api/hitl/:id/abandon", async request => {
    z.object({ confirm: z.literal(true) }).strict().parse(request.body);
    await autopilot.abandonHuman(packetId(request.params)); return { autopilot: autopilot.view() };
  });
  app.get("/api/career-links", async () => ({ sources: careerSources.list() }));
  app.post("/api/career-links", async request => {
    const value = z.object({ url: z.url().max(2048), label: z.string().trim().min(1).max(120).optional() }).strict().parse(request.body);
    autopilot.invalidate("Career-source scope is being changed. Review your added links and activate Auto Apply again.");
    return careerSources.add(value.url, value.label);
  });
  const careerId = (params: unknown) => z.object({ id: z.string().regex(/^career-[a-f0-9-]{36}$/) }).parse(params).id;
  app.post("/api/career-links/:id/scan", async request => ({ source: careerSources.requestScan(careerId(request.params)) }));
  app.post("/api/career-links/:id/enabled", async request => {
    const { enabled } = z.object({ enabled: z.boolean() }).strict().parse(request.body);
    autopilot.invalidate("An added career source changed. Review the enabled sources and authorize again.");
    return { source: careerSources.setEnabled(careerId(request.params), enabled) };
  });
  app.post("/api/career-links/:id/remove", async request => {
    autopilot.invalidate("A career source was removed. Review your remaining source scope and authorize again.");
    careerSources.remove(careerId(request.params)); return { removed: true };
  });
  app.post("/api/autopilot/rules", async request => {
    const { rules } = z.object({ rules: autopilotRulesSchema }).strict().parse(request.body);
    autopilot.setRules(rules);
    return { autopilot: autopilot.view() };
  });
  app.post("/api/autopilot/enable", async request => {
    const value = z.object({ snapshotHash: z.string().regex(/^[a-f0-9]{64}$/), authorizeSubmission: z.literal(true),
      confirmAccuracy: z.literal(true), confirmSiteRules: z.literal(true) }).strict().parse(request.body);
    await autopilot.enable(value.snapshotHash);
    return { autopilot: autopilot.view() };
  });
  app.post("/api/autopilot/pause", async () => { autopilot.pause(); return { autopilot: autopilot.view() }; });
  app.post("/api/autopilot/run-one", async () => {
    if (!autopilot.view().enabled) throw new Error("Explicitly enable automatic applications after reviewing the prerequisites first.");
    autopilot.kick(); return { autopilot: autopilot.view() };
  });
  app.post("/api/autopilot/browser", async request => {
    const { url } = z.object({ url: z.url().max(2048).optional() }).strict().parse(request.body ?? {});
    await autopilot.openBrowser(url); return { autopilot: autopilot.view() };
  });
  app.post("/api/autopilot/jobs/:id/retry", async request => {
    autopilot.retry(packetId(request.params)); return { autopilot: autopilot.view() };
  });
  app.post("/api/resume-variants/:slot", async request => {
    const { slot } = z.object({ slot: z.coerce.number().int().min(1).max(MAX_RESUME_SLOTS) }).parse(request.params);
    autopilot.invalidate("Resume library is being changed. Review your approved files and enable again.");
    const values: Record<string, string> = {};
    let file: { name: string; bytes: Buffer } | undefined;
    for await (const part of request.parts()) {
      if (part.type === "file") file = { name: part.filename, bytes: await part.toBuffer() };
      else {
        if (typeof part.value !== "string") throw new Error("Resume labels and role tags must be text.");
        values[part.fieldname] = part.value;
      }
    }
    if (!file) throw new Error("Choose one PDF or DOCX file.");
    const input = z.object({
      label: z.string().trim().min(1).max(120), families: z.string().max(1000),
      approved: z.enum(["true", "false"]).default("false")
    }).strict().parse(values);
    let parsed: unknown;
    try { parsed = JSON.parse(input.families); } catch { throw new Error("Role families must be a JSON array of supported role tags."); }
    const families = z.array(referenceFamilies).min(1).max(6).parse(parsed);
    const variant = await library.upload(slot, file.name, file.bytes, input.label, families, input.approved === "true");
    return { variant };
  });
  app.post("/api/resume-variants/:id/approval", async request => {
    const { approved } = z.object({ approved: z.boolean() }).strict().parse(request.body);
    autopilot.invalidate("Resume approval changed. Review and re-enable automatic applications.");
    return { variant: library.approve(packetId(request.params), approved) };
  });
  app.post("/api/resume-variants/:id/tailor", async request => {
    const value = z.object({
      jobId: z.string().min(1).max(300),
      mode: z.enum(["deterministic", "local-ai"]).default("deterministic")
    }).strict().parse(request.body);
    const id = packetId(request.params), variant = library.approvedVariants().find(item => item.id === id);
    if (!variant) throw new Error("Choose an active, approved and valid base template.");
    const packet = await engine.prepareTailored(value.jobId, variant, await library.bytes(id), value.mode);
    return { packet };
  });
  app.post("/api/resume-variants/:id/remove", async request => {
    autopilot.invalidate("A resume slot was removed. At least two approved, valid resumes are required.");
    await library.remove(packetId(request.params)); return { removed: true };
  });
  app.get("/api/resume-variants/:id/file", async (request, reply) => {
    const id = packetId(request.params), variant = library.get(id);
    reply.header("Content-Disposition", `attachment; filename="${variant.originalFilename.replace(/["\r\n]/g, "")}"`);
    return reply.type(variant.artifact.format === "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document").send(await library.bytes(id));
  });
  app.get("/api/external-applications", async request => {
    const { offset, limit } = z.object({ offset: z.coerce.number().int().min(0).default(0), limit: z.coerce.number().int().min(1).max(1000).default(50) }).parse(request.query);
    return { items: store.externalApplications(limit, offset).map(application => ({ application, job: store.job(application.jobId) })), total: store.externalCount(), offset, limit };
  });
  app.post("/api/external-applications", async request => {
    const value = z.object({ jobId: z.string().min(1).max(300), submittedDate: dateSchema,
      confirmation: z.string().trim().min(10).max(2000), sourceId: z.string().max(100).optional()
    }).strict().parse(request.body);
    const job = store.job(value.jobId);
    if (!job) throw new Error("Import or choose the original job first.");
    if (value.submittedDate > today()) throw new Error("A future application cannot be recorded as already submitted.");
    const sourceId = value.sourceId ?? job.sourceId;
    if (sourceId !== "manual" && !discovery.sources().some(source => source.id === sourceId)) throw new Error("Choose a known source or manual.");
    const timestamp = new Date().toISOString();
    const application: ExternalApplication = { id: randomUUID(), jobId: job.id, sourceId, submittedDate: value.submittedDate,
      confirmation: value.confirmation, createdAt: timestamp, progress: { stage: "applied", note: "", updatedAt: timestamp } };
    store.transaction(() => {
      if (store.hasConflictingApplication(job.id)) throw new Error("This job already has a confirmed or unresolved application; don't count it again.");
      store.putExternal(application); store.event(application.id, "external_recorded", "User logged a previously submitted external application; the tool sent nothing.");
    });
    return { application };
  });
  app.post("/api/external-applications/:id/progress", async request => {
    const application = store.externalApplication(packetId(request.params));
    if (!application) throw new Error("External application record not found.");
    const value = progressSchema.parse(request.body);
    application.progress = { ...value, updatedAt: new Date().toISOString() };
    store.transaction(() => { store.putExternal(application); store.event(application.id, `progress:${value.stage}`, "User reported an external application outcome; nothing was sent."); });
    return { application };
  });
  app.get("/api/jobs", async request => {
    const query = z.object({
      offset: z.coerce.number().int().min(0).max(1000000).default(0), limit: z.coerce.number().int().min(1).max(1000).default(50),
      q: z.string().max(100).default(""), role: z.string().max(100).default(""), location: z.string().max(100).default(""),
      eligibleOnly: z.enum(["true", "false"]).default("false")
    }).parse(request.query);
    const profile = store.profile(), hash = digest(profile);
    const results = store.jobs().filter(job =>
      `${job.title} ${job.company} ${job.description}`.toLowerCase().includes(query.q.toLowerCase())
      && job.title.toLowerCase().includes(query.role.toLowerCase())
      && `${job.location} ${job.countries.join(" ")} ${job.remote ? "remote" : ""}`.toLowerCase().includes(query.location.toLowerCase())
    ).map(job => ranked(job, profile, hash)).filter(job => query.eligibleOnly !== "true" || (job.match.eligible && !job.match.needsReview)).sort(orderRanked);
    return { items: results.slice(query.offset, query.offset + query.limit), total: results.length, offset: query.offset, limit: query.limit };
  });
  app.get("/api/history", async request => {
    const query = z.object({
      offset: z.coerce.number().int().min(0).max(1000000).default(0), limit: z.coerce.number().int().min(1).max(1000).default(50),
      status: z.string().max(100).default(""), stage: z.string().max(100).default(""), q: z.string().max(100).default("")
    }).parse(request.query);
    const where = `(?='' OR json_extract(p.json,'$.status')=?) AND (?='' OR (json_extract(p.json,'$.status')='submitted_confirmed' AND COALESCE(json_extract(p.json,'$.progress.stage'),'applied')=?))
      AND instr(lower(COALESCE(json_extract(j.json,'$.title'),'')||' '||COALESCE(json_extract(j.json,'$.company'),'')),lower(?))>0`;
    const args = [query.status, query.status, query.stage, query.stage, query.q];
    const rows = store.db.prepare(`SELECT p.id FROM packets p JOIN jobs j ON j.id=p.job_id WHERE ${where} ORDER BY p.rowid DESC LIMIT ? OFFSET ?`).all(...args, query.limit, query.offset);
    const total = Number(store.db.prepare(`SELECT count(*) AS n FROM packets p JOIN jobs j ON j.id=p.job_id WHERE ${where}`).get(...args)?.n ?? 0);
    const items = rows.map(row => { const packet = engine.get(String(row.id)); return { packet, job: store.job(packet.jobId)! }; });
    return { items, total, offset: query.offset, limit: query.limit };
  });
  app.get("/api/packets/:id", async request => {
    const packet = engine.get(packetId(request.params)), job = store.job(packet.jobId);
    if (!job) throw new Error("Packet job is missing; restore the relevant history before continuing.");
    return { packet, job };
  });
  app.post("/api/preparation", async request => {
    const value = z.object({ jobIds: z.array(z.string().min(1).max(300)).min(1).max(MAX_APPROVAL_BATCH_SIZE), mode: z.enum(["local-ai", "deterministic"]) }).strict().parse(request.body);
    return { tasks: preparation.enqueue(value.jobIds, value.mode) };
  });
  app.post("/api/preparation/cancel", async request => {
    const value = z.object({ ids: z.array(z.string().uuid()).max(MAX_APPROVAL_BATCH_SIZE).optional() }).strict().parse(request.body ?? {});
    return { cancelled: preparation.cancel(value.ids) };
  });
  app.post("/api/resumes/reference", async request => {
    const { families = ["software", "cloud", "data", "forward-deployed", "mlops", "hybrid"] } = z.object({ families: z.array(referenceFamilies).min(1).max(6).optional() }).strict().parse(request.body ?? {});
    if (new Set(families).size !== families.length) throw new Error("Choose each reference family only once.");
    const profile = store.profile(), hash = digest(profile), resumes: ReferenceResume[] = [];
    if (!profile.facts.length) throw new Error("Import the reference resume first.");
    for (const family of families) {
      const cached = referenceList().find(item => item.family === family && item.sourceProfileHash === hash);
      if (cached) {
        for (const artifact of cached.artifacts) {
          if (basename(artifact.filename) !== artifact.filename) throw new Error("Invalid reference artifact.");
          const bytes = await readFile(join(dataDir, "reference-resumes", cached.id, artifact.filename));
          if (createHash("sha256").update(bytes).digest("hex") !== artifact.sha256) throw new Error("A cached reference draft changed on disk. Restore or remove the damaged draft before regeneration.");
        }
        resumes.push(cached); continue;
      }
      const id = randomUUID(), path = join(dataDir, "reference-resumes", id);
      await mkdir(path, { recursive: true, mode: 0o700 });
      const artifacts = await createReferenceDocuments(profile, family, path);
      const reference: ReferenceResume = { id, family, title: `${family.replaceAll("-", " ")} reference draft`, createdAt: new Date().toISOString(), sourceProfileHash: hash, profileVersion: profile.version, needsReview: true, artifacts };
      store.set("referenceResumes", [...referenceList(), reference]); resumes.push(reference);
    }
    return { resumes };
  });
  app.get("/api/resumes/reference/:id/:format", async (request, reply) => {
    const { id, format } = z.object({ id: z.string().uuid(), format: z.enum(["pdf", "docx"]) }).parse(request.params);
    const reference = referenceList().find(item => item.id === id), artifact = reference?.artifacts.find(item => item.format === format);
    if (!artifact || basename(artifact.filename) !== artifact.filename) throw new Error("Reference draft not found.");
    const bytes = await readFile(join(dataDir, "reference-resumes", id, artifact.filename));
    if (createHash("sha256").update(bytes).digest("hex") !== artifact.sha256) throw new Error("Reference document changed on disk.");
    reply.header("Content-Disposition", `attachment; filename="${artifact.filename.replace(/["\r\n]/g, "")}"`);
    return reply.type(format === "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document").send(bytes);
  });
  app.get("/api/downloads/:kind", async (request, reply) => {
    const { kind } = z.object({ kind: z.enum(["extension", "local", "windows"]) }).parse(request.params);
    const filename = kind === "extension" ? "chairman-chrome-extension.zip" : `chairman-${kind}.zip`, path = join(projectRoot, "dist", filename);
    if (!existsSync(path)) throw new Error("The distributable is not built. Run npm run package in the project directory.");
    return reply.header("Content-Disposition", `attachment; filename="${filename}"`).type("application/zip").send(await readFile(path));
  });
  app.post("/api/profile", async request => {
    autopilot.invalidate("Profile changes require a fresh standing authorization.");
    const { profile } = z.object({ profile: profileSchema }).strict().parse(request.body);
    if (new Set(profile.facts.map(f => f.id)).size !== profile.facts.length) throw new Error("Fact IDs must be unique.");
    if (profile.confirmed && (!profile.name.trim() || !profile.email || !profile.facts.some(f => f.confirmed))) throw new Error("Confirmed profiles require a name, valid email and confirmed experience facts.");
    for (const [key, url] of Object.entries(profile.links)) if (url && !/^https:\/\//.test(url)) throw new Error(`${key} must be an HTTPS profile URL.`);
    if (Object.keys(profile.answers).some(k => /password|secret|otp|verification.?code/i.test(k))) throw new Error("Do not store passwords or verification codes in the answer bank.");
    profile.version = store.profile().version + 1;
    store.set("profile", profile);
    store.event(null, "profile_updated", "Existing packet approvals require regeneration.");
    return { profile };
  });
  app.post("/api/profile/import", async request => {
    autopilot.invalidate("Profile import started. Review the imported facts before enabling automatic applications.");
    const file = await request.file();
    if (!file) throw new Error("Choose a DOCX, PDF or text resume.");
    const buffer = await file.toBuffer();
    const profile = await importResume(buffer, extname(file.filename));
    profile.version = store.profile().version + 1;
    profile.preferences = store.profile().preferences;
    store.set("profile", profile);
    return { profile };
  });
  app.post("/api/jobs/import", async request => {
    const value = z.object({
      title: z.string().min(2).max(300), company: z.string().min(1).max(300), description: z.string().min(30).max(100000),
      applyUrl: z.url().max(2000), location: z.string().max(500).optional(), employmentType: z.string().max(100).optional()
    }).strict().parse(request.body);
    const url = new URL(value.applyUrl);
    if (url.username || url.password || (url.protocol !== "https:" && !(fixtureMode && url.origin === origin && url.pathname === "/fixture/application")))
      throw new Error("Use an HTTPS employer application URL. Local URLs are only allowed for an enabled fixture.");
    const job: Job = { id: randomUUID(), sourceId: fixtureMode && url.origin === origin ? "fixture" : "manual", sourceJobId: value.applyUrl,
      title: value.title, company: value.company, description: value.description, location: value.location ?? "Unverified",
      remote: /\bremote\b/i.test(value.location ?? ""), countries: /\bindia\b/i.test(value.location ?? "") ? ["India"] : [],
      employmentType: value.employmentType ?? "Unknown", applyUrl: value.applyUrl, canonicalUrl: value.applyUrl, fetchedAt: new Date().toISOString(),
      salary: null, language: null, sponsorship: "unknown", aiPolicy: prohibitsAi(value.description) ? "prohibited" : "unknown", status: "open" };
    return { job: store.saveJob(job) };
  });
  app.post("/api/scan", async request => {
    const { sourceId } = z.object({ sourceId: z.string().max(100).optional() }).strict().parse(request.body ?? {});
    if (sourceId?.startsWith("career-")) {
      careerSources.requestScan(sourceId);
      return { results: [{ sourceId, count: 0, message: "Career scan scheduled; see its source status for imported listings." }] };
    }
    return discovery.scan(sourceId);
  });
  app.post("/api/packets", async request => {
    const value = z.object({ jobId: z.string().min(1).max(300), mode: z.enum(["local-ai", "deterministic"]), answers: answersSchema.shape.answers.optional() }).strict().parse(request.body);
    return { packet: await engine.prepare(value.jobId, value.mode, value.answers) };
  });
  app.post("/api/packets/:id/answers", async request => ({ packet: engine.updateAnswers(packetId(request.params), answersSchema.parse(request.body).answers) }));
  app.post("/api/packets/approve", async request => {
    const value = z.object({ ids: z.array(z.string().uuid()).min(1).max(MAX_APPROVAL_BATCH_SIZE), acknowledgeWarnings: z.boolean() }).strict().parse(request.body);
    return { packets: await engine.approve(value.ids, value.acknowledgeWarnings) };
  });
  app.get("/api/packets/:id/documents/:format", async (request, reply) => {
    const { id, format } = z.object({ id: z.string().uuid(), format: z.enum(["pdf", "docx"]) }).parse(request.params);
    const packet = engine.get(id), artifact = packet.artifacts.find(a => a.format === format);
    if (!artifact || basename(artifact.filename) !== artifact.filename) throw new Error("Document not found.");
    const bytes = await readFile(join(engine.directory(id), artifact.filename));
    reply.header("Content-Disposition", `attachment; filename="${artifact.filename.replace(/["\r\n]/g, "")}"`);
    return reply.type(format === "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document").send(bytes);
  });
  app.post("/api/control", async request => {
    const { stopped } = z.object({ stopped: z.boolean() }).strict().parse(request.body);
    if (stopped) autopilot.pause();
    engine.stop(stopped); return { stopped };
  });
  app.post("/api/packets/:id/confirm", async request => {
    const { confirmation } = z.object({ confirmation: z.string().trim().min(10).max(2000) }).strict().parse(request.body);
    const packet = engine.get(packetId(request.params));
    if (!["manual_only", "awaiting_human", "submission_unknown"].includes(packet.status)) throw new Error("Only manual or unresolved applications can be reconciled here.");
    if (store.hasConflictingApplication(packet.jobId, packet.id)) throw new Error("This job already has a submitted or unresolved application. Reconcile the existing record rather than count it twice.");
    packet.status = "submitted_confirmed"; packet.confirmation = `User-reported confirmation: ${confirmation}`; delete packet.error;
    packet.submittedAt ??= new Date().toISOString();
    packet.progress ??= { stage: "applied", note: "", updatedAt: packet.submittedAt };
    store.transaction(() => {
      store.putPacket(packet);
      store.db.prepare("UPDATE runs SET status='submitted_confirmed' WHERE packet_id=?").run(packet.id);
      store.event(packet.id, "user_confirmed", "User explicitly reported employer confirmation; not a browser-verified receipt.");
    });
    await autopilot.resolveHumanPacket(packet.id);
    return { packet };
  });
  app.post("/api/packets/:id/progress", async request => {
    const value = progressSchema.parse(request.body), packet = engine.get(packetId(request.params));
    if (packet.status !== "submitted_confirmed") throw new Error("Record a real submission confirmation before tracking hiring outcomes.");
    packet.progress = { ...value, updatedAt: new Date().toISOString() };
    store.transaction(() => {
      store.putPacket(packet); store.event(packet.id, `progress:${value.stage}`, "User reported a hiring-pipeline update; no message or application was sent.");
    });
    return { packet };
  });
  app.post("/api/extension/pair", async () => {
    assistance.invalidate();
    const token = randomBytes(32).toString("hex");
    extensionTokenHash = hashPairingToken(token); extensionOrigin = ""; paired = false;
    await savePairing();
    return { token };
  });
  app.post("/api/extension/connect", async () => { paired = true; await savePairing(); return { paired: true }; });
  app.get("/api/extension/jobs", async () => ({
    stopped: store.value("stopped", false),
    items: store.extensionPackets().map(packet => {
      const job = store.job(packet.jobId)!; const policy = engine.policy(job);
      return { packet, job, automationAllowed: policy.allowed, reason: policy.reason };
    })
  }));
  app.post("/api/extension/preflight", async request => {
    const value = z.object({ packetId: z.string().uuid(), snapshot: formSchema }).strict().parse(request.body);
    return { packet: engine.preflight(value.packetId, value.snapshot) };
  });
  app.post("/api/extension/claim", async request => {
    const { packetId: id } = z.object({ packetId: z.string().uuid() }).strict().parse(request.body);
    return engine.claim(id);
  });
  app.post("/api/extension/report", async request => {
    const value = z.object({
      packetId: z.string().uuid(), runToken: z.string().regex(/^[a-f0-9]{64}$/),
      outcome: z.enum(["submitted_confirmed", "submission_unknown", "failed"]),
      confirmation: z.string().max(2000).optional(), error: z.string().max(2000).optional()
    }).strict().parse(request.body);
    return { packet: engine.report(value.packetId, value.runToken, value.outcome, value.confirmation, value.error) };
  });
  app.get("/api/export", async (_request, reply) => {
    reply.header("Content-Disposition", 'attachment; filename="chairman-private-export.json"');
    return { profile: store.profile(), jobs: store.jobs(), packets: store.packets(), externalApplications: store.externalApplications(), campaign: campaignConfig(store), referenceResumes: referenceList(), resumeVariants: library.list(), careerSources: careerSources.list(), gmailSuggestions: gmail.status().suggestions,
      assistance: assistance.export(), rememberedPageAnswers: assistance.rememberedAnswers(), searchPortals: searchPortals.list().portals, discoveryPreferences: discovery.preferences(),
      trackingNotes: store.db.prepare("SELECT key,value FROM settings WHERE key LIKE 'trackingNote:%'").all(),
      events: store.db.prepare("SELECT packet_id,type,detail,created_at FROM events").all(),
      warning: "Private local export. Documents are downloadable individually; credentials are intentionally excluded." };
  });
  app.post("/api/data/delete", async request => {
    z.object({ confirmation: z.literal("DELETE LOCAL DATA") }).strict().parse(request.body);
    if (store.packetsWithStatus("executing").length || store.preparationWithStatus("running").length) throw new Error("Stop and finish or reconcile running work before deleting local history.");
    assistance.clear();
    extensionTokenHash = ""; extensionOrigin = ""; paired = false; await savePairing();
    deletingData = true;
    try {
    process.env.JAA_ALLOW_COPILOT_REMOTE = "0";
    process.env.JAA_ALLOW_GEMINI_REMOTE = "0";
    process.env.JAA_GEMINI_FREE_TIER_CONFIRMED = "0";
    geminiInference.invalidate();
    await geminiKeys.revoke();
    await gmail.disconnect(true);
    const gmailWarning = gmail.status().error;
    aiCache = undefined; aiChecked = 0;
    await autopilot.pauseAndDrain();
    await careerSources.close();
    await rm(join(dataDir, "documents"), { recursive: true, force: true });
    await rm(join(dataDir, "reference-resumes"), { recursive: true, force: true });
    await rm(join(dataDir, "resume-variants"), { recursive: true, force: true });
    await rm(join(dataDir, "automation-browser"), { recursive: true, force: true });
    await rm(join(dataDir, "portal-browser"), { recursive: true, force: true });
    const day = today(), total = store.attempts(day);
    const prior = store.value<{ sources: Record<string, number> }>("attemptCarry", { sources: {} });
    const sourceIds = new Set([...Object.keys(prior.sources), ...store.db.prepare("SELECT DISTINCT source_id FROM runs WHERE day=?").all(day).map(row => String(row.source_id))]);
    const counts = Object.fromEntries([...sourceIds].map(id => [id, store.attempts(day, id)]));
    const discoveryCooldowns = store.db.prepare("SELECT key,value FROM settings WHERE key LIKE 'nextScan:%' OR key LIKE 'career-board-cooldown:%'").all();
    const blockedSources = Object.fromEntries(discovery.sources().filter(source => source.mode === "blocked").map(source => [source.id, { mode: "blocked", lastError: "Source access remains blocked pending permission review." }]));
    store.transaction(() => {
      store.db.exec("DELETE FROM apply_sessions; DELETE FROM application_evidence; DELETE FROM shortlists; DELETE FROM shortlist_state; DELETE FROM question_inbox; DELETE FROM human_tasks; DELETE FROM live_events; DELETE FROM career_source_jobs; DELETE FROM career_sources; DELETE FROM autopilot_jobs; DELETE FROM resume_variants; DELETE FROM external_applications; DELETE FROM preparation; DELETE FROM runs; DELETE FROM packets; DELETE FROM jobs; DELETE FROM events; DELETE FROM settings;");
      store.set("attemptCarry", { day, total, sources: counts });
      for (const row of discoveryCooldowns) store.set(String(row.key), JSON.parse(String(row.value)));
      store.set("sourceHealth", blockedSources);
    });
    extensionTokenHash = ""; extensionOrigin = ""; paired = false; await savePairing();
    careerSources.start();
    return { deleted: true, ...(gmailWarning ? { warning: gmailWarning } : {}) };
    } finally { deletingData = false; }
  });
  if (fixtureMode) {
    app.get("/fixture/application", async (_request, reply) => reply.type("text/html").send(`<!doctype html><html lang="en"><head><title>Controlled application fixture</title></head><body><h1>LOCAL TEST ONLY</h1><form method="post" action="/fixture/submit" enctype="multipart/form-data">
      <label>Full name<input name="full_name" id="full_name" required></label><label>Email<input type="email" name="email" id="email" required></label>
      <label>Phone<input type="tel" name="phone" id="phone"></label><label>Relevant experience<textarea name="experience" id="experience" required></textarea></label>
      <label>Resume<input type="file" name="resume" id="resume" accept=".pdf" required></label><button type="submit">Submit application</button></form></body></html>`));
    app.post("/fixture/submit", async (request, reply) => {
      const parts = request.parts(); let gotResume = false, gotEmail = false, gotName = false, gotExperience = false;
      for await (const part of parts) {
        if (part.type === "file") {
          const bytes = await part.toBuffer(); gotResume = part.fieldname === "resume" && bytes.subarray(0, 4).toString() === "%PDF";
        } else if (part.fieldname === "email") gotEmail = /@/.test(String(part.value));
        else if (part.fieldname === "full_name") gotName = Boolean(String(part.value).trim());
        else if (part.fieldname === "experience") gotExperience = Boolean(String(part.value).trim());
      }
      if (!gotResume || !gotEmail || !gotName || !gotExperience) throw new Error("Fixture validation failed.");
      const id = randomUUID(); store.set(`fixture:${id}`, true);
      return reply.redirect(`/fixture/confirmation?id=${id}`);
    });
    app.get("/fixture/confirmation", async (request, reply) => {
      const { id } = z.object({ id: z.string().uuid() }).parse(request.query);
      if (!store.value(`fixture:${id}`, false)) return reply.code(404).send("Unknown fixture confirmation.");
      return reply.type("text/html").send(`<main data-jaa-submitted="true" data-confirmation-id="${id}"><h1>Application submitted</h1><p>Local fixture only. Reference ${id}</p></main>`);
    });
  }
  const dashboard = join(projectRoot, "dist", "dashboard");
  if (existsSync(join(dashboard, "index.html"))) {
    await app.register(staticFiles, { root: dashboard, prefix: "/" });
    app.setNotFoundHandler((request, reply) => request.url.startsWith("/api/") ? reply.code(404).send({ error: "Endpoint not found." }) : reply.sendFile("index.html"));
  } else app.get("/", async (_request, reply) => reply.type("text/html").send("<h1>Chairman</h1><p>Run npm run build, then restart to open the dashboard.</p>"));
  app.addHook("onClose", async () => { shortlist.close(); await assistance.close(); await gmail.close(); await autopilot.close(); await careerSources.close(); await preparation.stop(); await discovery.stop(); store.close(); });
  app.addHook("preClose", async () => {
    for (const [response, timer] of liveStreams) { clearInterval(timer); response.end(); }
    liveStreams.clear();
  });
  return { app, store, engine, discovery, preparation, library, autopilot, careerSources, shortlist, sessions, progress, origin, port };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const runtime = await createApp();
  const resumePath = process.env.JAA_IMPORT_RESUME;
  if (resumePath && !runtime.store.profile().facts.length) {
    const profile = await importResume(await readFile(resumePath), extname(resumePath));
    runtime.store.set("profile", profile);
  }
  await runtime.app.listen({ port: runtime.port, host: "127.0.0.1" });
  runtime.discovery.start();
  runtime.preparation.start();
  runtime.autopilot.start();
  runtime.careerSources.start();
  runtime.shortlist.start();
  console.log(`Chairman: ${runtime.origin} (private local dashboard)`);
  const close = async () => { await runtime.app.close(); process.exit(0); };
  process.once("SIGINT", close); process.once("SIGTERM", close);
}
