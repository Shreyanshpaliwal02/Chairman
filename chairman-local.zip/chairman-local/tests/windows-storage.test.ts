import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { linkOrCopyArtifact } from "../apps/local/artifact-storage.js";
import { isNormalBrowserProfile } from "../packages/automation/profile-path.js";
import { ApplicationBrowser } from "../packages/automation/browser.js";
import { PortalBrowser } from "../packages/automation/portal-browser.js";

test("normal browser profile protection recognizes Windows separators and case", () => {
  for (const path of [
    "C:\\Users\\Candidate\\AppData\\Local\\Google\\Chrome\\User Data",
    "C:\\Users\\Candidate\\AppData\\Local\\MICROSOFT\\EDGE\\User Data\\Default",
    "\\\\host\\share\\Google\\Chrome\\User Data",
    "/Users/candidate/Library/Application Support/Google/Chrome/Default",
    "/home/candidate/.config/google-chrome/Default",
  ]) {
    assert.equal(isNormalBrowserProfile(path), true, path);
    assert.throws(() => new ApplicationBrowser({ userDataDir: path }), /dedicated|normal/i);
    assert.throws(() => new PortalBrowser({ userDataDir: path }), /dedicated/i);
  }
  for (const path of ["C:\\Users\\Candidate\\AppData\\Local\\Job Application Assistant\\portal-browser", "/tmp/jaa-profile"]) {
    assert.equal(isNormalBrowserProfile(path), false);
  }
});

test("resume storage preserves exact bytes on filesystems without hard links", async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-storage-"));
  const bytes = Buffer.from("%PDF-1.4 synthetic approved fixture");
  try {
    const source = join(dir, "original.pdf");
    await writeFile(source, bytes);
    const linked = join(dir, "linked.pdf");
    assert.equal(await linkOrCopyArtifact(source, linked, bytes), "linked");
    assert.equal((await stat(source)).ino, (await stat(linked)).ino);
    for (const code of ["EXDEV", "ENOTSUP", "EOPNOTSUPP", "ENOSYS", "EMLINK", "EPERM"]) {
      const target = join(dir, `${code}.pdf`);
      assert.equal(await linkOrCopyArtifact(source, target, bytes, async () => { throw Object.assign(new Error(code), { code }); }), "copied");
      assert.deepEqual(await readFile(target), bytes);
      assert.notEqual((await stat(target)).ino, (await stat(source)).ino);
    }
    await assert.rejects(linkOrCopyArtifact(source, linked, Buffer.from("must not overwrite"), async () => {
      throw Object.assign(new Error("unsupported"), { code: "ENOTSUP" });
    }), { code: "EEXIST" });
    assert.deepEqual(await readFile(source), bytes);
    for (const code of ["ENOENT", "EACCES", "EIO", "ENOSPC", "EEXIST"]) {
      const target = join(dir, `error-${code}.pdf`);
      await assert.rejects(linkOrCopyArtifact(source, target, bytes, async () => { throw Object.assign(new Error(code), { code }); }), { code });
      await assert.rejects(stat(target), { code: "ENOENT" });
    }
  } finally { await rm(dir, { recursive: true, force: true }); }
});
