import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "../apps/local/server.js";
import { sessionStartUrl } from "../apps/local/apply-sessions.js";
import { localDate } from "../packages/domain/dates.js";
import { jobFixture } from "./fixtures.js";

test("start URLs skip the job page where a site links straight to its application", () => {
  assert.equal(sessionStartUrl({ applyUrl: "https://cisco.wd5.myworkdayjobs.com/en-US/Cisco_Careers/job/Bangalore%2C-India/SRE_2023851", canonicalUrl: "" }),
    "https://cisco.wd5.myworkdayjobs.com/en-US/Cisco_Careers/job/Bangalore%2C-India/SRE_2023851/apply/autofillWithResume");
  assert.equal(sessionStartUrl({ applyUrl: "https://cisco.wd5.myworkdayjobs.com/en-US/Cisco_Careers/job/Bangalore/SRE_1/apply/applyManually", canonicalUrl: "" }),
    "https://cisco.wd5.myworkdayjobs.com/en-US/Cisco_Careers/job/Bangalore/SRE_1/apply/applyManually", "an application link is kept as it is");
  assert.equal(sessionStartUrl({ applyUrl: "https://jobs.lever.co/palantir/00000000-0000-4000-8000-000000000001", canonicalUrl: "" }), "https://jobs.lever.co/palantir/00000000-0000-4000-8000-000000000001/apply");
  assert.equal(sessionStartUrl({ applyUrl: "https://jobs.ashbyhq.com/openai/00000000-0000-4000-8000-000000000002", canonicalUrl: "" }), "https://jobs.ashbyhq.com/openai/00000000-0000-4000-8000-000000000002/application");
  assert.equal(sessionStartUrl({ applyUrl: "https://job-boards.greenhouse.io/anthropic/jobs/5424111008", canonicalUrl: "" }), "https://job-boards.greenhouse.io/anthropic/jobs/5424111008", "Greenhouse forms are on the job page");
});

test("a session takes today's top to-do roles, keeps at most 10 open, finishes when every role is done, and the next session takes the rest", { timeout: 60_000 }, async () => {
  const directory = await mkdtemp(join(tmpdir(), "jaa-sessions-"));
  const runtime = await createApp({ dataDir: directory, port: 4345 });
  const host = { host: "127.0.0.1:4345" };
  try {
    const entries = Array.from({ length: 13 }, (_, index) => {
      const url = `https://job-boards.greenhouse.io/fixture/jobs/${1000 + index}`;
      const job = runtime.store.saveJob(jobFixture({ id: `career-role-${index}`, sourceId: "career-11111111-1111-1111-1111-111111111111", title: `Data Engineer ${index}`, applyUrl: url, canonicalUrl: url }));
      return { jobId: job.id, rank: index + 1, score: 90 - index, tier: "india", label: "India", sponsorship: "unknown", experience: "fits", skills: [], reasons: [], carriedOver: false };
    });
    runtime.store.db.prepare("INSERT INTO shortlists VALUES (?,?)").run(localDate(), JSON.stringify({ date: localDate(), generatedAt: new Date().toISOString(), candidates: 13, excluded: {}, levels: ["mid"], entries }));
    const cookie = (await runtime.app.inject({ url: "/api/session", headers: host })).cookies[0]!;
    const dashboard = { ...host, cookie: `${cookie.name}=${cookie.value}` };
    const call = async (method: "GET" | "POST", url: string, payload?: object) => {
      const response = await runtime.app.inject({ method, url, headers: dashboard, ...(payload ? { payload } : {}) });
      assert.equal(response.statusCode, 200, response.body);
      return response.json();
    };
    assert.equal((await call("GET", "/api/apply-sessions/current")).available, 13);
    const started = await call("POST", "/api/apply-sessions", { size: 12 });
    assert.deepEqual([started.session.size, started.session.status, started.session.items[0].jobId, started.available], [12, "active", "career-role-0", 1], "best first; the 13th stays for later");
    assert.equal((await runtime.app.inject({ method: "POST", url: "/api/apply-sessions", headers: dashboard, payload: {} })).statusCode, 400, "one session at a time");

    const first = runtime.sessions.next();
    assert.deepEqual(first.map(item => item.jobId), Array.from({ length: 10 }, (_, index) => `career-role-${index}`), "10 tabs at a time");
    assert.equal(runtime.sessions.next().length, 0, "no more while 10 are open");
    assert.equal((await call("GET", "/api/shortlist")).entries.find((entry: { jobId: string }) => entry.jobId === "career-role-0").status, "opened");
    runtime.sessions.update("career-role-0", "needs_you", "Sign in");
    runtime.sessions.update("career-role-1", "submitted");
    runtime.sessions.update("career-role-2", "closed");
    runtime.sessions.update("career-role-3", "skipped");
    assert.equal((await call("GET", "/api/shortlist")).entries.find((entry: { jobId: string }) => entry.jobId === "career-role-3").status, "skipped", "skipping in the panel skips it on Today");
    assert.deepEqual(runtime.sessions.next().map(item => item.jobId), ["career-role-10", "career-role-11"], "each finished tab frees a place for the next role");
    runtime.sessions.update("career-role-1", "working");
    assert.equal(runtime.sessions.view()!.items[1]!.state, "submitted", "a finished role stays finished");
    for (let index = 0; index < 12; index++) if (![1, 2, 3].includes(index)) runtime.sessions.update(`career-role-${index}`, index % 2 ? "submitted" : "closed");
    const done = await call("GET", "/api/apply-sessions/current");
    assert.deepEqual([done.session.status, done.session.finished, done.available], ["complete", 12, 1]);
    const next = await call("POST", "/api/apply-sessions", {});
    assert.deepEqual([next.session.number, next.session.items.map((item: { jobId: string }) => item.jobId)], [2, ["career-role-12"]], "the next session takes the roles still to do");
    // One role opened on its own from the dashboard is driven like a session role and starts at its application.
    const workday = runtime.store.saveJob(jobFixture({ id: "career-role-workday", sourceId: "career-11111111-1111-1111-1111-111111111111", title: "Sr Data Engineer",
      applyUrl: "https://fictional.wd5.myworkdayjobs.com/en-US/External/job/Hyderabad/Sr-Data-Engineer_JR358536", canonicalUrl: "https://fictional.wd5.myworkdayjobs.com/en-US/External/job/Hyderabad/Sr-Data-Engineer_JR358536" }));
    assert.equal(runtime.sessions.driven(workday.id), false);
    assert.deepEqual(runtime.sessions.startFor(workday.id), { jobId: workday.id, company: workday.company, title: "Sr Data Engineer",
      startUrl: "https://fictional.wd5.myworkdayjobs.com/en-US/External/job/Hyderabad/Sr-Data-Engineer_JR358536/apply/autofillWithResume" });
    assert.equal(runtime.sessions.driven(workday.id), true);
    assert.equal(runtime.sessions.driven("career-role-12"), true, "roles in the active session are driven");
    assert.throws(() => runtime.sessions.startFor("no-such-role"), /no longer in Chairman/);
    const stopped = await call("POST", "/api/apply-sessions/current/stop", {});
    assert.equal(stopped.session.status, "stopped");
    assert.equal((await runtime.app.inject({ url: "/api/extension/assist/session", headers: host })).statusCode, 403, "extension session routes need the paired extension's side panel");
    assert.equal((await runtime.app.inject({ url: "/api/extension/assist/session", headers: { ...host, origin: `chrome-extension://${"d".repeat(32)}`, authorization: "Bearer wrong" } })).statusCode, 403);
  } finally {
    await runtime.app.close();
    await rm(directory, { recursive: true, force: true });
  }
});
