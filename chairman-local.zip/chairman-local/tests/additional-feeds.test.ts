import assert from "node:assert/strict";
import test from "node:test";
import { DiscoveryError, scanSource, validatePublicJob } from "../packages/adapters/discovery";
import { getSource, getSourceCooldownMs } from "../packages/adapters/sources";

const remotiveJob = {
  id: 123, url: "https://remotive.com/remote-jobs/software-dev/platform-engineer-123",
  title: "Platform Engineer", company_name: "Fixture", job_type: "full_time",
  publication_date: "2026-09-01T10:00:00Z", candidate_required_location: "United States",
  salary: "$60–80/hour + equity", description: "<p>Build infrastructure.</p>"
};
const arbeitnowJob = {
  slug: "cloud-engineer-fixture-123", url: "https://www.arbeitnow.com/jobs/companies/fixture/cloud-engineer-fixture-123",
  title: "Cloud Engineer", company_name: "Fixture", remote: true, location: "Berlin, Germany",
  job_types: ["full time"], created_at: 1_788_000_000, description: "<p>Build cloud services.</p>"
};
const remoteokJob = {
  id: "456", url: "https://remoteok.com/remote-jobs/remote-engineer-fixture-456",
  position: "Infrastructure Engineer", company: "Fixture", location: "United States",
  salary_min: 120000, salary_max: 160000, description: "<p>Maintain systems.</p>",
  date: "2026-09-01T10:00:00+00:00"
};
const remoteokMetadata = {
  last_updated: 1_788_000_000,
  legal: "API Terms of Service: link back with follow, not nofollow, and mention Remote OK. No logo without written permission."
};
const remotivePayload = (jobs: unknown[] = [remotiveJob]) => ({
  "0-legal-notice": "Remotive API Legal Notice", "job-count": jobs.length, jobs
});
const arbeitnowPayload = (data: unknown[] = [arbeitnowJob], page = 1, next: string | null = null) => ({
  data, meta: { current_page: page, per_page: 250 },
  links: { next }
});
const fixtureFetch = (payload: unknown): typeof fetch => (async () => Response.json(payload)) as typeof fetch;
const errorIs = (code: string) => (error: unknown) => error instanceof DiscoveryError && error.code === code;

test("additional source permission and caller cooldowns are explicit", () => {
  for (const id of ["remotive", "arbeitnow", "remoteok"]) {
    const source = getSource(id)!;
    assert.equal(source.discoveryAllowed, true);
    assert.equal(source.assistanceAllowed, false);
    assert.equal(source.submissionAllowed, false);
    assert.match(source.notes, /Local-only/);
  }
  assert.equal(getSourceCooldownMs("remotive"), 21_600_000);
  assert.equal(getSourceCooldownMs("arbeitnow"), 3_600_000);
  assert.equal(getSourceCooldownMs("remoteok"), 86_400_000);
  assert.equal(getSourceCooldownMs("himalayas"), 0);
  assert.equal(getSourceCooldownMs("unknown"), 0);
});

test("new feeds use only fixed public GET requests with no account data", async () => {
  for (const [id, expected, payload] of [
    ["remotive", "https://remotive.com/api/remote-jobs?category=software-dev", remotivePayload()],
    ["arbeitnow", "https://www.arbeitnow.com/api/job-board-api?page=1", arbeitnowPayload()],
    ["remoteok", "https://remoteok.com/api", [remoteokMetadata, remoteokJob]]
  ] as const) {
    let calls = 0;
    const fetcher = (async (input, init) => {
      calls++;
      assert.equal(String(input), expected);
      assert.equal(init?.method, "GET");
      assert.equal(init?.redirect, "error");
      assert.equal(init?.credentials, "omit");
      assert.equal(init?.referrerPolicy, "no-referrer");
      assert.equal(init?.body, undefined);
      const headers = new Headers(init?.headers);
      for (const name of ["authorization", "cookie", "referer"]) assert.equal(headers.get(name), null);
      return Response.json(payload);
    }) as typeof fetch;
    const result = await scanSource(id, undefined, fetcher);
    assert.equal(calls, 1);
    assert.equal(result.jobs.length, 1);
    assert.equal(result.jobs[0]!.applyUrl, result.jobs[0]!.canonicalUrl);
    assert.match(result.jobs[0]!.description, new RegExp(`Original source: ${getSource(id)!.name} — https:`));
  }
});

test("Remotive keeps raw salary uncertainty and explicit remote restrictions", async () => {
  const result = await scanSource("remotive", undefined, fixtureFetch(remotivePayload()));
  const job = result.jobs[0]!;
  assert.equal(job.salary, null);
  assert.match(job.description, /\$60–80\/hour \+ equity/);
  assert.match(job.description, /type unverified/);
  assert.deepEqual(job.countries, ["United States"]);
  assert.equal(job.employmentType, "Full-time");
  assert.equal(job.sponsorship, "unknown");
  assert.equal(job.language, null);
  assert.equal(job.postedAt, remotiveJob.publication_date.replace("Z", ".000Z"));
  const [naiveDate] = (await scanSource("remotive", undefined, fixtureFetch(remotivePayload([
    { ...remotiveJob, publication_date: "2026-09-01T10:00:00" }
  ])))).jobs;
  assert.equal(naiveDate!.postedAt, undefined);
  assert.match(naiveDate!.description, /timezone unspecified\): 2026-09-01T10:00:00/);
  for (const [location, countries] of [
    ["", []], ["Remote", []], ["Worldwide except India", []], ["Worldwide, excluding India", []], ["Europe", []],
    ["Worldwide", ["Worldwide"]], ["India, US", ["India", "United States"]]
  ] as const) {
    const [item] = (await scanSource("remotive", undefined, fixtureFetch(remotivePayload([
      { ...remotiveJob, candidate_required_location: location }
    ])))).jobs;
    assert.deepEqual(item!.countries, countries);
  }
});

test("Arbeitnow follows validated numeric pagination by reconstructing the endpoint", async () => {
  const first = await scanSource("arbeitnow", undefined, fixtureFetch(arbeitnowPayload(
    [arbeitnowJob], 1, "https://arbeitnow.com/api/job-board-api?page=2"
  )));
  assert.equal(first.nextCursor, "2");
  const second = await scanSource("arbeitnow", first.nextCursor, (async (input) => {
    assert.equal(String(input), "https://www.arbeitnow.com/api/job-board-api?page=2");
    return Response.json(arbeitnowPayload([{ ...arbeitnowJob, slug: "next-124" }], 2));
  }) as typeof fetch);
  assert.equal(second.nextCursor, undefined);
  assert.equal(second.jobs.length, 1);
});

test("Arbeitnow preserves countries, employment labels and only explicit visa flags", async () => {
  for (const [visa, sponsorship] of [[undefined, "unknown"], [true, "yes"], [false, "no"]] as const) {
    const [job] = (await scanSource("arbeitnow", undefined, fixtureFetch(arbeitnowPayload([
      { ...arbeitnowJob, visa_sponsorship: visa, job_types: ["freelance", "contract"], description: "" }
    ])))).jobs;
    assert.equal(job!.sponsorship, sponsorship);
    assert.equal(job!.salary, null);
    assert.equal(job!.language, null);
    assert.deepEqual(job!.countries, ["Germany"]);
    assert.equal(job!.employmentType, "freelance, Contract");
    assert.match(job!.description, /Description not supplied/);
  }
  const [job] = (await scanSource("arbeitnow", undefined, fixtureFetch(arbeitnowPayload([
    { ...arbeitnowJob, location: "Berlin", remote: false }
  ])))).jobs;
  assert.deepEqual(job!.countries, []);
  assert.equal(job!.remote, false);
});

test("Remote OK ignores the legal record, preserves raw ranges, and never assumes annual USD base", async () => {
  const [job] = (await scanSource("remoteok", undefined, fixtureFetch([remoteokMetadata, remoteokJob]))).jobs;
  assert.equal(job!.sourceJobId, "456");
  assert.deepEqual(job!.salary, { min: 120000, max: 160000, kind: "unknown" });
  assert.match(job!.description, /"salary_min":120000/);
  assert.match(job!.description, /period and base\/total type unverified/);
  assert.deepEqual(job!.countries, ["United States"]);
  assert.equal(job!.employmentType, "unknown");
  assert.equal(job!.sponsorship, "unknown");
  const [zero] = (await scanSource("remoteok", undefined, fixtureFetch([
    remoteokMetadata, { ...remoteokJob, salary_min: 0, salary_max: 0, location: "" }
  ]))).jobs;
  assert.equal(zero!.salary, null);
  assert.deepEqual(zero!.countries, []);
  assert.match(zero!.description, /"salary_min":0/);
  const [upperOnly] = (await scanSource("remoteok", undefined, fixtureFetch([
    remoteokMetadata, { ...remoteokJob, salary_min: 0, salary_currency: "EUR" }
  ]))).jobs;
  assert.deepEqual(upperOnly!.salary, { max: 160000, currency: "EUR", kind: "unknown" });
});

test("provider pages and snapshots never silently discard jobs to match a smaller budget", async () => {
  const arbeitnowRows = Array.from({ length: 250 }, (_, index) => ({ ...arbeitnowJob, slug: `job-${index}` }));
  const remotiveRows = Array.from({ length: 21 }, (_, index) => ({ ...remotiveJob, id: index + 1 }));
  const remoteokRows = Array.from({ length: 21 }, (_, index) => ({ ...remoteokJob, id: String(index + 1) }));
  for (const [id, payload, count] of [
    ["arbeitnow", arbeitnowPayload(arbeitnowRows, 1, "https://www.arbeitnow.com/api/job-board-api?page=2"), 250],
    ["remotive", remotivePayload(remotiveRows), 21],
    ["remoteok", [remoteokMetadata, ...remoteokRows], 21]
  ] as const) {
    assert.equal((await scanSource(id, undefined, fixtureFetch(payload))).jobs.length, count);
    await assert.rejects(scanSource(id, undefined, fixtureFetch(payload), { pageSize: 1 }), errorIs("TOO_LARGE"));
    await assert.rejects(scanSource(id, undefined, fixtureFetch(payload), { maxResponseBytes: 50 }), errorIs("TOO_LARGE"));
  }
});

test("Arbeitnow's bounded 2 MiB local default accommodates its published 250-entry page", async () => {
  const rows = Array.from({ length: 250 }, (_, index) => ({
    ...arbeitnowJob, slug: `job-${index}`, description: "Public job text. ".repeat(400)
  }));
  const payload = arbeitnowPayload(rows);
  assert.ok(Buffer.byteLength(JSON.stringify(payload)) > 1_048_576);
  assert.equal((await scanSource("arbeitnow", undefined, fixtureFetch(payload))).jobs.length, 250);
  await assert.rejects(scanSource("arbeitnow", undefined, fixtureFetch(payload), { maxResponseBytes: 1_048_576 }), errorIs("TOO_LARGE"));
  await assert.rejects(scanSource("arbeitnow", undefined, fixtureFetch(payload), { maxResponseBytes: 64 * 1024, pageSize: 1 }), errorIs("TOO_LARGE"));
  const huge = arbeitnowPayload(rows.map(row => ({ ...row, description: "Public job text. ".repeat(600) })));
  await assert.rejects(scanSource("arbeitnow", undefined, fixtureFetch(huge)), errorIs("TOO_LARGE"));
});

test("feed cursor validation happens before any fetch", async () => {
  let calls = 0;
  const noFetch = (async () => { calls++; throw new Error("Unexpected fetch"); }) as typeof fetch;
  for (const id of ["remotive", "remoteok"]) {
    for (const cursor of ["1", "", "https://localhost", "opaque"]) {
      await assert.rejects(scanSource(id, cursor, noFetch), errorIs("INVALID_CURSOR"));
    }
  }
  for (const cursor of ["0", "01", "10001", "../../private", "1&search=private", "\n"]) {
    await assert.rejects(scanSource("arbeitnow", cursor, noFetch), errorIs("INVALID_CURSOR"));
  }
  assert.equal(calls, 0);
});

test("Arbeitnow rejects malicious, regressing and malformed next-page metadata", async () => {
  for (const next of [
    "https://evil.example.com/api/job-board-api?page=2",
    "https://www.arbeitnow.com.evil.example.com/api/job-board-api?page=2",
    "https://www.arbeitnow.com/redirect?page=2",
    "https://www.arbeitnow.com/api/job-board-api?page=1",
    "https://www.arbeitnow.com/api/job-board-api?page=3",
    "https://www.arbeitnow.com/api/job-board-api?page=2&search=secret",
    "https://www.arbeitnow.com/api/job-board-api?page=2&page=2",
    "http://www.arbeitnow.com/api/job-board-api?page=2"
  ]) {
    await assert.rejects(scanSource("arbeitnow", undefined, fixtureFetch(arbeitnowPayload([arbeitnowJob], 1, next))), errorIs("INVALID_DATA"));
  }
  for (const payload of [
    arbeitnowPayload([], 1, "https://www.arbeitnow.com/api/job-board-api?page=2"),
    arbeitnowPayload([arbeitnowJob], 2),
    { ...arbeitnowPayload(), links: {} },
    { ...arbeitnowPayload(), meta: { current_page: 1, per_page: 251 } }
  ]) await assert.rejects(scanSource("arbeitnow", undefined, fixtureFetch(payload)), errorIs("INVALID_DATA"));
});

test("additional feeds reject malformed records, metadata, duplicates and off-provider links", async () => {
  for (const [id, payloads] of [
    ["remotive", [
      {}, { ...remotivePayload(), "job-count": 2 }, remotivePayload([remotiveJob, remotiveJob]),
      remotivePayload([{ ...remotiveJob, salary: 100 }]),
      remotivePayload([{ ...remotiveJob, id: -1 }]),
      remotivePayload([{ ...remotiveJob, candidate_required_location: ["India"] }]),
      remotivePayload([{ ...remotiveJob, url: "https://evil.example.com/job" }])
    ]],
    ["arbeitnow", [
      {}, arbeitnowPayload([arbeitnowJob, arbeitnowJob]),
      arbeitnowPayload([{ ...arbeitnowJob, remote: "true" }]),
      arbeitnowPayload([{ ...arbeitnowJob, visa_sponsorship: "yes" }]),
      arbeitnowPayload([{ ...arbeitnowJob, slug: "../../foo" }]),
      arbeitnowPayload([{ ...arbeitnowJob, url: "https://evil.example.com/job" }])
    ]],
    ["remoteok", [
      {}, [], [remoteokJob], [{ legal: remoteokMetadata.legal }],
      [remoteokMetadata, remoteokJob, remoteokJob],
      [remoteokMetadata, { ...remoteokJob, salary_min: "120000" }],
      [remoteokMetadata, { ...remoteokJob, position: "<script>nothing</script>" }],
      [remoteokMetadata, { ...remoteokJob, url: "https://evil.example.com/job" }]
    ]]
  ] as const) {
    for (const payload of payloads) await assert.rejects(scanSource(id, undefined, fixtureFetch(payload)), errorIs("INVALID_DATA"));
  }
});

test("new feeds refuse redirects and honor Retry-After without retrying", async () => {
  for (const id of ["remotive", "arbeitnow", "remoteok"]) {
    let calls = 0;
    const redirect = (async () => {
      calls++;
      return new Response(null, { status: 302, headers: { Location: "https://127.0.0.1/private" } });
    }) as typeof fetch;
    await assert.rejects(scanSource(id, undefined, redirect), errorIs("REDIRECT"));
    assert.equal(calls, 1);
    await assert.rejects(scanSource(id, undefined, (async () => new Response("private provider body", {
      status: 429, headers: { "Retry-After": "86400" }
    })) as typeof fetch), (error: unknown) => {
      assert.ok(error instanceof DiscoveryError);
      assert.equal(error.retryAfterMs, 86_400_000);
      assert.equal(error.code, "RATE_LIMITED");
      assert.doesNotMatch(error.message, /private/);
      return true;
    });
  }
});

test("cloud validation preserves new source attribution and rejects changed attribution hosts", async () => {
  for (const [id, payload] of [
    ["remotive", remotivePayload()], ["arbeitnow", arbeitnowPayload()],
    ["remoteok", [remoteokMetadata, remoteokJob]]
  ] as const) {
    const [job] = (await scanSource(id, undefined, fixtureFetch(payload))).jobs;
    const normalized = validatePublicJob({ ...job, description: "Public job text", candidateAccount: "not retained" });
    assert.match(normalized.description, new RegExp(`Original source: ${getSource(id)!.name}`));
    assert.equal("candidateAccount" in normalized, false);
    assert.throws(() => validatePublicJob({ ...job, canonicalUrl: "https://evil.example.com/job" }), errorIs("INVALID_DATA"));
  }
});
