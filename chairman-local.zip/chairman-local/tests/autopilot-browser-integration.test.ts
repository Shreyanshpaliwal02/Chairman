import assert from "node:assert/strict";
import test from "node:test";
import { createHash, randomUUID } from "node:crypto";
import { mkdir, readFile, rm, rmdir, stat } from "node:fs/promises";
import { createServer } from "node:http";
import type { AddressInfo, Socket } from "node:net";
import { basename, join, resolve } from "node:path";
import { Document, Packer, Paragraph } from "docx";
import { AutopilotService } from "../apps/local/autopilot.js";
import { Engine } from "../apps/local/engine.js";
import { ResumeLibrary } from "../apps/local/resume-library.js";
import { Store } from "../apps/local/store.js";
import { CareerSourceService } from "../apps/local/career-sources.js";
import { ApplicationBrowser } from "../packages/automation/browser.js";
import { providerFixtureHtml } from "../packages/automation/testing/provider-fixture.js";
import { extractPdfText } from "../packages/documents/index.js";
import type { CareerBoardTarget, ReferenceFamily, ResumeVariant } from "../packages/domain/types.js";
import { jobFixture, profileFixture } from "./fixtures.js";

for (const strategy of ["original", "job-tailored"] as const) test(`standing authorization with two resumes submits ${strategy} bytes through the real services and Chrome`, { timeout: 90_000 }, async () => {
  const root = resolve(".autopilot-browser-integration");
  const directory = join(root, randomUUID());
  await mkdir(directory, { recursive: true, mode: 0o700 });
  const path = "/fixture/jobs/100";
  const payloads: {
    answers: Record<string, string>;
    resume: { name: string; type: string; bytes: string };
    optionalFiles: number[];
    marketing: boolean;
  }[] = [];
  const sockets = new Set<Socket>();
  let store: Store | undefined;
  let browser: ApplicationBrowser | undefined;
  let service: AutopilotService | undefined;
  let careers: CareerSourceService | undefined;
  let durableBoundaryAtUpload = false;
  let executingAtUpload = false;
  const server = createServer(async (request, response) => {
    if (request.url !== path) { response.writeHead(404); response.end(); return; }
    if (request.method === "POST") {
      const chunks: Buffer[] = [];
      for await (const chunk of request) chunks.push(Buffer.from(chunk));
      payloads.push(JSON.parse(Buffer.concat(chunks).toString("utf8")));
      durableBoundaryAtUpload = Number(store?.db.prepare("SELECT count(*) AS n FROM events WHERE type='submit_started'").get()?.n) === 1;
      executingAtUpload = store?.packets()[0]?.status === "executing";
      response.writeHead(200, { "Content-Type": "application/json" });
      response.end('{"received":true}');
      return;
    }
    response.writeHead(200, { "Content-Type": "text/html" });
    response.end(providerFixtureHtml("greenhouse", "integration", path));
  });
  server.on("connection", socket => { sockets.add(socket); socket.on("close", () => sockets.delete(socket)); });

  try {
    await new Promise<void>(resolve => server.listen(0, "127.0.0.1", resolve));
    const origin = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
    store = new Store(join(directory, "test.sqlite"));
    const profile = profileFixture();
    profile.name = "Riley Jordan";
    profile.email = "riley.jordan@example.test";
    profile.answers = { country: "India", schedule: "r", notes: "Approved local integration note.", total_years_experience: "3" };
    store.set("profile", profile);
    const engine = new Engine(store, directory, [], false, origin);
    const library = new ResumeLibrary(store, directory);
    browser = new ApplicationBrowser({ userDataDir: join(directory, "chrome-profile"), headless: true, testOrigins: [origin] });
    const job = jobFixture({
      id: randomUUID(), sourceId: "local-greenhouse", sourceJobId: "100",
      applyUrl: `${origin}${path}`, canonicalUrl: "https://himalayas.app/companies/example/jobs/data-engineer",
    });
    const target: CareerBoardTarget = { provider: "greenhouse", board: "fixture", boardUrl: "https://job-boards.greenhouse.io/fixture" };
    careers = new CareerSourceService(store, {
      resolve: async () => ({ target, candidates: [target], message: "Synthetic career board." }),
      scan: async (_target, sourceId) => ({ jobs: [{ ...job, sourceId }] })
    });
    service = new AutopilotService(store, engine, library, directory, { browser, allowTestJobs: true, careerSources: careers });
    service.setRules({ ...service.view().rules, resumeStrategy: strategy, tailoringMode: "deterministic" });
    const career = await careers.add(target.boardUrl, "Fixture career link");
    for (let attempt = 0; attempt < 100 && !store.job(job.id); attempt++) await new Promise(resolve => setTimeout(resolve, 5));
    assert.ok(store.job(job.id));
    assert.equal(careers.get(career.source!.id).jobCount, 1);
    assert.equal(service.view().enabled, false);

    const families: ReferenceFamily[] = ["software", "data"];
    const variants: ResumeVariant[] = [];
    const originalBytes: Buffer[] = [];
    for (const [index, family] of families.entries()) {
      const text = family === "data"
        ? "Data Engineer. Built Python, SQL, Apache Kafka and Apache Spark data pipelines on AWS."
        : `${family} engineer. Built applications and maintained production services.`;
      const bytes = await Packer.toBuffer(new Document({ sections: [{ children: [
        new Paragraph("Riley Jordan"), new Paragraph("riley.jordan@example.test"),
        new Paragraph(text),
        new Paragraph("Example University, Engineering, 2023. Fictional record used exclusively for local integration testing."),
      ] }] }));
      originalBytes.push(bytes);
      variants.push(await library.upload(index === 0 ? 2 : 4, `${family}.docx`, bytes, `${family} resume`, [family], true));
    }
    assert.equal(library.list().length, 2);
    assert.ok(library.list().every(variant => variant.approved && variant.issues.length === 0));
    assert.equal(store.packets().length, 0);
    assert.equal(payloads.length, 0);
    assert.equal(service.view().ready, true, service.view().blockers.join("; "));

    const activationHash = service.snapshotHash();
    await service.enable(activationHash);
    const deadline = Date.now() + 45_000;
    while (Date.now() < deadline) {
      const status = service.view().jobs[0]?.status;
      if (status && !["queued", "inspecting", "submitting"].includes(status)) break;
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    const view = service.view();
    assert.equal(view.jobs[0]?.status, "submitted_confirmed", view.jobs[0]?.reason ?? view.status);
    assert.equal(view.enabled, true);
    assert.equal(view.authorization?.snapshotHash, activationHash);
    assert.equal(store.packets().length, 1);
    const packet = store.packets()[0]!;
    const selected = variants[1]!;
    assert.equal(packet.variantId, selected.id);
    assert.equal(packet.sourceId, career.source!.id);
    assert.equal(packet.draft.mode, strategy === "original" ? "uploaded-variant" : "jd-tailored");
    assert.equal(packet.approvedBy, "autopilot");
    assert.equal(packet.authorizationId, view.authorization?.id);
    assert.equal(packet.status, "submitted_confirmed");
    assert.equal(packet.artifacts.length, strategy === "original" ? 1 : 2);
    const submittedArtifact = engine.submissionArtifact(packet);
    const privatePath = join(engine.directory(packet.id), submittedArtifact.filename);
    assert.notEqual(basename(privatePath), selected.originalFilename);
    if (strategy === "original") {
      assert.equal(basename(privatePath), `${selected.artifact.sha256}.docx`);
      assert.deepEqual(await readFile(privatePath), originalBytes[1]);
      assert.equal((await stat(privatePath)).ino, (await stat(library.path(selected.id))).ino);
    } else {
      assert.equal(packet.tailoring!.baseVariantSha256, selected.artifact.sha256);
      assert.equal(packet.submissionArtifactSha256, submittedArtifact.sha256);
      assert.notEqual(submittedArtifact.sha256, selected.artifact.sha256);
    }

    assert.equal(payloads.length, 1);
    assert.equal(payloads[0]!.resume.name, strategy === "original" ? "data.docx" : `resume-${packet.id}.pdf`);
    assert.equal(payloads[0]!.resume.type, strategy === "original" ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : "application/pdf");
    const transmitted = Buffer.from(payloads[0]!.resume.bytes, "base64");
    assert.deepEqual(transmitted, await readFile(privatePath));
    assert.equal(createHash("sha256").update(transmitted).digest("hex"), submittedArtifact.sha256);
    assert.deepEqual(await library.bytes(selected.id), originalBytes[1]);
    if (strategy === "job-tailored") {
      const text = await extractPdfText(transmitted);
      assert.ok(text.includes(profile.email));
      assert.ok(text.includes("Kafka"));
      assert.deepEqual(packet.resumeContent!.facts, packet.draft.factIds.map(id => profile.facts.find(fact => fact.id === id)));
    }
    assert.deepEqual(payloads[0]!.answers, {
      first_name: "Riley", email: "riley.jordan@example.test", work: "authorized", country: "India", schedule: "r",
    });
    assert.deepEqual(payloads[0]!.optionalFiles, [0, 0]);
    assert.equal(payloads[0]!.marketing, false);
    assert.equal(durableBoundaryAtUpload, true);
    assert.equal(executingAtUpload, true);
    assert.equal(store.confirmedCount(), 1);
    assert.equal(store.attemptsSession(), 1);
    const receipt = JSON.parse(packet.confirmation!);
    assert.equal(receipt.provider, "greenhouse");
    assert.equal(receipt.url, job.applyUrl);
    assert.equal(receipt.receipt, "application-confirmation");
    assert.equal(receipt.formFingerprint, packet.formSnapshot?.fingerprint);
    assert.ok(!packet.confirmation!.includes(profile.email));
    const events = store.db.prepare("SELECT type FROM events ORDER BY rowid").all().map(row => String(row.type));
    assert.equal(events.filter(type => type === "autopilot_approved").length, 1);
    assert.equal(events.filter(type => type === "submit_started").length, 1);
    assert.equal(events.filter(type => type === "approved").length, 0);
    assert.ok(events.indexOf("submit_started") < events.indexOf("submitted_confirmed"));
    assert.throws(() => service!.retry(view.jobs[0]!.id), /cannot be automatically retried/);
    careers.setEnabled(career.source!.id, false);
    assert.equal(service.view().enabled, false);
  } finally {
    await service?.close();
    await careers?.close();
    await browser?.close();
    store?.close();
    for (const socket of sockets) socket.destroy();
    if (server.listening) await new Promise<void>(resolve => server.close(() => resolve()));
    await rm(directory, { recursive: true, force: true });
    await rmdir(root).catch((error: NodeJS.ErrnoException) => {
      if (error.code !== "ENOTEMPTY" && error.code !== "ENOENT") throw error;
    });
  }
});
