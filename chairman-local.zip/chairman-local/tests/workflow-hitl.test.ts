import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { Document, Packer, Paragraph } from "docx";
import type { ApplicationBrowserDriver, WorkflowInput, WorkflowResult, HumanContinuation } from "../packages/automation/contracts.js";
import { Store } from "../apps/local/store.js";
import { Engine, snapshotHash } from "../apps/local/engine.js";
import { ResumeLibrary } from "../apps/local/resume-library.js";
import { AutopilotService } from "../apps/local/autopilot.js";
import { jobFixture, profileFixture } from "./fixtures.js";
import type { FormSnapshot } from "../packages/domain/types.js";

class PartialPortal implements ApplicationBrowserDriver {
  saved?: WorkflowInput;
  submissions = 0;
  inspected = 0;
  focused = "";
  snapshot!: FormSnapshot;
  async inspect() { return { status: "unsupported" as const, reason: "Monitored path only" }; }
  async submit(): Promise<never> { throw new Error("The old submit path must not be called."); }
  async openForSetup() {}
  isRunning() { return Boolean(this.saved); }
  async close() {}
  async runWorkflow(input: WorkflowInput): Promise<WorkflowResult> {
    this.saved = input; this.inspected++;
    assert.equal(await input.checkAuthorization(), true);
    const plan = await input.resolveAnswers(this.snapshot);
    assert.ok(plan.missing.length);
    assert.equal(plan.answers.full_name, "Riley Jordan");
    await input.beforeTransmit(this.snapshot, plan.answers, false);
    const progress = { phase: "awaiting_human" as const, message: "Known fields and resume filled; one factual answer is needed.", step: 1, url: input.job.applyUrl,
      filledFields: ["Full name", "Email", "Resume"], missingFields: this.snapshot.fields.filter(field => field.key === "custom_answer") };
    await input.onProgress(progress);
    return { status: "human_required", sessionId: "held-session", progress, reason: "Please provide your answer to the employer's question." };
  }
  async resumeWorkflow(sessionId: string, continuation: HumanContinuation): Promise<WorkflowResult> {
    assert.equal(sessionId, "held-session");
    const input = this.saved!;
    const plan = await input.resolveAnswers(this.snapshot, continuation.answers);
    assert.equal(plan.missing.length, 0);
    await input.beforeTransmit(this.snapshot, plan.answers, true);
    const bytes = await readFile(input.resumePath);
    assert.equal(createHash("sha256").update(bytes).digest("hex"), input.resumeSha256);
    await input.beforeSubmit(); this.submissions++;
    return { status: "submitted_confirmed", evidence: "Synthetic portal receipt HITL-123", reason: "Application received." };
  }
  async focusWorkflow(sessionId: string) { this.focused = sessionId; }
  async abandonWorkflow() {}
}

test("partial autofill parks a durable task and resumes the same application without a second attempt", async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-human-flow-")), store = new Store(join(dir, "state.sqlite"));
  const profile = profileFixture(); profile.name = "Riley Jordan"; profile.email = "riley.jordan@example.test"; store.set("profile", profile);
  const library = new ResumeLibrary(store, dir), engine = new Engine(store, dir, [], false, "http://127.0.0.1:4318");
  const job = jobFixture({ applyUrl: "https://careers.example.com/jobs/100", canonicalUrl: "https://careers.example.com/jobs/100" }); store.saveJob(job);
  const browser = new PartialPortal();
  browser.snapshot = { url: job.applyUrl, fields: [
    { key: "full_name", label: "Full name", type: "text", required: true, options: [] },
    { key: "email", label: "Email", type: "email", required: true, options: [] },
    { key: "custom_answer", label: "Which delivery team would you prefer?", type: "text", required: true, options: [] },
    { key: "resume", label: "Resume", type: "file", required: true, options: [] }
  ], fingerprint: "", hasCaptcha: false, hasLegal: false, unsupported: [] };
  browser.snapshot.fingerprint = snapshotHash(browser.snapshot);
  const service = new AutopilotService(store, engine, library, dir, { browser });
  try {
    const bytes = await Packer.toBuffer(new Document({ sections: [{ children: [new Paragraph(profile.name), new Paragraph(profile.email),
      new Paragraph("Data engineer. Built Python, SQL and Apache Kafka pipelines on AWS. Fictional local testing experience only.")] }] }));
    for (const slot of [1, 3]) await library.upload(slot, "resume.docx", bytes, `Data variant ${slot}`, ["data"], true);
    await service.enable(service.snapshotHash());
    for (let n = 0; n < 300 && !service.view().humanTasks?.length; n++) await new Promise(resolve => setTimeout(resolve, 10));
    const task = service.view().humanTasks![0]!;
    assert.equal(task.status, "waiting");
    assert.equal("runToken" in task, false);
    assert.equal(store.packets()[0]!.status, "awaiting_human");
    assert.equal(store.attemptsSession(), 1);
    assert.equal(store.confirmedCount(), 0);
    assert.equal(store.hasConflictingApplication(job.id), true);
    assert.ok(service.view().liveEvents!.some(event => event.phase === "awaiting_human"));
    await service.focusHuman(task.id); assert.equal(browser.focused, task.sessionId);
    service.continueHuman(task.id, { answers: { custom_answer: "Data platform team" }, useCurrentValues: false });
    for (let n = 0; n < 300 && store.confirmedCount() === 0; n++) {
      service.kick(); await new Promise(resolve => setTimeout(resolve, 10));
    }
    assert.equal(store.confirmedCount(), 1);
    assert.equal(store.attemptsSession(), 1);
    assert.equal(browser.inspected, 1); assert.equal(browser.submissions, 1);
    assert.equal(store.packets()[0]!.workflowSteps!.at(-1)!.humanSupplied, true);
    assert.equal(service.view().humanTasks![0]!.status, "resolved");
  } finally { await service.close(); store.close(); await rm(dir, { recursive: true, force: true }); }
});
