import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, stat, chmod, symlink } from "node:fs/promises";
import { join, resolve } from "node:path";
import test from "node:test";
import { createGeminiKeyStore, geminiKeyRequestSchema } from "../apps/local/gemini-key.js";
import { inferenceConfigSchema, applyInferenceConfig } from "../apps/local/inference-config.js";
import { geminiInference } from "../packages/inference/gemini.js";
import { configuredAiAvailable } from "../apps/dashboard/src/model.js";

const key = `AIza${"y".repeat(35)}`;
const config = { provider: "gemini" as const, model: "gemini-2.5-flash", allowRemoteProcessing: true, acknowledgeUsage: true, confirmFreeTier: true };

test("inference config never accepts keys or custom Gemini models in exported SQLite settings", () => {
  for (const field of ["apiKey", "key", "geminiApiKey", "GEMINI_API_KEY"]) {
    assert.equal(inferenceConfigSchema.safeParse({ ...config, [field]: key }).success, false);
  }
  for (const model of ["auto", "gemini-pro", "gemini-2.5-flash-latest", "https://example.invalid"]) {
    assert.equal(inferenceConfigSchema.safeParse({ ...config, model }).success, false);
  }
  for (const provider of ["gemini", "copilot", "ollama"]) {
    assert.equal(inferenceConfigSchema.safeParse({ ...config, provider, model: key }).success, false);
  }
  assert.deepEqual(inferenceConfigSchema.parse(config), config);
  assert.equal(geminiKeyRequestSchema.safeParse({ apiKey: key, provider: "gemini" }).success, false);
  assert.equal(geminiKeyRequestSchema.safeParse({ apiKey: key, revoke: true }).success, false);
});

test("switching providers revokes other remote permissions and Gemini requires all three confirmations", () => {
  const names = ["JAA_AI_PROVIDER", "JAA_GEMINI_MODEL", "JAA_ALLOW_GEMINI_REMOTE", "JAA_GEMINI_FREE_TIER_CONFIRMED",
    "JAA_COPILOT_MODEL", "JAA_ALLOW_COPILOT_REMOTE", "JAA_OLLAMA_MODEL"];
  const previous = names.map(name => [name, process.env[name]] as const);
  try {
    const revision = geminiInference.credentialRevision();
    applyInferenceConfig(config);
    assert.notEqual(geminiInference.credentialRevision(), revision);
    assert.equal(process.env.JAA_ALLOW_GEMINI_REMOTE, "1");
    assert.equal(process.env.JAA_ALLOW_COPILOT_REMOTE, "0");
    for (const changed of [{ confirmFreeTier: false }, { confirmFreeTier: undefined }, { acknowledgeUsage: false }, { allowRemoteProcessing: false }]) {
      applyInferenceConfig({ ...config, ...changed });
      assert.equal(process.env.JAA_ALLOW_GEMINI_REMOTE, "0");
    }
    applyInferenceConfig({ provider: "copilot", model: "gpt-6-astra", allowRemoteProcessing: true, acknowledgeUsage: true });
    assert.equal(process.env.JAA_ALLOW_COPILOT_REMOTE, "1");
    assert.equal(process.env.JAA_ALLOW_GEMINI_REMOTE, "0");
    assert.equal(process.env.JAA_GEMINI_FREE_TIER_CONFIRMED, "0");
    applyInferenceConfig({ provider: "ollama", allowRemoteProcessing: true, acknowledgeUsage: true });
    assert.equal(process.env.JAA_ALLOW_COPILOT_REMOTE, "0");
    assert.equal(process.env.JAA_ALLOW_GEMINI_REMOTE, "0");
    assert.equal(process.env.JAA_OLLAMA_MODEL, "qwen3:4b");
  } finally { for (const [name, value] of previous) { if (value === undefined) delete process.env[name]; else process.env[name] = value; } }
});

test("private key storage persists separately with owner permissions and revocation overrides environment fallback", async () => {
  const directory = await mkdtemp(resolve("tests/.gemini-keys-"));
  try {
    const env = { JAA_GEMINI_API_KEY: `AIza${"e".repeat(35)}` };
    const keys = createGeminiKeyStore(directory, () => env);
    await keys.load();
    assert.equal(keys.get(), env.JAA_GEMINI_API_KEY);
    await keys.save(key);
    assert.equal(keys.get(), key);
    const path = join(directory, "private", "gemini-key.json");
    assert.deepEqual(JSON.parse(await readFile(path, "utf8")), { apiKey: key });
    if (process.platform !== "win32") {
      assert.equal((await stat(path)).mode & 0o777, 0o600);
      assert.equal((await stat(join(directory, "private"))).mode & 0o777, 0o700);
    }
    const restarted = createGeminiKeyStore(directory, () => env);
    await restarted.load();
    assert.equal(restarted.get(), key);
    await restarted.revoke();
    assert.equal(restarted.get(), undefined);
    await keys.load();
    assert.equal(keys.get(), undefined);
    assert.deepEqual(JSON.parse(await readFile(path, "utf8")), { apiKey: null });
    await assert.rejects(keys.save("bad-key-sensitive"), error => error instanceof Error && !error.message.includes("bad-key-sensitive"));
  } finally { await rm(directory, { recursive: true, force: true }); }
});

test("private key storage rejects symlinks and overly broad POSIX file permissions", async () => {
  if (process.platform === "win32") return;
  const directory = await mkdtemp(resolve("tests/.gemini-key-permissions-"));
  try {
    const keys = createGeminiKeyStore(directory, () => ({}));
    await keys.save(key);
    const path = join(directory, "private", "gemini-key.json");
    await chmod(path, 0o644);
    await assert.rejects(keys.load(), /owner-only permissions/);
    await chmod(path, 0o600);
    await rm(path);
    await symlink(join(directory, "missing"), path);
    await assert.rejects(keys.load(), /owner-only permissions/);
  } finally { await rm(directory, { recursive: true, force: true }); }
});

test("Gemini UI availability cannot mistake a saved model or unverified Free project for readiness", () => {
  const ready = { available: true, provider: "gemini" as const, model: config.model, remote: true, authenticated: true,
    modelAvailable: true, consentRequired: false, keyConfigured: true, freeTierConfirmed: true, billingTierVerified: false as const };
  assert.equal(configuredAiAvailable(ready), true);
  for (const change of [{ freeTierConfirmed: false }, { keyConfigured: false }, { consentRequired: true }, { authenticated: undefined }, { remote: false }]) {
    assert.equal(configuredAiAvailable({ ...ready, ...change }), false);
  }
});
