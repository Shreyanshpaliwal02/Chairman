import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Store } from "../apps/local/store.js";
import { campaignConfig, campaignStats } from "../apps/local/campaign.js";
import { profileSchema } from "../apps/local/schemas.js";
import { profileFixture, jobFixture } from "./fixtures.js";
import type { Packet } from "../packages/domain/types.js";

test("legacy default ceiling migrates once without changing facts or confirmation", async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-migration-")), path = join(dir, "legacy.sqlite");
  const original = profileFixture(); original.preferences.dailyLimit = 200;
  const legacy = new DatabaseSync(path);
  legacy.exec("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)");
  legacy.prepare("INSERT INTO settings VALUES (?,?)").run("profile", JSON.stringify(original)); legacy.close();
  try {
    const migrated = new Store(path);
    assert.equal(migrated.profile().preferences.dailyLimit, null);
    assert.equal(migrated.profile().confirmed, original.confirmed);
    assert.deepEqual(migrated.profile().facts, original.facts);
    assert.equal(migrated.profile().version, original.version + 1);
    migrated.close();
    const again = new Store(path);
    assert.equal(again.profile().version, original.version + 1);
    const capped = again.profile(); capped.preferences.dailyLimit = 1000; again.set("profile", capped); again.close();
    const preserved = new Store(path);
    assert.equal(preserved.profile().preferences.dailyLimit, 1000); preserved.close();
    assert.equal(profileSchema.safeParse({ ...original, preferences: { ...original.preferences, dailyLimit: 5000 } }).success, true);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

function packet(id: string, jobId: string, submittedAt?: string): Packet {
  return { id, jobId, sourceId: "himalayas", profileVersion: 1, profileHash: "profile", jobHash: "job",
    draft: { factIds: ["exp-1"], skills: ["Python"], mode: "deterministic", notes: [] }, artifacts: [], answers: {},
    warnings: [], status: submittedAt ? "submitted_confirmed" : "prepared", createdAt: "2026-09-14T04:00:00Z", submittedAt };
}
test("45-day campaign is a 22,500 target, not attempts or fabricated confirmations", () => {
  const store = new Store(":memory:");
  try {
    const now = new Date("2026-09-15T10:00:00Z");
    const config = campaignConfig(store, new Date("2026-09-14T10:00:00Z"));
    assert.equal(config.days, 45); assert.equal(config.dailyTarget, 500);
    const job = jobFixture(); store.saveJob(job);
    const applied = packet("p1", job.id, "2026-09-14T20:00:00Z");
    applied.progress = { stage: "offer", note: "", nextActionDate: "2026-09-15", updatedAt: now.toISOString() };
    store.putPacket(applied);
    store.event("p1", "progress:interview", "User reported an interview.");
    store.event("p1", "progress:offer", "User reported an offer.");
    store.putPacket(packet("duplicate", job.id, "2026-09-14T20:01:00Z"));
    store.putPacket(packet("only-prepared", "not-submitted"));
    const unknownDate = packet("unknown-date", "legacy-job"); unknownDate.status = "submitted_confirmed"; store.putPacket(unknownDate);
    store.db.prepare("INSERT INTO runs(packet_id,job_id,source_id,token,day,status) VALUES (?,?,?,?,?,?)").run("attempt", "attempt-job", "himalayas", "test", "2026-09-15", "failed");
    const stats = campaignStats(store, now);
    assert.equal(stats.totalTarget, 22500); assert.equal(stats.endDate, "2026-10-28");
    assert.equal(stats.dayNumber, 2); assert.equal(stats.targetToDate, 1000); assert.equal(stats.daysRemaining, 44);
    assert.equal(stats.confirmedToday, 1); assert.equal(stats.confirmedTotal, 1);
    assert.equal(stats.interviews, 1); assert.equal(stats.offers, 1); assert.equal(stats.interviewRate, 100);
    assert.equal(stats.followUpsDue, 1); assert.equal(stats.untrackedSubmissionDates, 1);
    assert.equal(stats.daily[0]!.confirmed, 0); assert.equal(stats.daily[1]!.confirmed, 1);
    assert.equal(stats.sources[0]!.sourceId, "himalayas");
    store.saveJob({ ...job, sourceId: "supabase" });
    assert.equal(campaignStats(store, now).sources[0]!.sourceId, "himalayas");
    assert.equal(campaignStats(store, new Date("2026-11-01T00:00:00Z")).daysRemaining, 0);
  } finally { store.close(); }
});
