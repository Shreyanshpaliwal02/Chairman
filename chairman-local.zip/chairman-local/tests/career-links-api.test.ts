import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "../apps/local/server.js";
import { jobFixture } from "./fixtures.js";
import type { CareerBoardTarget } from "../packages/domain/types.js";

test("career link API adds discovered jobs but leaves Auto Apply paused until fresh authorization", async () => {
  const directory = await mkdtemp(join(tmpdir(), "jaa-career-api-"));
  const target: CareerBoardTarget = { provider: "ashby", board: "example", boardUrl: "https://jobs.ashbyhq.com/example" };
  let requests = 0;
  const runtime = await createApp({ dataDir: directory, port: 4341, careerOptions: {
    resolve: async () => ({ target, candidates: [target], message: "Known public board." }),
    scan: async (_target, sourceId) => {
      requests++;
      return { jobs: [jobFixture({
        id: "custom-job", company: "Example", sourceId,
        applyUrl: "https://jobs.ashbyhq.com/example/12345678-1234-1234-1234-123456789abc/application",
        canonicalUrl: "https://jobs.ashbyhq.com/example/12345678-1234-1234-1234-123456789abc"
      })] };
    }
  } });
  const { app, store } = runtime;
  const host = { host: "127.0.0.1:4341" };
  try {
    assert.equal((await app.inject({ method: "POST", url: "/api/career-links", headers: host, payload: { url: target.boardUrl } })).statusCode, 401);
    const session = await app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = session.cookies[0]!;
    const headers = { ...host, cookie: `${cookie.name}=${cookie.value}` };
    const previousHash = runtime.autopilot.snapshotHash();
    const response = await app.inject({ method: "POST", url: "/api/career-links", headers, payload: { url: target.boardUrl, label: "Preferred engineering roles" } });
    assert.equal(response.statusCode, 200, response.body);
    const source = response.json().source;
    for (let n = 0; n < 100 && !runtime.careerSources.get(source.id).lastScannedAt; n++) await new Promise(resolve => setTimeout(resolve, 5));
    assert.equal(store.jobCount(), 1);
    assert.notEqual(runtime.autopilot.snapshotHash(), previousHash);
    assert.equal(runtime.autopilot.view().enabled, false);
    assert.equal(store.confirmedCount(), 0);
    const state = (await app.inject({ method: "GET", url: "/api/state", headers })).json();
    assert.equal(state.careerSources.length, 1);
    assert.equal(state.careerSources[0].jobCount, 1);
    assert.ok(state.sources.some((entry: { id: string }) => entry.id === source.id));
    assert.equal(requests, 1);
    const duplicate = await app.inject({ method: "POST", url: "/api/career-links", headers, payload: { url: target.boardUrl } });
    assert.equal(duplicate.json().source.id, source.id);
    assert.equal(requests, 1);
    const scanAgain = await app.inject({ method: "POST", url: `/api/career-links/${source.id}/scan`, headers, payload: {} });
    assert.equal(scanAgain.statusCode, 400);
    assert.match(scanAgain.json().error, /cooldown/);
    const paused = await app.inject({ method: "POST", url: `/api/career-links/${source.id}/enabled`, headers, payload: { enabled: false } });
    assert.equal(paused.statusCode, 200); assert.equal(paused.json().source.enabled, false);
    assert.equal(runtime.careerSources.allowsJob(store.jobs()[0]!), false);
    const removed = await app.inject({ method: "POST", url: `/api/career-links/${source.id}/remove`, headers, payload: {} });
    assert.equal(removed.statusCode, 200);
    assert.equal((await app.inject({ method: "GET", url: "/api/career-links", headers })).json().sources.length, 0);
    assert.equal(store.packets().length, 0);
  } finally { await app.close(); await rm(directory, { recursive: true, force: true }); }
});
