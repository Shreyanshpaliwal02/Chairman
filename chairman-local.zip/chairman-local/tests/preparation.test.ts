import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Store } from "../apps/local/store.js";
import { Engine } from "../apps/local/engine.js";
import { PreparationService } from "../apps/local/preparation.js";
import { profileFixture, jobFixture } from "./fixtures.js";

test("bulk preparation is local, durable, idempotent and never approves applications", async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-preparation-")), store = new Store(join(dir, "test.sqlite"));
  const engine = new Engine(store, dir, [], true, "http://127.0.0.1:4318"), service = new PreparationService(store, engine);
  try {
    store.set("profile", profileFixture()); store.saveJob(jobFixture());
    const task = service.enqueue(["fixture-job"], "deterministic")[0]!;
    assert.equal(service.enqueue(["fixture-job"], "deterministic")[0]!.id, task.id);
    store.putPreparation({ ...task, status: "running" }); service.recover();
    assert.equal(store.nextPreparation()!.status, "queued");
    await service.processNext();
    const done = store.preparationTasks()[0]!;
    assert.equal(done.status, "completed");
    assert.equal(store.packet(done.packetId!)!.status, "prepared");
    assert.equal(store.packets().length, 1);
    assert.equal(service.enqueue(["fixture-job"], "deterministic")[0]!.id, task.id);
    assert.equal(store.db.prepare("SELECT count(*) AS n FROM runs").get()?.n, 0);
  } finally { await service.stop(); store.close(); await rm(dir, { recursive: true, force: true }); }
});
test("501 distinct jobs can be queued, while changed profiles and Stop remain binding", async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-bulk-")), store = new Store(join(dir, "test.sqlite"));
  const engine = new Engine(store, dir, [], true, "http://127.0.0.1:4318"), service = new PreparationService(store, engine);
  try {
    store.set("profile", profileFixture());
    for (let n = 0; n < 501; n++) store.saveJob(jobFixture({ id: `job-${n}`, canonicalUrl: `https://example.test/jobs/${n}` }));
    const tasks = service.enqueue(Array.from({ length: 501 }, (_, n) => `job-${n}`), "deterministic");
    assert.equal(tasks.length, 501);
    store.set("stopped", true); assert.equal(await service.processNext(), false);
    store.set("stopped", false);
    const profile = store.profile(); profile.version++; store.set("profile", profile);
    await service.processNext();
    assert.match(store.preparationTasks().find(task => task.id === tasks[0]!.id)!.error!, /profile changed/i);
    assert.equal(service.cancel(), 500);
    assert.equal(store.preparationWithStatus("queued").length, 0);
  } finally { await service.stop(); store.close(); await rm(dir, { recursive: true, force: true }); }
});
