import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import type { ClientRequest, IncomingMessage } from "node:http";
import type { RequestOptions, request as httpsRequest } from "node:https";
import { Readable } from "node:stream";
import test from "node:test";
import { parseCareerTarget, resolveCareerLink, scanCareerBoard } from "../packages/adapters/career-links";
import { DiscoveryError, scanSource } from "../packages/adapters/discovery";
import { isPublicIpAddress, loadPublicCareerPage, MAX_PUBLIC_PAGE_BYTES } from "../packages/adapters/public-page";
import { canonicalApplicationUrl, providerForUrl } from "../packages/automation/providers";
import type { CareerBoardTarget } from "../packages/domain/types";

const id = "12345678-abcd-abcd-abcd-123456789012";
const ashby = parseCareerTarget("https://jobs.ashbyhq.com/fixture-team")!;
const greenhouse = parseCareerTarget("https://job-boards.greenhouse.io/fixtureteam")!;
const jsonFetch = (value: unknown) => (async () => Response.json(value)) as typeof fetch;
const errorIs = (code: string) => (error: unknown) => error instanceof DiscoveryError && error.code === code;
const ashbyJob = (jobId = id, board = ashby.board) => ({
  id: jobId, isListed: true, title: "Platform Engineer", descriptionHtml: "<p>Build reliable infrastructure.</p>",
  jobUrl: `https://jobs.ashbyhq.com/${board}/${jobId}`,
  applyUrl: `https://jobs.ashbyhq.com/${board}/${jobId}/application`,
  isRemote: true, location: "Remote", employmentType: "FullTime",
  publishedAt: "2026-01-01T00:00:00Z"
});
const greenhouseJob = (jobId = 1, board = greenhouse.board) => ({
  id: jobId, internal_job_id: jobId + 100, title: "Platform Engineer", company_name: "Fixture Team",
  content: "&lt;p&gt;Build reliable infrastructure.&lt;/p&gt;", location: { name: "Remote" },
  absolute_url: `https://job-boards.greenhouse.io/${board}/jobs/${jobId}`,
  questions: [], metadata: []
});
const greenhouseFetch = (count: number, transform: (row: ReturnType<typeof greenhouseJob>) => unknown = (row) => row, calls: string[] = []) => (async (input, init) => {
  const url = String(input);
  calls.push(url);
  assert.equal(init?.method, "GET");
  assert.equal(init?.redirect, "error");
  assert.equal(init?.credentials, "omit");
  if (!url.includes("?")) return Response.json({ jobs: Array.from({ length: count }, (_, i) => greenhouseJob(i + 1)) });
  const jobId = Number(/\/jobs\/(\d+)\?/.exec(url)![1]);
  return Response.json(transform(greenhouseJob(jobId)));
}) as typeof fetch;

test("career targets accept hosted boards, exact jobs, legacy links and documented embeds", async () => {
  assert.deepEqual(parseCareerTarget("https://jobs.ashbyhq.com/fixture-team/?utm_source=mail#openings"), ashby);
  assert.deepEqual(parseCareerTarget(`https://jobs.ashbyhq.com/fixture-team/${id.toUpperCase()}/application?source=mail`), { ...ashby, jobId: id });
  for (const host of ["boards.greenhouse.io", "job-boards.greenhouse.io"]) {
    assert.deepEqual(parseCareerTarget(`https://${host}/fixtureteam/?gh_src=tracking`), greenhouse);
    assert.deepEqual(parseCareerTarget(`https://${host}/fixtureteam/jobs/123/?utm_campaign=jobs`), { ...greenhouse, jobId: "123" });
    assert.deepEqual(parseCareerTarget(`https://${host}/embed/job_app?for=fixtureteam&token=123&gh_src=tracking`), { ...greenhouse, jobId: "123" });
    assert.deepEqual(parseCareerTarget(`https://${host}/embed/job_board?for=fixtureteam`), greenhouse);
  }
  let calls = 0;
  const result = await resolveCareerLink(ashby.boardUrl, {
    fetcher: (async () => { calls++; throw new Error("no network"); }) as typeof fetch,
    pageLoader: async () => { calls++; throw new Error("no network"); }
  });
  assert.deepEqual(result.target, ashby);
  assert.equal(calls, 0);
});

test("unsafe, private and blocked inputs are rejected before either injected transport", async () => {
  let calls = 0;
  const options = { pageLoader: async () => { calls++; return ""; }, fetcher: (async () => { calls++; return new Response(""); }) as typeof fetch };
  for (const url of [
    "http://careers.example.com/", "file:///etc/passwd", "javascript:alert(1)", "https://name:password@careers.example.com/",
    "https://@careers.example.com/", "https://careers.example.com:443/", "https://careers.example.com:8443/",
    " https://careers.example.com/", "https://careers.example.com/\n", "https://careers.example.com\\@127.0.0.1/",
    "https://careers.example.com/foo/../careers", "https://careers.example.com/%2e%2e/careers", "https://careers.example.com/%252e%252e/careers",
    "https://careers.example.com/%2Fprivate", "https://careers.example.com/a//b", "https://careers%2eexample.com/",
    "https://127.0.0.1/", "https://127.1/", "https://2130706433/", "https://0x7f000001/", "https://[::1]/",
    "https://[::ffff:127.0.0.1]/", "https://localhost/", "https://a.internal/", "https://a.local/", "https://a.test/",
    "https://linkedin.com/jobs", "https://www.linkedin.com/jobs", "https://lnkd.in/abc", "https://wellfound.com/jobs",
    "https://angel.co/jobs", "https://angellist.com/jobs", "https://www.naukri.com/jobs",
    "https://app.ashbyhq.com/", "https://api.ashbyhq.com/", "https://app.greenhouse.io/", "https://boards-api.greenhouse.io/",
    "https://mygreenhouse.io/", "https://careers.example.com/login", "https://careers.example.com/candidate/profile",
    "https://careers.example.com/api/jobs", "https://careers.example.com/?access_token=private",
    "https://careers.example.com/?for=fixtureteam&token=123", "https://careers.example.com/?url=https://jobs.ashbyhq.com/fixture-team"
  ]) {
    assert.equal(parseCareerTarget(url), undefined, url);
    const result = await resolveCareerLink(url, options);
    assert.equal(result.target, undefined, url);
    assert.equal(result.candidates.length, 0, url);
    assert.match(result.message, /unsafe|private|hosted|manual/i);
  }
  assert.equal(calls, 0);
});

test("unsupported hosted routes and ambiguous query identities never become entire boards", async () => {
  for (const url of [
    "https://jobs.ashbyhq.com.evil.com/fixture-team",
    "https://jobs.ashbyhq.com/fixture-team/not-a-uuid",
    `https://jobs.ashbyhq.com/fixture-team/${id}/anything`,
    "https://jobs.ashbyhq.com/fixture-team?jobId=123",
    "https://boards.greenhouse.io/fixtureteam?gh_jid=123",
    "https://boards.greenhouse.io/fixtureteam/jobs/0",
    "https://boards.greenhouse.io/fixtureteam/jobs/01",
    "https://boards.greenhouse.io/fixtureteam/jobs/9007199254740992",
    "https://boards.greenhouse.io/embed/job_app?for=fixtureteam",
    "https://boards.greenhouse.io/embed/job_app?for=fixtureteam&for=other&token=123",
    "https://boards.greenhouse.io/embed/job_app?for=fixtureteam&token=123&token=456",
    "https://boards.greenhouse.io/embed/job_app?for=..%2Fprivate&token=123",
    "https://boards.greenhouse.io/embed/job_app?for=fixtureteam&token=123&redirect=https://127.0.0.1",
    "https://boards.greenhouse.io/embed/job_board?for=fixtureteam&token=123",
    "https://boards.greenhouse.io/jobs/fixtureteam/jobs/123"
  ]) assert.equal(parseCareerTarget(url), undefined, url);
  const result = await resolveCareerLink("https://jobs.ashbyhq.com/fixture-team/not-a-uuid", { pageLoader: async () => { throw new Error("must not load"); } });
  assert.equal(result.target, undefined);
});

test("generic HTML resolves actual links once, strips tracking, and does not execute or crawl", async () => {
  const requests: string[] = [];
  const result = await resolveCareerLink("https://careers.example.com/careers?utm_source=private#jobs", {
    pageLoader: async (url) => {
      requests.push(url);
      return `<!-- <a href="https://jobs.ashbyhq.com/comment">not a link</a> -->
        <script>window.location="https://jobs.ashbyhq.com/script";</script>
        <textarea><a href="https://jobs.ashbyhq.com/text">text</a></textarea>
        <div data-href="https://jobs.ashbyhq.com/data" title="<a href='https://jobs.ashbyhq.com/fake'>">
          https://jobs.ashbyhq.com/plain <a href="/other-careers">another page</a>
          <a href="//boards.greenhouse.io/fixtureteam/jobs/123?gh_src=x">Job</a>
          <iframe src="https://job-boards.greenhouse.io/embed/job_app?for=fixtureteam&amp;token=123"></iframe>
          <iframe src="/unloaded"><a href="https://jobs.ashbyhq.com/fallback">fallback is not HTML</a></iframe>
        </div>`;
    },
    fetcher: (async () => { throw new Error("generic pages must never use fetch"); }) as typeof fetch
  });
  assert.deepEqual(requests, ["https://careers.example.com/careers"]);
  assert.deepEqual(result.target, { ...greenhouse, jobId: "123" });
});

test("multiple destinations require choice, deduplicate canonical identities, and preserve job-only scope", async () => {
  const result = await resolveCareerLink("https://careers.example.com/", { pageLoader: async () => `
    <a href="${ashby.boardUrl}">Ashby</a><a href="${ashby.boardUrl}/?utm_source=foo">duplicate</a>
    <a href="https://boards.greenhouse.io/fixtureteam">Greenhouse</a>
    <a href="${ashby.boardUrl}/${id}/application">One job, not an entire board</a>
  ` });
  assert.equal(result.target, undefined);
  assert.deepEqual(result.candidates, [ashby, greenhouse, { ...ashby, jobId: id }]);
  assert.match(result.message, /Choose/);
  for (const html of [
    "<script>const url='https://jobs.ashbyhq.com/fixture-team';</script>",
    `<a data-href="${ashby.boardUrl}">missing href</a>`,
    `<template><template></template><a href="${ashby.boardUrl}">template</a></template>`,
    `<a href="https://jobs.ashbyhq.com/other/../fixture-team">unsafe spelling</a>`
  ]) {
    const empty = await resolveCareerLink("https://careers.example.com/", { pageLoader: async () => html });
    assert.equal(empty.target, undefined);
    assert.deepEqual(empty.candidates, []);
    assert.match(empty.message, /manual bookmark/);
  }
});

test("injected pages retain the same size and time limits and preserve cooldown errors", async (context) => {
  await assert.rejects(resolveCareerLink("https://careers.example.com/", { pageLoader: async () => "é".repeat(MAX_PUBLIC_PAGE_BYTES / 2 + 1) }), errorIs("TOO_LARGE"));
  for (const status of [429, 503]) {
    const error = new DiscoveryError(status === 429 ? "RATE_LIMITED" : "HTTP_ERROR", "Request deferred.", 30_000, status);
    await assert.rejects(resolveCareerLink("https://careers.example.com/", { pageLoader: async () => { throw error; } }), (caught) => caught === error);
  }
  context.mock.timers.enable({ apis: ["setTimeout"] });
  const pending = resolveCareerLink("https://careers.example.com/", { pageLoader: async () => new Promise<string>(() => {}) });
  context.mock.timers.tick(15_000);
  await assert.rejects(pending, errorIs("TIMEOUT"));
});

test("public DNS filtering rejects special IPv4/IPv6 ranges including mapped and transition addresses", () => {
  for (const address of [
    "0.0.0.0", "10.1.2.3", "100.100.100.200", "127.0.0.1", "169.254.169.254", "172.16.1.2", "172.31.255.255",
    "192.0.0.1", "192.168.1.1", "192.0.2.2", "192.88.99.1", "198.18.0.1", "198.51.100.2", "203.0.113.1",
    "224.1.1.1", "255.255.255.255", "168.63.129.16", "::", "::1", "::ffff:127.0.0.1", "::ffff:8.8.8.8",
    "::ffff:7f00:1", "::192.168.1.1", "fc00::1", "fd00::1", "fe80::1", "fe80::1%en0", "ff02::1",
    "64:ff9b::a00:1", "2001::1", "2001:db8::1", "2002:7f00:1::", "3fff::1", "not-an-address"
  ]) assert.equal(isPublicIpAddress(address), false, address);
  for (const address of ["8.8.8.8", "93.184.215.14", "172.32.0.1", "2606:4700:4700::1111", "2001:4860:4860::8888"]) {
    assert.equal(isPublicIpAddress(address), true, address);
  }
});

function transport(fixtures: { status?: number; headers?: Record<string, string>; body?: string; chunks?: Buffer[] }[]) {
  const calls: RequestOptions[] = [];
  const request = ((options: RequestOptions, callback: (res: IncomingMessage) => void) => {
    calls.push(options);
    const fixture = fixtures[calls.length - 1];
    assert.ok(fixture, "Unexpected extra network request");
    const req = new EventEmitter() as ClientRequest;
    req.destroy = () => req;
    req.end = (() => {
      queueMicrotask(() => {
        const response = Readable.from(fixture.chunks ?? [Buffer.from(fixture.body ?? "")]) as IncomingMessage;
        response.statusCode = fixture.status ?? 200;
        response.headers = { "content-type": "text/html; charset=utf-8", ...fixture.headers };
        callback(response);
      });
      return req;
    }) as ClientRequest["end"];
    return req;
  }) as typeof httpsRequest;
  const names: string[] = [];
  const resolve = async (hostname: string) => { names.push(hostname); return [{ address: "93.184.215.14", family: 4 }]; };
  return { request, resolve, calls, names };
}

test("generic HTTPS pins validated DNS, original SNI and Host with no ambient credentials", async () => {
  const network = transport([{ body: `<a href="${ashby.boardUrl}">Jobs</a>` }]);
  assert.match(await loadPublicCareerPage("https://careers.example.com/jobs?utm_source=not-forwarded", network), /Jobs/);
  const options = network.calls[0]!;
  assert.equal(options.hostname, "careers.example.com");
  assert.equal(options.servername, "careers.example.com");
  assert.equal(options.family, 4);
  assert.equal(options.method, "GET");
  assert.equal(options.path, "/jobs");
  assert.equal(options.agent, false);
  assert.equal(options.rejectUnauthorized, true);
  assert.equal(options.auth, undefined);
  const headers = new Headers(options.headers as Record<string, string>);
  assert.equal(headers.get("host"), "careers.example.com");
  for (const name of ["cookie", "authorization", "referer"]) assert.equal(headers.get(name), null);
  const pinned = await new Promise<string>((resolve, reject) => options.lookup!("careers.example.com", {}, (error, address) => error ? reject(error) : resolve(String(address))));
  assert.equal(pinned, "93.184.215.14");
  assert.deepEqual(network.names, ["careers.example.com"]);
  const ipv6 = transport([{ body: "IPv6" }]);
  await loadPublicCareerPage("https://careers.example.com/", { ...ipv6, resolve: async () => [{ address: "2606:4700::1111", family: 6 }] });
  assert.equal(ipv6.calls[0]!.family, 6);
});

test("every redirect is validated before DNS or HTTPS and chains stop after three redirects", async () => {
  for (const location of [
    "http://careers.example.com/", "https://127.0.0.1/", "https://[::1]/", "https://user:password@careers.example.com/",
    "https://careers.example.com:443/", "https://www.linkedin.com/jobs", "https://careers.example.com/private",
    "https://careers.example.com/%2e%2e/jobs", "/foo/../jobs", "/jobs?token=private", "//app.greenhouse.io/"
  ]) {
    const network = transport([{ status: 302, headers: { location } }]);
    await assert.rejects(loadPublicCareerPage("https://careers.example.com/", network), errorIs("INVALID_DATA"));
    assert.equal(network.calls.length, 1, location);
    assert.equal(network.names.length, 1, location);
  }
  const success = transport([
    { status: 301, headers: { location: "/jobs" } },
    { status: 302, headers: { location: "https://jobs.example.com/open" } },
    { status: 307, headers: { location: "/careers?utm_source=dropped" } }, { body: "public careers" }
  ]);
  assert.equal(await loadPublicCareerPage("https://careers.example.com/", success), "public careers");
  assert.equal(success.calls.length, 4);
  assert.deepEqual(success.names, ["careers.example.com", "careers.example.com", "jobs.example.com", "jobs.example.com"]);
  const loop = transport(Array.from({ length: 4 }, () => ({ status: 302, headers: { location: "/jobs" } })));
  await assert.rejects(loadPublicCareerPage("https://careers.example.com/", loop), errorIs("REDIRECT"));
  assert.equal(loop.calls.length, 4);
});

test("mixed/private DNS answers and redirect rebinding never create a private connection", async () => {
  for (const addresses of [
    [], [{ address: "127.0.0.1", family: 4 }],
    [{ address: "8.8.8.8", family: 4 }, { address: "::ffff:127.0.0.1", family: 6 }],
    [{ address: "8.8.8.8", family: 6 }]
  ]) {
    const network = transport([]);
    await assert.rejects(loadPublicCareerPage("https://careers.example.com/", { ...network, resolve: async () => addresses }), errorIs("INVALID_DATA"));
    assert.equal(network.calls.length, 0);
  }
  const network = transport([{ status: 302, headers: { location: "/careers" } }]);
  let lookups = 0;
  await assert.rejects(loadPublicCareerPage("https://careers.example.com/", {
    ...network, resolve: async () => [{ address: ++lookups === 1 ? "8.8.8.8" : "127.0.0.1", family: 4 }]
  }), errorIs("INVALID_DATA"));
  assert.equal(network.calls.length, 1);
});

test("generic network enforces byte/content/time budgets and Retry-After", async () => {
  for (const fixture of [
    { headers: { "content-length": String(MAX_PUBLIC_PAGE_BYTES + 1) } },
    { chunks: [Buffer.alloc(MAX_PUBLIC_PAGE_BYTES), Buffer.from("x")] }
  ]) await assert.rejects(loadPublicCareerPage("https://careers.example.com/", transport([fixture])), errorIs("TOO_LARGE"));
  for (const headers of [{ "content-type": "application/json" }, { "content-encoding": "gzip" }] as Record<string, string>[]) {
    await assert.rejects(loadPublicCareerPage("https://careers.example.com/", transport([{ headers }])), errorIs("INVALID_DATA"));
  }
  for (const status of [429, 503]) {
    await assert.rejects(loadPublicCareerPage("https://careers.example.com/", transport([{ status, headers: { "retry-after": "120" }, body: "private error" }])), (error: unknown) => {
      assert.ok(error instanceof DiscoveryError);
      assert.equal(error.httpStatus, status);
      assert.equal(error.retryAfterMs, 120_000);
      assert.doesNotMatch(error.message, /private error/);
      return true;
    });
  }
  const network = transport([]);
  await assert.rejects(loadPublicCareerPage("https://careers.example.com/", { ...network, resolve: async () => new Promise(() => {}), timeoutMs: 5 }), errorIs("TIMEOUT"));
  assert.equal(network.calls.length, 0);
});

test("Ashby scans fixed public endpoints with stable IDs independent of the user source and full honest fields", async () => {
  const payload = { jobs: [{
    ...ashbyJob(), descriptionHtml: "<p>Build databases.</p><p>Do not use AI tools to write your application.</p>",
    location: "Remote — United States only", address: { postalAddress: { addressCountry: "USA" } },
    compensation: { summaryComponents: [{ compensationType: "Salary", minValue: 100, maxValue: 200, currencyCode: "USD", interval: "1 HOUR" }] }
  }] };
  const fetcher = (async (input, init) => {
    assert.equal(String(input), "https://api.ashbyhq.com/posting-api/job-board/fixture-team?includeCompensation=true");
    assert.equal(init?.method, "GET"); assert.equal(init?.credentials, "omit"); assert.equal(init?.redirect, "error");
    assert.equal(new Headers(init?.headers).get("authorization"), null);
    assert.equal(new Headers(init?.headers).get("cookie"), null);
    assert.equal(init?.body, undefined);
    return Response.json(payload);
  }) as typeof fetch;
  const first = (await scanCareerBoard(ashby, "career-one", "My employer label", undefined, fetcher)).jobs[0]!;
  const second = (await scanCareerBoard({ ...ashby, jobId: id }, "career-two", "", undefined, fetcher)).jobs[0]!;
  assert.equal(first.id, `ashby:fixture-team:${id}`);
  assert.equal(first.id, second.id);
  assert.equal(first.sourceId, "career-one"); assert.equal(second.sourceId, "career-two");
  assert.equal(first.sourceJobId, id);
  assert.equal(first.careerSourceIds, undefined);
  assert.equal(first.company, "fixture team"); assert.equal(second.company, "fixture team");
  assert.equal(first.aiPolicy, "prohibited"); assert.deepEqual(first.countries, ["United States"]);
  assert.equal(first.employmentType, "Full-time");
  assert.equal(first.salary?.period, "hourly"); assert.equal(first.salary?.kind, "base");
  assert.equal(first.sponsorship, "unknown"); assert.equal(first.language, null);
  assert.match(first.description, /Build databases/);
  assert.equal(providerForUrl(first.applyUrl), "ashby");
  assert.equal(first.applyUrl, canonicalApplicationUrl(first.applyUrl));
});

test("Ashby uses twenty-item lexicographic pages and an individual link imports exactly one listed job", async () => {
  const jobs = Array.from({ length: 25 }, (_, i) => ashbyJob(`${String(i + 1).padStart(8, "0")}-abcd-abcd-abcd-123456789012`));
  const fetcher = jsonFetch({ jobs: [{ id: "private", isListed: false }, ...jobs.toReversed()] });
  const first = await scanCareerBoard(ashby, "career-one", "", undefined, fetcher);
  assert.equal(first.jobs.length, 20);
  assert.equal(first.nextCursor, jobs[19]!.id);
  const second = await scanCareerBoard(ashby, "career-one", "", first.nextCursor, fetcher);
  assert.equal(second.jobs.length, 5); assert.equal(second.nextCursor, undefined);
  assert.equal(new Set([...first.jobs, ...second.jobs].map((job) => job.id)).size, 25);
  const direct = await scanCareerBoard({ ...ashby, jobId: jobs[22]!.id }, "career-one", "", undefined, fetcher);
  assert.deepEqual(direct.jobs.map((job) => job.sourceJobId), [jobs[22]!.id]);
  assert.equal(direct.nextCursor, undefined);
  await assert.rejects(scanCareerBoard({ ...ashby, jobId: id }, "career-one", "", undefined, fetcher), (error: unknown) => {
    assert.ok(error instanceof DiscoveryError); assert.equal(error.httpStatus, 404); assert.match(error.message, /closed|missing/); return true;
  });
  await assert.rejects(scanCareerBoard({ ...ashby, jobId: id }, "career-one", "", undefined, jsonFetch({ jobs: [{ ...ashbyJob(), isListed: false }] })), errorIs("HTTP_ERROR"));
});

test("malformed and cross-board Ashby replies fail closed, not as successful empty scans", async () => {
  for (const row of [
    { ...ashbyJob(), id: "bad" }, { ...ashbyJob(), isListed: undefined }, { ...ashbyJob(), isRemote: "true" },
    { ...ashbyJob(), title: 7 }, { ...ashbyJob(), descriptionHtml: "" },
    { ...ashbyJob(), descriptionHtml: "<script>not a description</script>" },
    { ...ashbyJob(), jobUrl: `https://jobs.ashbyhq.com/other/${id}` },
    { ...ashbyJob(), applyUrl: `https://jobs.ashbyhq.com/fixture-team/${id}/application/other` },
    { ...ashbyJob(), jobUrl: `https://jobs.ashbyhq.com/fixture-team/${id}extra` },
    { ...ashbyJob(), jobUrl: `https://jobs.ashbyhq.com/other/../fixture-team/${id}` },
    { ...ashbyJob(), applyUrl: `https://jobs.ashbyhq.com/fixture-team/${id.replace(/^1/, "2")}/application` }
  ]) await assert.rejects(scanCareerBoard(ashby, "career-one", "", undefined, jsonFetch({ jobs: [row] })), errorIs("INVALID_DATA"));
  for (const payload of [{}, { jobs: {} }, { jobs: [ashbyJob(), ashbyJob()] }]) {
    await assert.rejects(scanCareerBoard(ashby, "career-one", "", undefined, jsonFetch(payload)), errorIs("INVALID_DATA"));
  }
});

test("Greenhouse imports ten verified details per page, no prospects, and only the chosen job for a direct link", async () => {
  const calls: string[] = [];
  const fetcher = greenhouseFetch(12, (row) => row, calls);
  const first = await scanCareerBoard(greenhouse, "career-one", "", undefined, fetcher);
  assert.equal(first.jobs.length, 10); assert.equal(first.nextCursor, "10"); assert.equal(calls.length, 11);
  assert.equal(first.jobs[0]!.id, "greenhouse:fixtureteam:1");
  assert.equal(first.jobs[0]!.company, "Fixture Team");
  const second = await scanCareerBoard(greenhouse, "career-two", "", first.nextCursor, fetcher);
  assert.equal(second.jobs.length, 2); assert.equal(second.nextCursor, undefined);
  calls.length = 0;
  const direct = await scanCareerBoard({ ...greenhouse, jobId: "11" }, "career-three", "", undefined, fetcher);
  assert.deepEqual(direct.jobs.map((job) => job.sourceJobId), ["11"]);
  assert.equal(direct.jobs[0]!.id, second.jobs[0]!.id);
  assert.equal(calls.length, 2);
  assert.deepEqual(await scanCareerBoard(greenhouse, "career-one", "", undefined, jsonFetch({ jobs: [{ id: 1, internal_job_id: null }] })), { jobs: [] });
  await assert.rejects(scanCareerBoard({ ...greenhouse, jobId: "1" }, "career-one", "", undefined, jsonFetch({ jobs: [{ id: 1, internal_job_id: null }] })), errorIs("HTTP_ERROR"));
});

test("Greenhouse retains no-AI questions, Canonical board-wide hold, geography and salary uncertainty", async () => {
  const result = await scanCareerBoard(greenhouse, "career-one", "", undefined, greenhouseFetch(1, (row) => ({
    ...row, questions: [{ label: "Do &lt;b&gt;not&lt;/b&gt; use AI tools." }], location: { name: "Remote except India" },
    pay_input_ranges: [{ min_cents: 10000000, max_cents: 20000000, currency_type: "USD" }], language: "en"
  })));
  assert.equal(result.jobs[0]!.aiPolicy, "prohibited"); assert.deepEqual(result.jobs[0]!.countries, []);
  assert.equal(result.jobs[0]!.salary, null); assert.equal(result.jobs[0]!.employmentType, "unknown");
  assert.equal(result.jobs[0]!.language, null); assert.equal(result.jobs[0]!.sponsorship, "unknown");
  const canonical = parseCareerTarget("https://boards.greenhouse.io/canonical/jobs/1")!;
  const fetcher = (async (input) => {
    const row = { ...greenhouseJob(1, "canonical"), absolute_url: "https://canonical.com/careers/1", questions: [] };
    return Response.json(String(input).includes("?") ? row : { jobs: [row] });
  }) as typeof fetch;
  const held = (await scanCareerBoard(canonical, "custom-source", "Canonical", undefined, fetcher)).jobs[0]!;
  assert.equal(held.aiPolicy, "prohibited");
  assert.equal(held.company, "Canonical");
  assert.equal(held.applyUrl, "https://job-boards.greenhouse.io/canonical/jobs/1");
});

test("source labels cannot rename employer identities or hide an excluded employer", async () => {
  const hpe = parseCareerTarget("https://jobs.ashbyhq.com/hpe")!;
  const payload = { companyName: "Unverified feed field", jobs: [{ ...ashbyJob(id, hpe.board), company_name: "Unverified job field" }] };
  for (const label of ["My favorite opportunities", "Unrelated employer", ""]) {
    const job = (await scanCareerBoard(hpe, `career-${id}`, label, undefined, jsonFetch(payload))).jobs[0]!;
    assert.equal(job.company, "hpe");
    assert.equal(job.sourceId, `career-${id}`);
    assert.equal(job.careerSourceIds, undefined);
  }
  const gh = greenhouseFetch(1, (row) => ({ ...row, company_name: "Hewlett Packard Enterprise (HPE)" }));
  const original = (await scanCareerBoard(greenhouse, `career-${id}`, "HPE roles", undefined, gh)).jobs[0]!;
  const renamed = (await scanCareerBoard(greenhouse, `career-${id}`, "Not HPE", undefined, gh)).jobs[0]!;
  assert.equal(original.company, "Hewlett Packard Enterprise (HPE)");
  assert.equal(renamed.company, original.company);
  assert.equal(renamed.id, original.id);
});

test("verified boards retain their employer names independently of labels and incidental payload names", async () => {
  const target = parseCareerTarget("https://jobs.ashbyhq.com/supabase")!;
  const job = (await scanCareerBoard(target, `career-${id}`, "Some other employer", undefined, jsonFetch({ jobs: [ashbyJob(id, "supabase")] }))).jobs[0]!;
  assert.equal(job.company, "Supabase");
  for (const [board, company] of [["canonical", "Canonical"], ["automatticcareers", "Automattic"]]) {
    const target = parseCareerTarget(`https://job-boards.greenhouse.io/${board}`)!;
    const fetcher = (async (input) => {
      const row = { ...greenhouseJob(1, board), company_name: "Incidental payload label" };
      return Response.json(String(input).includes("?") ? row : { jobs: [row] });
    }) as typeof fetch;
    const job = (await scanCareerBoard(target, `career-${id}`, "Unrelated source label", undefined, fetcher)).jobs[0]!;
    assert.equal(job.company, company);
    assert.equal(job.aiPolicy, board === "canonical" ? "prohibited" : "unknown");
  }
});

test("Greenhouse uses documented board metadata once when job company names are absent", async () => {
  const calls: string[] = [];
  const fixture = greenhouseFetch(2, (row) => ({ ...row, company_name: undefined }));
  const fetcher = (async (input, init) => {
    const url = String(input);
    calls.push(url);
    assert.equal(init?.method, "GET");
    assert.equal(init?.credentials, "omit");
    assert.equal(init?.redirect, "error");
    if (url === "https://boards-api.greenhouse.io/v1/boards/fixtureteam") {
      return Response.json({ name: "Hewlett Packard Enterprise (HPE)", content: "<p>Public board introduction.</p>" });
    }
    return fixture(input, init);
  }) as typeof fetch;
  const result = await scanCareerBoard(greenhouse, `career-${id}`, "Not HPE", undefined, fetcher);
  assert.deepEqual(result.jobs.map((job) => job.company), ["Hewlett Packard Enterprise (HPE)", "Hewlett Packard Enterprise (HPE)"]);
  assert.equal(calls.length, 4);
  assert.equal(calls.filter((url) => url.endsWith("/fixtureteam")).length, 1);
  const jobNamedCalls: string[] = [];
  await scanCareerBoard(greenhouse, `career-${id}`, "", undefined, greenhouseFetch(1, (row) => row, jobNamedCalls));
  assert.equal(jobNamedCalls.length, 2);
});

test("missing board names fall back only to the slug; malformed or throttled metadata fails explicitly", async () => {
  const fixture = greenhouseFetch(1, (row) => ({ ...row, company_name: undefined }));
  const withMetadata = (metadata: () => Response) => (async (input, init) => String(input).endsWith("/fixtureteam") ? metadata() : fixture(input, init)) as typeof fetch;
  const result = await scanCareerBoard(greenhouse, `career-${id}`, "Invented company", undefined, withMetadata(() => Response.json({ name: null })));
  assert.equal(result.jobs[0]!.company, "fixtureteam");
  await assert.rejects(scanCareerBoard(greenhouse, `career-${id}`, "", undefined, withMetadata(() => Response.json({ name: 42 }))), errorIs("INVALID_DATA"));
  for (const status of [429, 503]) {
    await assert.rejects(scanCareerBoard({ ...greenhouse, jobId: "1" }, `career-${id}`, "", undefined,
      withMetadata(() => new Response(null, { status, headers: { "Retry-After": "120" } }))), (error: unknown) => {
      assert.ok(error instanceof DiscoveryError);
      assert.equal(error.httpStatus, status);
      assert.equal(error.retryAfterMs, 120_000);
      return true;
    });
  }
});

test("Greenhouse does not skip missing details, mismatched IDs or cross-board response URLs", async () => {
  for (const transform of [
    (row: ReturnType<typeof greenhouseJob>) => ({ ...row, id: 2 }),
    (row: ReturnType<typeof greenhouseJob>) => ({ ...row, internal_job_id: null }),
    (row: ReturnType<typeof greenhouseJob>) => ({ ...row, absolute_url: "https://boards.greenhouse.io/other/jobs/1" }),
    (row: ReturnType<typeof greenhouseJob>) => ({ ...row, absolute_url: "https://boards.greenhouse.io/fixtureteam/jobs/2" }),
    (row: ReturnType<typeof greenhouseJob>) => ({ ...row, absolute_url: "https://unverified.example.com/jobs/1" }),
    (row: ReturnType<typeof greenhouseJob>) => ({ ...row, content: "<style>not a JD</style>" })
  ]) await assert.rejects(scanCareerBoard(greenhouse, "career-one", "", undefined, greenhouseFetch(1, transform)), errorIs("INVALID_DATA"));
  for (const jobs of [[{ id: 1 }], [{ id: 1, internal_job_id: -1 }], [greenhouseJob(), greenhouseJob()]]) {
    await assert.rejects(scanCareerBoard(greenhouse, "career-one", "", undefined, jsonFetch({ jobs })), errorIs("INVALID_DATA"));
  }
  let calls = 0;
  const missingDetail = (async (input) => {
    calls++;
    if (!String(input).includes("?")) return Response.json({ jobs: [greenhouseJob(), greenhouseJob(2)] });
    return String(input).includes("/1?") ? Response.json(greenhouseJob()) : new Response(null, { status: 404 });
  }) as typeof fetch;
  await assert.rejects(scanCareerBoard(greenhouse, "career-one", "", undefined, missingDetail), errorIs("HTTP_ERROR"));
  assert.equal(calls, 3);
});

test("target, source and cursor validation happens before any network request", async () => {
  let calls = 0;
  const noFetch = (async () => { calls++; throw new Error("no network"); }) as typeof fetch;
  for (const target of [
    { ...ashby, board: "../private" }, { ...ashby, boardUrl: "https://127.0.0.1/" },
    { ...ashby, provider: "greenhouse" }, { ...greenhouse, jobId: "../secret" }
  ]) await assert.rejects(scanCareerBoard(target as CareerBoardTarget, "career-one", "", undefined, noFetch), errorIs("INVALID_DATA"));
  for (const sourceId of ["", "../x", "career:one", "a b", "x\n", "a".repeat(129)]) {
    await assert.rejects(scanCareerBoard(ashby, sourceId, "", undefined, noFetch), errorIs("INVALID_DATA"));
  }
  for (const [target, cursors] of [[ashby, ["", "../x", "1", id.toUpperCase()]], [greenhouse, ["", "0", "01", "../x", id]]] as const) {
    for (const cursor of cursors) await assert.rejects(scanCareerBoard(target, "career-one", "", cursor, noFetch), errorIs("INVALID_CURSOR"));
  }
  await assert.rejects(scanCareerBoard({ ...ashby, jobId: id }, "career-one", "", id, noFetch), errorIs("INVALID_CURSOR"));
  assert.equal(calls, 0);
});

test("new scans retain 8 MiB bounds, refuse redirects and preserve 429/503 Retry-After without retries", async () => {
  for (const target of [ashby, greenhouse]) {
    for (const status of [429, 503]) {
      let requests = 0;
      const fetcher = (async () => { requests++; return new Response("private response", { status, headers: { "retry-after": "90" } }); }) as typeof fetch;
      await assert.rejects(scanCareerBoard(target, "career-one", "", undefined, fetcher), (error: unknown) => {
        assert.ok(error instanceof DiscoveryError); assert.equal(error.httpStatus, status); assert.equal(error.retryAfterMs, 90_000);
        assert.doesNotMatch(error.message, /private response/); return true;
      });
      assert.equal(requests, 1);
    }
    for (const response of [
      new Response("{}", { headers: { "content-length": String(8 * 1_048_576 + 1) } }),
      new Response(new ReadableStream<Uint8Array>({ start(controller) { controller.enqueue(new Uint8Array(8 * 1_048_576 + 1)); controller.close(); } }))
    ]) await assert.rejects(scanCareerBoard(target, "career-one", "", undefined, (async () => response) as typeof fetch), errorIs("TOO_LARGE"));
    await assert.rejects(scanCareerBoard(target, "career-one", "", undefined, (async () => new Response(null, { status: 302, headers: { location: "https://127.0.0.1/" } })) as typeof fetch), errorIs("REDIRECT"));
    await assert.rejects(scanCareerBoard(target, "career-one", "", undefined, (async () => new Response("<html>error</html>")) as typeof fetch), errorIs("INVALID_DATA"));
  }
});

test("existing built-in Supabase/Automattic/Canonical IDs and behavior remain unchanged", async () => {
  const supabase = (await scanSource("supabase", undefined, jsonFetch({ jobs: [ashbyJob(id, "supabase")] }))).jobs[0]!;
  assert.equal(supabase.id, `supabase:${id}`); assert.equal(supabase.company, "Supabase");
  for (const source of ["automattic", "canonical"]) {
    const board = source === "canonical" ? source : "automatticcareers";
    const fetcher = (async (input) => {
      const row = greenhouseJob(1, board);
      return Response.json(String(input).includes("?") ? row : { jobs: [row, greenhouseJob(2, board)] });
    }) as typeof fetch;
    const result = await scanSource(source, undefined, fetcher);
    assert.equal(result.jobs.length, 1); assert.equal(result.nextCursor, "1");
    assert.equal(result.jobs[0]!.id, `${source}:1`);
    assert.equal(result.jobs[0]!.aiPolicy, source === "canonical" ? "prohibited" : "unknown");
  }
});
