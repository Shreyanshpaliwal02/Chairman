import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { mkdir, rm, writeFile } from "node:fs/promises";
import { createServer, type Server } from "node:http";
import { resolve } from "node:path";
import { test } from "node:test";
import { ApplicationBrowser, canonicalApplicationUrl, providerForUrl, sameApplication, PROVIDERS } from "../packages/automation/browser.js";
import type { Job, FormSnapshot } from "../packages/domain/types.js";
import type { BrowserSubmitInput } from "../packages/automation/contracts.js";
import { fingerprint } from "../packages/automation/form.js";
import { providerFixtureHtml as fixture, type ProviderFixtureMode as Mode } from "../packages/automation/testing/provider-fixture.js";

const UUID = "206c6a86-74e3-4fcf-9175-fdfe07858676";
test("production destinations are exact allowlisted job identities", () => {
  assert.equal(providerForUrl(`https://jobs.ashbyhq.com/ashby/${UUID}`), "ashby");
  assert.equal(canonicalApplicationUrl(`https://jobs.ashbyhq.com/ashby/${UUID}?source=board#apply`), `https://jobs.ashbyhq.com/ashby/${UUID}/application`);
  assert.equal(providerForUrl("https://job-boards.greenhouse.io/acme/jobs/123"), "greenhouse");
  assert.ok(sameApplication("https://boards.greenhouse.io/acme/jobs/123?gh_src=a", "https://job-boards.greenhouse.io/acme/jobs/123"));
  assert.ok(!sameApplication("https://job-boards.greenhouse.io/acme/jobs/123", "https://job-boards.greenhouse.io/acme/jobs/124"));
  for (const url of [
    "https://www.linkedin.com/jobs/view/123", "https://wellfound.com/jobs/123", "https://www.naukri.com/job/123",
    "http://127.0.0.1/acme/jobs/123", "https://localhost/acme/jobs/123", "https://192.168.1.1/acme/jobs/123",
    "https://job-boards.greenhouse.io.evil.test/acme/jobs/123", "https://evil.test/acme/jobs/123",
    "https://user:pass@job-boards.greenhouse.io/acme/jobs/123", "http://job-boards.greenhouse.io/acme/jobs/123",
    "https://job-boards.greenhouse.io:444/acme/jobs/123", "https://job-boards.greenhouse.io/acme/jobs/123/other",
    "https://job-boards.greenhouse.io/acme/../acme/jobs/123", "https://job-boards.greenhouse.io/acme%2fjobs/123",
    `https://jobs.ashbyhq.com/ashby/${UUID}/application/other`,
  ]) {
    assert.equal(providerForUrl(url), undefined, url);
    assert.throws(() => canonicalApplicationUrl(url));
  }
  assert.equal(PROVIDERS.length, 2);
  assert.throws(() => new ApplicationBrowser({ userDataDir: "Library/Application Support/Google/Chrome" }));
  assert.throws(() => new ApplicationBrowser({ userDataDir: "test-profile", testOrigins: ["https://example.com"] }));
});

test("dedicated Chrome executes only approved synthetic application interactions", { timeout: 240_000 }, async t => {
  const dir = resolve(".browser-test-data", randomUUID());
  await mkdir(dir, { recursive: true });
  const resumePath = resolve(dir, "approved-resume.pdf");
  const bytes = Buffer.from("%PDF-1.7\nSynthetic resume fixture only. No personal data.\n%%EOF");
  await writeFile(resumePath, bytes);
  let mode: Mode = "normal";
  let provider: "ashby" | "greenhouse" = "ashby";
  let posted: Record<string, unknown>[] = [];
  let requestCount = 0;
  let unauthorizedRequests = 0;
  let locationQueries: string[] = [];
  let locationSelections: string[] = [];
  const sockets = new Set<import("node:net").Socket>();
  const server: Server = createServer(async (req, res) => {
    requestCount++;
    if (req.url?.startsWith("/location-suggestions?")) {
      locationQueries.push(new URL(req.url, "http://fixture.test").searchParams.get("text") ?? "");
      await new Promise(r => setTimeout(r, 350));
      const exact = "Test City, Test Region, Test Country";
      const labels = mode === "location-ambiguous" ? [exact, `  ${exact.toUpperCase()}  `] :
        mode === "location-mismatch" ? ["Other City, Test Region, Test Country"] : ["Other City, Test Region, Test Country", exact];
      res.writeHead(200, { "Content-Type": "application/json" }); res.end(JSON.stringify(labels)); return;
    }
    if (req.url?.startsWith("/location-selected?")) {
      locationSelections.push(new URL(req.url, "http://fixture.test").searchParams.get("label") ?? "");
      res.writeHead(200); res.end(); return;
    }
    if (req.url?.startsWith("/other/jobs/") || req.url?.startsWith("/different/jobs/")) unauthorizedRequests++;
    if (req.method === "POST") {
      const chunks: Buffer[] = [];
      for await (const c of req) chunks.push(c);
      const raw = Buffer.concat(chunks).toString();
      posted.push(raw ? JSON.parse(raw) : {});
      if (mode === "post-timeout") return;
      if (mode === "rate-limit") { res.writeHead(429, { "Retry-After": "25" }); res.end(); return; }
      if (mode === "post-redirect") { res.writeHead(303, { Location: "/other/jobs/999" }); res.end(); return; }
      if (mode === "native-navigation") { res.writeHead(200, { "Content-Type": "text/html" }); res.end('<main><div class="application--confirmation">Thank you for applying. Application received.</div></main>'); return; }
      res.writeHead(200, { "Content-Type": "application/json" }); res.end('{"received":true}'); return;
    }
    if (mode === "redirect") { res.writeHead(302, { Location: "/other/jobs/999" }); res.end(); return; }
    if (mode === "preflight-throttle") { res.writeHead(429, { "Content-Type": "text/html", "Retry-After": "40" }); res.end("<h1>Too many requests</h1>"); return; }
    res.writeHead(200, { "Content-Type": "text/html" }); res.end(fixture(provider, mode, req.url!));
  });
  server.on("connection", s => { sockets.add(s); s.on("close", () => sockets.delete(s)); });
  await new Promise<void>(r => server.listen(0, "127.0.0.1", r));
  const origin = `http://127.0.0.1:${(server.address() as import("node:net").AddressInfo).port}`;
  const browser = new ApplicationBrowser({ userDataDir: resolve(dir, "profile"), headless: true, testOrigins: [origin] });
  let sequence = 100;
  const job = (): Job => {
    const url = provider === "ashby" ? `${origin}/fixture/${randomUUID()}/application` : `${origin}/fixture/jobs/${sequence++}`;
    return {
      id: randomUUID(), sourceId: provider, sourceJobId: String(sequence), title: "Fixture", company: "Synthetic",
      location: "Test", remote: true, countries: [], employmentType: "Full time", description: "Synthetic",
      applyUrl: url, canonicalUrl: url, fetchedAt: new Date().toISOString(), salary: null, language: "en", sponsorship: "unknown", aiPolicy: "allowed", status: "open",
    };
  };
  let before = 0;
  const prepare = async (): Promise<BrowserSubmitInput> => {
    const j = job();
    const inspection = await browser.inspect(j);
    assert.equal(inspection.status, "ready", inspection.reason);
    assert.ok(inspection.snapshot);
    return {
      job: j, snapshot: inspection.snapshot, answers: { first_name: "Synthetic", email: "fixture@example.test", notes: "User-approved fixture", work: "authorized", schedule: "r", country: provider === "greenhouse" ? "India" : "IN", ...(provider === "ashby" ? { relocate: "no" } : {}) },
      resumePath, resumeFilename: "approved-resume.pdf", resumeSha256: createHash("sha256").update(bytes).digest("hex"),
      checkAuthorization: async () => true, beforeSubmit: async () => { before++; },
    };
  };
  const scenario = async (name: string, next: Mode, run: () => Promise<void>) => t.test(name, async () => {
    mode = next; posted = []; before = 0; locationQueries = []; locationSelections = []; await run();
  });
  try {
    await scenario("visible structure only, stable fingerprint and passive privacy/captcha", "passive", async () => {
      const input = await prepare();
      assert.equal(input.snapshot.fingerprint, fingerprint(input.snapshot));
      assert.ok(input.snapshot.fields.some(f => f.key === "resume"));
      assert.ok(!JSON.stringify(input.snapshot).includes("synthetic-internal-token"));
      assert.ok(!input.snapshot.fields.some(f => ["csrf", "honeypot", "invisible"].includes(f.key)));
      assert.deepEqual(input.snapshot.fields.find(f => f.key === "work")?.options, ["authorized", "sponsorship"]);
      assert.deepEqual(input.snapshot.fields.find(f => f.key === "work")?.optionLabels, { authorized: "Eligible to work", sponsorship: "Needs sponsorship" });
      assert.equal(input.snapshot.hasCaptcha, false);
      assert.equal(input.snapshot.hasLegal, false);
      const resume = input.snapshot.fields.find(f => f.key === "resume")!;
      assert.deepEqual(resume.accept, [".pdf", ".docx"]);
      assert.deepEqual(Object.keys(resume), ["key", "label", "type", "required", "options", "accept"]);
      assert.deepEqual(input.snapshot.fields.find(f => f.key === "cover_letter")?.accept, [".pdf", "application/pdf", ".docx"]);
      assert.equal(input.snapshot.fields.find(f => f.key === "portfolio")?.accept, undefined);
      const { url, fields, hasCaptcha, hasLegal, unsupported } = input.snapshot;
      assert.equal(input.snapshot.fingerprint, createHash("sha256").update(JSON.stringify({ url, fields, hasCaptcha, hasLegal, unsupported })).digest("hex"));
      const changed = structuredClone(input.snapshot);
      changed.fields.find(f => f.key === "resume")!.accept = [".docx"];
      assert.notEqual(fingerprint(changed), input.snapshot.fingerprint);
      assert.equal(posted.length, 0);
    });
    for (const [m, status] of [["legal", "needs_input"], ["ownwords", "needs_input"], ["optional-ownwords", "needs_input"], ["required-document", "needs_input"], ["captcha", "captcha_required"], ["auth", "auth_required"], ["closed", "job_closed"], ["unknown-widget", "unsupported"], ["opaque-combo", "unsupported"]] as const) {
      await scenario(m, m, async () => assert.equal((await browser.inspect(job())).status, status));
    }
    await scenario("unknown or private production destinations cannot make network requests", "normal", async () => {
      const isolated = new ApplicationBrowser({ userDataDir: resolve(dir, "non-test-profile"), headless: true });
      const count = requestCount;
      assert.equal((await isolated.inspect(job())).status, "unsupported");
      assert.equal(requestCount, count);
      assert.equal(isolated.isRunning(), false);
      await assert.rejects(isolated.openForSetup(origin));
      await isolated.close();
    });
    await scenario("unauthorized redirect is stopped before hopping to another job", "redirect", async () => {
      assert.equal((await browser.inspect(job())).status, "unsupported");
      assert.equal(posted.length, 0);
      assert.equal(unauthorizedRequests, 0);
    });
    await scenario("preflight throttling includes Retry-After without leaking it to the next inspection", "preflight-throttle", async () => {
      const inspection = await browser.inspect(job());
      assert.equal(inspection.status, "unsupported");
      assert.equal(inspection.retryAfterMs, 40000);
      assert.match(inspection.reason, /rate limit/i);
      assert.equal(posted.length, 0);
      mode = "normal";
      const ready = await browser.inspect(job());
      assert.equal(ready.status, "ready", ready.reason);
      assert.equal(ready.retryAfterMs, undefined);
    });
    await scenario("resume hash mismatch and unsafe display names never upload", "normal", async () => {
      const input = await prepare();
      assert.equal((await browser.submit({ ...input, resumeSha256: "0".repeat(64) })).status, "failed");
      assert.equal((await browser.submit({ ...input, resumeFilename: "../different.pdf" })).status, "failed");
      assert.equal(posted.length, 0); assert.equal(before, 0);
    });
    await scenario("Stop callback checked before every answer", "normal", async () => {
      const input = await prepare();
      let checks = 0;
      input.checkAuthorization = async () => ++checks < 6;
      assert.equal((await browser.submit(input)).status, "cancelled");
      assert.equal(posted.length, 0); assert.equal(before, 0);
    });
    await scenario("new conditional required questions pause before any submit", "conditional", async () => {
      assert.equal((await browser.submit(await prepare())).status, "needs_input");
      assert.equal(posted.length, 0); assert.equal(before, 0);
    });
    provider = "greenhouse";
    await scenario("required additional documents stay manual even with their snapshot approved", "normal", async () => {
      const input = await prepare();
      mode = "required-document";
      const j = job(), inspected = await browser.inspect(j);
      assert.equal(inspected.status, "needs_input");
      assert.equal((await browser.submit({ ...input, job: j, snapshot: inspected.snapshot! })).status, "needs_input");
      assert.equal(before, 0); assert.equal(posted.length, 0);
    });
    await scenario("optional opt-ins cannot be activated by approved answer strings", "normal", async () => {
      const input = await prepare();
      input.answers.marketing = "true";
      assert.equal((await browser.submit(input)).status, "needs_input");
      assert.equal(before, 0); assert.equal(posted.length, 0);
    });
    await scenario("prechecked optional opt-in requires manual review rather than silently consenting", "checked-opt-in", async () => {
      assert.equal((await browser.submit(await prepare())).status, "needs_input");
      assert.equal(before, 0); assert.equal(posted.length, 0);
    });
    await scenario("changed accept list invalidates approval before upload", "accept-change", async () => {
      assert.equal((await browser.submit(await prepare())).status, "needs_input");
      assert.equal(before, 0); assert.equal(posted.length, 0);
    });
    await scenario("changed form destination pauses before transmission", "changed-action", async () => {
      assert.equal((await browser.submit(await prepare())).status, "needs_input");
      assert.equal(posted.length, 0); assert.equal(before, 0);
    });
    await scenario("missing required answer and non-option answer pause", "normal", async () => {
      const input = await prepare();
      delete input.answers.email;
      assert.equal((await browser.submit(input)).status, "needs_input");
      input.answers.email = "fixture@example.test"; input.answers.work = "not-an-option";
      assert.equal((await browser.submit(input)).status, "needs_input");
      assert.equal(posted.length, 0);
    });
    await scenario("altered approval snapshot rejected", "normal", async () => {
      const input = await prepare();
      input.snapshot.fields[0].label = "Changed";
      assert.equal((await browser.submit(input)).status, "needs_input");
      assert.equal(posted.length, 0);
    });
    for (const m of ["upload-reject", "filelist-only", "mime-reject", "upload-autofill", "upload-conditional"] as const) await scenario(m, m, async () => {
      assert.equal((await browser.submit(await prepare())).status, "needs_input");
      assert.equal(before, 0); assert.equal(posted.length, 0);
    });
    await scenario("existing receipt and success in job description never confirm", "preexisting-success", async () => {
      assert.equal((await browser.submit(await prepare())).status, "needs_input");
      assert.equal(before, 0); assert.equal(posted.length, 0);
    });
    await scenario("Stop after sending persistence prevents final click", "normal", async () => {
      const input = await prepare(); let allowed = true;
      input.checkAuthorization = async () => allowed;
      input.beforeSubmit = async () => { before++; allowed = false; };
      assert.equal((await browser.submit(input)).status, "cancelled");
      assert.equal(before, 1); assert.equal(posted.length, 0);
    });
    for (const [m, status] of [["validation", "needs_input"], ["after-captcha", "captcha_required"], ["after-auth", "auth_required"], ["rate-limit", "failed"]] as const) await scenario(m, m, async () => {
      const result = await browser.submit(await prepare());
      assert.equal(result.status, status, result.reason);
      assert.equal(before, 1);
      if (m === "rate-limit") assert.equal(result.retryAfterMs, 25000);
    });
    for (const m of ["navigate-away", "post-timeout", "no-receipt", "fake-receipt", "post-redirect"] as const) await scenario(m, m, async () => {
      const input = await prepare();
      assert.equal((await browser.submit(input)).status, "submission_unknown");
      assert.equal(before, 1); assert.equal(posted.length, m === "fake-receipt" ? 0 : 1);
      assert.equal((await browser.submit(input)).status, "submission_unknown");
      assert.equal(posted.length, m === "fake-receipt" ? 0 : 1);
      assert.equal(unauthorizedRequests, 0);
    });
    await scenario("normal native same-job navigation can produce a receipt", "native-navigation", async () => {
      const result = await browser.submit(await prepare());
      assert.equal(result.status, "submitted_confirmed", result.reason);
      assert.equal(before, 1); assert.equal(posted.length, 1);
    });
    await scenario("Greenhouse fill, accepted hidden uploader, receipt and exact synthetic bytes", "normal", async () => {
      const result = await browser.submit(await prepare());
      assert.equal(result.status, "submitted_confirmed", result.reason);
      assert.equal(before, 1); assert.equal(posted.length, 1);
      assert.deepEqual(posted[0].resume, { name: "approved-resume.pdf", type: "application/pdf", bytes: bytes.toString() });
      assert.deepEqual(posted[0].answers, { first_name: "Synthetic", email: "fixture@example.test", work: "authorized", country: "India", schedule: "r" });
      assert.equal(posted[0].internal, "synthetic-internal-token"); assert.equal(posted[0].honeypot, "");
      assert.deepEqual(posted[0].optionalFiles, [0, 0]); assert.equal(posted[0].marketing, false);
      assert.ok(!result.evidence?.includes("fixture@example.test"));
    });
    provider = "ashby";
    await scenario("known Ashby location awaits an async unique exact match without fingerprinting suggestions", "location-exact", async () => {
      const input = await prepare();
      const field = input.snapshot.fields.find(f => f.key === "_systemfield_location")!;
      assert.equal(field.type, "autocomplete"); assert.equal(field.required, true); assert.deepEqual(field.options, []);
      assert.equal(locationQueries.length, 0, "inspect must not query using any location text");
      input.answers._systemfield_location = "  TEST CITY,\u00a0Test Region, Test Country  ";
      const result = await browser.submit(input);
      assert.equal(result.status, "submitted_confirmed", result.reason);
      assert.deepEqual(locationQueries, [input.answers._systemfield_location]);
      assert.deepEqual(locationSelections, ["Test City, Test Region, Test Country"]);
      assert.equal((posted[0].answers as Record<string, string>).location, "Test City, Test Region, Test Country");
      assert.equal(before, 1);
    });
    for (const m of ["location-ambiguous", "location-mismatch", "location-field-change", "location-unselected"] as const) await scenario(m, m, async () => {
      const input = await prepare();
      input.answers._systemfield_location = "Test City, Test Region, Test Country";
      assert.equal((await browser.submit(input)).status, "needs_input");
      assert.deepEqual(locationQueries, [input.answers._systemfield_location]);
      assert.equal(locationSelections.length, 0); assert.equal(posted.length, 0); assert.equal(before, 0);
    });
    await scenario("Stop during asynchronous location suggestions prevents choosing or submitting", "location-stop", async () => {
      const input = await prepare();
      input.answers._systemfield_location = "Test City, Test Region, Test Country";
      input.checkAuthorization = async () => locationQueries.length === 0;
      assert.equal((await browser.submit(input)).status, "cancelled");
      assert.equal(locationSelections.length, 0); assert.equal(posted.length, 0); assert.equal(before, 0);
    });
    await scenario("lookalike dynamic controls outside Ashby's system location remain unsupported", "location-opaque", async () => {
      assert.equal((await browser.inspect(job())).status, "unsupported");
      assert.equal(locationQueries.length, 0);
    });
    await scenario("Ashby no-form root and yes/no buttons support actual normal form interactions", "normal", async () => {
      const result = await browser.submit(await prepare());
      assert.equal(result.status, "submitted_confirmed", result.reason);
      assert.equal(before, 1); assert.equal(posted.length, 1);
      assert.deepEqual(posted[0].optionalFiles, [0, 0]); assert.equal(posted[0].marketing, false);
    });
    await scenario("setup tab remains separate and close has correct lifecycle", "normal", async () => {
      await browser.openForSetup(origin);
      assert.equal(browser.isRunning(), true);
      assert.equal((await browser.inspect(job())).status, "ready");
      await browser.close(); assert.equal(browser.isRunning(), false);
      await browser.close();
    });
  } finally {
    await browser.close();
    for (const socket of sockets) socket.destroy();
    await new Promise<void>(r => server.close(() => r()));
    await rm(dir, { recursive: true, force: true });
  }
});
