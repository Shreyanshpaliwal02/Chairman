import { test, expect } from "@playwright/test";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "../../apps/local/server.js";
import { snapshotHash } from "../../apps/local/engine.js";
import type { FormSnapshot } from "../../packages/domain/types.js";
import { profileFixture, jobFixture } from "../fixtures.js";
import { localDate } from "../../packages/domain/dates.js";

let runtime: Awaited<ReturnType<typeof createApp>>, directory: string;
test.beforeAll(async () => {
  directory = await mkdtemp(join(tmpdir(), "jaa-browser-"));
  runtime = await createApp({ dataDir: directory, port: 4328, fixtureMode: true });
  await runtime.app.listen({ port: 4328, host: "127.0.0.1" });
});
test.afterAll(async () => { await runtime.app.close(); await rm(directory, { recursive: true, force: true }); });

test("dashboard renders real local state without browser exceptions or external requests", async ({ page }) => {
  const errors: string[] = [], external: string[] = [];
  page.on("pageerror", e => errors.push(e.message));
  page.on("request", request => { if (!request.url().startsWith(runtime.origin)) external.push(request.url()); });
  await page.goto(runtime.origin);
  await expect(page.locator("main")).toBeVisible();
  await expect(page.getByRole("button", { name: "Opportunities", exact: true })).toBeVisible();
  await page.getByRole("button", { name: /^Profile/ }).click();
  await expect(page.getByRole("heading", { name: /profile/i }).first()).toBeVisible();
  await page.getByRole("button", { name: "Sources", exact: true }).click();
  await expect(page.getByText("LinkedIn", { exact: true }).first()).toBeVisible();
  await expect(page.getByText("SideShift.app", { exact: true }).first()).toBeVisible();
  expect(errors).toEqual([]); expect(external).toEqual([]);
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});

test("approved immutable packet reaches a genuine local multipart form and confirmation", async ({ page }) => {
  runtime.store.set("profile", profileFixture());
  const url = `${runtime.origin}/fixture/application`;
  const job = jobFixture({ applyUrl: url, canonicalUrl: url }); runtime.store.saveJob(job);
  const packet = await runtime.engine.prepare(job.id, "deterministic", { experience: profileFixture().facts[0]!.text });
  await page.goto(url);
  const fields = await page.locator("input, textarea").evaluateAll(elements => elements.map(element => {
    const field = element as HTMLInputElement | HTMLTextAreaElement;
    return { key: field.name, label: field.labels?.[0]?.textContent?.trim() ?? "", type: field.tagName === "TEXTAREA" ? "textarea" : (field as HTMLInputElement).type,
      required: field.required, options: [] };
  }));
  const snapshot: FormSnapshot = { url, fields, hasCaptcha: false, hasLegal: false, unsupported: [], fingerprint: "" };
  snapshot.fingerprint = snapshotHash(snapshot);
  runtime.engine.preflight(packet.id, snapshot);
  await runtime.engine.approve([packet.id], true);
  const claimed = await runtime.engine.claim(packet.id);
  for (const [key, value] of Object.entries(claimed.fields)) await page.locator(`[name="${key}"]`).fill(value);
  await page.locator('[name="resume"]').setInputFiles({ name: claimed.resume.filename, mimeType: claimed.resume.mime, buffer: Buffer.from(claimed.resume.base64, "base64") });
  await page.getByRole("button", { name: "Submit application" }).click();
  const receipt = page.locator('[data-jaa-submitted="true"]');
  await expect(receipt).toBeVisible();
  const reference = await receipt.getAttribute("data-confirmation-id");
  expect(reference).toBeTruthy();
  runtime.engine.report(packet.id, claimed.runToken, "submitted_confirmed", `Local fixture receipt ${reference}`);
  expect(runtime.store.packet(packet.id)!.status).toBe("submitted_confirmed");
});

test("real dashboard preparation can be approved for manual handoff and reconciled", async ({ page }) => {
  runtime.store.set("profile", profileFixture());
  const job = jobFixture({ id: "manual-ui-job", sourceId: "manual", title: "Data Engineer Manual UI",
    company: "Manual Workflow Example", applyUrl: "https://example.test/jobs/manual-ui", canonicalUrl: "https://example.test/jobs/manual-ui" });
  runtime.store.saveJob(job);
  await page.goto(runtime.origin);
  await page.getByRole("button", { name: "Opportunities", exact: true }).click();
  await page.getByRole("button", { name: /Manual Workflow Example.*Data Engineer Manual UI/ }).click();
  await page.getByRole("button", { name: "Prepare without AI" }).click();
  await expect(page.getByRole("region", { name: "Exact application packet review" })).toBeVisible();
  await page.getByRole("checkbox", { name: /I opened and reviewed the exact PDF/ }).check();
  await page.getByRole("checkbox", { name: /I reviewed the saved answers/ }).check();
  await page.getByRole("checkbox", { name: /I reviewed this exact packet/ }).check();
  await page.getByRole("checkbox", { name: /I reviewed all warnings/ }).check();
  await page.getByRole("button", { name: /Approve 1 selected packet/ }).click();
  await expect.poll(() => runtime.store.packets().find(packet => packet.jobId === job.id)?.status).toBe("manual_only");
  await page.getByText("Report a submission you verified", { exact: true }).click();
  await page.getByLabel("Confirmation evidence", { exact: true }).fill("Confirmed by the synthetic employer reference EXAMPLE-789.");
  await page.getByRole("checkbox", { name: /I personally verified/ }).check();
  await page.getByRole("button", { name: "Record my confirmation" }).click();
  await expect.poll(() => runtime.store.packets().find(packet => packet.jobId === job.id)?.status).toBe("submitted_confirmed");
  expect(runtime.store.packets().find(packet => packet.jobId === job.id)?.confirmation).toMatch(/^User-reported confirmation:/);
});

test("Home shows a target rather than a quota and unverified references remain separate", async ({ page }) => {
  const profile = profileFixture(); profile.confirmed = false; profile.facts.forEach(fact => { fact.confirmed = false; });
  runtime.store.set("profile", profile);
  await page.goto(runtime.origin);
  await page.getByRole("button", { name: "Home", exact: true }).click();
  await expect(page.getByRole("heading", { name: /500 a day/ })).toBeVisible();
  await expect(page.getByText("No global daily or session cap.", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Resumes", exact: true }).click();
  const before = runtime.store.packetCount();
  await page.getByRole("button", { name: "Create all 6 drafts" }).click();
  await expect(page.locator(".reference-resume")).toHaveCount(6);
  expect(runtime.store.profile().confirmed).toBe(false);
  expect(runtime.store.packetCount()).toBe(before);
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});

test("external manual applications and interview reports need no generated resume", async ({ page }) => {
  const job = jobFixture({ id: "external-ui", company: "External UI Example", title: "Cloud Engineer External",
    sourceId: "canonical", aiPolicy: "prohibited", applyUrl: "https://canonical.com/careers/example",
    canonicalUrl: "https://canonical.com/careers/example" });
  runtime.store.saveJob(job);
  await page.goto(runtime.origin);
  await page.getByRole("button", { name: /^Applications/ }).click();
  const section = page.getByRole("region", { name: "External application history" });
  await section.getByText("Record an external application", { exact: true }).click();
  await section.getByLabel("Previously submitted job").selectOption(job.id);
  await section.getByLabel("Actual submission date").fill(localDate());
  await section.getByLabel("External confirmation evidence").fill("Synthetic external employer receipt UI-456.");
  await section.getByRole("checkbox", { name: /I actually submitted this application/ }).check();
  await section.getByRole("button", { name: "Record external submission" }).click();
  await expect.poll(() => runtime.store.externalApplications().some(application => application.jobId === job.id)).toBe(true);
  const row = section.locator("details.setup-section").filter({ hasText: "External UI Example" });
  await row.locator("summary").click();
  await row.getByLabel("External hiring stage").selectOption("interview");
  await row.getByRole("button", { name: "Save external outcome" }).click();
  await expect.poll(() => runtime.store.externalApplications().find(application => application.jobId === job.id)?.progress.stage).toBe("interview");
  expect(runtime.store.packetsForJob(job.id)).toHaveLength(0);
});
