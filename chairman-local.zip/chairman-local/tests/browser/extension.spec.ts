import { test, expect, chromium, type CDPSession } from "@playwright/test";
import { z } from "zod";
import { cp, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { createApp } from "../../apps/local/server.js";
import { profileFixture, jobFixture } from "../fixtures.js";

async function attachPanel(cdp: CDPSession, targetId: string) {
  const { sessionId } = await cdp.send("Target.attachToTarget", { targetId, flatten: false });
  let sequence = 0;
  const waiting = new Map<number, { resolve: (value: unknown) => void; reject: (error: Error) => void }>();
  cdp.on("Target.receivedMessageFromTarget", event => {
    if (event.sessionId !== sessionId) return;
    const response = z.object({ id: z.number(), result: z.unknown().optional(), error: z.object({ message: z.string() }).optional() }).safeParse(JSON.parse(event.message));
    if (!response.success) return;
    const pending = waiting.get(response.data.id);
    if (!pending) return;
    waiting.delete(response.data.id);
    if (response.data.error) pending.reject(new Error(response.data.error.message));
    else pending.resolve(response.data.result);
  });
  return async (expression: string) => {
    const id = ++sequence;
    const response = new Promise<unknown>((resolve, reject) => waiting.set(id, { resolve, reject }));
    await cdp.send("Target.sendMessageToTarget", {
      sessionId, message: JSON.stringify({ id, method: "Runtime.evaluate", params: { expression, userGesture: true, awaitPromise: true, returnByValue: true } })
    });
    let timeout: ReturnType<typeof setTimeout> | undefined;
    const result = z.object({ result: z.object({ value: z.unknown().optional() }), exceptionDetails: z.unknown().optional() }).parse(await Promise.race([
      response,
      new Promise<never>((_resolve, reject) => { timeout = setTimeout(() => reject(new Error("Side-panel operation exceeded its controlled-test deadline.")), 20000); })
    ]).finally(() => clearTimeout(timeout)));
    if (result.exceptionDetails) throw new Error(JSON.stringify(result.exceptionDetails));
    return result.result.value;
  };
}

test("loaded extension with a pre-authorized fixture host pairs and submits only the approved local fixture", async () => {
  const directory = await mkdtemp(join(tmpdir(), "jaa-extension-e2e-"));
  const runtime = await createApp({ dataDir: directory, port: 4329, fixtureMode: true });
  await runtime.app.listen({ port: 4329, host: "127.0.0.1" });
  const context = await chromium.launchPersistentContext("", {
    channel: "chrome", headless: true, ignoreDefaultArgs: ["--disable-extensions"],
    args: ["--enable-unsafe-extension-debugging"]
  });
  try {
    runtime.store.set("profile", profileFixture());
    const job = jobFixture({ applyUrl: `${runtime.origin}/fixture/application`, canonicalUrl: `${runtime.origin}/fixture/application` });
    runtime.store.saveJob(job);
    const packet = await runtime.engine.prepare(job.id, "deterministic", { experience: profileFixture().facts[0]!.text });
    const session = await runtime.app.inject({ method: "GET", url: "/api/session", headers: { host: "127.0.0.1:4329" } });
    const cookie = session.cookies[0]!;
    const paired = await runtime.app.inject({ method: "POST", url: "/api/extension/pair", headers: { host: "127.0.0.1:4329", cookie: `${cookie.name}=${cookie.value}` } });
    const token = z.object({ token: z.string() }).parse(paired.json()).token;

    const browser = context.browser();
    if (!browser) throw new Error("An isolated Chrome browser connection is required.");
    const cdp = await browser.newBrowserCDPSession();
    const extensionPath = join(directory, "extension");
    await cp(resolve("dist/extension"), extensionPath, { recursive: true });
    const manifest = JSON.parse(await readFile(join(extensionPath, "manifest.json"), "utf8"));
    // Native consent dialogs require a person. Pre-authorize only this isolated
    // test's loopback host; production keeps its original optional permissions.
    manifest.host_permissions = ["http://127.0.0.1/*"];
    manifest.optional_host_permissions = ["https://*/*"];
    await writeFile(join(extensionPath, "manifest.json"), JSON.stringify(manifest));
    const loaded = await cdp.send("Extensions.loadUnpacked", { path: extensionPath });
    const panelUrl = `chrome-extension://${loaded.id}/sidepanel.html`;
    const helper = await context.newPage();
    await helper.goto(panelUrl);
    const helperCdp = await context.newCDPSession(helper);
    const helperInfo = await helperCdp.send("Target.getTargetInfo");
    await helperCdp.send("Runtime.evaluate", {
      expression: "(async()=>{const window=await chrome.windows.getCurrent();await chrome.sidePanel.open({windowId:window.id});})()",
      userGesture: true, awaitPromise: true
    });
    let panelId: string | undefined;
    await expect.poll(async () => {
      const targets = await cdp.send("Target.getTargets");
      panelId = targets.targetInfos.find(target => target.type === "page" && target.url === panelUrl && target.targetId !== helperInfo.targetInfo.targetId)?.targetId;
      return Boolean(panelId);
    }).toBe(true);
    const evaluatePanel = await attachPanel(cdp, panelId!);
    await expect.poll(async () => evaluatePanel("document.readyState")).toBe("complete");
    const permission = await evaluatePanel("chrome.permissions.request({origins:['http://127.0.0.1/*']})");
    expect(permission).toBe(true);
    const pairReply = await evaluatePanel(`chrome.runtime.sendMessage(${JSON.stringify({ channel: "jaa:panel", action: "pair", port: 4329, token })})`);
    expect(pairReply).toMatchObject({ ok: true });

    const page = await context.newPage();
    await page.goto(job.applyUrl);
    await page.bringToFront();
    const inspect = await evaluatePanel(`chrome.runtime.sendMessage(${JSON.stringify({ channel: "jaa:panel", action: "preflight", packetId: packet.id })})`);
    expect(inspect).toMatchObject({ ok: true });
    expect(runtime.store.packet(packet.id)?.status).toBe("prepared");
    await runtime.engine.approve([packet.id], true);
    const execution = await evaluatePanel(`chrome.runtime.sendMessage(${JSON.stringify({ channel: "jaa:panel", action: "execute", packetId: packet.id })})`);
    expect(execution).toMatchObject({ ok: true });
    await expect.poll(() => runtime.store.packet(packet.id)?.status).toBe("submitted_confirmed");
    await expect(page).toHaveURL(/\/fixture\/confirmation\?id=/);
    expect(runtime.store.attempts(new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format())).toBe(1);
  } finally {
    await context.close(); await runtime.app.close(); await rm(directory, { recursive: true, force: true });
  }
});
