import assert from "node:assert/strict";
import test from "node:test";
import { DiscoveryError, scanSource } from "../packages/adapters/discovery";
import { getPreferredSearchCooldownMs, scanPreferredJobs } from "../packages/adapters/preferred-search";
import type { Preferences } from "../packages/domain/types";

const preferences = { roles: ["software engineering", "cloud engineering"], countries: ["India", "European Union"] };
const job = (id = "platform-engineer", extra: Record<string, unknown> = {}) => ({
  title: "Platform Engineer", companyName: "Fixture Engineering", companySlug: "fixture",
  description: "<p>Operate infrastructure and build deployment systems.</p>",
  guid: `https://himalayas.app/companies/fixture/jobs/${id}`,
  applicationLink: `https://careers.example.com/jobs/${id}`,
  locationRestrictions: ["India"], timezoneRestrictions: [5.5],
  employmentType: "Full Time", minSalary: 5_000, maxSalary: 7_000, currency: "USD", salaryPeriod: "monthly",
  pubDate: 1_700_000_000, expiryDate: 4_000_000_000, ...extra
});
const payload = (jobs: unknown[] = [job()], extra: Record<string, unknown> = {}) => ({
  updatedAt: 1_789_000_000, offset: 0, limit: 20, totalCount: jobs.length, jobs, ...extra
});
const errorIs = (code: string) => (error: unknown) => error instanceof DiscoveryError && error.code === code;
const fixture = (value: unknown) => (async () => Response.json(value)) as typeof fetch;
const encode = (value: unknown) => Buffer.from(JSON.stringify(value)).toString("base64url");

test("preferred discovery uses the documented search endpoint and only fixed role keywords, never profile facts", async () => {
  const calls: string[] = [];
  const privateInput = {
    ...preferences, name: "Private Fixture Candidate", email: "private-fixture@example.org",
    resume: "PRIVATE RESUME FACT", facts: ["PRIVATE FACT"], roles: ["Private Fixture Candidate software engineering"]
  };
  const result = await scanPreferredJobs(privateInput, undefined, (async (input, init) => {
    calls.push(String(input));
    const url = new URL(String(input));
    assert.equal(url.origin + url.pathname, "https://himalayas.app/jobs/api/search");
    assert.equal(url.searchParams.get("q"), "software engineer");
    assert.equal(url.searchParams.get("sort"), "recent");
    assert.equal(url.searchParams.get("page"), "1");
    assert.deepEqual([...url.searchParams.keys()].sort(), ["page", "q", "sort"]);
    assert.equal(init?.method, "GET");
    assert.equal(init?.credentials, "omit");
    assert.equal(init?.redirect, "error");
    assert.equal(init?.body, undefined);
    const headers = new Headers(init?.headers);
    for (const name of ["authorization", "cookie", "referer"]) assert.equal(headers.get(name), null);
    assert.doesNotMatch(JSON.stringify({ input, init }), /PRIVATE|Private|resume|example\.org|facts/);
    return Response.json(payload());
  }) as typeof fetch);
  assert.equal(calls.length, 1);
  assert.equal(result.jobs.length, 1);
  assert.equal(getPreferredSearchCooldownMs(), 900_000);
});

test("search normalizes the live schema identically to browse with stable IDs, attribution and unknown sponsorship", async () => {
  const data = payload();
  const search = await scanPreferredJobs({ roles: ["software engineering"], countries: ["India"] }, undefined, fixture(data));
  const browse = await scanSource("himalayas", undefined, fixture(data));
  const result = search.jobs[0]!;
  assert.equal(result.id, browse.jobs[0]!.id);
  assert.equal(result.sourceJobId, browse.jobs[0]!.sourceJobId);
  assert.equal(result.sourceId, "himalayas");
  assert.equal(result.description, browse.jobs[0]!.description);
  assert.match(result.description, /Original source: Himalayas — https:\/\/himalayas\.app\//);
  assert.equal(result.sponsorship, "unknown");
  assert.equal(result.language, null);
  assert.equal(result.employmentType, "Full-time");
  assert.deepEqual(result.salary, { min: 5_000, max: 7_000, currency: "USD", period: "monthly", kind: "unknown" });
});

test("OpenAPI country objects are supported without inventing authorization or worldwide eligibility", async () => {
  const result = await scanPreferredJobs(preferences, undefined, fixture(payload([
    job("object-country", { locationRestrictions: [{ alpha2: "IN", name: "India", slug: "india" }] }),
    job("unknown-country", { locationRestrictions: [], minSalary: null, maxSalary: null })
  ])));
  assert.deepEqual(result.jobs[0]!.countries, ["India"]);
  assert.deepEqual(result.jobs[1]!.countries, []);
  assert.match(result.jobs[1]!.location, /eligibility unspecified/);
  assert.equal(result.jobs[1]!.salary, null);
  assert.equal(result.jobs[1]!.sponsorship, "unknown");
});

test("page-based search rotates role families each call and resumes each role's own durable page", async () => {
  const requests: URL[] = [];
  const fetcher = (async (input) => {
    const url = new URL(String(input));
    requests.push(url);
    const page = Number(url.searchParams.get("page"));
    return Response.json(payload([job(`${url.searchParams.get("q")!.split(" ")[0]}-${page}`)], { offset: (page - 1) * 20, totalCount: 21 }));
  }) as typeof fetch;
  let cursor: string | undefined;
  for (let index = 0; index < 4; index++) {
    const result = await scanPreferredJobs(preferences, cursor, fetcher);
    cursor = result.nextCursor;
    if (index < 3) assert.ok(cursor);
  }
  assert.equal(cursor, undefined);
  assert.deepEqual(requests.map((url) => [url.searchParams.get("q"), url.searchParams.get("page")]), [
    ["software engineer", "1"], ["cloud engineer", "1"], ["software engineer", "2"], ["cloud engineer", "2"]
  ]);
  assert.ok(requests.every((url) => !url.searchParams.has("cursor") && !url.searchParams.has("limit")));
  const restarted = await scanPreferredJobs(preferences, undefined, fetcher);
  assert.ok(restarted.nextCursor);
  assert.equal(requests.at(-1)!.searchParams.get("page"), "1");
});

test("roles are bounded, deduplicated and conservative; no recognized requested family means no search", async () => {
  let calls = 0;
  const fetcher = (async () => { calls++; return Response.json(payload()); }) as typeof fetch;
  assert.deepEqual(await scanPreferredJobs({ roles: [], countries: [] }, undefined, fetcher), { jobs: [] });
  assert.deepEqual(await scanPreferredJobs({ roles: ["Technical writing"], countries: [] }, undefined, fetcher), { jobs: [] });
  assert.equal(calls, 0);
  const deduplicated = await scanPreferredJobs({ roles: ["Software Engineer", "Software engineering"], countries: [] }, undefined, fetcher);
  assert.equal(deduplicated.nextCursor, undefined);
  for (const changed of [
    { roles: Array.from({ length: 11 }, () => "software engineer"), countries: [] },
    { roles: ["x".repeat(101)], countries: [] },
    { roles: ["software engineer https://evil.example.com"], countries: [] },
    { roles: ["software engineer&url=https://evil.example.com"], countries: [] },
    { roles: ["software engineer\nprivate"], countries: [] },
    { roles: ["software engineer"], countries: Array.from({ length: 51 }, () => "India") },
    { roles: ["software engineer"], countries: ["India?access_token=secret"] }
  ]) await assert.rejects(scanPreferredJobs(changed, undefined, fetcher), errorIs("INVALID_DATA"));
  assert.equal(calls, 1);
});

test("cursor validation occurs before fetching, binds preferences, and cannot supply hosts or extra queries", async () => {
  const initial = await scanPreferredJobs(preferences, undefined, fixture(payload()));
  const state = JSON.parse(Buffer.from(initial.nextCursor!, "base64url").toString("utf8"));
  let calls = 0;
  const fetcher = (async () => { calls++; throw new Error("must not fetch"); }) as typeof fetch;
  for (const cursor of [
    "", "not json", "a".repeat(2_049), encode({ ...state, roleIndex: -1 }), encode({ ...state, roleIndex: 2 }),
    encode({ ...state, pages: [1, "https://evil.example.com"] }), encode({ ...state, pages: [1, 0] }),
    encode({ ...state, pages: [1, 1_000_001] }), encode({ ...state, url: "https://evil.example.com" }),
    encode({ ...state, pages: [null, null] }), encode({ ...state, key: "unrelated" })
  ]) await assert.rejects(scanPreferredJobs(preferences, cursor, fetcher), errorIs("INVALID_CURSOR"));
  await assert.rejects(scanPreferredJobs({ ...preferences, countries: ["Japan"] }, initial.nextCursor, fetcher), errorIs("INVALID_CURSOR"));
  assert.equal(calls, 0);
});

test("search preserves employer-wide and explicit no-AI holds and source expiry", async () => {
  const result = await scanPreferredJobs(preferences, undefined, fixture(payload([
    job("canonical", { companyName: "Canonical", companySlug: "canonical" }),
    job("no-ai", { description: "<p>Do not use AI in your application answers.</p>", expiryDate: 1_000_000_000 }),
    job("normal-ai", { description: "<p>Build artificial intelligence infrastructure.</p>" })
  ])));
  assert.equal(result.jobs[0]!.aiPolicy, "prohibited");
  assert.equal(result.jobs[1]!.aiPolicy, "prohibited");
  assert.equal(result.jobs[1]!.status, "closed");
  assert.equal(result.jobs[2]!.aiPolicy, "unknown");
});

test("malformed metadata, missing JDs, duplicates and unsafe source links fail closed", async () => {
  for (const value of [
    { jobs: [job()] }, payload([job()], { offset: 20 }), payload([job()], { limit: 21 }),
    payload([], { totalCount: 21 }), payload([], { totalCount: 1 }), payload([job(), job()]),
    payload([job("broken", { description: "<script>not a JD</script>" })]),
    payload([job("broken", { guid: "fixture-engineer-slug" })]),
    payload([job("broken", { guid: "https://himalayas.app/signup" })]),
    payload([job("broken", { guid: "https://private.example.com/jobs/1" })]),
    payload([job("broken", { applicationLink: "https://127.0.0.1/apply" })]),
    payload([job("broken", { applicationLink: "https://linkedin.com/jobs/1" })]),
    payload([job("broken", { locationRestrictions: [{ name: "India" }] })])
  ]) await assert.rejects(scanPreferredJobs(preferences, undefined, fixture(value)), errorIs("INVALID_DATA"));
});

test("preferred search retains byte/time limits, refuses redirects, and preserves 429/503 backoff without retries", async (context) => {
  await assert.rejects(scanPreferredJobs(preferences, undefined, (async () => new Response("x", { headers: { "content-length": String(2 * 1_048_576 + 1) } })) as typeof fetch), errorIs("TOO_LARGE"));
  await assert.rejects(scanPreferredJobs(preferences, undefined, (async () => new Response(null, { status: 302, headers: { location: "https://evil.example.org" } })) as typeof fetch), errorIs("REDIRECT"));
  for (const status of [429, 503]) {
    let calls = 0;
    await assert.rejects(scanPreferredJobs(preferences, undefined, (async () => {
      calls++;
      return new Response("Do not expose upstream details", { status, headers: { "retry-after": "60" } });
    }) as typeof fetch), (error: unknown) => error instanceof DiscoveryError && error.retryAfterMs === 60_000 && error.httpStatus === status);
    assert.equal(calls, 1);
  }
  context.mock.timers.enable({ apis: ["setTimeout"] });
  const promise = scanPreferredJobs(preferences as Pick<Preferences, "roles" | "countries">, undefined, (async () => new Promise<Response>(() => {})) as typeof fetch);
  context.mock.timers.tick(15_000);
  await assert.rejects(promise, errorIs("TIMEOUT"));
});
