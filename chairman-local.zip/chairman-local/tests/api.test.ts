import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "../apps/local/server.js";
import { profileFixture, jobFixture } from "./fixtures.js";
import { localDate } from "../packages/domain/dates.js";

test("local API requires same-site sessions and separates extension credentials", async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-api-"));
  const { app } = await createApp({ dataDir: dir, port: 4318, fixtureMode: true });
  const host = { host: "127.0.0.1:4318" };
  try {
    const wrongHost = await app.inject({ method: "GET", url: "/api/session", headers: { host: "attacker.test" } });
    assert.equal(wrongHost.statusCode, 403);
    assert.equal((await app.inject({ method: "GET", url: "/api/state", headers: host })).statusCode, 401);
    assert.equal((await app.inject({ method: "GET", url: "/api/session", headers: { ...host, origin: "https://attacker.test" } })).statusCode, 403);
    const session = await app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = session.cookies[0]!;
    const headers = { ...host, cookie: `${cookie.name}=${cookie.value}`, origin: "http://127.0.0.1:4318" };
    const saved = await app.inject({ method: "POST", url: "/api/profile", headers, payload: { profile: profileFixture() } });
    assert.equal(saved.statusCode, 200, saved.body);
    const invalid = await app.inject({ method: "POST", url: "/api/profile", headers, payload: { profile: { ...profileFixture(), links: { github: "javascript:alert(1)" } } } });
    assert.equal(invalid.statusCode, 400);
    const paired = await app.inject({ method: "POST", url: "/api/extension/pair", headers });
    assert.equal(paired.statusCode, 200);
    const extHeaders = { ...host, origin: `chrome-extension://${"a".repeat(32)}`, authorization: `Bearer ${paired.json().token}` };
    assert.equal((await app.inject({ method: "POST", url: "/api/extension/connect", headers: extHeaders })).statusCode, 200);
    assert.equal((await app.inject({ method: "GET", url: "/api/state", headers: extHeaders })).statusCode, 403);
    assert.equal((await app.inject({ method: "POST", url: "/api/extension/pair?bypass=1", headers: extHeaders })).statusCode, 403);
    assert.equal((await app.inject({ method: "GET", url: "/api/extension/jobs", headers: extHeaders })).statusCode, 200);
  } finally { await app.close(); await rm(dir, { recursive: true, force: true }); }
});

test("reference drafts do not confirm a profile or become approvable application packets", async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-reference-api-"));
  const { app, store } = await createApp({ dataDir: dir, port: 4318 });
  const host = { host: "127.0.0.1:4318" };
  try {
    const profile = profileFixture(); profile.confirmed = false; profile.facts.forEach(fact => { fact.confirmed = false; });
    store.set("profile", profile); store.saveJob(jobFixture());
    const session = await app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = session.cookies[0]!;
    const headers = { ...host, cookie: `${cookie.name}=${cookie.value}` };
    const references = await app.inject({ method: "POST", url: "/api/resumes/reference", headers, payload: {} });
    assert.equal(references.statusCode, 200, references.body);
    assert.equal(references.json().resumes.length, 6);
    const first = references.json().resumes[0];
    assert.equal(first.needsReview, true); assert.equal(first.artifacts.length, 2);
    assert.equal(store.profile().confirmed, false); assert.equal(store.packets().length, 0);
    assert.equal((await app.inject({ method: "GET", url: `/api/resumes/reference/${first.id}/pdf`, headers })).rawPayload.subarray(0, 4).toString(), "%PDF");
    const again = await app.inject({ method: "POST", url: "/api/resumes/reference", headers, payload: { families: [first.family] } });
    assert.equal(again.json().resumes[0].id, first.id);
    const forbidden = await app.inject({ method: "POST", url: "/api/packets", headers, payload: { jobId: "fixture-job", mode: "deterministic" } });
    assert.equal(forbidden.statusCode, 400);
    assert.equal((await app.inject({ method: "POST", url: "/api/packets/approve", headers, payload: { ids: [first.id], acknowledgeWarnings: true } })).statusCode, 400);
    const state = await app.inject({ method: "GET", url: "/api/state", headers });
    assert.equal(state.json().stats.limit, null); assert.equal(state.json().campaign.totalTarget, 22500);
    assert.equal(state.json().campaign.confirmedTotal, 0);
  } finally { await app.close(); await rm(dir, { recursive: true, force: true }); }
});

test("manual-only and no-AI applications can be logged and tracked without generating content", async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-external-api-"));
  const { app, store } = await createApp({ dataDir: dir, port: 4318 });
  const host = { host: "127.0.0.1:4318" };
  try {
    const job = jobFixture({ sourceId: "canonical", aiPolicy: "prohibited" }); store.saveJob(job);
    const session = await app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = session.cookies[0]!;
    const headers = { ...host, cookie: `${cookie.name}=${cookie.value}` };
    const response = await app.inject({ method: "POST", url: "/api/external-applications", headers, payload: {
      jobId: job.id, submittedDate: localDate(), confirmation: "Synthetic user-reported receipt EXTERNAL-123."
    } });
    assert.equal(response.statusCode, 200, response.body);
    const id = response.json().application.id;
    assert.equal(store.packets().length, 0); assert.equal(store.profile().confirmed, false);
    const duplicate = await app.inject({ method: "POST", url: "/api/external-applications", headers, payload: {
      jobId: job.id, submittedDate: localDate(), confirmation: "Repeated receipt EXTERNAL-123."
    } });
    assert.equal(duplicate.statusCode, 400);
    for (const stage of ["interview", "offer"]) {
      const result = await app.inject({ method: "POST", url: `/api/external-applications/${id}/progress`, headers, payload: { stage, note: "Synthetic reported outcome." } });
      assert.equal(result.statusCode, 200, result.body);
    }
    const state = (await app.inject({ method: "GET", url: "/api/state", headers })).json();
    assert.equal(state.stats.submitted, 1); assert.equal(state.stats.attemptsToday, 0);
    assert.equal(state.campaign.confirmedToday, 1); assert.equal(state.campaign.interviews, 1); assert.equal(state.campaign.offers, 1);
    assert.equal(store.hasConflictingApplication(job.id), true);
  } finally { await app.close(); await rm(dir, { recursive: true, force: true }); }
});

test("job import, manual packet approval and human reconciliation persist truthful outcomes", async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-api-flow-"));
  const { app, store } = await createApp({ dataDir: dir, port: 4318 });
  const host = { host: "127.0.0.1:4318" };
  try {
    const session = await app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = session.cookies[0]!;
    const headers = { ...host, cookie: `${cookie.name}=${cookie.value}` };
    const profile = await app.inject({ method: "POST", url: "/api/profile", headers, payload: { profile: profileFixture() } });
    assert.equal(profile.statusCode, 200);
    const imported = await app.inject({ method: "POST", url: "/api/jobs/import", headers, payload: { title: "Data Engineer", company: "Example Corp",
      description: "Build data systems with Python, Apache Spark, Kafka and SQL for our engineering team.", applyUrl: "https://example.test/careers/1", location: "India", employmentType: "Full-time" } });
    assert.equal(imported.statusCode, 200, imported.body);
    const prepared = await app.inject({ method: "POST", url: "/api/packets", headers, payload: { jobId: imported.json().job.id, mode: "deterministic" } });
    assert.equal(prepared.statusCode, 200, prepared.body);
    const id = prepared.json().packet.id;
    const approve = await app.inject({ method: "POST", url: "/api/packets/approve", headers, payload: { ids: [id], acknowledgeWarnings: true } });
    assert.equal(approve.statusCode, 200, approve.body);
    assert.equal(approve.json().packets[0].status, "manual_only");
    const document = await app.inject({ method: "GET", url: `/api/packets/${id}/documents/pdf`, headers });
    assert.equal(document.statusCode, 200); assert.equal(document.rawPayload.subarray(0, 4).toString(), "%PDF");
    const confirmation = await app.inject({ method: "POST", url: `/api/packets/${id}/confirm`, headers, payload: { confirmation: "I saw the employer confirmation reference EXAMPLE-123." } });
    assert.equal(confirmation.statusCode, 200);
    assert.match(store.packet(id)!.confirmation!, /^User-reported confirmation:/);
    assert.equal(store.packet(id)!.status, "submitted_confirmed");
    assert.equal(store.attempts(new Date().toISOString().slice(0, 10)), 0);
    const badUrl = await app.inject({ method: "POST", url: "/api/jobs/import", headers, payload: { title: "Data Engineer", company: "Example", description: "A sufficiently detailed technical job description.", applyUrl: "http://127.0.0.1/private" } });
    assert.equal(badUrl.statusCode, 400);
  } finally { await app.close(); await rm(dir, { recursive: true, force: true }); }
});
