import { emptyProfile, type Job, type Profile } from "../packages/domain/types.js";
export function profileFixture(): Profile {
  return { ...emptyProfile(), name: "Example Applicant", email: "applicant@example.test", phone: "+91 0000000000", location: "India",
    skills: ["Python", "Apache Kafka", "Apache Spark", "SQL", "AWS"], confirmed: true,
    facts: [
      { id: "exp-1", category: "experience", employer: "Example Systems", role: "Data Engineer", dates: "2023 - Present", text: "Built Apache Kafka and Spark pipelines using Python and SQL on AWS.", confirmed: true },
      { id: "exp-2", category: "experience", employer: "Example Systems", role: "Data Engineer", dates: "2023 - Present", text: "Reduced pipeline cost by 20% through measured resource tuning.", confirmed: true },
      { id: "edu-1", category: "education", text: "Example University | Bachelor of Engineering | 2023", confirmed: true }
    ]
  };
}
export function jobFixture(extra: Partial<Job> = {}): Job {
  return { id: "fixture-job", sourceId: "fixture", sourceJobId: "fixture-job", title: "Data Engineer", company: "Example Employer",
    location: "India", remote: false, countries: ["India"], employmentType: "Full-time",
    description: "Build reliable data pipelines using Python, SQL, Apache Kafka, Apache Spark and AWS. English is the working language.",
    applyUrl: "http://127.0.0.1:4318/fixture/application", canonicalUrl: "http://127.0.0.1:4318/fixture/application",
    fetchedAt: new Date().toISOString(), salary: { min: 5000000, currency: "INR", period: "year", kind: "base" },
    language: "English", sponsorship: "unknown", aiPolicy: "allowed", status: "open", ...extra };
}
