import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { Document, Packer, Paragraph } from "docx";
import { createApp } from "../apps/local/server.js";
import { profileFixture, jobFixture } from "./fixtures.js";
import type { ApplicationBrowserDriver } from "../packages/automation/contracts.js";

const browser: ApplicationBrowserDriver = {
  inspect: async () => ({ status: "unsupported", reason: "No real site in API fixtures." }),
  submit: async () => { throw new Error("No submission is permitted in this API fixture."); },
  openForSetup: async () => {}, isRunning: () => false, close: async () => {}
};
async function multipartUpload(name: string, email: string, approved: boolean) {
  const bytes = await Packer.toBuffer(new Document({ sections: [{ children: [
    new Paragraph(name), new Paragraph(email),
    new Paragraph("Software and data engineering. Built Python, SQL and Apache Kafka pipelines on AWS. Fictional fixture employment and education.")
  ] }] }));
  const form = new FormData();
  form.append("file", new Blob([new Uint8Array(bytes)], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" }), "resume.docx");
  form.append("label", "Approved role resume"); form.append("families", '["data","software"]'); form.append("approved", String(approved));
  const request = new Request("http://127.0.0.1/upload", { method: "POST", body: form });
  return { payload: Buffer.from(await request.arrayBuffer()), contentType: request.headers.get("content-type")! };
}

test("two nonadjacent resume slots, explicit activation, and change revocation are wired through authenticated APIs", async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-auto-api-"));
  const { app, store } = await createApp({ dataDir: dir, port: 4340, autopilotOptions: { browser } });
  const host = { host: "127.0.0.1:4340" };
  try {
    const session = await app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = session.cookies[0]!;
    const headers = { ...host, cookie: `${cookie.name}=${cookie.value}` };
    const profile = profileFixture(); profile.name = "Riley Jordan"; profile.email = "riley.jordan@example.test";
    assert.equal((await app.inject({ method: "POST", url: "/api/profile", headers, payload: { profile } })).statusCode, 200);
    const initial = (await app.inject({ method: "GET", url: "/api/state", headers })).json();
    assert.equal(initial.autopilot.ready, false);
    assert.equal(initial.resumeVariants.length, 0);
    assert.equal((await app.inject({ method: "POST", url: "/api/autopilot/enable", headers, payload: { snapshotHash: initial.autopilot.snapshotHash } })).statusCode, 400);
    const upload = await multipartUpload(profile.name, profile.email, true);
    for (const slot of [2, 4]) {
      const result = await app.inject({ method: "POST", url: `/api/resume-variants/${slot}`,
        headers: { ...headers, "content-type": upload.contentType }, payload: upload.payload });
      assert.equal(result.statusCode, 200, result.body);
      assert.equal(result.json().variant.approved, true);
      assert.equal("text" in result.json().variant, false);
      if (slot === 2) assert.equal((await app.inject({ method: "GET", url: "/api/state", headers })).json().autopilot.ready, false);
    }
    const state = (await app.inject({ method: "GET", url: "/api/state", headers })).json();
    assert.equal(state.autopilot.ready, true);
    assert.equal(state.autopilot.enabled, false);
    assert.equal(state.resumeVariants.length, 2);
    assert.equal(state.autopilot.rules.resumeStrategy, "job-tailored");
    const enable = await app.inject({ method: "POST", url: "/api/autopilot/enable", headers, payload: {
      snapshotHash: state.autopilot.snapshotHash, authorizeSubmission: true, confirmAccuracy: true, confirmSiteRules: true
    } });
    assert.equal(enable.statusCode, 200, enable.body);
    assert.equal(enable.json().autopilot.enabled, true);
    const id = state.resumeVariants[0].id;
    const download = await app.inject({ method: "GET", url: `/api/resume-variants/${id}/file`, headers });
    assert.equal(download.statusCode, 200);
    assert.equal(download.rawPayload.subarray(0, 2).toString(), "PK");
    assert.equal((await app.inject({ method: "GET", url: `/api/resume-variants/${id}/file`, headers: host })).statusCode, 401);
    const changed = await app.inject({ method: "POST", url: `/api/resume-variants/${id}/approval`, headers, payload: { approved: false } });
    assert.equal(changed.statusCode, 200);
    assert.equal((await app.inject({ method: "GET", url: "/api/state", headers })).json().autopilot.enabled, false);
    assert.equal(store.confirmedCount(), 0);
  } finally { await app.close(); await rm(dir, { recursive: true, force: true }); }
});

test("one approved template can preview a JD-specific resume without enabling automatic sending", async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-preview-api-"));
  const { app, store } = await createApp({ dataDir: dir, port: 4340, autopilotOptions: { browser } });
  const host = { host: "127.0.0.1:4340" };
  try {
    const session = await app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = session.cookies[0]!;
    const headers = { ...host, cookie: `${cookie.name}=${cookie.value}` };
    const profile = profileFixture(); profile.name = "Riley Jordan"; profile.email = "riley.jordan@example.test";
    store.set("profile", profile); store.saveJob(jobFixture());
    const upload = await multipartUpload(profile.name, profile.email, true);
    const result = await app.inject({ method: "POST", url: "/api/resume-variants/3", headers: { ...headers, "content-type": upload.contentType }, payload: upload.payload });
    assert.equal(result.statusCode, 200);
    const variant = result.json().variant;
    const preview = await app.inject({ method: "POST", url: `/api/resume-variants/${variant.id}/tailor`, headers, payload: { jobId: "fixture-job", mode: "deterministic" } });
    assert.equal(preview.statusCode, 200, preview.body);
    assert.equal(preview.json().packet.status, "prepared");
    assert.equal(preview.json().packet.draft.mode, "jd-tailored");
    assert.equal(preview.json().packet.tailoring.baseVariantId, variant.id);
    const repeat = await app.inject({ method: "POST", url: `/api/resume-variants/${variant.id}/tailor`, headers, payload: { jobId: "fixture-job", mode: "deterministic" } });
    assert.equal(repeat.statusCode, 200, repeat.body);
    assert.equal(repeat.json().packet.id, preview.json().packet.id);
    const state = (await app.inject({ method: "GET", url: "/api/state", headers })).json();
    assert.equal(state.autopilot.enabled, false);
    assert.equal(state.autopilot.ready, false);
    assert.equal(state.stats.submitted, 0);
    assert.equal(state.stats.attemptsToday, 0);
    for (const format of ["pdf", "docx"]) {
      const download = await app.inject({ method: "GET", url: `/api/packets/${preview.json().packet.id}/documents/${format}`, headers });
      assert.equal(download.statusCode, 200);
    }
  } finally { await app.close(); await rm(dir, { recursive: true, force: true }); }
});
