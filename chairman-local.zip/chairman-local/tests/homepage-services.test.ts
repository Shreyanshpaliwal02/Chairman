import test from "node:test";
import assert from "node:assert/strict";
import { Store } from "../apps/local/store.js";
import { SearchPortalService } from "../apps/local/search-portals.js";
import { DiscoveryService } from "../apps/local/discovery-service.js";
import { ApplicationTracker } from "../apps/local/application-tracker.js";
import { SOURCES } from "../packages/adapters/sources.js";
import { searchPortalUrl, validateSearchTemplate } from "../packages/domain/discovery-settings.js";
import { jobFixture } from "./fixtures.js";

test("manual search websites validate templates and persist without enabling any automation", () => {
  const store = new Store(":memory:");
  try {
    const service = new SearchPortalService(store);
    const result = service.update({ action: "save", label: "My public search", urlTemplate: "https://jobs.example.com/search?role={role}&location={location}" });
    const saved = result.portals.find(portal => !portal.builtIn)!;
    assert.equal(new SearchPortalService(store).list().portals.at(-1)!.id, saved.id);
    assert.equal(searchPortalUrl(saved.urlTemplate, "C++ / backend", "India & remote"), "https://jobs.example.com/search?role=C%2B%2B%20%2F%20backend&location=India%20%26%20remote");
    assert.equal(store.value("autopilot", null), null);
    for (const template of ["http://jobs.example.com/", "javascript:alert(1)", "https://user:password@jobs.example.com", "https://localhost/jobs", "https://127.0.0.1/", "https://[::1]/", "https://jobs.example.com/{unknown}", "https://{role}.example.com/"])
      assert.throws(() => validateSearchTemplate(template));
    assert.throws(() => service.update({ action: "save", id: "indeed", label: "Override", urlTemplate: "https://jobs.example.com" }));
    assert.throws(() => service.update({ action: "save", label: "Escalation", urlTemplate: "https://jobs.example.com", discoveryAllowed: true }));
    assert.equal(service.update({ action: "remove", id: saved.id }).portals.some(portal => portal.id === saved.id), false);
  } finally { store.close(); }
});

test("public feed preferences persist while base permissions, denied holds, and cooldowns remain immutable", async () => {
  const store = new Store(":memory:");
  let requests = 0;
  try {
    const service = new DiscoveryService(store, { scanner: async () => { requests++; return { jobs: [] }; } });
    const next = Date.now() + 600_000;
    store.set("nextScan:himalayas", next);
    assert.equal(service.setPreference({ sourceId: "himalayas", enabled: false }).changed, true);
    assert.equal(service.setPreference({ sourceId: "himalayas", enabled: false }).changed, false);
    assert.equal(new DiscoveryService(store).sources().find(source => source.id === "himalayas")!.mode, "paused");
    assert.match((await service.scan("himalayas")).results[0]!.error!, /not enabled/);
    assert.match(await service.scanPreferred({ roles: ["engineer"], countries: ["India"] }), /paused/);
    assert.equal(requests, 0);
    assert.equal(service.setPreference({ sourceId: "himalayas", enabled: true }).changed, true);
    assert.equal(store.value("nextScan:himalayas", 0), next);
    assert.match((await service.scan("himalayas")).results[0]!.error!, /cooldown/);
    assert.throws(() => service.setPreference({ sourceId: "indeed", enabled: true }), /no reviewed/);
    store.set("sourceHealth", { linkedin: { mode: "enabled", discoveryAllowed: true, assistanceAllowed: true }, himalayas: { mode: "blocked" } });
    assert.equal(service.sources().find(source => source.id === "linkedin")!.mode, "manual_only");
    assert.equal(service.sources().find(source => source.id === "linkedin")!.assistanceAllowed, false);
    assert.equal(service.sources().find(source => source.id === "himalayas")!.mode, "blocked");
    assert.equal(SOURCES.find(source => source.id === "himalayas")!.mode, "enabled");
  } finally { store.close(); }
});

test("cloud jobs from paused sources are not imported but their cursor advances", async () => {
  const store = new Store(":memory:");
  let calls = 0;
  try {
    const service = new DiscoveryService(store, { cloudUrl: "https://scanner.example.com", cloudToken: "synthetic",
      cloudSync: async () => ++calls === 1 ? { jobs: [jobFixture({ sourceId: "himalayas" })], nextCursor: "1" } : { jobs: [], nextCursor: "1" },
      scanner: async () => ({ jobs: [] }) });
    service.setPreference({ sourceId: "himalayas", enabled: false });
    await service.scan();
    assert.equal(store.jobCount(), 0);
    assert.equal(store.value("cloudCursor:https://scanner.example.com", ""), "1");
  } finally { store.close(); }
});

test("pausing during a scan discards its response and prevents later queued source requests", async () => {
  const store = new Store(":memory:");
  const requests: string[] = [];
  try {
    const service = new DiscoveryService(store, { scanner: async id => {
      requests.push(id);
      if (id === "supabase") {
        service.setPreference({ sourceId: "supabase", enabled: false });
        service.setPreference({ sourceId: "automattic", enabled: false });
        return { jobs: [jobFixture({ sourceId: "supabase" })] };
      }
      return { jobs: [] };
    } });
    const result = await service.scan();
    assert.equal(requests.includes("automattic"), false);
    assert.equal(store.jobCount(), 0);
    assert.match(result.results.find(item => item.sourceId === "supabase")!.error!, /discarded/);
    assert.ok(store.value("nextScan:supabase", 0) > Date.now());
  } finally { store.close(); }
});

test("monitoring merges linked Chrome records, paginates globally, and never treats a fill as applied", () => {
  const store = new Store(":memory:");
  try {
    const tracker = new ApplicationTracker(store);
    assert.equal(tracker.list().total, 0);
    const job = jobFixture();
    store.saveJob(job);
    const packet = { id: "p1", jobId: job.id, status: "prepared", createdAt: "2026-09-20T10:00:00Z" };
    store.db.prepare("INSERT INTO packets VALUES (?,?,?)").run(packet.id, job.id, JSON.stringify(packet));
    assert.equal(tracker.list().items[0]!.kind, "packet");
    tracker.setNote("packet", "p1", { notes: "Follow up after review" });
    assert.equal(tracker.list({ q: "Follow up" }).total, 1);
    store.db.exec("CREATE TABLE assistance_records(id TEXT PRIMARY KEY,json TEXT NOT NULL)");
    const assistance = { id: "a1", jobId: job.id, packetId: "p1", company: job.company, title: job.title, portal: "jobs.example.com",
      sourceUrl: "https://jobs.example.com/job", status: "filled", notes: "Not sent", createdAt: "2026-09-20T10:30:00Z", updatedAt: "2026-09-20T10:30:00Z" };
    store.db.prepare("INSERT INTO assistance_records VALUES (?,?)").run(assistance.id, JSON.stringify(assistance));
    assert.equal(tracker.list().total, 1);
    assert.equal(tracker.list().items[0]!.status, "filled");
    assert.equal(tracker.list({ stage: "applied" }).total, 0);
    assert.equal(store.confirmedCount(), 0);
    store.putExternal({ id: "e1", jobId: job.id, sourceId: "manual", submittedDate: "2026-09-20", confirmation: "Synthetic actual receipt",
      createdAt: "2026-09-20T11:00:00Z", progress: { stage: "interview", note: "User reported", updatedAt: "2026-09-20T12:00:00Z" } });
    const confirmed = tracker.list({ stage: "interview", status: "submitted_confirmed" });
    assert.equal(confirmed.total, 1);
    assert.equal(confirmed.items[0]!.progress!.id, "e1");
    for (let i = 2; i <= 32; i++) store.db.prepare("INSERT INTO packets VALUES (?,?,?)").run(`p${i}`, job.id,
      JSON.stringify({ ...packet, id: `p${i}`, createdAt: `2026-09-${String(i % 20 + 1).padStart(2, "0")}T10:00:00Z` }));
    const first = tracker.list({ limit: "25" });
    const second = tracker.list({ offset: "25", limit: "25" });
    assert.equal(first.items.length, 25); assert.equal(second.items.length, 7);
    assert.equal(new Set([...first.items, ...second.items].map(row => row.id)).size, 32);
    assert.throws(() => tracker.list({ limit: 500 }));
    assert.throws(() => tracker.setNote("packet", "missing", { notes: "None" }), /not found/);
    assert.throws(() => tracker.setNote("packet", "p1", { notes: "x".repeat(4001) }));
    assert.equal(store.packet("p1")!.status, "prepared");
    store.db.exec("CREATE TABLE autopilot_jobs(id TEXT PRIMARY KEY,job_id TEXT UNIQUE NOT NULL,status TEXT NOT NULL,json TEXT NOT NULL)");
    store.db.prepare("DELETE FROM external_applications WHERE id=?").run("e1");
    store.db.prepare("UPDATE assistance_records SET json=json_set(json,'$.status','queued') WHERE id=?").run("a1");
    store.db.prepare("INSERT INTO autopilot_jobs VALUES (?,?,?,?)").run("runner", job.id, "awaiting_human",
      JSON.stringify({ packetId: "p2", status: "awaiting_human", updatedAt: "2026-09-20T13:00:00Z" }));
    const queued = tracker.list({ kind: "assistance" }).items[0]!;
    assert.equal(queued.status, "awaiting_human"); assert.equal(queued.packetId, "p2"); assert.equal(queued.runnerOwned, true);
    assert.equal(tracker.list({ limit: 100 }).items.some(row => row.id === "p2"), false);
    store.db.prepare("UPDATE packets SET json=json_set(json,'$.status','submitted_confirmed','$.submittedAt','2026-09-20T13:05:00Z') WHERE id=?").run("p2");
    const completed = tracker.list({ kind: "assistance" }).items[0]!;
    assert.equal(completed.status, "submitted_confirmed"); assert.equal(completed.progress!.id, "p2");
  } finally { store.close(); }
});
