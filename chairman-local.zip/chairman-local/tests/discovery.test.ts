import assert from "node:assert/strict";
import test from "node:test";
import { DiscoveryError, detectAiPolicy, normalizeHtml, retryAfterMs, scanSource, syncCloudJobs } from "../packages/adapters/discovery";
import { SOURCES, getSource } from "../packages/adapters/sources";

const himalayasJob = {
  title: "Platform Engineer", companyName: "Fixture Company", employmentType: "Contractor",
  minSalary: 60, maxSalary: 80, currency: "USD", salaryPeriod: "hourly",
  locationRestrictions: ["United States"], timezoneRestrictions: [-5],
  description: "<p>Build reliable systems.</p><script>stealCookies()</script>",
  pubDate: 1_788_000_000, expiryDate: 1_888_000_000,
  applicationLink: "https://careers.example.com/job/platform",
  guid: "https://himalayas.app/companies/fixture/jobs/platform"
};

function jsonFetch(payload: unknown): typeof fetch {
  return (async () => Response.json(payload)) as typeof fetch;
}

const errorIs = (code: string) => (error: unknown) => error instanceof DiscoveryError && error.code === code;

test("registry contains original and additional sources, with no blanket form permission", () => {
  assert.equal(SOURCES.length, 15);
  assert.equal(new Set(SOURCES.map((source) => source.id)).size, 15);
  for (const source of SOURCES) {
    assert.equal(source.assistanceAllowed, false);
    assert.equal(source.submissionAllowed, false);
    assert.match(source.policyUrl, /^https:\/\//);
    assert.ok(source.notes.length > 30);
  }
  const copy = getSource("himalayas")!;
  copy.endpoint = "http://localhost/";
  assert.equal(getSource("himalayas")!.endpoint, "https://himalayas.app/jobs/api");
  assert.equal(getSource("missing"), undefined);
});

test("manual and unknown sources never invoke fetch", async () => {
  let requests = 0;
  const fetcher = (async () => { requests++; throw new Error("Should not run"); }) as typeof fetch;
  for (const id of ["linkedin", "indeed", "wellfound", "naukri", "deel", "toptal", "sideshift"]) {
    await assert.rejects(scanSource(id, undefined, fetcher), errorIs("SOURCE_DISABLED"));
  }
  await assert.rejects(scanSource("https://localhost/", undefined, fetcher), errorIs("UNKNOWN_SOURCE"));
  assert.equal(requests, 0);
});

test("Himalayas uses opaque cursor, fixed endpoint and exact periodic salary", async () => {
  const fetcher = (async (input, init) => {
    const url = new URL(String(input));
    assert.equal(url.origin + url.pathname, "https://himalayas.app/jobs/api");
    assert.equal(url.searchParams.get("cursor"), "opaque+/==&x");
    assert.equal(url.searchParams.get("offset"), null);
    assert.equal(url.searchParams.get("limit"), "2");
    assert.equal(init?.redirect, "error");
    assert.equal(init?.method, "GET");
    return Response.json({ jobs: [himalayasJob], nextCursor: "next-opaque" });
  }) as typeof fetch;
  const result = await scanSource("himalayas", "opaque+/==&x", fetcher, { pageSize: 2 });
  assert.equal(result.nextCursor, "next-opaque");
  const job = result.jobs[0]!;
  assert.deepEqual(job.countries, ["United States"]);
  assert.equal(job.remote, true);
  assert.match(job.location, /timezone restrictions: -5/);
  assert.deepEqual(job.salary, { min: 60, max: 80, currency: "USD", period: "hourly", kind: "unknown" });
  assert.equal(job.employmentType, "Contract");
  assert.equal(job.sponsorship, "unknown");
  assert.equal(job.language, null);
  assert.match(job.description, /Original source: Himalayas — https:\/\/himalayas.app/);
  assert.doesNotMatch(job.description, /script|stealCookies/);
  assert.equal(job.canonicalUrl, himalayasJob.guid);
});

test("remote without country evidence does not become India-eligible or worldwide", async () => {
  const result = await scanSource("himalayas", undefined, jsonFetch({ jobs: [{ ...himalayasJob, locationRestrictions: [] }] }));
  assert.deepEqual(result.jobs[0]!.countries, []);
  assert.match(result.jobs[0]!.location, /unspecified/);
});

test("missing salary stays unknown, publication/expiry retain truthful status", async () => {
  const result = await scanSource("himalayas", undefined, jsonFetch({ jobs: [{ ...himalayasJob, minSalary: null, maxSalary: null, expiryDate: 1_600_000_000 }] }));
  assert.equal(result.jobs[0]!.salary, null);
  assert.equal(result.jobs[0]!.status, "closed");
  assert.equal(result.jobs[0]!.postedAt, new Date(himalayasJob.pubDate * 1_000).toISOString());
});

test("malformed payloads fail instead of appearing as successful empty scans", async () => {
  for (const payload of [{}, { jobs: {} }, { jobs: [{ ...himalayasJob, title: 5 }] }, { jobs: [{ ...himalayasJob, title: "<script>not a title</script>" }] }, { jobs: [{ ...himalayasJob, locationRestrictions: "India" }] }, { jobs: [{ ...himalayasJob, pubDate: "not a date" }] }]) {
    await assert.rejects(scanSource("himalayas", undefined, jsonFetch(payload)), errorIs("INVALID_DATA"));
  }
  await assert.rejects(scanSource("himalayas", undefined, (async () => new Response("<html>blocked</html>")) as typeof fetch), errorIs("INVALID_DATA"));
});

test("unsafe listing links and changed Himalayas attribution hosts are rejected", async () => {
  for (const applicationLink of ["http://localhost/job", "https://127.0.0.1/job", "https://[::1]/job", "javascript:alert(1)", "https://user:password@example.com/job", "https://internal.local/job"]) {
    await assert.rejects(scanSource("himalayas", undefined, jsonFetch({ jobs: [{ ...himalayasJob, applicationLink }] })), errorIs("INVALID_DATA"));
  }
  await assert.rejects(scanSource("himalayas", undefined, jsonFetch({ jobs: [{ ...himalayasJob, guid: "https://other.example.com/job" }] })), errorIs("INVALID_DATA"));
});

test("pagination enforces result limits, distinct IDs and progress", async () => {
  await assert.rejects(scanSource("himalayas", undefined, jsonFetch({ jobs: [himalayasJob, himalayasJob] }), { pageSize: 1 }), errorIs("INVALID_DATA"));
  await assert.rejects(scanSource("himalayas", undefined, jsonFetch({ jobs: [himalayasJob, himalayasJob] })), errorIs("INVALID_DATA"));
  await assert.rejects(scanSource("himalayas", "same", jsonFetch({ jobs: [himalayasJob], nextCursor: "same" })), errorIs("INVALID_DATA"));
  await assert.rejects(scanSource("himalayas", undefined, jsonFetch({ jobs: [], nextCursor: "next" })), errorIs("INVALID_DATA"));
  assert.deepEqual(await scanSource("himalayas", undefined, jsonFetch({ jobs: [] })), { jobs: [] });
});

test("invalid cursors are rejected before network requests", async () => {
  const noFetch = (async () => { throw new Error("No network"); }) as typeof fetch;
  for (const cursor of ["", "\n", "a".repeat(2_049)]) await assert.rejects(scanSource("himalayas", cursor, noFetch), errorIs("INVALID_CURSOR"));
  await assert.rejects(scanSource("canonical", "../../private", noFetch), errorIs("INVALID_CURSOR"));
  await assert.rejects(scanSource("supabase", "https://localhost/", noFetch), errorIs("INVALID_CURSOR"));
});

test("byte budgets apply to announced and streamed body sizes", async () => {
  await assert.rejects(scanSource("himalayas", undefined, (async () => new Response("{}", { headers: { "Content-Length": "9999" } })) as typeof fetch, { maxResponseBytes: 50 }), errorIs("TOO_LARGE"));
  await assert.rejects(scanSource("himalayas", undefined, (async () => new Response("x".repeat(200))) as typeof fetch, { maxResponseBytes: 50 }), errorIs("TOO_LARGE"));
});

test("fetch and body timeouts remain bounded even for stalled fixtures", async () => {
  const stalledFetch = (async () => new Promise<Response>(() => {})) as typeof fetch;
  await assert.rejects(scanSource("himalayas", undefined, stalledFetch, { timeoutMs: 5 }), errorIs("TIMEOUT"));
  const stalledBody = (async () => new Response(new ReadableStream<Uint8Array>({ start() {} }))) as typeof fetch;
  await assert.rejects(scanSource("himalayas", undefined, stalledBody, { timeoutMs: 5 }), errorIs("TIMEOUT"));
});

test("redirects and error pages never trigger a follow-up fetch", async () => {
  let calls = 0;
  const fetcher = (async (_input, init) => {
    calls++;
    assert.equal(init?.redirect, "error");
    return new Response(null, { status: 302, headers: { Location: "http://127.0.0.1/private" } });
  }) as typeof fetch;
  await assert.rejects(scanSource("himalayas", undefined, fetcher), errorIs("REDIRECT"));
  assert.equal(calls, 1);
});

test("429 and 503 preserve Retry-After, without leaking upstream bodies", async () => {
  for (const status of [429, 503]) {
    await assert.rejects(scanSource("himalayas", undefined, (async () => new Response("private stack trace", { status, headers: { "Retry-After": "7200" } })) as typeof fetch), (error: unknown) => {
      assert.ok(error instanceof DiscoveryError);
      assert.equal(error.httpStatus, status);
      assert.equal(error.retryAfterMs, 7_200_000);
      assert.doesNotMatch(error.message, /private/);
      return true;
    });
  }
  assert.equal(retryAfterMs("Wed, 01 Jan 2025 00:01:00 GMT", Date.parse("2025-01-01T00:00:00Z")), 60_000);
  assert.equal(retryAfterMs("nonsense"), undefined);
});

test("HTML normalization handles encoded vendor markup without retaining executable content", () => {
  assert.equal(normalizeHtml("&amp;lt;p&amp;gt;Hello &amp;amp; goodbye&amp;lt;/p&amp;gt;"), "Hello & goodbye");
  assert.equal(normalizeHtml("<p>Safe</p><style>bad{}</style><iframe>hidden</iframe><p>&#x1F600; &bogus;</p>"), "Safe\n\n😀 &bogus;");
  assert.doesNotMatch(normalizeHtml("<script>unclosed script"), /unclosed/);
  assert.equal(normalizeHtml("<script><svg></svg>still hidden</script><p>Safe</p>"), "Safe");
});

test("AI-prohibited content gates are conservative, not triggered by ordinary AI product descriptions", () => {
  for (const value of ["Do not use ChatGPT to write your answer.", "AI-generated answers are not permitted.", "Please write your answers in your own words.", "No-AI declaration"]) {
    assert.equal(detectAiPolicy(value), "prohibited");
  }
  assert.equal(detectAiPolicy("Build AI infrastructure; we use AI for matching."), "unknown");
  assert.equal(detectAiPolicy("We welcome AI assistance."), "unknown");
});

const ashbyJob = {
  id: "12345678-abcd-abcd-abcd-123456789012", title: "Database Engineer", isListed: true,
  isRemote: null, workplaceType: null, location: "Remote, Global", employmentType: "FullTime",
  address: null, secondaryLocations: [], publishedAt: "2026-01-01T00:00:00Z",
  jobUrl: "https://jobs.ashbyhq.com/supabase/12345678-abcd-abcd-abcd-123456789012",
  applyUrl: "https://jobs.ashbyhq.com/supabase/12345678-abcd-abcd-abcd-123456789012/application",
  descriptionHtml: "<p>Work with Postgres.</p>",
  compensation: { summaryComponents: [
    { compensationType: "Salary", minValue: 120000, maxValue: 160000, currencyCode: "USD", interval: "1 YEAR" },
    { compensationType: "EquityPercentage", minValue: 0.1, maxValue: 0.2 }
  ] }
};

test("Supabase honors listing visibility, structured countries, and salary component boundaries", async () => {
  const result = await scanSource("supabase", undefined, jsonFetch({
    jobs: [
      { ...ashbyJob, id: "private", isListed: false },
      { ...ashbyJob, address: { postalAddress: { addressCountry: "IND" } } }
    ]
  }));
  assert.equal(result.jobs.length, 1);
  assert.equal(result.jobs[0]!.remote, true);
  assert.deepEqual(result.jobs[0]!.countries, ["India"]);
  assert.equal(result.jobs[0]!.salary?.kind, "base");
  assert.equal(result.jobs[0]!.salary?.period, "annual");
  assert.equal(result.jobs[0]!.salary?.min, 120000);
  const noPay = await scanSource("supabase", undefined, jsonFetch({ jobs: [{ ...ashbyJob, shouldDisplayCompensationOnJobPostings: false }] }));
  assert.equal(noPay.jobs[0]!.salary, null);
  assert.deepEqual(noPay.jobs[0]!.countries, []);
});

test("Ashby continuation uses stable sorted IDs instead of page indexes", async () => {
  const secondId = "22345678-abcd-abcd-abcd-123456789012";
  const second = { ...ashbyJob, id: secondId, jobUrl: `https://jobs.ashbyhq.com/supabase/${secondId}`, applyUrl: `https://jobs.ashbyhq.com/supabase/${secondId}/application` };
  const fetcher = jsonFetch({ jobs: [second, ashbyJob] });
  const first = await scanSource("supabase", undefined, fetcher, { pageSize: 1 });
  assert.equal(first.nextCursor, ashbyJob.id);
  const next = await scanSource("supabase", first.nextCursor, fetcher, { pageSize: 1 });
  assert.equal(next.jobs[0]!.sourceJobId, secondId);
  assert.equal(next.nextCursor, undefined);
});

test("Greenhouse uses a fixed board and one detail, skipping prospect posts", async () => {
  const calls: string[] = [];
  const fetcher = (async (input) => {
    const url = String(input);
    calls.push(url);
    if (!url.includes("?")) return Response.json({ jobs: [{ id: 1, internal_job_id: null }, { id: 7, internal_job_id: 9 }, { id: 8, internal_job_id: 10 }] });
    return Response.json({
      id: 7, title: "Cloud Engineer", content: "&lt;p&gt;Your answers must be in your own words.&lt;/p&gt;",
      location: { name: "Home based - Worldwide" }, absolute_url: "https://job-boards.greenhouse.io/canonical/jobs/7",
      language: "en", first_published: "2026-01-01T00:00:00Z",
      metadata: [{ name: "Employment Length", value: "Full-time" }]
    });
  }) as typeof fetch;
  const result = await scanSource("canonical", undefined, fetcher);
  assert.deepEqual(calls, [
    "https://boards-api.greenhouse.io/v1/boards/canonical/jobs",
    "https://boards-api.greenhouse.io/v1/boards/canonical/jobs/7?questions=true"
  ]);
  assert.equal(result.nextCursor, "7");
  assert.equal(result.jobs[0]!.aiPolicy, "prohibited");
  assert.equal(result.jobs[0]!.language, null);
  assert.deepEqual(result.jobs[0]!.countries, []);
  assert.equal(result.jobs[0]!.employmentType, "Full-time");
  assert.equal(result.jobs[0]!.remote, true);
});

test("Automattic respects no-AI public question labels and does not call a form POST", async () => {
  const fetcher = (async (input, init) => {
    assert.equal(init?.method, "GET");
    if (!String(input).includes("?")) return Response.json({ jobs: [{ id: 10, internal_job_id: 11 }] });
    return Response.json({
      id: 10, title: "Engineer", content: "<p>Build tools.</p>", location: { name: "Remote, United States" },
      absolute_url: "https://automattic.com/work-with-us/engineer/", updated_at: "2026-01-01",
      questions: [{ label: "Do not use AI tools to complete this application." }]
    });
  }) as typeof fetch;
  const result = await scanSource("automattic", undefined, fetcher);
  assert.equal(result.jobs[0]!.company, "Automattic");
  assert.equal(result.jobs[0]!.postedAt, undefined);
  assert.equal(result.jobs[0]!.aiPolicy, "prohibited");
});

const rssFixture = `<?xml version="1.0"?><rss xmlns:content="http://purl.org/rss/1.0/modules/content/"><channel>
<title>Careers at SafetyWing</title><item><title>Platform Engineer</title>
<link>https://safetywing.pinpointhq.com/jobs/123</link><pubDate>Wed, 01 Jan 2025 00:00:00 GMT</pubDate>
<content:encoded>&lt;p&gt;&lt;strong&gt;Employment Type: &lt;/strong&gt;Permanent - Full Time&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Location: &lt;/strong&gt;Remote&lt;/p&gt;&lt;p&gt;Build systems.&lt;/p&gt;</content:encoded>
</item></channel></rss>`;

test("published Pinpoint RSS handles a single item and explicit metadata", async () => {
  const result = await scanSource("safetywing", undefined, (async () => new Response(rssFixture)) as typeof fetch);
  assert.equal(result.jobs.length, 1);
  assert.equal(result.jobs[0]!.employmentType, "Permanent - Full-time");
  assert.equal(result.jobs[0]!.location, "Remote");
  assert.deepEqual(result.jobs[0]!.countries, []);
  assert.equal(result.jobs[0]!.salary, null);
  assert.equal(result.jobs[0]!.language, null);
});

test("RSS rejects external entities, malformed XML and off-board job links", async () => {
  for (const fixture of [
    '<!DOCTYPE rss [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><rss/>',
    "<rss><channel></rss>",
    rssFixture.replace("https://safetywing.pinpointhq.com/jobs/123", "https://attacker.example.com/job")
  ]) {
    await assert.rejects(scanSource("safetywing", undefined, (async () => new Response(fixture)) as typeof fetch), errorIs("INVALID_DATA"));
  }
});

test("cloud sync sends a token only to the exact allowed Worker and strips unknown properties", async () => {
  const job = (await scanSource("himalayas", undefined, jsonFetch({ jobs: [himalayasJob] }))).jobs[0]!;
  const token = "x".repeat(40);
  const fetcher = (async (input, init) => {
    assert.equal(String(input), "https://job-application-scanner.fixture.workers.dev/jobs?cursor=7");
    assert.equal(new Headers(init?.headers).get("Authorization"), `Bearer ${token}`);
    assert.equal(init?.redirect, "error");
    return Response.json({ jobs: [{ ...job, candidateProfile: { private: true } }], nextCursor: "8" });
  }) as typeof fetch;
  const result = await syncCloudJobs("https://job-application-scanner.fixture.workers.dev", token, "7", fetcher);
  assert.equal(result.nextCursor, "8");
  assert.ok(!("candidateProfile" in result.jobs[0]!));
});

test("cloud sync refuses arbitrary URLs and regressing checkpoints", async () => {
  let calls = 0;
  const fetcher = (async () => { calls++; return Response.json({ jobs: [], nextCursor: "1" }); }) as typeof fetch;
  for (const url of ["https://other.fixture.workers.dev", "https://job-application-scanner.fixture.workers.dev.evil.com", "http://127.0.0.1", "https://job-application-scanner.fixture.workers.dev/redirect", "https://job-application-scanner.fixture.workers.dev?url=x"]) {
    await assert.rejects(syncCloudJobs(url, "x".repeat(40), undefined, fetcher));
  }
  assert.equal(calls, 0);
  await assert.rejects(syncCloudJobs("https://job-application-scanner.fixture.workers.dev", "x".repeat(40), "7", fetcher), errorIs("INVALID_DATA"));
  const job = (await scanSource("himalayas", undefined, jsonFetch({ jobs: [himalayasJob] }))).jobs[0]!;
  await assert.rejects(syncCloudJobs("https://job-application-scanner.fixture.workers.dev", "x".repeat(40), "7", jsonFetch({ jobs: [job], nextCursor: "7" })), errorIs("INVALID_DATA"));
});
