import test from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { mkdir, rm } from "node:fs/promises";
import { join, resolve } from "node:path";
import { Store } from "../apps/local/store.js";
import { ResumeLibrary } from "../apps/local/resume-library.js";
import { DEMO_EMAIL, demoDataDirectory, demoProfile, seedDemo } from "../apps/local/demo.js";
import { profileSchema } from "../apps/local/schemas.js";
import { resolveAnswers } from "../packages/automation/answers.js";
import { defaultDataDirectory } from "../packages/platform/paths.js";

test("demo data is fictional, valid, seeds two approved resumes, and never overwrites a real profile", async () => {
  const directory = resolve(`tests/.demo-${randomUUID()}`);
  await mkdir(directory, { recursive: true, mode: 0o700 });
  const store = new Store(join(directory, "demo.sqlite")), library = new ResumeLibrary(store, directory);
  try {
    assert.notEqual(demoDataDirectory(), defaultDataDirectory(), "the demo instance uses its own data folder");
    const profile = profileSchema.parse(demoProfile());
    assert.match(profile.email, /@example\.com$/, "reserved example domain");
    assert.equal(await seedDemo(store, library, directory), "seeded");
    assert.equal(store.profile().email, DEMO_EMAIL);
    const approved = library.approvedVariants();
    assert.deepEqual(approved.map(variant => variant.artifact.format).sort(), ["docx", "pdf"]);
    assert.ok(approved.every(variant => !variant.issues.length));
    assert.equal(await seedDemo(store, library, directory), "kept", "re-running keeps existing demo data");
    const plan = resolveAnswers(store.profile(), { id: "j", sourceId: "s", sourceJobId: "j", title: "Data Engineer", company: "Acme", location: "India", remote: false,
      countries: ["India"], employmentType: "Full-time", description: "Role.", applyUrl: "https://example.com", canonicalUrl: "https://example.com", fetchedAt: "2026-01-01",
      salary: null, language: null, sponsorship: "unknown", aiPolicy: "allowed", status: "open" },
      { url: "https://example.com", fingerprint: "x", hasCaptcha: false, hasLegal: false, unsupported: [], fields: [
        { key: "a", label: "First name", type: "text", required: true, options: [] },
        { key: "b", label: "Notice period (days)", type: "text", required: true, options: [] },
        { key: "c", label: "Why do you want to work here?", type: "textarea", required: true, options: [] },
      ] });
    assert.equal(plan.answers.a, "Demo");
    assert.equal(plan.answers.b, "30");
    assert.match(plan.answers.c, /Data Engineer role at Acme/);

    store.set("profile", { ...store.profile(), email: "real.person@fictional.invalid" });
    await assert.rejects(seedDemo(store, library, directory, true), /non-demo profile/, "a real profile is never replaced");
  } finally { store.db.close(); await rm(directory, { recursive: true, force: true }); }
});
