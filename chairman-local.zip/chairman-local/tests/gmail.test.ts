import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import { GmailService, suggestGmailStage } from "../apps/local/gmail.js";
import { Store } from "../apps/local/store.js";
import { createApp } from "../apps/local/server.js";
import { jobFixture } from "./fixtures.js";

const scope = "https://www.googleapis.com/auth/gmail.readonly";
const client = { clientId: "synthetic-test-client.apps.googleusercontent.com", clientSecret: "synthetic-private-client" };
const refreshToken = "synthetic-private-refresh", accessToken = "synthetic-private-access";
const json = (value: unknown) => Response.json(value);
async function fixture(fetcher: typeof fetch) {
  const dir = await mkdtemp(join(tmpdir(), "chairman-gmail-"));
  const store = new Store(join(dir, "test.sqlite"));
  const gmail = new GmailService(store, dir, fetcher);
  await gmail.load();
  return { gmail, dir, store, close: async () => { await gmail.close(); store.close(); await rm(dir, { recursive: true, force: true }); } };
}
async function authenticate(gmail: GmailService) {
  await gmail.configure(client);
  const { url } = await gmail.connect(), authorization = new URL(url);
  assert.equal(authorization.origin, "https://accounts.google.com");
  assert.equal(authorization.searchParams.get("scope"), scope);
  assert.equal(authorization.searchParams.get("code_challenge_method"), "S256");
  assert.ok(!url.includes(client.clientSecret));
  const callback = new URL(authorization.searchParams.get("redirect_uri")!);
  callback.search = new URLSearchParams({ state: authorization.searchParams.get("state")!, code: "synthetic-one-use-code" }).toString();
  const response = await fetch(callback);
  assert.equal(response.status, 200, await response.text());
  assert.equal(gmail.status().connected, true);
  return callback;
}
function seed(store: Store) {
  const job = jobFixture({ id: randomUUID(), applyUrl: "https://careers.example.test/jobs/1" });
  store.saveJob(job);
  const application = {
    id: randomUUID(), jobId: job.id, sourceId: job.sourceId, submittedDate: new Date().toISOString().slice(0, 10),
    confirmation: "User-reported actual receipt", createdAt: new Date().toISOString(),
    progress: { stage: "applied" as const, note: "Keep my notes", updatedAt: new Date().toISOString() },
  };
  store.putExternal(application);
  return application;
}

test("Gmail OAuth uses PKCE, private credentials, bounded metadata and explicit status review without counting submissions", async () => {
  const calls: { url: string; init?: RequestInit }[] = [];
  const environment = await fixture(async (input, init) => {
    const url = String(input); calls.push({ url, init });
    assert.equal(init?.redirect, "error");
    if (url.endsWith("/token")) {
      const body = new URLSearchParams(String(init?.body));
      assert.equal(body.get("client_secret"), client.clientSecret);
      assert.ok(body.get("code_verifier")!.length >= 43);
      return json({ access_token: accessToken, refresh_token: refreshToken, expires_in: 3600, token_type: "Bearer", scope });
    }
    assert.equal(new Headers(init?.headers).get("authorization"), `Bearer ${accessToken}`);
    if (url.includes("/messages?")) {
      assert.equal(new URL(url).searchParams.get("maxResults"), "25");
      assert.match(new URL(url).searchParams.get("q")!, /newer_than:90d/);
      return json({ messages: [{ id: "a123" }, { id: "b456" }] });
    }
    assert.equal(new URL(url).searchParams.get("format"), "metadata");
    assert.ok(!new URL(url).searchParams.get("fields")!.includes("body"));
    return json({
      id: url.includes("/a123?") ? "a123" : "b456", internalDate: String(Date.now()),
      snippet: "We would like to schedule your interview.",
      payload: { headers: [
        { name: "Subject", value: url.includes("/a123?") ? "Example Employer Data Engineer application" : "Unrelated Employer Data Engineer application" },
        { name: "From", value: "Example recruiter <recruiter@example.test>" },
      ] },
    });
  });
  try {
    const { gmail, store, dir } = environment;
    const application = seed(store), before = store.confirmedCount();
    const callback = await authenticate(gmail);
    assert.match(callback.hostname, /^127\.0\.0\.1$/);
    assert.equal(calls.length, 1, "OAuth must not scan the inbox");
    await gmail.scan();
    const status = gmail.status();
    assert.equal(status.suggestions.length, 1);
    assert.equal(status.suggestions[0]!.stage, "interview");
    assert.equal(store.externalApplication(application.id)!.progress.stage, "applied");
    assert.equal(store.confirmedCount(), before);
    assert.ok(!JSON.stringify(status).includes(refreshToken));
    assert.ok(!JSON.stringify(status).includes(client.clientSecret));
    assert.ok(!(await readFile(join(dir, "private", "gmail.json"), "utf8")).includes(accessToken));
    if (process.platform !== "win32") assert.equal((await stat(join(dir, "private", "gmail.json"))).mode & 0o077, 0);
    gmail.review({ id: status.suggestions[0]!.id, action: "accept" });
    assert.equal(store.externalApplication(application.id)!.progress.stage, "interview");
    assert.equal(store.externalApplication(application.id)!.progress.note, "Keep my notes");
    assert.equal(store.confirmedCount(), before);
    assert.equal(gmail.status().suggestions.length, 0);
    await assert.rejects(() => gmail.scan(), /paused/);
  } finally { await environment.close(); }
});

test("Gmail rejects nonce substitution and missing scopes, and never persists an unauthorized token", async () => {
  let exchanges = 0;
  const environment = await fixture(async () => { exchanges++; return json({ access_token: accessToken, refresh_token: refreshToken, expires_in: 3600, token_type: "Bearer", scope: "openid" }); });
  try {
    await environment.gmail.configure(client);
    await assert.rejects(() => environment.gmail.configure({ ...client, apiKey: "not-allowed" }), /Unknown fields/);
    const authorization = new URL((await environment.gmail.connect()).url);
    const callback = new URL(authorization.searchParams.get("redirect_uri")!);
    callback.search = new URLSearchParams({ state: "x".repeat(43), code: "test" }).toString();
    assert.equal((await fetch(callback)).status, 403);
    assert.equal(exchanges, 0);
    callback.searchParams.set("state", authorization.searchParams.get("state")!);
    const denied = await fetch(callback);
    assert.equal(denied.status, 400);
    assert.ok(!(await denied.text()).includes(refreshToken));
    assert.equal(exchanges, 1);
    assert.equal(environment.gmail.status().connected, false);
    assert.ok(!(await readFile(join(environment.dir, "private", "gmail.json"), "utf8")).includes(refreshToken));
  } finally { await environment.close(); }
});

test("Gmail quota pauses and explicit disconnect removes local secrets even when remote revocation fails", async () => {
  const environment = await fixture(async input => {
    if (String(input).endsWith("/token")) return json({ access_token: accessToken, refresh_token: refreshToken, expires_in: 3600, token_type: "Bearer", scope });
    return new Response("sensitive provider text never displayed", { status: 429, headers: { "Retry-After": "120" } });
  });
  try {
    seed(environment.store);
    await authenticate(environment.gmail);
    await assert.rejects(() => environment.gmail.scan(), /HTTP 429/);
    assert.ok(Date.parse(environment.gmail.status().nextScanAt!) >= Date.now() + 119000);
    assert.ok(!JSON.stringify(environment.gmail.status()).includes("sensitive provider"));
    await environment.gmail.disconnect(true);
    assert.equal(environment.gmail.status().connected, false);
    assert.equal(environment.gmail.status().configured, false);
    assert.match(environment.gmail.status().error!, /disconnected locally.*revocation was not confirmed/);
    assert.deepEqual(JSON.parse(await readFile(join(environment.dir, "private", "gmail.json"), "utf8")), {});
    const restarted = new GmailService(environment.store, environment.dir);
    await restarted.load();
    assert.equal(restarted.status().connected, false);
    await restarted.close();
  } finally { await environment.close(); }
});

test("Gmail classification excludes receipt-only mail and stale suggestions cannot overwrite newer tracker updates", async () => {
  assert.equal(suggestGmailStage("Thank you for your application. We will be in touch."), undefined);
  assert.equal(suggestGmailStage("We are not moving forward after your interview invitation."), "rejected");
  const environment = await fixture(async () => { throw new Error("No network should run."); });
  try {
    const application = seed(environment.store), id = "a".repeat(64);
    environment.store.set("gmail:suggestions", [{
      id, applicationId: application.id, applicationKind: "external", jobId: application.jobId,
      stage: "interview", previousStage: "applied",
    }]);
    environment.store.putExternal({ ...application, progress: { ...application.progress, stage: "offer" } });
    assert.throws(() => environment.gmail.review({ id, action: "accept" }), /newer application status/);
    assert.equal(environment.store.externalApplication(application.id)!.progress.stage, "offer");
    environment.gmail.review({ id, action: "dismiss" });
    assert.equal(environment.gmail.status().suggestions.length, 0);
  } finally { await environment.close(); }
});

test("Gmail endpoints are dashboard-only, exports omit credentials and data deletion clears private configuration", async () => {
  const dir = await mkdtemp(join(tmpdir(), "chairman-gmail-api-"));
  const runtime = await createApp({ dataDir: dir, port: 4392 });
  try {
    const host = { host: "127.0.0.1:4392" }, response = await runtime.app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = response.cookies[0]!, headers = { ...host, cookie: `${cookie.name}=${cookie.value}`, origin: "http://127.0.0.1:4392" };
    assert.equal((await runtime.app.inject({ method: "GET", url: "/api/gmail/status", headers: host })).statusCode, 401);
    assert.equal((await runtime.app.inject({ method: "GET", url: "/api/gmail/status", headers: { ...headers, origin: `chrome-extension://${"a".repeat(32)}` } })).statusCode, 403);
    assert.equal((await runtime.app.inject({ method: "POST", url: "/api/gmail/config", headers, payload: client })).statusCode, 200);
    const status = await runtime.app.inject({ method: "GET", url: "/api/gmail/status", headers });
    assert.equal(status.json().configured, true);
    assert.ok(!status.body.includes(client.clientSecret));
    const exported = await runtime.app.inject({ method: "GET", url: "/api/export", headers });
    assert.ok(!exported.body.includes(client.clientSecret));
    assert.equal((await runtime.app.inject({ method: "POST", url: "/api/gmail/connect", headers, payload: {} })).statusCode, 400);
    const removed = await runtime.app.inject({ method: "POST", url: "/api/data/delete", headers, payload: { confirmation: "DELETE LOCAL DATA" } });
    assert.equal(removed.statusCode, 200, removed.body);
    assert.deepEqual(JSON.parse(await readFile(join(dir, "private", "gmail.json"), "utf8")), {});
  } finally { await runtime.app.close(); await rm(dir, { recursive: true, force: true }); }
});
