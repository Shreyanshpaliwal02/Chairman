import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "../apps/local/server.js";

const host = { host: "127.0.0.1:4331" };
const extensionOrigin = `chrome-extension://${"b".repeat(32)}`;

test("the extension stays paired across service restarts; only a hash of its token is stored, privately", async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-pairing-"));
  const start = () => createApp({ dataDir: dir, port: 4331, fixtureMode: true });
  const dashboard = async (app: Awaited<ReturnType<typeof start>>["app"]) => {
    const session = await app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = session.cookies[0]!;
    return { ...host, cookie: `${cookie.name}=${cookie.value}`, origin: "http://127.0.0.1:4331" };
  };
  let runtime = await start();
  try {
    const token = (await runtime.app.inject({ method: "POST", url: "/api/extension/pair", headers: await dashboard(runtime.app) })).json().token as string;
    const extension = { ...host, origin: extensionOrigin, authorization: `Bearer ${token}` };
    assert.equal((await runtime.app.inject({ method: "POST", url: "/api/extension/connect", headers: extension })).statusCode, 200);
    assert.equal((await runtime.app.inject({ method: "GET", url: "/api/extension/jobs", headers: extension })).statusCode, 200);
    const state = (await runtime.app.inject({ method: "GET", url: "/api/state", headers: await dashboard(runtime.app) })).json();
    assert.deepEqual(state.runtime.extension, { paired: true, id: "b".repeat(32) }, "the dashboard learns which extension to ask to open application tabs");

    const file = join(dir, "private", "extension-pairing.json");
    const saved = await readFile(file, "utf8");
    assert.ok(!saved.includes(token), "the pairing token itself is never written to disk");
    if (process.platform !== "win32") assert.equal((await stat(file)).mode & 0o077, 0, "owner-only file");

    await runtime.app.close();
    runtime = await start();
    assert.equal((await runtime.app.inject({ method: "GET", url: "/api/extension/jobs", headers: extension })).statusCode, 200, "still paired after a restart");
    assert.equal((await runtime.app.inject({ method: "POST", url: "/api/extension/assist/sites", headers: extension, payload: {} })).statusCode, 200,
      "side-panel routes keep working too (the panel connected before the restart)");
    assert.equal((await runtime.app.inject({ method: "GET", url: "/api/extension/jobs", headers: { ...extension, origin: `chrome-extension://${"c".repeat(32)}` } })).statusCode, 403,
      "another extension cannot reuse the pairing");

    const fresh = (await runtime.app.inject({ method: "POST", url: "/api/extension/pair", headers: await dashboard(runtime.app) })).json().token as string;
    assert.equal((await runtime.app.inject({ method: "GET", url: "/api/extension/jobs", headers: extension })).statusCode, 401, "a new pairing token revokes the old one");
    assert.equal((await runtime.app.inject({ method: "GET", url: "/api/extension/jobs", headers: { ...extension, authorization: `Bearer ${fresh}` } })).statusCode, 200);

    const deleted = await runtime.app.inject({ method: "POST", url: "/api/data/delete", headers: await dashboard(runtime.app), payload: { confirmation: "DELETE LOCAL DATA" } });
    assert.equal(deleted.statusCode, 200, deleted.body);
    await runtime.app.close();
    runtime = await start();
    assert.equal((await runtime.app.inject({ method: "GET", url: "/api/extension/jobs", headers: { ...extension, authorization: `Bearer ${fresh}` } })).statusCode, 401, "deleting local data unpairs for good");
  } finally {
    await runtime.app.close();
    await rm(dir, { recursive: true, force: true });
  }
});
