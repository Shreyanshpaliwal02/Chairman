import test from "node:test";
import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { build } from "esbuild";
import { chromium } from "@playwright/test";
import { applicationStartUrl } from "../packages/domain/apply-start.js";
import type { AssistancePage } from "../packages/domain/extension-assist.js";
import type { PageNavigation } from "../apps/extension/assist-page.js";

const JOB = "https://fictional.wd5.myworkdayjobs.com/en-US/External_Career_Site/job/India---Hyderabad/Sr-Data-Engineer_JR358536";

test("applications start where the site links straight to its form", () => {
  const salesforce = "https://salesforce.wd12.myworkdayjobs.com/External_Career_Site/job/India---Hyderabad/Sr-Data-Engineer--Python---SQL-exp-mandatory-_JR358536";
  assert.equal(applicationStartUrl(salesforce), `${salesforce}/apply/autofillWithResume`, "Workday: Autofill with Resume, the first of its three start options");
  assert.equal(applicationStartUrl(`${salesforce}/`), `${salesforce}/apply/autofillWithResume`);
  assert.equal(applicationStartUrl(`${salesforce}?source=LinkedIn`), `${salesforce}/apply/autofillWithResume?source=LinkedIn`, "tracking parameters are kept");
  assert.equal(applicationStartUrl(`${salesforce}/apply/autofillWithResume`), `${salesforce}/apply/autofillWithResume`, "already started: unchanged");
  assert.equal(applicationStartUrl(`${salesforce}/apply/applyManually`), `${salesforce}/apply/applyManually`, "a start you chose is kept");
  assert.equal(applicationStartUrl("https://salesforce.wd12.myworkdayjobs.com/External_Career_Site"), "https://salesforce.wd12.myworkdayjobs.com/External_Career_Site", "job search pages are unchanged");
  assert.equal(applicationStartUrl("https://wd5.myworkdaysite.com/recruiting/fictional/External/job/Pune/Engineer_R1"), "https://wd5.myworkdaysite.com/recruiting/fictional/External/job/Pune/Engineer_R1/apply/autofillWithResume");
  const lever = "https://jobs.lever.co/fictional/0f8d2e8a-1b2c-4d5e-8f90-123456789abc";
  assert.equal(applicationStartUrl(lever), `${lever}/apply`);
  const ashby = "https://jobs.ashbyhq.com/fictional/0f8d2e8a-1b2c-4d5e-8f90-123456789abc";
  assert.equal(applicationStartUrl(ashby), `${ashby}/application`);
  assert.equal(applicationStartUrl("https://careers.fictional.test/jobs/42"), "https://careers.fictional.test/jobs/42");
  assert.equal(applicationStartUrl("not a url"), "not a url");
});

/** Workday's job page, optionally with its "Start Your Application" dialog open over it. */
function jobPage(dialog: boolean): string {
  return `<!doctype html><html><head><title>Sr Data Engineer</title>
<script type="application/ld+json">${JSON.stringify({ "@type": "JobPosting", title: "Sr Data Engineer", hiringOrganization: { name: "Fictional" }, description: "Build and operate Python and SQL data pipelines on AWS for analytics, with monitoring and data quality checks. Full-time role in Hyderabad, India." })}</script></head>
<body><header data-automation-id="header"><a href="/en-US/External_Career_Site">Careers</a><button type="button">Sign In</button></header>
<main><h2 data-automation-id="jobPostingHeader">Sr Data Engineer</h2>
<div data-automation-id="jobPostingDescription"><p>Build and operate Python and SQL data pipelines on AWS for analytics, with monitoring and data quality checks. Full-time role in Hyderabad, India.</p></div>
<a role="button" data-automation-id="adventureButton" href="${JOB}/apply" ${dialog ? 'aria-hidden="true"' : ""}>Apply</a></main>
${dialog ? `<div data-automation-id="wd-Popup" role="dialog" aria-modal="true" aria-labelledby="start"><h2 id="start">Start Your Application</h2>
<a role="button" data-automation-id="autofillWithResume" href="${JOB}/apply/autofillWithResume">Autofill with Resume</a>
<a role="button" data-automation-id="applyManually" href="${JOB}/apply/applyManually">Apply Manually</a>
<a role="button" data-automation-id="useMyLastApplication" href="${JOB}/apply/useMyLastApplication">Use My Last Application</a>
<button type="button" data-automation-id="closeButton" aria-label="Close">×</button></div>` : ""}
</body></html>`;
}

/** Workday's "Autofill with Resume" step and its "My Experience" step: hidden file inputs behind a drop zone, cleared after upload. */
function applyPage(step: "autofill" | "experience"): string {
  const zone = `<div data-automation-id="file-upload-drop-zone"><div><p>Drop file here</p><p>or</p></div>
<button type="button" data-automation-id="select-files">Select file</button>
<input type="file" data-automation-id="file-upload-input-ref" tabindex="-1" style="display:none" accept=".doc,.docx,.html,.pdf,.txt"></div>`;
  const body = step === "autofill"
    ? `<h2 data-automation-id="applyFlowPageTitle">Autofill with Resume</h2><div data-automation-id="uploadSection"><p>Upload your resume here to autofill key application fields.</p>${zone}
<p>Upload either DOC, DOCX, HTML, PDF, or TXT file types (5MB max)</p></div>`
    : `<h2 data-automation-id="applyFlowPageTitle">My Experience</h2>
<div role="group" aria-labelledby="work"><h3 id="work">Work Experience</h3><button type="button" data-automation-id="Add">Add</button></div>
<div role="group" aria-labelledby="attachments-section"><h3 id="attachments-section">Resume/CV</h3>
<div data-automation-id="formField-attachments"><label>Upload a file (5MB max)<abbr title="required">*</abbr></label>${zone}</div></div>`;
  return `<!doctype html><html><head><title>Apply</title></head><body>
<header data-automation-id="header"><a href="/en-US/External_Career_Site">Careers</a></header>
<div data-automation-id="applyFlowPage"><ol><li data-automation-id="progressBarActiveStep">current step ${step === "autofill" ? 1 : 3} of 7 ${step === "autofill" ? "Autofill with Resume" : "My Experience"}</li></ol>
<div id="content">${body}</div></div>
<div data-automation-id="pageFooter">${step === "experience" ? '<button type="button" data-automation-id="bottom-navigation-back-button">Back</button>' : ""}
<button type="button" data-automation-id="bottom-navigation-next-button">${step === "autofill" ? "Continue" : "Save and Continue"}</button></div>
<script>
document.querySelector('[data-automation-id="file-upload-input-ref"]').addEventListener('change', event => {
  const name = event.target.files[0] && event.target.files[0].name;
  if (!name) return;
  // Workday uploads the file, clears its input and lists the file instead.
  event.target.value = '';
  const zone = event.target.closest('[data-automation-id="file-upload-drop-zone"]');
  zone.insertAdjacentHTML('beforebegin', '<div data-automation-id="file-upload-successful"><div data-automation-id="file-upload-item-name">' + name + '</div><p>Successfully Uploaded!</p><button type="button" data-automation-id="delete-file">Delete</button></div>');
  window.uploaded = name;
});
</script></body></html>`;
}

test("real Chrome on Workday: the start dialog, the resume upload behind a drop zone, and an uploaded file that is kept", { timeout: 120_000 }, async () => {
  const browser = await chromium.launch({ headless: true, ...(existsSync(chromium.executablePath()) ? {} : { channel: "chrome" }) });
  const bundle = await build({ entryPoints: [resolve("apps/extension/assist-page.ts")], bundle: true, write: false, format: "iife", globalName: "ChairmanPage", platform: "browser", target: "chrome120" });
  const context = await browser.newContext(), tab = await context.newPage();
  let html = "";
  await context.route("**/*", route => new URL(route.request().url()).hostname === "fictional.wd5.myworkdayjobs.com" ? route.fulfill({ contentType: "text/html", body: html }) : route.abort());
  const open = async (content: string, url: string) => { html = content; await tab.goto(url); await tab.addScriptTag({ content: bundle.outputFiles[0].text }); };
  const navigation = () => tab.evaluate("ChairmanPage.inspectNavigation(document)") as Promise<PageNavigation>;
  const inspect = () => tab.evaluate("ChairmanPage.inspectAssistancePage(document, { quietMs: 40, maxWaitMs: 400 })") as Promise<AssistancePage>;
  try {
    // The job page: Apply is the way in; nothing else on the page counts as the application.
    await open(jobPage(false), JOB);
    const job = await navigation();
    assert.equal(job.apply?.text, "Apply");
    assert.equal(job.next, undefined);
    assert.equal(job.submit, undefined);
    assert.equal(job.signIn, false, "the header's Sign In button does not make a job page a sign-in page");
    const captured = await inspect();
    assert.equal(captured.job?.title, "Sr Data Engineer", "the job is captured, so its application gets this role's resume");
    assert.equal(captured.snapshot.fields.length, 0);

    // Apply opened "Start Your Application": Chairman picks Autofill with Resume, never the Apply button behind the dialog.
    await open(jobPage(true), JOB);
    const choice = await navigation();
    assert.equal(choice.apply?.text, "Autofill with Resume");
    const pressed = await tab.evaluate(`ChairmanPage.advance(document, "apply", "Autofill with Resume")`) as { clicked: string; href?: string };
    assert.deepEqual(pressed, { clicked: "Autofill with Resume", href: `${JOB}/apply/autofillWithResume` }, "the option's link opens in this tab");
    await assert.rejects(tab.evaluate(`ChairmanPage.advance(document, "apply", "Apply")`), /buttons changed/, "the background Apply is not pressable while the dialog is open");

    // Autofill with Resume: the hidden upload is the resume field and Continue moves on.
    await open(applyPage("autofill"), `${JOB}/apply/autofillWithResume`);
    const autofill = await inspect();
    const upload = autofill.snapshot.fields.filter(field => field.type === "file");
    assert.equal(upload.length, 1, JSON.stringify(autofill.snapshot));
    assert.match(upload[0]!.label, /resume/i, "planned as the resume");
    assert.deepEqual(upload[0]!.accept, [".doc", ".docx", ".html", ".pdf", ".txt"]);
    assert.equal(autofill.occupied.includes(upload[0]!.key), false);
    assert.equal((await navigation()).next?.text, "Continue");

    // My Experience: "Upload a file (5MB max)" under the "Resume/CV" heading is the resume, and required.
    await open(applyPage("experience"), `${JOB}/apply/autofillWithResume`);
    const experience = await inspect();
    const resume = experience.snapshot.fields.filter(field => field.type === "file");
    assert.equal(resume.length, 1, JSON.stringify(experience.snapshot));
    assert.equal(resume[0]!.label, "Resume/CV: Upload a file (5MB max)");
    assert.equal(resume[0]!.required, true);
    const steps = await navigation();
    assert.equal(steps.next?.text, "Save and Continue");
    assert.match(steps.step ?? "", /My Experience/);
    // Uploaded: Workday clears its input and lists the file; Chairman counts it as attached and keeps it.
    await tab.setInputFiles('[data-automation-id="file-upload-input-ref"]', { name: "Data_Engineer_Resume.pdf", mimeType: "application/pdf", buffer: Buffer.from("%PDF-1.4 fixture") });
    assert.equal(await tab.evaluate("window.uploaded"), "Data_Engineer_Resume.pdf");
    const after = await inspect();
    assert.ok(after.occupied.includes(resume[0]!.key), "the listed file counts as the attached resume");

    // Never Submit: Workday's step button is "next" only while its words say so.
    for (const [label, kind] of [["Save and Continue", "next"], ["Next", "next"], ["Submit", "submit"], ["Apply", "submit"], ["Done", "submit"], ["Submit Application", "submit"]] as const) {
      await open(`<!doctype html><html><body><div data-automation-id="applyFlowPage"><h2>Review</h2><p>Name: Jordan Fixture</p></div>
<div data-automation-id="pageFooter"><button type="button" data-automation-id="bottom-navigation-back-button">Back</button><button type="button" data-automation-id="bottom-navigation-next-button">${label}</button></div></body></html>`, `${JOB}/apply/autofillWithResume`);
      const buttons = await navigation();
      assert.equal(kind === "next" ? buttons.next?.text : buttons.submit?.text, label, `"${label}" is ${kind}`);
      assert.equal(buttons.apply, undefined, `"${label}" is never a way into the application`);
      if (kind === "submit") await assert.rejects(tab.evaluate(`ChairmanPage.advance(document, "next", ${JSON.stringify(label)})`), /yours to press|buttons changed/);
    }
    // An Apply button that sends a form with questions is that form's submission, even when Chairman sees no questions it can fill.
    await open(`<!doctype html><html><body><main><h1>Data Engineer</h1><form action="/submit"><label>Email <input name="email" type="email" disabled></label><button type="submit">Apply</button></form></main></body></html>`, JOB);
    const lone = await navigation();
    assert.equal(lone.apply?.text, "Apply", "no question Chairman can fill, so the button reads as a way in");
    await assert.rejects(tab.evaluate(`ChairmanPage.advance(document, "apply", "Apply")`), /sends a form/, "but it sends a form with questions, so it is yours to press");
  } finally {
    await context.close();
    await browser.close();
  }
});
