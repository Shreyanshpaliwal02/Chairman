import test from "node:test";
import assert from "node:assert/strict";
import { defaultDataDirectory } from "../packages/platform/paths.js";

test("macOS preserves the existing private application directory", () => {
  assert.equal(defaultDataDirectory({ platform: "darwin", home: "/Users/person", env: { XDG_DATA_HOME: "/other" } }),
    "/Users/person/Library/Application Support/Job Application Assistant");
});

test("Windows honors LOCALAPPDATA and uses Windows separators on every host", () => {
  assert.equal(defaultDataDirectory({ platform: "win32", home: "C:\\Users\\Person", env: { LOCALAPPDATA: "D:\\Local data" } }),
    "D:\\Local data\\Job Application Assistant");
  for (const LOCALAPPDATA of [undefined, "", "relative"]) {
    assert.equal(defaultDataDirectory({ platform: "win32", home: "C:\\Users\\Person", env: { LOCALAPPDATA } }),
      "C:\\Users\\Person\\AppData\\Local\\Job Application Assistant");
  }
});

test("Linux honors absolute XDG data paths and rejects relative XDG values", () => {
  assert.equal(defaultDataDirectory({ platform: "linux", home: "/home/person", env: { XDG_DATA_HOME: "/data" } }),
    "/data/job-application-assistant");
  for (const XDG_DATA_HOME of [undefined, "", "relative"]) {
    assert.equal(defaultDataDirectory({ platform: "linux", home: "/home/person", env: { XDG_DATA_HOME } }),
      "/home/person/.local/share/job-application-assistant");
  }
});
