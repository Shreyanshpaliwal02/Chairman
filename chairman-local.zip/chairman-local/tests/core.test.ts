import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm, appendFile, chmod } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { matchJob, jobHash, prohibitsAi } from "../packages/domain/matching.js";
import { Store } from "../apps/local/store.js";
import { Engine, snapshotHash, today } from "../apps/local/engine.js";
import { automationPolicy } from "../apps/local/policies.js";
import type { FormSnapshot } from "../packages/domain/types.js";
import { profileFixture, jobFixture } from "./fixtures.js";

test("eligibility distinguishes exclusions, sponsorship, unknown remote, short gigs and pay target", () => {
  const profile = profileFixture();
  assert.equal(matchJob(profile, jobFixture()).eligible, true);
  assert.equal(matchJob(profile, jobFixture({ company: "HPE Aruba Networking" })).eligible, false);
  assert.equal(matchJob(profile, jobFixture({ company: "Hewlett Packard Enterprise" })).eligible, false);
  assert.equal(matchJob(profile, jobFixture({ location: "United States", countries: ["US"], sponsorship: "no" })).eligible, false);
  assert.match(matchJob(profile, jobFixture({ location: "Remote", countries: [], remote: true })).warnings.join(" "), /India-eligible/);
  assert.equal(matchJob(profile, jobFixture({ employmentType: "short-term contract" })).eligible, false);
  const lower = matchJob(profile, jobFixture({ salary: { max: 3000000, currency: "INR", period: "year", kind: "base" } }));
  assert.equal(lower.eligible, true); assert.match(lower.warnings.join(" "), /below/);
  assert.match(matchJob(profile, jobFixture({ salary: null })).warnings.join(" "), /undisclosed/);
  assert.match(matchJob(profile, jobFixture({ description: "Fluent in Japanese required for customer work." })).warnings.join(" "), /another language/);
});
test("matching evidence does not claim unsupported JD technologies or use a fetch timestamp as a material edit", () => {
  const a = jobFixture(), b = { ...a, description: a.description + " Terraform and Databricks are useful." };
  const result = matchJob(profileFixture(), b);
  assert.ok(result.missingSkills.includes("Terraform")); assert.ok(!result.matchedSkills.includes("Terraform"));
  assert.equal(jobHash(a), jobHash({ ...a, fetchedAt: "2030-01-01T00:00:00Z" }));
  assert.notEqual(jobHash(a), jobHash(b));
  assert.ok(prohibitsAi("During this process I agree to use only my own words."));
});
test("policies never enable restricted domains or ambiguous external application hosts", () => {
  for (const host of ["www.linkedin.com", "wellfound.com", "www.naukri.com", "sideshift.app"]) {
    assert.equal(automationPolicy(jobFixture({ applyUrl: `https://${host}/jobs/1` }), [], true, "http://127.0.0.1:4318").allowed, false);
  }
  assert.equal(automationPolicy(jobFixture(), [], false, "http://127.0.0.1:4318").allowed, false);
  assert.equal(automationPolicy(jobFixture(), [], true, "http://127.0.0.1:4318").allowed, true);
  assert.equal(automationPolicy(jobFixture({ aiPolicy: "prohibited" }), [], true, "http://127.0.0.1:4318").allowed, false);
});
test("cross-source ATS identities deduplicate without merging generic careers pages by title", () => {
  const store = new Store(":memory:");
  try {
    const apply = "https://jobs.ashbyhq.com/example/12345678-abcd-abcd-abcd-123456789abc/application";
    store.saveJob(jobFixture({ id: "vendor", applyUrl: apply, canonicalUrl: apply }));
    const duplicate = store.saveJob(jobFixture({ id: "himalayas:copy", sourceId: "himalayas", applyUrl: apply.replace("/application", "") + "?utm_source=himalayas", canonicalUrl: "https://himalayas.app/companies/example/jobs/data-engineer" }));
    assert.equal(duplicate.id, "vendor");
    assert.equal(store.jobs().length, 1);
    store.saveJob(jobFixture({ id: "distinct", applyUrl: "https://example.test/careers", canonicalUrl: "https://example.test/jobs/second-role" }));
    store.saveJob(jobFixture({ id: "distinct2", applyUrl: "https://example.test/careers", canonicalUrl: "https://example.test/jobs/third-role" }));
    assert.equal(store.jobs().length, 3);
  } finally { store.close(); }
});

function form(): FormSnapshot {
  const snapshot: FormSnapshot = { url: jobFixture().applyUrl, fields: [
    { key: "full_name", label: "Full name", type: "text", required: true, options: [] },
    { key: "email", label: "Email", type: "email", required: true, options: [] },
    { key: "resume", label: "Resume", type: "file", required: true, options: [] }
  ], fingerprint: "", hasCaptcha: false, hasLegal: false, unsupported: [] };
  snapshot.fingerprint = snapshotHash(snapshot); return snapshot;
}
async function setup(dailyLimit: number | null = null) {
  const dir = await mkdtemp(join(tmpdir(), "jaa-core-"));
  const store = new Store(join(dir, "test.sqlite"));
  const profile = profileFixture(); profile.preferences.dailyLimit = dailyLimit;
  store.set("profile", profile); store.saveJob(jobFixture());
  const engine = new Engine(store, dir, [], true, "http://127.0.0.1:4318");
  const prepared = await engine.prepare("fixture-job", "deterministic");
  engine.preflight(prepared.id, form());
  return { dir, store, engine, id: prepared.id, clean: async () => { store.close(); await rm(dir, { recursive: true, force: true }); } };
}
test("approval requires exact facts, form, documents; reports require explicit evidence; no duplicate retry", async () => {
  const r = await setup();
  try {
    await r.engine.approve([r.id], true);
    const claim = await r.engine.claim(r.id);
    assert.equal(r.store.attempts(today()), 1);
    assert.throws(() => r.engine.report(r.id, claim.runToken, "submitted_confirmed"), /evidence/);
    r.engine.report(r.id, claim.runToken, "submission_unknown", undefined, "Navigation lost.");
    await assert.rejects(r.engine.claim(r.id), /not approved/);
    const packet = r.engine.report(r.id, claim.runToken, "submitted_confirmed", "Fixture receipt abc123");
    assert.equal(packet.status, "submitted_confirmed");
    await assert.rejects(r.engine.prepare("fixture-job", "deterministic"), /already exists/);
  } finally { await r.clean(); }
});
test("profile or document mutation invalidates prior approval", async () => {
  const r = await setup();
  try {
    await r.engine.approve([r.id], true);
    r.store.set("profile", { ...r.store.profile(), version: 2 });
    await assert.rejects(r.engine.claim(r.id), /Profile changed/);
    r.store.set("profile", profileFixture());
    const artifact = r.engine.get(r.id).artifacts[0]!;
    await chmod(join(r.engine.directory(r.id), artifact.filename), 0o600);
    await appendFile(join(r.engine.directory(r.id), artifact.filename), "mutated");
    await assert.rejects(r.engine.claim(r.id), /bytes changed/);
  } finally { await r.clean(); }
});
test("more than 500 daily attempts are allowed without an app cap; unknown runs never replay", async () => {
  const r = await setup();
  try {
    await r.engine.approve([r.id], true);
    for (let n = 0; n < 501; n++) r.store.db.prepare("INSERT INTO runs(packet_id,job_id,source_id,token,day,status) VALUES (?,?,?,?,?,?)").run(`p${n}`, `j${n}`, "fixture", `t${n}`, today(), "failed");
    const claim = await r.engine.claim(r.id);
    assert.equal(claim.packet.status, "executing");
    assert.equal(r.store.attempts(today()), 502);
    assert.equal(r.store.attemptsSession(), 1);
  } finally { await r.clean(); }
  const second = await setup();
  try {
    await second.engine.approve([second.id], true);
    await second.engine.claim(second.id);
    second.store.recover();
    assert.equal(second.engine.get(second.id).status, "submission_unknown");
    assert.equal(second.store.db.prepare("SELECT status FROM runs WHERE packet_id=?").get(second.id)?.status, "submission_unknown");
    await assert.rejects(second.engine.claim(second.id), /not approved/);
  } finally { await second.clean(); }
});
test("optional user caps and independent source caps are still enforced", async () => {
  const capped = await setup(2);
  try {
    await capped.engine.approve([capped.id], true);
    for (let n = 0; n < 2; n++) capped.store.db.prepare("INSERT INTO runs(packet_id,job_id,source_id,token,day,status) VALUES (?,?,?,?,?,?)").run(`p${n}`, `j${n}`, "fixture", `t${n}`, today(), "failed");
    await assert.rejects(capped.engine.claim(capped.id), /optional daily/);
  } finally { await capped.clean(); }
  const source = await setup();
  try {
    source.engine.policy = () => ({ allowed: true, canSubmit: true, reason: "Controlled source limit", limit: 1 });
    await source.engine.approve([source.id], true);
    source.store.db.prepare("INSERT INTO runs(packet_id,job_id,source_id,token,day,status) VALUES (?,?,?,?,?,?)").run("p", "j", "fixture", "t", today(), "failed");
    await assert.rejects(source.engine.claim(source.id), /Source submission ceiling/);
  } finally { await source.clean(); }
});
test("stop withdraws queued approvals and legal/CAPTCHA forms never become automatic", async () => {
  const r = await setup();
  try {
    await r.engine.approve([r.id], true); r.engine.stop(true);
    assert.equal(r.engine.get(r.id).status, "withdrawn_from_queue");
    await assert.rejects(r.engine.claim(r.id), /stopped/);
    r.engine.stop(false);
    const snapshot = { ...form(), hasLegal: true }; snapshot.fingerprint = snapshotHash(snapshot);
    r.engine.preflight(r.id, snapshot);
    await assert.rejects(r.engine.approve([r.id], true), /manual steps/);
  } finally { await r.clean(); }
});
