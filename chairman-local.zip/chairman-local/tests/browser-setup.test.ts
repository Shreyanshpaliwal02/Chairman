import test from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import type { AddressInfo } from "node:net";
import { mkdtemp, rm } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { ApplicationBrowser } from "../packages/automation/browser.js";

test("manual setup can use a separate identity-provider popup without opening the automation tab's scope", { timeout: 30000 }, async () => {
  const directory = await mkdtemp(join(tmpdir(), "jaa-login-"));
  let callbackSeen = false;
  const identity = createServer((request, response) => { callbackSeen = request.url === "/callback"; response.end("Synthetic sign-in complete"); });
  await new Promise<void>(resolve => identity.listen(0, "127.0.0.1", resolve));
  const identityOrigin = `http://127.0.0.1:${(identity.address() as AddressInfo).port}`;
  const application = createServer((_request, response) => {
    response.setHeader("Content-Type", "text/html");
    response.end(`<h1>Manual sign-in fixture</h1><script>setTimeout(()=>window.open('${identityOrigin}/callback'),100)</script>`);
  });
  await new Promise<void>(resolve => application.listen(0, "127.0.0.1", resolve));
  const origin = `http://127.0.0.1:${(application.address() as AddressInfo).port}`;
  const driver = new ApplicationBrowser({ userDataDir: directory, headless: true, testOrigins: [origin, identityOrigin] });
  try {
    await driver.openForSetup(origin);
    for (let attempt = 0; attempt < 50 && !callbackSeen; attempt++) await new Promise(resolve => setTimeout(resolve, 100));
    assert.equal(callbackSeen, true);
    assert.equal(driver.isRunning(), true);
  } finally {
    await driver.close();
    application.closeAllConnections(); identity.closeAllConnections();
    await Promise.all([new Promise<void>(resolve => application.close(() => resolve())), new Promise<void>(resolve => identity.close(() => resolve()))]);
    await rm(directory, { recursive: true, force: true });
  }
});
