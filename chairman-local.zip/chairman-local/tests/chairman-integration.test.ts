import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "../apps/local/server.js";
import { safeCareerUrl } from "../packages/adapters/public-page.js";
import { canUsePortal } from "../packages/automation/portal-browser.js";

test("Indeed manual-search policy applies to both generic discovery and the dedicated runner", () => {
  for (const url of ["https://www.indeed.com/viewjob?jk=123", "https://in.indeed.com/jobs", "https://indeed.co.in/jobs", "https://indeed.com.au/jobs", "https://indeed.de/jobs"]) {
    assert.throws(() => safeCareerUrl(url), /public HTTPS employer careers page/);
    assert.equal(canUsePortal(url), false);
  }
  assert.equal(canUsePortal("https://careers.example.com/jobs/engineer"), true);
});

test("Chairman routes enforce exact extension pairing, preserve source permissions and clear/export new local state", async () => {
  const dir = await mkdtemp(join(tmpdir(), "chairman-integration-"));
  const runtime = await createApp({ dataDir: dir, port: 4393 });
  try {
    const host = { host: "127.0.0.1:4393" }, origin = "http://127.0.0.1:4393";
    const session = await runtime.app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = session.cookies[0]!, headers = { ...host, cookie: `${cookie.name}=${cookie.value}`, origin };
    for (const url of ["/api/tracking", "/api/assistance", "/api/search-portals", "/api/discovery/preferences"]) {
      assert.equal((await runtime.app.inject({ method: "GET", url, headers: host })).statusCode, 401);
      const allowed = await runtime.app.inject({ method: "GET", url, headers });
      assert.equal(allowed.statusCode, 200, allowed.body);
    }
    const pair = await runtime.app.inject({ method: "POST", url: "/api/extension/pair", headers, payload: {} });
    const token = pair.json<{ token: string }>().token;
    const extension = { ...host, origin: `chrome-extension://${"a".repeat(32)}`, authorization: `Bearer ${token}` };
    const assist = "/api/extension/assist/import";
    assert.equal((await runtime.app.inject({ method: "POST", url: assist, headers: extension, payload: {} })).statusCode, 403);
    assert.equal((await runtime.app.inject({ method: "POST", url: "/api/extension/connect", headers: extension, payload: {} })).statusCode, 200);
    assert.equal((await runtime.app.inject({ method: "POST", url: assist, headers: { ...host, authorization: `Bearer ${token}` }, payload: {} })).statusCode, 403);
    assert.equal((await runtime.app.inject({ method: "POST", url: assist, headers: { ...extension, origin }, payload: {} })).statusCode, 403);
    assert.equal((await runtime.app.inject({ method: "POST", url: assist, headers: { ...extension, origin: `chrome-extension://${"b".repeat(32)}` }, payload: {} })).statusCode, 403);
    assert.equal((await runtime.app.inject({ method: "POST", url: assist, headers: extension, payload: {} })).statusCode, 400, "Authenticated malformed input reaches validation, not authorization failure");
    assert.equal((await runtime.app.inject({ method: "GET", url: "/api/tracking", headers: extension })).statusCode, 403);
    const saved = await runtime.app.inject({ method: "POST", url: "/api/search-portals", headers, payload: {
      action: "save", label: "Custom portal", urlTemplate: "https://example.com/jobs?q={role}&location={location}",
    } });
    assert.equal(saved.statusCode, 200, saved.body);
    const preference = await runtime.app.inject({ method: "POST", url: "/api/discovery/preferences", headers, payload: { sourceId: "himalayas", enabled: false } });
    assert.equal(preference.statusCode, 200, preference.body);
    assert.equal(runtime.autopilot.view().enabled, false);
    assert.equal((await runtime.app.inject({ method: "POST", url: "/api/discovery/preferences", headers, payload: { sourceId: "linkedin", enabled: true } })).statusCode, 400);
    const exported = await runtime.app.inject({ method: "GET", url: "/api/export", headers });
    assert.match(exported.body, /Custom portal/);
    assert.ok(!exported.body.includes(token));
    const removed = await runtime.app.inject({ method: "POST", url: "/api/data/delete", headers, payload: { confirmation: "DELETE LOCAL DATA" } });
    assert.equal(removed.statusCode, 200, removed.body);
    assert.equal(runtime.store.db.prepare("SELECT count(*) AS n FROM assistance_records").get()!.n, 0);
    assert.ok(!(await runtime.app.inject({ method: "GET", url: "/api/search-portals", headers })).body.includes("Custom portal"));
    assert.equal((await runtime.app.inject({ method: "POST", url: assist, headers: extension, payload: {} })).statusCode, 403);
  } finally { await runtime.app.close(); await rm(dir, { recursive: true, force: true }); }
});
