import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import test from "node:test";
import type { D1Database } from "@cloudflare/workers-types";
import { handleRequest, runScanTick, type Env } from "../apps/scanner/src/index";
import { DiscoveryError } from "../packages/adapters/discovery";
import type { Job } from "../packages/domain/types";

const NOW = Date.parse("2026-09-14T10:00:00Z");
const MINUTE = 60_000;
const DAY = 86_400_000;
const TOKEN = "scanner-fixture-token".repeat(3);

class D1Fixture {
  sqlite = new DatabaseSync(":memory:");
  failBatch = false;
  failPrepare = false;
  constructor() {
    this.sqlite.exec(readFileSync(new URL("../apps/scanner/migrations/0001_public_jobs.sql", import.meta.url), "utf8"));
  }
  prepare(query: string) {
    if (this.failPrepare) throw new Error("account-id secret internal SQL detail");
    const database = this.sqlite;
    const create = (bindings: (string | number | null)[]) => ({
      bind: (...values: (string | number | null)[]) => create(values),
      async first() { return database.prepare(query).get(...bindings) ?? null; },
      async all() { return { results: database.prepare(query).all(...bindings), success: true, meta: {} }; },
      async run() {
        const result = database.prepare(query).run(...bindings);
        return { success: true, meta: { changes: Number(result.changes) } };
      }
    });
    return create([]);
  }
  async batch(statements: { run(): Promise<unknown> }[]) {
    this.sqlite.exec("BEGIN");
    try {
      const output = [];
      for (const statement of statements) {
        output.push(await statement.run());
        if (this.failBatch) throw new Error("simulated write failure after first statement");
      }
      this.sqlite.exec("COMMIT");
      return output;
    } catch (error) {
      this.sqlite.exec("ROLLBACK");
      throw error;
    }
  }
  env(sources = "himalayas"): Env {
    return { DB: this as unknown as D1Database, SYNC_TOKEN: TOKEN, SCAN_ENABLED: "true", SCAN_SOURCES: sources };
  }
  state(id = "himalayas") { return this.sqlite.prepare("SELECT * FROM source_state WHERE source_id = ?").get(id)!; }
  jobs() { return this.sqlite.prepare("SELECT * FROM public_jobs ORDER BY revision").all(); }
}

function fixtureJob(sourceId = "himalayas", sourceJobId = "fixture-1"): Job {
  return {
    id: `${sourceId}:${sourceJobId}`, sourceId, sourceJobId, title: "Engineer", company: "Public Fixture",
    location: "Remote — country eligibility unspecified", remote: true, countries: [],
    employmentType: "Full-time", description: "Public listing only.",
    applyUrl: "https://careers.example.com/job/1", canonicalUrl: "https://himalayas.app/companies/fixture/jobs/1",
    fetchedAt: new Date(NOW).toISOString(), salary: null, sponsorship: "unknown", language: null, aiPolicy: "unknown", status: "open"
  };
}

function request(path: string, token = TOKEN) {
  return new Request(`https://job-application-scanner.fixture.workers.dev${path}`, { headers: { Authorization: `Bearer ${token}` } });
}

test("D1 page writes and cursor advance atomically and repeated jobs are idempotent", async (t) => {
  const database = new D1Fixture();
  t.after(() => database.sqlite.close());
  const env = database.env();
  const scan = async () => ({ jobs: [fixtureJob()], nextCursor: "page-2" });
  await runScanTick(env, { now: NOW, scan });
  assert.equal(database.jobs().length, 1);
  assert.equal(database.state().cursor, "page-2");
  assert.equal(database.state().last_success_at, NOW);
  assert.equal(database.state().lease_token, null);
  await runScanTick(env, { now: NOW + 15 * MINUTE, scan });
  assert.equal(database.jobs().length, 1);
  assert.equal(database.jobs()[0]!.revision, 1);
});

test("a mid-batch failure rolls back jobs and preserves the previous source cursor", async (t) => {
  const database = new D1Fixture();
  t.after(() => database.sqlite.close());
  database.sqlite.prepare("UPDATE source_state SET cursor = ?, cycle_started_at = ? WHERE source_id = ?").run("previous", NOW, "himalayas");
  database.failBatch = true;
  await runScanTick(database.env(), { now: NOW, scan: async (_source, cursor) => {
    assert.equal(cursor, "previous");
    return { jobs: [fixtureJob()], nextCursor: "not-committed" };
  } });
  assert.equal(database.jobs().length, 0);
  assert.equal(database.state().cursor, "previous");
  assert.equal(database.state().last_error_code, "PERSISTENCE_OR_SCAN_FAILED");
  assert.equal(database.state().failures, 1);
  assert.equal(database.sqlite.prepare("SELECT revision FROM sync_meta").get()!.revision, 0);
});

test("rate limiting observes Retry-After and makes no immediate retry", async (t) => {
  const database = new D1Fixture();
  t.after(() => database.sqlite.close());
  let calls = 0;
  const scan = async () => { calls++; throw new DiscoveryError("RATE_LIMITED", "fixture", 3 * 60 * MINUTE, 429); };
  await runScanTick(database.env(), { now: NOW, scan });
  await runScanTick(database.env(), { now: NOW + 15 * MINUTE, scan });
  assert.equal(calls, 1);
  assert.equal(database.state().next_scan_at, NOW + 3 * 60 * MINUTE);
  assert.equal(database.state().last_error_code, "RATE_LIMITED");
  assert.equal(database.state().last_success_at, null);
});

test("scheduler fairly visits enabled sources without fetching manual/unknown IDs", async (t) => {
  const database = new D1Fixture();
  t.after(() => database.sqlite.close());
  const env = database.env("himalayas,supabase,canonical,automattic,safetywing,linkedin,evil,himalayas");
  const calls: string[] = [];
  const scan = async (source: string, _cursor: string | undefined, _fetch: typeof fetch | undefined, options: unknown) => {
    calls.push(source);
    assert.deepEqual(options, { pageSize: 1, timeoutMs: 8000, maxResponseBytes: 65536 });
    return { jobs: [fixtureJob(source)], nextCursor: "more" };
  };
  for (let index = 0; index < 5; index++) await runScanTick(env, { now: NOW + index * 15 * MINUTE, scan });
  assert.deepEqual(new Set(calls), new Set(["himalayas", "supabase", "canonical", "automattic", "safetywing"]));
});

test("an active lease prevents concurrent duplicate fetches and an interrupted lease recovers", async (t) => {
  const database = new D1Fixture();
  t.after(() => database.sqlite.close());
  database.sqlite.prepare("UPDATE source_state SET lease_token = ?, lease_until = ?, last_started_at = ? WHERE source_id = ?")
    .run("old-lease", NOW + 2 * MINUTE, NOW, "himalayas");
  let calls = 0;
  const scan = async () => { calls++; return { jobs: [], nextCursor: undefined }; };
  await runScanTick(database.env(), { now: NOW + MINUTE, scan });
  assert.equal(calls, 0);
  await runScanTick(database.env(), { now: NOW + 3 * MINUTE, scan });
  assert.equal(calls, 1);
  assert.equal(database.state().lease_token, null);
});

test("source size failures pause for a day and do not become an empty successful scan", async (t) => {
  const database = new D1Fixture();
  t.after(() => database.sqlite.close());
  await runScanTick(database.env(), { now: NOW, scan: async () => { throw new DiscoveryError("TOO_LARGE", "fixture"); } });
  assert.equal(database.state().next_scan_at, NOW + DAY);
  assert.equal(database.state().last_success_at, null);
  assert.equal(database.state().last_error_code, "TOO_LARGE");
});

test("daily cycles restart at the head and a 96-page cap is visibly partial", async (t) => {
  const database = new D1Fixture();
  t.after(() => database.sqlite.close());
  database.sqlite.prepare("UPDATE source_state SET cursor = ?, cycle_started_at = ?, cycle_pages = 95 WHERE source_id = ?").run("tail", NOW, "himalayas");
  await runScanTick(database.env(), { now: NOW + MINUTE, scan: async (_id, cursor) => {
    assert.equal(cursor, "tail");
    return { jobs: [fixtureJob()], nextCursor: "still-more" };
  } });
  assert.equal(database.state().cycle_limited, 1);
  assert.equal(database.state().cursor, null);
  assert.equal(database.state().next_scan_at, NOW + DAY);
  await runScanTick(database.env(), { now: NOW + DAY, scan: async (_id, cursor) => {
    assert.equal(cursor, undefined);
    return { jobs: [], nextCursor: undefined };
  } });
  assert.equal(database.state().cycle_pages, 1);
});

test("GET /jobs requires authentication and validates cursors and methods", async (t) => {
  const database = new D1Fixture();
  t.after(() => database.sqlite.close());
  const env = database.env();
  assert.equal((await handleRequest(request("/jobs", "wrong"), env)).status, 401);
  assert.equal((await handleRequest(request("/jobs"), { ...env, SYNC_TOKEN: undefined })).status, 503);
  for (const path of ["/jobs?cursor=-1", "/jobs?cursor=1.5", "/jobs?cursor=1&cursor=2", "/jobs?cursor=9999", "/jobs?anything=1"]) {
    assert.equal((await handleRequest(request(path), env)).status, 400);
  }
  assert.equal((await handleRequest(new Request("https://fixture.example/jobs", { method: "POST", body: '{"resume":"private"}' }), env)).status, 405);
  assert.equal((await handleRequest(request("/other"), env)).status, 404);
});

test("incremental sync includes updates, bounds pages and preserves an empty checkpoint", async (t) => {
  const database = new D1Fixture();
  t.after(() => database.sqlite.close());
  const env = database.env();
  for (let index = 0; index < 6; index++) {
    await runScanTick(env, { now: NOW + index * 15 * MINUTE, scan: async () => ({ jobs: [fixtureJob("himalayas", `job-${index}`)], nextCursor: "more" }) });
  }
  const first = await (await handleRequest(request("/jobs"), env)).json() as { jobs: Job[]; nextCursor: string };
  assert.equal(first.jobs.length, 5);
  assert.equal(first.nextCursor, "5");
  const second = await (await handleRequest(request(`/jobs?cursor=${first.nextCursor}`), env)).json() as { jobs: Job[]; nextCursor: string };
  assert.equal(second.jobs.length, 1);
  assert.equal(second.nextCursor, "6");
  const empty = await (await handleRequest(request("/jobs?cursor=6"), env)).json();
  assert.deepEqual(empty, { jobs: [], nextCursor: "6" });
  await runScanTick(env, { now: NOW + 6 * 15 * MINUTE, scan: async () => ({ jobs: [{ ...fixtureJob("himalayas", "job-0"), title: "Updated Engineer" }], nextCursor: "more" }) });
  const update = await (await handleRequest(request("/jobs?cursor=6"), env)).json() as { jobs: Job[]; nextCursor: string };
  assert.equal(update.jobs[0]!.title, "Updated Engineer");
  assert.equal(update.nextCursor, "7");
  assert.equal(database.jobs().length, 6);
});

test("retention is indexed, bounded and invalidates older sync checkpoints", async (t) => {
  const database = new D1Fixture();
  t.after(() => database.sqlite.close());
  const env = database.env();
  await runScanTick(env, { now: NOW - 31 * DAY, scan: async () => ({ jobs: [fixtureJob("himalayas", "old")] }) });
  await runScanTick(env, { now: NOW, scan: async () => ({ jobs: [fixtureJob("himalayas", "fresh")] }) });
  assert.equal(database.jobs().length, 1);
  assert.equal((await handleRequest(request("/jobs?cursor=0"), env)).status, 409);
  assert.equal((await handleRequest(request("/jobs"), env)).status, 200);
  const plan = database.sqlite.prepare("EXPLAIN QUERY PLAN SELECT revision FROM public_jobs WHERE revision > ? ORDER BY revision LIMIT 5").all(0);
  assert.match(JSON.stringify(plan), /INDEX/);
});

test("health exposes deferral and operational codes, never secrets/cursors/raw errors", async (t) => {
  const database = new D1Fixture();
  t.after(() => database.sqlite.close());
  database.sqlite.prepare("UPDATE source_state SET cursor = ?, lease_token = ?, lease_until = 1 WHERE source_id = ?").run("private-upstream-cursor", "lease-secret", "himalayas");
  const health = await handleRequest(new Request("https://fixture.example/health"), database.env());
  const output = await health.text();
  assert.equal(health.status, 200);
  assert.doesNotMatch(output, /private-upstream-cursor|lease-secret|scanner-fixture-token/);
  assert.match(output, /INTERRUPTED_OR_CPU_LIMIT/);
  assert.match(output, /Cloud deferred/);
  database.failPrepare = true;
  const unavailable = await handleRequest(request("/jobs"), database.env());
  assert.equal(unavailable.status, 503);
  assert.doesNotMatch(await unavailable.text(), /account-id|SQL detail/);
});

test("disabled scanner and unavailable D1 cause no public network requests", async (t) => {
  const database = new D1Fixture();
  t.after(() => database.sqlite.close());
  let calls = 0;
  const scan = async () => { calls++; return { jobs: [] }; };
  await runScanTick({ ...database.env(), SCAN_ENABLED: "false" }, { now: NOW, scan });
  database.failPrepare = true;
  await runScanTick(database.env(), { now: NOW, scan });
  assert.equal(calls, 0);
});
