import test from "node:test";
import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { existsSync } from "node:fs";
import { mkdir, readFile, rm } from "node:fs/promises";
import { join, resolve } from "node:path";
import { createContext, runInContext } from "node:vm";
import Fastify from "fastify";
import { build } from "esbuild";
import { chromium, type Page } from "@playwright/test";
import { Store } from "../apps/local/store.js";
import { Engine, packetHash } from "../apps/local/engine.js";
import { ResumeLibrary } from "../apps/local/resume-library.js";
import { ExtensionAssistService, registerExtensionAssist } from "../apps/local/extension-assist.js";
import type { FieldAi } from "../apps/local/assist-ai.js";
import { assistanceDestination } from "../apps/extension/assist-safety.js";
import { assistancePagePayload, assistanceSnapshotPayload, type AssistanceFillResult, type AssistanceGrant, type AssistancePage, type AssistPlan } from "../packages/domain/extension-assist.js";
import { comparableValue } from "../packages/domain/assist-match.js";
import { createDocuments, extractPdfText } from "../packages/documents/index.js";
import { emptyProfile, type FormField, type FormSnapshot, type Profile } from "../packages/domain/types.js";
import { jobFixture } from "./fixtures.js";

const sha = (value: string | Buffer) => createHash("sha256").update(value).digest("hex");
const url = "http://127.0.0.1:47821/fixture/application";
const KEYS = { name: "f00000000001", email: "f00000000002", resume: "f00000000003", phone: "f00000000004", hear: "f00000000005", notice: "f00000000006",
  why: "f00000000007", education: "f00000000008", kubernetes: "f00000000009", nationality: "f0000000000a", city: "f0000000000b" };
const DESCRIPTION = "Build reliable data pipelines using Python, SQL and AWS. Responsibilities include monitoring and optimization. Full-time engineering role in India.";
function sourceProfile(): Profile {
  return { ...emptyProfile(), name: "Taylor Fixture", email: "taylor@fictional.invalid", phone: "+1 202-555-0118", location: "India",
    confirmed: true, skills: ["Python", "SQL", "AWS"], answers: { Country: "India" }, links: { Portfolio: "https://taylor.fictional.invalid" },
    facts: [
      { id: "exp-one", category: "experience", text: "Built Python and SQL data pipelines on AWS with reliable monitoring.", employer: "Fictional Labs", role: "Data Engineer", dates: "2023 - Present", confirmed: true },
      { id: "exp-two", category: "experience", text: "Reduced Python data pipeline runtime by 20% through measured SQL tuning.", employer: "Fictional Labs", role: "Data Engineer", dates: "2023 - Present", confirmed: true },
      { id: "degree", category: "education", text: "Completed a computer science degree.", employer: "Fictional Institute", role: "Bachelor of Science", dates: "2018 - 2022", confirmed: true }
    ] };
}
function field(key: string, label: string, overrides: Partial<FormField> = {}): FormField {
  return { key, label, type: "text", required: false, options: [], ...overrides };
}
function makePage(fields: FormField[], overrides: Partial<Omit<AssistancePage, "snapshot" | "fingerprint">> & { snapshot?: Partial<FormSnapshot> } = {}): AssistancePage {
  const pageUrl = overrides.url ?? url;
  const base = { url: pageUrl, fields, hasCaptcha: false, hasLegal: false, unsupported: [], ...overrides.snapshot };
  const snapshot: FormSnapshot = { ...base, fingerprint: sha(assistanceSnapshotPayload(base)) };
  const { snapshot: _snapshot, ...rest } = overrides;
  const page: AssistancePage = { kind: "job", title: "Data Engineer", job: { title: "Data Engineer", company: "Fictional Employer", location: "India", description: DESCRIPTION, evidence: "JobPosting" },
    occupied: [], blockers: [], ...rest, url: pageUrl, snapshot, fingerprint: "" };
  page.fingerprint = sha(assistancePagePayload(page)); return page;
}
function pageFixture(): AssistancePage {
  return makePage([field(KEYS.name, "Full name", { required: true }), field(KEYS.email, "Email", { type: "email", required: true }),
    field(KEYS.resume, "Resume", { type: "file", required: true, accept: [".pdf"] })]);
}
function rehash(page: AssistancePage): AssistancePage {
  page.snapshot.fingerprint = sha(assistanceSnapshotPayload(page.snapshot)); page.fingerprint = sha(assistancePagePayload(page)); return page;
}
function fakeAi(respond: (input: { system: string; user: string; schema: object }) => unknown, available = true) {
  const calls: { system: string; user: Record<string, unknown>; raw: string }[] = [];
  const ai: FieldAi = {
    status: async () => ({ available, provider: "ollama", model: "fixture-model", remote: false, ...(available ? {} : { reason: "Fixture AI is unavailable." }) }),
    call: async input => { calls.push({ system: input.system, user: JSON.parse(input.user), raw: input.user }); return respond(input); }
  };
  return { ai, calls };
}
async function harness(ai?: FieldAi) {
  const directory = resolve(`tests/.extension-assist-${randomUUID()}`);
  await mkdir(directory, { mode: 0o700 });
  const store = new Store(join(directory, "test.sqlite"));
  const profile = sourceProfile(); store.set("profile", profile);
  const engine = new Engine(store, directory, [], true, new URL(url).origin);
  const library = new ResumeLibrary(store, directory), service = new ExtensionAssistService({ store, engine, library, ...(ai ? { ai } : {}) });
  const artifacts = await createDocuments(profile, jobFixture(), {
    mode: "deterministic", factIds: profile.facts.map(fact => fact.id), skills: profile.skills, notes: []
  }, join(directory, "templates"));
  const pdf = artifacts.find(item => item.format === "pdf")!, docx = artifacts.find(item => item.format === "docx")!;
  const variant = await library.upload(1, "fictional-baseline.pdf", await readFile(join(directory, "templates", pdf.filename)), "Fictional data baseline", ["data"], true);
  await library.upload(2, "fictional-baseline-two.docx", await readFile(join(directory, "templates", docx.filename)), "Fictional secondary baseline", ["software"], true);
  return { directory, store, engine, library, service, variant,
    close: async () => { await service.close(); store.db.close(); await rm(directory, { recursive: true, force: true }); } };
}
const item = (plan: AssistPlan, key: string) => plan.items.find(entry => entry.key === key)!;
const ready = (plan: AssistPlan) => plan.items.filter(entry => entry.include && entry.value !== undefined).map(entry => entry.key);

test("assistance URL gate blocks restricted platforms, account URLs and sensitive query tokens", () => {
  for (const destination of ["https://linkedin.com/jobs/1", "https://uk.indeed.com/viewjob", "https://indeed.co.in/viewjob",
    "https://wellfound.com/jobs", "https://naukri.com/jobs", "https://careers.example.com/login",
    "https://careers.example.com/apply?access_token=secret", "http://careers.example.com/job", "https://localhost/jobs",
    "https://boards.greenhouse.io/embed/job_app?for=acme&token=abc", "https://careers.example.com/embed/job_app?token=123"])
    assert.throws(() => assistanceDestination(destination));
  assert.equal(assistanceDestination("https://careers.example.com/job/1#application").hash, "#application");
  assert.equal(assistanceDestination("https://boards.greenhouse.io/embed/job_app?for=acme&token=4012345").hostname, "boards.greenhouse.io",
    "Greenhouse's public numeric embed job id is the only exempt token");
});

test("page plan is deterministic, needs no JD import, binds one-use grants, and never counts a fill as applied", async () => {
  const h = await harness();
  try {
    const page = makePage([...pageFixture().snapshot.fields, field(KEYS.hear, "How did you hear about us?"), field(KEYS.city, "Portfolio website", { type: "url" })],
      { job: undefined, kind: "form", title: "Apply", url: "https://boards.greenhouse.io/fictional-employer/jobs/4012345" });
    const plan = await h.service.plan(page);
    assert.equal((await h.service.plan(page, { id: plan.recordId })).planHash, plan.planHash, "same page and data, same plan");
    assert.equal(item(plan, KEYS.name).value, "Taylor Fixture");
    assert.equal(item(plan, KEYS.name).source, "profile");
    assert.equal(item(plan, KEYS.email).value, "taylor@fictional.invalid");
    assert.equal(item(plan, KEYS.city).value, "https://taylor.fictional.invalid", "saved links match by name deterministically");
    assert.equal(item(plan, KEYS.hear).source, "manual");
    assert.equal(item(plan, KEYS.hear).include, false);
    assert.equal(plan.ai.asked, 0, "no AI was configured, so nothing was sent anywhere");
    assert.equal(plan.resume?.key, KEYS.resume);
    assert.deepEqual(plan.resume?.options.map(option => option.format), ["pdf"], "only formats the upload accepts are offered");
    assert.equal(plan.resume?.selected, `variant:${h.variant.id}`);
    const record = h.service.get(plan.recordId);
    assert.equal(record.company, "Fictional Employer", "company comes from the page URL/metadata when no JD was imported");
    const steps = plan.debug!.map(entry => entry.step);
    for (const name of ["validate", "record", "page", "saved-answers", "ai", "resume", "plan"]) assert.ok(steps.includes(name), `service step ${name}`);
    assert.equal(JSON.stringify(plan.debug).includes("taylor@fictional.invalid"), false, "diagnostics never contain answers");
    assert.equal(h.store.confirmedCount(), 0);

    await assert.rejects(h.service.grant(plan.recordId, page, { planHash: "0".repeat(64), include: ready(plan), resume: plan.resume!.selected }), /plan changed/);
    await assert.rejects(h.service.grant(plan.recordId, page, { planHash: plan.planHash, include: [KEYS.hear, "f0000000zzzz"], resume: null }), /unknown field/);
    await assert.rejects(h.service.grant(plan.recordId, page, { planHash: plan.planHash, include: [KEYS.email], resume: "variant:00000000-0000-0000-0000-000000000000" }), /listed resumes/);
    const grant = await h.service.grant(plan.recordId, page, { planHash: plan.planHash, include: [...ready(plan), KEYS.hear],
      edits: { [KEYS.hear]: "Company website" }, resume: plan.resume!.selected });
    assert.deepEqual(grant.fields, { [KEYS.name]: "Taylor Fixture", [KEYS.email]: "taylor@fictional.invalid", [KEYS.city]: "https://taylor.fictional.invalid", [KEYS.hear]: "Company website" });
    assert.equal(sha(Buffer.from(grant.resume!.base64, "base64")), h.variant.artifact.sha256, "the approved original bytes are attached unchanged");
    assert.equal(grant.resume!.filename, "fictional-baseline.pdf");
    assert.equal(h.service.get(plan.recordId).status, "fill_intent", "intent is durable before bytes leave the service");
    await assert.rejects(h.service.grant(plan.recordId, page, { planHash: plan.planHash, include: [KEYS.name] }), /existing assistance/);
    await assert.rejects(h.service.report(plan.recordId, grant.id, { filled: ["f0000000zzzz"], preserved: [], skipped: [], errors: [], newFields: 0, blockers: [], selected: {} }), /unauthorized/);
    const reported = await h.service.report(plan.recordId, grant.id, { filled: [KEYS.name, KEYS.email, KEYS.city, KEYS.hear, KEYS.resume], preserved: [], skipped: [], errors: [], newFields: 0, blockers: [], selected: {} });
    assert.equal(reported.record.status, "filled");
    assert.equal(reported.record.lastFill?.values[KEYS.email], sha(comparableValue("email", "taylor@fictional.invalid")), "only value hashes are retained");
    assert.equal(JSON.stringify(reported.record).includes("taylor@fictional.invalid"), false);
    await assert.rejects(h.service.report(plan.recordId, grant.id, { filled: [], preserved: [], skipped: [], errors: [], newFields: 0, blockers: [], selected: {} }), /already reported/);
    assert.equal(h.store.confirmedCount(), 0);

    h.service.update(plan.recordId, { status: "submission_unknown", notes: "User unsure whether final submit succeeded." });
    assert.equal(h.store.confirmedCount(), 0);
    assert.ok((await h.service.plan(page, { id: plan.recordId })).blockers.some(blocker => /tracked state|already has/.test(blocker)));
    const receipt = h.service.receipt(plan.recordId, "User-reported real receipt TEST-123", "2026-09-01");
    assert.equal(receipt.status, "submitted_confirmed");
    assert.equal(h.store.confirmedCount(), 1);
    h.service.receipt(plan.recordId, "User-reported real receipt TEST-123", "2026-09-01");
    assert.equal(h.store.confirmedCount(), 1);
    const after = await h.service.plan(page, { id: plan.recordId });
    await assert.rejects(h.service.grant(plan.recordId, page, { planHash: after.planHash, include: ready(after) }), /existing assistance|submitted/);
  } finally { await h.close(); }
});

test("typing or attaching on the page after review keeps the reviewed plan valid, and the page keeps your values", async () => {
  const h = await harness();
  try {
    const page = pageFixture();
    const plan = await h.service.plan(page);
    const typed = rehash({ ...page, occupied: [KEYS.email, KEYS.resume] });
    assert.equal(typed.fingerprint, page.fingerprint, "values are not structure");
    const replanned = await h.service.plan(typed, { id: plan.recordId });
    assert.equal(replanned.planHash, plan.planHash, "occupancy never changes the plan hash");
    assert.equal(item(replanned, KEYS.email).include, false);
    assert.match(item(replanned, KEYS.email).reason!, /Already answered/);
    assert.equal(replanned.resume?.selected, undefined, "an attached file is kept by default");
    const grant = await h.service.grant(plan.recordId, typed, { planHash: plan.planHash, include: ready(plan), resume: plan.resume!.selected });
    assert.deepEqual(Object.keys(grant.fields), [KEYS.name], "occupied fields are never sent to the page for filling");
  } finally { await h.close(); }
});

test("a plan that changed after review is explained by question, without revealing values", async () => {
  const h = await harness();
  try {
    const page = pageFixture();
    const plan = await h.service.plan(page);
    h.store.set("profile", { ...h.store.profile(), email: "changed@fictional.invalid", version: h.store.profile().version + 1 });
    await assert.rejects(h.service.grant(plan.recordId, page, { planHash: plan.planHash, include: ready(plan) }), (error: Error) => {
      assert.match(error.message, /"Email" answer changed/);
      assert.equal(error.message.includes("changed@fictional.invalid") || error.message.includes("taylor@fictional.invalid"), false);
      return true;
    });
  } finally { await h.close(); }
});

test("tailoring stays optional and immutable; a prepared packet becomes the preferred resume in the plan", async () => {
  const h = await harness();
  try {
    const page = pageFixture(), imported = h.service.import(page);
    assert.equal(imported.record.status, "detected");
    assert.equal(h.service.import(page).record.id, imported.record.id, "same URL dedupes");
    let review = await h.service.prepare(imported.record.id, page);
    const original = structuredClone(review.packet!);
    assert.equal(review.packet!.draft.mode, "jd-tailored");
    assert.equal(review.packet!.formSnapshot, undefined, "form structure never forks the resume packet");
    const file = await h.service.artifact(imported.record.id, "pdf");
    assert.equal(sha(Buffer.from(file.base64, "base64")), file.sha256);
    assert.match(await extractPdfText(Buffer.from(file.base64, "base64")), /Taylor Fixture/);
    review = await h.service.edit(imported.record.id, page, ["exp-two", "exp-one", "degree"], ["SQL", "Python"]);
    assert.notEqual(review.packet!.id, original.id);
    assert.notEqual(packetHash(review.packet!), packetHash(original));
    assert.deepEqual(h.engine.get(original.id), original);
    assert.equal(sha(await h.library.bytes(h.variant.id)), h.variant.artifact.sha256);
    await assert.rejects(h.service.edit(imported.record.id, page, ["invented"], ["SQL"]), /fact|Invalid/i);
    const plan = await h.service.plan(page, { id: imported.record.id });
    assert.equal(plan.recordId, imported.record.id);
    assert.equal(plan.resume?.selected, `packet:${review.packet!.id}:pdf`);
    const grant = await h.service.grant(plan.recordId, page, { planHash: plan.planHash, include: ready(plan), resume: plan.resume!.selected });
    assert.equal(grant.resume!.sha256, review.packet!.artifacts.find(artifact => artifact.format === "pdf")!.sha256);
    assert.equal(grant.packetId, review.packet!.id);
    const saved = h.store.profile(); h.store.set("profile", { ...saved, phone: "Changed", version: saved.version + 1 });
    const reported = await h.service.report(plan.recordId, grant.id, { filled: [KEYS.name], preserved: [], skipped: [], errors: [], newFields: 0, blockers: [], selected: {} });
    assert.equal(reported.record.status, "manual_required");
    assert.ok(reported.record.blockers.some(blocker => /Profile or resume changed/.test(blocker)));
    const stale = await h.service.plan(page, { id: plan.recordId });
    assert.ok(stale.resume?.options.every(option => option.source === "baseline"), "an out-of-date packet is never offered");
    assert.match(stale.resume?.reason ?? "", /out of date/);
  } finally { await h.close(); }
});

test("stale snapshots are rejected; clear, revocation and restart produce manual-only recovery", async () => {
  const h = await harness();
  try {
    const page = pageFixture();
    const stale = structuredClone(page); stale.snapshot.fields[0].required = false;
    await assert.rejects(h.service.plan(stale), /fingerprint/i);
    const forged = rehash(makePage([field(KEYS.name, "Password", { required: true })]));
    await assert.rejects(h.service.plan(forged), /sensitive/);
    const record = h.service.import(page).record;
    const pending = h.service.prepare(record.id, page);
    assert.throws(() => h.service.clear(), /Wait for current/);
    await pending;
    let plan = await h.service.plan(page, { id: record.id });
    let grant = await h.service.grant(record.id, page, { planHash: plan.planHash, include: ready(plan) });
    h.service.invalidate();
    assert.equal(h.service.get(record.id).status, "manual_required");
    await assert.rejects(h.service.report(record.id, grant.id, { filled: [], preserved: [], skipped: [], errors: [], newFields: 0, blockers: [], selected: {} }), /unknown/);
    plan = await h.service.plan(page, { id: record.id });
    grant = await h.service.grant(record.id, page, { planHash: plan.planHash, include: ready(plan) });
    assert.ok(grant.id);
    const recovered = new ExtensionAssistService({ store: h.store, engine: h.engine, library: h.library });
    assert.equal(recovered.get(record.id).status, "manual_required");
    assert.equal(h.store.confirmedCount(), 0);
    await recovered.close();
    h.service.clear();
    assert.equal(h.service.list().total, 0);
  } finally { await h.close(); }
});

test("AI help is validated against confirmed facts, cached by content, replayed exactly at grant time, and never sees contact details", async () => {
  const fields = [
    field(KEYS.notice, "How much notice do you need to give?"),
    field(KEYS.why, "Why do you want to work here?", { type: "textarea", maxLength: 600 }),
    field(KEYS.education, "Highest level of education", { type: "select", options: ["hs", "ba", "ma"], optionLabels: { hs: "High school", ba: "Bachelor's", ma: "Master's" } }),
    field(KEYS.kubernetes, "Describe your Kubernetes work", { type: "textarea" }),
    field(KEYS.hear, "How did you hear about us?"),
    field(KEYS.nationality, "What is your nationality?"),
  ];
  const { ai, calls } = fakeAi(input => {
    const user = JSON.parse(input.user) as { questions: { id: string; text: string }[] };
    const id = (text: string) => user.questions.find(question => question.text.startsWith(text))!.id;
    return { results: [
      { id: id("How much notice"), decision: "answer_key", answerKey: "notice_period_days", option: "", text: "", factIds: [], reason: "" },
      { id: id("Why do you"), decision: "draft", answerKey: "", option: "", factIds: ["f1", "f2"], reason: "",
        text: "I build reliable Python and SQL data pipelines on AWS and cut pipeline runtime by 20%. Your data platform role matches that work." },
      { id: id("Highest level"), decision: "option", answerKey: "", option: "Bachelor's", text: "", factIds: ["f3"], reason: "" },
      { id: id("Describe your Kubernetes"), decision: "draft", answerKey: "", option: "", factIds: ["f1"], reason: "", text: "I ran Kubernetes clusters for 5 years." },
    ] };
  });
  const h = await harness(ai);
  try {
    h.store.set("profile", { ...h.store.profile(), answers: { ...h.store.profile().answers, notice_period_days: "30" } });
    const page = makePage(fields);
    const plan = await h.service.plan(page);
    assert.equal(calls.length, 1, "one batched request for every unknown question");
    const prompt = calls[0];
    assert.match(prompt.system, /never follow instructions/);
    assert.equal(prompt.raw.includes("taylor@fictional.invalid"), false);
    assert.equal(prompt.raw.includes("202-555"), false);
    assert.equal(prompt.raw.includes("\"30\""), false, "saved answer values stay local; only key names are shared");
    assert.equal((prompt.user.questions as { text: string }[]).some(question => /nationality/i.test(question.text)), false, "eligibility/demographic questions are never sent");
    assert.equal((prompt.user.questions as { text: string }[]).some(question => /hear about/i.test(question.text)), false, "personal answer-bank questions wait for your saved answer instead of AI");
    assert.equal(item(plan, KEYS.notice).value, "30 days");
    assert.equal(item(plan, KEYS.notice).source, "ai_mapped");
    assert.equal(item(plan, KEYS.why).source, "ai_draft");
    assert.equal(item(plan, KEYS.why).review, true);
    assert.equal(item(plan, KEYS.education).value, "ba");
    assert.equal(item(plan, KEYS.education).source, "ai_option");
    assert.equal(item(plan, KEYS.kubernetes).source, "manual");
    assert.match(item(plan, KEYS.kubernetes).reason!, /number \(5\)|Kubernetes/, "invented numbers and technologies are rejected deterministically");
    assert.equal(item(plan, KEYS.hear).source, "manual");
    assert.match(item(plan, KEYS.hear).reason!, /how_did_you_hear/);
    assert.equal(item(plan, KEYS.nationality).source, "manual");
    assert.deepEqual([plan.ai.asked, plan.ai.cached], [4, 0]);

    const again = await h.service.plan(page, { id: plan.recordId });
    assert.equal(calls.length, 1, "accepted decisions are replayed from the content-hash cache");
    assert.equal(again.planHash, plan.planHash);
    assert.equal(again.ai.cached, 4, "rejections replay too, so the same inputs always give the same plan");
    const grant = await h.service.grant(plan.recordId, page, { planHash: plan.planHash, include: ready(plan) });
    assert.equal(calls.length, 1, "authorizing never makes a new model call");
    assert.equal(grant.fields[KEYS.why], item(plan, KEYS.why).value);
    assert.equal(grant.fields[KEYS.education], "ba");

    const off = await h.service.plan(page, { id: plan.recordId, ai: false });
    assert.equal(off.items.filter(entry => entry.source.startsWith("ai_")).length, 0);
    assert.equal(calls.length, 1);
    assert.equal(h.service.intelligence.clearCache() > 0, true);
  } finally { await h.close(); }
});

test("unavailable or malformed AI output changes nothing and is reported plainly", async () => {
  const unavailable = fakeAi(() => ({}), false), malformed = fakeAi(() => ({ results: [{ id: "q1", decision: "draft", text: 42 }] }));
  for (const [fake, pattern] of [[unavailable, /unavailable/], [malformed, /structure/]] as const) {
    const h = await harness(fake.ai);
    try {
      const plan = await h.service.plan(makePage([field(KEYS.why, "Why do you want to work here?", { type: "textarea" })]));
      assert.equal(item(plan, KEYS.why).source, "manual");
      assert.match(plan.ai.reason ?? "", pattern);
    } finally { await h.close(); }
  }
  assert.equal(unavailable.calls.length, 0, "no prompt is sent when the provider is unavailable");
});

test("site errors produce reviewed format fixes that replace only Chairman's own values; remembered answers are exact and reversible", async () => {
  const { ai } = fakeAi(input => JSON.parse(input.user).limit ? { text: "I build reliable Python and SQL pipelines on AWS." } : { results: [
    { id: "q1", decision: "draft", answerKey: "", option: "", factIds: ["f1"], reason: "", text: "I build reliable Python and SQL data pipelines on AWS with monitoring, and I would bring that reliability to your platform team." }] });
  const h = await harness(ai);
  try {
    const page = makePage([field(KEYS.phone, "Phone", { type: "tel" }), field(KEYS.city, "Location", { type: "combobox" }),
      field(KEYS.why, "Why do you want to work here?", { type: "textarea" }), field(KEYS.hear, "How did you hear about us?")]);
    const plan = await h.service.plan(page);
    assert.equal(item(plan, KEYS.phone).value, "+1 202-555-0118");
    assert.equal(item(plan, KEYS.city).value, "India", "dynamic comboboxes are planned as the text to choose");
    const grant = await h.service.grant(plan.recordId, page, { planHash: plan.planHash, include: [KEYS.phone, KEYS.city, KEYS.why, KEYS.hear],
      edits: { [KEYS.hear]: "Company website" } });
    const { repairs } = await h.service.report(plan.recordId, grant.id, { filled: [KEYS.phone, KEYS.why, KEYS.hear], preserved: [], skipped: [], newFields: 0, blockers: [], selected: {},
      errors: [{ key: KEYS.phone, message: "Enter a 10 digit phone number" }, { key: KEYS.city, message: "No listed option matched this answer; choose one yourself.", options: ["Bengaluru, India", "Mumbai, India"] },
        { key: KEYS.why, message: "Please use at most 60 characters." }] });
    assert.deepEqual(repairs.find(repair => repair.key === KEYS.phone), { key: KEYS.phone, value: "2025550118", reason: "Used the national number without the country code.", source: "repair" });
    assert.deepEqual(repairs.find(repair => repair.key === KEYS.city)?.options, ["Bengaluru, India", "Mumbai, India"]);
    assert.equal(repairs.find(repair => repair.key === KEYS.why)?.source, "ai_repair");
    const filledPage = rehash({ ...page, occupied: [KEYS.phone, KEYS.why, KEYS.hear] });
    const next = await h.service.plan(filledPage, { id: plan.recordId });
    assert.deepEqual([item(next, KEYS.phone).source, item(next, KEYS.phone).value, item(next, KEYS.phone).overwrite], ["repair", "2025550118", true]);
    assert.equal(item(next, KEYS.city).value, undefined, "no option is guessed; you pick from the site's own list");
    assert.deepEqual(item(next, KEYS.city).options?.map(option => option.label), ["Bengaluru, India", "Mumbai, India"]);
    assert.match(item(next, KEYS.hear).reason!, /Already answered/);
    const fix = await h.service.grant(plan.recordId, filledPage, { planHash: next.planHash, include: [KEYS.phone, KEYS.city], edits: { [KEYS.city]: "Bengaluru, India" } });
    assert.equal(fix.overwrite?.[KEYS.phone], sha(comparableValue("tel", "+1 202-555-0118")), "overwrite is bound to the exact value Chairman filled");
    assert.equal(fix.fields[KEYS.city], "Bengaluru, India");
    await h.service.report(plan.recordId, fix.id, { filled: [KEYS.phone, KEYS.city], preserved: [], skipped: [], errors: [], newFields: 0, blockers: [], selected: { [KEYS.city]: "Bengaluru, India" } });

    const blank = makePage([field(KEYS.hear, "How did you hear about us?"), field(KEYS.nationality, "Are you authorized to work in India?", { type: "radio", options: ["y", "n"], optionLabels: { y: "Yes", n: "No" } })],
      { url: "http://127.0.0.1:47821/fixture/application?step=2" });
    assert.throws(() => h.service.remember(plan.recordId, blank, [{ key: KEYS.nationality, value: "y" }]), /non-sensitive/);
    assert.equal(h.service.remember(plan.recordId, blank, [{ key: KEYS.hear, value: "Company website" }]), 1);
    const remembered = await h.service.plan(blank, { id: plan.recordId });
    assert.deepEqual([item(remembered, KEYS.hear).value, item(remembered, KEYS.hear).source], ["Company website", "remembered"]);
    assert.deepEqual(h.service.rememberedAnswers().map(entry => entry.question), ["How did you hear about us?"]);
    assert.equal(h.service.forget(["How did you hear about us?"]), 1);
    assert.equal(item(await h.service.plan(blank, { id: plan.recordId, ai: false }), KEYS.hear).source, "manual");
  } finally { await h.close(); }
});

test("dates misread as an employer (a résumé-import mistake) are never answered as your current company", async () => {
  const h = await harness();
  try {
    const employer = "f0000000000c", title = "f0000000000d";
    const page = makePage([field(employer, "Current employer", { required: true }), field(title, "Current job title")], { job: undefined, kind: "form", title: "Apply" });
    const mistake = (id: string) => ({ id, category: "experience" as const, text: "Ran AWS data platforms for analytics teams.", employer: "Sept", role: "Senior Data Engineer", dates: "2023 – Present", confirmed: true });
    h.store.set("profile", { ...sourceProfile(), facts: [mistake("m1"), mistake("m2"), mistake("m3")] });
    let plan = await h.service.plan(page);
    assert.notEqual(item(plan, employer).value, "Sept");
    assert.equal(item(plan, employer).source, "manual", "only a month in the employer field: Chairman asks you instead");
    assert.equal(item(plan, title).value, "Senior Data Engineer", "the rest of the record is still used");
    h.store.set("profile", { ...sourceProfile(), facts: [mistake("m1"), { ...mistake("real"), employer: "Hewlett Packard Enterprise" }] });
    plan = await h.service.plan(page);
    assert.equal(item(plan, employer).value, "Hewlett Packard Enterprise", "the real employer is used once the date is ignored");
  } finally { await h.close(); }
});

test("strict extension route schemas reject selectors, forged snapshots, invented keys and false consent", async () => {
  const h = await harness(), app = Fastify();
  const service = registerExtensionAssist(app, h);
  try {
    const planned = await app.inject({ method: "POST", url: "/api/extension/assist/plan", payload: { page: pageFixture(), ai: false } });
    assert.equal(planned.statusCode, 200, planned.body);
    const plan = planned.json() as AssistPlan;
    for (const payload of [
      { page: pageFixture(), selector: "#password" },
      { page: { ...pageFixture(), fingerprint: "0".repeat(64) } },
      { page: rehash(makePage([field("field-0", "Full name")])) },
    ]) assert.ok((await app.inject({ method: "POST", url: "/api/extension/assist/plan", payload })).statusCode >= 400);
    for (const payload of [
      { id: plan.recordId, page: pageFixture(), planHash: plan.planHash, include: ready(plan), confirm: false },
      { id: plan.recordId, page: pageFixture(), planHash: plan.planHash, include: ["#email"], confirm: true },
      { id: plan.recordId, page: pageFixture(), planHash: plan.planHash, include: ready(plan), edits: { "input[name=x]": "y" }, confirm: true },
    ]) assert.ok((await app.inject({ method: "POST", url: "/api/extension/assist/grant", payload })).statusCode >= 400);
    const denied = await app.inject({ method: "POST", url: `/api/assistance/${plan.recordId}/receipt`, payload: { confirmation: "No actual receipt", submittedDate: "2026-09-01", confirm: false } });
    assert.ok(denied.statusCode >= 400);
    assert.equal((await app.inject({ method: "GET", url: "/api/assistance?limit=1&offset=0" })).json().total, 1);
    assert.deepEqual((await app.inject({ method: "GET", url: "/api/assist-answers" })).json(), { items: [] });
  } finally { await app.close(); await service.close(); await h.close(); }
});

const realisticForm = (description: string) => `<!doctype html><html><head><title>Data Engineer - Fictional Employer</title>
  <script type="application/ld+json">${JSON.stringify({ "@type": "JobPosting", title: "Data Engineer", description, hiringOrganization: { name: "Fictional Employer" }, jobLocation: { address: { addressCountry: "India" } } })}</script></head>
  <body><header><form role="search"><input type="search" name="q" aria-label="Search jobs"></form><div hidden><input type="password" name="login"></div></header>
  <main><h1>Data Engineer</h1><p>Responsibilities: ${description}</p>
  <form id="application-form"><input type="hidden" value="HIDDEN_TOKEN_MUST_NOT_LEAK">
    <div class="field"><label for="full_name">Full name <span aria-hidden="true">*</span></label><input id="full_name" name="full_name" value="KEEP_MANUAL_NAME"></div>
    <div class="field"><label for="email">Email</label><input id="email" type="email" aria-required="true"></div>
    <div class="field"><div class="field-label">Phone</div><input id="phone" type="tel" pattern="[0-9]{10}"></div>
    <div class="field"><label for="employer">Current employer</label><input id="employer"></div>
    <div class="field"><label for="country">Country</label><select id="country"><option value="0">Select...</option><option value="in">India</option><option value="us">United States</option></select></div>
    <div class="field"><div class="question-title">Are you legally authorized to work in India?</div>
      <label><input type="radio" name="auth" value="1"> Yes</label><label><input type="radio" name="auth" value="0"> No</label></div>
    <div class="field"><label id="loc-label">Location</label><div class="select__control"><div class="select__value-container"><div class="select__single-value"></div>
      <input id="react-select-7-input" role="combobox" aria-autocomplete="list" aria-labelledby="loc-label" aria-expanded="false"></div></div><div class="select__menu-portal"></div></div>
    <div class="field"><div class="ashby-question-title">Are you willing to relocate?</div><div class="yesno"><button type="button">Yes</button><button type="button">No</button></div></div>
    <div class="ashby-application-form-autofill-uploader"><p>Autofill from resume</p><p>Upload your resume here to autofill key application fields.</p>
      <label>Upload file<input type="file" id="autofill" style="position:absolute;width:1px;height:1px;opacity:0"></label></div>
    <div class="field"><label class="upload">Resume/CV <input type="file" id="resume" accept=".pdf" style="position:absolute;width:1px;height:1px;opacity:0"></label></div>
    <div class="field"><label for="why">Why do you want to join?</label><textarea id="why" maxlength="600"></textarea></div>
    <div class="field"><label for="gender">Gender</label><select id="gender"><option value="">Select</option><option>Female</option><option>Male</option></select></div>
    <div class="field"><label><input type="checkbox" required> I agree to the privacy policy</label></div>
    <button type="submit">Submit application</button></form></main>
  <footer><form class="newsletter"><label>Email address<input type="email" name="newsletter"></label><button>Subscribe</button></form></footer>
  <div class="grecaptcha-badge" data-sitekey="fixture" style="width:256px;height:60px"></div>
  <script>
    window.submissions = 0; document.querySelector("#application-form").onsubmit = e => { e.preventDefault(); window.submissions++; };
    const input = document.getElementById("react-select-7-input"), control = input.closest(".select__control"), portal = document.querySelector(".select__menu-portal");
    const all = ["Bengaluru, Karnataka, India", "Mumbai, Maharashtra, India", "India (anywhere)"];
    function open(filter) {
      portal.innerHTML = ""; const menu = document.createElement("div"); menu.className = "select__menu"; menu.setAttribute("role", "listbox"); menu.id = "loc-listbox";
      for (const label of all.filter(l => !filter || l.toLowerCase().includes(filter.toLowerCase()))) {
        const option = document.createElement("div"); option.setAttribute("role", "option"); option.textContent = label;
        option.addEventListener("click", () => { document.querySelector(".select__single-value").textContent = label; input.value = ""; portal.innerHTML = ""; });
        menu.append(option);
      }
      portal.append(menu); input.setAttribute("aria-controls", menu.id);
    }
    control.addEventListener("mousedown", () => setTimeout(() => open(""), 30));
    input.addEventListener("input", () => setTimeout(() => open(input.value), 120));
    input.addEventListener("keydown", e => { if (e.key === "Escape") portal.innerHTML = ""; });
    document.querySelectorAll(".yesno button").forEach(b => b.addEventListener("click", () => { document.querySelectorAll(".yesno button").forEach(x => x.removeAttribute("aria-pressed")); b.setAttribute("aria-pressed", "true"); }));
  </script></body></html>`;

test("real Chrome: intelligent detection, stable keys, reviewed fill of native and custom controls, and nothing outside the application form", async t => {
  const { ai } = fakeAi(input => {
    const user = JSON.parse(input.user) as { questions: { id: string; text: string }[] };
    return { results: user.questions.map(question => /Why do you want/.test(question.text)
      ? { id: question.id, decision: "draft", answerKey: "", option: "", factIds: ["f1"], reason: "", text: "I build reliable Python and SQL data pipelines on AWS with monitoring." }
      : { id: question.id, decision: "manual", answerKey: "", option: "", text: "", factIds: [], reason: "Needs you." }) };
  });
  const h = await harness(ai);
  h.store.set("profile", { ...h.store.profile(), phone: "+91 98765 43210", answers: { Country: "India", location: "Bengaluru" } });
  const browser = await chromium.launch({ headless: true, ...(existsSync(chromium.executablePath()) ? {} : { channel: "chrome" }) });
  const context = await browser.newContext(), tab = await context.newPage();
  const bundle = await build({ entryPoints: [resolve("apps/extension/assist-page.ts")], bundle: true, write: false, format: "iife", globalName: "ChairmanPage", platform: "browser", target: "chrome120" });
  let html = realisticForm(DESCRIPTION);
  await tab.route("**/*", route => route.request().url().startsWith(url) ? route.fulfill({ contentType: "text/html", body: html }) : route.abort());
  const reset = async (page: Page = tab) => { await page.goto(url); await page.addScriptTag({ content: bundle.outputFiles[0].text }); };
  const timing = "{ quietMs: 40, maxWaitMs: 400, finalQuietMs: 80, finalMaxMs: 500 }";
  const inspect = () => tab.evaluate(`ChairmanPage.inspectAssistancePage(document, ${timing})`) as Promise<AssistancePage>;
  const fill = (grant: AssistanceGrant) => tab.evaluate(`ChairmanPage.fillAssistancePage(document, ${JSON.stringify(grant)}, ${timing})`) as Promise<AssistanceFillResult & { selected: Record<string, string> }>;
  try {
    await reset();
    const captured = await inspect(), again = await inspect();
    assert.equal(captured.fingerprint, again.fingerprint, "identical scans produce identical structure fingerprints");
    assert.equal(captured.kind, "job");
    assert.equal(captured.job?.description, DESCRIPTION);
    assert.equal(captured.snapshot.hasCaptcha, false, "a passive invisible reCAPTCHA badge is not a challenge");
    const labels = captured.snapshot.fields.map(entry => entry.label);
    assert.deepEqual(labels, ["Full name", "Email", "Phone", "Current employer", "Country", "Are you legally authorized to work in India?", "Location",
      "Are you willing to relocate?", "Resume/CV", "Why do you want to join?", "Gender", "I agree to the privacy policy"]);
    const byLabel = (label: string) => captured.snapshot.fields.find(entry => entry.label === label)!;
    assert.equal(byLabel("Full name").required, true, "asterisks mark required fields");
    assert.equal(byLabel("Email").required, true, "aria-required marks required fields");
    assert.deepEqual(byLabel("Country").options, ["in", "us"], "placeholder options are not answers");
    assert.equal(byLabel("Location").type, "combobox");
    assert.equal(byLabel("Phone").pattern, "[0-9]{10}");
    assert.ok(captured.occupied.includes(byLabel("Full name").key));
    assert.equal(JSON.stringify(captured).includes("KEEP_MANUAL_NAME"), false, "current values are never exported");
    assert.equal(JSON.stringify(captured).includes("HIDDEN_TOKEN_MUST_NOT_LEAK"), false);
    assert.equal(byLabel("Gender").sensitivity, "disclosure", "voluntary self-identification is recognised and tagged, never answered blind");
    assert.deepEqual([byLabel("I agree to the privacy policy").sensitivity, byLabel("I agree to the privacy policy").type, byLabel("I agree to the privacy policy").required],
      ["acknowledgement", "checkbox", true]);

    const plan = await h.service.plan(captured);
    const planned = (label: string) => item(plan, byLabel(label).key);
    assert.equal(planned("Phone").value, "9876543210", "values are adapted to the site's visible pattern before filling");
    assert.equal(planned("Country").value, "in");
    assert.equal(planned("Are you legally authorized to work in India?").value, "1");
    assert.equal(planned("Location").value, "Bengaluru");
    assert.equal(planned("Current employer").value, "Fictional Labs");
    assert.equal(planned("Why do you want to join?").source, "ai_draft");
    assert.equal(planned("Are you willing to relocate?").source, "manual");
    assert.equal(planned("Gender").include, false);
    assert.match(planned("Gender").reason!, /Voluntary disclosure/);
    assert.equal(planned("I agree to the privacy policy").include, false);
    assert.match(planned("I agree to the privacy policy").reason!, /Accept required acknowledgements/);
    const grant = await h.service.grant(plan.recordId, captured, { planHash: plan.planHash, include: [...ready(plan), byLabel("Are you willing to relocate?").key],
      edits: { [byLabel("Are you willing to relocate?").key]: "Yes" }, resume: plan.resume!.selected });
    const result = await fill(grant);
    assert.deepEqual(result.errors, []);
    assert.deepEqual(result.preserved, [], "occupied fields were never planned, so nothing needed preserving");
    assert.equal(await tab.locator("#full_name").inputValue(), "KEEP_MANUAL_NAME");
    assert.equal(await tab.locator("#email").inputValue(), "taylor@fictional.invalid");
    assert.equal(await tab.locator("#phone").inputValue(), "9876543210");
    assert.equal(await tab.locator("#country").inputValue(), "in");
    assert.equal(await tab.locator("input[name=auth]:checked").getAttribute("value"), "1");
    assert.equal(await tab.locator(".select__single-value").textContent(), "Bengaluru, Karnataka, India");
    assert.equal(result.selected[byLabel("Location").key], "Bengaluru, Karnataka, India");
    assert.equal(await tab.locator(".yesno button[aria-pressed=true]").textContent(), "Yes");
    assert.equal(await tab.locator("#why").inputValue(), "I build reliable Python and SQL data pipelines on AWS with monitoring.");
    const uploaded = await tab.locator("#resume").evaluate(async input => Array.from(new Uint8Array(await (input as HTMLInputElement).files![0].arrayBuffer())));
    assert.equal(sha(Buffer.from(uploaded)), grant.resume!.sha256);
    assert.equal(await tab.locator("#autofill").evaluate(input => (input as HTMLInputElement).files!.length), 0, "a site's autofill-from-resume uploader is never used as the resume field");
    assert.equal(await tab.locator("#gender").inputValue(), "", "demographic questions are never touched while voluntary disclosures are off");
    assert.equal(await tab.locator("input[type=checkbox]").isChecked(), false, "consent stays yours while required acknowledgements are off");
    assert.equal(await tab.locator("input[name=newsletter]").inputValue(), "", "fields outside the application form are never filled");
    assert.equal(await tab.locator("input[name=q]").inputValue(), "");
    assert.equal(await tab.evaluate("window.submissions"), 0, "Chairman never submits");
    const report = await h.service.report(plan.recordId, grant.id, result);
    assert.ok(["filled", "manual_required"].includes(report.record.status));
    assert.equal(h.store.confirmedCount(), 0);
    await assert.rejects(fill(grant), /already used/);
    const after = await inspect();
    assert.deepEqual(after.snapshot.fields.map(entry => entry.key), captured.snapshot.fields.map(entry => entry.key), "filling never changes field identity");
    assert.equal(after.fingerprint, captured.fingerprint, "values are not structure");
    const replan = await h.service.plan(after, { id: plan.recordId });
    assert.equal(ready(replan).length, 0, "a filled page has nothing left to fill");

    await t.test("page traces name every step, including combobox internals, without exposing answers", async () => {
      await reset();
      type Trace = { step: string; detail?: string; ok?: false }[];
      const traced = await tab.evaluate(`(async () => { ChairmanPage.startTrace(); const page = await ChairmanPage.inspectAssistancePage(document, ${timing}); return { page, trace: ChairmanPage.takeTrace() }; })()`) as { page: AssistancePage; trace: Trace };
      const steps = traced.trace.map(entry => entry.step);
      for (const name of ["settle", "form-root", "captcha", "job", "fingerprint"]) assert.ok(steps.includes(name), `page step ${name}`);
      assert.match(traced.trace.find(entry => entry.step === "form-root")!.detail!, /form#application-form/);
      assert.equal(traced.trace.filter(entry => entry.step === "field").length, traced.page.snapshot.fields.length);
      const tracedPlan = await h.service.plan(traced.page, { id: plan.recordId });
      const tracedGrant = await h.service.grant(tracedPlan.recordId, traced.page, { planHash: tracedPlan.planHash, include: ready(tracedPlan) });
      const filled = await tab.evaluate(`(async () => { ChairmanPage.startTrace(); const result = await ChairmanPage.fillAssistancePage(document, ${JSON.stringify(tracedGrant)}, ${timing}); return { result, trace: ChairmanPage.takeTrace() }; })()`) as { result: AssistanceFillResult & { selected: Record<string, string> }; trace: Trace };
      const fillSteps = filled.trace.map(entry => entry.step);
      for (const name of ["grant", "fingerprint-check", "fill", "combobox-open", "combobox-match", "combobox-verify", "fill-summary"]) assert.ok(fillSteps.includes(name), `fill step ${name}`);
      assert.equal(filled.trace.filter(entry => entry.step === "fill").length, Object.keys(tracedGrant.fields).length);
      const serialized = JSON.stringify([traced.trace, filled.trace]);
      for (const secret of ["taylor@fictional.invalid", "9876543210", "Fictional Labs"]) assert.equal(serialized.includes(secret), false, `trace never contains ${secret}`);
      await h.service.report(tracedPlan.recordId, tracedGrant.id, filled.result);
    });
    await t.test("stale page, expired grant and wrong resume bytes never transmit", async () => {
      for (const mutation of ["stale", "expired", "bytes"] as const) {
        await reset(); const current = await inspect();
        const attempt: AssistanceGrant = { ...grant, id: randomUUID(), pageFingerprint: current.fingerprint, expiresAt: Date.now() + 90_000 };
        if (mutation === "stale") await tab.locator("#employer").evaluate(input => input.setAttribute("required", ""));
        if (mutation === "expired") attempt.expiresAt = 1;
        if (mutation === "bytes") attempt.resume = { ...grant.resume!, sha256: "0".repeat(64) };
        await assert.rejects(fill(attempt), /changed|expired|hash/);
        assert.equal(await tab.locator("#email").inputValue(), "");
        assert.equal(await tab.locator("#resume").evaluate(input => (input as HTMLInputElement).files!.length), 0);
      }
    });
    await t.test("typing between review and fill keeps the plan valid and your value wins", async () => {
      await reset(); const current = await inspect();
      await tab.locator("#email").fill("typed-by-you@fictional.invalid");
      const result = await fill({ ...grant, id: randomUUID(), pageFingerprint: current.fingerprint, expiresAt: Date.now() + 90_000 });
      assert.ok(result.preserved.includes(byLabel("Email").key));
      assert.equal(await tab.locator("#email").inputValue(), "typed-by-you@fictional.invalid");
    });
    await t.test("repairs replace only Chairman's own earlier value", async () => {
      await reset(); let current = await inspect();
      const phone = byLabel("Phone").key;
      await tab.locator("#phone").fill("5550001111");
      current = await inspect();
      const repaired = await fill({ ...grant, id: randomUUID(), pageFingerprint: current.fingerprint, expiresAt: Date.now() + 90_000,
        fields: { [phone]: "9876543210" }, overwrite: { [phone]: sha(comparableValue("tel", "+1 202 555 0000")) }, resume: undefined });
      assert.deepEqual(repaired.preserved, [phone]);
      assert.equal(await tab.locator("#phone").inputValue(), "5550001111", "a value you typed is never overwritten");
      const own = await fill({ ...grant, id: randomUUID(), pageFingerprint: current.fingerprint, expiresAt: Date.now() + 90_000,
        fields: { [phone]: "9876543210" }, overwrite: { [phone]: sha(comparableValue("tel", "5550001111")) }, resume: undefined });
      assert.deepEqual(own.filled, [phone]);
      assert.equal(await tab.locator("#phone").inputValue(), "9876543210");
    });
    await t.test("with the Profile switches on, saved disclosures and required acknowledgements are filled and still never submitted", async () => {
      const saved = h.store.profile();
      h.store.set("profile", { ...saved, answers: { ...saved.answers, eeo_gender: "Female" },
        preferences: { ...saved.preferences, fillVoluntaryDisclosures: true, acceptRequiredAcknowledgements: true } });
      try {
        await reset(); const current = await inspect();
        const on = await h.service.plan(current, { id: plan.recordId });
        const entry = (label: string) => item(on, current.snapshot.fields.find(field => field.label === label)!.key);
        assert.equal(entry("Gender").value, "Female");
        assert.deepEqual([entry("I agree to the privacy policy").source, entry("I agree to the privacy policy").value, entry("I agree to the privacy policy").review], ["acknowledgement", "true", true]);
        const granted = await h.service.grant(on.recordId, current, { planHash: on.planHash, include: ready(on) });
        const result = await fill(granted);
        assert.deepEqual(result.errors, []);
        assert.equal(await tab.locator("#gender").inputValue(), "Female");
        assert.equal(await tab.locator("input[type=checkbox]").isChecked(), true);
        assert.equal(await tab.evaluate("window.submissions"), 0, "Chairman never submits");
        await h.service.report(on.recordId, granted.id, result);
      } finally { h.store.set("profile", saved); }
    });
    await t.test("navigation binds the exact URL; conditional questions do not abort the rest", async () => {
      await reset();
      await tab.evaluate(() => history.pushState({}, "", "?step=2"));
      await assert.rejects(fill({ ...grant, id: randomUUID() }), /Navigation/);
      await reset(); const current = await inspect();
      await tab.locator("#country").evaluate(select => select.addEventListener("change", () =>
        document.querySelector("#why")!.closest(".field")!.insertAdjacentHTML("afterend", '<div class="field"><label for="visa">Visa details</label><input id="visa" required></div>')));
      const result = await fill({ ...grant, id: randomUUID(), pageFingerprint: current.fingerprint, expiresAt: Date.now() + 90_000 });
      assert.equal(result.newFields, 1);
      assert.ok(result.filled.includes(byLabel("Why do you want to join?").key), "later questions are still filled");
      assert.ok(result.blockers.some(blocker => /new question/.test(blocker)));
      assert.equal(await tab.locator("#visa").inputValue(), "");
    });
    await t.test("visible credential forms and no-AI text stop inspection; listings and bare forms never invent a JD", async () => {
      await reset(); await tab.evaluate(() => document.querySelector("form#application-form")!.insertAdjacentHTML("beforeend", '<label>Password<input type="password" value="PRIVATE_NEVER_READ"></label>'));
      await assert.rejects(inspect(), /credential/);
      await reset(); await tab.evaluate(() => document.querySelector("form#application-form")!.insertAdjacentHTML("beforeend", "<p>Do not use AI in this application.</p>"));
      await assert.rejects(inspect(), /restricts AI/);
      await reset(); await tab.evaluate(() => { document.querySelector('script[type="application/ld+json"]')!.remove(); document.querySelector("main > p")!.remove(); });
      const bare = await inspect();
      assert.equal(bare.job, undefined); assert.equal(bare.kind, "form");
      assert.throws(() => h.service.import(bare), /No actual job/);
      const barePlan = await h.service.plan(bare);
      assert.ok(barePlan.items.length > 0, "a bare application form can still be filled");
    });
    await t.test("an embedded ATS form is offered as its own page instead of being filled blind", async () => {
      html = `<!doctype html><html><body><h1>Careers</h1><iframe src="https://boards.greenhouse.io/embed/job_app?for=fictional&token=4012345" style="width:600px;height:600px"></iframe></body></html>`;
      await reset();
      const embedded = await inspect();
      assert.equal(embedded.snapshot.fields.length, 0);
      assert.deepEqual(embedded.embedded, { url: "https://boards.greenhouse.io/embed/job_app?for=fictional&token=4012345", host: "boards.greenhouse.io" });
      html = realisticForm(DESCRIPTION);
    });

    await t.test("a page left open across an extension reload stops watching quietly instead of throwing", async () => {
      const content = await build({ entryPoints: [resolve("apps/extension/assist-content.ts")], bundle: true, write: false, format: "iife", platform: "browser", target: "chrome120" });
      const page = await context.newPage(), errors: string[] = [];
      page.on("pageerror", error => errors.push(error.message));
      await page.route("**/*", route => route.request().url().startsWith(url) ? route.fulfill({ contentType: "text/html", body: html }) : route.abort());
      // A string, not a function: the test compiler's helpers do not exist in the page.
      await page.addInitScript(`globalThis.__sent = [];
        Object.defineProperty(globalThis, "chrome", { configurable: true, writable: true,
          value: { runtime: { id: "fixture-extension", onMessage: { addListener: () => undefined }, sendMessage: async message => { globalThis.__sent.push(message); } } } });`);
      try {
        await page.goto(url);
        await page.addScriptTag({ content: content.outputFiles[0].text });
        await page.evaluate(() => document.querySelector("form#application-form")!.insertAdjacentHTML("beforeend", '<label>New question<input id="late"></label>'));
        await page.waitForFunction(() => (globalThis as unknown as { __sent: unknown[] }).__sent.length === 1, undefined, { timeout: 3000 });
        // Chrome removes the runtime from a script whose extension was reloaded.
        await page.evaluate(() => { (globalThis as unknown as { chrome: { runtime?: unknown } }).chrome.runtime = undefined; });
        for (let n = 0; n < 3; n++) {
          await page.evaluate(index => document.querySelector("form#application-form")!.insertAdjacentHTML("beforeend", `<label>More ${index}<input id="more-${index}"></label>`), n);
          await page.waitForTimeout(900);
        }
        assert.deepEqual(errors, [], "no \"Cannot read properties of undefined (reading 'sendMessage')\" or context-invalidated errors");
        assert.equal(await page.evaluate(() => (globalThis as unknown as { __sent: unknown[] }).__sent.length), 1);
      } finally { await page.close(); }
    });
    await t.test("worker plans on request, never calls the service on passive scans, and fills only after confirmation", async () => {
      const w = await harness();
      const compiled = await build({ entryPoints: [resolve("apps/extension/assist-worker.ts")], bundle: true, write: false, format: "iife", globalName: "ChairmanWorker", platform: "browser", target: "chrome120" });
      type Listener = (message: unknown, sender: object, respond: (value: unknown) => void) => unknown;
      const listeners: Listener[] = [];
      let injections = 0, pageFills = 0, permission = false;
      let active = { id: 5, url, status: "complete", active: true };
      let snapshot = pageFixture();
      const calls: string[] = [], session: Record<string, unknown> = {}, local: Record<string, unknown> = {};
      const storage = (data: Record<string, unknown>) => ({
        get: async (key: string) => ({ [key]: data[key] }),
        set: async (values: Record<string, unknown>) => { Object.assign(data, values); },
        remove: async (key: string) => { delete data[key]; }
      });
      const sandbox = createContext({
        URL, setTimeout, clearTimeout, Date,
        chrome: {
          runtime: { id: "fixture-extension", getURL: (path: string) => `chrome-extension://fixture-extension/${path}`, onMessage: { addListener: (callback: Listener) => { listeners.push(callback); } } },
          tabs: { query: async () => [active], create: async () => {}, update: async () => {}, onActivated: { addListener: () => {} }, onUpdated: { addListener: () => {} },
            sendMessage: async (_tabId: number, request: { action: string; grant?: AssistanceGrant }, target: { documentId: string }) => {
              assert.equal(target.documentId, "top-document");
              if (request.action === "fill") { pageFills++; return { ok: true, result: { filled: Object.keys(request.grant!.fields), preserved: [], skipped: [], errors: [], newFields: 0, blockers: [], selected: {} } }; }
              return { ok: true, result: snapshot };
            } },
          storage: { session: storage(session), local: storage(local) },
          permissions: { contains: async (query: { permissions?: string[] }) => query.permissions ? false : permission, onRemoved: { addListener: () => {} }, onAdded: { addListener: () => {} } },
          scripting: { executeScript: async () => { injections++; return [{ frameId: 0, documentId: "top-document" }]; } },
          action: { setBadgeText: async () => {}, setBadgeBackgroundColor: async () => {}, onClicked: { addListener: () => {} } },
          sidePanel: { open: async () => {} },
          notifications: { create: async () => {} }
        },
        api: async (path: string, body: Record<string, unknown>) => {
          calls.push(path);
          const id = body.id as string, page = body.page as AssistancePage;
          if (path.endsWith("/plan")) return w.service.plan(page, { id, ai: body.ai as boolean });
          if (path.endsWith("/grant")) return w.service.grant(id, page, body as never);
          if (path.endsWith("/report")) return w.service.report(id, body.grantId as string, body as never);
          throw new Error(`Unexpected ${path}`);
        }
      });
      try {
        runInContext(`${compiled.outputFiles[0].text}; ChairmanWorker.installAssistanceWorker(api, async () => "http://127.0.0.1:47821");`, sandbox);
        const panel = listeners[1];
        assert.ok(panel);
        let outsider = false;
        assert.equal(panel({ channel: "chairman:panel", action: "fill", confirm: true }, { id: "fixture-extension", tab: { id: 5 }, url }, () => { outsider = true; }), undefined);
        assert.equal(outsider, false, "page contexts cannot command the worker");
        type Reply = { ok: boolean; error?: string; state: { plan?: AssistPlan; page?: AssistancePage; debug: { runs: { action: string; failedAt?: string; steps: { step: string; source: string }[] }[] } } };
        const send = (action: string, extra: object = {}) => new Promise<Reply>(done =>
          panel({ channel: "chairman:panel", action, ...extra }, { id: "fixture-extension", url: "chrome-extension://fixture-extension/sidepanel.html" }, value => done(value as Reply)));
        assert.equal((await send("authorize", { url })).ok, false);
        assert.equal(injections, 0, "denied permissions never inject");
        permission = true;
        const visible = active;
        active = { ...active, url: undefined as unknown as string };
        const hidden = await send("scan");
        assert.equal(hidden.ok, false);
        assert.match(hidden.error!, /can't see this tab yet/, "a site Chrome hides from Chairman gets an actionable message");
        assert.equal(hidden.state.debug.runs[0].failedAt, "tab");
        active = visible;
        assert.equal((await send("authorize", { url })).ok, true);
        assert.equal(calls.length, 0, "scanning never sends page data to the service");
        const planned = await send("plan", { ai: false });
        assert.equal(planned.ok, true, planned.error);
        const plan = planned.state.plan!;
        assert.equal(pageFills, 0);
        assert.equal((await send("fill", { confirm: false, planHash: plan.planHash, include: ready(plan) })).ok, false);
        active = { ...active, url: `${url}?step=2` }; snapshot = rehash({ ...pageFixture(), url: active.url, snapshot: { ...pageFixture().snapshot, url: active.url } });
        const moved = await send("fill", { confirm: true, planHash: plan.planHash, include: ready(plan) });
        assert.equal(moved.ok, false);
        assert.equal(moved.state.debug.runs[0].failedAt, "compare-page", "the failed step is named");
        assert.match(moved.error!, /the URL changed/, "and the page difference is explained");
        assert.equal(calls.some(path => path.endsWith("/grant")), false, "navigation stops before any authorization");
        active = { ...active, url }; snapshot = pageFixture();
        const replanned = (await send("plan", { ai: false })).state.plan!;
        const filled = await send("fill", { confirm: true, planHash: replanned.planHash, include: ready(replanned), resume: replanned.resume?.selected ?? null });
        assert.equal(filled.ok, true, filled.error);
        assert.equal(pageFills, 1);
        assert.deepEqual(calls.filter(path => /grant|report/.test(path)).map(path => path.split("/").pop()), ["grant", "report"]);
        const fillRun = filled.state.debug.runs.find(entry => entry.action === "fill")!;
        assert.equal(fillRun.failedAt, undefined);
        for (const name of ["tab", "inject", "page-rescan", "compare-page", "service-grant", "page-fill", "service-report"])
          assert.ok(fillRun.steps.some(entry => entry.step === name && entry.source === "worker"), `worker stage ${name}`);
        assert.ok(fillRun.steps.some(entry => entry.source === "service" && entry.step === "plan-check"), "service steps are merged into the run");
        assert.equal(w.store.confirmedCount(), 0);
        assert.ok(!calls.some(path => /submit/.test(path)));
        const before = calls.length;
        const quick = await send("quick-fill", { ai: false });
        assert.equal(quick.ok, true, quick.error);
        assert.equal(pageFills, 2, "one click plans and fills the page");
        assert.deepEqual(calls.slice(before).map(path => path.split("/").pop()), ["plan", "grant", "report", "plan"], "plan, grant, fill, report, then re-plan");
        assert.match((quick.state as { message?: string }).message ?? "", /^Filled \d+ answers? in one pass\..* click Submit yourself\.$/);
        assert.ok(quick.state.debug.runs[0]!.steps.some(entry => entry.step === "quick-fill"));
        assert.equal(w.store.confirmedCount(), 0, "one-click fill never submits");
      } finally { await w.close(); }
    });
  } finally { await context.close(); await browser.close(); await h.close(); }
});
