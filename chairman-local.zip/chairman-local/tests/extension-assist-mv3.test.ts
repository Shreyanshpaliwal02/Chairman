/// <reference types="chrome" />
import test from "node:test";
import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { createServer } from "node:net";
import { mkdir, readFile, rm, writeFile, copyFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { build } from "esbuild";
import { chromium, type BrowserContext } from "playwright";
import { createApp } from "../apps/local/server.js";
import { createDocuments } from "../packages/documents/index.js";
import { emptyProfile, type Profile } from "../packages/domain/types.js";
import type { AssistState } from "../apps/extension/assist-worker.js";
import type { AssistanceRecord } from "../packages/domain/extension-assist.js";
import { jobFixture } from "./fixtures.js";

test("actual loaded MV3 worker pairs, sends exact Origin through root auth, plans and fills only the localhost fixture", async () => {
  const directory = resolve(`tests/.extension-mv3-${randomUUID()}`), extension = join(directory, "extension");
  await mkdir(extension, { recursive: true, mode: 0o700 });
  const reservation = createServer();
  await new Promise<void>(resolve => reservation.listen(0, "127.0.0.1", resolve));
  const address = reservation.address(); assert.ok(address && typeof address !== "string");
  const port = address.port;
  await new Promise<void>((resolve, reject) => reservation.close(error => error ? reject(error) : resolve()));
  const runtime = await createApp({ dataDir: join(directory, "data"), port, fixtureMode: true });
  let context: BrowserContext | undefined;
  try {
    const profile: Profile = { ...emptyProfile(), name: "Jordan Fixture", email: "jordan@fictional.invalid", phone: "+1 202-555-0108",
      location: "India", confirmed: true, skills: ["Python", "SQL", "AWS"],
      facts: [
        { id: "experience", category: "experience", text: "Built Python and SQL data pipelines on AWS with production monitoring.", employer: "Fictional Labs", role: "Data Engineer", dates: "2023 - Present", confirmed: true },
        { id: "education", category: "education", text: "Completed a computer science degree.", employer: "Fictional Institute", role: "Bachelor of Science", dates: "2018 - 2022", confirmed: true }
      ] };
    runtime.store.set("profile", profile);
    const artifacts = await createDocuments(profile, jobFixture(), { mode: "deterministic", factIds: profile.facts.map(fact => fact.id), skills: profile.skills, notes: [] }, join(directory, "base"));
    const base = artifacts.find(artifact => artifact.format === "docx")!;
    const bytes = await readFile(join(directory, "base", base.filename));
    await runtime.library.upload(1, "fictional-data.docx", bytes, "Data fixture", ["data"], true);
    await runtime.library.upload(2, "fictional-software.docx", bytes, "Software fixture", ["software"], true);
    const origins: { path: string; origin?: string }[] = [];
    runtime.app.addHook("onRequest", async request => {
      if (request.url.startsWith("/api/extension/assist/")) origins.push({ path: request.url, origin: request.headers.origin });
    });
    await runtime.app.listen({ host: "127.0.0.1", port });
    const host = `127.0.0.1:${port}`;
    const session = await runtime.app.inject({ url: "/api/session", headers: { host } });
    const cookie = String(session.headers["set-cookie"]).split(";")[0];
    const pairing = await runtime.app.inject({ method: "POST", url: "/api/extension/pair", headers: { host, cookie }, payload: {} });
    assert.equal(pairing.statusCode, 200);
    const token: string = pairing.json().token;
    const manifest = JSON.parse(await readFile(resolve("apps/extension/manifest.json"), "utf8")) as Record<string, unknown>;
    // Test-only pregrant removes native permission-dialog automation; production stays optional-host.
    manifest.host_permissions = ["http://127.0.0.1/*"];
    manifest.permissions = [...manifest.permissions as string[], "notifications"];
    manifest.optional_permissions = [];
    await writeFile(join(extension, "manifest.json"), JSON.stringify(manifest));
    await build({ entryPoints: ["apps/extension/service-worker.ts", "apps/extension/sidepanel.ts", "apps/extension/assist-panel.ts"],
      outdir: extension, bundle: true, format: "esm", platform: "browser", target: "chrome120" });
    await build({ entryPoints: ["apps/extension/content.ts", "apps/extension/assist-content.ts"],
      outdir: extension, bundle: true, format: "iife", platform: "browser", target: "chrome120" });
    for (const file of ["sidepanel.html", "sidepanel.css"]) await copyFile(resolve("apps/extension", file), join(extension, file));
    await writeFile(join(extension, "icon.png"), Buffer.from((await readFile(resolve("apps/extension/notification-icon.base64"), "utf8")).trim(), "base64"));
    context = await chromium.launchPersistentContext(join(directory, "chrome"), {
      channel: "chrome", headless: true, args: ["--enable-unsafe-extension-debugging"], ignoreDefaultArgs: ["--disable-extensions"]
    });
    const cdp = await context.browser()!.newBrowserCDPSession();
    const loaded = await cdp.send("Extensions.loadUnpacked", { path: extension });
    const extensionOrigin = `chrome-extension://${loaded.id}`;
    const control = await context.newPage();
    await control.goto(`${extensionOrigin}/sidepanel.html`);
    await control.evaluate(() => {
      const button = document.createElement("button");
      button.id = "test-open-native-panel"; button.textContent = "Open native Chairman panel";
      button.onclick = async () => { await chrome.sidePanel.open({ windowId: (await chrome.windows.getCurrent()).id! }); };
      document.body.append(button);
    });
    const previousTargets = new Set((await cdp.send("Target.getTargets")).targetInfos.map(target => target.targetId));
    await control.locator("#test-open-native-panel").click();
    let panelId: string | undefined;
    for (let attempt = 0; attempt < 50 && !panelId; attempt++) {
      panelId = (await cdp.send("Target.getTargets")).targetInfos.find(target =>
        target.url === `${extensionOrigin}/sidepanel.html` && !previousTargets.has(target.targetId))?.targetId;
      if (!panelId) await new Promise(resolve => setTimeout(resolve, 100));
    }
    assert.ok(panelId, "Chrome opened its real side panel, not an ordinary extension tab");
    const attached = await cdp.send("Target.attachToTarget", { targetId: panelId, flatten: false });
    let commandId = 0;
    async function evaluatePanel<T>(expression: string): Promise<T> {
      const id = ++commandId;
      return new Promise<T>((resolve, reject) => {
        const timer = setTimeout(() => { cdp.off("Target.receivedMessageFromTarget", received); reject(new Error("Native side panel did not respond.")); }, 30_000);
        const received = (event: { sessionId: string; message: string }) => {
          if (event.sessionId !== attached.sessionId) return;
          const message = JSON.parse(event.message) as { id?: number; error?: { message: string }; result?: { exceptionDetails?: { text: string }; result?: { value: T } } };
          if (message.id !== id) return;
          clearTimeout(timer); cdp.off("Target.receivedMessageFromTarget", received);
          if (message.error || message.result?.exceptionDetails) reject(new Error(message.error?.message ?? message.result?.exceptionDetails?.text));
          else resolve(message.result!.result!.value);
        };
        cdp.on("Target.receivedMessageFromTarget", received);
        void cdp.send("Target.sendMessageToTarget", { sessionId: attached.sessionId,
          message: JSON.stringify({ id, method: "Runtime.evaluate", params: { expression, awaitPromise: true, returnByValue: true } })
        }).catch(error => { clearTimeout(timer); cdp.off("Target.receivedMessageFromTarget", received); reject(error); });
      });
    }
    const paired = await evaluatePanel<{ ok: boolean; error?: string }>(
      `chrome.runtime.sendMessage(${JSON.stringify({ channel: "jaa:panel", action: "pair", token, port })})`);
    assert.equal(paired.ok, true, paired.error);
    const fixtureUrl = `${runtime.origin}/fixture/application`, fixture = await context.newPage();
    const description = "Responsibilities include building Python and SQL data pipelines on AWS, monitoring reliable engineering systems and optimizing performance. Full-time Data Engineer based in India.";
    await fixture.route(fixtureUrl, route => route.fulfill({ contentType: "text/html", body: `<!doctype html><html><head>
      <script type="application/ld+json">${JSON.stringify({ "@type": "JobPosting", title: "Data Engineer", hiringOrganization: { name: "Fictional Employer" }, description })}</script>
      </head><body><h1>Data Engineer</h1><form><label>Full name<input id="name" required></label>
      <label>Email<input id="email" type="email" required></label><label>Resume<input id="resume" type="file" accept=".pdf" required></label>
      <button type="submit">Submit application</button></form><script>window.submissions=0;document.querySelector("form").onsubmit=e=>{e.preventDefault();window.submissions++}</script></body></html>` }));
    await fixture.goto(fixtureUrl);
    await fixture.bringToFront();
    async function send(action: string, extra: Record<string, unknown> = {}): Promise<{ ok: boolean; error?: string; state: AssistState }> {
      return evaluatePanel(`chrome.runtime.sendMessage(${JSON.stringify({ channel: "chairman:panel", action, ...extra })})`);
    }
    const authorized = await send("authorize", { url: fixtureUrl });
    assert.equal(authorized.ok, true, authorized.error);
    assert.equal(authorized.state.page?.job?.title, "Data Engineer");
    assert.equal(origins.length, 0, "authorized DOM scanning does not call the local API");
    const imported = await send("import", { confirm: true });
    assert.equal(imported.ok, true, imported.error);
    const prepared = await send("prepare", { confirm: true, mode: "deterministic" });
    assert.equal(prepared.ok, true, prepared.error);
    const packet = prepared.state.review?.packet; assert.ok(packet);
    const planned = await send("plan", { ai: false });
    assert.equal(planned.ok, true, planned.error);
    const plan = planned.state.plan; assert.ok(plan);
    assert.equal(plan.resume?.selected, `packet:${packet.id}:pdf`, "the prepared job-specific resume is the default attachment");
    const include = plan.items.filter(item => item.include && item.value !== undefined).map(item => item.key);
    assert.equal(include.length, 2);
    assert.equal(await fixture.locator("#email").inputValue(), "");
    const worker = context.serviceWorkers().find(item => item.url() === `${extensionOrigin}/service-worker.js`)!;
    await worker.evaluate(`(() => {
      const create = chrome.notifications.create.bind(chrome.notifications);
      globalThis.chairmanTestNotices = [];
      chrome.notifications.create = async (id, options) => {
        const record = { id, title: options.title, message: options.message };
        globalThis.chairmanTestNotices.push(record);
        try { record.result = await create(id, options); return record.result; }
        catch (error) { record.error = error.message; throw error; }
      };
    })()`);
    const unreviewed = await send("fill", { confirm: false, planHash: plan.planHash, include, resume: plan.resume!.selected });
    assert.equal(unreviewed.ok, false);
    let alerts: { id: string; message: string; result?: string; error?: string }[] = [];
    for (let attempt = 0; attempt < 20 && !alerts[0]?.result; attempt++) {
      alerts = await worker.evaluate("globalThis.chairmanTestNotices");
      if (!alerts[0]?.result) await new Promise(resolve => setTimeout(resolve, 50));
    }
    assert.equal(alerts[0]?.result, "chairman-attention", `the actual Chrome notification API accepted the intervention alert: ${JSON.stringify({ alerts, error: unreviewed.error, allowed: await worker.evaluate(() => chrome.permissions.contains({ permissions: ["notifications"] })) })}`);
    assert.equal(alerts[0].message.includes(profile.email), false);
    assert.equal(alerts[0].message.includes("Fictional Employer"), false);
    const filled = await send("fill", { confirm: true, planHash: plan.planHash, include, resume: plan.resume!.selected });
    assert.equal(filled.ok, true, filled.error);
    assert.equal(filled.state.result?.filled, 3);
    assert.equal(await fixture.locator("#name").inputValue(), profile.name);
    assert.equal(await fixture.locator("#email").inputValue(), profile.email);
    const upload = await fixture.locator("#resume").evaluate(async element => Array.from(new Uint8Array(await (element as HTMLInputElement).files![0].arrayBuffer())));
    assert.equal(createHash("sha256").update(Buffer.from(upload)).digest("hex"), packet.artifacts.find(artifact => artifact.format === "pdf")!.sha256);
    assert.equal(await fixture.evaluate("window.submissions"), 0);
    const records = await runtime.app.inject({ url: "/api/assistance", headers: { host, cookie } });
    const record = (records.json().items as AssistanceRecord[])[0];
    assert.equal(record.status, "filled");
    assert.equal(record.packetId, packet.id);
    assert.equal(runtime.store.confirmedCount(), 0);
    for (const path of ["import", "prepare", "plan", "grant", "report"]) assert.ok(origins.some(item => item.path.endsWith(`/${path}`)), path);
    assert.ok(origins.every(item => item.origin === extensionOrigin), "actual Chrome worker supplied paired exact Origin on every assist request");
    const wrongOrigin = await runtime.app.inject({ method: "POST", url: "/api/extension/assist/import",
      headers: { host, authorization: `Bearer ${token}`, origin: runtime.origin }, payload: {} });
    assert.equal(wrongOrigin.statusCode, 403);
  } finally {
    await context?.close();
    await runtime.app.close();
    await rm(directory, { recursive: true, force: true });
  }
});
