import test from "node:test";
import assert from "node:assert/strict";
import { candidateYears, defaultLevels, experienceFit, jobFit, locationFit, requiredYears, sponsorshipOf, titleSeniority, type FitPolicy } from "../packages/domain/job-fit.js";
import { classifyJob, DEFAULT_ROLE_FAMILIES } from "../packages/domain/role-families.js";
import { profileFixture, jobFixture } from "./fixtures.js";

const at = (location: string, extra: Partial<Parameters<typeof locationFit>[0]> = {}) =>
  locationFit({ location, remote: /remote/i.test(location), description: "", sponsorship: "unknown", ...extra });

test("location tiers: India first, global remote allowed, region-locked remote never, offices abroad with sponsorship", () => {
  for (const place of ["Bengaluru", "Bangalore, Karnataka, India", "India - Hyderabad", "Gurugram", "Pune, MH, India", "Remote - India"])
    assert.match(at(place).tier, /^(?:india|remote_india)$/, place);
  for (const place of ["Remote", "Remote - Global", "Remote (Worldwide)", "Anywhere", "Remote, Global", "Remote - Anywhere"]) assert.equal(at(place).tier, "remote_global", place);
  for (const place of ["Remote - US", "US Remote", "Remote, United States", "California - Remote", "Remote (EU)", "Remote - EMEA", "Remote - UK", "Remote - Canada",
    "Remote, USA", "Dublin, County Dublin, Ireland (Remote)", "Remote - San Francisco, CA", "Remote - Americas"]) assert.equal(at(place).tier, "remote_restricted", place);
  assert.equal(at("Remote - APAC").tier, "remote_apac");
  assert.equal(at("San Francisco, CA").tier, "abroad");
  assert.equal(at("London, United Kingdom").tier, "abroad");
  assert.equal(at("Bengaluru; San Francisco, CA").tier, "india", "any Indian location counts");
  assert.equal(at("Bengaluru - India; Remote - Remote").tier, "india", "a Remote entry is one location, not the workplace type of the others");
  assert.equal(at("Hybrid or Remote").tier, "remote_global", "workplace words alone are not a place abroad");
  assert.equal(at("Remote", { description: "This role is fully remote. Candidates must be located in the United States." }).tier, "remote_restricted", "the description can restrict a remote role");
  assert.equal(at("Remote", { description: "Join us from anywhere; we sponsor visas for relocation if needed." }).tier, "remote_global", "the word \"us\" is not the United States");
  assert.equal(at("Remote", { description: "Open to candidates based in India or Singapore." }).tier, "remote_global");
});

test("visa sponsorship is read from the posting, with your company note only as a fallback", () => {
  const job = (description: string) => ({ description, sponsorship: "unknown" as const });
  for (const text of ["We do sponsor visas! However, we aren't able to sponsor every role.", "Visa sponsorship is available for this position.", "We offer visa sponsorship.",
    "Relocation and visa support is provided.", "Visa sponsorship: Yes"]) assert.equal(sponsorshipOf(job(text)), "available", text);
  for (const text of ["We are unable to sponsor visas for this role.", "This position is not eligible for visa sponsorship.", "Applicants must be authorized to work in the US without sponsorship.",
    "No visa sponsorship is available.", "We cannot provide sponsorship.", "Visa sponsorship: No"]) assert.equal(sponsorshipOf(job(text)), "not_available", text);
  assert.equal(sponsorshipOf(job("Great team.")), "unknown");
  assert.equal(sponsorshipOf(job("Great team."), true), "available");
  assert.equal(sponsorshipOf(job("We cannot provide sponsorship."), true), "not_available", "the posting wins over your note");
  assert.equal(at("Seattle, WA", { description: "Visa sponsorship is available." }).label, "Seattle, WA · visa sponsorship stated");
});

test("seniority, required years and your experience", () => {
  assert.equal(titleSeniority("Senior Data Engineer"), "senior");
  assert.equal(titleSeniority("Staff Software Engineer, Platform"), "staff");
  assert.equal(titleSeniority("Principal Engineer"), "principal");
  assert.equal(titleSeniority("Software Engineer III, Infrastructure"), "mid");
  assert.equal(titleSeniority("Software Engineer II"), "mid");
  assert.equal(titleSeniority("Software Engineer I"), "entry");
  assert.equal(titleSeniority("Associate Software Engineer"), "entry");
  assert.equal(titleSeniority("Engineering Manager, Data"), "manager");
  assert.equal(titleSeniority("Site Reliability Manager"), "manager");
  assert.equal(titleSeniority("Data Engineering Intern"), "intern");
  assert.equal(titleSeniority("Data Engineer"), undefined);
  assert.deepEqual(requiredYears("Requirements:\n- 5+ years of experience building data pipelines\n- 2+ years with Spark"), { min: 5, text: "5+ years of experience" });
  assert.equal(requiredYears("You have 3-5 years of professional experience.").max, 5);
  assert.equal(requiredYears("Minimum of 4 years in software development").min, 4);
  assert.equal(requiredYears("Preferred qualifications\n- 8+ years of experience\nMinimum qualifications\n- 3 years of experience with Python").min, 3, "preferred sections are skipped");
  assert.equal(requiredYears("Founded in 2015, we serve 20 countries.").min, undefined);
  assert.deepEqual(requiredYears("Minimum Qualifications\n5-8yrs of machine learning expertise.\nStrong programming using Python."), { min: 5, max: 8, text: "5-8yrs of machine learning expertise" }, "Apple's phrasing");
  const profile = profileFixture();
  profile.answers = {};
  profile.facts = [
    { id: "a", category: "experience", text: "Built pipelines", employer: "A", role: "Data Engineer", dates: "Jan 2019 - Dec 2021", confirmed: true },
    { id: "b", category: "experience", text: "Platform work", employer: "B", role: "Senior Data Engineer", dates: "Jan 2022 - Present", confirmed: true },
    { id: "c", category: "experience", text: "Summer internship", employer: "C", role: "Intern", dates: "2018 - 2018", confirmed: true },
  ];
  assert.equal(candidateYears(profile, new Date("2026-01-01T00:00:00Z")), 7);
  profile.answers.total_years_experience = "4";
  assert.equal(candidateYears(profile), 4, "your saved answer wins");
  assert.deepEqual(defaultLevels(4), ["mid", "senior"]);
  assert.equal(experienceFit({ title: "Staff Engineer", description: "" }, 4, ["mid", "senior"]).excluded, "The title is staff level; you target mid, senior.");
  assert.equal(experienceFit({ title: "Data Engineer", description: "8+ years of experience" }, 4, ["mid", "senior"]).fit, "under");
  assert.equal(experienceFit({ title: "Data Engineer", description: "5+ years of experience" }, 4, ["mid", "senior"]).fit, "stretch");
  assert.equal(experienceFit({ title: "Senior Data Engineer", description: "3+ years of experience" }, 4, ["mid", "senior"]).fit, "match");
});

test("jobFit keeps relevant roles, explains exclusions and ranks sponsored abroad, India and global remote above unknown sponsorship", () => {
  const profile = profileFixture();
  profile.answers = { ...profile.answers, total_years_experience: "5" };
  const policy: FitPolicy = { priority: "abroad-first", includeIndia: true, includeRemoteGlobal: true, includeAbroadSponsored: true, includeAbroadUnknown: true,
    years: 5, levels: ["mid", "senior"], maxAgeDays: 60 };
  const now = Date.parse("2026-09-27T00:00:00Z");
  const description = "Build data pipelines with Python, SQL, Spark, Kafka and Airflow on AWS. 4+ years of experience.";
  const make = (location: string, extra = "") => jobFixture({ id: location, title: "Senior Data Engineer", location, description: `${description} ${extra}`, postedAt: "2026-09-25T00:00:00Z", employmentType: "Full-time" });
  const fit = (job: ReturnType<typeof make>) => jobFit(job, profile, classifyJob(job, DEFAULT_ROLE_FAMILIES, new Set(["data-engineering"])), policy, undefined, now);
  const sponsored = fit(make("Seattle, WA", "Visa sponsorship is available.")), india = fit(make("Bengaluru, India")), remote = fit(make("Remote - Global"));
  const unknown = fit(make("London, United Kingdom")), noVisa = fit(make("Austin, TX", "We are unable to sponsor visas.")), usRemote = fit(make("Remote - US"));
  for (const item of [sponsored, india, remote, unknown]) assert.equal(item.eligible, true, item.excluded);
  assert.ok(sponsored.score > india.score, "sponsored roles abroad come first by default");
  assert.equal(india.score, remote.score, "India and global remote rank together");
  assert.ok(india.score > unknown.score, "roles abroad without sponsorship info come last");
  assert.deepEqual([noVisa.eligible, noVisa.excludedKind], [false, "no_sponsorship"]);
  assert.deepEqual([usRemote.eligible, usRemote.excludedKind], [false, "remote_restricted"]);
  assert.match(india.reasons.join(" "), /Data Engineering match: .*spark/i);
  const indiaFirst = jobFit(make("Bengaluru, India"), profile, classifyJob(make("Bengaluru, India"), DEFAULT_ROLE_FAMILIES, new Set()), { ...policy, priority: "india-first" }, undefined, now);
  const abroadLast = jobFit(make("Seattle, WA", "Visa sponsorship is available."), profile, classifyJob(make("Seattle, WA"), DEFAULT_ROLE_FAMILIES, new Set()), { ...policy, priority: "india-first" }, undefined, now);
  assert.ok(indiaFirst.score > abroadLast.score);
  const cleared = make("Herndon, VA", "Active TS/SCI clearance required.");
  assert.deepEqual([fit(cleared).eligible, fit(cleared).excluded], [false, "Requires a U.S. security clearance or citizenship."]);
  const sales = jobFixture({ title: "Account Executive", description: "Sell." });
  assert.equal(jobFit(sales, profile, classifyJob(sales, DEFAULT_ROLE_FAMILIES), policy).excludedKind, "role");
  const old = { ...make("Bengaluru"), postedAt: "2026-01-01T00:00:00Z" };
  assert.equal(jobFit(old, profile, classifyJob(old, DEFAULT_ROLE_FAMILIES), policy, undefined, now).excludedKind, "stale");
  assert.equal(jobFit(make("London, UK"), profile, classifyJob(make("London, UK"), DEFAULT_ROLE_FAMILIES), { ...policy, includeAbroadUnknown: false }, undefined, now).excludedKind, "settings");
});
