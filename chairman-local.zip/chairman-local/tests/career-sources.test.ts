import test from "node:test";
import assert from "node:assert/strict";
import { Store } from "../apps/local/store.js";
import { CareerSourceService } from "../apps/local/career-sources.js";
import { DiscoveryError } from "../packages/adapters/discovery.js";
import { digest, jobHash } from "../packages/domain/matching.js";
import { jobFixture } from "./fixtures.js";
import type { CareerBoardTarget, CareerLinkResolution, Job } from "../packages/domain/types.js";

const target: CareerBoardTarget = { provider: "ashby", board: "example", boardUrl: "https://jobs.ashbyhq.com/example" };
const resolution: CareerLinkResolution = { target, candidates: [target], message: "Supported board." };
const applicationUrl = "https://jobs.ashbyhq.com/example/12345678-1234-1234-1234-123456789abc/application";
function listing(sourceId: string): Job {
  return jobFixture({ id: "ashby:example:12345678-1234-1234-1234-123456789abc", sourceId, sourceJobId: "12345678-1234-1234-1234-123456789abc",
    company: "Example", applyUrl: applicationUrl, canonicalUrl: applicationUrl });
}
async function waitForScan(service: CareerSourceService, id: string) {
  for (let n = 0; n < 100; n++) {
    const source = service.get(id);
    if (source.lastScannedAt || source.status === "error") return;
    await new Promise(resolve => setTimeout(resolve, 5));
  }
  throw new Error("Synthetic career scan did not complete.");
}
test("added career source persists imported jobs, deduplicates repeats and does not grant application authorization", async () => {
  const store = new Store(":memory:");
  let requests = 0;
  const service = new CareerSourceService(store, { resolve: async () => resolution, scan: async (_target, id) => {
    requests++; return { jobs: [listing(id)] };
  } });
  try {
    const { source } = await service.add(target.boardUrl, "My preferred employer");
    assert.ok(source);
    await waitForScan(service, source.id);
    assert.equal(service.get(source.id).jobCount, 1);
    assert.equal(store.jobs().length, 1);
    assert.deepEqual(store.jobs()[0]!.careerSourceIds, [source.id]);
    assert.equal(service.allowsJob(store.jobs()[0]!), true);
    assert.equal(store.value("autopilot", { enabled: false }).enabled, false);
    assert.equal((await service.add(target.boardUrl)).source!.id, source.id);
    assert.equal(requests, 1);
    assert.throws(() => service.requestScan(source.id), /cooldown/);
    const beforeScope = digest(service.scope());
    service.setEnabled(source.id, false);
    assert.notEqual(digest(service.scope()), beforeScope);
    assert.equal(service.allowsJob(store.jobs()[0]!), false);
    service.remove(source.id);
    assert.equal(service.list().length, 0);
    assert.equal(store.jobs().length, 1);
    assert.equal(service.allowsJob(store.jobs()[0]!), false);
  } finally { await service.close(); store.close(); }
});
test("ambiguous or unsupported links require a choice and create no enabled source", async () => {
  const store = new Store(":memory:");
  const service = new CareerSourceService(store, { resolve: async () => ({ candidates: [target, { ...target, board: "second" }], message: "Choose a board." }) });
  try {
    const result = await service.add("https://example.com/careers");
    assert.equal(result.source, undefined);
    assert.equal(result.resolution.candidates.length, 2);
    assert.equal(service.list().length, 0);
  } finally { await service.close(); store.close(); }
});
test("career scan failure preserves cursor, surfaces error and honors Retry-After", async () => {
  const store = new Store(":memory:");
  const start = Date.now();
  const service = new CareerSourceService(store, { resolve: async () => resolution, scan: async () => {
    throw new DiscoveryError("RATE_LIMITED", "Provider requested a pause.", 7200000, 429);
  } });
  try {
    const { source } = await service.add(target.boardUrl);
    await waitForScan(service, source!.id);
    const saved = service.get(source!.id);
    assert.equal(saved.status, "error");
    assert.match(saved.message, /pause/);
    assert.ok(Date.parse(saved.nextScanAt!) >= start + 7200000);
    assert.equal(store.value(`career-cursor:${source!.id}`, null), null);
    assert.equal(store.jobs().length, 0);
  } finally { await service.close(); store.close(); }
});
test("adding a second discovery path preserves trusted employer identity and material job hash", () => {
  const store = new Store(":memory:");
  try {
    const original = listing("supabase"); original.company = "Hewlett Packard Enterprise";
    store.saveJob(original);
    const custom = { ...original, id: "career-copy", sourceId: "career-source", company: "Friendly label", careerSourceIds: ["career-source"] };
    const merged = store.saveJob(custom);
    assert.equal(merged.id, original.id);
    assert.equal(merged.company, original.company);
    assert.equal(merged.sourceId, original.sourceId);
    assert.equal(jobHash(merged), jobHash(original));
    assert.deepEqual(merged.careerSourceIds, ["career-source"]);
    assert.equal(store.jobs().length, 1);
  } finally { store.close(); }
});

test("a removed source cannot commit a late scan or rewrite its checkpoint", async () => {
  const store = new Store(":memory:");
  let release: (() => void) | undefined;
  const gate = new Promise<void>(resolve => { release = resolve; });
  const service = new CareerSourceService(store, { resolve: async () => resolution, scan: async (_target, sourceId) => {
    await gate; return { jobs: [listing(sourceId)], nextCursor: "next" };
  } });
  try {
    const { source } = await service.add(target.boardUrl);
    service.remove(source!.id);
    release!();
    await service.close();
    assert.equal(store.jobCount(), 0);
    assert.equal(store.value(`career-cursor:${source!.id}`, null), null);
  } finally { release?.(); await service.close(); store.close(); }
});

test("source ID mismatches fail visibly instead of bypassing custom-source controls", async () => {
  const store = new Store(":memory:");
  const service = new CareerSourceService(store, { resolve: async () => resolution, scan: async () => ({ jobs: [listing("supabase")] }) });
  try {
    const { source } = await service.add(target.boardUrl);
    await waitForScan(service, source!.id);
    assert.equal(service.get(source!.id).status, "error");
    assert.match(service.get(source!.id).message, /outside its registered source/);
    assert.equal(store.jobCount(), 0);
  } finally { await service.close(); store.close(); }
});
