/// <reference types="chrome" />
import test from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { createServer } from "node:net";
import { createServer as createHttps } from "node:https";
import { execFileSync } from "node:child_process";
import { copyFile, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { build } from "esbuild";
import { chromium, type BrowserContext, type Page } from "playwright";
import { createApp } from "../apps/local/server.js";
import { createDocuments } from "../packages/documents/index.js";
import { emptyProfile, type Job, type Profile } from "../packages/domain/types.js";
import { localDate } from "../packages/domain/dates.js";
import type { AssistState } from "../apps/extension/assist-worker.js";
import type { ShortlistView } from "../apps/local/shortlist.js";
import type { AssistanceRecord } from "../packages/domain/extension-assist.js";
import { jobFixture } from "./fixtures.js";

/** A Workday-like multi-step application: button dropdowns, a radio group, a resume step, a review step with Submit, then a confirmation. */
function workdayFixture(company: string, onsite = false): string {
  return `<!doctype html><html><head><title>Apply · ${company}</title></head><body>
<div data-automation-id="applyFlowPage">
  <ol id="progress"><li data-step="1">My Information</li><li data-step="2">My Experience</li><li data-step="3">Review</li></ol>
  <div id="step"></div><div id="footer"></div>
</div>
<script>
const state = { step: 1, answers: {}, submissions: 0, nextPresses: 0, resume: "" };
window.appState = state;
const field = (id, label, required, control) => '<div data-automation-id="formField-' + id + '"><label for="' + id + '">' + label + (required ? '<abbr title="required">*</abbr>' : '') + '</label>' + control + '</div>';
function render() {
  document.querySelectorAll('#progress li').forEach(li => { if (Number(li.dataset.step) === state.step) li.setAttribute('data-automation-id', 'progressBarActiveStep'); else li.removeAttribute('data-automation-id'); });
  const step = document.getElementById('step'), footer = document.getElementById('footer');
  if (state.step === 1) {
    step.innerHTML = '<h2>My Information</h2>'
      + field('source', 'How Did You Hear About Us?', true, '<button type="button" id="source" aria-haspopup="listbox" aria-expanded="false">Select One</button><ul role="listbox" id="source-list" hidden><li role="option">Job Board</li><li role="option">Company Careers Website</li><li role="option">Employee Referral</li></ul>')
      + '<fieldset><legend>Have you previously worked for ${company}?<abbr title="required">*</abbr></legend><label><input type="radio" name="previous" value="yes" required> Yes</label><label><input type="radio" name="previous" value="no"> No</label></fieldset>'
      + field('given', 'Given Name(s)', true, '<input id="given" type="text" required>')
      + field('family', 'Family Name', true, '<input id="family" type="text" required>')
      + field('city', 'City', true, '<input id="city" type="text" required>')
      + ${onsite ? `field('onsite', 'Are you open to working in-person in one of our offices?', true, '<select id="onsite" required><option value="">Select One</option><option value="yes">Yes</option><option value="no">No</option></select>')` : "''"}
      + field('extension', 'Phone Extension', false, '<input id="extension" type="text">');
    const button = document.getElementById('source'), list = document.getElementById('source-list');
    button.onclick = () => { list.hidden = !list.hidden; button.setAttribute('aria-expanded', String(!list.hidden)); };
    list.querySelectorAll('[role=option]').forEach(option => option.onclick = () => { button.textContent = option.textContent; state.answers.source = option.textContent; list.hidden = true; });
  } else if (state.step === 2) {
    step.innerHTML = '<h2>My Experience</h2>' + field('resume', 'Resume/CV', true, '<input id="resume" type="file" accept=".pdf,.docx" required>')
      + field('why', 'Why do you want to join ${company}?', false, '<textarea id="why"></textarea>');
    document.getElementById('resume').onchange = event => { state.resume = event.target.files[0] ? event.target.files[0].name : ''; };
  } else if (state.step === 3) {
    step.innerHTML = '<h2>Review</h2><p>After your application is submitted, we will email you.</p><dl><dt>Name</dt><dd>' + (state.answers.given || '') + ' ' + (state.answers.family || '') + '</dd></dl>';
  } else step.innerHTML = '<h2>Thank you for applying</h2><p>Your application has been received.</p>';
  footer.innerHTML = state.step > 3 ? '' : (state.step > 1 ? '<button type="button" data-automation-id="bottom-navigation-back-button">Back</button>' : '')
    + '<button type="button" data-automation-id="bottom-navigation-next-button">' + (state.step === 3 ? 'Submit' : 'Save and Continue') + '</button><div id="errors"></div>';
  const next = footer.querySelector('[data-automation-id="bottom-navigation-next-button"]');
  if (next) next.onclick = advance;
}
function advance() {
  const errors = [];
  if (state.step === 1) {
    for (const id of ['given', 'family', 'city', 'onsite']) { const input = document.getElementById(id); if (!input) continue; const value = input.value.trim(); if (!value) errors.push(id + ' is required'); state.answers[id] = value; }
    if (!state.answers.source) errors.push('How Did You Hear About Us? is required');
    const previous = document.querySelector('input[name=previous]:checked');
    if (!previous) errors.push('Previous employment is required'); else state.answers.previous = previous.value;
  }
  if (state.step === 2 && !state.resume) errors.push('Resume is required');
  if (errors.length) { document.getElementById('errors').innerHTML = errors.map(error => '<div role="alert">' + error + '</div>').join(''); return; }
  if (state.step === 3) state.submissions++; else state.nextPresses++;
  state.step++;
  render();
}
render();
</script></body></html>`;
}

/**
 * Workday's own flow after "Autofill with Resume": optionally a sign-in page, the resume upload (a hidden input behind a
 * drop zone that the site clears and redraws with the file listed), then My Information, My Experience (the same file
 * listed under Resume/CV), Application Questions, Voluntary Disclosures and Review with Submit.
 */
function workdayApplyFixture(company: string, signIn: boolean): string {
  return `<!doctype html><html><head><title>Apply · ${company}</title></head><body>
<header data-automation-id="header"><a href="/en-US/External">Careers</a></header>
<div data-automation-id="applyFlowPage">
  <ol id="progress"><li data-step="1">Autofill with Resume</li><li data-step="2">My Information</li><li data-step="3">My Experience</li><li data-step="4">Application Questions</li><li data-step="5">Voluntary Disclosures</li><li data-step="6">Review</li></ol>
  <div id="step"></div><div id="footer"></div>
</div>
<script>
const state = { step: ${signIn ? 0 : 1}, answers: {}, submissions: 0, nextPresses: 0, resume: "", uploads: 0 };
window.appState = state;
const field = (id, label, required, control) => '<div data-automation-id="formField-' + id + '"><label for="' + id + '">' + label + (required ? '<abbr title="required">*</abbr>' : '') + '</label>' + control + '</div>';
const zone = '<div data-automation-id="file-upload-drop-zone"><div><p>Drop file here</p><p>or</p></div><button type="button" data-automation-id="select-files">Select file</button>'
  + '<input type="file" data-automation-id="file-upload-input-ref" tabindex="-1" style="display:none" accept=".doc,.docx,.html,.pdf,.txt"></div>';
const listed = () => state.resume ? '<div data-automation-id="file-upload-successful"><div data-automation-id="file-upload-item-name">' + state.resume + '</div><p>Successfully Uploaded!</p></div>' : '';
function render() {
  document.querySelectorAll('#progress li').forEach(li => { if (Number(li.dataset.step) === state.step) li.setAttribute('data-automation-id', 'progressBarActiveStep'); else li.removeAttribute('data-automation-id'); });
  const step = document.getElementById('step'), footer = document.getElementById('footer');
  if (state.step === 0) {
    step.innerHTML = '<h2>Sign In</h2>' + field('email', 'Email Address', true, '<input id="email" type="email">') + field('password', 'Password', true, '<input id="password" type="password">');
    footer.innerHTML = '<button type="button" id="signin">Sign In</button>';
    footer.querySelector('#signin').onclick = () => { if (document.getElementById('password').value) { state.step = 1; render(); } };
    return;
  }
  if (state.step === 1) step.innerHTML = '<h2>Autofill with Resume</h2><div data-automation-id="uploadSection"><p>Upload your resume here to autofill key application fields.</p>' + listed() + zone
    + '<p>Upload either DOC, DOCX, HTML, PDF, or TXT file types (5MB max)</p></div>';
  else if (state.step === 2) {
    step.innerHTML = '<h2>My Information</h2>'
      + field('source', 'How Did You Hear About Us?', true, '<button type="button" id="source" aria-haspopup="listbox" aria-expanded="false">Select One</button><ul role="listbox" id="source-list" hidden><li role="option">Job Board</li><li role="option">Company Careers Website</li><li role="option">Employee Referral</li></ul>')
      + '<fieldset><legend>Have you previously worked for ${company}?<abbr title="required">*</abbr></legend><label><input type="radio" name="previous" value="yes"> Yes</label><label><input type="radio" name="previous" value="no"> No</label></fieldset>'
      + field('given', 'Given Name(s)', true, '<input id="given" type="text">') + field('family', 'Family Name', true, '<input id="family" type="text">') + field('city', 'City', true, '<input id="city" type="text">');
    const button = document.getElementById('source'), list = document.getElementById('source-list');
    button.onclick = () => { list.hidden = !list.hidden; button.setAttribute('aria-expanded', String(!list.hidden)); };
    list.querySelectorAll('[role=option]').forEach(option => option.onclick = () => { button.textContent = option.textContent; state.answers.source = option.textContent; list.hidden = true; });
  } else if (state.step === 3) step.innerHTML = '<h2>My Experience</h2><div role="group" aria-labelledby="work"><h3 id="work">Work Experience</h3><button type="button">Add</button></div>'
    + '<div role="group" aria-labelledby="attachments"><h3 id="attachments">Resume/CV</h3><div data-automation-id="formField-attachments"><label>Upload a file (5MB max)<abbr title="required">*</abbr></label>' + listed() + zone + '</div></div>';
  else if (state.step === 4) step.innerHTML = '<h2>Application Questions</h2>'
    + field('authorized', 'Are you legally authorized to work in India?', true, '<select id="authorized"><option value="">Select One</option><option value="yes">Yes</option><option value="no">No</option></select>');
  else if (state.step === 5) step.innerHTML = '<h2>Voluntary Disclosures</h2>'
    + field('gender', 'Gender', false, '<select id="gender"><option value="">Select One</option><option>Male</option><option>Female</option><option>I do not wish to answer</option></select>');
  else if (state.step === 6) step.innerHTML = '<h2>Review</h2><dl><dt>Name</dt><dd>' + (state.answers.given || '') + ' ' + (state.answers.family || '') + '</dd><dt>Resume</dt><dd>' + state.resume + '</dd></dl>';
  else step.innerHTML = '<h2>Thank you for applying</h2><p>Your application has been received.</p>';
  const input = step.querySelector('[data-automation-id="file-upload-input-ref"]');
  // Workday takes the file, clears its input and redraws the widget with the file listed.
  if (input) input.onchange = event => { const file = event.target.files[0]; if (!file) return; state.uploads++; state.resume = file.name; render(); };
  footer.innerHTML = state.step > 6 ? '' : (state.step > 1 ? '<button type="button" data-automation-id="bottom-navigation-back-button">Back</button>' : '')
    + '<button type="button" data-automation-id="bottom-navigation-next-button">' + (state.step === 1 ? 'Continue' : state.step === 6 ? 'Submit' : 'Save and Continue') + '</button><div id="errors"></div>';
  const next = footer.querySelector('[data-automation-id="bottom-navigation-next-button"]');
  if (next) next.onclick = advance;
}
function advance() {
  const errors = [];
  if ((state.step === 1 || state.step === 3) && !state.resume) errors.push('Upload a file (5MB max) is required');
  if (state.step === 2) {
    for (const id of ['given', 'family', 'city']) { const value = document.getElementById(id).value.trim(); if (!value) errors.push(id + ' is required'); state.answers[id] = value; }
    if (!state.answers.source) errors.push('How Did You Hear About Us? is required');
    const previous = document.querySelector('input[name=previous]:checked');
    if (!previous) errors.push('Previous employment is required'); else state.answers.previous = previous.value;
  }
  if (state.step === 4) { state.answers.authorized = document.getElementById('authorized').value; if (!state.answers.authorized) errors.push('Work authorization is required'); }
  if (state.step === 5) state.answers.gender = document.getElementById('gender').value;
  if (errors.length) { document.getElementById('errors').innerHTML = errors.map(error => '<div role="alert">' + error + '</div>').join(''); return; }
  if (state.step === 6) state.submissions++; else state.nextPresses++;
  state.step++;
  render();
}
render();
</script></body></html>`;
}
/** A Workday job page: its job description (JobPosting) and the Apply button. */
function workdayJobPage(title: string, url: string): string {
  const description = `${title}: build and operate Python and SQL data pipelines on AWS with monitoring and data quality checks. Full-time role in Hyderabad, India.`;
  return `<!doctype html><html><head><title>${title}</title><script type="application/ld+json">${JSON.stringify({ "@type": "JobPosting", title, hiringOrganization: { name: "Fictional" }, description })}</script></head>
<body><header data-automation-id="header"><a href="/en-US/External">Careers</a><button type="button">Sign In</button></header>
<main><h2 data-automation-id="jobPostingHeader">${title}</h2><div data-automation-id="jobPostingDescription"><p>${description}</p></div>
<a role="button" data-automation-id="adventureButton" href="${url}/apply">Apply</a></main></body></html>`;
}

type Runtime = Awaited<ReturnType<typeof createApp>>;
type PanelReply = { ok: boolean; error?: string; state: AssistState };
interface Harness {
  runtime: Runtime; context: BrowserContext; dashboard: { host: string; cookie: string }; port: number; extensionId: string;
  send: (action: string, extra?: Record<string, unknown>) => Promise<PanelReply>;
  trace: () => Promise<string>;
  windowId: number;
}
/**
 * The service, the unpacked extension (paired, with its real side panel open) in Chrome, and the employers' sites on a
 * local HTTPS server that Chrome reaches for exactly `hosts`. Every other hostname fails to resolve, so nothing in these
 * tests can reach the network.
 */
async function withExtension(options: { hosts: string[]; site: (url: URL) => string; seed: (runtime: Runtime, directory: string) => Promise<void> },
  work: (harness: Harness) => Promise<void>): Promise<void> {
  const directory = resolve(`tests/.extension-session-${randomUUID()}`), extension = join(directory, "extension");
  await mkdir(extension, { recursive: true, mode: 0o700 });
  const reservation = createServer();
  await new Promise<void>(done => reservation.listen(0, "127.0.0.1", done));
  const address = reservation.address(); assert.ok(address && typeof address !== "string");
  const port = address.port;
  await new Promise<void>((done, reject) => reservation.close(error => error ? reject(error) : done()));
  const runtime = await createApp({ dataDir: join(directory, "data"), port, fixtureMode: true });
  let context: BrowserContext | undefined;
  const cleanups: (() => Promise<void>)[] = [];
  try {
    await options.seed(runtime, directory);
    await runtime.app.listen({ host: "127.0.0.1", port });
    const host = `127.0.0.1:${port}`;
    const cookie = String((await runtime.app.inject({ url: "/api/session", headers: { host } })).headers["set-cookie"]).split(";")[0];
    const dashboard = { host, cookie };
    const token: string = (await runtime.app.inject({ method: "POST", url: "/api/extension/pair", headers: dashboard, payload: {} })).json().token;

    const manifest = JSON.parse(await readFile(resolve("apps/extension/manifest.json"), "utf8")) as Record<string, unknown>;
    manifest.host_permissions = ["http://127.0.0.1/*", ...options.hosts.map(name => `https://${name}/*`)];
    manifest.optional_permissions = [];
    await writeFile(join(extension, "manifest.json"), JSON.stringify(manifest));
    await build({ entryPoints: ["apps/extension/service-worker.ts", "apps/extension/sidepanel.ts", "apps/extension/assist-panel.ts"], outdir: extension, bundle: true, format: "esm", platform: "browser", target: "chrome120" });
    await build({ entryPoints: ["apps/extension/content.ts", "apps/extension/assist-content.ts"], outdir: extension, bundle: true, format: "iife", platform: "browser", target: "chrome120" });
    for (const file of ["sidepanel.html", "sidepanel.css"]) await copyFile(resolve("apps/extension", file), join(extension, file));
    await writeFile(join(extension, "icon.png"), Buffer.from((await readFile(resolve("apps/extension/notification-icon.base64"), "utf8")).trim(), "base64"));

    execFileSync("openssl", ["req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", join(directory, "key.pem"), "-out", join(directory, "cert.pem"), "-days", "1", "-subj", "/CN=fixture"], { stdio: "ignore" });
    const sites = createHttps({ key: await readFile(join(directory, "key.pem")), cert: await readFile(join(directory, "cert.pem")) }, (request, response) => {
      response.setHeader("content-type", "text/html");
      response.end(options.site(new URL(request.url ?? "/", `https://${request.headers.host}`)));
    });
    await new Promise<void>(done => sites.listen(0, "127.0.0.1", done));
    const sitesPort = (sites.address() as { port: number }).port;
    cleanups.push(() => new Promise<void>(done => sites.close(() => done())));
    context = await chromium.launchPersistentContext(join(directory, "chrome"), { channel: "chrome", headless: true, ignoreHTTPSErrors: true, ignoreDefaultArgs: ["--disable-extensions"],
      args: ["--enable-unsafe-extension-debugging", "--ignore-certificate-errors",
        `--host-resolver-rules=${options.hosts.map(name => `MAP ${name} 127.0.0.1:${sitesPort}`).join(",")},MAP * ~NOTFOUND,EXCLUDE 127.0.0.1`] });
    const cdp = await context.browser()!.newBrowserCDPSession();
    const loaded = await cdp.send("Extensions.loadUnpacked", { path: extension });
    // The panel's actions are accepted only from Chrome's real side panel, so open it and talk to it over CDP.
    const origin = `chrome-extension://${loaded.id}`, control = await context.newPage();
    await control.goto(`${origin}/sidepanel.html`);
    await control.evaluate(() => {
      const button = document.createElement("button");
      button.id = "open-panel"; button.textContent = "Open";
      button.onclick = async () => { await chrome.sidePanel.open({ windowId: (await chrome.windows.getCurrent()).id! }); };
      document.body.append(button);
    });
    const before = new Set((await cdp.send("Target.getTargets")).targetInfos.map(target => target.targetId));
    await control.locator("#open-panel").click();
    let panelId: string | undefined;
    for (let attempt = 0; attempt < 50 && !panelId; attempt++) {
      panelId = (await cdp.send("Target.getTargets")).targetInfos.find(target => target.url === `${origin}/sidepanel.html` && !before.has(target.targetId))?.targetId;
      if (!panelId) await new Promise(done => setTimeout(done, 100));
    }
    assert.ok(panelId, "Chrome opened its side panel");
    const attached = await cdp.send("Target.attachToTarget", { targetId: panelId, flatten: false });
    let commandId = 0;
    const evaluatePanel = <T>(expression: string): Promise<T> => {
      const id = ++commandId;
      return new Promise<T>((done, reject) => {
        const timer = setTimeout(() => { cdp.off("Target.receivedMessageFromTarget", received); reject(new Error("The side panel did not respond.")); }, 60_000);
        const received = (event: { sessionId: string; message: string }) => {
          if (event.sessionId !== attached.sessionId) return;
          const message = JSON.parse(event.message) as { id?: number; error?: { message: string }; result?: { exceptionDetails?: { text: string }; result?: { value: T } } };
          if (message.id !== id) return;
          clearTimeout(timer); cdp.off("Target.receivedMessageFromTarget", received);
          if (message.error || message.result?.exceptionDetails) reject(new Error(message.error?.message ?? message.result?.exceptionDetails?.text));
          else done(message.result!.result!.value);
        };
        cdp.on("Target.receivedMessageFromTarget", received);
        void cdp.send("Target.sendMessageToTarget", { sessionId: attached.sessionId,
          message: JSON.stringify({ id, method: "Runtime.evaluate", params: { expression, awaitPromise: true, returnByValue: true } }) }).catch(reject);
      });
    };
    const pairing = await evaluatePanel<{ ok: boolean; error?: string }>(`chrome.runtime.sendMessage(${JSON.stringify({ channel: "jaa:panel", action: "pair", token, port })})`);
    assert.equal(pairing.ok, true, pairing.error);
    const send = (action: string, extra: Record<string, unknown> = {}) =>
      evaluatePanel<PanelReply>(`chrome.runtime.sendMessage(${JSON.stringify({ channel: "chairman:panel", action, ...extra })})`);
    const browserContext = context;
    const trace = async () => {
      const { state } = await send("state");
      return `Tabs: ${browserContext.pages().map(page => page.url()).join(" | ")}\nSession: ${JSON.stringify(state.session?.tabs)}\nTab: ${JSON.stringify(state.tab)} ${state.message ?? ""}\n` + state.debug.runs.map(run =>
        `${run.action}${run.failedAt ? ` FAILED at ${run.failedAt}: ${run.error}` : ""}\n  ${run.steps.map(item => `${item.ok === false ? "✗ " : ""}${item.source}:${item.step} ${item.detail ?? ""}`).join("\n  ")}`).join("\n");
    };
    const windowId = await evaluatePanel<number>("chrome.windows.getCurrent().then(window => window.id)");
    await work({ runtime, context, dashboard, port, extensionId: loaded.id, send, trace, windowId });
  } finally {
    await context?.close();
    for (const cleanup of cleanups) await cleanup();
    await runtime.app.close();
    await rm(directory, { recursive: true, force: true });
  }
}

test("a session opens today's roles in separate Chrome tabs, fills every step to Review, never submits, and records your submission from the confirmation page", { timeout: 240_000 }, async () => {
  const posting = "https://careers.fictional-employer.test/jobs/data-engineer";
  const workday = "https://fictional.wd5.myworkdayjobs.com/en-US/External/job/Bengaluru/Cloud-Engineer_R200";
  let first!: Job, second!: Job;
  const site = (url: URL) => url.hostname === "fictional.wd5.myworkdayjobs.com" ? workdayFixture("Fictional Cloud Co", true)
    : url.pathname.endsWith("/apply") ? workdayFixture("Fictional Employer")
      : `<!doctype html><html><head>
      <script type="application/ld+json">${JSON.stringify({ "@type": "JobPosting", title: "Data Engineer", hiringOrganization: { name: "Fictional Employer" }, description: "Build Python and SQL data pipelines on AWS. Full-time role in Bengaluru, India." })}</script>
      </head><body><header><a href="/careers">Careers home</a></header><main><h1>Data Engineer</h1><p>Build Python and SQL data pipelines on AWS.</p><a href="${posting}/apply">Apply</a></main></body></html>`;
  await withExtension({ hosts: ["careers.fictional-employer.test", "fictional.wd5.myworkdayjobs.com"], site, seed: async (runtime, directory) => {
    const profile: Profile = { ...emptyProfile(), name: "Jordan Fixture", email: "jordan@fictional.invalid", phone: "+91 98765 43210", location: "Bengaluru, Karnataka",
      confirmed: true, skills: ["Python", "SQL", "AWS"],
      facts: [{ id: "experience", category: "experience", text: "Built Python and SQL data pipelines on AWS with production monitoring.", employer: "Fictional Labs", role: "Data Engineer", dates: "2023 - Present", confirmed: true }] };
    runtime.store.set("profile", profile);
    const artifacts = await createDocuments(profile, jobFixture(), { mode: "deterministic", factIds: ["experience"], skills: profile.skills, notes: [] }, join(directory, "base"));
    const base = artifacts.find(artifact => artifact.format === "docx")!;
    await runtime.library.upload(1, "fictional-data.docx", await readFile(join(directory, "base", base.filename)), "Data fixture", ["data"], true);

    // Today's list: a role on a company careers site (its posting links to the application) and one on a Workday site.
    first = runtime.store.saveJob(jobFixture({ id: "career-session-a", sourceId: "career-11111111-1111-1111-1111-111111111111", company: "Fictional Employer", title: "Data Engineer",
      location: "Bengaluru, India", countries: ["India"], applyUrl: posting, canonicalUrl: posting }));
    second = runtime.store.saveJob(jobFixture({ id: "career-session-b", sourceId: "career-11111111-1111-1111-1111-111111111111", company: "Fictional Cloud Co", title: "Cloud Engineer",
      location: "Bengaluru, India", countries: ["India"], applyUrl: workday, canonicalUrl: workday }));
    const entry = (jobId: string, rank: number) => ({ jobId, rank, score: 90, tier: "india", label: "Bengaluru, India", sponsorship: "unknown", experience: "fits", skills: [], reasons: [], carriedOver: false });
    runtime.store.db.prepare("INSERT INTO shortlists VALUES (?,?)").run(localDate(), JSON.stringify({ date: localDate(), generatedAt: new Date().toISOString(), candidates: 2, excluded: {}, levels: ["mid"],
      entries: [entry(first.id, 1), entry(second.id, 2)] }));
  } }, async ({ runtime, context, dashboard, send, trace, windowId }) => {
    const started = await send("session-start", { windowId });
    assert.equal(started.ok, true, started.error);
    assert.equal(started.state.session?.size, 2);

    // The worker drives both tabs on its own: Apply on the posting (A), then each step, until the step with Submit.
    let reached: AssistState["session"] | undefined;
    const stages = () => Object.fromEntries((reached?.tabs ?? []).map(tab => [tab.jobId, tab]));
    const waitFor = async (done: () => boolean, what: string) => {
      for (let attempt = 0; attempt < 150 && !done(); attempt++) {
        await new Promise(resolveWait => setTimeout(resolveWait, 1000));
        reached = (await send("state")).state.session;
      }
      assert.ok(done(), `${what}\n${await trace()}`);
    };
    // A reaches Review; B waits for you on a question Chairman has no answer for, while A carries on.
    await waitFor(() => stages()[first.id]?.stage === "review" && stages()[second.id]?.stage === "needs_you", "A should reach Review while B waits for your answer");
    assert.match(stages()[second.id]!.message, /Are you open to working in-person in one of our offices/);
    const tabFor = (prefix: string) => context.pages().find(page => page.url().startsWith(prefix))!;
    const formA = tabFor(`${posting}/apply`), formB = tabFor(`${workday}/apply/autofillWithResume`);
    // You answer on the page, as you would; B continues on its own and Chairman remembers the answer for the next form.
    await formB.selectOption("#onsite", "yes");
    await waitFor(() => stages()[second.id]?.stage === "review", "B should continue to Review after you answered");
    const remembered = (await runtime.app.inject({ url: "/api/assist-answers", headers: dashboard })).json() as { items: { question: string; value: string }[] };
    assert.ok(remembered.items.some(item => item.question === "Are you open to working in-person in one of our offices?" && item.value === "Yes"),
      `your answer is remembered for the next form: ${JSON.stringify(remembered.items)}`);
    assert.ok(formA && formB, "A was opened through its Apply link; B straight into Workday's resume autofill start");
    type App = { step: number; submissions: number; nextPresses: number; answers: Record<string, string>; resume: string };
    for (const form of [formA, formB]) {
      const app = await form.evaluate(() => (window as unknown as { appState: App }).appState);
      assert.equal(app.step, 3, "stopped on the Review step");
      assert.equal(app.submissions, 0, "Chairman never presses Submit");
      assert.equal(app.nextPresses, 2, "each step's Save and Continue was pressed exactly once");
      assert.deepEqual({ given: app.answers.given, family: app.answers.family, city: app.answers.city, source: app.answers.source, previous: app.answers.previous },
        { given: "Jordan", family: "Fixture", city: "Bengaluru", source: "Company Careers Website", previous: "no" }, "answers from the profile, derived values and the work history");
      assert.match(app.resume, /\.docx$/, "the role's resume was attached");
    }
    let today = (await runtime.app.inject({ url: "/api/shortlist", headers: dashboard })).json() as ShortlistView;
    const status = (jobId: string) => today.entries.find(item => item.jobId === jobId)!;
    assert.deepEqual([status(first.id).status, status(second.id).status], ["review", "review"], "Today shows both as ready for your review, not applied");

    // You submit A: its confirmation page is the proof, recorded against A only.
    await formA.locator('[data-automation-id="bottom-navigation-next-button"]').click();
    for (let attempt = 0; attempt < 40 && status(first.id).status !== "applied"; attempt++) {
      await new Promise(done => setTimeout(done, 500));
      today = (await runtime.app.inject({ url: "/api/shortlist", headers: dashboard })).json() as ShortlistView;
    }
    assert.equal(status(first.id).status, "applied", await trace());
    assert.equal(status(first.id).evidence?.kind, "confirmation_page");
    assert.match(status(first.id).evidence!.detail, /Thank you for applying/);
    assert.equal(status(second.id).status, "review", "the other tab's application is untouched");
    // Closing B without submitting finishes the session; B is not counted as applied.
    await formB.close();
    let current = { session: { status: "", finished: 0, counts: {} as Record<string, number> } };
    for (let attempt = 0; attempt < 20 && current.session.status !== "complete"; attempt++) {
      await new Promise(done => setTimeout(done, 500));
      current = (await runtime.app.inject({ url: "/api/apply-sessions/current", headers: dashboard })).json();
    }
    assert.deepEqual([current.session.status, current.session.finished, current.session.counts.submitted, current.session.counts.closed], ["complete", 2, 1, 1]);
    today = (await runtime.app.inject({ url: "/api/shortlist", headers: dashboard })).json() as ShortlistView;
    assert.notEqual(status(second.id).status, "applied");
  });
});

test("Fill everything on a Workday job you opened: starts with Autofill with Resume, waits for your sign-in, uploads this role's resume, continues every step to Review and never submits; the dashboard opens a role the same way", { timeout: 240_000 }, async () => {
  const data = "https://fictional.wd5.myworkdayjobs.com/en-US/External/job/India---Hyderabad/Sr-Data-Engineer_JR358536";
  const cloud = "https://fictional.wd5.myworkdayjobs.com/en-US/External/job/India---Pune/Cloud-Engineer_JR400100";
  let cloudJob!: Job;
  const site = (url: URL) => {
    const job = url.pathname.includes("JR358536") ? data : cloud;
    return url.pathname.includes("/apply") ? workdayApplyFixture("Fictional", job === data) : workdayJobPage(job === data ? "Sr Data Engineer" : "Cloud Engineer", job);
  };
  await withExtension({ hosts: ["fictional.wd5.myworkdayjobs.com"], site, seed: async (runtime, directory) => {
    // Work history includes a résumé-import mistake (a month read as the employer); it is never used as an answer.
    const profile: Profile = { ...emptyProfile(), name: "Jordan Fixture", email: "jordan@fictional.invalid", phone: "+91 98765 43210", location: "Hyderabad, Telangana",
      confirmed: true, skills: ["Python", "SQL", "AWS"], answers: { "Are you legally authorized to work in India?": "Yes", "How did you hear about us?": "Company Careers Website" },
      facts: [{ id: "experience", category: "experience", text: "Built Python and SQL data pipelines on AWS with production monitoring.", employer: "Northwind Labs", role: "Data Engineer", dates: "2023 - Present", confirmed: true },
        { id: "import-mistake", category: "experience", text: "Ran AWS data platforms for analytics teams.", employer: "Sept", role: "Data Engineer", dates: "2023 – Present", confirmed: true }] };
    runtime.store.set("profile", profile);
    const artifacts = await createDocuments(profile, jobFixture(), { mode: "deterministic", factIds: ["experience"], skills: profile.skills, notes: [] }, join(directory, "base"));
    const pdf = artifacts.find(artifact => artifact.format === "pdf")!, docx = artifacts.find(artifact => artifact.format === "docx")!;
    await runtime.library.upload(1, "fictional-cloud.pdf", await readFile(join(directory, "base", pdf.filename)), "Cloud fixture", ["cloud"], true);
    await runtime.library.upload(2, "fictional-data.docx", await readFile(join(directory, "base", docx.filename)), "Data fixture", ["data"], true);
    cloudJob = runtime.store.saveJob(jobFixture({ id: "workday-cloud", sourceId: "career-22222222-2222-2222-2222-222222222222", company: "Fictional", title: "Cloud Engineer",
      location: "Pune, India", countries: ["India"], applyUrl: cloud, canonicalUrl: cloud }));
  } }, async ({ runtime, context, port, extensionId, send, trace }) => {
    type App = { step: number; submissions: number; nextPresses: number; answers: Record<string, string>; resume: string; uploads: number };
    const app = (page: Page) => page.evaluate(() => (window as unknown as { appState?: App }).appState).catch(() => undefined);
    const until = async (check: () => Promise<boolean>, what: string, seconds = 120) => {
      for (let attempt = 0; attempt < seconds && !await check().catch(() => false); attempt++) await new Promise(done => setTimeout(done, 1000));
      assert.ok(await check().catch(() => false), `${what}\n${await trace()}`);
    };
    const stage = async () => (await send("state")).state.tab?.stage;
    const records = () => runtime.store.db.prepare("SELECT json FROM assistance_records").all().map(row => JSON.parse(String(row.json)) as AssistanceRecord);

    // You open the job yourself and press Fill everything ("Continue through every step" is on by default).
    const tab = await context.newPage();
    await tab.goto(data);
    await tab.bringToFront();
    const started = await send("quick-fill", { ai: false, drive: true });
    assert.equal(started.ok, true, started.error);
    // Chairman goes straight to Autofill with Resume; Workday asks you to sign in first, and Chairman waits for you.
    await until(async () => tab.url() === `${data}/apply/autofillWithResume` && await stage() === "needs_you", "Chairman should open Autofill with Resume and wait for your sign-in");
    assert.match((await send("state")).state.message ?? "", /Sign in/);
    await tab.fill("#email", "jordan@fictional.invalid");
    await tab.fill("#password", "fixture-password");
    await tab.click("#signin");
    // Once you are signed in it uploads the resume for this role and continues through every step to Review.
    await until(async () => (await app(tab))?.step === 6 && await stage() === "review", "Chairman should continue through every step to Review");
    const manual = (await app(tab))!;
    assert.equal(manual.submissions, 0, "Chairman never presses Submit");
    assert.equal(manual.nextPresses, 5, "Continue and each step's Save and Continue were pressed exactly once");
    assert.equal(manual.uploads, 1, "the resume was uploaded once; My Experience kept the file Workday listed");
    assert.equal(manual.resume, "fictional-data.docx", "the data resume for a data role, known from the job page");
    assert.deepEqual({ given: manual.answers.given, family: manual.answers.family, city: manual.answers.city, source: manual.answers.source, previous: manual.answers.previous,
      authorized: manual.answers.authorized, gender: manual.answers.gender },
    { given: "Jordan", family: "Fixture", city: "Hyderabad", source: "Company Careers Website", previous: "no", authorized: "yes", gender: "" },
    "profile, derived and saved answers; voluntary disclosures stay yours");
    assert.equal(records().find(record => record.title === "Sr Data Engineer")?.stage?.name, "review", "Today and Progress show it as ready for your review");
    // You submit: the confirmation page is the proof that you applied.
    await tab.locator('[data-automation-id="bottom-navigation-next-button"]').click();
    await until(async () => await stage() === "submitted", "the confirmation page should be recorded", 30);
    assert.equal(records().find(record => record.title === "Sr Data Engineer")?.status, "submitted_confirmed");

    // From the dashboard, "Fill in my Chrome" asks the extension to open the role in a tab it works through the same way.
    const dashboardPage = await context.newPage();
    await dashboardPage.goto(`http://127.0.0.1:${port}/api/session`);
    const opened = await dashboardPage.evaluate(([id, jobId]) => new Promise<{ ok?: boolean; error?: string }>(done =>
      (window as unknown as { chrome: { runtime: { sendMessage: (id: string, message: unknown, callback: (response: { ok?: boolean; error?: string }) => void) => void } } })
        .chrome.runtime.sendMessage(id!, { channel: "chairman:session", action: "open-job", jobId }, done)), [extensionId, cloudJob.id]);
    assert.equal(opened.ok, true, opened.error);
    let cloudTab: Page | undefined;
    await until(async () => !!(cloudTab = context.pages().find(page => page.url() === `${cloud}/apply/autofillWithResume`)), "the role should open straight into Autofill with Resume", 20);
    await until(async () => (await app(cloudTab!))?.step === 6, "the role opened from the dashboard should reach Review");
    const opening = (await app(cloudTab!))!;
    assert.equal(opening.submissions, 0);
    assert.equal(opening.resume, "fictional-cloud.pdf", "the cloud resume for a cloud role");
    await until(async () => records().find(record => record.jobId === cloudJob.id)?.stage?.name === "review", "its record shows it ready for your review", 20);
  });
});
