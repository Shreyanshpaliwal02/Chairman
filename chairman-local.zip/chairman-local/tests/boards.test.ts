import test from "node:test";
import assert from "node:assert/strict";
import { crawlBoard, parseBoardUrl } from "../packages/adapters/boards.js";
import { parseCareerTarget } from "../packages/adapters/career-links.js";
import { jobIdentity } from "../apps/local/store.js";
import type { CareerBoardTarget } from "../packages/domain/types.js";

const SOURCE = "career-11111111-1111-1111-1111-111111111111";
const UUID = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, "0")}`;
type Route = (url: URL, init?: RequestInit) => unknown;
function network(routes: Record<string, Route>) {
  const calls: { url: string; body?: unknown }[] = [];
  const fetcher = (async (input: string | URL, init?: RequestInit) => {
    const url = new URL(String(input));
    calls.push({ url: url.href, ...(init?.body ? { body: JSON.parse(String(init.body)) } : {}) });
    const key = Object.keys(routes).find(prefix => url.href.startsWith(prefix));
    if (!key) return new Response("not found", { status: 404 });
    const value = routes[key]!(url, init);
    if (value instanceof Response) return value;
    return new Response(typeof value === "string" ? value : JSON.stringify(value), { status: 200 });
  }) as typeof fetch;
  return { fetcher, calls };
}
const keepEngineers = (title: string) => /engineer/i.test(title);

test("board links of every supported kind parse to a crawlable target; other hosts do not", () => {
  assert.deepEqual(parseBoardUrl("https://jobs.lever.co/palantir"), { provider: "lever", board: "palantir", boardUrl: "https://jobs.lever.co/palantir" });
  assert.equal(parseBoardUrl(`https://jobs.eu.lever.co/acme/${UUID(1)}/apply`)?.jobId, UUID(1));
  assert.deepEqual(parseBoardUrl("https://jobs.smartrecruiters.com/PHONEPELIMITED/1000000000001015-associate"), { provider: "smartrecruiters", board: "PHONEPELIMITED",
    boardUrl: "https://jobs.smartrecruiters.com/PHONEPELIMITED", jobId: "1000000000001015" });
  assert.deepEqual(parseBoardUrl("https://salesforce.wd12.myworkdayjobs.com/en-US/External_Career_Site/job/India---Hyderabad/Data-Engineer_JR1"),
    { provider: "workday", board: "salesforce.wd12.myworkdayjobs.com/salesforce/External_Career_Site", boardUrl: "https://salesforce.wd12.myworkdayjobs.com/External_Career_Site" });
  assert.equal(parseBoardUrl("https://morganstanley.eightfold.ai/careers?domain=morganstanley.com")?.board, "morganstanley.eightfold.ai|morganstanley.com");
  assert.equal(parseBoardUrl("https://jpmc.fa.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CX_1001/job/210790435")?.board, "jpmc.fa.oraclecloud.com|CX_1001");
  assert.equal(parseBoardUrl("https://ats.rippling.com/thoughtspot/jobs")?.provider, "rippling");
  assert.equal(parseBoardUrl("https://www.google.com/about/careers/applications/jobs/results/83336424635409094-software-engineer-iii")?.provider, "google");
  assert.equal(parseBoardUrl("https://www.atlassian.com/company/careers/details/25583")?.provider, "atlassian");
  assert.equal(parseBoardUrl("https://careers.nutanix.com/en/jobs/32751/global-account-manager/")?.provider, "nutanix");
  assert.equal(parseCareerTarget("https://job-boards.eu.greenhouse.io/groww")?.board, "groww", "EU Greenhouse boards are Greenhouse boards");
  assert.equal(parseCareerTarget("https://jobs.lever.co/cred")?.provider, "lever", "career-link resolution understands the new boards");
  for (const bad of ["https://evil.example/palantir", "http://jobs.lever.co/palantir", "https://jobs.lever.co:444/palantir", "https://user:pass@jobs.lever.co/palantir",
    "https://evil.myworkdayjobs.com.example/site", "https://jobs.smartrecruiters.com/oneclick-ui/company/x"]) assert.equal(parseBoardUrl(bad), undefined, bad);
  const lever = { applyUrl: `https://jobs.lever.co/acme/${UUID(2)}/apply`, canonicalUrl: `https://jobs.lever.co/acme/${UUID(2)}` };
  assert.equal(jobIdentity(lever as never), jobIdentity({ applyUrl: lever.canonicalUrl, canonicalUrl: lever.canonicalUrl } as never), "a posting and its apply page are one job");
  const workday = "https://acme.wd5.myworkdayjobs.com/careers/job/India---Bengaluru/Data-Engineer_JR123-1";
  assert.equal(jobIdentity({ applyUrl: `${workday}/apply/applyManually`, canonicalUrl: workday } as never), jobIdentity({ applyUrl: workday, canonicalUrl: workday } as never));
  assert.equal(jobIdentity({ applyUrl: "https://careers-apac-atlassian.icims.com/jobs/26569/principal-data-engineer/job?mode=apply", canonicalUrl: "https://www.atlassian.com/company/careers/details/26569" } as never),
    jobIdentity({ applyUrl: "https://www.atlassian.com/company/careers/details/26569", canonicalUrl: "https://www.atlassian.com/company/careers/details/26569" } as never));
});

test("Greenhouse, Ashby and Lever boards are read in one request each, keeping only roles you care about", async () => {
  const { fetcher, calls } = network({
    "https://boards-api.greenhouse.io/v1/boards/groww/jobs?content=true": () => ({ jobs: [
      { id: 11, internal_job_id: 5, title: "Senior Data Engineer", location: { name: "Bengaluru, India" }, absolute_url: "https://job-boards.eu.greenhouse.io/groww/jobs/11",
        content: "&lt;p&gt;Build &lt;strong&gt;Spark&lt;/strong&gt; pipelines.&lt;/p&gt;", first_published: "2026-09-20T10:00:00-04:00", company_name: "Groww",
        metadata: [{ name: "Employment Type", value: "Full-time" }], departments: [{ name: "Data" }] },
      { id: 12, internal_job_id: 6, title: "Account Manager", location: { name: "Mumbai" }, content: "Sell." },
      { id: 13, internal_job_id: null, title: "Engineer (prospects)", location: { name: "" }, content: "Talent pool." },
    ] }),
    "https://api.ashbyhq.com/posting-api/job-board/acme": () => ({ jobs: [
      { id: UUID(3), title: "ML Engineer", location: "Remote", secondaryLocations: [{ location: "London", address: { postalAddress: { addressCountry: "United Kingdom" } } }],
        isListed: true, isRemote: true, workplaceType: "Remote", employmentType: "FullTime", descriptionHtml: "<p>Train models.</p>", publishedAt: "2026-09-21T00:00:00Z",
        compensation: { summaryComponents: [{ compensationType: "Salary", minValue: 100, maxValue: 200, currencyCode: "USD", interval: "1 YEAR" }] } },
      { id: UUID(4), title: "Hidden Engineer", location: "Remote", isListed: false, descriptionHtml: "x" },
    ] }),
    "https://api.eu.lever.co/v0/postings/acme?mode=json": () => [{ id: UUID(5), text: "Cloud Engineer", categories: { location: "Berlin", allLocations: ["Berlin", "Remote - EU"], commitment: "Full-time", team: "Infra" },
      workplaceType: "hybrid", country: "DE", description: "<p>Run Kubernetes.</p>", lists: [{ text: "You bring", content: "<li>Terraform</li>" }], additional: "<p>Visa sponsorship is available.</p>", createdAt: 1790000000000 }],
  });
  const target = (raw: string) => (parseCareerTarget(raw) ?? parseBoardUrl(raw)) as CareerBoardTarget;
  const gh = await crawlBoard(target("https://job-boards.greenhouse.io/groww"), SOURCE, "Groww", { fetcher, keep: keepEngineers });
  assert.deepEqual([gh.listed, gh.kept, gh.jobs.length, gh.truncated], [3, 1, 1, false]);
  assert.deepEqual([gh.jobs[0]!.title, gh.jobs[0]!.applyUrl, gh.jobs[0]!.description, gh.jobs[0]!.countries, gh.jobs[0]!.employmentType, gh.jobs[0]!.department],
    ["Senior Data Engineer", "https://job-boards.eu.greenhouse.io/groww/jobs/11", "Build Spark pipelines.", ["India"], "Full-time", "Data"]);
  assert.equal(gh.jobs[0]!.id, "greenhouse:groww:11", "same id scheme as the page-by-page scanner");
  const ashby = await crawlBoard(target("https://jobs.ashbyhq.com/acme"), SOURCE, "Acme", { fetcher, keep: keepEngineers });
  assert.deepEqual([ashby.listed, ashby.jobs.length, ashby.jobs[0]!.applyUrl, ashby.jobs[0]!.workplaceType, ashby.jobs[0]!.remote, ashby.jobs[0]!.location],
    [1, 1, `https://jobs.ashbyhq.com/acme/${UUID(3)}/application`, "remote", true, "Remote; London"]);
  assert.deepEqual(ashby.jobs[0]!.salary, { min: 100, max: 200, currency: "USD", period: "annual", kind: "base" });
  const lever = await crawlBoard(target(`https://jobs.eu.lever.co/acme`), SOURCE, "Acme", { fetcher });
  assert.deepEqual([lever.jobs[0]!.location, lever.jobs[0]!.workplaceType, lever.jobs[0]!.applyUrl], ["Berlin; Remote - EU", "hybrid", `https://jobs.eu.lever.co/acme/${UUID(5)}/apply`]);
  assert.match(lever.jobs[0]!.description, /Run Kubernetes\.[\s\S]*You bring[\s\S]*Terraform[\s\S]*Visa sponsorship is available\./);
  assert.ok(lever.jobs[0]!.countries.includes("Germany"));
  assert.equal(calls.length, 3, "one request per bulk board");
});

test("SmartRecruiters and Workday fetch details only for kept roles; huge Workday boards are searched with your keywords", async () => {
  const summaries = Array.from({ length: 120 }, (_, n) => ({ id: String(7_000_000 + n), name: n % 40 === 0 ? `Data Engineer ${n}` : `Store Associate ${n}`, location: { city: "Pune", country: "in", remote: false },
    releasedDate: "2026-09-22T00:00:00Z", typeOfEmployment: { label: "Full-time" }, experienceLevel: { label: "Mid-Senior Level" } }));
  const workdayPostings = (offset: number, total: number) => ({ total: offset === 0 ? total : 0, jobPostings: Array.from({ length: Math.min(20, Math.max(0, total - offset)) }, (_, n) => ({
    title: (offset + n) % 25 === 0 ? `Cloud Engineer ${offset + n}` : `Cashier ${offset + n}`, externalPath: `/job/India---Bengaluru/Role_JR${offset + n}`, locationsText: "India - Bengaluru" })) });
  let workdayTotal = 60;
  const { fetcher, calls } = network({
    "https://api.smartrecruiters.com/v1/companies/Acme/postings?limit=100&offset=": url => ({ totalFound: 120, content: summaries.slice(Number(url.searchParams.get("offset")), Number(url.searchParams.get("offset")) + 100) }),
    "https://api.smartrecruiters.com/v1/companies/Acme/postings/": url => ({ postingUrl: `https://jobs.smartrecruiters.com/Acme/${url.pathname.split("/").at(-1)}-data-engineer`,
      applyUrl: `https://jobs.smartrecruiters.com/Acme/${url.pathname.split("/").at(-1)}-data-engineer?oga=true`,
      jobAd: { sections: { jobDescription: { title: "Role", text: "<p>Pipelines.</p>" }, qualifications: { title: "You", text: "<p>3+ years of experience.</p>" } } } }),
    "https://acme.wd5.myworkdayjobs.com/wday/cxs/acme/careers/jobs": (_url, init) => {
      const body = JSON.parse(String(init!.body)) as { offset: number; searchText: string };
      if (body.searchText) return { total: 3, jobPostings: [{ title: `${body.searchText} lead`, externalPath: `/job/Remote/${body.searchText.replace(/\s/g, "-")}_JR9`, locationsText: "Remote" }] };
      return workdayPostings(body.offset, workdayTotal);
    },
    "https://acme.wd5.myworkdayjobs.com/wday/cxs/acme/careers/job/": url => ({ jobPostingInfo: { title: decodeURIComponent(url.pathname.split("/").at(-1)!.split("_")[0]!).replace(/-/g, " "),
      jobDescription: "<p>Terraform and AWS.</p>", location: "India - Bengaluru", jobReqId: url.pathname.split("_").at(-1), startDate: "2026-09-26", timeType: "Full time", remoteType: "Hybrid",
      externalUrl: `https://acme.wd5.myworkdayjobs.com/careers${url.pathname.replace("/wday/cxs/acme/careers", "")}`, country: { descriptor: "India" } } }),
  });
  const sr = await crawlBoard(parseBoardUrl("https://jobs.smartrecruiters.com/Acme")!, SOURCE, "Acme", { fetcher, keep: title => /data engineer/i.test(title), delayMs: 0 });
  assert.deepEqual([sr.listed, sr.kept, sr.jobs.length], [120, 3, 3]);
  assert.equal(calls.filter(call => /postings\/\d+$/.test(call.url)).length, 3, "details only for kept roles");
  assert.deepEqual([sr.jobs[0]!.applyUrl.endsWith("?oga=true"), sr.jobs[0]!.seniority, sr.jobs[0]!.countries], [true, "Mid-Senior Level", ["India"]]);
  const target = parseBoardUrl("https://acme.wd5.myworkdayjobs.com/careers")!;
  const small = await crawlBoard(target, SOURCE, "Acme", { fetcher, keep: title => /engineer/i.test(title), delayMs: 0 });
  assert.deepEqual([small.listed, small.kept, small.truncated], [60, 3, false], "every page of a normal board is listed");
  assert.deepEqual([small.jobs[0]!.workplaceType, small.jobs[0]!.postedAt, small.jobs[0]!.applyUrl], ["hybrid", "2026-09-26T00:00:00.000Z", "https://acme.wd5.myworkdayjobs.com/careers/job/India---Bengaluru/Role_JR0"]);
  workdayTotal = 12_000;
  const before = calls.length;
  const huge = await crawlBoard(target, SOURCE, "Acme", { fetcher, keep: title => /engineer|lead/i.test(title), queries: ["data engineer", "data engineer", "cloud engineer"], delayMs: 0 });
  assert.equal(huge.truncated, true);
  assert.deepEqual(calls.slice(before).filter(call => (call.body as { searchText?: string } | undefined)?.searchText).map(call => (call.body as { searchText: string }).searchText), ["data engineer", "cloud engineer"]);
  assert.ok(huge.jobs.some(job => job.title === "data engineer" && job.location === "India - Bengaluru"), "details (not list rows) name the role");
});

test("Apple Jobs: a cookie-bound session, every India role, exact-phrase searches elsewhere, merged cities and sign-in-only applying", async () => {
  const pasted = "https://jobs.apple.com/en-in/details/200614863-0321/machine-learning-research-engineer-apple-intelligence?team=MLAI";
  assert.deepEqual(parseBoardUrl(pasted), { provider: "apple", board: "apple", boardUrl: "https://jobs.apple.com/en-in/search" });
  assert.deepEqual(parseCareerTarget(pasted), parseBoardUrl(pasted));
  const row = (id: string, title: string, city: string, country: string, locale: string, extra: Record<string, unknown> = {}) => ({ positionId: id, postingTitle: title,
    transformedPostingTitle: title.toLowerCase().replace(/[^a-z0-9]+/g, "-"), team: { teamCode: "MLAI" }, localeInfo: { defaultLocaleCode: locale },
    postDateInGMT: "2026-09-08T09:46:25.040+00:00", locations: [{ name: city, countryName: country }], ...extra });
  const india = [row("200614863", "Machine Learning Research Engineer, Apple Intelligence", "Bengaluru", "India", "en-in"),
    ...Array.from({ length: 19 }, (_, n) => row(String(200300000 + n), "IN-Operations Expert", "India", "India", "en-in"))];
  const searches: { query: string; india: boolean; page: number; token?: string; cookie?: string }[] = [];
  const { fetcher, calls } = network({
    "https://jobs.apple.com/api/v1/CSRFToken": () => new Response("", { headers: [["x-apple-csrf-token", "0123456789abcdef0123"], ["set-cookie", "jssid=s%3Aabc.def; Path=/; HttpOnly"], ["set-cookie", "jobs=42; Expires=Mon, 28-Sep-26 05:44:00 GMT"]] }),
    "https://jobs.apple.com/api/v1/search": (_url, init) => {
      const body = JSON.parse(String(init!.body)) as { query: string; filters: { locations?: string[] }; page: number; format?: unknown };
      const headers = new Headers(init!.headers);
      searches.push({ query: body.query, india: !!body.filters.locations, page: body.page, token: headers.get("x-apple-csrf-token") ?? undefined, cookie: headers.get("cookie") ?? undefined });
      if (!body.format) return { res: { searchResults: [], totalRecords: 0 } };
      if (body.filters.locations) return { res: { totalRecords: 21, searchResults: body.page === 1 ? india : [row("200600001", "Data Engineer", "Hyderabad", "India", "en-in")] } };
      if (!body.query) return { res: { totalRecords: 6210, searchResults: [row("200999999", "Data Engineer", "Cupertino", "United States", "en-us")] } };
      if (body.query === '"data engineer"') return { res: { totalRecords: 3, searchResults: [row("200657330", "Data Engineer", "Cupertino", "United States", "en-us"),
        row("200657330", "Data Engineer", "Austin", "United States", "en-us"), row("200700000", "Data Engineer, Home-based", "Home Office", "United Kingdom", "en-gb", { homeOffice: true })] } };
      return { res: { totalRecords: 0, searchResults: [] } };
    },
    "https://jobs.apple.com/api/v1/jobDetails/": url => {
      const id = url.pathname.split("/").pop()!;
      return { res: { positionId: id, postingTitle: id === "200614863" ? "Machine Learning Research Engineer, Apple Intelligence" : "Data Engineer",
        jobSummary: "Apple is where individual imaginations gather together.", description: "Build data pipelines.\nOwn quality.", responsibilities: "undefined",
        minimumQualifications: "5-8yrs of machine learning expertise.", homeOffice: id === "200700000", teamNames: ["Machine Learning and AI"], postDateInGMT: "2026-09-08T09:46:25.040+00:00",
        locations: id === "200657330" ? [{ city: "Cupertino", stateProvince: "California", countryName: "United States" }, { city: "Austin", stateProvince: "Texas", countryName: "United States" }]
          : id === "200700000" ? [{ name: "Home Office", countryName: "United Kingdom" }] : [{ city: id === "200600001" ? "Hyderabad" : "Bengaluru", stateProvince: "Karnataka", countryName: "India" }] } };
    },
  });
  const result = await crawlBoard(parseBoardUrl(pasted)!, SOURCE, "Apple", { fetcher, delayMs: 0, keep: title => /engineer/i.test(title), queries: ["Data Engineer", "data engineer", "ab"] });
  assert.ok(searches.length && searches.every(search => search.token === "0123456789abcdef0123" && search.cookie === "jssid=s%3Aabc.def; jobs=42"), "every search carries the session token and cookies");
  assert.deepEqual(searches.map(({ query, india, page }) => `${india ? "IN" : "all"}:${query || "*"}:${page}`), ["all:*:1", "IN:*:1", "IN:*:2", 'all:"data engineer":1'],
    "India is listed page by page; elsewhere only exact role phrases are searched");
  assert.equal(result.listed, 6210);
  assert.equal(result.truncated, true, "a keyword search never closes roles it did not see");
  assert.deepEqual(result.jobs.map(job => job.sourceJobId).sort(), ["200600001", "200614863", "200657330", "200700000"], "operations roles are filtered out before any detail request");
  assert.equal(calls.filter(call => call.url.includes("/jobDetails/")).length, 4);
  const ml = result.jobs.find(job => job.sourceJobId === "200614863")!;
  assert.equal(ml.canonicalUrl, "https://jobs.apple.com/en-in/details/200614863/machine-learning-research-engineer-apple-intelligence?team=MLAI");
  assert.equal(ml.applyUrl, "https://jobs.apple.com/app/en-in/apply/200614863");
  assert.equal(ml.location, "Bengaluru, Karnataka, India");
  assert.deepEqual(ml.countries, ["India"]);
  assert.match(ml.description, /Minimum qualifications[\s\S]*5-8yrs/);
  assert.doesNotMatch(ml.description, /undefined/);
  assert.equal(jobIdentity(ml), "apple:200614863");
  assert.equal(jobIdentity({ ...ml, canonicalUrl: pasted, applyUrl: pasted }), "apple:200614863", "the city-specific link you paste is the same role");
  const multi = result.jobs.find(job => job.sourceJobId === "200657330")!;
  assert.equal(multi.location, "Cupertino, California, United States; Austin, Texas, United States");
  assert.equal(multi.applyUrl, "https://jobs.apple.com/app/en-us/apply/200657330");
  const home = result.jobs.find(job => job.sourceJobId === "200700000")!;
  assert.equal(home.remote, true);
  assert.equal(home.workplaceType, "remote");
  const { fetcher: refused } = network({ "https://jobs.apple.com/api/v1/CSRFToken": () => ({}) });
  await assert.rejects(crawlBoard(parseBoardUrl(pasted)!, SOURCE, "Apple", { fetcher: refused, delayMs: 0 }), /did not start a search session/);
});

test("a crawl cut short (stopped or out of time) is marked truncated, so roles it did not reach are never treated as removed", async () => {
  const summaries = Array.from({ length: 6 }, (_, n) => ({ id: String(7_100_000 + n), name: `Data Engineer ${n}`, location: { city: "Pune", country: "in" } }));
  const stop = new AbortController();
  let details = 0;
  const { fetcher } = network({
    "https://api.smartrecruiters.com/v1/companies/Acme/postings?limit=100&offset=": () => ({ totalFound: 6, content: summaries }),
    "https://api.smartrecruiters.com/v1/companies/Acme/postings/": url => {
      if (++details === 2) stop.abort();
      return { postingUrl: `https://jobs.smartrecruiters.com/Acme/${url.pathname.split("/").at(-1)}-data-engineer`, jobAd: { sections: { jobDescription: { text: "<p>Pipelines.</p>" } } } };
    },
  });
  const board = parseBoardUrl("https://jobs.smartrecruiters.com/Acme")!;
  const stopped = await crawlBoard(board, SOURCE, "Acme", { fetcher, delayMs: 0, signal: stop.signal });
  assert.equal(stopped.truncated, true);
  assert.ok(stopped.jobs.length < 6, "no requests after the stop");
  const late = await crawlBoard(board, SOURCE, "Acme", { fetcher, delayMs: 5, deadlineMs: 12 });
  assert.equal(late.truncated, true, "a time budget that runs out mid-board is truncated too");
  const complete = await crawlBoard(board, SOURCE, "Acme", { fetcher, delayMs: 0 });
  assert.deepEqual([complete.truncated, complete.jobs.length], [false, 6]);
  await assert.rejects(crawlBoard(parseBoardUrl("https://jobs.lever.co/acme")!, SOURCE, "Acme", { fetcher, signal: AbortSignal.abort() }), /stopped/);
});

test("the crawler refuses other hosts, retries a 429 once and reports repeated failures", async () => {
  await assert.rejects(crawlBoard({ provider: "workday", board: "evil.example/acme/site", boardUrl: "https://evil.example/site" }, SOURCE, "x"), /Invalid Workday board/);
  await assert.rejects(crawlBoard({ provider: "generic", board: "x", boardUrl: "https://x.example" }, SOURCE, "x"), /page by page/);
  let attempts = 0;
  const { fetcher } = network({ "https://api.lever.co/v0/postings/acme": () => ++attempts === 1 ? new Response("slow down", { status: 429, headers: { "retry-after": "0" } }) : [] });
  assert.deepEqual((await crawlBoard(parseBoardUrl("https://jobs.lever.co/acme")!, SOURCE, "Acme", { fetcher })).listed, 0);
  assert.equal(attempts, 2);
  const failing = network({ "https://api.lever.co/v0/postings/acme": () => new Response("down", { status: 503, headers: { "retry-after": "0" } }) });
  await assert.rejects(crawlBoard(parseBoardUrl("https://jobs.lever.co/acme")!, SOURCE, "Acme", { fetcher: failing.fetcher }), /503/);
});
