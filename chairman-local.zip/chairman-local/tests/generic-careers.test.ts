import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import type { ClientRequest, IncomingMessage } from "node:http";
import type { RequestOptions, request as httpsRequest } from "node:https";
import { Readable } from "node:stream";
import test from "node:test";
import { resolveCareerLink, scanCareerBoard } from "../packages/adapters/career-links";
import { DiscoveryError } from "../packages/adapters/discovery";
import { inspectGenericCareerPage, scanGenericCareerBoard } from "../packages/adapters/generic-careers";
import { loadPublicCareerPage, MAX_PUBLIC_PAGE_BYTES, publicCareerPageUrl } from "../packages/adapters/public-page";
import type { CareerBoardTarget } from "../packages/domain/types";

const seed = "https://careers.example.com/careers";
const target: CareerBoardTarget = { provider: "generic", board: "careers.example.com", boardUrl: seed };
const jobUrl = (number = 1) => `${seed}/jobs/${number}`;
const jd = (number = 1, extra: Record<string, unknown> = {}) => ({
  "@type": "JobPosting", title: `Platform Engineer ${number}`, url: jobUrl(number),
  description: "<p>Build reliable infrastructure.</p><h2>Requirements</h2><p>Experience maintaining production services.</p>",
  hiringOrganization: { "@type": "Organization", name: "Example Engineering" },
  ...extra
});
const html = (value: unknown, rest = "") => `<script type="application/ld+json">${JSON.stringify(value).replace(/</g, "\\u003c")}</script>${rest}`;
const errorIs = (code: string) => (error: unknown) => error instanceof DiscoveryError && error.code === code;
const encode = (value: unknown) => Buffer.from(JSON.stringify(value)).toString("base64url");

test("generic resolution retains the exact seed and makes a full source JD previewable", async () => {
  const result = await resolveCareerLink(`${jobUrl()}?utm_source=never-forward#apply`, { pageLoader: async (url) => {
    assert.equal(url, jobUrl());
    return html({ "@graph": [{ "@type": "Organization" }, jd()] });
  } });
  assert.deepEqual(result.target, { provider: "generic", board: "careers.example.com", boardUrl: jobUrl(), jobId: jobUrl() });
  assert.match(result.message, /previewable/);
  assert.deepEqual(result.candidates, []);
});

test("JSON-LD graph source metadata stays honest and full text has no executable markup", () => {
  const page = inspectGenericCareerPage(html({ "@graph": [jd(1, {
    description: "<p>Build systems.</p><script>stealCookies()</script><p>Do not use AI in your application.</p>",
    jobLocationType: "TELECOMMUTE", applicantLocationRequirements: [{ "@type": "Country", name: "IN" }],
    jobLocation: { "@type": "Place", address: { addressLocality: "Pune", addressCountry: "India" } },
    employmentType: "FULL_TIME", datePosted: "2026-01-01", validThrough: "2020-01-01",
    baseSalary: { currency: "INR", value: { minValue: 500_000, maxValue: 600_000, unitText: "MONTH" } }
  })] }, '<a href="/careers/jobs/1/apply">Apply now</a>'), jobUrl());
  const job = page.jobs[0]!;
  assert.equal(job.title, "Platform Engineer 1");
  assert.equal(job.company, "Example Engineering");
  assert.equal(job.canonicalUrl, jobUrl());
  assert.equal(job.applyUrl, `${jobUrl()}/apply`);
  assert.deepEqual(job.countries, ["India"]);
  assert.equal(job.location, "Pune, India");
  assert.equal(job.remote, true);
  assert.equal(job.employmentType, "FULL_TIME");
  assert.deepEqual(job.salary, { min: 500_000, max: 600_000, currency: "INR", period: "monthly", kind: "base" });
  assert.equal(job.postedAt, "2026-01-01T00:00:00.000Z");
  assert.equal(job.status, "closed");
  assert.equal(job.aiPolicy, "prohibited");
  assert.equal(job.sponsorship, "unknown");
  assert.equal(job.language, null);
  assert.doesNotMatch(job.description, /stealCookies|<script|<p>/);
});

test("remote without applicant-country evidence never adopts office countries or worldwide eligibility", () => {
  const job = inspectGenericCareerPage(html(jd(1, {
    jobLocationType: "TELECOMMUTE", jobLocation: { address: { addressCountry: "US" } },
    hiringOrganization: undefined, baseSalary: { currency: "USD", value: { minValue: 50, unitText: "FORTNIGHT" } }
  })), jobUrl()).jobs[0]!;
  assert.deepEqual(job.countries, []);
  assert.equal(job.company, "Employer unspecified");
  assert.equal(job.sponsorship, "unknown");
  assert.equal(job.salary?.period, undefined);
  const onsite = inspectGenericCareerPage(html(jd(1, { jobLocation: [{ address: { addressCountry: { name: "DE" } } }] })), jobUrl()).jobs[0]!;
  assert.deepEqual(onsite.countries, ["Germany"]);
  assert.equal(onsite.remote, false);
});

test("a board follows at most five direct same-origin candidates with durable monotonic cursors", async () => {
  const calls: string[] = [];
  const index = Array.from({ length: 7 }, (_, i) => `<a href="${jobUrl(i + 1)}">Platform Engineer ${i + 1}</a>`).join("");
  const pageLoader = async (url: string) => {
    calls.push(url);
    if (url === seed) return `<h1>Careers</h1>${index}<p>AI-generated applications are prohibited.</p>
      <a href="https://other.example.org/jobs/1">Software Engineer</a><a href="/contact">Contact us</a>
      <a href="/careers/newsletter">Newsletter</a><iframe src="/careers/jobs/99"></iframe>`;
    return html(jd(Number(url.split("/").at(-1))), '<a href="/careers/jobs/999">Unrelated nested engineer</a>');
  };
  const first = await scanGenericCareerBoard(target, "career-source", "Not the employer", undefined, { pageLoader });
  assert.equal(calls.length, 6);
  assert.equal(first.jobs.length, 5);
  assert.ok(first.jobs.every((job) => job.company === "Example Engineering" && job.aiPolicy === "prohibited"));
  const state = JSON.parse(Buffer.from(first.nextCursor!, "base64url").toString("utf8"));
  assert.equal(state.after, jobUrl(5));
  const second = await scanGenericCareerBoard(target, "another-source", "Renamed", first.nextCursor, { pageLoader });
  assert.deepEqual(second.jobs.map((job) => job.sourceJobId), [jobUrl(6), jobUrl(7)]);
  assert.equal(second.nextCursor, undefined);
  assert.equal(calls.length, 9);
  const repeated = await scanGenericCareerBoard(target, "other", "Anything", undefined, { pageLoader });
  assert.equal(repeated.jobs[0]!.id, first.jobs[0]!.id);
  assert.equal(repeated.jobs[0]!.sourceId, "other");
  assert.ok(!calls.some((url) => /contact|newsletter|999|other\.example/.test(url)));
});

test("only explicitly linked numeric pages on the seed path paginate", async () => {
  const calls: string[] = [];
  const pageLoader = async (url: string) => {
    calls.push(url);
    return url === seed
      ? `<h1>Careers</h1><p>Do not use AI in applications.</p><a href="?page=2">Next page</a><a href="?page=0">Bad</a><a href="?page=3&action=delete">Bad</a><a href="/contact?page=2">Bad</a>`
      : html(jd(2));
  };
  const first = await scanGenericCareerBoard(target, "fixture", "", undefined, { pageLoader });
  assert.equal(first.jobs.length, 0);
  assert.ok(first.nextCursor);
  const second = await scanGenericCareerBoard(target, "fixture", "", first.nextCursor, { pageLoader });
  assert.equal(second.jobs.length, 1);
  assert.equal(second.jobs[0]!.aiPolicy, "prohibited");
  assert.equal(second.nextCursor, undefined);
  assert.deepEqual(calls, [seed, `${seed}?page=2`]);
  assert.throws(() => publicCareerPageUrl(`${seed}?page=2`), errorIs("INVALID_DATA"));
});

test("a title-only index follows the posting for its JD; detail indexes do not expand crawl scope", async () => {
  const calls: string[] = [];
  const result = await scanCareerBoard(target, "fixture", "Label", undefined, (async () => { throw new Error("No global fetch for generic HTML"); }) as typeof fetch, {
    pageLoader: async (url) => {
      calls.push(url);
      return url === seed ? html([jd(1, { description: undefined }), jd(2, { description: undefined })])
        : url === jobUrl(1) ? html(jd(1)) : html(jd(3), `<a href="${jobUrl(4)}">Platform Engineer</a>`);
    }
  });
  assert.equal(result.jobs.length, 1);
  assert.equal(result.jobs[0]!.canonicalUrl, jobUrl());
  assert.deepEqual(calls, [seed, jobUrl(1), jobUrl(2)]);
});

test("JavaScript-only and iframe career portals are watch sources, never fabricated jobs", async () => {
  for (const body of [
    "<h1>Careers</h1><script>fetch('/api/jobs')</script>",
    '<h1>Careers</h1><iframe src="https://unsupported.example.org/jobs"><h1>Fake job</h1></iframe>',
    '<h1>Careers</h1><a href="/careers/newsletter">Apply to our newsletter</a><a href="/contact">Request a demo</a>',
    html(jd(1, { description: undefined }), "<h1>Careers</h1>")
  ]) {
    const resolved = await resolveCareerLink(seed, { pageLoader: async () => body });
    assert.equal(resolved.target?.provider, "generic");
    assert.match(resolved.message, /job description|full JD|no opening/i);
    const scanned = await scanGenericCareerBoard(target, "fixture", "", undefined, { pageLoader: async () => body });
    assert.deepEqual(scanned.jobs, []);
  }
});

test("plain postings require a specific title, real description region, and one clear actual apply link", () => {
  const body = '<h1>Cloud Engineer</h1><section class="job-description"><h2>Responsibilities</h2><p>You will operate cloud services.</p></section><a href="/careers/jobs/1/apply">Apply now</a>';
  const found = inspectGenericCareerPage(body, jobUrl()).jobs[0]!;
  assert.equal(found.title, "Cloud Engineer");
  assert.equal(found.company, "Employer unspecified");
  assert.equal(found.location, "Location unspecified");
  assert.equal(found.applyUrl, `${jobUrl()}/apply`);
  for (const broken of [
    body.replace('class="job-description"', 'class="marketing"'),
    body.replace("Cloud Engineer", "Careers"),
    body.replace("Apply now", "Request demo"),
    body.replace("/careers/jobs/1/apply", "/delete"),
    body.replace("You will operate cloud services.", "<textarea>You will operate cloud services.</textarea>").replace("<h2>Responsibilities</h2>", ""),
    body.replace("You will operate cloud services.", '<span hidden>You will operate cloud services.</span>').replace("<h2>Responsibilities</h2>", ""),
    `${body}<a href="/careers/jobs/2/apply">Apply here</a>`,
    body.replace("/careers/jobs/1/apply", "https://private.example.org/apply")
  ]) assert.equal(inspectGenericCareerPage(broken, jobUrl()).jobs.length, 0);
});

test("script JSON is never evaluated and hidden/malformed/unsupported HTML cannot manufacture links", () => {
  for (const body of [
    `<script>({payload: ${JSON.stringify(jd())}})</script>`,
    `<script type="application/ld+json">window.payload=${JSON.stringify(jd())}</script>`,
    `<script type="application/ld+json">{malformed}</script>`,
    `<template>${html(jd())}<a href="${jobUrl()}">Engineer</a></template>`,
    `<!-- ${html(jd())} --><div hidden><a href="${jobUrl()}">Engineer</a></div>`,
    `<iframe src="/careers/jobs/1">${html(jd())}</iframe>`,
    `<textarea>${html(jd())}</textarea>`,
    `<div data-x="<a href='${jobUrl()}'>Engineer</a>">No posting</div>`
  ]) {
    const result = inspectGenericCareerPage(body, seed);
    assert.equal(result.jobs.length, 0);
    assert.deepEqual(result.links, []);
  }
});

test("malicious JSON links and apply destinations never redirect discovery or silently change employer", () => {
  for (const url of [
    "https://127.0.0.1/jobs", "https://localhost/jobs", "https://a.internal/jobs", "https://linkedin.com/jobs/1",
    "https://careers.example.com:443/careers/jobs/1", "https://careers.example.com/careers/../private",
    "https://careers.example.com/%2e%2e/jobs", "https://careers.example.com/careers/jobs/1?token=secret",
    "https://careers.example.com/api/jobs", "https://careers.example.com/careers/jobs/1?action=delete", "//evil.example.org/jobs/1"
  ]) {
    const found = inspectGenericCareerPage(html(jd(1, { url }), `<a href="${url}">Apply now</a><a href="${url}">Software Engineer</a>`), jobUrl());
    assert.deepEqual(found.links, []);
    assert.equal(found.jobs[0]?.canonicalUrl, jobUrl());
    assert.equal(found.jobs[0]?.applyUrl, jobUrl());
  }
});

test("duplicate postings deduplicate explicitly, conflicts fail, and Canonical/no-AI holds survive source aliases", () => {
  assert.equal(inspectGenericCareerPage(html([jd(), jd()]), seed).jobs.length, 1);
  assert.throws(() => inspectGenericCareerPage(html([jd(), jd(1, { description: "A different job" })]), seed), errorIs("INVALID_DATA"));
  const canonical = inspectGenericCareerPage(html(jd(1, { hiringOrganization: { name: "Canonical" } })), jobUrl(), jobUrl(), "alias").jobs[0]!;
  assert.equal(canonical.aiPolicy, "prohibited");
  const outside = inspectGenericCareerPage(html(jd(), "<p>Use your own words for all application answers; do not use AI.</p>"), jobUrl()).jobs[0]!;
  assert.equal(outside.aiPolicy, "prohibited");
});

test("malicious targets and cursors fail before a page fetch", async () => {
  let calls = 0;
  const options = { pageLoader: async () => { calls++; return ""; } };
  for (const state of [
    { v: 1, seed, page: "https://127.0.0.1/careers" },
    { v: 1, seed, page: `${seed}?page=2&token=private` },
    { v: 1, seed, page: `${seed}?page=2&page=3` },
    { v: 1, seed, page: `${seed}?page=1001` },
    { v: 1, seed, page: "https://careers.example.com/contact?page=2" },
    { v: 1, seed, page: seed, after: "https://careers.example.com/api/jobs" },
    { v: 1, seed, page: seed, after: "https://careers.example.com/careers/%2e%2e/private" },
    { v: 1, seed: "https://other.example.com/careers", page: seed },
    { v: 1, seed, page: seed, url: "https://evil.example.org/" },
    { v: 1, seed, page: seed, aiProhibited: false }
  ]) await assert.rejects(scanGenericCareerBoard(target, "fixture", "", encode(state), options), errorIs("INVALID_CURSOR"));
  for (const modified of [
    { ...target, board: "other.example.com" },
    { ...target, boardUrl: "https://127.0.0.1/careers" },
    { ...target, jobId: "https://other.example.com/jobs/1" },
    { ...target, boardUrl: `${seed}?page=2` },
    { ...target, boardUrl: "https://google.co.uk/careers", board: "google.co.uk" }
  ]) await assert.rejects(scanGenericCareerBoard(modified, "fixture", "", undefined, options), errorIs("INVALID_DATA"));
  await assert.rejects(scanGenericCareerBoard(target, "../../profile", "", undefined, options), errorIs("INVALID_DATA"));
  await assert.rejects(scanGenericCareerBoard({ ...target, jobId: jobUrl() }, "fixture", "", encode({ v: 1, seed, page: seed }), options), errorIs("INVALID_CURSOR"));
  assert.equal(calls, 0);
});

test("generic pages enforce 2 MiB each, 8 MiB aggregate, nested JSON limits and a real timeout", async (context) => {
  await assert.rejects(scanGenericCareerBoard(target, "fixture", "", undefined, { pageLoader: async () => "x".repeat(MAX_PUBLIC_PAGE_BYTES + 1) }), errorIs("TOO_LARGE"));
  const links = Array.from({ length: 5 }, (_, i) => `<a href="${jobUrl(i + 1)}">Platform Engineer</a>`).join("");
  await assert.rejects(scanGenericCareerBoard(target, "fixture", "", undefined, { pageLoader: async (url) => {
    const content = url === seed ? links : html(jd(Number(url.split("/").at(-1))));
    return content + "<!--" + "x".repeat(1_800_000) + "-->";
  } }), errorIs("TOO_LARGE"));
  let nested: unknown = jd();
  for (let index = 0; index < 34; index++) nested = { "@graph": [nested] };
  assert.throws(() => inspectGenericCareerPage(html(nested), seed), errorIs("TOO_LARGE"));
  assert.throws(() => inspectGenericCareerPage("<div>".repeat(129), seed), errorIs("TOO_LARGE"));
  context.mock.timers.enable({ apis: ["setTimeout"] });
  const promise = scanGenericCareerBoard(target, "fixture", "", undefined, { pageLoader: async () => new Promise<string>(() => {}) });
  context.mock.timers.tick(15_000);
  await assert.rejects(promise, errorIs("TIMEOUT"));
});

test("gone candidate links do not become openings; rate limits retain Retry-After and never retry", async () => {
  const gone = await scanGenericCareerBoard(target, "fixture", "", undefined, { pageLoader: async (url) => {
    if (url === seed) return `<a href="${jobUrl()}">Software Engineer</a>`;
    throw new DiscoveryError("HTTP_ERROR", "Gone", undefined, 410);
  } });
  assert.deepEqual(gone, { jobs: [] });
  for (const status of [429, 503]) {
    const error = new DiscoveryError(status === 429 ? "RATE_LIMITED" : "HTTP_ERROR", "Deferred", 60_000, status);
    let calls = 0;
    await assert.rejects(scanGenericCareerBoard(target, "fixture", "", undefined, { pageLoader: async () => { calls++; throw error; } }), (caught) => caught === error);
    assert.equal(calls, 1);
  }
});

test("scanner-only numeric pagination retains DNS pinning and refuses redirects before another connection", async () => {
  const calls: RequestOptions[] = [];
  let redirect = false;
  const request = ((options: RequestOptions, callback: (response: IncomingMessage) => void) => {
    calls.push(options);
    const req = new EventEmitter() as ClientRequest;
    req.destroy = () => req;
    req.end = (() => {
      queueMicrotask(() => {
        const response = Readable.from([Buffer.from("<h1>Careers</h1>")]) as IncomingMessage;
        response.statusCode = redirect ? 302 : 200;
        response.headers = { "content-type": "text/html", ...(redirect ? { location: "https://other.example.com/careers" } : {}) };
        callback(response);
      });
      return req;
    }) as ClientRequest["end"];
    return req;
  }) as typeof httpsRequest;
  const dependencies = { request, resolve: async () => [{ address: "93.184.215.14", family: 4 }], listingSeed: seed };
  await loadPublicCareerPage(`${seed}?page=2`, dependencies);
  assert.equal(calls[0]!.path, "/careers?page=2");
  assert.equal(calls[0]!.method, "GET");
  assert.equal(calls[0]!.agent, false);
  assert.equal(calls[0]!.servername, "careers.example.com");
  const pinned = await new Promise<string>((resolve, reject) => calls[0]!.lookup!("careers.example.com", {}, (error, address) => error ? reject(error) : resolve(String(address))));
  assert.equal(pinned, "93.184.215.14");
  const headers = new Headers(calls[0]!.headers as Record<string, string>);
  for (const name of ["cookie", "authorization", "referer"]) assert.equal(headers.get(name), null);
  redirect = true;
  await assert.rejects(loadPublicCareerPage(seed, dependencies), errorIs("REDIRECT"));
  assert.equal(calls.length, 2);
  await assert.rejects(loadPublicCareerPage(seed, { ...dependencies, resolve: async () => [{ address: "127.0.0.1", family: 4 }] }), errorIs("INVALID_DATA"));
  assert.equal(calls.length, 2);
});
