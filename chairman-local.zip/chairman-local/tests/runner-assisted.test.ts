import test from "node:test";
import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { createServer, type Server } from "node:http";
import type { AddressInfo, Socket } from "node:net";
import { join, resolve } from "node:path";
import { PortalBrowser } from "../packages/automation/portal-browser.js";
import type { WorkflowInput, WorkflowResult } from "../packages/automation/contracts.js";
import { fingerprint } from "../packages/automation/form.js";
import { Store } from "../apps/local/store.js";
import { Engine, snapshotHash } from "../apps/local/engine.js";
import { ResumeLibrary } from "../apps/local/resume-library.js";
import { ExtensionAssistService } from "../apps/local/extension-assist.js";
import { createDocuments } from "../packages/documents/index.js";
import { emptyProfile, type FormSnapshot, type Profile } from "../packages/domain/types.js";
import { jobFixture } from "./fixtures.js";

type Case = "plain" | "consent" | "terms" | "captcha" | "after" | "unknown";
const TOKEN = "fixture-response-token-0123456789abcdef";
function html(kind: Case): string {
  const extra = kind === "consent" ? '<div class="field"><label><input type="checkbox" id="consent" required> I agree to the privacy policy</label></div>'
    : kind === "terms" ? "<p>By submitting this application, you agree to our privacy policy and terms.</p>"
      : kind === "captcha" ? '<div class="g-recaptcha" data-sitekey="fixture" style="width:304px;height:78px;border:1px solid #ccc"><textarea name="g-recaptcha-response" style="display:none"></textarea></div>'
        : kind === "after" ? '<textarea name="g-recaptcha-response" style="display:none"></textarea>'
          : kind === "unknown" ? '<div class="field"><label for="project">Preferred project <span aria-hidden="true">*</span></label><input id="project" name="project"></div>' : "";
  return `<!doctype html><html><head><meta charset="utf-8"><title>Data Engineer - Fictional Employer</title></head><body>
  <main><h1>Apply for Data Engineer</h1>
  <form id="application-form" action="/fixture/application" method="post">
    <div class="field"><label for="name">Full name <span aria-hidden="true">*</span></label><input id="name" name="name"></div>
    <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" aria-required="true"></div>
    <div class="field"><div class="ashby-question-title">Are you willing to relocate?</div><div class="yesno"><button type="button">Yes</button><button type="button">No</button></div></div>
    <div class="field"><label class="upload">Resume/CV <input type="file" id="resume" accept=".pdf" style="position:absolute;width:1px;height:1px;opacity:0"></label></div>
    ${extra}
    <button type="submit">Submit application</button>
  </form></main>
  <script>
    window.state = { submits: 0 };
    document.querySelectorAll(".yesno button").forEach(b => b.addEventListener("click", () => {
      document.querySelectorAll(".yesno button").forEach(x => x.removeAttribute("aria-pressed")); b.setAttribute("aria-pressed", "true"); }));
    const form = document.getElementById("application-form");
    const send = async () => {
      const file = document.getElementById("resume").files[0];
      const body = { name: document.getElementById("name").value, email: document.getElementById("email").value,
        relocate: document.querySelector(".yesno button[aria-pressed=true]")?.textContent ?? "", consent: document.getElementById("consent")?.checked ?? null,
        project: document.getElementById("project")?.value ?? null, file: file ? { name: file.name, size: file.size } : null };
      await fetch("/fixture/application", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      form.remove();
      document.body.insertAdjacentHTML("beforeend", "<div role=status>Thank you for applying. Your application has been received.</div>");
    };
    form.onsubmit = event => {
      event.preventDefault(); window.state.submits++;
      if (${JSON.stringify(kind)} !== "after") { void send(); return; }
      document.body.insertAdjacentHTML("beforeend", '<div data-captcha-challenge="open" id="challenge" style="position:fixed;top:10px;left:10px;width:400px;height:400px;background:#eee">Select all images with buses</div>');
      const wait = setInterval(() => {
        if (document.querySelector('[name="g-recaptcha-response"]').value.length < 20) return;
        clearInterval(wait); document.getElementById("challenge").remove(); void send();
      }, 100);
    };
  </script></body></html>`;
}

function profile(acknowledge: boolean): Profile {
  return { ...emptyProfile(), name: "Taylor Fixture", email: "taylor@fictional.invalid", phone: "+1 202-555-0118", location: "India", confirmed: true,
    skills: ["Python", "SQL", "AWS"], answers: { willing_to_relocate: "Yes" },
    preferences: { ...emptyProfile().preferences, acceptRequiredAcknowledgements: acknowledge },
    facts: [{ id: "exp-one", category: "experience", text: "Built Python and SQL data pipelines on AWS.", employer: "Fictional Labs", role: "Data Engineer", dates: "2023 - Present", confirmed: true }] };
}

test("assisted runner: page-engine fills, CAPTCHA hand-off continues by itself, acknowledgements follow Profile, never a second Submit", { timeout: 180_000 }, async t => {
  const dir = resolve(".runner-assisted-tests", randomUUID());
  await mkdir(dir, { recursive: true });
  const store = new Store(join(dir, "test.sqlite"));
  store.set("profile", profile(false));
  const engine = new Engine(store, dir, [], true, "http://127.0.0.1");
  const library = new ResumeLibrary(store, dir), service = new ExtensionAssistService({ store, engine, library });
  const artifacts = await createDocuments(store.profile(), jobFixture(), { mode: "deterministic", factIds: ["exp-one"], skills: ["Python"], notes: [] }, join(dir, "templates"));
  const pdf = artifacts.find(item => item.format === "pdf")!;
  await library.upload(1, "baseline.pdf", await readFile(join(dir, "templates", pdf.filename)), "Data baseline", ["data"], true);
  const bytes = Buffer.from("%PDF-1.7\nSynthetic fixture only. No applicant data.\n%%EOF"), resumePath = join(dir, "fixture.pdf");
  await writeFile(resumePath, bytes);

  let kind: Case = "plain";
  const posts: Record<string, unknown>[] = [], sockets = new Set<Socket>();
  const server: Server = createServer(async (req, res) => {
    if (req.method === "POST") {
      const chunks: Buffer[] = [];
      for await (const chunk of req) chunks.push(Buffer.from(chunk));
      posts.push(JSON.parse(Buffer.concat(chunks).toString() || "{}"));
      res.writeHead(200, { "Content-Type": "application/json" }); res.end('{"received":true}'); return;
    }
    res.writeHead(200, { "Content-Type": "text/html" }); res.end(html(kind));
  });
  server.on("connection", socket => { sockets.add(socket); socket.on("close", () => sockets.delete(socket)); });
  await new Promise<void>(done => server.listen(0, "127.0.0.1", done));
  const origin = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  const browser = new PortalBrowser({ userDataDir: join(dir, "profiles"), headless: true, testOrigins: [origin] });
  const internal = browser as unknown as { sessions: Map<string, { page: import("playwright").Page }> };
  const pageFor = (result: WorkflowResult) => internal.sessions.get(result.sessionId!)!.page;

  const run = (next: Case, acknowledge = false) => {
    kind = next;
    store.set("profile", profile(acknowledge));
    const job = jobFixture({ id: randomUUID(), applyUrl: `${origin}/fixture/application?case=${next}-${randomUUID().slice(0, 8)}` });
    const records: { snapshot: FormSnapshot; answers: Record<string, string>; human: boolean }[] = [], acknowledged: string[] = [];
    let boundaries = 0;
    const input: WorkflowInput = {
      job, resumePath, resumeFilename: "fixture.pdf", resumeSha256: createHash("sha256").update(bytes).digest("hex"), allowHuman: true,
      checkAuthorization: async () => true,
      beforeTransmit: async (snapshot, answers, human) => { records.push({ snapshot, answers, human }); },
      beforeSubmit: async () => { boundaries++; },
      onProgress: async () => undefined,
      resolveAnswers: async () => { throw new Error("The assisted runner plans with the page engine, not the native resolver."); },
      planPage: page => service.autoPlan(job, page, { ai: "off", allowAi: false }),
      acceptAcknowledgements: acknowledge,
      onAcknowledge: async labels => { acknowledged.push(...labels); },
    };
    return { input, records, acknowledged, boundaries: () => boundaries };
  };
  try {
    await t.test("saved answers, custom yes/no and the resume are filled by the page engine and submitted once with a receipt", async () => {
      const f = run("plain"), before = posts.length;
      const result = await browser.runWorkflow(f.input);
      assert.equal(result.status, "submitted_confirmed", result.reason);
      assert.equal(f.boundaries(), 1);
      assert.equal(posts.length, before + 1);
      assert.deepEqual(posts.at(-1), { name: "Taylor Fixture", email: "taylor@fictional.invalid", relocate: "Yes", consent: null, project: null, file: { name: "fixture.pdf", size: bytes.length } });
      for (const record of f.records) {
        assert.equal(record.snapshot.fingerprint, fingerprint(record.snapshot));
        assert.equal(record.snapshot.fingerprint, snapshotHash(record.snapshot), "workflow records pass the engine's snapshot check");
      }
      assert.ok(f.records.some(record => record.answers[Object.keys(record.answers).find(key => record.answers[key] === "fixture.pdf")!] === "fixture.pdf"));
      assert.ok(result.progress?.filledFields.includes("Are you willing to relocate?"));
    });
    await t.test("a CAPTCHA before Submit parks the filled tab; solving it is noticed and the run submits by itself", async () => {
      const f = run("captcha"), before = posts.length;
      const parked = await browser.runWorkflow(f.input);
      assert.equal(parked.status, "human_required", parked.reason);
      assert.equal(parked.waitingFor, "captcha");
      const page = pageFor(parked);
      assert.match(await page.title(), /^🔐 Solve CAPTCHA · /u);
      assert.equal(await page.locator("#name").inputValue(), "Taylor Fixture");
      assert.equal(await page.locator("#resume").evaluate(e => (e as HTMLInputElement).files?.length), 1);
      assert.equal(posts.length, before);
      assert.deepEqual(await browser.watchWaiting(), [], "an unsolved CAPTCHA is not a signal");
      await page.locator('[name="g-recaptcha-response"]').evaluate((e, token) => { (e as HTMLTextAreaElement).value = token; }, TOKEN);
      assert.deepEqual(await browser.watchWaiting(), [{ sessionId: parked.sessionId, signal: "captcha_solved" }]);
      const resumed = await browser.resumeWorkflow(parked.sessionId!, { answers: {}, useCurrentValues: false });
      assert.equal(resumed.status, "submitted_confirmed", resumed.reason);
      assert.equal(f.boundaries(), 1);
      assert.equal(posts.length, before + 1);
      assert.equal(posts.at(-1)!.relocate, "Yes");
    });
    await t.test("a CAPTCHA raised by Submit parks the tab; the receipt after you solve it is confirmed without a second click", async () => {
      const f = run("after"), before = posts.length;
      const parked = await browser.runWorkflow(f.input);
      assert.equal(parked.status, "human_required", parked.reason);
      assert.equal(parked.waitingFor, "captcha_after_submit");
      assert.equal(f.boundaries(), 1);
      const page = pageFor(parked);
      assert.equal(await page.evaluate("window.state.submits"), 1);
      await page.locator('[name="g-recaptcha-response"]').evaluate((e, token) => { (e as HTMLTextAreaElement).value = token; }, TOKEN);
      await page.getByRole("status").waitFor();
      assert.deepEqual(await browser.watchWaiting(), [{ sessionId: parked.sessionId, signal: "receipt_visible" }]);
      const confirmed = await browser.resumeWorkflow(parked.sessionId!, { answers: {}, useCurrentValues: false });
      assert.equal(confirmed.status, "submitted_confirmed", confirmed.reason);
      assert.equal(posts.length, before + 1);
      assert.equal(f.boundaries(), 1, "Submit is never clicked twice");
    });
    await t.test("required consent waits for you unless Profile accepts required acknowledgements, which is recorded", async () => {
      const off = run("consent", false);
      const parked = await browser.runWorkflow(off.input);
      assert.equal(parked.status, "human_required", parked.reason);
      assert.equal(parked.waitingFor, "answers");
      assert.deepEqual(parked.progress?.missingFields.map(field => field.label), ["I agree to the privacy policy"]);
      assert.equal(await pageFor(parked).locator("#consent").isChecked(), false);
      await browser.abandonWorkflow(parked.sessionId!);
      const on = run("consent", true), before = posts.length;
      const result = await browser.runWorkflow(on.input);
      assert.equal(result.status, "submitted_confirmed", result.reason);
      assert.equal(posts.length, before + 1);
      assert.equal(posts.at(-1)!.consent, true);
      assert.deepEqual(on.acknowledged, ["I agree to the privacy policy"]);
    });
    await t.test("\"by submitting you agree\" terms follow the same Profile switch", async () => {
      const off = run("terms", false), parked = await browser.runWorkflow(off.input);
      assert.equal(parked.status, "human_required", parked.reason);
      assert.match(parked.reason, /Accept required acknowledgements/);
      await browser.abandonWorkflow(parked.sessionId!);
      const on = run("terms", true), result = await browser.runWorkflow(on.input);
      assert.equal(result.status, "submitted_confirmed", result.reason);
      assert.equal(on.acknowledged.length, 1);
    });
    await t.test("an unanswered question parks with its label; your answer from the dashboard is filled and submitted", async () => {
      const f = run("unknown"), before = posts.length;
      const parked = await browser.runWorkflow(f.input);
      assert.equal(parked.status, "human_required", parked.reason);
      assert.equal(parked.waitingFor, "answers");
      const [missing] = parked.progress!.missingFields;
      assert.equal(missing?.label, "Preferred project");
      assert.match(await pageFor(parked).title(), /^✋ Needs you · /u);
      assert.deepEqual(await browser.watchWaiting(), [], "answers are never guessed by the watcher");
      const resumed = await browser.resumeWorkflow(parked.sessionId!, { answers: { [missing!.key]: "Streaming pipelines" }, useCurrentValues: false });
      assert.equal(resumed.status, "submitted_confirmed", resumed.reason);
      assert.equal(posts.length, before + 1);
      assert.equal(posts.at(-1)!.project, "Streaming pipelines");
      assert.ok(f.records.some(record => record.human && record.answers[missing!.key] === "Streaming pipelines"));
    });
  } finally {
    await browser.close();
    for (const socket of sockets) socket.destroy();
    await new Promise<void>(done => server.close(() => done()));
    await service.close(); store.db.close();
    await rm(dir, { recursive: true, force: true });
  }
});
