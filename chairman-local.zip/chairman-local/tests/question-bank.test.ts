import assert from "node:assert/strict";
import test from "node:test";
import { resolveAnswers } from "../packages/automation/answers.js";
import { DISCLOSURE_KEYS, QUESTION_BANK, bankQuestion } from "../packages/domain/question-bank.js";
import { emptyProfile, type FormField, type Job, type Profile } from "../packages/domain/types.js";

function profile(answers: Record<string, string> = {}): Profile {
  return { ...emptyProfile(), confirmed: true, name: "Demo Candidate", email: "demo@example.com", phone: "+91 90000 00000", location: "Bengaluru, Karnataka, India", answers };
}
const job: Job = { id: "j", sourceId: "s", sourceJobId: "j", title: "Data Engineer", company: "Confluent", location: "India", remote: false, countries: ["India"],
  employmentType: "Full-time", description: "Build data pipelines.", applyUrl: "https://example.invalid", canonicalUrl: "https://example.invalid", fetchedAt: "2026-01-01",
  salary: null, language: null, sponsorship: "unknown", aiPolicy: "allowed", status: "open" };
const field = (key: string, label: string, extra: Partial<FormField> = {}): FormField => ({ key, label, type: "text", required: true, options: [], ...extra });
const choice = (key: string, label: string, labels: string[], extra: Partial<FormField> = {}): FormField =>
  field(key, label, { type: "radio", options: labels.map((_, index) => `o${index}`), optionLabels: Object.fromEntries(labels.map((item, index) => [`o${index}`, item])), ...extra });
const resolve = (fields: FormField[], source: Profile, options = {}) =>
  resolveAnswers(source, job, { url: "https://example.invalid", fields, fingerprint: "x", hasCaptcha: false, hasLegal: false, unsupported: [] }, options);

test("the question bank is well-formed: unique keys, disclosures namespaced, choices for choice questions", () => {
  const keys = QUESTION_BANK.map(entry => entry.key);
  assert.equal(new Set(keys).size, keys.length);
  for (const entry of QUESTION_BANK) {
    if (entry.kind === "choice") assert.ok(entry.choices?.length, `${entry.key} has choices`);
    if (entry.disclosure) assert.match(entry.key, /^eeo_/, "disclosure answers never match ordinary exact labels");
  }
  assert.ok(DISCLOSURE_KEYS.has("eeo_gender") && !DISCLOSURE_KEYS.has("military_service"));
  assert.equal(bankQuestion("postal_code")?.category, "location");
});

test("catalog wordings and company-specific questions resolve to your saved answers", () => {
  const source = profile({ postal_code: "560001", previously_employed_here: "No", how_did_you_hear: "Company careers page", age_18_or_over: "Yes", state_province: "Karnataka" });
  const plan = resolve([
    field("zip", "Location - Zip Code"), field("state", "State/Province"),
    choice("past", "Have you previously been employed at Confluent or one of our subsidiaries?", ["Yes", "No"]),
    field("heard", "How did you hear about Confluent?"),
    choice("adult", "Are you at least 18 years of age?", ["Yes", "No"]),
  ], source);
  assert.deepEqual(plan.answers, { zip: "560001", state: "Karnataka", past: "o1", heard: "Company careers page", adult: "o0" });
});

test("voluntary disclosures fill from your saved answers only when enabled, with decline and wording synonyms", () => {
  const source = profile({ eeo_gender: "Male", eeo_veteran_status: "I am not a protected veteran", eeo_disability_status: "I don't wish to answer" });
  const fields = [
    choice("gender", "What is your gender identity?", ["Man", "Woman", "Non-binary", "Decline to self-identify"], { required: false }),
    choice("veteran", "Veteran status", ["I am a protected veteran", "I am not a veteran", "I don't wish to answer"], { required: false }),
    choice("disability", "Do you have a disability?", ["Yes, I have a disability", "No, I do not have a disability", "I do not want to answer"], { required: false }),
  ];
  assert.deepEqual(resolve(fields, source).answers, {}, "off by default: never filled");
  assert.deepEqual(resolve(fields, source, { disclosures: true }).answers, { gender: "o0", veteran: "o1", disability: "o2" });
  assert.deepEqual(resolve(fields, profile(), { disclosures: true }).answers, {}, "enabling disclosures never invents an answer");
});

test("required acknowledgements are ticked only in acknowledgement mode; marketing opt-ins are declined unless you said yes", () => {
  const ack = field("privacy", "I have read and acknowledge the privacy notice", { type: "checkbox", options: ["true", "false"] });
  const agree = choice("terms", "Do you agree to the terms of the candidate data policy?", ["I agree", "I do not agree"]);
  const sms = choice("sms", "Check Yes or No to indicate your agreement to receive text message updates", ["Yes - I consent to receiving text messages", "No - I do not consent to receiving text messages"]);
  const off = resolve([ack, agree, sms], profile());
  assert.deepEqual(off.answers, {});
  assert.ok(off.blockers.length, "without acknowledgement mode these stay yours");
  const on = resolve([ack, agree, sms], profile(), { acknowledgements: true, provenance: true });
  assert.deepEqual(on.answers, { privacy: "true", terms: "o0", sms: "o1" });
  assert.equal(on.sources?.privacy, "acknowledgement:auto");
  assert.equal(on.sources?.sms, "marketing:declined");
  assert.equal(resolve([sms], profile({ marketing_opt_in: "Yes" }), { acknowledgements: true }).answers.sms, "o0");
  assert.deepEqual(resolve([field("optional", "I agree to receive marketing emails", { type: "checkbox", options: ["true", "false"], required: false })], profile(), { acknowledgements: true }).answers, {},
    "optional opt-ins are never ticked");
});

test("factual questions that use legal words are answered from your saved answer, never auto-affirmed", () => {
  const noncompete = choice("nc", "Are you subject to a non-compete agreement?", ["Yes", "No"]);
  assert.deepEqual(resolve([noncompete], profile({ non_compete: "No" })).answers, { nc: "o1" });
  const unanswered = resolve([noncompete], profile(), { acknowledgements: true });
  assert.deepEqual(unanswered.answers, {}, "acknowledgement mode does not answer factual questions");
  assert.ok(unanswered.missing.length);
  assert.deepEqual(resolve([choice("bg", "Are you willing to undergo a background check?", ["Yes", "No"])], profile({ background_check_willing: "Yes" })).answers, { bg: "o0" });
});
