import test from "node:test";
import assert from "node:assert/strict";
import { appendFile, chmod, mkdtemp, readFile, rm, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { Document, Packer, Paragraph } from "docx";
import type { ApplicationBrowserDriver, BrowserInspection, BrowserSubmitInput, BrowserSubmission } from "../packages/automation/contracts.js";
import type { FormSnapshot, ReferenceFamily } from "../packages/domain/types.js";
import { Engine, snapshotHash } from "../apps/local/engine.js";
import { Store } from "../apps/local/store.js";
import { ResumeLibrary } from "../apps/local/resume-library.js";
import { AutopilotService } from "../apps/local/autopilot.js";
import { profileFixture, jobFixture } from "./fixtures.js";

class BrowserStub implements ApplicationBrowserDriver {
  inspected = 0;
  submitted = 0;
  fileName = "";
  outcome: BrowserSubmission["status"] = "submitted_confirmed";
  onSubmit?: (input: BrowserSubmitInput) => Promise<BrowserSubmission>;
  snapshot!: FormSnapshot;
  inspectResult?: BrowserInspection;
  async inspect(): Promise<BrowserInspection> { this.inspected++; return this.inspectResult ?? { status: "ready", provider: "ashby", reason: "Synthetic form.", snapshot: this.snapshot }; }
  async submit(input: BrowserSubmitInput): Promise<BrowserSubmission> {
    this.submitted++;
    this.fileName = input.resumeFilename;
    const bytes = await readFile(input.resumePath);
    assert.equal(createHash("sha256").update(bytes).digest("hex"), input.resumeSha256);
    assert.equal(await input.checkAuthorization(), true);
    if (this.onSubmit) return this.onSubmit(input);
    await input.beforeSubmit();
    return { status: this.outcome, reason: "Synthetic controlled outcome.", evidence: this.outcome === "submitted_confirmed" ? "Synthetic receipt AUTO-123" : undefined };
  }
  async openForSetup(): Promise<void> {}
  isRunning(): boolean { return false; }
  async close(): Promise<void> {}
}
async function cv(text: string): Promise<Buffer> {
  return Packer.toBuffer(new Document({ sections: [{ children: [
    new Paragraph("Riley Jordan"), new Paragraph("riley.jordan@example.test"),
    new Paragraph(text), new Paragraph("Example University, Engineering, 2023. This fictional record is used only in local automated fixtures.")
  ] }] }));
}
async function setup(strategy: "original" | "job-tailored" = "original") {
  const dir = await mkdtemp(join(tmpdir(), "jaa-autopilot-")), store = new Store(join(dir, "test.sqlite"));
  const profile = profileFixture(); profile.name = "Riley Jordan"; profile.email = "riley.jordan@example.test";
  profile.answers = { country: "India", experience: profile.facts[0]!.text, total_years_experience: "3" };
  store.set("profile", profile);
  const engine = new Engine(store, dir, [], false, "http://127.0.0.1:4318"), library = new ResumeLibrary(store, dir);
  const url = `https://jobs.ashbyhq.com/example/${randomUUID()}/application`;
  const job = jobFixture({ applyUrl: url, canonicalUrl: url });
  store.saveJob(job);
  const browser = new BrowserStub();
  browser.snapshot = { url, fields: [
    { key: "full_name", label: "Full name", type: "text", required: true, options: [] },
    { key: "email", label: "Email", type: "email", required: true, options: [] },
    { key: "experience", label: "Relevant experience", type: "textarea", required: true, options: [] },
    { key: "resume", label: "Resume", type: "file", required: true, options: [], accept: [".docx", ".pdf"] },
    { key: "cover_letter", label: "Cover letter", type: "file", required: false, options: [] }
  ], fingerprint: "", hasCaptcha: false, hasLegal: false, unsupported: [] };
  browser.snapshot.fingerprint = snapshotHash(browser.snapshot);
  const service = new AutopilotService(store, engine, library, dir, { browser });
  service.setRules({ ...service.view().rules, resumeStrategy: strategy, tailoringMode: "deterministic" });
  const families: ReferenceFamily[] = ["software", "cloud", "data", "mlops"];
  async function uploadSlots(slots: number[]) {
    for (const slot of slots) await library.upload(slot, `${families[slot - 1]}.docx`,
      await cv(slot === 3 ? "Data Engineer. Built Python, SQL, Apache Kafka and Apache Spark data pipelines on AWS." : `${families[slot - 1]} engineer. Built applications and maintained production services.`),
      `${families[slot - 1]} resume`, [families[slot - 1]!], true);
  }
  const uploadFour = () => uploadSlots([1, 2, 3, 4]);
  async function settle() {
    for (let n = 0; n < 500; n++) {
      const status = service.view().jobs[0]?.status;
      if (status && !["queued", "inspecting", "submitting"].includes(status)) return;
      await new Promise(resolve => setTimeout(resolve, 10));
    }
    throw new Error("Automatic cycle did not settle.");
  }
  return { dir, store, profile, engine, library, browser, service, job, uploadFour, uploadSlots, settle,
    cleanup: async () => { await service.close(); store.close(); await rm(dir, { recursive: true, force: true }); } };
}
test("two valid approved resumes in any slots are sufficient; zero or one cannot activate", async () => {
  const r = await setup();
  try {
    assert.equal(r.service.view().ready, false);
    await assert.rejects(r.service.enable(r.service.snapshotHash()), /at least 2/);
    assert.equal(r.browser.inspected, 0);
    await r.uploadSlots([2]);
    assert.equal(r.service.view().ready, false);
    await assert.rejects(r.service.enable(r.service.snapshotHash()), /at least 2/);
    await r.uploadSlots([4]);
    assert.equal(r.service.view().ready, true);
    const before = r.service.snapshotHash();
    const variant = r.library.list()[0]!;
    r.library.approve(variant.id, false);
    await assert.rejects(r.service.enable(before), /at least 2/);
    assert.equal(r.browser.inspected, 0);
    await assert.rejects(r.library.upload(1, "wrong.docx", await cv("REFERENCE DRAFT - verify facts before use"), "Wrong", ["software"], true), /reference\/sample draft/);
  } finally { await r.cleanup(); }
});
test("optional unapproved and invalid extras neither count nor block two valid resumes", async () => {
  const r = await setup();
  try {
    await r.uploadSlots([2, 4]);
    const draft = await r.library.upload(1, "draft.docx", await cv("REFERENCE DRAFT - verify facts before use"), "Unapproved draft", ["data"], false);
    await r.library.upload(3, "unapproved.docx", await cv("A nonapproved optional resume."), "Optional", ["data"], false);
    // Even a damaged, unapproved extra must not be read or silently promoted.
    await chmod(r.library.path(draft.id), 0o600); await appendFile(r.library.path(draft.id), "changed");
    assert.equal(r.library.approvedVariants().length, 2);
    assert.equal(r.service.view().ready, true);
    await r.service.enable(r.service.snapshotHash()); await r.settle();
    assert.equal(r.store.packets()[0]!.status, "submitted_confirmed");
    assert.ok(r.store.packets()[0]!.variantId !== draft.id);
    await r.library.remove(r.library.approvedVariants()[0]!.id);
    assert.equal(r.service.view().ready, false);
    assert.equal(r.service.view().enabled, false);
  } finally { await r.cleanup(); }
});
test("JD-tailored mode generates and submits new artifacts from two templates with immutable provenance", async () => {
  const r = await setup("job-tailored");
  try {
    await r.uploadSlots([1, 3]);
    const originals = await Promise.all(r.library.list().map(async variant => ({ id: variant.id, bytes: await r.library.bytes(variant.id) })));
    await r.service.enable(r.service.snapshotHash()); await r.settle();
    const packet = r.store.packets()[0]!;
    assert.equal(packet.status, "submitted_confirmed", r.service.view().jobs[0]?.reason);
    assert.equal(packet.draft.mode, "jd-tailored");
    assert.equal(packet.artifacts.length, 2);
    assert.equal(packet.tailoring?.baseVariantId, r.library.list().find(variant => variant.slot === 3)!.id);
    assert.ok(packet.submissionArtifactSha256);
    assert.equal(r.browser.fileName, `resume-${packet.id}.pdf`);
    assert.equal(r.engine.submissionArtifact(packet).format, "pdf");
    assert.notEqual(packet.submissionArtifactSha256, packet.tailoring!.baseVariantSha256);
    assert.deepEqual(packet.resumeContent!.facts, packet.draft.factIds.map(id => r.profile.facts.find(fact => fact.id === id)));
    for (const original of originals) assert.deepEqual(await r.library.bytes(original.id), original.bytes);
    const tampered = structuredClone(packet);
    tampered.resumeContent!.facts[0]!.text += " Invented experience.";
    assert.throws(() => r.engine.validate(tampered), /content differs/);
  } finally { await r.cleanup(); }
});
test("JD tailoring emits a compatible DOCX even when the submitted base itself is only a reference", async () => {
  const r = await setup("job-tailored");
  try {
    await r.uploadSlots([1, 3]);
    r.browser.snapshot.fields.find(field => field.key === "resume")!.accept = [".docx"];
    r.browser.snapshot.fingerprint = snapshotHash(r.browser.snapshot);
    await r.service.enable(r.service.snapshotHash()); await r.settle();
    const packet = r.store.packets()[0]!;
    assert.equal(packet.status, "submitted_confirmed", r.service.view().jobs[0]?.reason);
    assert.equal(r.browser.fileName, `resume-${packet.id}.docx`);
    assert.equal(r.engine.submissionArtifact(packet).format, "docx");
    assert.notEqual(packet.submissionArtifactSha256, packet.tailoring!.baseVariantSha256);
  } finally { await r.cleanup(); }
});
test("standing authorization selects the correct untouched variant and records an actual driver receipt", async () => {
  const r = await setup();
  try {
    await r.uploadFour();
    await r.service.enable(r.service.snapshotHash());
    await r.settle();
    assert.equal(r.browser.inspected, 1); assert.equal(r.browser.submitted, 1);
    assert.equal(r.browser.fileName, "data.docx");
    const packet = r.store.packets()[0]!;
    assert.equal(packet.draft.mode, "uploaded-variant");
    assert.equal(packet.approvedBy, "autopilot");
    assert.equal(packet.status, "submitted_confirmed");
    assert.equal(packet.artifacts.length, 1);
    assert.equal((await stat(r.library.path(packet.variantId!))).ino, (await stat(join(r.engine.directory(packet.id), packet.artifacts[0]!.filename))).ino);
    assert.ok(packet.authorizationId);
    assert.equal(r.store.confirmedCount(), 1);
    assert.throws(() => r.service.retry(r.service.view().jobs[0]!.id), /cannot be automatically retried/);
  } finally { await r.cleanup(); }
});
test("current-page assistance is never swept into standing auto-apply without an explicit queue action", async () => {
  const r = await setup();
  try {
    await r.uploadSlots([1, 3]);
    r.store.db.exec("CREATE TABLE assistance_records(id TEXT PRIMARY KEY,json TEXT NOT NULL)");
    r.store.db.prepare("INSERT INTO assistance_records VALUES(?,?)").run("assist-record", JSON.stringify({ jobId: r.job.id, status: "prepared" }));
    await r.service.enable(r.service.snapshotHash()); await r.settle();
    assert.equal(r.browser.inspected, 0);
    assert.equal(r.browser.submitted, 0);
    assert.match(r.service.view().jobs[0]!.reason!, /filling this role in your own Chrome/);
    assert.equal(r.store.confirmedCount(), 0);
  } finally { await r.cleanup(); }
});
test("browser assistance ownership is rechecked at the final automatic transmission boundary", async () => {
  const r = await setup();
  try {
    await r.uploadSlots([1, 3]);
    r.store.db.exec("CREATE TABLE assistance_records(id TEXT PRIMARY KEY,json TEXT NOT NULL)");
    r.browser.onSubmit = async input => {
      r.store.db.prepare("INSERT INTO assistance_records VALUES(?,?)").run("assist-record", JSON.stringify({ jobId: r.job.id, status: "manual_required" }));
      assert.equal(await input.checkAuthorization(), false);
      await assert.rejects(input.beforeSubmit(), /Browser assistance owns/);
      return { status: "needs_input", reason: "Explicit browser assistance now owns the job." };
    };
    await r.service.enable(r.service.snapshotHash()); await r.settle();
    assert.equal(r.store.confirmedCount(), 0);
    assert.ok(!r.store.packets().some(packet => packet.status === "submitted_confirmed"));
  } finally { await r.cleanup(); }
});
test("required unknown questions pause without transmitting data or consuming a submission attempt", async () => {
  const r = await setup();
  try {
    await r.uploadFour();
    r.browser.snapshot.fields.push({ key: "unknown", label: "Describe your experience with our custom proprietary system", type: "textarea", required: true, options: [] });
    r.browser.snapshot.fingerprint = snapshotHash(r.browser.snapshot);
    await r.service.enable(r.service.snapshotHash()); await r.settle();
    assert.equal(r.service.view().jobs[0]!.status, "needs_input");
    assert.equal(r.browser.submitted, 0); assert.equal(r.store.packets().length, 0);
    assert.equal(r.store.attemptsSession(), 0);
  } finally { await r.cleanup(); }
});
test("profile changes invalidate standing authority and uncertain submissions never retry", async () => {
  const r = await setup();
  try {
    await r.uploadFour();
    r.browser.outcome = "submission_unknown";
    await r.service.enable(r.service.snapshotHash()); await r.settle();
    const packet = r.store.packets()[0]!;
    assert.equal(packet.status, "submission_unknown");
    assert.equal(r.store.confirmedCount(), 0);
    assert.throws(() => r.service.retry(r.service.view().jobs[0]!.id), /uncertain outcome/);
    r.store.set("profile", { ...r.profile, version: r.profile.version + 1 });
    assert.equal(r.service.view().enabled, false);
  } finally { await r.cleanup(); }
});
test("no-AI postings remain outside automatic submission regardless of uploaded documents", async () => {
  const r = await setup();
  try {
    await r.uploadFour();
    r.store.saveJob({ ...r.job, aiPolicy: "prohibited" });
    await r.service.enable(r.service.snapshotHash()); await r.settle();
    assert.equal(r.browser.inspected, 0); assert.equal(r.browser.submitted, 0);
    assert.equal(r.service.view().jobs[0]!.status, "skipped");
  } finally { await r.cleanup(); }
});
test("revoking a resume during execution prevents final submission under stale consent", async () => {
  const r = await setup();
  try {
    await r.uploadFour();
    r.browser.onSubmit = async input => {
      r.library.approve(r.library.list()[0]!.id, false);
      assert.equal(await input.checkAuthorization(), false);
      return { status: "cancelled", reason: "User revoked a resume approval before submit." };
    };
    await r.service.enable(r.service.snapshotHash()); await r.settle();
    assert.equal(r.store.confirmedCount(), 0);
    assert.equal(r.service.view().enabled, false);
    assert.equal(r.store.db.prepare("SELECT count(*) AS n FROM events WHERE type='submit_started'").get()?.n, 0);
  } finally { await r.cleanup(); }
});
test("a modified upload cannot activate and a driver cannot confirm before the durable submit boundary", async () => {
  const r = await setup();
  try {
    await r.uploadFour();
    const path = r.library.path(r.library.list()[0]!.id);
    await chmod(path, 0o600); await appendFile(path, "changed");
    await assert.rejects(r.service.enable(r.service.snapshotHash()), /changed on disk/);
    assert.equal(r.browser.inspected, 0);
  } finally { await r.cleanup(); }
  const second = await setup();
  try {
    await second.uploadFour();
    second.browser.onSubmit = async () => ({ status: "submitted_confirmed", reason: "Invalid premature receipt.", evidence: "Not an actual submission." });
    await second.service.enable(second.service.snapshotHash()); await second.settle();
    assert.equal(second.store.confirmedCount(), 0);
    assert.equal(second.service.view().jobs[0]!.status, "failed");
  } finally { await second.cleanup(); }
});

test("roles you pick from Today run first and skip your rule-based filters, but never the safety checks", async () => {
  const r = await setup();
  try {
    await r.uploadSlots([1, 3]);
    assert.throws(() => r.service.prioritize([r.job.id]), /Auto Apply is paused/, "picking needs the standing authorization");
    r.service.setRules({ ...r.service.view().rules, minimumScore: 100 });
    await r.service.enable(r.service.snapshotHash()); await r.settle();
    assert.equal(r.browser.submitted, 0, "under your rules nothing qualifies");
    assert.match(r.service.view().jobs[0]!.reason!, /below your configured 100/);
    const url = `https://jobs.ashbyhq.com/example/${randomUUID()}/application`;
    const noAi = jobFixture({ id: "no-ai", applyUrl: url, canonicalUrl: url, description: "Build pipelines. Do not use AI tools in your application." });
    r.store.saveJob(noAi);
    const result = r.service.prioritize([r.job.id, "missing-job", "no-ai"]);
    assert.deepEqual(result.queued, [r.job.id]);
    assert.deepEqual(result.skipped.map(item => item.jobId), ["missing-job", "no-ai"]);
    assert.match(result.skipped[1]!.reason, /no-AI/);
    await r.settle();
    assert.equal(r.browser.submitted, 1, "the picked role ran despite the minimum score");
    const row = r.service.view().jobs.find(job => job.jobId === r.job.id)!;
    assert.deepEqual([row.status, row.priority], ["submitted_confirmed", true]);
    assert.deepEqual(r.service.prioritize([r.job.id]).skipped.map(item => item.reason), ["Already submitted confirmed."], "a submitted role is never queued again");
  } finally { await r.cleanup(); }
});
