import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Document, Packer, Paragraph } from "docx";
import { createApp } from "../apps/local/server.js";
import { PortalBrowser } from "../packages/automation/portal-browser.js";
import { profileFixture, jobFixture } from "./fixtures.js";

test("generic two-step application uses a compatible tailored resume, parks for HITL and resumes once through authenticated APIs", { timeout: 60000 }, async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-full-portal-"));
  const port = 4355, origin = `http://127.0.0.1:${port}`;
  const driver = new PortalBrowser({ userDataDir: join(dir, "browser"), headless: true, testOrigins: [origin] });
  let discoveryCalls = 0;
  const runtime = await createApp({ dataDir: join(dir, "data"), port, autopilotOptions: {
    browser: driver, allowTestJobs: true, discover: async () => { discoveryCalls++; return "Synthetic preference search finished."; }
  } });
  const uploads: { filename: string; hash: string }[] = [];
  let finalCalls = 0;
  runtime.app.get("/fixture/portal-start", async (_request, reply) => reply.type("text/html").send(`<!doctype html>
    <html><head><meta charset="utf-8"></head><body><h1>Engineering application</h1>
    <form id="application" method="post" action="/fixture/step">
      <label>Full name<input name="full_name" required></label>
      <label>Email address<input name="email" type="email" required></label>
      <label>Resume<input name="resume" type="file" accept=".docx" required></label>
      <button type="submit">Next</button>
    </form><script>
    const form=document.querySelector('form');let step=1;
    form.addEventListener('submit',async e=>{e.preventDefault();
      if(step===1){
        const r=await fetch('/fixture/step',{method:'POST',body:new FormData(form)});if(!r.ok)return;
        step=2;form.action='/fixture/applications';
        form.innerHTML='<label>Preferred project<input name="project" required></label><button type="submit">Submit application</button>';
      }else{
        const r=await fetch('/fixture/applications',{method:'POST',body:new FormData(form)});if(!r.ok)return;
        form.remove();document.body.insertAdjacentHTML('beforeend','<div role="status">Thank you for applying. Your application has been received.</div>');
      }
    });
    </script></body></html>`));
  runtime.app.post("/fixture/step", async request => {
    for await (const part of request.parts()) if (part.type === "file") {
      uploads.push({ filename: part.filename, hash: createHash("sha256").update(await part.toBuffer()).digest("hex") });
    }
    return { received: true };
  });
  runtime.app.post("/fixture/applications", async request => {
    let project = "";
    for await (const part of request.parts()) if (part.type === "field" && part.fieldname === "project") project = String(part.value);
    assert.equal(project, "Data reliability");
    finalCalls++; return { received: true };
  });
  try {
    await runtime.app.listen({ port, host: "127.0.0.1" });
    const profile = profileFixture(); profile.name = "Riley Jordan"; profile.email = "riley.jordan@example.test";
    runtime.store.set("profile", profile);
    runtime.store.saveJob(jobFixture({ applyUrl: `${origin}/fixture/portal-start`, canonicalUrl: `${origin}/fixture/portal-start` }));
    const source = await Packer.toBuffer(new Document({ sections: [{ children: [
      new Paragraph(profile.name), new Paragraph(profile.email), ...profile.facts.map(fact => new Paragraph(fact.text))
    ] }] }));
    for (const slot of [1, 3]) await runtime.library.upload(slot, "data.docx", source, `Data template ${slot}`, ["data"], true);
    runtime.autopilot.start();
    const session = await fetch(`${origin}/api/session`);
    const headers = { cookie: session.headers.get("set-cookie")!.split(";")[0]!, "content-type": "application/json" };
    assert.equal((await fetch(`${origin}/api/monitor/screenshot`)).status, 401);
    const enabled = await fetch(`${origin}/api/autopilot/enable`, { method: "POST", headers, body: JSON.stringify({
      snapshotHash: runtime.autopilot.snapshotHash(), authorizeSubmission: true, confirmAccuracy: true, confirmSiteRules: true
    }) });
    assert.equal(enabled.status, 200, await enabled.text());
    const deadline = Date.now() + 20000;
    while (Date.now() < deadline && !runtime.autopilot.view().humanTasks?.length) await new Promise(resolve => setTimeout(resolve, 100));
    const task = runtime.autopilot.view().humanTasks?.[0];
    assert.ok(task, runtime.autopilot.view().status);
    assert.equal(task.status, "waiting"); assert.equal(finalCalls, 0);
    assert.equal(discoveryCalls, 1);
    assert.equal(uploads.length, 1);
    const packet = runtime.store.packet(task.packetId)!;
    assert.equal(packet.status, "awaiting_human");
    assert.equal(packet.draft.mode, "jd-tailored");
    assert.equal(runtime.engine.submissionArtifact(packet).format, "docx");
    assert.equal(uploads[0]!.hash, packet.submissionArtifactSha256);
    assert.notEqual(uploads[0]!.hash, packet.tailoring!.baseVariantSha256);
    assert.equal(runtime.store.attemptsSession(), 1);
    const screenshot = await fetch(`${origin}/api/monitor/screenshot?sessionId=${task.sessionId}`, { headers });
    assert.equal(screenshot.status, 200);
    assert.equal(Buffer.from(await screenshot.arrayBuffer()).subarray(1, 4).toString(), "PNG");
    const controller = new AbortController();
    const stream = await fetch(`${origin}/api/monitor/events`, { headers, signal: controller.signal });
    assert.equal(stream.status, 200);
    const reader = stream.body!.getReader();
    const first = new TextDecoder().decode((await reader.read()).value);
    assert.ok(first.includes("event: monitor"));
    assert.ok(first.includes("awaiting_human"));
    assert.ok(!first.includes("runToken"));
    controller.abort();
    const continuation = await fetch(`${origin}/api/hitl/${task.id}/continue`, { method: "POST", headers, body: JSON.stringify({
      answers: { project: "Data reliability" }, useCurrentValues: false, confirmReview: true
    }) });
    assert.equal(continuation.status, 200, await continuation.text());
    const end = Date.now() + 20000;
    while (Date.now() < end && runtime.store.confirmedCount() !== 1) await new Promise(resolve => setTimeout(resolve, 100));
    assert.equal(runtime.store.confirmedCount(), 1, runtime.autopilot.view().status);
    assert.equal(finalCalls, 1); assert.equal(uploads.length, 1);
    assert.equal(runtime.store.attemptsSession(), 1);
    assert.equal(runtime.autopilot.view().humanTasks![0]!.status, "resolved");
    assert.ok(runtime.store.packet(packet.id)!.workflowSteps!.some(step => step.humanSupplied && step.answers.project === "Data reliability"));
  } finally { await runtime.app.close(); await rm(dir, { recursive: true, force: true }); }
});

test("full app: the runner fills with the page engine, parks on a CAPTCHA, and submits by itself once you solve it", { timeout: 90000 }, async () => {
  const dir = await mkdtemp(join(tmpdir(), "jaa-captcha-portal-"));
  const port = 4356, origin = `http://127.0.0.1:${port}`;
  const driver = new PortalBrowser({ userDataDir: join(dir, "browser"), headless: true, testOrigins: [origin] });
  const runtime = await createApp({ dataDir: join(dir, "data"), port, autopilotOptions: {
    browser: driver, allowTestJobs: true, discover: async () => "Synthetic preference search finished."
  } });
  const submissions: { name: string; email: string; resume: string }[] = [];
  runtime.app.get("/fixture/application", async (_request, reply) => reply.type("text/html").send(`<!doctype html>
    <html><head><meta charset="utf-8"><title>Data Engineer application</title></head><body><main><h1>Apply for Data Engineer</h1>
    <form id="application-form" method="post" action="/fixture/submit-application">
      <div class="field"><label for="full_name">Full name <span aria-hidden="true">*</span></label><input id="full_name" name="full_name"></div>
      <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" aria-required="true"></div>
      <div class="field"><label>Resume/CV <input id="resume" name="resume" type="file" accept=".pdf,.docx"></label></div>
      <div class="g-recaptcha" data-sitekey="fixture" style="width:304px;height:78px"><textarea name="g-recaptcha-response" style="display:none"></textarea></div>
      <button type="submit">Submit application</button>
    </form></main><script>
    const form = document.getElementById('application-form');
    form.addEventListener('submit', async e => { e.preventDefault();
      const r = await fetch('/fixture/submit-application', { method: 'POST', body: new FormData(form) }); if (!r.ok) return;
      form.remove(); document.body.insertAdjacentHTML('beforeend', '<div role="status">Thank you for applying. Your application has been received.</div>');
    });
    </script></body></html>`));
  runtime.app.post("/fixture/submit-application", async request => {
    const fields: Record<string, string> = {};
    for await (const part of request.parts()) {
      if (part.type === "file") fields.resume = part.filename; else fields[part.fieldname] = String(part.value);
    }
    submissions.push({ name: fields.full_name ?? "", email: fields.email ?? "", resume: fields.resume ?? "" });
    return { received: true };
  });
  try {
    await runtime.app.listen({ port, host: "127.0.0.1" });
    const profile = profileFixture(); profile.name = "Riley Jordan"; profile.email = "riley.jordan@example.test";
    runtime.store.set("profile", profile);
    runtime.store.saveJob(jobFixture({ applyUrl: `${origin}/fixture/application?job=captcha`, canonicalUrl: `${origin}/fixture/application?job=captcha` }));
    const source = await Packer.toBuffer(new Document({ sections: [{ children: [
      new Paragraph(profile.name), new Paragraph(profile.email), ...profile.facts.map(fact => new Paragraph(fact.text))
    ] }] }));
    for (const slot of [1, 3]) await runtime.library.upload(slot, "data.docx", source, `Data template ${slot}`, ["data"], true);
    runtime.autopilot.start();
    const session = await fetch(`${origin}/api/session`);
    const headers = { cookie: session.headers.get("set-cookie")!.split(";")[0]!, "content-type": "application/json" };
    const enabled = await fetch(`${origin}/api/autopilot/enable`, { method: "POST", headers, body: JSON.stringify({
      snapshotHash: runtime.autopilot.snapshotHash(), authorizeSubmission: true, confirmAccuracy: true, confirmSiteRules: true
    }) });
    assert.equal(enabled.status, 200, await enabled.text());
    const deadline = Date.now() + 30000;
    while (Date.now() < deadline && !runtime.autopilot.view().humanTasks?.length) await new Promise(resolve => setTimeout(resolve, 100));
    const task = runtime.autopilot.view().humanTasks?.[0];
    assert.ok(task, runtime.autopilot.view().status);
    assert.equal(task.waitingFor, "captcha", task.reason);
    assert.deepEqual(task.missingFields, []);
    assert.ok(task.filledFields.includes("Full name") && task.filledFields.includes("Resume/CV"), task.filledFields.join(", "));
    assert.equal(submissions.length, 0);
    const internal = driver as unknown as { sessions: Map<string, { page: import("playwright").Page }> };
    const page = internal.sessions.get(task.sessionId)!.page;
    assert.equal(await page.locator("#full_name").inputValue(), "Riley Jordan");
    // You solve the CAPTCHA in the tab; nothing is clicked in Chairman.
    await page.locator('[name="g-recaptcha-response"]').evaluate(e => { (e as HTMLTextAreaElement).value = "fixture-response-token-0123456789abcdef"; });
    const end = Date.now() + 40000;
    while (Date.now() < end && runtime.store.confirmedCount() !== 1) await new Promise(resolve => setTimeout(resolve, 200));
    assert.equal(runtime.store.confirmedCount(), 1, runtime.autopilot.view().status);
    assert.equal(submissions.length, 1);
    assert.deepEqual(submissions[0]!.name, "Riley Jordan");
    assert.match(submissions[0]!.resume, /\.(?:docx|pdf)$/);
    assert.equal(runtime.autopilot.view().humanTasks![0]!.status, "resolved");
    assert.ok(runtime.autopilot.monitor.events().some(event => event.phase === "captcha" && /CAPTCHA solved/.test(event.message)));
  } finally { await runtime.app.close(); await rm(dir, { recursive: true, force: true }); }
});
