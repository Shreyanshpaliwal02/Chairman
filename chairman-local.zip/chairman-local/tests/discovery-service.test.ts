import test from "node:test";
import assert from "node:assert/strict";
import { Store } from "../apps/local/store.js";
import { DiscoveryService } from "../apps/local/discovery-service.js";
import { DiscoveryError } from "../packages/adapters/discovery.js";
import { jobFixture } from "./fixtures.js";

test("local discovery respects source cooldowns and disabled sources without network attempts", async () => {
  const store = new Store(":memory:");
  let calls = 0;
  const service = new DiscoveryService(store, { scanner: async () => { calls++; return { jobs: [jobFixture()], nextCursor: "next" }; } });
  try {
    const first = await service.scan("supabase");
    assert.equal(first.results[0]!.count, 1);
    assert.equal(store.value("cursor:supabase", ""), "next");
    assert.match((await service.scan("supabase")).results[0]!.error!, /cooldown/);
    assert.equal(calls, 1);
    assert.match((await service.scan("linkedin")).results[0]!.error!, /manual-only/);
    assert.equal(calls, 1);
  } finally { store.close(); }
});
test("local write failure preserves the cursor and records an explicit failure", async () => {
  const store = new Store(":memory:");
  store.set("cursor:supabase", "old");
  const service = new DiscoveryService(store, { scanner: async () => ({ jobs: [jobFixture()], nextCursor: "new" }) });
  store.saveJob = () => { throw new Error("Controlled disk write failure"); };
  try {
    const response = await service.scan("supabase");
    assert.match(response.results[0]!.error!, /disk write failure/);
    assert.equal(store.value("cursor:supabase", ""), "old");
    assert.match(service.sources().find(s => s.id === "supabase")!.lastError!, /disk write failure/);
  } finally { store.close(); }
});
test("expired cloud checkpoints restart explicitly and persist bounded pages after local writes", async () => {
  const store = new Store(":memory:");
  const url = "https://job-application-scanner.example.workers.dev";
  store.set(`cloudCursor:${url}`, "99");
  const cursors: (string | undefined)[] = [];
  const service = new DiscoveryService(store, {
    cloudUrl: url, cloudToken: "synthetic-test-token-not-a-real-credential",
    cloudSync: async (_url, _token, cursor) => {
      cursors.push(cursor);
      if (cursor === "99") throw new DiscoveryError("HTTP_ERROR", "Expired cursor", undefined, 409);
      return cursor === undefined ? { jobs: [jobFixture({ sourceId: "supabase" })], nextCursor: "1" } : { jobs: [], nextCursor: "1" };
    },
    scanner: async () => ({ jobs: [] })
  });
  try {
    const result = await service.scan();
    assert.equal(result.results[0]!.count, 1);
    assert.deepEqual(cursors, ["99", undefined, "1"]);
    assert.equal(store.value(`cloudCursor:${url}`, ""), "1");
    assert.equal(store.jobs().length, 1);
    assert.equal(store.db.prepare("SELECT count(*) AS n FROM events WHERE type='cloud_cursor_reset'").get()?.n, 1);
  } finally { store.close(); }
});
test("Retry-After survives into durable local source backoff", async () => {
  const store = new Store(":memory:");
  const start = Date.now();
  const service = new DiscoveryService(store, { scanner: async () => { throw new DiscoveryError("RATE_LIMITED", "Public source request failed.", 600000, 429); } });
  try {
    const result = await service.scan("himalayas");
    assert.match(result.results[0]!.error!, /429/);
    assert.ok(store.value("nextScan:himalayas", 0) >= start + 600000);
  } finally { store.close(); }
});
test("publisher cooldowns survive failures and source permission blocks stop new fetches", async () => {
  const store = new Store(":memory:");
  let calls = 0;
  const service = new DiscoveryService(store, { scanner: async () => {
    calls++; throw new DiscoveryError("HTTP_ERROR", "Source denied access.", undefined, 403);
  } });
  try {
    const start = Date.now();
    await service.scan("remotive");
    assert.ok(store.value("nextScan:remotive", 0) >= start + 6 * 3600_000);
    assert.equal(service.sources().find(source => source.id === "remotive")!.mode, "blocked");
    await service.scan("remotive"); assert.equal(calls, 1);
  } finally { store.close(); }
});
test("ending temporary viewing removes provider descriptions but preserves application history metadata", async () => {
  const store = new Store(":memory:");
  const job = jobFixture({ id: "arbeitnow:temporary", sourceId: "arbeitnow", canonicalUrl: "https://www.arbeitnow.com/jobs/example" });
  store.saveJob(job);
  store.putExternal({ id: "external", jobId: job.id, sourceId: "arbeitnow", submittedDate: "2026-09-14",
    confirmation: "User-reported synthetic receipt.", createdAt: new Date().toISOString(),
    progress: { stage: "applied", note: "", updatedAt: new Date().toISOString() } });
  const service = new DiscoveryService(store);
  try {
    await service.stop();
    assert.equal(store.job(job.id)!.description, "");
    assert.equal(store.job(job.id)!.cacheExpired, true);
    assert.equal(store.job(job.id)!.status, "open");
    assert.equal(store.externalApplications().length, 1);
  } finally { store.close(); }
});
