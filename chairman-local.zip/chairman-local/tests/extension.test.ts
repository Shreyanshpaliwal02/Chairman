import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { createServer } from "node:http";
import { existsSync } from "node:fs";
import { mkdir, rm } from "node:fs/promises";
import { resolve } from "node:path";
import { build } from "esbuild";
import { chromium, type BrowserContext } from "@playwright/test";
import type { FormSnapshot, Job, Packet } from "../packages/domain/types";
import { ExtensionController, recoveryReport, type ControllerPorts } from "../apps/extension/controller";
import { readFixtureReceipt } from "../apps/extension/receipt";
import type { Claim, PageCommand, PendingRun, QueueResponse, RunReport } from "../apps/extension/contracts";
import { assertApprovedSnapshot, assertExactDestination, assertFillPlan, decodeResume, destination, fingerprint, isFixtureReceipt, localApiOrigin, permissionFor, snapshotPayload } from "../apps/extension/safety";

const fixtureUrl = "http://127.0.0.1:4318/fixture/application";
const resume = { filename: "approved-fixture.pdf", mime: "application/pdf", base64: Buffer.from("%PDF-1.4 local fixture only").toString("base64") };
const fileBytes = Buffer.from(resume.base64, "base64");

async function snapshot(): Promise<FormSnapshot> {
  const structure = {
    url: fixtureUrl,
    fields: [
      { key: "name", label: "Full name", type: "text", required: true, options: [] },
      { key: "resume", label: "Resume", type: "file", required: true, options: [] }
    ],
    hasCaptcha: false, hasLegal: false, unsupported: []
  };
  return { ...structure, fingerprint: await fingerprint(structure) };
}

async function harness(options: {
  permitted?: boolean; stopped?: boolean; url?: string; pageFail?: string; noReceipt?: boolean;
  changeSnapshot?: boolean; claimLost?: boolean; stopAfter?: string; reportFails?: boolean; fixtureReceipt?: string;
} = {}) {
  const formSnapshot = await snapshot();
  const job: Job = {
    id: "fixture-job", sourceId: "fixture", sourceJobId: "one", title: "Fixture role", company: "Local fixture",
    location: "India", remote: true, countries: ["India"], employmentType: "full_time", description: "Controlled fixture",
    applyUrl: options.url ?? fixtureUrl, canonicalUrl: fixtureUrl, fetchedAt: new Date().toISOString(),
    salary: null, language: "English", sponsorship: "unknown", aiPolicy: "allowed", status: "open"
  };
  const packet: Packet = {
    id: "packet", jobId: job.id, jobHash: "jobhash", profileHash: "profilehash", profileVersion: 1,
    draft: { factIds: [], skills: [], mode: "deterministic", notes: [] },
    artifacts: [{ format: "pdf", filename: resume.filename, sha256: createHash("sha256").update(fileBytes).digest("hex"), bytes: fileBytes.length }],
    answers: { name: "Fixture applicant" }, warnings: [], status: "approved", createdAt: new Date().toISOString(),
    approvalHash: "immutable-approval", formSnapshot
  };
  let pending: PendingRun | undefined;
  let stopped = options.stopped ?? false;
  const commands: PageCommand[] = [];
  const reports: RunReport[] = [];
  const calls: string[] = [];
  const ports: ControllerPorts = {
    api: async <T>(path: string, body?: unknown): Promise<T> => {
      calls.push(path);
      if (path.endsWith("/jobs")) return {
        stopped, items: [{ packet: structuredClone(packet), job, automationAllowed: options.permitted ?? true }]
      } as T;
      if (path.endsWith("/claim")) {
        packet.status = "executing";
        if (options.claimLost) throw new Error("Claim receipt lost");
        return { packet: structuredClone(packet), job, fields: { name: "Fixture applicant" }, resume, runToken: "run-receipt" } satisfies Claim as T;
      }
      if (path.endsWith("/report")) {
        if (options.reportFails) throw new Error("Report unavailable");
        reports.push(body as RunReport);
        return { ok: true } as T;
      }
      if (path.endsWith("/preflight")) return { packet } as T;
      throw new Error(`Unexpected endpoint: ${path}`);
    },
    getPending: async () => pending,
    setPending: async (value) => { pending = structuredClone(value); },
    clearPending: async () => { pending = undefined; },
    hasToken: async () => true,
    activeTab: async () => 42,
    open: async () => { calls.push("open"); },
    inject: async () => { calls.push("inject"); return "doc-1"; },
    page: async (_tabId, _documentId, command) => {
      commands.push(command);
      if (options.stopAfter === command.action) stopped = true;
      if (options.pageFail === command.action) throw new Error("Page context lost");
      if (command.action === "snapshot") {
        const current = structuredClone(formSnapshot);
        if (options.changeSnapshot) {
          current.fields[0].required = false;
          current.fingerprint = await fingerprint(current);
        }
        return { snapshot: current };
      }
      if (command.action === "submit") return options.noReceipt ? {} : { confirmation: "Controlled fixture receipt: test-receipt" };
      return {};
    },
    ...(options.fixtureReceipt ? { fixtureConfirmation: async () => options.fixtureReceipt } : {})
  };
  return { controller: new ExtensionController(ports), ports, packet, commands, reports, calls, pending: () => pending };
}

test("extension destination guards reject restricted hosts, unsafe URLs, and nonexact job pages", () => {
  for (const url of [
    "https://linkedin.com/jobs", "https://www.linkedin.com/jobs", "https://lnkd.in/id",
    "https://jobs.wellfound.com/apply", "https://angel.co/jobs", "https://apply.naukri.com/job",
    "https://LINKEDIN.COM/jobs", "https://linkedin.com./jobs", "http://careers.example.com/apply",
    "https://localhost/apply", "https://127.0.0.1/apply", "https://[::1]/apply",
    "https://name:password@careers.example.com/apply", "https://careers.example.com/apply#another-step",
    "https://careers.example.com:8443/apply", "http://127.0.0.1:4318/other"
  ]) assert.throws(() => destination(url), url);
  assert.equal(permissionFor("https://careers.example.com/job/123?source=one"), "https://careers.example.com/*");
  assert.equal(permissionFor(fixtureUrl), "http://127.0.0.1/*");
  assert.throws(() => assertExactDestination(`${fixtureUrl}?other=job`, fixtureUrl));
  assert.throws(() => assertExactDestination(undefined, fixtureUrl));
  assertExactDestination(fixtureUrl, fixtureUrl);
  assert.equal(localApiOrigin(4518), "http://127.0.0.1:4518");
  assert.throws(() => localApiOrigin(80));
  assert.throws(() => localApiOrigin(65536));
  assert.equal(isFixtureReceipt("http://127.0.0.1:4318/fixture/confirmation?id=receipt-1", fixtureUrl), true);
  assert.equal(isFixtureReceipt("https://example.com/fixture/confirmation?id=receipt-1", fixtureUrl), false);
  assert.equal(isFixtureReceipt("http://127.0.0.1:4518/fixture/confirmation?id=receipt-1", fixtureUrl), false);
  assert.equal(isFixtureReceipt("http://127.0.0.1:4318/fixture/confirmation?id=receipt-1&id=other", fixtureUrl), false);
});

test("canonical snapshot hash uses exact property order and excludes current values/fingerprint", async () => {
  const form = await snapshot();
  const canonical = '{"url":"http://127.0.0.1:4318/fixture/application","fields":[{"key":"name","label":"Full name","type":"text","required":true,"options":[]},{"key":"resume","label":"Resume","type":"file","required":true,"options":[]}],"hasCaptcha":false,"hasLegal":false,"unsupported":[]}';
  assert.equal(snapshotPayload(form), canonical);
  assert.equal(form.fingerprint, createHash("sha256").update(canonical, "utf8").digest("hex"));
  assert.equal(await fingerprint({ ...form, fingerprint: "not-hashed" }), form.fingerprint);
  await assertApprovedSnapshot(form, form);
  for (const changed of [
    { ...form, fields: [...form.fields].reverse() }, { ...form, hasCaptcha: true }, { ...form, hasLegal: true },
    { ...form, unsupported: ["New requirement"] }, { ...form, url: `${fixtureUrl}?changed=1` }
  ]) await assert.rejects(assertApprovedSnapshot({ ...changed, fingerprint: await fingerprint(changed) }, form));
});

test("fill plan requires every confirmed answer, exact available options, and one actual resume", async () => {
  const form = await snapshot();
  assert.doesNotThrow(() => assertFillPlan(form, { name: "Fixture applicant" }, resume));
  assert.throws(() => assertFillPlan(form, {}, resume), /confirmed answer/);
  assert.throws(() => assertFillPlan(form, { name: "Fixture", unexpected: "guessed" }, resume), /mapping/);
  const select = { ...form, fields: [{ ...form.fields[0], type: "select", options: ["India"] }, form.fields[1]] };
  assert.throws(() => assertFillPlan(select, { name: "United States" }, resume), /option/);
  assert.throws(() => decodeResume({ ...resume, filename: "../resume.pdf" }));
  assert.throws(() => decodeResume({ ...resume, base64: Buffer.from("not a PDF").toString("base64") }));
  assert.throws(() => decodeResume({ ...resume, base64: "" }));
});

test("policy/Stop/restricted host gates run before injection or claims", async () => {
  for (const settings of [{ permitted: false }, { stopped: true }, { url: "https://www.linkedin.com/jobs/123" }, { url: "http://127.0.0.1:4518/fixture/application" }]) {
    const run = await harness(settings);
    await assert.rejects(run.controller.preflight("packet"));
    await assert.rejects(run.controller.execute("packet"));
    assert.equal(run.calls.includes("inject"), false);
    assert.equal(run.calls.includes("/api/extension/claim"), false);
  }
});

test("preflight attaches structure only and never claims or fills", async () => {
  const run = await harness();
  run.packet.status = "prepared";
  await run.controller.preflight("packet");
  assert.deepEqual(run.commands.map((command) => command.action), ["snapshot"]);
  assert.ok(run.calls.includes("/api/extension/preflight"));
  assert.equal(run.calls.includes("/api/extension/claim"), false);
});

test("an altered form aborts before claim", async () => {
  const run = await harness({ changeSnapshot: true });
  await assert.rejects(run.controller.execute("packet"), /changed/);
  assert.equal(run.calls.includes("/api/extension/claim"), false);
  assert.equal(run.pending(), undefined);
});

test("approved execution fills, verifies, submits once, and records explicit confirmation", async () => {
  const run = await harness();
  await run.controller.execute("packet");
  assert.deepEqual(run.commands.map((command) => command.action), ["snapshot", "snapshot", "fill", "attach", "verify", "submit"]);
  assert.equal(run.reports.length, 1);
  assert.equal(run.reports[0].outcome, "submitted_confirmed");
  assert.equal(run.pending(), undefined);
  await assert.rejects(run.controller.execute("packet"), /approved/);
  assert.equal(run.commands.filter((command) => command.action === "submit").length, 1);
});

test("Stop prevents the next browser action", async () => {
  const run = await harness({ stopAfter: "fill" });
  await run.controller.execute("packet");
  assert.equal(run.commands.some((command) => command.action === "attach" || command.action === "submit"), false);
  assert.equal(run.reports[0].outcome, "failed");
});

test("context loss or absent receipt after possible submit is unknown and never retried", async () => {
  for (const settings of [{ pageFail: "submit" }, { noReceipt: true }]) {
    const run = await harness(settings);
    await run.controller.execute("packet");
    assert.equal(run.reports[0].outcome, "submission_unknown");
    assert.equal(run.commands.filter((command) => command.action === "submit").length, 1);
  }
});

test("only the reviewed fixture redirect may reconcile a lost submit context with explicit receipt", async () => {
  const run = await harness({ pageFail: "submit", fixtureReceipt: "Controlled fixture receipt: fixture-redirect" });
  await run.controller.execute("packet");
  assert.equal(run.reports[0].outcome, "submitted_confirmed");
  assert.equal(run.reports[0].confirmation, "Controlled fixture receipt: fixture-redirect");
  assert.equal(run.commands.filter((command) => command.action === "submit").length, 1);
});

test("lost claims and reports persist a blocker; worker recovery reports unknown without page actions", async () => {
  const lostClaim = await harness({ claimLost: true });
  await assert.rejects(lostClaim.controller.execute("packet"), /Claim outcome unknown/);
  assert.equal(lostClaim.pending()?.phase, "claiming");
  await lostClaim.controller.recover();
  await assert.rejects(lostClaim.controller.execute("packet"), /reconciled/);
  assert.equal(lostClaim.calls.filter((path) => path.endsWith("/claim")).length, 1);
  assert.equal(recoveryReport(lostClaim.pending()!), undefined);
  lostClaim.packet.status = "submission_unknown";
  await lostClaim.controller.recover();
  assert.equal(lostClaim.pending(), undefined);

  const lostReport = await harness({ reportFails: true });
  await assert.rejects(lostReport.controller.execute("packet"), /Report unavailable/);
  assert.equal(lostReport.pending()?.phase, "submitting");
  const count = lostReport.commands.length;
  const restartedPorts = { ...lostReport.ports, api: async <T>(path: string, body?: unknown) => {
    assert.equal(path, "/api/extension/report");
    assert.equal((body as RunReport).outcome, "submission_unknown");
    return {} as T;
  } };
  await new ExtensionController(restartedPorts).recover();
  assert.equal(lostReport.commands.length, count);
  assert.equal(lostReport.pending(), undefined);
});

test("missing server Stop state fails closed", async () => {
  const run = await harness();
  const ports = { ...run.ports, api: async <T>() => ({ items: [] }) as T };
  await assert.rejects(new ExtensionController(ports).state(), /Stop state/);
});

test("controlled local browser form: metadata only, setters, upload acknowledgement, blockers and receipt", async (t) => {
  const browserDir = resolve("apps/extension/.test-browser");
  const runtimeDir = resolve("apps/extension/.test-runtime");
  await mkdir(runtimeDir, { recursive: true });
  let context: BrowserContext | undefined;
  try {
    context = await chromium.launchPersistentContext(browserDir, {
      headless: true, ...(existsSync(chromium.executablePath()) ? {} : { channel: "chrome" }),
      env: { ...process.env, TMPDIR: runtimeDir, TEMP: runtimeDir, TMP: runtimeDir }
    });
    const bundle = await build({
      entryPoints: [resolve("apps/extension/form.ts")], bundle: true, write: false, format: "iife",
      globalName: "JaaForm", platform: "browser", target: "chrome120"
    });
    const script = bundle.outputFiles[0].text;
    const html = `<!doctype html><html><body>
      <form method="post" action="/fixture/submit" enctype="multipart/form-data">
        <label for="name">Full name</label><input id="name" name="name" required value="DO_NOT_CAPTURE_ME">
        <label for="country">Country</label><select name="country" id="country"><option value="in">India</option><option value="us">United States</option></select>
        <label for="resume">Resume</label><input type="file" name="resume" id="resume" accept=".pdf" required>
        <output id="jaa-resume-accepted"></output><button type="submit">Submit application</button>
      </form><div id="receipt"></div>
      <script>
        window.changeEvents = [];
        document.querySelector('form').addEventListener('input', e => window.changeEvents.push('input:' + e.target.name));
        document.querySelector('form').addEventListener('change', e => window.changeEvents.push('change:' + e.target.name));
        document.querySelector('#resume').addEventListener('change', e => {
          const file = e.target.files[0], marker = document.querySelector('#jaa-resume-accepted');
          if (file) { marker.dataset.filename = file.name; marker.dataset.bytes = String(file.size); marker.textContent = 'Resume attached'; }
        });
        document.querySelector('form').addEventListener('submit', e => {
          e.preventDefault();
          history.replaceState({}, "", "/fixture/confirmation?id=fixture-123");
          document.querySelector('#receipt').innerHTML = '<main data-jaa-submitted="true" data-confirmation-id="fixture-123">Application received</main>';
        });
      </script></body></html>`;
    const page = await context.newPage();
    await page.route("**/*", (route) => route.request().url() === fixtureUrl
      ? route.fulfill({ contentType: "text/html", body: html }) : route.abort());
    const reset = async () => {
      await page.goto(fixtureUrl);
      await page.addScriptTag({ content: script });
    };
    const evaluate = async <T>(code: string) => page.evaluate(code) as Promise<T>;
    await reset();
    const form = await evaluate<FormSnapshot>("JaaForm.inspectForm(document, location.href)");
    assert.deepEqual(form.unsupported, []);
    assert.equal(JSON.stringify(form).includes("DO_NOT_CAPTURE_ME"), false);
    assert.deepEqual(Object.keys(form).sort(), ["fields", "fingerprint", "hasCaptcha", "hasLegal", "unsupported", "url"]);
    assert.equal(form.fingerprint, await fingerprint(form));
    const send = (command: PageCommand) => evaluate(`JaaForm.handlePageCommand(document, ${JSON.stringify(command)})`);
    await send({ action: "fill", url: fixtureUrl, fingerprint: form.fingerprint, key: "name", value: "Fixture applicant" });
    await send({ action: "fill", url: fixtureUrl, fingerprint: form.fingerprint, key: "country", value: "us" });
    assert.deepEqual(await evaluate<string[]>("window.changeEvents"), ["input:name", "change:name", "input:country", "change:country"]);
    await send({ action: "attach", url: fixtureUrl, fingerprint: form.fingerprint, resume });
    const verify = { url: fixtureUrl, fingerprint: form.fingerprint, fields: { name: "Fixture applicant", country: "us" }, resume };
    await send({ action: "verify", ...verify });
    const result = await send({ action: "submit", ...verify });
    assert.deepEqual(result, { confirmation: "Controlled fixture receipt: fixture-123" });
    await assert.rejects(send({ action: "submit", ...verify }), /exact approved/);

    await t.test("native multipart POST redirects to the backend's exact trusted fixture marker", async () => {
      const native = await context!.newPage();
      let posts = 0;
      let payload = "";
      const server = createServer((request, response) => {
        if (request.url === "/fixture/application" && request.method === "GET") {
          response.writeHead(200, { "Content-Type": "text/html" }).end(`<form method="post" action="/fixture/submit" enctype="multipart/form-data">
            <label>Full name<input name="full_name" id="full_name" required></label>
            <label>Email<input type="email" name="email" id="email" required></label>
            <label>Phone<input type="tel" name="phone" id="phone"></label>
            <label>Relevant experience<textarea name="experience" id="experience" required></textarea></label>
            <label>Resume<input type="file" name="resume" id="resume" accept=".pdf" required></label>
            <button type="submit">Submit application</button></form>`);
        } else if (request.url === "/fixture/submit" && request.method === "POST") {
          posts++;
          request.on("data", (chunk: Buffer) => { payload += chunk.toString(); });
          request.on("end", () => response.writeHead(303, { Location: "/fixture/confirmation?id=native-fixture" }).end());
        } else if (request.url === "/fixture/confirmation?id=native-fixture") {
          response.writeHead(200, { "Content-Type": "text/html" })
            .end('<main data-jaa-submitted="true" data-confirmation-id="native-fixture">Application submitted</main>');
        } else response.writeHead(404).end();
      });
      await new Promise<void>((resolve, reject) => { server.once("error", reject); server.listen(0, "127.0.0.1", resolve); });
      const address = server.address();
      assert.ok(address && typeof address !== "string");
      const applicationUrl = `http://127.0.0.1:${address.port}/fixture/application`;
      const receiptUrl = `http://127.0.0.1:${address.port}/fixture/confirmation?id=native-fixture`;
      try {
      await native.goto(applicationUrl);
      await native.addScriptTag({ content: script });
      const structure = await native.evaluate("JaaForm.inspectForm(document, location.href)") as FormSnapshot;
      assert.deepEqual(structure.unsupported, []);
      const nativeSend = (command: PageCommand) => native.evaluate(`JaaForm.handlePageCommand(document, ${JSON.stringify(command)})`);
      const common = { url: applicationUrl, fingerprint: structure.fingerprint };
      const fields = { full_name: "Native fixture", email: "fixture@example.invalid", phone: "", experience: "Controlled fixture only" };
      for (const [key, value] of Object.entries(fields)) await nativeSend({ action: "fill", ...common, key, value });
      await nativeSend({ action: "attach", ...common, resume });
      await nativeSend({ action: "verify", ...common, fields, resume });
      await nativeSend({ action: "submit", ...common, fields, resume }).catch((error: Error) => {
        assert.match(error.message, /context was destroyed|navigation/i);
      });
      await native.waitForURL(receiptUrl);
      await native.waitForSelector('main[data-jaa-submitted="true"]');
      assert.equal(await native.evaluate(readFixtureReceipt, applicationUrl), "Controlled fixture receipt: native-fixture");
      assert.equal(await native.evaluate(readFixtureReceipt, "https://example.com/fixture/application"), undefined);
      await native.locator("main").evaluate((marker) => marker.setAttribute("data-confirmation-id", "wrong-receipt"));
      assert.equal(await native.evaluate(readFixtureReceipt, applicationUrl), undefined);
      assert.equal(posts, 1);
      assert.match(payload, /name="full_name"/);
      assert.match(payload, /Native fixture/);
      assert.match(payload, /filename="approved-fixture.pdf"/);
      assert.ok(payload.includes(fileBytes.toString()));
      } finally {
        await native.close().catch(() => {});
        server.closeAllConnections();
        await new Promise<void>((resolve) => server.close(() => resolve()));
      }
      await page.bringToFront();
    });

    await t.test("conditional questions abort without a second field transmission", async () => {
      await reset();
      await page.evaluate(() => {
        document.getElementById("name")!.addEventListener("change", () => {
          const extra = document.createElement("input");
          extra.name = "newQuestion";
          extra.setAttribute("aria-label", "New question");
          document.querySelector("form")!.append(extra);
        });
      });
      await assert.rejects(send({ action: "fill", url: fixtureUrl, fingerprint: form.fingerprint, key: "name", value: "Fixture" }), /changed/);
    });
    await t.test("application state rejecting an input pauses instead of claiming acceptance", async () => {
      await reset();
      await page.evaluate(() => document.getElementById("name")!.addEventListener("change", (event) => {
        (event.target as HTMLInputElement).value = "state rejected";
      }));
      await assert.rejects(send({ action: "fill", url: fixtureUrl, fingerprint: form.fingerprint, key: "name", value: "Fixture" }), /retain/);
    });
    await t.test("React-controlled values and file state retain the exact approved packet", async () => {
      await reset();
      await page.evaluate(() => { document.body.innerHTML = '<div id="root"></div>'; });
      const reactFixture = await build({
        stdin: {
          contents: `
            import {createElement as h, useState} from "react";
            import {createRoot} from "react-dom/client";
            function Fixture() {
              const [name, setName] = useState("");
              const [file, setFile] = useState(null);
              const [receipt, setReceipt] = useState(false);
              return h("form", {method:"post", action:"/fixture/submit", encType:"multipart/form-data", onSubmit(event) {
                event.preventDefault();
                if (name === "React fixture" && file?.name === "approved-fixture.pdf") {
                  history.replaceState({}, "", "/fixture/confirmation?id=react-fixture");
                  setReceipt(true);
                }
              }},
                h("label", null, "Full name", h("input", {name:"name", required:true, value:name, onChange:event=>setName(event.target.value)})),
                h("label", null, "Resume", h("input", {name:"resume", type:"file", required:true, accept:".pdf", onChange:event=>setFile(event.target.files[0])})),
                h("output", {id:"react-state"}, name),
                file ? h("output", {id:"jaa-resume-accepted", "data-filename":file.name, "data-bytes":file.size}, "Resume attached") : null,
                h("button", {type:"submit"}, "Submit application"),
                receipt ? h("main", {"data-jaa-submitted":"true", "data-confirmation-id":"react-fixture"}, "Received") : null
              );
            }
            createRoot(document.getElementById("root")).render(h(Fixture));
          `,
          resolveDir: process.cwd()
        },
        bundle: true, write: false, platform: "browser", format: "iife", define: { "process.env.NODE_ENV": '"production"' }
      });
      await page.addScriptTag({ content: reactFixture.outputFiles[0].text });
      await page.waitForSelector("form");
      const reactForm = await evaluate<FormSnapshot>("JaaForm.inspectForm(document, location.href)");
      assert.deepEqual(reactForm.unsupported, []);
      const common = { url: fixtureUrl, fingerprint: reactForm.fingerprint };
      await send({ action: "fill", ...common, key: "name", value: "React fixture" });
      assert.equal(await page.locator("#react-state").textContent(), "React fixture");
      await send({ action: "attach", ...common, resume });
      assert.deepEqual(await send({ action: "submit", ...common, fields: { name: "React fixture" }, resume }), {
        confirmation: "Controlled fixture receipt: react-fixture"
      });
    });
    await t.test("an inconsistent application upload acknowledgement blocks submission", async () => {
      await reset();
      await page.evaluate(() => document.getElementById("resume")!.addEventListener("change", () => {
        document.getElementById("jaa-resume-accepted")!.removeAttribute("data-filename");
      }));
      await assert.rejects(send({ action: "attach", url: fixtureUrl, fingerprint: form.fingerprint, resume }), /acknowledged/);
    });
    await t.test("duplicate identifiers, frames, legal language, AI restrictions and custom controls block", async () => {
      for (const mutation of [
        `document.querySelector('form').insertAdjacentHTML('beforeend', '<label>Name<input name="name"></label>')`,
        `document.querySelector('form').insertAdjacentHTML('beforeend', '<iframe src="about:blank"></iframe>')`,
        `document.querySelector('form').insertAdjacentHTML('beforeend', '<label><input type="checkbox" name="terms">I agree to the terms of service</label>')`,
        `document.querySelector('form').insertAdjacentHTML('beforeend', '<p>Do not use AI in this application. Use your own words.</p>')`,
        `document.querySelector('form').insertAdjacentHTML('beforeend', '<div role="combobox" aria-label="Country"></div>')`,
        `document.querySelector('form').insertAdjacentHTML('beforeend', '<input type="hidden" name="hiddenAnswer" value="DO_NOT_CAPTURE_ME">')`,
        `document.querySelector('form').insertAdjacentHTML('beforeend', '<p>Step 1 of 3</p>')`,
        `document.querySelector('form').insertAdjacentHTML('beforeend', '<div class="g-recaptcha"></div>')`
      ]) {
        await reset();
        await evaluate(mutation);
        const blocked = await evaluate<FormSnapshot>("JaaForm.inspectForm(document, location.href)");
        assert.ok(blocked.unsupported.length || blocked.hasLegal || blocked.hasCaptcha, mutation);
      }
    });
    await t.test("arbitrary success text is not evidence", async () => {
      await reset();
      await page.evaluate(() => document.body.append(document.createTextNode("Success! Your application is submitted.")));
      assert.equal(await evaluate("JaaForm.confirmationEvidence(document, location.href)"), undefined);
    });
    await t.test("expired operations and concurrent structural changes cannot authorize a click", async () => {
      await reset();
      await assert.rejects(send({ action: "fill", url: fixtureUrl, fingerprint: form.fingerprint, key: "name", value: "Fixture", expiresAt: 1 }), /expired/);
      await assert.rejects(evaluate(`(() => {
        const pending = JaaForm.inspectForm(document, location.href);
        document.getElementById("name").required = false;
        return pending;
      })()`), /changed/);
    });
  } finally {
    await context?.close();
    await rm(browserDir, { recursive: true, force: true });
    await rm(runtimeDir, { recursive: true, force: true });
  }
});
