import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "../apps/local/server.js";
import { QuestionInbox } from "../apps/local/progress.js";
import { jobFixture } from "./fixtures.js";
import type { CareerBoardTarget } from "../packages/domain/types.js";
import type { ProgressView } from "../packages/domain/progress.js";
import type { RoleFamily } from "../packages/domain/role-families.js";

const UUID = (n: number) => `12345678-1234-1234-1234-12345678900${n}`;

test("Progress: companies with role families, relevance, per-application status, role-family edits, and the answer bank import/export", async () => {
  const directory = await mkdtemp(join(tmpdir(), "jaa-progress-api-"));
  const target: CareerBoardTarget = { provider: "ashby", board: "example", boardUrl: "https://jobs.ashbyhq.com/example" };
  const job = (n: number, title: string, description: string, sourceId: string) => jobFixture({ id: `progress-${n}`, title, description, company: "Example", sourceId,
    applyUrl: `https://jobs.ashbyhq.com/example/${UUID(n)}/application`, canonicalUrl: `https://jobs.ashbyhq.com/example/${UUID(n)}` });
  const runtime = await createApp({ dataDir: directory, port: 4342, careerOptions: {
    resolve: async () => ({ target, candidates: [target], message: "Known public board." }),
    scan: async (_target, sourceId) => ({ jobs: [
      job(1, "Senior Data Engineer", "Build streaming pipelines with Spark, Kafka and SQL on AWS.", sourceId),
      job(2, "Account Executive", "Own enterprise sales for data products.", sourceId),
      job(3, "Machine Learning Engineer", "Train machine learning models with PyTorch and Python; deploy LLM services.", sourceId),
    ] }),
  } });
  const { app, store } = runtime, host = { host: "127.0.0.1:4342" };
  try {
    const session = await app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = session.cookies[0]!, headers = { ...host, cookie: `${cookie.name}=${cookie.value}` };
    const call = async (method: "GET" | "POST", url: string, payload?: unknown) => {
      const response = await app.inject({ method, url, headers, ...(payload === undefined ? {} : { payload: payload as object }) });
      return { status: response.statusCode, body: response.body, json: () => response.json() };
    };
    assert.equal((await app.inject({ method: "GET", url: "/api/progress", headers: host })).statusCode, 401, "Progress needs the dashboard session");

    const added = await call("POST", "/api/companies", { url: target.boardUrl, company: "Example Corp", roleFamilies: [] });
    assert.equal(added.status, 200, added.body);
    const sourceId = added.json().source.id as string;
    for (let n = 0; n < 200 && !runtime.careerSources.get(sourceId).lastScannedAt; n++) await new Promise(resolve => setTimeout(resolve, 5));
    let view = (await call("GET", "/api/progress")).json() as ProgressView;
    assert.equal(view.companies.length, 1);
    const status = (title: string) => view.companies[0]!.jobs.find(item => item.title === title)!;
    assert.equal(view.companies[0]!.company, "Example Corp");
    assert.equal(status("Senior Data Engineer").status, "not_applied", "data engineering is an always-apply family");
    assert.equal(status("Senior Data Engineer").classification.familyId, "data-engineering");
    assert.ok(status("Senior Data Engineer").classification.matchedSkills.includes("spark"));
    assert.equal(status("Account Executive").status, "not_relevant");
    assert.equal(status("Machine Learning Engineer").status, "not_relevant", "AI/ML is not picked for this company yet");
    assert.deepEqual([view.totals.not_applied, view.totals.not_relevant, view.totals.total], [1, 2, 3]);
    // Rows carry what the Progress filters need: countries, remote, required years and the posting's department.
    const row = view.companies[0]!.jobs[0]!;
    assert.ok(Array.isArray(row.countries) && typeof row.remote === "boolean");
    assert.equal(view.totals.marked, 0);

    assert.equal((await call("POST", `/api/companies/${sourceId}`, { roleFamilies: ["not-a-family"] })).status, 400);
    assert.equal((await call("POST", `/api/companies/${sourceId}`, { roleFamilies: ["ai-ml-engineering"] })).status, 200);
    view = (await call("GET", "/api/progress")).json() as ProgressView;
    assert.equal(status("Machine Learning Engineer").status, "not_applied");

    const now = new Date().toISOString();
    store.db.prepare("INSERT INTO autopilot_jobs VALUES (?,?,?,?)").run("auto-1", "progress-1", "awaiting_human",
      JSON.stringify({ id: "auto-1", jobId: "progress-1", status: "awaiting_human", reason: "Solve the CAPTCHA in this tab.", createdAt: now, updatedAt: now }));
    view = (await call("GET", "/api/progress")).json() as ProgressView;
    assert.equal(status("Senior Data Engineer").status, "needs_you");
    assert.equal(status("Senior Data Engineer").channel, "auto_apply");
    assert.equal(view.companies[0]!.jobs[0]!.title, "Senior Data Engineer", "roles that need you come first");
    store.db.prepare("UPDATE autopilot_jobs SET status=?, json=? WHERE id=?").run("submitted_confirmed",
      JSON.stringify({ id: "auto-1", jobId: "progress-1", status: "submitted_confirmed", reason: "Receipt observed.", createdAt: now, updatedAt: now }), "auto-1");
    view = (await call("GET", "/api/progress")).json() as ProgressView;
    assert.equal(status("Senior Data Engineer").status, "applied");
    assert.equal(view.companies[0]!.counts.applied, 1);

    const families = (await call("GET", "/api/role-families")).json().families as RoleFamily[];
    assert.ok(families.some(family => family.id === "forward-deployed-engineering"));
    assert.equal((await call("POST", "/api/role-families", { families: [...families, families[0]] })).status, 400, "ids must be unique");
    assert.equal((await call("POST", "/api/role-families", { families: [{ ...families[0]!, titleKeywords: [] }] })).status, 400, "a family needs a title keyword");
    const edited = families.map(family => family.id === "ai-ml-engineering" ? { ...family, resumeSlot: 7 } : family.id === "data-engineering" ? { ...family, alwaysApply: false } : family);
    assert.equal((await call("POST", "/api/role-families", { families: edited })).status, 200);
    view = (await call("GET", "/api/progress")).json() as ProgressView;
    assert.equal(status("Machine Learning Engineer").status, "not_applied");
    assert.equal(view.families.find(family => family.id === "ai-ml-engineering")!.resumeSlot, 7);
    assert.equal((await call("POST", "/api/role-families/reset")).status, 200);
    assert.equal(((await call("GET", "/api/role-families")).json().families as RoleFamily[]).find(family => family.id === "data-engineering")!.alwaysApply, true);

    const saved = await call("POST", "/api/question-bank", { answers: { notice_period_days: "30", eeo_gender: "Male" }, preferences: { fillVoluntaryDisclosures: true } });
    assert.equal(saved.status, 200, saved.body);
    assert.equal(saved.json().answers.notice_period_days, "30");
    assert.equal(store.profile().preferences.fillVoluntaryDisclosures, true);
    const exported = await app.inject({ method: "GET", url: "/api/question-bank/export", headers });
    assert.match(String(exported.headers["content-disposition"]), /chairman-answers\.json/);
    const file = exported.json();
    assert.deepEqual([file.format, file.version, file.answers.eeo_gender, file.preferences.fillVoluntaryDisclosures], ["chairman-answers", 1, "Male", true]);
    assert.equal((await call("POST", "/api/question-bank/import", { answers: { account_password: "x" } })).status, 400, "secrets are never stored");
    const imported = await call("POST", "/api/question-bank/import", { ...file, answers: { willing_to_relocate: true, notice_period_days: 45, eeo_gender: "" } });
    assert.equal(imported.status, 200, imported.body);
    assert.equal(imported.json().imported, 2);
    assert.deepEqual([store.profile().answers.willing_to_relocate, store.profile().answers.notice_period_days, store.profile().answers.eeo_gender], ["true", "45", "Male"]);

    const inbox = new QuestionInbox(store);
    inbox.harvest([{ label: "What is your favourite data tool?", type: "text", options: [], required: true },
      { label: "How did you hear about us?", type: "text", options: [], required: false }], "Example Corp");
    let bank = (await call("GET", "/api/question-bank")).json();
    const favourite = bank.inbox.find((question: { label: string }) => question.label === "What is your favourite data tool?");
    assert.ok(favourite);
    assert.equal(bank.inbox.find((question: { label: string }) => /hear about/.test(question.label)).bankKey, "how_did_you_hear");
    assert.equal((await call("POST", `/api/question-bank/inbox/${favourite.id}/answer`, { value: "Apache Spark" })).status, 200);
    bank = (await call("GET", "/api/question-bank")).json();
    assert.equal(bank.answers["What is your favourite data tool?"], "Apache Spark");
    assert.ok(!bank.inbox.some((question: { label: string }) => question.label === "What is your favourite data tool?"));
    assert.equal(runtime.autopilot.view().enabled, false, "scope and answer changes never activate Auto Apply");
  } finally { await app.close(); await rm(directory, { recursive: true, force: true }); }
});
