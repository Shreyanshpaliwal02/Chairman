import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "../apps/local/server.js";
import type { LightMyRequestResponse } from "fastify";

test("Gemini key APIs require the dashboard session and never expose or revive credentials", async (t) => {
  const previous = { ...process.env };
  const directory = await mkdtemp(join(tmpdir(), "jaa-gemini-api-"));
  const fixtureKey = `AIza${"a".repeat(35)}`;
  const replacementKey = `AIza${"b".repeat(35)}`;
  const calls: string[] = [];
  let runtime: Awaited<ReturnType<typeof createApp>> | undefined;
  try {
    process.env.JAA_AI_PROVIDER = "gemini";
    process.env.JAA_GEMINI_MODEL = "gemini-2.5-flash";
    process.env.JAA_ALLOW_GEMINI_REMOTE = "0";
    process.env.JAA_GEMINI_FREE_TIER_CONFIRMED = "0";
    delete process.env.JAA_GEMINI_API_KEY;
    delete process.env.GEMINI_API_KEY;
    for (const name of Object.keys(process.env)) {
      if (/proxy/i.test(name)) delete process.env[name];
    }
    t.mock.method(globalThis, "fetch", async (input: string | URL | Request, init?: RequestInit) => {
      assert.equal(String(input), "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash");
      assert.equal(init?.method, "GET", "Setup must never send a generation prompt");
      assert.equal(new Headers(init?.headers).get("x-goog-api-key"), fixtureKey);
      assert.equal(init?.redirect, "error");
      calls.push(String(input));
      return Response.json({ name: "models/gemini-2.5-flash", supportedGenerationMethods: ["generateContent"] });
    });
    runtime = await createApp({ dataDir: directory, port: 4321 });
    const host = { host: "127.0.0.1:4321" };
    const session = await runtime.app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = session.cookies[0]!;
    const headers = { ...host, cookie: `${cookie.name}=${cookie.value}`, origin: "http://127.0.0.1:4321" };
    const keyPath = "/api/inference/gemini-key";
    assert.equal((await runtime.app.inject({ method: "POST", url: keyPath, headers: host, payload: { apiKey: fixtureKey } })).statusCode, 401);
    assert.equal((await runtime.app.inject({ method: "POST", url: keyPath, headers: { ...headers, origin: "https://example.invalid" }, payload: { apiKey: fixtureKey } })).statusCode, 403);
    const invalid = await runtime.app.inject({ method: "POST", url: keyPath, headers, payload: { apiKey: fixtureKey, unexpected: fixtureKey } });
    assert.equal(invalid.statusCode, 400);
    assert.ok(!invalid.body.includes(fixtureKey));
    const saved = await runtime.app.inject({ method: "POST", url: keyPath, headers, payload: { apiKey: fixtureKey } });
    assert.equal(saved.statusCode, 200, saved.body);
    assert.deepEqual(saved.json(), { ok: true });
    assert.equal(runtime.store.value("inference", null), null);
    assert.equal(calls.length, 0);
    for (const url of ["/api/state", "/api/export"]) {
      const result: LightMyRequestResponse = await runtime.app.inject({ method: "GET", url, headers });
      assert.equal(result.statusCode, 200, result.body);
      assert.ok(!result.body.includes(fixtureKey));
      if (url === "/api/state") {
        assert.equal(result.json().runtime.ai.keyConfigured, true);
        assert.equal(result.json().runtime.ai.consentRequired, true);
      }
    }
    assert.equal(calls.length, 0);
    const config = { provider: "gemini", model: "gemini-2.5-flash", allowRemoteProcessing: true, acknowledgeUsage: true, confirmFreeTier: true };
    assert.equal((await runtime.app.inject({ method: "POST", url: "/api/inference/config", headers, payload: { ...config, apiKey: fixtureKey } })).statusCode, 400);
    const consent = await runtime.app.inject({ method: "POST", url: "/api/inference/config", headers, payload: config });
    assert.equal(consent.statusCode, 200, consent.body);
    assert.equal(consent.json().ai.available, true);
    assert.equal(consent.json().ai.billingTierVerified, false);
    assert.equal(calls.length, 1);
    const replaced = await runtime.app.inject({ method: "POST", url: keyPath, headers, payload: { apiKey: replacementKey } });
    assert.equal(replaced.statusCode, 200, replaced.body);
    assert.deepEqual(runtime.store.value("inference", null), { ...config, allowRemoteProcessing: false, acknowledgeUsage: false, confirmFreeTier: false });
    assert.equal(runtime.autopilot.view().enabled, false);
    assert.equal(calls.length, 1);
    const persisted = JSON.parse(await readFile(join(directory, "private", "gemini-key.json"), "utf8"));
    assert.equal(persisted.apiKey, replacementKey);
    process.env.GEMINI_API_KEY = fixtureKey;
    assert.equal((await runtime.app.inject({ method: "POST", url: keyPath, headers, payload: { revoke: true } })).statusCode, 200);
    const revoked = await runtime.app.inject({ method: "GET", url: "/api/state", headers });
    assert.equal(revoked.json().runtime.ai.keyConfigured, false);
    await runtime.app.close();
    runtime = await createApp({ dataDir: directory, port: 4321 });
    const nextSession = await runtime.app.inject({ method: "GET", url: "/api/session", headers: host });
    const nextCookie = nextSession.cookies[0]!;
    const nextHeaders = { ...headers, cookie: `${nextCookie.name}=${nextCookie.value}` };
    const afterRestart = await runtime.app.inject({ method: "GET", url: "/api/state", headers: nextHeaders });
    assert.equal(afterRestart.json().runtime.ai.keyConfigured, false, "Revocation must override environment keys after restart");
    assert.equal((await runtime.app.inject({ method: "POST", url: keyPath, headers: nextHeaders, payload: { apiKey: replacementKey } })).statusCode, 200);
    const deleted = await runtime.app.inject({ method: "POST", url: "/api/data/delete", headers: nextHeaders, payload: { confirmation: "DELETE LOCAL DATA" } });
    assert.equal(deleted.statusCode, 200, deleted.body);
    assert.deepEqual(JSON.parse(await readFile(join(directory, "private", "gemini-key.json"), "utf8")), { apiKey: null });
    assert.equal(process.env.JAA_ALLOW_GEMINI_REMOTE, "0");
    assert.equal(process.env.JAA_GEMINI_FREE_TIER_CONFIRMED, "0");
    assert.equal(calls.length, 1);
  } finally {
    await runtime?.app.close();
    await rm(directory, { recursive: true, force: true });
    process.env = previous;
  }
});
