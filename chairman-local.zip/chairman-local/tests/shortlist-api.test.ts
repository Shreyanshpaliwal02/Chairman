import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "../apps/local/server.js";
import type { CrawlResult } from "../packages/adapters/boards.js";
import type { ShortlistView } from "../apps/local/shortlist.js";
import type { ProgressView } from "../packages/domain/progress.js";
import { profileFixture, jobFixture } from "./fixtures.js";

const UUID = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, "0")}`;
const recent = new Date(Date.now() - 2 * 86400_000).toISOString();
const description = (extra = "") => `Build data pipelines with Python, SQL, Spark, Kafka and Airflow on AWS. 4+ years of experience. ${extra}`;

test("Today: companies from the catalog are crawled, scored, capped per company and acted on", { timeout: 60_000 }, async () => {
  const directory = await mkdtemp(join(tmpdir(), "jaa-shortlist-"));
  const crawled: string[] = [];
  const runtime = await createApp({ dataDir: directory, port: 4343, careerOptions: {
    crawl: async (target, sourceId, _label, options): Promise<CrawlResult> => {
      crawled.push(target.board);
      const jobs = target.provider === "greenhouse" ? [
        jobFixture({ id: `gh-${sourceId}-1`, sourceId, company: "Databricks", title: "Senior Data Engineer", location: "Bengaluru, India", description: description(), postedAt: recent,
          applyUrl: "https://job-boards.greenhouse.io/databricks/jobs/1", canonicalUrl: "https://job-boards.greenhouse.io/databricks/jobs/1", employmentType: "Full-time" }),
        jobFixture({ id: `gh-${sourceId}-2`, sourceId, company: "Databricks", title: "Senior Data Engineer", location: "Remote - US", description: description(), postedAt: recent,
          applyUrl: "https://job-boards.greenhouse.io/databricks/jobs/2", canonicalUrl: "https://job-boards.greenhouse.io/databricks/jobs/2", employmentType: "Full-time" }),
        jobFixture({ id: `gh-${sourceId}-3`, sourceId, company: "Databricks", title: "Senior Cloud Engineer", location: "Seattle, WA", description: description("Terraform, Kubernetes, AWS. Visa sponsorship is available."),
          postedAt: recent, applyUrl: "https://job-boards.greenhouse.io/databricks/jobs/3", canonicalUrl: "https://job-boards.greenhouse.io/databricks/jobs/3", employmentType: "Full-time" }),
        jobFixture({ id: `gh-${sourceId}-4`, sourceId, company: "Databricks", title: "Staff Data Engineer", location: "Bengaluru, India", description: description(), postedAt: recent,
          applyUrl: "https://job-boards.greenhouse.io/databricks/jobs/4", canonicalUrl: "https://job-boards.greenhouse.io/databricks/jobs/4", employmentType: "Full-time" }),
      ] : [1, 2, 3].map(n => jobFixture({ id: `ashby-${sourceId}-${n}`, sourceId, company: "OpenAI", title: `Data Engineer ${["Platform", "Analytics", "Infra"][n - 1]}`, location: "Remote",
        description: description(), postedAt: recent, applyUrl: `https://jobs.ashbyhq.com/openai/${UUID(n)}/application`, canonicalUrl: `https://jobs.ashbyhq.com/openai/${UUID(n)}`, employmentType: "Full-time" }));
      const kept = jobs.filter(job => options?.keep?.(job.title, job.location) ?? true);
      return { jobs: kept, listed: jobs.length + 5, kept: kept.length, truncated: false };
    },
  } });
  const { app, store } = runtime, host = { host: "127.0.0.1:4343" };
  try {
    const session = await app.inject({ method: "GET", url: "/api/session", headers: host });
    const cookie = session.cookies[0]!, headers = { ...host, cookie: `${cookie.name}=${cookie.value}` };
    const call = async <T>(method: "GET" | "POST", url: string, payload?: unknown) => {
      const response = await app.inject({ method, url, headers, ...(payload === undefined ? {} : { payload: payload as object }) });
      return { status: response.statusCode, body: response.body, json: () => response.json() as T };
    };
    const profile = profileFixture();
    profile.answers = { ...profile.answers, total_years_experience: "5" };
    store.set("profile", profile);
    assert.equal((await app.inject({ method: "GET", url: "/api/shortlist", headers: host })).statusCode, 401);

    const empty = (await call<ShortlistView>("GET", "/api/shortlist")).json();
    assert.deepEqual([empty.entries.length, empty.generatedAt, empty.companies.total], [0, undefined, 0]);
    const added = await call<{ added: number; companies: { name: string; added: boolean; crawlable: boolean }[] }>("POST", "/api/companies/catalog/add", { names: ["Databricks", "OpenAI", "Uber"] });
    assert.equal(added.status, 200, added.body);
    assert.equal(added.json().added, 3);
    const catalog = added.json().companies;
    assert.deepEqual(["Databricks", "OpenAI", "Uber"].map(name => catalog.find(entry => entry.name === name)!.added), [true, true, true]);
    assert.equal(catalog.find(entry => entry.name === "Uber")!.crawlable, false);
    assert.equal(catalog.find(entry => entry.name === "Google")!.crawlable, true, "Google Careers is crawled by its own adapter");
    assert.equal((await call<{ added: number }>("POST", "/api/companies/catalog/add", { names: ["Databricks"] })).json().added, 0, "adding twice is a no-op");
    for (const source of runtime.careerSources.list()) await runtime.careerSources.scanOne(source.id);
    assert.deepEqual(crawled.sort(), ["databricks", "openai"]);
    const databricks = runtime.careerSources.list().find(source => source.company === "Databricks")!;
    assert.deepEqual([databricks.crawl?.listed, databricks.crawl?.relevant, databricks.status], [9, 4, "ready"]);
    assert.match(databricks.message, /9 open roles on the board; 4 match your role families/);
    const progress = (await call<ProgressView>("GET", "/api/progress")).json();
    assert.deepEqual(progress.manual.map(entry => entry.name), ["Uber"], "companies without a board are listed to check yourself");

    let view = (await call<ShortlistView>("POST", "/api/shortlist/rebuild")).json();
    const titles = view.entries.map(entry => `${entry.company}: ${entry.title} @ ${entry.label}`);
    assert.equal(view.entries[0]!.title, "Senior Cloud Engineer", `sponsored roles abroad come first: ${titles.join(" | ")}`);
    assert.equal(view.entries[0]!.tier, "abroad");
    assert.ok(view.entries.some(entry => entry.title === "Senior Data Engineer" && entry.tier === "india"));
    assert.equal(view.entries.filter(entry => entry.company === "OpenAI").length, 3);
    assert.ok(!titles.some(title => /Remote - US/.test(title)), "US-only remote roles are never listed");
    assert.ok(!view.entries.some(entry => entry.title === "Staff Data Engineer"), "staff level is outside 5 years' range");
    assert.deepEqual([view.excluded.remote_restricted, view.excluded.experience], [1, 1]);
    assert.deepEqual([view.years, view.levels], [5, ["mid", "senior"]]);
    assert.equal(view.counts.total, 5);
    assert.ok(view.entries.every(entry => entry.status === "new" && entry.applyUrl.startsWith("https://")));

    const settings = { ...view.settings, maxPerCompany: 2, priority: "india-first" as const };
    assert.equal((await call("POST", "/api/shortlist/settings", { settings: { ...settings, dailyCount: 0 } })).status, 400);
    view = (await call<ShortlistView>("POST", "/api/shortlist/settings", { settings })).json();
    assert.equal(view.entries.filter(entry => entry.company === "OpenAI").length, 2, "per-company cap");
    assert.equal(view.excluded.cap, 1);
    assert.notEqual(view.entries[0]!.title, "Senior Cloud Engineer", "India first puts the abroad role lower");

    const first = view.entries.find(entry => entry.company === "OpenAI")!;
    view = (await call<ShortlistView>("POST", `/api/shortlist/${encodeURIComponent(first.jobId)}/status`, { status: "skipped" })).json();
    assert.equal(view.entries.find(entry => entry.jobId === first.jobId)!.status, "skipped");
    const second = view.entries.find(entry => entry.company === "Databricks")!;
    view = (await call<ShortlistView>("POST", `/api/shortlist/${encodeURIComponent(second.jobId)}/status`, { status: "applied" })).json();
    // Your own "I submitted it" is shown as marked, never as applied: nothing confirmed the submission.
    assert.deepEqual([view.entries.find(entry => entry.jobId === second.jobId)!.status, view.counts.applied, view.counts.marked], ["marked", 0, 1]);
    let tracked = (await call<ProgressView>("GET", "/api/progress")).json().companies.flatMap(company => company.jobs).find(job => job.jobId === second.jobId)!;
    assert.equal(tracked.status, "marked");
    assert.match(tracked.detail, /^You marked this as submitted on .*No confirmation page or email has been seen, so it is not counted as applied\.$/);
    assert.equal(tracked.evidence, undefined);
    // Proof (here: the employer's confirmation page) turns it into applied, with the evidence shown.
    runtime.progress.recordEvidence(second.jobId, { kind: "confirmation_page", at: "2026-09-28T10:00:00.000Z", detail: 'The page said "Thank you for applying".' });
    view = (await call<ShortlistView>("GET", "/api/shortlist")).json();
    const proven = view.entries.find(entry => entry.jobId === second.jobId)!;
    assert.deepEqual([proven.status, proven.evidence?.kind, view.counts.applied, view.counts.marked], ["applied", "confirmation_page", 1, 0]);
    tracked = (await call<ProgressView>("GET", "/api/progress")).json().companies.flatMap(company => company.jobs).find(job => job.jobId === second.jobId)!;
    assert.deepEqual([tracked.status, tracked.evidence?.kind], ["applied", "confirmation_page"]);
    view = (await call<ShortlistView>("POST", "/api/shortlist/rebuild")).json();
    assert.ok(!view.entries.some(entry => entry.jobId === first.jobId || entry.jobId === second.jobId), "skipped and applied roles leave the next list");

    const auto = await call<{ error: string }>("POST", `/api/shortlist/${encodeURIComponent(view.entries[0]!.jobId)}/auto-apply`);
    assert.equal(auto.status, 400);
    assert.match(auto.body, /Auto Apply is paused/);
    assert.equal(view.autoApply.enabled, false);
    assert.equal(view.entries.every(entry => typeof entry.autoApply === "boolean"), true);
    assert.equal(runtime.autopilot.view().enabled, false, "nothing here activates Auto Apply");

    // A list built before the morning hour is provisional: the morning run refreshes companies, then rebuilds it once.
    const date = view.date, early = new Date(Date.parse(`${date}T00:05:00+05:30`)).toISOString();
    store.db.prepare("UPDATE shortlists SET json=json_set(json,'$.generatedAt',?) WHERE date=?").run(early, date);
    const morning = new Date(Date.parse(`${date}T07:30:00+05:30`));
    runtime.shortlist.tick(new Date(Date.parse(`${date}T06:30:00+05:30`)));
    assert.equal((await call<ShortlistView>("GET", "/api/shortlist")).json().generatedAt, early, "nothing happens before the morning hour");
    runtime.shortlist.tick(morning);
    assert.equal((await call<ShortlistView>("GET", "/api/shortlist")).json().generatedAt, early, "the first morning tick only refreshes companies");
    runtime.shortlist.tick(morning);
    const rebuilt = (await call<ShortlistView>("GET", "/api/shortlist")).json().generatedAt!;
    assert.ok(Date.parse(rebuilt) > Date.parse(early), "then the list is rebuilt");
    runtime.shortlist.tick(morning);
    assert.equal((await call<ShortlistView>("GET", "/api/shortlist")).json().generatedAt, rebuilt, "only once");
    assert.equal(store.confirmedCount(), 0);
  } finally { await app.close(); await rm(directory, { recursive: true, force: true }); }
});

test("stopping the service interrupts a running board crawl at once; the board is crawled again after the restart", { timeout: 30_000 }, async () => {
  const directory = await mkdtemp(join(tmpdir(), "jaa-shortlist-stop-"));
  let started!: () => void, sawStop = false;
  const running = new Promise<void>(resolve => { started = resolve; });
  const runtime = await createApp({ dataDir: directory, port: 4344, careerOptions: {
    crawl: (_target, _sourceId, _label, options) => new Promise<CrawlResult>((_resolve, reject) => {
      started();
      const timer = setTimeout(() => reject(new Error("the crawl was never stopped")), 20_000);
      options?.signal?.addEventListener("abort", () => { sawStop = true; clearTimeout(timer); reject(new Error("The board crawl was stopped.")); }, { once: true });
    }),
  } });
  try {
    const session = await runtime.app.inject({ method: "GET", url: "/api/session", headers: { host: "127.0.0.1:4344" } });
    const cookie = session.cookies[0]!;
    const added = await runtime.app.inject({ method: "POST", url: "/api/companies/catalog/add", headers: { host: "127.0.0.1:4344", cookie: `${cookie.name}=${cookie.value}` }, payload: { names: ["Apple"] } });
    assert.equal(added.statusCode, 200, added.body);
    const source = runtime.careerSources.list()[0]!;
    assert.equal(source.target?.provider, "apple");
    const scan = runtime.careerSources.scanOne(source.id);
    await running;
    const began = Date.now();
    await runtime.careerSources.close();
    await scan;
    assert.ok(Date.now() - began < 2000, "shutdown does not wait for the crawl's time budget");
    assert.equal(sawStop, true);
    const after = runtime.careerSources.get(source.id);
    assert.equal(after.status, "scanning", "not recorded as a failed crawl; the next start marks it interrupted and crawls it again");
    runtime.careerSources.start();
    assert.equal(runtime.careerSources.get(source.id).status, "error");
    assert.match(runtime.careerSources.get(source.id).message, /interrupted/);
  } finally {
    await runtime.app.close();
    await rm(directory, { recursive: true, force: true });
  }
});
