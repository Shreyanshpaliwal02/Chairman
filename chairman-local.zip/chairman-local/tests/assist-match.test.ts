import assert from "node:assert/strict";
import test from "node:test";
import { adaptToField, autocompleteMeaning, canonicalJson, cleanQuestion, comparableValue, countryCode, fitsConstraints, formatCandidates,
  formatDateLike, matchChoice, parseRange, sameComparable, stableFieldKey, ASSIST_KEY } from "../packages/domain/assist-match.js";
import { resolveAnswers } from "../packages/automation/answers.js";
import { assistancePagePayload, assistanceSnapshotPayload } from "../packages/domain/extension-assist.js";
import { emptyProfile, type FormField, type Job } from "../packages/domain/types.js";

const options = (...labels: string[]) => labels.map((label, index) => ({ value: `v${index}`, label }));

test("canonical JSON and field keys are independent of property order and stable across runs", () => {
  assert.equal(canonicalJson({ b: 1, a: { d: [2, { z: 1, y: undefined }], c: "x" } }), canonicalJson({ a: { c: "x", d: [2, { z: 1 }] }, b: 1 }));
  const key = stableFieldKey("text|id:first_name");
  assert.match(key, ASSIST_KEY);
  assert.equal(stableFieldKey("text|id:first_name"), key);
  assert.notEqual(stableFieldKey("text|id:last_name"), key);
  const snapshot = { url: "https://jobs.example.com/apply", fields: [{ key, label: "First name", type: "text", required: true, options: [], hint: "volatile error text" }],
    hasCaptcha: false, hasLegal: false, unsupported: [] };
  assert.equal(assistanceSnapshotPayload(snapshot), assistanceSnapshotPayload({ ...snapshot, fields: [{ ...snapshot.fields[0], hint: "different" }] }), "live hint/error text never changes the fingerprint");
  const page = { url: snapshot.url, kind: "form" as const, title: "Apply", snapshot: { ...snapshot, fingerprint: "0".repeat(64) }, occupied: [], blockers: ["a"] };
  assert.equal(assistancePagePayload(page), assistancePagePayload({ ...page, title: "Apply (1 new)", occupied: [key], blockers: ["b"] }), "typing, titles and informational blockers do not invalidate a reviewed plan");
});

test("option matching is deterministic, strongest-first, and refuses ambiguity", () => {
  assert.deepEqual(matchChoice("India", options("Select...", "India", "British Indian Ocean Territory")), { value: "v1", label: "India", tier: "label" });
  assert.equal((matchChoice("India", options("India (+91)", "Indonesia (+62)")) as { tier: string }).tier, "core");
  assert.equal((matchChoice("Yes", options("Yes, I am legally authorized", "No, I am not")) as { label: string }).label, "Yes, I am legally authorized");
  assert.deepEqual(matchChoice("Yes", options("Yes, with sponsorship", "Yes, without sponsorship", "No")), { error: "ambiguous" });
  assert.equal((matchChoice("4", options("0-2 years", "3-5 years", "6+ years")) as { label: string }).label, "3-5 years");
  assert.deepEqual(matchChoice("3", options("0-3 years", "3-5 years")), { error: "ambiguous" }, "overlapping ranges never pick one arbitrarily");
  assert.deepEqual(matchChoice("4", options("0-6 months", "More than 6 months"), "years"), { error: "none" }, "different units never match a range");
  assert.equal((matchChoice("USA", options("Canada", "United States")) as { label: string }).label, "United States");
  assert.equal((matchChoice("Bachelor of Science in Computer Science", options("High school", "Bachelor's", "Master's")) as { label: string }).label, "Bachelor's");
  assert.deepEqual(matchChoice("Remote", options("Remote - US", "Remote - EU")), { error: "ambiguous" });
  assert.deepEqual(matchChoice("Paris", options("London", "Berlin")), { error: "none" });
  assert.deepEqual(matchChoice("No", options("Norway", "Sweden")), { error: "none" }, "a yes/no answer is never read as a country code");
  assert.equal(countryCode("IN"), "IN");
  assert.equal(countryCode("in"), undefined);
  assert.equal(countryCode("the Netherlands"), "NL");
  assert.deepEqual(parseRange("Less than 1 year")!.max < 1, true);
  assert.deepEqual(parseRange("10+ years"), { min: 10, max: Infinity });
});

test("format-only repairs preserve the approved information and respect visible constraints", () => {
  const phone: FormField = { key: "k", label: "Phone", type: "tel", required: true, options: [], pattern: "[0-9]{10}" };
  assert.deepEqual(adaptToField("+91 98765 43210", phone), { value: "9876543210", reason: "Used the national number without the country code." });
  assert.equal(adaptToField("9876543210", phone), undefined, "a fitting value is never rewritten");
  assert.deepEqual(adaptToField("+91 98765 43210", { type: "tel", label: "Mobile" }, "Enter digits only"), { value: "919876543210", reason: "Removed spaces and punctuation from the phone number." });
  assert.equal(adaptToField("linkedin.com/in/me", { type: "url", label: "LinkedIn" })!.value, "https://linkedin.com/in/me");
  assert.equal(formatDateLike("2026-10-01", "MM/DD/YYYY"), "10/01/2026");
  assert.equal(formatDateLike("2026-10-01", "dd.mm.yyyy"), "01.10.2026");
  assert.equal(adaptToField("5 years", { type: "number", label: "Years" })!.value, "5");
  assert.ok(formatCandidates("hello", { type: "text", label: "Anything" }).length === 0, "free text has no invented rewrites");
  assert.equal(fitsConstraints("abc", { maxLength: 2 }), false);
  assert.equal(fitsConstraints("x", { pattern: "(" }), true, "an invalid site pattern is ignored rather than guessed");
  assert.equal(comparableValue("tel", "+1 (202) 555-0118"), "12025550118");
  assert.ok(sameComparable("tel", "2025550118", "+1 (202) 555-0118"), "phone masks that add a country code still match");
  assert.equal(cleanQuestion("First name *"), "First name");
  assert.equal(cleanQuestion("Email (required):"), "Email");
  assert.equal(autocompleteMeaning("section-a given-name"), "first_name");
  assert.equal(autocompleteMeaning("off"), undefined);
});

test("common ATS wordings (Ashby, Greenhouse) resolve to the same saved profile facts", () => {
  const profile = { ...emptyProfile(), confirmed: true, name: "Demo Candidate", email: "demo@example.com", phone: "+91 90000 00000", location: "Bengaluru, Karnataka, India" };
  const job: Job = { id: "j", sourceId: "s", sourceJobId: "j", title: "Engineer", company: "Example", location: "India", remote: false, countries: ["India"],
    employmentType: "Full-time", description: "Role.", applyUrl: "https://example.invalid", canonicalUrl: "https://example.invalid", fetchedAt: "2026-01-01",
    salary: null, language: null, sponsorship: "unknown", aiPolicy: "allowed", status: "open" };
  const labels = { a: "Preferred FULL Name", b: "Legal FULL Name", c: "Mobile Phone", d: "Location - City, State", e: "Alt. Phone" };
  const fields = Object.entries(labels).map(([key, label]) => ({ key, label, type: "text", required: false, options: [] }));
  const plan = resolveAnswers(profile, job, { url: "https://example.invalid", fields, fingerprint: "x", hasCaptcha: false, hasLegal: false, unsupported: [] });
  assert.deepEqual(plan.answers, { a: "Demo Candidate", b: "Demo Candidate", c: "+91 90000 00000", d: "Bengaluru, Karnataka, India" }, "an alternate phone is never guessed");
});

test("fuzzy option matching is opt-in for reviewed Chrome plans only; the unattended resolver stays exact", () => {
  const profile = { ...emptyProfile(), confirmed: true, name: "Taylor Example", email: "taylor@example.invalid", phone: "+1 202 555 0100", location: "India",
    answers: { total_years_experience: "4", country: "India" } };
  const job: Job = { id: "j", sourceId: "s", sourceJobId: "j", title: "Engineer", company: "Example", location: "India", remote: false, countries: ["India"],
    employmentType: "Full-time", description: "Role.", applyUrl: "https://example.invalid", canonicalUrl: "https://example.invalid", fetchedAt: "2026-01-01",
    salary: null, language: null, sponsorship: "unknown", aiPolicy: "allowed", status: "open" };
  const fields: FormField[] = [
    { key: "years", label: "Years of experience", type: "select", required: true, options: ["a", "b", "c"], optionLabels: { a: "0-2 years", b: "3-5 years", c: "6+ years" } },
    { key: "country", label: "Country", type: "select", required: true, options: ["IN", "US"], optionLabels: { IN: "India (+91)", US: "United States (+1)" } },
  ];
  const snapshot = { url: "https://example.invalid", fields, fingerprint: "x", hasCaptcha: false, hasLegal: false, unsupported: [] };
  assert.deepEqual(resolveAnswers(profile, job, snapshot).answers, {}, "strict mode is unchanged");
  const fuzzy = resolveAnswers(profile, job, snapshot, { fuzzyOptions: true, provenance: true });
  assert.equal(resolveAnswers(profile, job, snapshot, { fuzzyOptions: true }).sources, undefined, "the plan shape is unchanged unless provenance is requested");
  assert.deepEqual(fuzzy.answers, { years: "b", country: "IN" });
  assert.equal(fuzzy.sources?.years, "answers:total_years_experience");
});
