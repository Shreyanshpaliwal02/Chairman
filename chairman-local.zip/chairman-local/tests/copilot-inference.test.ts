import assert from "node:assert/strict";
import { readdir, stat } from "node:fs/promises";
import { dirname, isAbsolute } from "node:path";
import test, { mock } from "node:test";
import type { AssistantMessageEvent, CopilotClientOptions, CopilotRequestContext, GetAuthStatusResponse, ModelInfo, SessionConfig } from "@github/copilot-sdk";
import { copilotInference, createCopilotInference, type InferenceClient, type InferenceSession, RUNTIME_PATH } from "../packages/inference/index.js";
import { InferenceRequestGuard } from "../packages/inference/request-guard.js";
import { getAiStatus, selectResume } from "../packages/documents/selection.js";
import { jobFixture, profileFixture } from "./fixtures.js";

const model = "gpt-6-astra";
const consent = { JAA_ALLOW_COPILOT_REMOTE: "1" };
const selected = { factIds: ["exp-1"], skills: ["Python"] };
const schema = { type: "object", additionalProperties: false, required: ["factIds", "skills"] };
const reply = (content = JSON.stringify(selected)): AssistantMessageEvent => ({
  type: "assistant.message", id: "fixture-event", timestamp: "2026-09-15T00:00:00Z", parentId: null,
  data: { messageId: "fixture-message", model, content },
});
const inventory = (id = model): ModelInfo[] => [{
  id, name: "Synthetic test model",
  capabilities: { supports: { vision: false, reasoningEffort: false }, limits: { max_context_window_tokens: 8_192 } },
}];

class FakeSession implements InferenceSession {
  sessionId = "fixture-session";
  aborts = 0;
  disconnects = 0;
  sends = 0;
  current = model;
  response: AssistantMessageEvent | undefined = reply();
  onSend?: () => Promise<AssistantMessageEvent | undefined>;
  rpc = { model: { getCurrent: async () => ({ modelId: this.current }) } };
  async sendAndWait(): Promise<AssistantMessageEvent | undefined> {
    this.sends++;
    return this.onSend ? this.onSend() : this.response;
  }
  async abort() { this.aborts++; }
  async disconnect() { this.disconnects++; }
}

class FakeClient implements InferenceClient {
  auth: GetAuthStatusResponse = { isAuthenticated: true, authType: "user" };
  models = inventory();
  session = new FakeSession();
  starts = 0;
  stops = 0;
  forceStops = 0;
  authChecks = 0;
  modelChecks = 0;
  sessions = 0;
  deletes = 0;
  config?: SessionConfig;
  options?: CopilotClientOptions;
  onCreate?: (config: SessionConfig) => Promise<void>;
  onStart?: () => Promise<void>;
  onStop?: () => Promise<Error[]>;
  authError = false;
  modelsError = false;
  async start() { this.starts++; await this.onStart?.(); }
  async stop() { this.stops++; return this.onStop ? this.onStop() : []; }
  async forceStop() { this.forceStops++; }
  async getAuthStatus() {
    this.authChecks++;
    if (this.authError) throw new Error("Do not expose account identity or credentials in SDK diagnostics.");
    return this.auth;
  }
  async listModels() {
    this.modelChecks++;
    if (this.modelsError) throw new Error("Do not expose account identity in model errors.");
    return this.models;
  }
  async createSession(config: SessionConfig) {
    this.sessions++;
    this.config = config;
    await this.onCreate?.(config);
    return this.session;
  }
  async deleteSession() { this.deletes++; }
}

function fixture(environment: NodeJS.ProcessEnv = consent, client = new FakeClient(), timing: {
  now?: () => number; statusTimeoutMs?: number; inferenceTimeoutMs?: number; cleanupTimeoutMs?: number;
} = {}) {
  const controller = createCopilotInference({
    environment: () => environment,
    clientFactory: (options) => { client.options = options; return client; },
    ...timing,
  });
  return { client, controller, select: () => controller.select("Select only supplied facts.", "Synthetic fictional candidate data.", schema) };
}

async function removed(client: FakeClient) {
  const directory = client.options?.workingDirectory;
  assert.ok(directory);
  await assert.rejects(stat(dirname(directory)), { code: "ENOENT" });
}

test("remote consent is mandatory for status and prompts, without even starting the SDK", async () => {
  const { client, controller, select } = fixture({});
  const status = await controller.getStatus();
  assert.equal(status.available, false);
  assert.equal(status.model, model);
  assert.equal(status.provider, "copilot");
  assert.equal(status.remote, true);
  assert.equal(status.consentRequired, true);
  assert.equal(status.authenticated, undefined);
  assert.match(status.reason!, /hosted processing.*premium usage/);
  await assert.rejects(select(), /JAA_ALLOW_COPILOT_REMOTE=1/);
  assert.equal(client.starts, 0);
});

test("your stored Copilot OAuth or your own GitHub CLI login is required; missing sign-ins and environment tokens are not accepted", async () => {
  for (const authType of ["user", "gh-cli"] as const) {
    const { controller, client } = fixture();
    client.auth = { isAuthenticated: true, authType };
    const status = await controller.getStatus();
    assert.equal(status.authenticated, true, authType);
    assert.equal(status.available, true, authType);
  }
  for (const auth of [
    { isAuthenticated: false },
    { isAuthenticated: true, authType: "env" },
    { isAuthenticated: true, authType: "token" },
    { isAuthenticated: true, authType: "api-key" },
    { isAuthenticated: true },
  ] satisfies GetAuthStatusResponse[]) {
    const { controller, client, select } = fixture();
    client.auth = auth;
    const status = await controller.getStatus();
    assert.equal(status.available, false);
    assert.equal(status.authenticated, false);
    assert.match(status.reason!, /npm exec --package=@github\/copilot -- copilot login/);
    assert.equal(client.modelChecks, 0);
    assert.equal(client.sessions, 0);
    await assert.rejects(select(), /Stored Copilot OAuth/);
    assert.equal(client.session.sends, 0);
    assert.equal(client.stops, 2);
    await removed(client);
  }
});

test("exact model inventory and enabled policy are required; no alternate model or terms acceptance", async () => {
  for (const models of [[], inventory("gpt-5-mini"), inventory("GPT-6-ASTRA"),
    inventory().map((entry) => ({ ...entry, policy: { state: "unconfigured" as const, terms: "Synthetic terms" } })),
    inventory().map((entry) => ({ ...entry, policy: { state: "disabled" as const, terms: "" } })),
  ]) {
    const { client, controller, select } = fixture();
    client.models = models;
    const status = await controller.getStatus();
    assert.equal(status.available, false);
    assert.equal(status.authenticated, true);
    assert.equal(status.modelAvailable, false);
    assert.equal(status.model, model);
    await assert.rejects(select(), /exact Copilot model|policy/);
    assert.equal(client.session.sends, 0);
  }
});

test("status caches only read-only auth/model verification for 60 seconds and closes every runtime", async () => {
  let time = 1;
  const env: NodeJS.ProcessEnv = { ...consent };
  const { client, controller } = fixture(env, new FakeClient(), { now: () => time });
  const statuses = await Promise.all(Array.from({ length: 50 }, () => controller.getStatus()));
  assert.ok(statuses.every((status) => status.available && status.modelAvailable && status.authenticated));
  assert.equal(client.authChecks, 1);
  assert.equal(client.modelChecks, 1);
  assert.equal(client.starts, 1);
  assert.equal(client.stops, 1);
  assert.equal(client.sessions, 0);
  statuses[0].available = false;
  assert.equal((await controller.getStatus()).available, true);
  delete env.JAA_ALLOW_COPILOT_REMOTE;
  assert.equal((await controller.getStatus()).consentRequired, true);
  env.JAA_ALLOW_COPILOT_REMOTE = "1";
  time += 60_001;
  assert.equal((await controller.getStatus()).available, true);
  assert.equal(client.authChecks, 2);
  await removed(client);
});

test("SDK auth and inventory failures are unavailable, with safe stage-specific diagnostics", async () => {
  for (const stage of ["auth", "models"] as const) {
    const { controller, client } = fixture();
    if (stage === "auth") client.authError = true;
    else client.modelsError = true;
    const status = await controller.getStatus();
    assert.equal(status.available, false);
    assert.match(status.reason!, stage === "auth" ? /authentication status/ : /model inventory/);
    assert.doesNotMatch(status.reason!, /Do not expose/);
    assert.equal(client.sessions, 0);
  }
});

test("inference session is isolated, tokenless, instruction-free and tool-free with full cleanup", async () => {
  const { client, select } = fixture({
    ...consent, HOME: "/synthetic-home", PATH: "/synthetic-path",
    GH_TOKEN: "synthetic-not-a-token", GITHUB_TOKEN: "synthetic-not-a-token",
    COPILOT_GITHUB_TOKEN: "synthetic-not-a-token", COPILOT_CLI_PATH: "/untrusted-cli",
    COPILOT_PROVIDER_BASE_URL: "https://example.invalid", NODE_OPTIONS: "--inspect", COPILOT_HOME: "/untrusted-config",
  });
  client.onCreate = async (config) => {
    assert.ok(config.workingDirectory && config.configDirectory);
    assert.ok(isAbsolute(config.workingDirectory));
    assert.deepEqual(await readdir(config.workingDirectory), []);
    assert.equal((await stat(dirname(config.workingDirectory))).mode & 0o777, 0o700);
    assert.equal((await stat(config.workingDirectory)).mode & 0o777, 0o700);
  };
  assert.deepEqual(await select(), selected);
  const config = client.config!;
  assert.equal(config.model, model);
  assert.equal(config.systemMessage?.mode, "replace");
  assert.ok(config.systemMessage?.content?.includes(JSON.stringify(schema)));
  for (const key of ["availableTools", "tools", "customAgents", "skillDirectories", "includedBuiltinSkills",
    "pluginDirectories", "instructionDirectories", "additionalDirectories"] as const) assert.deepEqual(config[key], []);
  assert.deepEqual(config.excludedTools, ["builtin:*", "mcp:*", "custom:*"]);
  assert.deepEqual(config.mcpServers, {});
  for (const key of ["enableConfigDiscovery", "enableSkills", "enableFileHooks", "enableOnDemandInstructionDiscovery",
    "enableHostGitOperations", "enableFileChangeTracking", "enableSessionStore", "enableSessionTelemetry",
    "enableExperimentalMode", "requestExtensions", "requestCanvasRenderer", "manageScheduleEnabled", "enableMcpApps"] as const) {
    assert.equal(config[key], false, key);
  }
  assert.equal(config.skipCustomInstructions, true);
  assert.equal(config.skipEmbeddingRetrieval, true);
  assert.deepEqual(config.memory, { enabled: false });
  assert.deepEqual(config.infiniteSessions, { enabled: false });
  assert.deepEqual(config.capi, { enableWebSocketResponses: false });
  assert.equal(config.remoteSession, "off");
  assert.equal(config.provider, undefined);
  assert.equal(config.providers, undefined);
  assert.equal(config.gitHubToken, undefined);
  assert.equal(client.options?.useLoggedInUser, true);
  assert.equal(client.options?.logLevel, "none");
  assert.equal(client.options?.connection?.kind, "stdio");
  assert.equal(client.options?.gitHubToken, undefined);
  assert.deepEqual(client.options?.builtinPluginDirectories, []);
  for (const key of ["GH_TOKEN", "GITHUB_TOKEN", "COPILOT_GITHUB_TOKEN", "COPILOT_CLI_PATH", "COPILOT_PROVIDER_BASE_URL", "NODE_OPTIONS", "COPILOT_HOME"]) {
    assert.equal(client.options?.env?.[key], undefined, key);
  }
  // Only standard install locations: a gh bundled in another app's private folder (for example a chat app's) is never found.
  if (process.platform !== "win32") assert.equal(client.options?.env?.PATH, RUNTIME_PATH);
  assert.equal(client.session.sends, 1);
  assert.equal(client.session.aborts, 1);
  assert.equal(client.session.disconnects, 1);
  assert.equal(client.deletes, 1);
  assert.equal(client.stops, 1);
  await removed(client);
});

test("every permission request is denied and model errors abort rather than retry", async () => {
  const { client, select } = fixture();
  client.onCreate = async (config) => {
    const decision = await config.onPermissionRequest!({
      kind: "read", path: "/synthetic/private-data", toolCallId: "fixture-tool", intention: "Synthetic denied read",
    }, { sessionId: "fixture-session" });
    assert.equal(decision.kind, "denied-no-approval-rule-and-could-not-request-from-user");
    assert.deepEqual(await config.hooks!.onErrorOccurred!({ error: "synthetic", errorContext: "model_call", recoverable: true, timestamp: new Date(0), sessionId: "fixture-session", workingDirectory: "/synthetic" }, { sessionId: "fixture-session" }), { errorHandling: "abort" });
  };
  await assert.rejects(select(), /prohibited permission/);
  assert.equal(client.session.sends, 0);
  assert.equal(client.stops, 1);
});

test("invalid/oversized/tool-bearing output and unexpected model never retry or fall back", async () => {
  const invalid = [
    reply("```json\n{}\n```"), reply("x".repeat(24_001)), reply(""), undefined,
    { ...reply(), data: { ...reply().data, model: "gpt-5-mini" } },
    { ...reply(), data: { ...reply().data, toolRequests: [{ toolCallId: "fixture", name: "shell", arguments: {} }] } },
    { ...reply(), data: { ...reply().data, serverTools: { provider: "openai-responses", items: [{ type: "web_search_call" }] } } },
    { ...reply(), data: { ...reply().data, serverTools: { provider: "anthropic", rawContentBlocks: [{ type: "server_tool_use" }] } } },
    { ...reply(), data: { ...reply().data, serverTools: { provider: "openai-responses", advisorModel: "advisor" } } },
  ];
  for (const response of invalid) {
    const { client, select } = fixture();
    client.session.response = response;
    await assert.rejects(select(), /JSON|bounded|tool-free/);
    assert.equal(client.session.sends, 1);
    assert.equal(client.session.aborts, 1);
    assert.equal(client.session.disconnects, 1);
    assert.equal(client.stops, 1);
  }
});

test("a provider-tagged server-tool envelope without any tool use is an ordinary answer", async () => {
  for (const serverTools of [{ provider: "openai-responses" }, { provider: "openai-responses", items: [], rawContentBlocks: [{ type: "output_text" }] }]) {
    const { client, select } = fixture();
    client.session.response = { ...reply(), data: { ...reply().data, serverTools } };
    assert.deepEqual(await select(), selected);
  }
});

test("input bounds and automatic model aliases fail before starting a runtime", async () => {
  const { controller, client } = fixture();
  await assert.rejects(controller.select("x".repeat(4_097), "synthetic", schema), /bounded/);
  await assert.rejects(controller.select("system", "x".repeat(28_001), schema), /bounded/);
  await assert.rejects(controller.select("system", "synthetic", { value: "x".repeat(24_001) }), /bounded/);
  const circular: { self?: object } = {};
  circular.self = circular;
  await assert.rejects(controller.select("system", "synthetic", circular), /JSON schema/);
  assert.equal(client.starts, 0);
  const auto = fixture({ ...consent, JAA_COPILOT_MODEL: "auto" });
  assert.equal((await auto.controller.getStatus()).available, false);
  assert.equal(auto.client.starts, 0);
});

test("runtime model mismatch and consent revoked during setup prevent sending the prompt", async () => {
  const env: NodeJS.ProcessEnv = { ...consent };
  const first = fixture(env);
  first.client.session.current = "gpt-5-mini";
  await assert.rejects(first.select(), /exact configured model/);
  assert.equal(first.client.session.sends, 0);
  const second = fixture(env);
  second.client.onCreate = async () => { delete env.JAA_ALLOW_COPILOT_REMOTE; };
  await assert.rejects(second.select(), /JAA_ALLOW_COPILOT_REMOTE/);
  assert.equal(second.client.session.sends, 0);
});

test("timeouts abort and disconnect the session, delete state and force-stop unresponsive cleanup", async () => {
  const { client, select } = fixture(consent, new FakeClient(), { inferenceTimeoutMs: 35, cleanupTimeoutMs: 10 });
  client.session.onSend = () => new Promise(() => {});
  client.onStop = () => new Promise(() => {});
  await assert.rejects(select(), /timed out.*cancelled/);
  assert.equal(client.session.sends, 1);
  assert.equal(client.session.aborts, 1);
  assert.equal(client.session.disconnects, 1);
  assert.equal(client.forceStops, 1);
  await removed(client);
});

test("late startup and session creation after timeout never send and still release their resources", async () => {
  for (const stage of ["startup", "session"] as const) {
    let finish!: () => void;
    const pending = new Promise<void>((resolve) => { finish = resolve; });
    const { client, select } = fixture(consent, new FakeClient(), { inferenceTimeoutMs: 35, cleanupTimeoutMs: 10 });
    if (stage === "startup") client.onStart = () => pending;
    else client.onCreate = () => pending;
    await assert.rejects(select(), /timed out/);
    finish();
    await new Promise<void>((resolve) => setImmediate(resolve));
    assert.equal(client.session.sends, 0);
    if (stage === "session") {
      assert.equal(client.session.disconnects, 1);
      assert.equal(client.session.aborts, 1);
    } else {
      assert.equal(client.sessions, 0);
      assert.equal(client.stops, 2);
    }
    await removed(client);
  }
});

test("streaming output limits and model-switch events fail closed during inference", async () => {
  for (const event of [
    { type: "assistant.message_delta", data: { messageId: "synthetic", deltaContent: "x".repeat(24_001) } },
    { type: "session.model_change", data: { newModel: "gpt-5-mini", previousModel: model } },
  ] as const) {
    const { client, select } = fixture();
    client.session.onSend = () => {
      if (event.type === "assistant.message_delta") {
        client.config!.onEvent!({ ...event, id: "synthetic", timestamp: "2026-09-15T00:00:00Z", parentId: null, ephemeral: true });
      } else client.config!.onEvent!({ ...event, id: "synthetic", timestamp: "2026-09-15T00:00:00Z", parentId: null });
      return new Promise(() => {});
    };
    await assert.rejects(select(), /bounded response|switch away/);
    assert.equal(client.session.aborts, 1);
    assert.equal(client.session.disconnects, 1);
  }
});

test("single-flight inference rejects a parallel cost burst, without queueing or duplicate prompts", async () => {
  let started!: () => void;
  let finish!: (event: AssistantMessageEvent) => void;
  const ready = new Promise<void>((resolve) => { started = resolve; });
  const { client, select } = fixture();
  client.session.onSend = () => { started(); return new Promise((resolve) => { finish = resolve; }); };
  const first = select();
  await ready;
  const results = await Promise.allSettled(Array.from({ length: 500 }, select));
  assert.ok(results.every((result) => result.status === "rejected" && /already running/.test(String(result.reason))));
  assert.equal(client.starts, 1);
  assert.equal(client.session.sends, 1);
  finish(reply());
  assert.deepEqual(await first, selected);
});

test("the official SDK request handler blocks hidden retries, background inference and WebSockets", async () => {
  class ProbeGuard extends InferenceRequestGuard {
    send(request: Request, context: CopilotRequestContext) { return this.sendRequest(request, context); }
    socket(context: CopilotRequestContext) { return this.openWebSocket(context); }
  }
  const guard = new ProbeGuard(model);
  const context: CopilotRequestContext = {
    requestId: "fixture-request", transport: "http", url: "https://example.invalid/synthetic",
    headers: {}, signal: new AbortController().signal,
  };
  const request = new Request(context.url, { method: "POST", body: JSON.stringify({ model }) });
  const fetch = mock.method(globalThis, "fetch", async () => new Response("synthetic", { status: 500 }));
  try {
    await assert.rejects(guard.send(request, context), /Additional/);
    assert.equal(fetch.mock.callCount(), 0);
    guard.enable();
    assert.equal((await guard.send(request, context)).status, 500);
    await assert.rejects(guard.send(request, context), /no automatic retry/);
    assert.equal(fetch.mock.callCount(), 1);
    const wrongModel = new ProbeGuard(model);
    wrongModel.enable();
    await assert.rejects(wrongModel.send(new Request(context.url, { method: "POST", body: '{"model":"gpt-5-mini"}' }), context), /different or unspecified model/);
    assert.equal(fetch.mock.callCount(), 1);
    await assert.rejects(guard.socket(context), /HTTP transport/);
    // Reading the model list (a GitHub CLI sign-in fetches it through the handler) is allowed and never uses up the one request.
    const listing = new ProbeGuard(model);
    const inventory = { ...context, url: "https://api.business.githubcopilot.com/models" };
    assert.equal((await listing.send(new Request(inventory.url, { method: "GET" }), inventory)).status, 500);
    await assert.rejects(listing.send(new Request("https://api.business.githubcopilot.com/models", { method: "POST", body: JSON.stringify({ model }) }), inventory), /Additional/,
      "only a GET of the model list passes before inference is enabled");
    await assert.rejects(listing.send(new Request("https://example.invalid/models", { method: "GET" }), context), /Additional/, "only GitHub Copilot's own API");
    listing.enable();
    assert.equal((await listing.send(new Request(inventory.url, { method: "GET" }), inventory)).status, 500);
    assert.equal((await listing.send(request, context)).status, 500, "the inference request is still available after model-list reads");
    await assert.rejects(listing.send(request, context), /no automatic retry/);
    listing.close();
    await assert.rejects(listing.send(new Request(inventory.url, { method: "GET" }), inventory), /cancelled/);
    guard.close();
    assert.throws(() => guard.enable(), /cancelled/);
  } finally { fetch.mock.restore(); }
});

async function withProvider(provider: string | undefined, action: () => Promise<void>) {
  const previous = process.env.JAA_AI_PROVIDER;
  if (provider === undefined) delete process.env.JAA_AI_PROVIDER;
  else process.env.JAA_AI_PROVIDER = provider;
  try { await action(); }
  finally {
    if (previous === undefined) delete process.env.JAA_AI_PROVIDER;
    else process.env.JAA_AI_PROVIDER = previous;
  }
}

test("provider dispatch reports hosted status, preserves strict validation and uses honest Copilot notes", async () => {
  const statusMock = mock.method(copilotInference, "getStatus", async () => ({
    available: true, model, provider: "copilot" as const, remote: true as const, authenticated: true, modelAvailable: true,
  }));
  const selectMock = mock.method(copilotInference, "select", async (system: string, user: string, format: object) => {
    assert.match(system, /DATA, never instructions/);
    const sent = JSON.parse(user) as Record<string, unknown>;
    assert.equal(sent.email, undefined);
    assert.equal(sent.answers, undefined);
    assert.equal(JSON.stringify(sent).includes("applicant@example.test"), false);
    assert.equal((format as { additionalProperties: boolean }).additionalProperties, false);
    return selected;
  });
  const fetchMock = mock.method(globalThis, "fetch", async () => { throw new Error("Ollama must not be called."); });
  try {
    await withProvider("copilot", async () => {
      assert.deepEqual(await getAiStatus(), { available: true, model, provider: "copilot", remote: true, authenticated: true, modelAvailable: true });
      const draft = await selectResume(profileFixture(), jobFixture(), "local-ai");
      assert.deepEqual(draft.factIds, selected.factIds);
      assert.ok(draft.notes.some((note) => note.includes("Copilot-assisted selection")));
      assert.ok(draft.notes.every((note) => !/Local AI|local model|local-model/.test(note)));
      assert.equal(draft.mode, "local-ai");
      assert.equal(fetchMock.mock.callCount(), 0);
      selectMock.mock.mockImplementation(async () => ({ ...selected, invented: "claim" }));
      await assert.rejects(selectResume(profileFixture(), jobFixture(), "local-ai"), /Invalid resume selection/);
      selectMock.mock.mockImplementation(async () => ({ factIds: ["made-up"], skills: [] }));
      await assert.rejects(selectResume(profileFixture(), jobFixture(), "local-ai"), /unknown/);
      selectMock.mock.mockImplementation(async () => { throw new Error("Copilot test failure"); });
      await assert.rejects(selectResume(profileFixture(), jobFixture(), "local-ai"), /Copilot test failure/);
      assert.equal(fetchMock.mock.callCount(), 0);
      const deterministic = await selectResume(profileFixture(), jobFixture(), "deterministic");
      assert.equal(deterministic.mode, "deterministic");
    });
  } finally { statusMock.mock.restore(); selectMock.mock.restore(); fetchMock.mock.restore(); }
});

test("absent provider preserves Ollama confidentiality gates; unsupported providers do not fall back", async () => {
  const old = process.env.OLLAMA_NO_CLOUD;
  delete process.env.OLLAMA_NO_CLOUD;
  try {
    await withProvider(undefined, async () => {
      const status = await getAiStatus();
      assert.equal(status.available, false);
      assert.equal(status.provider, "ollama");
      assert.equal(status.remote, false);
      assert.match(status.reason!, /OLLAMA_NO_CLOUD/);
    });
    await withProvider("unknown-provider", async () => {
      assert.equal((await getAiStatus()).available, false);
      await assert.rejects(selectResume(profileFixture(), jobFixture(), "local-ai"), /Unsupported/);
    });
  } finally {
    if (old === undefined) delete process.env.OLLAMA_NO_CLOUD;
    else process.env.OLLAMA_NO_CLOUD = old;
  }
});
