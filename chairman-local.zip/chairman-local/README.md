# Chairman

A private job-search homepage and complementary Chrome side panel. Chairman
discovers permitted public jobs, selects among your approved baseline resumes,
tailors factual PDF/DOCX applications, fills supported career-page fields, and
keeps a durable application/status/notes table. Optional Gemini public-tag ranking
and read-only Gmail status suggestions keep costs and data exposure explicit.

**Two complementary workflows:** the extension plans and fills the application page
you have open, with per-site access and a reviewed fill action; the homepage coordinates
discovery, documents, tracking and a separately authorized dedicated Auto Apply
browser. Filling a form does not count as submitting it.

**This is not a universal auto-apply bot.** Auto Apply uses a dedicated local
Chrome browser for supported company career forms after explicit
standing authorization. It needs **at least two approved, valid uploaded resumes**
in any of the four available slots. It chooses the closest base template and, by
default, creates a JD-specific PDF/DOCX from confirmed profile facts for each job.
Original uploads are preserved; saved factual answers fill application fields.
Restricted sites, unsupported forms,
unknown required answers, active CAPTCHA, login challenges and required legal/
own-words declarations pause or skip work rather than being bypassed.
No actual job applications are submitted merely by installing or uploading files.

## Status and handover (29 Sep 2026, version 0.9.0)

Development moves from this Mac to the user's Windows PC, with a free AI model there.
**If you are the next developer or AI model, start with [HANDOVER.md](HANDOVER.md)**
(state, rules, architecture, open items, recent changes), then [WINDOWS.md](WINDOWS.md).

- Everything for the move is in `dist/Chairman-for-Windows-2026-09-29/`: the Windows
  app (`chairman-windows.zip`), this source (`chairman-local.zip`), the extension, the
  user's data (`chairman-data-2026-09-29.zip`, private) and `START-HERE.txt`.
- Every Chairman service on the Mac is stopped and nothing starts automatically;
  `npm start` resumes it here.
- 0.9.0 adds the **Today** list (100 roles a day from ~56 tracked companies),
  **Progress** with role families and resume slots, the answer bank with an inbox of
  questions seen on real forms, **application sessions** (50 roles, 10 tabs at a time),
  the extension's **step-by-step driver** (Workday: Autofill with Resume, each step
  filled and continued, stops before Submit), evidence-based **Applied**, the **AI** tab
  (Ollama, Gemini free tier or GitHub Copilot) and `npm run export-data`.

## Windows single-entry-point bundle

Use **`dist/chairman-windows.zip`** on Windows 10/11 x64. It includes the prebuilt
homepage and extension, official Windows Node runtime, clean lockfile-derived
Windows production dependencies, and Chrome for Testing. No system-wide Node,
npm install, Ollama or existing Chrome installation is needed to start this bundle.
This is an x64 build, not a native Windows ARM64 build.

1. Copy the Windows ZIP to the PC and use **Extract All**. Do not run files from
   inside the ZIP or copy this Mac's `node_modules`.
2. Double-click **`Start Chairman.cmd`** in the extracted `Chairman` folder.
3. Keep the launcher window open. It checks the bundled files, starts the local
   service and opens the homepage. No first-run dependency download is needed.
   Internet access is still needed for job websites, Google sign-in and Gemini.
   Load `dist/extension` using Chrome's **Developer mode > Load unpacked**, then
   pair it in Setup. That one-time user action is not bypassed or silently automated.
4. In **Setup > Configured AI**, choose Gemini and save your own
   [Google AI Studio API key](https://aistudio.google.com/api-keys). Use a **Free
   project with billing disabled**, then explicitly confirm the processing and
   free-project choices. The app cannot independently prove a key's billing tier.
5. Upload and confirm your profile and at least two resume variants on the PC.
   Select Gemini-assisted tailoring if desired, review the Auto Apply rules and
   activate. Installation never grants application authorization.

Gemini uses the **Developer API**, not the free Gemini chat website. The exact
supported model is `gemini-2.5-flash`, with no model or provider fallback.
Only anonymous fact references and recognized tags from a fixed public technical
vocabulary leave the device. Resume wording, contacts, employers, dates, links and
full job descriptions stay local. Gemini ranks those tags; local code selects and
renders the corresponding confirmed facts into the JD-specific resume.

[Google's unpaid API terms](https://ai.google.dev/gemini-api/terms) prohibit
personal/confidential inputs and permit model improvement and human review of
submitted content. No paid plan or billing account is enabled by this app.
[Quota varies by project and model](https://ai.google.dev/gemini-api/docs/rate-limits);
HTTP 429 pauses requests rather than switching models or using a paid fallback.
**500 applications/day remains a campaign target, not a free API allowance or a
guaranteed number of successful submissions.**

The ZIP is safe to transfer as software: it deliberately excludes profile data,
resumes, history, browser sessions, keys and `.env`. To take your data along, run
`npm run export-data`: it writes `dist/chairman-data-<date>.zip` (a consistent
database snapshot plus your resume library and documents; no keys, pairing,
browser profiles or logs) with a `RESTORE.txt` inside. On Windows, persistent data
is separate from the extracted app at `%LOCALAPPDATA%\Job Application Assistant`
(extract the data zip into `%LOCALAPPDATA%`); moving the program folder is not a
personal-data backup. See [WINDOWS.md](WINDOWS.md) for launcher details and
troubleshooting, and [Gemini integration](packages/inference/README.md) for the
provider's exact boundaries. Native Windows execution has not been verified on
a Windows host. Optional Copilot helper executables may additionally require an
approved Microsoft Visual C++ v14 x64 runtime; this prerequisite is not needed by
the bundled Node/Gemini path and is not silently installed. Existing private-data locations and API/environment
names remain compatible with earlier Job Application Assistant releases; the
Chairman rename does not move or erase your profile.

## Open or install the source bundle

**If the dashboard opens at http://127.0.0.1:4318, the local app is already
running on that computer.** You do not need another ZIP or the optional extension to use Auto Apply.
Do not start a second server on the same port.

The extension and source downloads are ZIP archives, not native installers.
The Windows portable ZIP has the single launcher described above:

- **Chrome extension ZIP:** extract it, open `chrome://extensions` in regular
  Google Chrome 120+, enable **Developer mode**, and click **Load unpacked**.
  Select the extracted `chairman-chrome-extension` folder that directly
  contains `manifest.json`, not the ZIP or its parent folder. From this source
  checkout, select `dist/extension`. Keep the selected folder on disk.
  Pairing instructions are in the extension folder's `README.md`.
- **Local app ZIP:** this is a Node.js project with a prebuilt dashboard, not a
  macOS `.app` or `.dmg`. On another Mac, install Node.js 22.13+ with npm and Google
  Chrome, extract the ZIP, and open Terminal in `chairman-local`.
  Run `npm ci`, then `npm start`. Open http://127.0.0.1:4318 after startup and
  keep the terminal/service running. Private profile data and installed
  dependencies are intentionally not bundled.
- **Continuing development elsewhere:** [HANDOVER.md](HANDOVER.md) is a
  self-contained onboarding prompt for a new developer or coding agent. It
  covers first-run and pairing on Windows, commands, architecture, the
  non-negotiable safety rules and a prioritized improvement backlog.

If downloading does nothing inside an embedded preview, open the dashboard
address in regular Chrome and use its download buttons there. Chrome cannot load
an unpacked extension from inside the app's embedded browser. If your managed
browser disables Developer mode, use the dashboard without the extension rather
than bypassing your organization's policy.

## Current setup

- Version 0.9 adds the daily **Today** list, **Progress** (companies, role families,
  resume slots 1–8, filters), the answer bank and its inbox, application sessions in
  your own Chrome, the extension's step-by-step driver that stops before Submit,
  evidence-based "Applied", the AI tab, notice-period questions, background-tab
  robustness and a portable data export. See HANDOVER.md for the file-level map.
- Version 0.8 names the app **Chairman**, makes Home the starting point, adds a
  permissioned current-page Chrome assistant, consolidated status/notes tracking,
  configurable discovery and manual portal searches, human-attention notifications,
  optional Gmail suggestions and a self-contained Windows x64 software bundle.
- Version 0.7 adds a transferable Windows launcher package, Windows-aware private
  storage and original-resume copying on filesystems without hard links, plus
  explicit Gemini free-tier setup with private local API-key storage.
- Version 0.6 makes **Auto Apply** the landing page, proactively searches supported
  public feeds for your role preferences, adds bounded generic company-career
  discovery, and handles common multi-step applications with **partial autofill
  and human-in-the-loop continuation**. Live status and redacted screenshots
  make blockers visible. Site-specific limits still apply.
- **GitHub Copilot / `gpt-6-astra`** was this Mac's configured AI option, through
  the official SDK (signed in with the user's own `gh auth login`). On Windows, use a
  free model instead: Ollama locally or Gemini's free tier (WINDOWS.md). Hosted processing stays **disabled until you explicitly
  consent in Setup**. Stored CLI OAuth and access to that exact model are also
  required; this chat's model does not establish SDK access. There is no fallback.
- Version 0.5 makes authorization checks reviewable even while another prerequisite
  needs attention, shows the exact activation blockers, and labels an unset cap
  **Unlimited - no daily cap**. The activation button and server checks still
  require a valid, explicitly reviewed setup.
- **Add a career link** is available in Auto Apply and Sources. Supported employer
  boards and individual jobs feed the same matching/tailoring/application runner.
  Adding, removing or changing a career source pauses the previous authorization
  so you can review the new source scope before sending.
- Version 0.4 lowers the minimum to **two approved, valid resumes** and adds
  **per-job template/JD tailoring**. Extra slots are optional; unapproved or invalid
  extras are neither selected nor counted. The previous authorization must be
  reviewed again because the document-generation behavior has changed.
- Version 0.3 adds **Auto Apply**: a four-slot upload library, explicit activation,
  durable automatic selection/preflight/submission and receipt tracking through
  a dedicated local Chrome profile. It is **off until you supply and approve the
  required data and activate it**.
- Version 0.2 removes the old default 200/day ceiling. There is **no global daily
  or session cap** unless you deliberately configure an optional personal cap.
  Source policies, provider limits, duplicate protection and exact approvals remain.
- Home tracks a **500/day, 45-day campaign** (22,500 target), confirmed outcomes,
  interview/offer reports, source conversion and follow-ups. This is a target,
  not an automated schedule, a guarantee, or permission to submit unreviewed work.
- Resumes can generate six **local, unverified reference drafts** from the saved
  source resume, in PDF and DOCX. Drafts do not confirm profile facts or approve
  any application. Application-specific resumes still require a confirmed profile.
- The dashboard runs at **http://127.0.0.1:4318** when the local service is started.
- Local AI (Ollama) does not run usably on this Mac; the free local model is set up on
  the Windows PC instead (WINDOWS.md → Free AI). Without AI, unknown questions wait
  for you.
- The existing resume and uploaded templates are kept in private local storage.
  Their original files are unchanged. Review the current confirmation status in
  Profile before enabling applications.
- The Chrome extension build is in `dist/extension`; loading and pairing it is a
  user action, not an automatic installation into your browser.
- **Cloud deployment is pending Cloudflare sign-in.** No Worker or D1 database has
  been deployed. Until that setup is completed, discovery only runs while the local
  app is running. The app does not claim the cloud is active merely because code exists.

## Run automatic applications

1. In **Profile**, save your real details and review/confirm the facts. Add the
   factual answers relevant to your applications: residence country/city, notice
   period, availability, experience by technology, work authorization and salary
   expectations with currency/period. Missing required answers are never guessed.
2. Open **Auto Apply** and upload **at least two final PDF/DOCX resume variants**,
   using any of the eight slots (one per role family works best, see
   [Companies, role families and the CAPTCHA hand-off](#companies-role-families-and-the-captcha-hand-off)).
   Explicitly approve each usable file's accuracy. Other slots are optional.
   The extracted name/email must match your profile. The generated reference/sample
   drafts are not accepted as final automatic-application resumes.
3. Review the providers (including **Generic company portals**), minimum alignment, unknown-salary/visa/remote-location
   handling, employer allowlist and pacing. Unknown sponsorship and remote-country
   eligibility are excluded by default; broadening those rules is an explicit choice.
   **Tailor to each job description** is the default document strategy. Choose
   evidence-based tailoring (no model/API cost) or configured AI selection. You can
   instead explicitly select **Send original unchanged**.
4. Review the standing authorization and click **Enable automatic applications**.
   This authorizes matching applications without per-job approval, using only the
   current profile, approved base files and selected tailoring/submission rules. Uploading, pairing,
   editing targets or opening Chrome does not activate it.
5. Keep your computer awake and the local service running. Use **Open automation
   browser** for any sign-in required by a provider; enter credentials yourself.
   This browser profile is separate from your everyday Chrome profile. Do not
   paste passwords, OTPs or provider tokens into the profile/answer bank.

## Automatic work and human review

There is no need to prepare each role manually. Once activated, the runner searches
the supported public job APIs and configured career pages for your saved role
preferences, matches openings, chooses/tailors an approved resume, and fills
supported applications. This is bounded public-source discovery—not unrestricted
Google/LinkedIn scraping, and not proof of 500 suitable vacancies per day.

**Live progress** shows discovery, matching, prefill, advancement, human-review and
receipt events. **Show live browser** is an opt-in, redacted view from a private
local endpoint; the actual editable tab stays in dedicated Chrome.

When a question or control blocks progress, **Needs your attention** keeps the
same prefilled application open. Enter a factual answer in the task or choose
**Open existing prefilled tab** for login, CAPTCHA, legal controls or complex
widgets. Explicitly review the current form before continuing. One-off answers
do not change your global profile. No assessment or credential is guessed.
If you submit directly in Chrome, record the actual receipt in Applications
instead of submitting a second time.

Up to **Tabs waiting for you** prefilled tabs (Auto Apply rules, 10 by default,
at most 50) can wait while other jobs progress. This is a resource bound, not a
daily application ceiling; many open tabs use a lot of memory. Uncertain final submissions cannot be
retried automatically. Browser/session loss requires manual reconciliation.
See [`packages/automation/PORTALS.md`](packages/automation/PORTALS.md) for exact
scope, network restrictions and unsupported portal behavior.

## Today: your daily list

**The crawler starts on its own.** Open **Progress → Suggested companies** and click **Add all**. About 55 of
your ~70 target companies have a public job board (Greenhouse, Ashby, Lever, SmartRecruiters, Workday,
Eightfold, Oracle Recruiting, Rippling, Google Careers, Apple Jobs, Atlassian and Nutanix). Chairman reads each one in a
single pass, about a minute per company (Apple: a few minutes), one at a time, while the local service runs.
Google and Apple applications need your own account sign-in, so their roles offer **Fill in my Chrome** only. It keeps only roles
whose title fits your role families, and checks every board again about once a day. The rest have no public
board and are listed under "Check these yourself". You can also paste any board or posting link in **Add a
company**.

Every morning (7:00 India time by default) Chairman refreshes every company and builds **Today**: the 100
best-fitting roles, at most 10 per company. A role is included when:

- its title and description fit one of your role families, and its level and required years fit your
  experience (from Profile → `total_years_experience`, or your confirmed experience dates);
- it is in India, remote without a region limit ("Remote", "Remote - Global"), or abroad. Remote roles limited
  to another region ("Remote - US", "EU only", "California - Remote") are never included, and neither are roles
  abroad that say they cannot sponsor a visa;
- by default, roles abroad that state visa sponsorship come first, then India and global remote, then roles
  abroad that do not mention sponsorship. You can switch to India first and change any of this under **List
  settings**. Per company, you can note "sponsors visas" in Progress for when a posting is silent.

### Auto-apply in your Chrome (sessions of 50)

**Auto-apply top 50 in Chrome** on Today starts a session: Chairman opens today's best to-do roles in your own
Chrome, **10 tabs at a time**, in the window you started from (the side panel stays open across them, and each
tab's application is kept separate). In every tab it:

1. opens the application directly where the site allows it (Workday's resume autofill, Lever `/apply`, Ashby
   `/application`), or presses **Apply** on the job page;
2. waits while you **sign in, create an account or complete a verification check** (it never reads sign-in
   pages or solves CAPTCHAs);
3. fills each step from your saved answers, your profile (name parts, city, phone code, work history) and, for
   anything else, your configured AI; attaches the resume for the role's family; presses **Next / Save and
   Continue** once per step;
4. stops at the step with **Submit** as *Ready for your review*. You check every answer and submit yourself.

A tab waits for you when a required question has no answer; answer it on the page or in the side panel and it
continues on its own, remembering your answer for the next form. The next role opens as each one is finished
(submitted, skipped or closed). When all are finished, **Apply to the next 50** starts the next session; roles an
earlier session opened are not reopened.

### What "Applied" means

**Applied ✓** always has proof: the employer's confirmation page seen in the tab you submitted from ("Thank you for
applying"), a runner receipt, or a confirmation you recorded. **I submitted it** records your word only and is shown
as **Marked by you · not verified** (with Undo) until proof is seen. *Filled* and *Ready for your review* are never
applied.

Each role can also be opened on its own: **Fill in my Chrome** asks the paired extension to open it in a new tab,
start the application (on Workday: **Autofill with Resume**), upload the resume for its role family, fill each step
and press Next / Save and Continue up to the review step. Sign in when the site asks; it carries on. It never presses
Submit. On a job page you opened yourself, click the Chairman icon and **Fill everything** to do the same. **Chairman window** sends it to the separate runner, which
submits by itself after you solve its CAPTCHA (Auto Apply must be activated).

## Companies, role families and the CAPTCHA hand-off

**Progress** tracks the companies you care about. Add a company with its careers
page (any supported board above, or a company careers page) and pick the
role families to apply for there. Chairman checks each page on a schedule and lists
every role as **Needs you**, **In progress**, **Not applied**, **Applied**,
**Failed** or **Not relevant**, with the matched keywords and the resume used.

**Role families** (bottom of Progress) decide relevance and the resume. A role
belongs to a family when its title contains one of the family's title keywords,
no exclusion word, and its description has enough skill keywords. "Always apply"
families (Data Engineering and Cloud Engineering by default) apply at every
company; others only where you picked them. Assign each family a resume slot
(1–8), for example slot 1 data, slot 2 cloud, slot 3 software, slot 4 AI/ML,
slot 5 forward deployed, slot 6 cloud platform. With **Only apply to roles in my
role families** on (default), everything else is skipped.

**Profile → Standard application questions** holds about 60 common questions
(eligibility and visa, relocation, notice period, salary, education, background
checks, military service, how you heard about the job, voluntary
self-identification). Answer once; the extension and Auto Apply recognize the
many wordings forms use, including company-specific ones such as "Have you worked
at {company} before?". **Questions from real forms** collects questions Chairman
had no answer for (labels only), so you can answer them once. Answers can be
exported and imported as JSON:

```json
{ "answers": { "notice_period_days": "30", "willing_to_relocate": "Yes", "eeo_gender": "Male" },
  "preferences": { "fillVoluntaryDisclosures": true, "acceptRequiredAcknowledgements": false } }
```

Two switches there are off by default. **Fill my voluntary self-identification
answers** sends your saved gender, race/ethnicity, veteran, disability and
pronoun answers (including "I don't wish to answer"). **Accept required
acknowledgements in my name** ticks required "I agree / acknowledge / certify"
boxes, accepts "by submitting you agree" terms and declines optional marketing;
each one is recorded in that application's history.

**The CAPTCHA hand-off.** Auto Apply fills forms in the dedicated Chairman Chrome
window with the same page engine as the extension (custom yes/no buttons,
comboboxes, the right resume upload, conditional questions). When only a CAPTCHA
is left, the tab stays open with a title starting **🔐 Solve CAPTCHA** and the next
job starts. Solve the CAPTCHA in that tab; Chairman notices within seconds and
submits by itself, then confirms the receipt. If Submit itself opens a challenge,
solve it and Chairman confirms the receipt without clicking Submit again. Tabs
titled **✋ Needs you** wait for answers in **Needs your attention**. Chairman never
solves or bypasses a CAPTCHA.

In these tabs, CAPTCHA provider frames (reCAPTCHA, hCaptcha, Turnstile) and the
employer's same-site APIs load normally. Third-party requests such as analytics
are dropped without stopping the application, so nothing from the form goes to
another site. Cross-origin navigation and frames still pause for review.

## GitHub Copilot model setup

The app uses the official `@github/copilot-sdk`, not this chat's internal endpoint
or authentication token. The requested model ID is **`gpt-6-astra`** exactly.
It is checked against the account's SDK model inventory; unavailable or
organization-disabled models cause an explicit error, not a replacement model.

Sign in yourself using the official interactive CLI:

```bash
npm exec --package=@github/copilot -- copilot login
```

This may offer to download the official CLI. The SDK includes a headless runtime,
not that interactive login UI. The command is documented in GitHub's
[CLI command reference](https://docs.github.com/en/copilot/reference/copilot-cli-reference/cli-command-reference).
No password or token belongs in the application profile or chat. If you already use the
GitHub CLI, your own `gh auth login` works too (Chairman's AI runtime only looks in standard
install locations such as Homebrew, so it never uses a `gh` bundled inside another app).
Tokens passed through environment variables are never used.

On the **AI** tab, the models your Copilot account can use are listed; pick one (or
enter the exact ID of a newer model that is not listed yet), review the hosted-data and
Copilot-allowance acknowledgments, and save only if you agree. **Send a test question**
checks the saved model with a fixed question that contains nothing about you. Then refresh AI status and select AI-assisted tailoring in Auto Apply
if desired. The legacy API mode name `local-ai` now refers to the explicitly
configured provider; the UI shows whether processing is local or hosted.

Copilot receives only bounded confirmed resume-fact/skill and JD text for
constrained selection. It is denied tools, filesystem/browser access, MCPs and
permission escalation. OAuth/model metadata and inference fail explicitly.
Your resume files, browser sessions and credentials are not uploaded to Copilot.
The SDK can consume subscription allowance/premium usage; this is not free local
inference. You can revoke remote-processing consent in Setup.

Ollama remains a separately selectable local option. Evidence-based tailoring
uses no model calls. Choosing either is explicit; neither substitutes silently
when the requested Copilot model is unavailable.

### If authorization looks blocked

An empty daily cap is valid unlimited mode. It does not need to be configured
before selecting authorization checkboxes or activating.

The review boxes do not send anything and can be checked before other prerequisites
are complete. **Activate Auto Apply** remains disabled until all real blockers are
resolved: confirmed profile, two approved valid resumes, saved edits, an available
chosen AI engine, and a running queue. The section lists each blocker and offers
links to the affected settings, a contextual queue-resume button, and an explicit
option to discard unsaved Auto Apply edits without changing saved data.

Checks are reset when the saved authorization scope changes. Refreshing unchanged
saved data does not erase your selections. If the integrated browser is in its
element-inspection mode, exit that mode before interacting with page controls.

### Add your own career links

In **Auto Apply** or **Sources**, paste a public career URL and an optional label:

- An Ashby or Greenhouse **board** imports its public openings in bounded pages.
- A supported **individual job** imports only that job.
- A public employer **careers page** is inspected for actual links to those boards.
  If several are found, choose the intended board; the app does not guess.
- Generic public career pages can also yield real JSON-LD job postings or a bounded
  set of clearly linked same-origin job-detail pages. JavaScript-only indexes
  without an extractable JD remain watch/manual sources, not fabricated openings.
- Unsupported portals, restricted job boards, private-network addresses and
  protected pages remain explicit human/manual tasks.

The link starts discovery, not an unreviewed application. After adding sources,
review the enabled source list and **activate Auto Apply again**. Eligible jobs
then use the same approved templates, JD-tailoring strategy, factual answer bank
and provider safeguards as other jobs. No new provider login tokens are created,
and a career URL does not make an unsupported application's form automatable.

Each source shows its imported job count, last/next scan, provider, status and
errors. Pause, resume or remove it from that panel. Scans use durable board
cooldowns, continue across bounded pages and refresh periodically; manually
clicking scan cannot bypass a provider backoff. Duplicate boards/jobs do not
create duplicate submissions. Pausing/removing a custom-only source excludes
its jobs from automatic applications; a job independently available from another
enabled source may still qualify under your rules.

The source label is a display label, never evidence to rename an employer or evade
your exclusions. Only public GET discovery is performed. General employer pages
are fetched under strict public-network and redirect restrictions; scripts are not
executed to discover arbitrary links. Personal profile/resume data is not sent to
career pages during source discovery.

The worker selects eligible supported jobs, inspects the actual form, resolves
known fields, and chooses the best approved base. In JD-tailored mode it generates
a separate resume packet for that job and uploads the exact compatible generated
PDF or DOCX, rather than the generic original. Its stored record includes the
source template hash, JD hash, selected facts/keywords, frozen resume content and
the hash of the exact submitted file. In original mode, it sends the unchanged
uploaded file and uses immutable hard links to avoid duplicate storage.

### What per-job tailoring does

The uploaded template guides source emphasis and ordering; the confirmed Profile
remains the authority for factual claims. The JD determines relevant experience,
skill priority and supported name/abbreviation equivalents. Employers, titles,
dates, qualifications and metrics are preserved, not invented. Template-only
claims absent from the confirmed profile are not automatically promoted to facts.
Transferable foundations and missing JD skills stay out of asserted skills.

Outputs use a clean single-column ATS-safe layout. They do not promise a
pixel-perfect copy of an uploaded PDF, a "perfect" resume, or an employer ATS
score. Local-AI mode fails explicitly if the model is unavailable; it does not
silently fall back to another mode or a cloud service.

Use **Preview JD-tailored resume** to generate and inspect a local packet from a
chosen approved base and job before activation. A single approved base is enough
for a preview; at least two are required to activate Auto Apply. Previewing creates
neither a standing authorization nor a submission. Each generated packet remains
downloadable under Applications even after the current profile is edited.

**Pause** or the global **Stop queue** prevents new actions; in-flight data cannot
be recalled. Profile, resume, approval, rule or campaign changes revoke the old
standing authorization. Its expiry is tied to the reviewed campaign dates.
Interrupted/unknown submissions never retry automatically. Safe preflight blockers
can be rechecked after you resolve them; any existing transmission attempt needs
manual reconciliation rather than duplicate submission.

The default goal remains 500/day, not a guaranteed outcome or a fabricated count.
The default has no global application ceiling; an optional personal cap, site
restrictions, provider backoff and the optional "stop at daily goal" rule still
apply. Insufficient eligible vacancies or incomplete answers may result in fewer
submissions. Chrome must be available locally; the public cloud scanner does not
run this private submission browser while your Mac is off.

An optional user-authored `cover_letter_template` / `motivation_template` may
answer ordinary narrative fields. Only `{company}` and `{role}` are substituted.
Templates never answer assessments, legal declarations or unrelated questions.
No new experience, qualifications or personal claims are generated.

See [`packages/automation/README.md`](packages/automation/README.md) for supported
provider structures, current evidence and the precise browser safety boundaries.

## Start and stop

From this directory:

```bash
npm start
```

If you select Ollama and its local model server is not running, start it in another
terminal. Evidence-based JD tailoring and original-file selection do not need an
LLM call per application; AI-assisted tailoring uses the explicitly selected provider:

```bash
npm run ai:serve
```

Both commands run in the foreground and stop with Ctrl+C. During initial setup,
the assistant may already have started these processes. Do not start a second copy
on the same ports. The UI's **Stop queue** stops application work, not the web or AI
servers; a request already sent to an employer can still complete.

On a new installation, use Node 22.13+ with npm, then:

```bash
npm ci
npm run build
```

For the optional local AI provider, install Ollama from its official distribution, start it in local-only mode, and
download `qwen3:4b` using `ollama pull qwen3:4b`. Model downloads require disk space
and an internet connection; subsequent inference uses local weights, not a paid API.
No Chrome Store account, paid domain or job-site subscription is needed.

`.env.example` documents configuration. The local `.env` contains no credentials
and enables `OLLAMA_NO_CLOUD=1`. `npm start` loads `.env` if present. Keep real sync
tokens only in this ignored file or a private environment/secret manager. Never
share them in chat or commit them.

## Use the dashboard

1. Open **Profile**. Review contact details, links, skills, achievement wording,
   employer/title/date metadata and imported facts. Confirm only true facts.
   Complete notice period, availability and any required answers; do not store
   passwords, verification codes or confidential employer material.
2. Open **Opportunities**. Discovery runs on startup and on a bounded recurring
   local schedule. **Scan** fetches another bounded page from permitted sources.
   Source cooldowns, errors and missing information are visible; a successful page
   does not mean the entire source has been scanned.
3. Review role fit, location, work authorization, salary evidence and missing skills.
   You can manually add an employer-original job URL and a JD you are permitted to use.
   Importing a link does not fetch an arbitrary website or enable its automation.
4. Optionally prepare an **AI-assisted** or clearly labeled **deterministic** manual packet. Both select
   and order your confirmed source facts and skills; they never invent experience.
   Download/inspect its text-based PDF or DOCX and edit factual application answers.
5. The per-packet workflow below is separate from Auto Apply. Unknown questions,
   legal declarations, CAPTCHA and unsupported controls require manual handling.
   Auto Apply uses its own standing authorization and dedicated browser preflight.
6. Select the exact packets to approve. Review warnings, resumes, answers and
   destinations. Supported packets can be executed through the extension; other
   approved generated packets become **manual-only** with a download/handoff workflow.
   The legacy extension's direct-form driver remains a controlled-fixture tool;
   real supported forms use the new Auto Apply browser runner.
7. Track outcomes in **Applications**. A click is not a receipt. Unknown outcomes
   block duplicate attempts; reconcile them using a real employer confirmation.
   A manual confirmation is explicitly labeled **user-reported**.

Your initial preferences are engineering roles, India and suitable English-working-
language opportunities abroad, sponsorship required for overseas relocation,
full-time/long-term work, an INR 50 lakh annual base **target** rather than hard
minimum, and HPE/Aruba excluded. International travel is a bonus when the JD says so.

The old global **200/day ceiling is removed**. Leave the optional daily cap empty
for uncapped daily/session volume; a separately chosen personal cap still works.
Asia/Kolkata defines daily reporting, and the current service startup defines the
session counter. Source limits and uncertain-outcome protections remain binding.
The 500/day campaign number is a target, not a limit or a promise.

Choose eligible jobs for **bulk local preparation**. Tasks persist, run serially,
reuse matching valid drafts, and never approve or send applications. Stop/cancel
controls retain their stated boundaries. Requests accept up to 1,000 job/packet
IDs as a bounded payload, not a daily/session quota; use more requests as needed.
Complete job and packet history is server-paginated instead of rendering every
record at once. Queue totals cover the entire database even when only priority
records are loaded.

In Applications, record actual interview/offer stages and next-action dates.
**External application records** let you log a submission you made yourself,
including manual-only/no-AI sites, without generating a resume or falsely
approving a packet. Enter the real date and confirmation; these are user-reported
records, not independently verified provider receipts. Duplicate jobs are not
counted twice. None of these controls sends recruiter messages or applications.

Relevant JD terms can be included when they are direct evidence or reviewed
equivalent names/abbreviations of your selected facts/skills. Adjacent platforms
are marked as **transferable foundations**, not claimed hands-on experience.
Learning-only, negated and hypothetical source statements do not become skills.
Employers, titles, dates, education, metrics and experience are never invented.

## Source support

| Source | Public discovery | Application behavior |
| --- | --- | --- |
| Himalayas | Documented API, bounded pages, original-source attribution | Original destination independently reviewed |
| Supabase | Public Ashby board | Employer-specific review needed |
| Automattic | Public Greenhouse board; one detail per page | Native form review; assessments remain human-led |
| Canonical/Ubuntu | Public Greenhouse board; large/slow feed can defer | Conservative no-AI hold; human-authored/manual until current form is reviewed |
| SafetyWing | Published Pinpoint RSS | AI wording guidance is not submission permission |
| LinkedIn | Manual-only | No extension scraping, filling or submission |
| Indeed | Manual-only | Search links only; no automated access without applicable permission |
| Wellfound | Manual-only | No automation grant verified |
| Naukri.com | Manual-only | Policy/API permission unverified |
| Deel | Manual watchlist | Current custom portal not a verified generic Ashby connector |
| Toptal | Manual corporate/talent-network distinction | No bulk network signup or automated screening |
| SideShift.app | Manual corporate engineering watchlist | No creator gigs, creator signup or customer demo forms |
| Remotive | Complete public software-dev category snapshot; at least six hours between attempts | Preserve attribution; no application API grant |
| Arbeitnow | Public paginated feed; at least one hour between attempts; mostly Europe | Temporary private cache; no automatic India eligibility |
| Remote OK | Public current snapshot; conservative once-daily retrieval | Preserve source name and original follow link; no logo use |

Public GET documentation does not grant employer application POST credentials or
permission to operate a form. The application never uses employer ATS API keys.
Source health separates empty pages, failures, blocked connectors and known expiry.
Missing jobs in a feed are not silently asserted to be closed.

Himalayas listings remain attributed and linked to Himalayas. The cache is private;
do not republish it or upload listings to another job board.

## Chrome setup

**The extension and homepage share the same local workspace.** The side panel is a
page-assisted filler: after a per-site access grant, **Plan answers for this page**
reads the application form's structure (never its current values), proposes an
answer per question from your confirmed profile, answer bank and remembered
answers, and, if enabled, asks your configured AI (local Ollama or consented
Copilot, never Gemini) about questions with no saved answer. AI output is checked
against your confirmed facts and cached so the same form is always planned the same
way. Review and edit the plan, choose the resume, confirm, and fill; site validation
errors come back as reviewed fixes. Consent, demographic and legal questions,
sign-in, CAPTCHA and no-AI rules stay with you. Next and final Submit remain your
clicks; record the actual receipt afterward. JD import and resume tailoring are
optional. No automatic filling occurs merely because a page is visited.

The separately authorized Auto Apply runner opens its own dedicated Chrome
profile. An extension site-access grant does not activate that runner or grant
submission permission. The older extension packet executor is retained only for
controlled fixtures; it is distinct from the new current-page assistant.

1. Run `npm run build`.
2. In Chrome, open `chrome://extensions`, enable **Developer mode**, choose **Load
   unpacked**, and select this project's `dist/extension` directory.
3. Open the local dashboard's **Setup** page and generate a pairing token.
4. Open the extension side panel, enter the local port (4318 by default) and pairing
   token, and connect to `http://127.0.0.1:4318`. The token stays in Chrome session storage. Re-pair after the local
   service restarts; generating a replacement token invalidates the previous one.

The extension requests destination access only as needed. It never reads browser
cookies or password fields and never controls restricted sites. See
[`apps/extension/README.md`](apps/extension/README.md) for the supported controls
(including ARIA/React-Select comboboxes, Yes/No buttons and styled upload widgets),
the AI data boundary, pause conditions and the recovery workflow. Remembered page
answers and the AI suggestion cache are managed under Profile → Application answers.
For real-site testing, `npm run demo` starts an isolated demo instance on port 4319
with a fictional applicant, and the side panel's **Debug** section shows each
step (worker, page script and local service) with the exact step that failed.

Sources supports enabled/disabled public feeds and custom HTTPS search links.
Search templates can contain `{role}` and `{location}`. Adding a LinkedIn,
Indeed or other restricted portal is a manual bookmark, not permission to crawl
its signed-in pages. Use the employer's original career destination when permitted.
Keep passwords and verification codes in the website/browser, not your resume or
Chairman profile. Browser and desktop notifications require an explicit opt-in.

## Optional Gmail status connection

In **Setup > Gmail status suggestions**, configure your own Google **Desktop
app** OAuth client after enabling the Gmail API and setting up its consent screen.
For a personal testing project, add yourself as a test user. Save the client,
review the read-only acknowledgement, choose Connect Gmail and complete Google's
sign-in page. Return to Chairman and refresh Gmail status.

Chairman requests only `gmail.readonly`, using a loopback callback, random OAuth
state and PKCE. This is a restricted Google scope: Google may require
verification, and external testing-mode refresh tokens can expire after seven
days. A Gemini key and your resume email address cannot substitute for this login.
See [Google's installed-app OAuth guide](https://developers.google.com/identity/protocols/oauth2/native-app)
and [Gmail scopes](https://developers.google.com/workspace/gmail/api/auth/scopes).

Each explicitly requested scan examines at most 25 recent application-related
messages from the past 90 days. It reads metadata and snippets, not attachments
or full bodies; matching and status suggestions run locally, never through an LLM.
Only an unambiguous company/role match to an already confirmed application produces
a suggestion. Review and accept or dismiss it. No email is sent, deleted or marked
read, and no submission counter increases from an email suggestion.

OAuth credentials are stored separately in `private/gmail.json`, excluded from
exports and packages. Suggestions retain only bounded headers and suggested
status metadata in the local database. Disconnect removes local credentials and
suggestions and requests Google revocation; any revocation failure is shown
explicitly. You can also revoke access in your Google Account connections.

The older per-packet extension path can carry a private `JAA_POLICY_FILE`. The example file
is deliberately empty. Each real entry must reflect an actual policy review and
compatible employer form, not merely your desire to apply:

```json
[
  {
    "employer": "Exact employer name",
    "host": "jobs.ashbyhq.com",
    "pathPrefix": "/exact-employer-board",
    "policyUrl": "https://employer.example/actual-applicable-policy",
    "reviewedAt": "REPLACE_WITH_ACTUAL_ISO_REVIEW_TIMESTAMP",
    "allowFill": true,
    "allowSubmit": false,
    "dailyLimit": 5
  }
]
```

This is an illustrative legacy schema, not Auto Apply activation or a provider permission grant. Reviews expire
after 30 days. The server still refuses restricted domains, unsupported controls,
AI-policy conflicts and changed packets. Start with submission disabled; a compatible
form and applicable permission must be established before enabling it. Account
terms, hiring assessments and own-words/no-AI declarations are not automated.

## Optional always-on scanner

Follow [`apps/scanner/README.md`](apps/scanner/README.md) after signing in to your own
Cloudflare account. That guide covers creating the **public-job-only** D1 database,
replacing its placeholder ID, applying the migration, setting the `SYNC_TOKEN`
Worker secret and deploying on **Workers Free**.

Set these private local environment values afterward:

```text
JAA_CLOUD_URL=https://job-application-scanner.YOUR-ACCOUNT.workers.dev
JAA_CLOUD_TOKEN=YOUR_PRIVATE_SYNC_TOKEN
```

Restart the local app. It will incrementally synchronize public listings, checkpoint
only after durable writes, and recover an expired cloud cursor explicitly. The cloud
never receives profile facts, resume documents, answers, application records, browser
credentials or AI prompts.

The default Worker scans bounded Himalayas pages. Larger vendor feeds require
measured opt-in; **all-source 24/7 coverage is not promised**. Workers Free has a
10 ms CPU budget per invocation, which must be measured after deployment. Free
quotas or oversized feeds pause/defer work rather than enabling paid services.
Local vendor scanning can continue independently while your Mac is awake.

Remotive, Arbeitnow and Remote OK are local-only and cannot be enabled in the
Worker merely by changing its source environment variable. The local scanner
persists retrieval cooldowns before requests, including failures, and respects
longer Retry-After periods. A 401/403 blocks that source pending review.
Arbeitnow descriptions are removed when the local viewing service stops, with a
short bounded cache while running. Expired or revoked source descriptions are
removed even from application-linked jobs; only minimal tracking metadata remains.
Cache expiry is not represented as an employer closing a job.

## Downloadable packages and account setup

```bash
npm run package
```

Home and Setup expose the local-source, Chrome-extension and Windows downloads,
with SHA-256 files beside the archives in `dist`.
The local archive contains source, built homepage/extension, lockfile and guides.
`dist/chairman-windows.zip` additionally includes the Windows launcher, Node,
clean Windows production dependencies and Chrome for Testing. The launcher
does not run npm or download missing packages; an incomplete bundle fails with
re-extraction guidance rather than silently changing dependencies.
The extension archive can be extracted and loaded unpacked in Chrome.
Archives deliberately exclude actual resumes, reference drafts, profile/history
databases, credentials, `.env`, model weights and this computer's installed
dependencies. Only the Windows package includes its separately staged runtime
dependencies. For the source archive on another machine, run `npm ci`, configure a private `.env` from the example,
import your own reference resume, and start the local app/model. The current Mac's
private setup is not silently copied into a distributable.

The tokens created by Setup are **cryptographically random local pairing
credentials**, not LinkedIn/Naukri/Wellfound/Cloudflare login tokens. Resume names,
email addresses and phone numbers cannot authenticate to those providers or mint
their tokens. Use the official sign-in/account links and complete verification
and terms yourself. Opening a link does not mark an account connected.
Auto Apply browser logins are stored only in the dedicated private Chrome profile,
not exported to the model, public scanner or ZIP packages.

## Privacy, persistence and recovery

Default private data directory on this Mac:

```text
~/Library/Application Support/Job Application Assistant/
```

It contains the SQLite database and immutable, content-hashed document artifacts.
The resume library and dedicated automation-browser profile are private data too.
Directory/file permissions restrict ordinary local access; this is **not a claim
that SQLite or Chrome storage encrypts its data**. Use appropriate device/account
security and FileVault. Nothing private belongs in this source tree.

- **Export** downloads a private JSON archive of profile/history; resume documents
  can be downloaded individually. Secrets are deliberately excluded.
- **Delete private data** deletes profile, jobs, documents and application history.
  It also closes and removes the dedicated automation-browser profile and uploaded
  resume library. It does not touch your regular Chrome profile.
  The Windows bundle's interactive `chairman-browser` profile is also kept:
  clear website cookies in Chrome yourself, or exit Chrome and the launcher
  normally before removing only that profile folder. Saved Gmail OAuth tokens
  are separate and are revoked/removed by workspace deletion.
  Anonymous current-day total/per-source attempt counts and discovery cooldowns
  remain to honor optional/provider limits. Blocked-source permission holds remain.
  Deleting history also removes
  historical deduplication evidence; export first if you need it.
- Routine logs do not contain resume or answer text. Career-site credentials remain
  in the browser/password manager. Optional Gmail access requires its own explicit
  OAuth consent; it is never enabled merely by entering an email address.
- Restarting the service invalidates dashboard/extension session tokens. Executing
  applications become unknown and are never automatically replayed.
- A changed profile, JD, answer, document or form invalidates its existing approval.
- AI unavailable means AI drafting is unavailable: it never silently falls back and
  labels template output as AI. Deterministic mode is a separate explicit choice.
- Cloud errors/backoff are surfaced in scan results. A scanner code deployment is
  not proof that its schedule or free-tier CPU budget is operational.

No actual ATS score, interview, compensation or visa outcome is guaranteed.
AI chooses existing evidence only; unsupported application questions need your
own answers. Local AI accuracy does not replace reviewing what will be sent.

## Development

```bash
npm run typecheck
npm test
npm run build
npm run test:browser
```

Automated submissions use synthetic local fixtures only. `JAA_FIXTURE_MODE=1`
enables a controlled `/fixture/application`; it is off by default and must not
be used for actual employer applications.

Browser acceptance uses installed Google Chrome and isolated temporary profiles,
never your everyday Chrome profile. The extension test pre-authorizes only its
loopback fixture host in a temporary test copy; the production extension retains
optional, user-granted host permissions.

The original Upskill projects and resume files are not modified. This project is
not published, is not a Git repository unless you initialize one, and has no PR
or hosted personal-dashboard workflow.
