/**
 * A portable copy of your Chairman data for another computer (for example, moving from macOS to Windows).
 *
 * Included: the database (a consistent snapshot, safe to take while Chairman is running) with your profile, saved and
 * remembered answers, questions from real forms, companies, today's list and application history; your resume
 * library; reference resumes; generated documents.
 * Left out: private/ (pairing and provider keys), browser profiles (sign-ins and cookies), backups and logs. The AI
 * provider choice is cleared, because it belongs to one computer: choose one in the new computer's AI tab (Ollama runs
 * a free local model; Gemini's free tier uses your own key).
 *
 * Usage: node scripts/export-data.mjs [--from <data folder>] [--out <folder>]
 */
import { DatabaseSync } from "node:sqlite";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { cp, mkdir, mkdtemp, readdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join, relative, resolve, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

export const DATA_FOLDER = "Job Application Assistant";
/** Folders copied as they are; everything else in the data folder stays on this computer. */
export const INCLUDED_FOLDERS = ["resume-variants", "reference-resumes", "documents"];
/** Settings that describe one computer, not you. */
export const MACHINE_SETTINGS = ["inference"];
export const RESTORE_NOTE = "RESTORE.txt", MANIFEST = "data-manifest.json";

/** Chairman's data folder on this computer (the same rule as packages/platform/paths.ts). */
export function defaultDataFolder(platform = process.platform, env = process.env, home = homedir()) {
  if (env.JAA_DATA_DIR) return env.JAA_DATA_DIR;
  if (platform === "win32") return join(env.LOCALAPPDATA || join(home, "AppData", "Local"), DATA_FOLDER);
  if (platform === "darwin") return join(home, "Library", "Application Support", DATA_FOLDER);
  return join(env.XDG_DATA_HOME || join(home, ".local", "share"), DATA_FOLDER);
}

async function files(folder) {
  const found = [];
  for (const entry of await readdir(folder, { withFileTypes: true })) {
    if (entry.name.startsWith(".")) continue;
    const path = join(folder, entry.name);
    if (entry.isDirectory()) found.push(...await files(path));
    else if (entry.isFile()) found.push(path);
  }
  return found;
}
const sha256 = async path => createHash("sha256").update(await readFile(path)).digest("hex");
const today = () => { const now = new Date(); return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`; };

function restoreNote(created) {
  return [
    `Chairman data exported ${created}.`,
    "",
    "Contains your profile, saved and remembered answers, questions from real forms, companies, today's list,",
    "application history, resume library, reference resumes and generated documents. It does not contain",
    "passwords, API keys, the extension pairing, browser sign-ins or logs. Keep it private.",
    "",
    "Restore on Windows",
    "1. Close Chairman if it is running on that computer.",
    "2. If Chairman has run there before, rename %LOCALAPPDATA%\\Job Application Assistant to \"Job Application Assistant (old)\".",
    "3. Type %LOCALAPPDATA% in File Explorer's address bar, then extract this zip there, so that",
    "   %LOCALAPPDATA%\\Job Application Assistant\\assistant.sqlite exists.",
    "4. Start Chairman (Start Chairman.cmd), open http://127.0.0.1:4318 and pair the Chrome extension again",
    "   (Setup > Browser extension). Choose your AI in the AI tab: Ollama runs a free local model (see WINDOWS.md),",
    "   Gemini's free tier uses your own API key.",
    "",
    "Restore on macOS: the same, extracting into ~/Library/Application Support.",
    "",
  ].join("\r\n");
}

/** Writes <out>/chairman-data-<date>.zip and its .sha256; returns what was exported. */
export async function exportData({ from = defaultDataFolder(), out = resolve(dirname(fileURLToPath(import.meta.url)), "..", "dist"), date = today() } = {}) {
  const database = join(from, "assistant.sqlite");
  if (!existsSync(database)) throw new Error(`No Chairman database in ${from}. Pass --from with the data folder.`);
  await mkdir(out, { recursive: true });
  const staging = await mkdtemp(join(out, ".data-export-"));
  try {
    const target = join(staging, DATA_FOLDER);
    await mkdir(target, { recursive: true });
    // A consistent snapshot of the live database (includes changes still in its write-ahead log).
    const snapshot = join(target, "assistant.sqlite");
    const source = new DatabaseSync(database);
    try { source.exec(`VACUUM INTO '${snapshot.replaceAll("'", "''")}'`); } finally { source.close(); }
    const copy = new DatabaseSync(snapshot);
    const tables = {};
    let removed = [];
    try {
      const check = copy.prepare("PRAGMA integrity_check").get();
      if (Object.values(check ?? {})[0] !== "ok") throw new Error("The database snapshot failed its integrity check; nothing was exported.");
      const settings = copy.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='settings'").get();
      if (settings) {
        removed = MACHINE_SETTINGS.filter(key => copy.prepare("SELECT 1 FROM settings WHERE key=?").get(key));
        for (const key of removed) copy.prepare("DELETE FROM settings WHERE key=?").run(key);
      }
      for (const { name } of copy.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all())
        tables[name] = copy.prepare(`SELECT count(*) AS n FROM "${name.replaceAll('"', '""')}"`).get().n;
      copy.exec("PRAGMA journal_mode=DELETE");
    } finally { copy.close(); }
    for (const folder of INCLUDED_FOLDERS)
      if (existsSync(join(from, folder))) await cp(join(from, folder), join(target, folder), { recursive: true, filter: path => !path.split(sep).at(-1).startsWith(".") });
    const created = new Date().toISOString();
    await writeFile(join(target, RESTORE_NOTE), restoreNote(created));
    const inventory = [];
    for (const path of (await files(target)).sort()) inventory.push({ path: relative(target, path).split(sep).join("/"), sha256: await sha256(path) });
    const manifest = { format: "chairman-data", version: 1, created, sourcePlatform: process.platform, tables, removedSettings: removed,
      excluded: "private/, browser profiles, backups/, logs", files: inventory };
    await writeFile(join(target, MANIFEST), JSON.stringify(manifest, null, 2) + "\n");

    const name = `chairman-data-${date}.zip`, zipped = join(staging, name);
    const result = process.platform === "win32"
      ? spawnSync("powershell.exe", ["-NoProfile", "-Command", `Compress-Archive -LiteralPath '${target.replaceAll("'", "''")}' -DestinationPath '${zipped.replaceAll("'", "''")}'`], { encoding: "utf8" })
      : spawnSync("zip", ["-q", "-X", "-r", zipped, DATA_FOLDER], { cwd: staging, encoding: "utf8" });
    if (result.error || result.status !== 0) throw new Error(`Creating the zip failed: ${result.error?.message ?? result.stderr}`);
    const digest = await sha256(zipped);
    await rename(zipped, join(out, name));
    await writeFile(join(out, `${name}.sha256`), `${digest}  ${name}\n`);
    return { zip: join(out, name), sha256: digest, tables, files: inventory.length, removedSettings: removed };
  } finally { await rm(staging, { recursive: true, force: true }); }
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  const args = process.argv.slice(2), options = {};
  for (let index = 0; index < args.length; index += 2) {
    const [flag, value] = [args[index], args[index + 1]];
    if (!value || !["--from", "--out"].includes(flag)) throw new Error("Usage: node scripts/export-data.mjs [--from <data folder>] [--out <folder>]");
    options[flag.slice(2)] = resolve(value);
  }
  const result = await exportData(options);
  console.log(`Exported ${result.files} files and ${Object.values(result.tables).reduce((sum, count) => sum + count, 0)} database rows to ${result.zip}`);
  console.log(`SHA256 ${result.sha256}${result.removedSettings.length ? `; cleared this computer's settings: ${result.removedSettings.join(", ")}` : ""}`);
}
