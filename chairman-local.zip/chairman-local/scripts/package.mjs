import { chmod, cp, lstat, mkdir, mkdtemp, open, readFile, readdir, rename, rm, utimes, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { basename, dirname, extname, join, relative, resolve, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { NODE_CHECKSUMS_URL, NODE_RUNTIMES, NODE_VERSION, runtimeUrl } from "./windows/node-runtime.mjs";
import { CHROME_METADATA_URL, CHROME_RUNTIME } from "./windows/chrome-runtime.mjs";
import { BUNDLE_MANIFEST, createBundleManifest, fileSha256, safeBundlePath, verifyBundle } from "./windows/bundle-integrity.mjs";

const projectRoot = dirname(dirname(fileURLToPath(import.meta.url)));
const sourceExtensions = new Set([".ts", ".tsx", ".mjs", ".js", ".json", ".jsonc", ".html", ".css", ".md", ".sql"]);
const blockedDirectories = new Set(["node_modules", ".git", ".wrangler", "test-results", "playwright-report", "data", "private", "artifacts", "reference-resumes", "resume-variants", "automation-browser", "portal-browser", "chairman-browser", "backups", "runtime", "launcher", "npm-cache"]);
const sourceEntries = ["package.json", "package-lock.json", "tsconfig.json", "playwright.config.ts", "README.md", "WINDOWS.md", "HANDOVER.md", ".env.example", "policies.example.json", "apps", "packages", "scripts", "tests"];
const slash = path => path.split(sep).join("/");
const sha256 = bytes => createHash("sha256").update(bytes).digest("hex");
const fixtureDirectory = /^(?:tests?|__tests__|fixtures?|__fixtures__|test-data|coverage|\.github|examples?)$/i;
const foreignFile = /(?:^|\/)[^/]*(?:darwin|linux|android|freebsd|openbsd|netbsd|aix|sunos)[^/]*\.(?:node|exe|dll)$|\.(?:dylib|so|dSYM)(?:\/|$)/i;
const privateFile = /(?:^|\/)\.env(?:\.|$)|\.(?:sqlite(?:-wal|-shm)?|db|pdf|docx|log|pem|key|pfx)$/i;

export function sourceFilter(root, { windows = false } = {}) {
  return async path => {
    const name = basename(path), stat = await lstat(path);
    if (stat.isSymbolicLink()) throw new Error(`Packaging refuses symlinks: ${relative(root, path)}`);
    if (blockedDirectories.has(name) || (name.startsWith(".") && name !== ".env.example")) return false;
    if (windows && (fixtureDirectory.test(name) || /\.(?:test|spec)\.[cm]?[jt]sx?$/.test(name))) return false;
    if (stat.isDirectory()) return true;
    if (name === ".env.example") return true;
    if (/^scripts\/windows\/Start (?:Chairman|Job Assistant)\.cmd$/.test(slash(relative(root, path)))) return true;
    if (!sourceExtensions.has(extname(name))) return false;
    if (extname(name) === ".json" && /secret|credential|token|private|session|profile|resume|export/i.test(name)) return false;
    return true;
  };
}

export async function inventory(directory) {
  const files = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name);
    if (entry.isSymbolicLink()) throw new Error("Packaging refuses symbolic links.");
    if (entry.isDirectory()) files.push(...await inventory(path));
    else if (entry.isFile()) files.push(path);
    else throw new Error("Packaging refuses special filesystem entries.");
  }
  return files;
}

export function assertShareable(paths, verifiedPayload = new Set()) {
  for (const rel of paths.map(slash)) {
    if (!safeBundlePath(rel)) throw new Error(`Unsafe Windows path selected: ${rel}`);
    if (/^(?:runtime|node_modules)\//.test(rel)) {
      if (verifiedPayload.has(rel) && !foreignFile.test(rel) && !privateFile.test(rel)) continue;
      throw new Error(`Unverified runtime artifact unexpectedly selected for packaging: ${rel}`);
    }
    if (/(^|\/)(?:\.env(?!\.example$)|node_modules|runtime|launcher|data|private|backups|artifacts|test-results|playwright-report|automation-browser|portal-browser|chairman-browser)(\/|$)|\.(?:sqlite(?:-wal|-shm)?|db|pdf|docx|log|pem|key|pfx)$/i.test(rel))
      throw new Error(`Private/runtime artifact unexpectedly selected for packaging: ${rel}`);
  }
}

export function windowsCommandBytes(text) {
  return text.replace(/\r?\n/g, "\r\n");
}

async function normalizeCommands(folder) {
  for (const file of await inventory(folder))
    if (extname(file) === ".cmd") await writeFile(file, windowsCommandBytes(await readFile(file, "utf8")));
}

export async function archive(folder, kind, staging, dist, verifiedPayload = new Set()) {
  const name = kind === "windows" ? "chairman-windows.zip" : kind === "extension" ? "chairman-chrome-extension.zip" : "chairman-local.zip";
  const output = join(staging, name);
  const files = (await inventory(folder)).sort();
  assertShareable(files.map(file => relative(folder, file)), verifiedPayload);
  await normalizeCommands(folder);
  const epoch = new Date("2000-01-01T00:00:00Z");
  for (const file of files) {
    await chmod(file, [".exe", ".cmd"].includes(extname(file)) ? 0o755 : 0o644);
    await utimes(file, epoch, epoch);
  }
  const result = spawnSync("zip", ["-q", "-X", output, "-@"], {
    cwd: dirname(folder), encoding: "utf8", timeout: 10 * 60_000,
    input: files.map(file => slash(relative(dirname(folder), file))).join("\n") + "\n",
  });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`ZIP creation failed: ${result.stderr}`);
  const digest = await fileSha256(output);
  await rename(output, join(dist, name));
  await writeFile(join(dist, `${name}.sha256`), `${digest}  ${name}\n`);
  const compatibilityName = `job-application-assistant-${kind}.zip`;
  await cp(join(dist, name), join(dist, compatibilityName));
  await writeFile(join(dist, `${compatibilityName}.sha256`), `${digest}  ${compatibilityName}\n`);
  return name;
}

export function validateRuntimeMembers(members, archive) {
  const prefix = `${archive.replace(/\.zip$/, "")}/`;
  if (!members.length || members.some(member => !member.startsWith(prefix) || !safeBundlePath(member.replace(/\/$/, ""))))
    throw new Error("The official runtime archive contains unexpected paths.");
  if (new Set(members.map(member => member.toLowerCase())).size !== members.length)
    throw new Error("The official runtime archive contains duplicate Windows paths.");
}

async function verifiedDownload({ archive, url, sha256: expected }, cache) {
  const cached = join(cache, archive);
  try { if (await fileSha256(cached) === expected) return cached; }
  catch (error) { if (error.code !== "ENOENT") throw error; }
  console.log(`Fetching official ${archive}; verifying pinned SHA256.`);
  const response = await fetch(url, { redirect: "error", signal: AbortSignal.timeout(300_000) });
  if (!response.ok) throw new Error(`Official runtime download failed (${response.status}).`);
  const bytes = Buffer.from(await response.arrayBuffer());
  if (sha256(bytes) !== expected) throw new Error("Official runtime SHA256 did not match the reviewed pin. Nothing was extracted or executed.");
  await mkdir(cache, { recursive: true });
  await writeFile(`${cached}.tmp`, bytes);
  await rename(`${cached}.tmp`, cached);
  return cached;
}

function unpackVerified(archivePath, prefix, destination, members = [`${prefix}/*`]) {
  const list = spawnSync("unzip", ["-Z1", archivePath], { encoding: "utf8", maxBuffer: 16 * 1024 * 1024, timeout: 60_000 });
  if (list.error) throw list.error;
  if (list.status !== 0) throw new Error("Unable to inspect the official runtime archive.");
  validateRuntimeMembers(list.stdout.trimEnd().split("\n"), `${prefix}.zip`);
  const result = spawnSync("unzip", ["-q", archivePath, ...members, "-d", destination], { encoding: "utf8", timeout: 120_000 });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error("Unable to extract the verified official runtime.");
}

export function peArchitecture(bytes) {
  if (bytes.length < 64 || bytes.toString("ascii", 0, 2) !== "MZ") return undefined;
  const offset = bytes.readUInt32LE(0x3c);
  if (offset + 6 > bytes.length || bytes.toString("ascii", offset, offset + 4) !== "PE\u0000\u0000") return undefined;
  return bytes.readUInt16LE(offset + 4);
}

export async function verifyNativeFiles(folder) {
  for (const file of await inventory(folder)) {
    const rel = slash(relative(folder, file));
    if (foreignFile.test(rel)) throw new Error(`Foreign native artifact in Windows bundle: ${rel}`);
    const handle = await open(file, "r");
    const bytes = Buffer.alloc(4096);
    let bytesRead;
    try { ({ bytesRead } = await handle.read(bytes, 0, bytes.length, 0)); }
    finally { await handle.close(); }
    const header = bytes.subarray(0, bytesRead);
    if (/\.(?:exe|dll|node)$/i.test(file) || header.toString("ascii", 0, 2) === "MZ") {
      if (peArchitecture(header) !== 0x8664) throw new Error(`Expected Windows x64 PE binary: ${rel}`);
    } else if (header.length >= 4 && [0x7f454c46, 0xfeedface, 0xcefaedfe, 0xfeedfacf, 0xcffaedfe, 0xcafebabe].includes(header.readUInt32BE(0))) {
      throw new Error(`Non-Windows executable in Windows bundle: ${rel}`);
    }
  }
}

async function bundleRuntimes(windows, staging, dist) {
  const runtime = NODE_RUNTIMES.x64;
  const archivePath = await verifiedDownload({ ...runtime, url: runtimeUrl("x64") }, join(dist, ".node-runtime-cache"));
  const prefix = runtime.archive.replace(/\.zip$/, ""), unpack = join(staging, "node-x64");
  await mkdir(unpack);
  unpackVerified(archivePath, prefix, unpack, [`${prefix}/node.exe`, `${prefix}/LICENSE`]);
  if (await fileSha256(join(unpack, prefix, "node.exe")) !== runtime.executableSha256)
    throw new Error("Extracted Node executable SHA256 did not match its pin.");
  await mkdir(join(windows, "runtime"), { recursive: true });
  await rename(join(unpack, prefix), join(windows, "runtime", "win-x64"));
  const chromeArchive = await verifiedDownload(CHROME_RUNTIME, join(dist, ".browser-runtime-cache"));
  unpackVerified(chromeArchive, "chrome-win64", join(windows, "runtime"));
  if (await fileSha256(join(windows, "runtime", "chrome-win64", "chrome.exe")) !== CHROME_RUNTIME.executableSha256)
    throw new Error("Extracted Chrome executable SHA256 did not match its pin.");
  await verifyNativeFiles(join(windows, "runtime"));
}

export function windowsProductionPackages(lock) {
  if (lock.lockfileVersion !== 3 || !lock.packages) throw new Error("Packaging requires the reviewed npm v3 lockfile.");
  const matches = (values, target) => !values || (!values.includes(`!${target}`) && (values.every(value => value.startsWith("!")) || values.includes(target)));
  const entries = Object.entries(lock.packages).filter(([path, value]) =>
    path && !value.dev && matches(value.os, "win32") && matches(value.cpu, "x64"));
  for (const [path, value] of entries) {
    if (!safeBundlePath(path) || !/^node_modules\//.test(path) || value.link
      || !/^https:\/\/registry\.npmjs\.org\/[^?#]+\.tgz$/.test(value.resolved ?? "")
      || !/^sha512-[A-Za-z0-9+/]{86}==$/.test(value.integrity ?? ""))
      throw new Error(`Production dependency lacks an approved npm URL/SHA512 lock pin: ${path}`);
    if (value.hasInstallScript && !["node_modules/koffi", "node_modules/tsx/node_modules/esbuild"].includes(path))
      throw new Error(`Review this new production install script before packaging: ${path}`);
  }
  return Object.fromEntries(entries);
}

export async function bundleDependencies(windows, staging, dist) {
  const prefix = join(staging, "windows-dependencies");
  await mkdir(prefix);
  await cp(join(windows, "package.json"), join(prefix, "package.json"));
  await cp(join(windows, "package-lock.json"), join(prefix, "package-lock.json"));
  const lock = JSON.parse(await readFile(join(prefix, "package-lock.json"), "utf8"));
  const expected = windowsProductionPackages(lock);
  const userConfig = join(staging, "user-npmrc"), globalConfig = join(staging, "global-npmrc");
  await writeFile(userConfig, "");
  await writeFile(globalConfig, "");
  const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => !/^npm_config_|^node_options$|^node_path$/i.test(key)));
  const args = ["ci", "--prefix", prefix, "--os=win32", "--cpu=x64", "--omit=dev", "--include=optional",
    "--ignore-scripts", "--bin-links=false", "--no-audit", "--no-fund", "--loglevel=error", "--logs-max=0",
    "--registry=https://registry.npmjs.org", "--fetch-retries=1", "--fetch-timeout=120000",
    "--userconfig", userConfig, "--globalconfig", globalConfig, "--cache", join(dist, ".npm-package-cache")];
  console.log("Staging clean, SHA512-locked Windows x64 production dependencies (no host node_modules or lifecycle scripts).");
  const result = spawnSync(process.env.npm_execpath ? process.execPath : "npm",
    process.env.npm_execpath ? [process.env.npm_execpath, ...args] : args,
    { cwd: prefix, env: { ...env, PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD: "1", npm_config_update_notifier: "false" }, encoding: "utf8", timeout: 10 * 60_000 });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error("Clean Windows dependency staging failed. Check maintainer registry access, lockfile consistency and disk space. Raw npm output is withheld to avoid exposing proxy credentials.");
  const installed = JSON.parse(await readFile(join(prefix, "node_modules", ".package-lock.json"), "utf8")).packages;
  if (Object.keys(installed).length !== Object.keys(expected).length)
    throw new Error("Installed Windows package inventory differs from the lockfile allowlist.");
  for (const [path, entry] of Object.entries(expected)) {
    if (installed[path]?.version !== entry.version || installed[path]?.integrity !== entry.integrity)
      throw new Error(`Locked Windows dependency is missing or mismatched: ${path}`);
    const actual = JSON.parse(await readFile(join(prefix, path, "package.json"), "utf8"));
    if (actual.version !== entry.version) throw new Error(`Installed dependency version mismatch: ${path}`);
  }
  const packageRoots = Object.keys(expected).sort((a, b) => b.length - a.length);
  const payload = new Set();
  for (const file of await inventory(join(prefix, "node_modules"))) {
    const rel = slash(relative(prefix, file));
    if (rel === "node_modules/.package-lock.json") continue;
    const owner = packageRoots.find(path => rel.startsWith(`${path}/`));
    if (!owner) throw new Error(`File outside locked package roots: ${rel}`);
    const inside = rel.slice(owner.length + 1);
    if (inside.split("/").some(part => fixtureDirectory.test(part) || part.endsWith(".dSYM"))
      || privateFile.test(inside) || /(^|\/)\.(?:npmrc|DS_Store)$/.test(inside)) continue;
    if (foreignFile.test(inside)) throw new Error(`Foreign native artifact in a Windows package: ${rel}`);
    await mkdir(dirname(join(windows, rel)), { recursive: true });
    await cp(file, join(windows, rel));
    payload.add(rel);
  }
  await verifyNativeFiles(join(windows, "node_modules"));
  return { payload, packages: Object.fromEntries(Object.entries(expected).map(([path, value]) =>
    [path, { version: value.version, resolved: value.resolved, integrity: value.integrity }])) };
}

export async function packageApp(root = projectRoot, { windowsOnly = false, outputDirectory = join(root, "dist") } = {}) {
  const dist = join(root, "dist");
  await mkdir(dist, { recursive: true });
  await mkdir(outputDirectory, { recursive: true });
  const staging = await mkdtemp(join(dist, ".package-"));
  try {
    const windows = join(staging, "Chairman"), filter = sourceFilter(root, { windows: true });
    await mkdir(windows);
    for (const entry of sourceEntries.filter(entry => entry !== "tests"))
      await cp(join(root, entry), join(windows, entry), { recursive: true, filter });
    await cp(join(dist, "dashboard"), join(windows, "dist", "dashboard"), { recursive: true, filter });
    await cp(join(dist, "extension"), join(windows, "dist", "extension"), { recursive: true, filter });
    await cp(join(root, "scripts", "windows", "Start Chairman.cmd"), join(windows, "Start Chairman.cmd"));
    await cp(join(root, "scripts", "windows", "Start Chairman.cmd"), join(windows, "Start Job Assistant.cmd"));
    await writeFile(join(windows, ".env.example"), [
      "# Optional local overrides. Never transfer keys or private files from another machine.",
      "JAA_PORT=4318",
      "# Private storage remains %LOCALAPPDATA%\\Job Application Assistant for compatibility.",
      "JAA_AI_PROVIDER=gemini", "JAA_GEMINI_MODEL=gemini-2.5-flash",
      "JAA_ALLOW_GEMINI_REMOTE=0", "JAA_GEMINI_FREE_TIER_CONFIRMED=0", "JAA_ALLOW_COPILOT_REMOTE=0",
      "# Configure your own Gemini key and consent in Setup. Opening Chairman does not activate Auto Apply.", "",
    ].join("\r\n"));
    await bundleRuntimes(windows, staging, dist);
    const dependencies = await bundleDependencies(windows, staging, dist);
    const verifiedPayload = new Set([...dependencies.payload, ...(await inventory(join(windows, "runtime"))).map(file => slash(relative(windows, file)))]);
    assertShareable((await inventory(windows)).map(file => relative(windows, file)), verifiedPayload);
    await normalizeCommands(windows);
    const manifest = await createBundleManifest(windows, {
      name: "Chairman", version: JSON.parse(await readFile(join(windows, "package.json"), "utf8")).version,
      node: { ...NODE_RUNTIMES.x64, url: runtimeUrl("x64"), checksumsSource: NODE_CHECKSUMS_URL },
      chrome: { ...CHROME_RUNTIME, metadataSource: CHROME_METADATA_URL, hashSource: "SHA256 computed from the official HTTPS archive; Google Storage MD5 matched." },
      dependencies: dependencies.packages,
    });
    await writeFile(join(windows, BUNDLE_MANIFEST), JSON.stringify(manifest, null, 2) + "\n");
    await verifyBundle(windows);
    const names = [await archive(windows, "windows", staging, outputDirectory, verifiedPayload)];
    const extension = join(staging, "chairman-chrome-extension");
    await cp(join(dist, "extension"), extension, { recursive: true, filter });
    names.push(await archive(extension, "extension", staging, outputDirectory));
    if (!windowsOnly) {
      const local = join(staging, "chairman-local");
      await mkdir(local);
      for (const entry of sourceEntries) await cp(join(root, entry), join(local, entry), { recursive: true, filter: sourceFilter(root) });
      await cp(join(dist, "dashboard"), join(local, "dist", "dashboard"), { recursive: true, filter });
      await cp(join(dist, "extension"), join(local, "dist", "extension"), { recursive: true, filter });
      names.push(await archive(local, "local", staging, outputDirectory));
    }
    console.log(`Created ${names.join(", ")} with SHA256 sidecars and compatibility aliases. Windows x64 includes pinned Node, all production dependencies and Chrome for Testing. No target npm installation, credentials or private profiles. Windows-native execution still requires a Windows host.`);
    return names;
  } finally { await rm(staging, { recursive: true, force: true }); }
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  const args = process.argv.slice(2);
  if (args.some(arg => arg !== "--windows-only")) throw new Error("Supported option: --windows-only");
  await packageApp(projectRoot, { windowsOnly: args.includes("--windows-only") });
}
