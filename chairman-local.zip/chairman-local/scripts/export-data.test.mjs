import test from "node:test";
import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { mkdir, readdir, readFile, rm, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { DATA_FOLDER, exportData } from "./export-data.mjs";
import { createApp } from "../apps/local/server.js";
import { createDocuments } from "../packages/documents/index.js";
import { emptyProfile } from "../packages/domain/types.js";
import { normalizeQuestion } from "../packages/automation/answers.js";
import { assistancePagePayload, assistanceSnapshotPayload } from "../packages/domain/extension-assist.js";
import { jobFixture } from "../tests/fixtures.js";

const sha = value => createHash("sha256").update(value).digest("hex");
const PORT = 4371, host = `127.0.0.1:${PORT}`, extensionOrigin = `chrome-extension://${"a".repeat(32)}`;

/** The requests the Chrome extension makes: pair, then plan a page and ask for the fill (answers and resume bytes). */
async function extensionFill(runtime, fields) {
  const cookie = String((await runtime.app.inject({ url: "/api/session", headers: { host } })).headers["set-cookie"]).split(";")[0];
  const token = (await runtime.app.inject({ method: "POST", url: "/api/extension/pair", headers: { host, cookie }, payload: {} })).json().token;
  const headers = { host, origin: extensionOrigin, authorization: `Bearer ${token}` };
  assert.equal((await runtime.app.inject({ method: "POST", url: "/api/extension/connect", headers, payload: {} })).statusCode, 200);
  const url = "https://boards.greenhouse.io/fictional-employer/jobs/4012345";
  const base = { url, fields, hasCaptcha: false, hasLegal: false, unsupported: [] };
  const snapshot = { ...base, fingerprint: sha(assistanceSnapshotPayload(base)) };
  const page = { kind: "form", title: "Apply", occupied: [], blockers: [], url, snapshot, fingerprint: "" };
  page.fingerprint = sha(assistancePagePayload(page));
  const planned = await runtime.app.inject({ method: "POST", url: "/api/extension/assist/plan", headers, payload: { page, ai: false } });
  assert.equal(planned.statusCode, 200, planned.body);
  const plan = planned.json();
  const include = plan.items.filter(item => item.include && item.value !== undefined).map(item => item.key);
  const granted = await runtime.app.inject({ method: "POST", url: "/api/extension/assist/grant", headers,
    payload: { id: plan.recordId, page, planHash: plan.planHash, include, resume: plan.resume?.selected ?? null, confirm: true } });
  assert.equal(granted.statusCode, 200, granted.body);
  return { plan, grant: granted.json() };
}

test("exported data restores on another computer with the extension's memory and resumes, and nothing private", { timeout: 120_000 }, async () => {
  const directory = resolve(`tests/.export-data-${randomUUID()}`), from = join(directory, "source"), out = join(directory, "out"), restored = join(directory, "restored");
  await mkdir(from, { recursive: true });
  try {
    // A data folder as Chairman leaves it, including things that must stay on this computer.
    let runtime = await createApp({ dataDir: from, port: PORT });
    let resumeSha = "";
    try {
      const profile = { ...emptyProfile(), name: "Jordan Fixture", email: "jordan@fictional.invalid", phone: "+91 98765 43210", location: "Hyderabad, Telangana", confirmed: true,
        skills: ["Python", "SQL"], answers: { notice_period_days: "30" },
        facts: [{ id: "experience", category: "experience", text: "Built Python and SQL data pipelines.", employer: "Northwind Labs", role: "Data Engineer", dates: "2023 - Present", confirmed: true }] };
      runtime.store.set("profile", profile);
      const question = "Which cloud do you use most?";
      runtime.store.set("assistAnswers", { [normalizeQuestion(question)]: { question, value: "AWS", updatedAt: new Date().toISOString() } });
      runtime.store.set("inference", { provider: "copilot", model: "gpt-6-astra", allowRemoteProcessing: true, acknowledgeUsage: true });
      const artifacts = await createDocuments(profile, jobFixture(), { mode: "deterministic", factIds: ["experience"], skills: profile.skills, notes: [] }, join(directory, "base"));
      const pdf = artifacts.find(artifact => artifact.format === "pdf");
      const variant = await runtime.library.upload(1, "jordan-data.pdf", await readFile(join(directory, "base", pdf.filename)), "Data resume", ["data"], true);
      resumeSha = variant.artifact.sha256;
    } finally { await runtime.app.close(); }
    await mkdir(join(from, "private"), { recursive: true });
    await writeFile(join(from, "private", "extension-pairing.json"), "PAIRING_SECRET_MUST_NOT_TRAVEL");
    await mkdir(join(from, "automation-browser", "Default"), { recursive: true });
    await writeFile(join(from, "automation-browser", "Default", "Cookies"), "COOKIE_MUST_NOT_TRAVEL");
    await writeFile(join(from, "service.log"), "LOG_MUST_NOT_TRAVEL");

    const result = await exportData({ from, out, date: "2026-01-02" });
    assert.equal(result.zip, join(out, "chairman-data-2026-01-02.zip"));
    assert.equal((await readFile(`${result.zip}.sha256`, "utf8")).trim(), `${result.sha256}  chairman-data-2026-01-02.zip`);
    assert.deepEqual(result.removedSettings, ["inference"], "the AI provider belongs to the old computer");
    assert.deepEqual(await readdir(out).then(names => names.filter(name => name.startsWith(".data-export-"))), [], "no staging left behind");

    await mkdir(restored, { recursive: true });
    const unzip = spawnSync("unzip", ["-q", result.zip, "-d", restored], { encoding: "utf8" });
    assert.equal(unzip.status, 0, unzip.stderr);
    const data = join(restored, DATA_FOLDER);
    for (const leftOut of ["private", "automation-browser", "service.log", "assistant.sqlite-wal"]) assert.equal(existsSync(join(data, leftOut)), false, `${leftOut} stays behind`);
    const everything = spawnSync("grep", ["-rl", "MUST_NOT_TRAVEL", data], { encoding: "utf8" });
    assert.equal(everything.stdout, "", "no private content anywhere in the export");
    const manifest = JSON.parse(await readFile(join(data, "data-manifest.json"), "utf8"));
    assert.equal(manifest.tables.resume_variants, 1);
    for (const file of manifest.files) assert.equal(sha(await readFile(join(data, file.path))), file.sha256, file.path);
    const database = new DatabaseSync(join(data, "assistant.sqlite"), { readOnly: true });
    assert.equal(database.prepare("SELECT value FROM settings WHERE key='inference'").get(), undefined);
    database.close();

    // The restored folder on the new computer: the extension plans from your answers and memory and attaches your resume.
    runtime = await createApp({ dataDir: data, port: PORT });
    try {
      const { plan, grant } = await extensionFill(runtime, [
        { key: "f00000000001", label: "Full name", type: "text", required: true, options: [] },
        { key: "f00000000002", label: "Email", type: "email", required: true, options: [] },
        { key: "f00000000003", label: "What is your notice period?", type: "text", required: true, options: [] },
        { key: "f00000000004", label: "Which cloud do you use most?", type: "text", required: false, options: [] },
        { key: "f00000000005", label: "Resume/CV", type: "file", required: true, options: [], accept: [".pdf"] },
      ]);
      const value = key => plan.items.find(item => item.key === key)?.value;
      assert.deepEqual([value("f00000000001"), value("f00000000002"), value("f00000000003"), value("f00000000004")],
        ["Jordan Fixture", "jordan@fictional.invalid", "30 days", "AWS"], "profile, saved answer and remembered answer");
      assert.equal(sha(Buffer.from(grant.resume.base64, "base64")), resumeSha, "the approved resume's exact bytes are attached");
    } finally { await runtime.app.close(); }
  } finally { await rm(directory, { recursive: true, force: true }); }
});
