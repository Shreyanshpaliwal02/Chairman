import { build } from "esbuild";
import { copyFile, mkdir, readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";

const root = fileURLToPath(new URL("../", import.meta.url));
const output = resolve(root, "dist/extension");
await mkdir(output, { recursive: true });
await Promise.all([
  build({
    entryPoints: [resolve(root, "apps/extension/service-worker.ts"), resolve(root, "apps/extension/sidepanel.ts"), resolve(root, "apps/extension/assist-panel.ts")],
    outdir: output, bundle: true, format: "esm", platform: "browser", target: "chrome120", sourcemap: false
  }),
  build({
    entryPoints: [resolve(root, "apps/extension/content.ts"), resolve(root, "apps/extension/assist-content.ts")],
    outdir: output, bundle: true, format: "iife", platform: "browser", target: "chrome120", sourcemap: false
  }),
  // The dedicated Auto Apply runner injects the same page engine; this copy is used when esbuild is unavailable at runtime.
  build({
    entryPoints: [resolve(root, "apps/extension/assist-page.ts")], outfile: resolve(root, "dist/runner/page-engine.js"),
    bundle: true, format: "iife", globalName: "ChairmanPage", platform: "browser", target: "chrome120", sourcemap: false
  }),
  ...["manifest.json", "sidepanel.html", "sidepanel.css", "README.md"].map((file) =>
    copyFile(resolve(root, "apps/extension", file), resolve(output, file))),
  readFile(resolve(root, "apps/extension/notification-icon.base64"), "utf8").then(base64 =>
    writeFile(resolve(output, "icon.png"), Buffer.from(base64.trim(), "base64")))
]);
console.log("Extension built in dist/extension. Load unpacked in chrome://extensions.");
