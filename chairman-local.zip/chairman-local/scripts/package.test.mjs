import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { archive, assertShareable, peArchitecture, sourceFilter, validateRuntimeMembers, verifyNativeFiles, windowsCommandBytes, windowsProductionPackages } from "./package.mjs";

test("source packaging excludes private state, credentials, browser profiles and foreign dependencies", async t => {
  const root = await mkdtemp(join(tmpdir(), "jaa-package-filter-"));
  try {
    const filter = sourceFilter(root);
    for (const name of [".env", ".env.local", ".browser-test-data", "profile.json", "gemini-credentials.json", "assistant.sqlite", "resume.pdf", "resume.docx", "key.pem", "error.log"]) {
      await writeFile(join(root, name), "private fixture");
      assert.equal(await filter(join(root, name)), false, name);
    }
    for (const name of ["node_modules", "runtime", "data", "private", "artifacts", "backups", "automation-browser", "portal-browser", "launcher", "npm-cache"]) {
      await mkdir(join(root, name));
      assert.equal(await filter(join(root, name)), false, name);
    }
    for (const name of ["package-lock.json", ".env.example", "server.ts", "WINDOWS.md"]) {
      await writeFile(join(root, name), "public fixture");
      assert.equal(await filter(join(root, name)), true, name);
    }
    await mkdir(join(root, "scripts", "windows"), { recursive: true });
    const cmd = join(root, "scripts", "windows", "Start Job Assistant.cmd");
    await writeFile(cmd, "@echo off\n");
    assert.equal(await filter(cmd), true);
    try { await symlink(join(root, ".env"), join(root, "linked.ts")); }
    catch (error) { if (process.platform === "win32" && error.code === "EPERM") { t.diagnostic("Symlink assertion skipped: Windows account lacks symlink privilege."); return; } throw error; }
    await assert.rejects(filter(join(root, "linked.ts")), /symlinks/);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("only exact verified payload paths are exempt from runtime/dependency exclusions", () => {
  const allowed = new Set(["runtime/win-x64/node.exe", "runtime/win-x64/LICENSE", "node_modules/tsx/package.json"]);
  assert.doesNotThrow(() => assertShareable([...allowed, "scripts/windows/launcher.mjs", ".env.example"], allowed));
  for (const file of [".env", "node_modules/tsx/package.json", "runtime/win-x64/node_modules/user-package/index.js", "runtime/darwin-arm64/node", "data/assistant.sqlite", "packages/private/gemini-key.json", "packages/.env", "dist/user.pdf", "runtime/private-key.json"])
    assert.throws(() => assertShareable([file]), /unexpectedly selected/, file);
});

test("official archive member validation rejects traversal, absolute paths and ambiguous Windows names", () => {
  const archive = "node-v24.21.0-win-x64.zip";
  assert.doesNotThrow(() => validateRuntimeMembers(["node-v24.21.0-win-x64/", "node-v24.21.0-win-x64/node.exe"], archive));
  for (const members of [
    ["node-v24.21.0-win-x64/../outside"],
    ["/tmp/node.exe"],
    ["other/node.exe"],
    ["node-v24.21.0-win-x64/Node.exe", "node-v24.21.0-win-x64/node.exe"],
    ["node-v24.21.0-win-x64/..\\outside"],
  ]) assert.throws(() => validateRuntimeMembers(members, archive));
});

test("Windows ZIP has a named root, CRLF launcher, executable attributes and SHA256 sidecar", async () => {
  const temporary = await mkdtemp(join(tmpdir(), "jaa-package-archive-"));
  try {
    const root = join(temporary, "Chairman"), output = join(temporary, "out");
    await mkdir(root);
    await mkdir(output);
    await writeFile(join(root, "Start Chairman.cmd"), "@echo off\necho Ready\n");
    await writeFile(join(root, "WINDOWS.md"), "Public installation instructions\n");
    const name = await archive(root, "windows", temporary, output);
    const zip = join(output, name);
    const entries = spawnSync("unzip", ["-Z1", zip], { encoding: "utf8" });
    assert.equal(entries.status, 0);
    assert.equal(name, "chairman-windows.zip");
    assert.equal(entries.stdout.split("\n").filter(Boolean).every(path => path.startsWith("Chairman/")), true);
    const command = spawnSync("unzip", ["-p", zip, "Chairman/Start Chairman.cmd"]).stdout;
    assert.equal(command.toString(), "@echo off\r\necho Ready\r\n");
    const attributes = spawnSync("zipinfo", ["-l", zip], { encoding: "utf8" }).stdout;
    assert.match(attributes, /-rwxr-xr-x.+Start Chairman\.cmd/);
    const hash = createHash("sha256").update(await readFile(zip)).digest("hex");
    assert.equal(await readFile(`${zip}.sha256`, "utf8"), `${hash}  ${name}\n`);
    assert.equal(windowsCommandBytes("@echo off\r\necho Ready\n"), "@echo off\r\necho Ready\r\n");
  } finally { await rm(temporary, { recursive: true, force: true }); }
});

test("Windows production allowlist is lock-derived, excludes development/foreign packages and rejects new install scripts", () => {
  const entry = { version: "1.0.0", resolved: "https://registry.npmjs.org/example/-/example-1.0.0.tgz", integrity: `sha512-${"A".repeat(86)}==` };
  const lock = { lockfileVersion: 3, packages: {
    "": {}, "node_modules/example": entry,
    "node_modules/dev": { ...entry, dev: true },
    "node_modules/mac": { ...entry, os: ["darwin"], cpu: ["arm64"] },
    "node_modules/arm64": { ...entry, os: ["win32"], cpu: ["arm64"] },
  } };
  assert.deepEqual(Object.keys(windowsProductionPackages(lock)), ["node_modules/example"]);
  for (const changed of [{ integrity: undefined }, { resolved: "http://registry.npmjs.org/example.tgz" }, { resolved: "file:../private" }, { hasInstallScript: true }])
    assert.throws(() => windowsProductionPackages({ ...lock, packages: { "node_modules/example": { ...entry, ...changed } } }));
});

test("native file validation accepts only Windows x64 PE files and rejects Mach-O or renamed ARM64", async () => {
  const root = await mkdtemp(join(tmpdir(), "chairman-pe-"));
  try {
    const pe = Buffer.alloc(128);
    pe.write("MZ");
    pe.writeUInt32LE(64, 0x3c);
    pe.write("PE\u0000\u0000", 64);
    pe.writeUInt16LE(0x8664, 68);
    assert.equal(peArchitecture(pe), 0x8664);
    await writeFile(join(root, "runtime.node"), pe);
    await verifyNativeFiles(root);
    pe.writeUInt16LE(0xaa64, 68);
    await writeFile(join(root, "runtime.node"), pe);
    await assert.rejects(verifyNativeFiles(root), /Windows x64 PE/);
    await rm(join(root, "runtime.node"));
    await writeFile(join(root, "hidden-binary"), Buffer.from([0xcf, 0xfa, 0xed, 0xfe]));
    await assert.rejects(verifyNativeFiles(root), /Non-Windows executable/);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("portable source excludes project tests and never selects a user's browsing profile", async () => {
  const root = await mkdtemp(join(tmpdir(), "chairman-source-"));
  try {
    const filter = sourceFilter(root, { windows: true });
    for (const name of ["tests", "private", "chairman-browser"]) {
      await mkdir(join(root, name));
      assert.equal(await filter(join(root, name)), false, name);
    }
    await writeFile(join(root, "browser.test.ts"), "test fixture");
    assert.equal(await filter(join(root, "browser.test.ts")), false);
  } finally { await rm(root, { recursive: true, force: true }); }
});
