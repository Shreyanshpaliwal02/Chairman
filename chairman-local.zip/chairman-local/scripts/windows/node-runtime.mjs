// Pins from https://nodejs.org/dist/v24.21.0/SHASUMS256.txt, verified over HTTPS.
export const NODE_VERSION = "24.21.0";
export const NODE_CHECKSUMS_URL = `https://nodejs.org/dist/v${NODE_VERSION}/SHASUMS256.txt`;
export const NODE_RUNTIMES = Object.freeze({
  x64: Object.freeze({
    archive: "node-v24.21.0-win-x64.zip",
    sha256: "158f7685b44de51f6c0df1d153526cbcd3e1bc739a8dfc607721cef75de9e541",
    executableSha256: "ba4e6d110e8c1592a1ecd390f6b05f3da124b13871a5be62b341a07a853c6c32",
  }),
  arm64: Object.freeze({
    archive: "node-v24.21.0-win-arm64.zip",
    sha256: "8779b1bde1d39f8d420e3b57aa657b39891af434d3de44a919044cec06785921",
    executableSha256: "dff59da18b6ffe1bf1ca99e1d2af4906080c481740619f5b5098c0fca28bd9b7",
  }),
});

export function runtimeUrl(architecture) {
  const runtime = NODE_RUNTIMES[architecture];
  if (!runtime) throw new Error("Only Windows x64 and ARM64 runtimes are supported.");
  return `https://nodejs.org/dist/v${NODE_VERSION}/${runtime.archive}`;
}
