import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import PDFDocument from "pdfkit";
import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";
import { createCanvas } from "@napi-rs/canvas";
import koffi from "koffi";
import { createApp } from "../../apps/local/server.ts";

// Imports validate the app without opening a server, loading a profile or calling AI.
assert.equal(typeof createApp, "function");
assert.equal(createCanvas(1, 1).width, 1);
assert.equal(typeof koffi.load, "function");
const db = new DatabaseSync(":memory:");
try { assert.equal(db.prepare("SELECT 1 AS ok").get().ok, 1); }
finally { db.close(); }

const pdf = new PDFDocument();
const bytes = [];
const complete = new Promise((resolve, reject) => {
  pdf.on("data", chunk => bytes.push(chunk));
  pdf.on("end", resolve);
  pdf.on("error", reject);
});
pdf.text("Windows runtime document check");
pdf.end();
await complete;
const task = getDocument({ data: new Uint8Array(Buffer.concat(bytes)), useSystemFonts: false });
try {
  const document = await task.promise;
  const content = await (await document.getPage(1)).getTextContent();
  assert.ok(content.items.some(item => "str" in item && item.str.includes("runtime document check")));
} finally { await task.destroy(); }
console.log("RUNTIME_OK");
