import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { lstat, readFile, readdir } from "node:fs/promises";
import { join } from "node:path";
import { NODE_VERSION } from "./node-runtime.mjs";
import { CHROME_RUNTIME } from "./chrome-runtime.mjs";

export const BUNDLE_MANIFEST = "bundle-manifest.json";
export const REQUIRED_PAYLOAD = [
  "runtime/win-x64/node.exe",
  "runtime/chrome-win64/chrome.exe",
  "node_modules/tsx/package.json",
  "node_modules/tsx/node_modules/@esbuild/win32-x64/esbuild.exe",
  "node_modules/@github/copilot-sdk-win32-x64/prebuilds/win32-x64/runtime.node",
  "node_modules/@github/copilot-sdk-win32-x64/prebuilds/win32-x64/copilot-runtime.exe",
  "node_modules/@koromix/koffi-win32-x64/win32_x64/koffi.node",
  "node_modules/@napi-rs/canvas-win32-x64-msvc/skia.win32-x64-msvc.node",
  "dist/dashboard/index.html",
  "dist/extension/manifest.json",
  "apps/local/server.ts",
  "package.json",
  "package-lock.json",
  "Start Chairman.cmd",
];

export function safeBundlePath(path) {
  return typeof path === "string" && path.length > 0 && !/[\\:*?"<>|\x00-\x1f]/.test(path)
    && path.split("/").every(part => part && part !== "." && part !== ".." && !/[. ]$/.test(part)
      && !/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part));
}

export async function fileSha256(path) {
  const hash = createHash("sha256");
  for await (const bytes of createReadStream(path)) hash.update(bytes);
  return hash.digest("hex");
}

export async function regularFiles(directory, prefix = "") {
  const files = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (!safeBundlePath(path) || entry.isSymbolicLink())
      throw new Error(`Bundle contains an unsafe filesystem entry: ${path}`);
    if (entry.isDirectory()) files.push(...await regularFiles(join(directory, entry.name), path));
    else if (entry.isFile()) files.push(path);
    else throw new Error(`Bundle contains a special filesystem entry: ${path}`);
  }
  return files.sort();
}

export async function createBundleManifest(root, provenance) {
  const files = {};
  for (const path of await regularFiles(root)) {
    if (path === BUNDLE_MANIFEST) continue;
    files[path] = { size: (await lstat(join(root, path))).size, sha256: await fileSha256(join(root, path)) };
  }
  for (const path of REQUIRED_PAYLOAD) if (!files[path]) throw new Error(`Required portable payload missing: ${path}`);
  return { schema: 1, platform: "win32", arch: "x64", nodeVersion: NODE_VERSION, chromeVersion: CHROME_RUNTIME.version, ...provenance, files };
}

export async function verifyBundle(root, { signal } = {}) {
  const failure = detail => new Error(`Portable bundle integrity failed (${detail}). Extract the complete verified Chairman Windows ZIP again. No files were downloaded or repaired.`);
  let manifest;
  try { manifest = JSON.parse(await readFile(join(root, BUNDLE_MANIFEST), "utf8")); }
  catch (error) {
    if (error.code === "ENOENT" || error instanceof SyntaxError) throw failure("missing or invalid manifest");
    throw error;
  }
  if (manifest?.schema !== 1 || manifest.platform !== "win32" || manifest.arch !== "x64"
    || manifest.nodeVersion !== NODE_VERSION || manifest.chromeVersion !== CHROME_RUNTIME.version
    || !manifest.files || typeof manifest.files !== "object" || Array.isArray(manifest.files))
    throw failure("unsupported manifest");
  const paths = Object.keys(manifest.files);
  if (new Set(paths.map(path => path.toLowerCase())).size !== paths.length)
    throw failure("duplicate Windows paths");
  for (const path of REQUIRED_PAYLOAD) if (!manifest.files[path]) throw failure("incomplete manifest");
  for (const path of paths) {
    signal?.throwIfAborted();
    const record = manifest.files[path];
    if (!safeBundlePath(path) || !record || !/^[a-f0-9]{64}$/.test(record.sha256) || !Number.isSafeInteger(record.size) || record.size < 0)
      throw failure("invalid file record");
    const components = path.split("/");
    for (let i = 1; i <= components.length; i++) {
      let stat;
      try { stat = await lstat(join(root, ...components.slice(0, i))); }
      catch (error) { if (error.code === "ENOENT") throw failure(`missing ${path}`); throw error; }
      if (stat.isSymbolicLink() || (i === components.length ? !stat.isFile() || stat.size !== record.size : !stat.isDirectory()))
        throw failure(`changed ${path}`);
    }
    if (await fileSha256(join(root, path)) !== record.sha256) throw failure(`changed ${path}`);
  }
  // Local .env overrides may be added, but executable payload trees are immutable.
  for (const tree of ["node_modules", "runtime", "apps", "packages", "scripts", "dist"]) {
    for (const path of await regularFiles(join(root, tree), tree))
      if (!Object.hasOwn(manifest.files, path)) throw failure(`unexpected ${path}`);
  }
  return manifest;
}
