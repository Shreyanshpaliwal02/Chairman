import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  APPLICATION_ID, READY_PATH, acquireInstance, assertPortAvailable, assertSupportedRuntime,
  dashboardArguments, ensureDependencies, installationId, parsePort, probeReadiness,
  readinessMatches, validLocalOrigin, windowsDefaults,
} from "./launcher-lib.mjs";
import { NODE_RUNTIMES, NODE_VERSION, runtimeUrl } from "./node-runtime.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "../..");
const withDirectory = async fn => {
  const directory = await mkdtemp(join(tmpdir(), "jaa-windows-"));
  try { await fn(directory); } finally { await rm(directory, { recursive: true, force: true }); }
};

test("Windows defaults do not enable remote processing or overwrite existing choices", () => {
  const defaults = windowsDefaults({});
  assert.equal(defaults.JAA_AI_PROVIDER, "gemini");
  assert.equal(defaults.JAA_GEMINI_MODEL, "gemini-2.5-flash");
  assert.equal(defaults.JAA_ALLOW_GEMINI_REMOTE, "0");
  assert.equal(defaults.JAA_GEMINI_FREE_TIER_CONFIRMED, "0");
  assert.equal(defaults.JAA_ALLOW_COPILOT_REMOTE, "0");
  const existing = { JAA_AI_PROVIDER: "ollama", JAA_GEMINI_MODEL: "chosen-model", JAA_ALLOW_GEMINI_REMOTE: "1", JAA_ALLOW_COPILOT_REMOTE: "1" };
  assert.deepEqual(windowsDefaults(existing), { ...existing, JAA_GEMINI_FREE_TIER_CONFIRMED: "0" });
  assert.deepEqual(existing, { JAA_AI_PROVIDER: "ollama", JAA_GEMINI_MODEL: "chosen-model", JAA_ALLOW_GEMINI_REMOTE: "1", JAA_ALLOW_COPILOT_REMOTE: "1" });
});

test("runtime pins allow only the supported official Windows downloads", () => {
  for (const arch of ["x64", "arm64"]) {
    assert.equal(runtimeUrl(arch), `https://nodejs.org/dist/v${NODE_VERSION}/node-v${NODE_VERSION}-win-${arch}.zip`);
    assert.match(NODE_RUNTIMES[arch].sha256, /^[a-f0-9]{64}$/);
    assert.match(NODE_RUNTIMES[arch].executableSha256, /^[a-f0-9]{64}$/);
  }
  assert.doesNotThrow(() => assertSupportedRuntime("win32", "x64", NODE_VERSION));
  assert.throws(() => assertSupportedRuntime("win32", "arm64", NODE_VERSION), /x64 emulation/);
  assert.throws(() => runtimeUrl("ia32"));
  assert.throws(() => assertSupportedRuntime("darwin", "arm64", NODE_VERSION));
  assert.throws(() => assertSupportedRuntime("win32", "x64", "22.13.0"));
});

test("ports and browser URLs cannot inject shell arguments or leave loopback", () => {
  assert.equal(parsePort(), 4318);
  assert.equal(parsePort("54321"), 54321);
  for (const input of ["", "80", "0", "65536", "-1", "4318 & calc", "4318/../../", "http://localhost", "4.3"])
    assert.throws(() => parsePort(input));
  for (const origin of ["https://example.com", "http://localhost:4318", "http://127.0.0.1:4318/evil", "http://127.0.0.1:99999", "http://127.0.0.1:4318 & calc"])
    assert.equal(validLocalOrigin(origin), false);
});

test("offline launch validates bundled files before native imports and never installs or repairs", async () => withDirectory(async directory => {
  const order = [];
  const options = {
    root: directory, env: {}, log() {},
    verify: async () => { order.push("integrity"); },
    healthy: async () => { order.push("native"); return true; },
  };
  await ensureDependencies(options);
  assert.deepEqual(order, ["integrity", "native"]);
  await assert.rejects(ensureDependencies({ ...options, healthy: async () => false }), /No internet repair or package installation/);
  order.length = 0;
  await assert.rejects(ensureDependencies({ ...options, verify: async () => { throw new Error("Portable bundle integrity failed (missing file)"); } }), /integrity failed/);
  assert.deepEqual(order, []);
}));

test("dashboard uses a separate persistent profile without extension injection or debugging flags", () => {
  const profile = join(tmpdir(), "Chairman & browsing profile");
  assert.deepEqual(dashboardArguments("http://127.0.0.1:4318", profile), [
    `--user-data-dir=${profile}`, "--no-first-run", "--no-default-browser-check", "http://127.0.0.1:4318",
  ]);
  assert.throws(() => dashboardArguments("https://example.com", profile), /unexpected dashboard/);
  assert.throws(() => dashboardArguments("http://127.0.0.1:4318", "relative"), /absolute/);
});

test("readiness requires this exact app instance, not just a successful HTTP response", async () => {
  const expected = { application: APPLICATION_ID, installationId: "installation", instanceId: "instance", origin: "", ready: true };
  let response = expected;
  const server = createServer((request, reply) => {
    assert.equal(request.url, READY_PATH);
    reply.setHeader("Content-Type", "application/json");
    reply.end(JSON.stringify(response));
  });
  await new Promise(resolve => server.listen(0, "127.0.0.1", resolve));
  expected.origin = `http://127.0.0.1:${server.address().port}`;
  try {
    assert.equal(await probeReadiness(expected), true);
    response = { ready: true };
    assert.equal(await probeReadiness(expected), false);
    response = { ...expected, instanceId: "different instance" };
    assert.equal(await probeReadiness(expected), false);
    assert.equal(readinessMatches({ ...expected, ready: false }, expected), false);
    await assert.rejects(assertPortAvailable(server.address().port), /occupied/);
    assert.equal(server.listening, true);
  } finally { await new Promise(resolve => server.close(resolve)); }
});

test("IPC ownership differentiates same installation, startup, and a conflicting copy", async () => withDirectory(async directory => {
  const pipe = process.platform === "win32" ? `\\\\.\\pipe\\jaa-test-${installationId(directory)}` : join(directory, "guard.sock");
  const state = { application: APPLICATION_ID, installationId: "one", ready: false };
  const first = await acquireInstance(pipe, state);
  try {
    assert.equal(first.owned, true);
    const second = await acquireInstance(pipe, state);
    assert.equal(second.owned, false);
    assert.equal(second.existing.ready, false);
    state.ready = true;
    assert.equal((await acquireInstance(pipe, state)).existing.ready, true);
    await assert.rejects(acquireInstance(pipe, { ...state, installationId: "two" }), /Another copy/);
  } finally { await first.close(); }
  const next = await acquireInstance(pipe, state);
  assert.equal(next.owned, true);
  await next.close();
}));

test("batch launcher uses bundled x64 without policy bypass, shell forwarding or remote scripts", async () => {
  const batch = await readFile(join(root, "scripts", "windows", "Start Chairman.cmd"), "utf8");
  assert.match(batch, /DisableDelayedExpansion/i);
  assert.match(batch, /PROCESSOR_ARCHITEW6432/);
  assert.match(batch, /ARM64/);
  assert.match(batch, /AMD64/);
  assert.doesNotMatch(batch, /JAA_ARCH=arm64/);
  assert.match(batch, /x64 emulation/);
  assert.match(batch, /runtime\\win-%JAA_ARCH%\\node\.exe/);
  assert.match(batch, /pause/i);
  assert.doesNotMatch(batch, /powershell|ExecutionPolicy|bypass|curl|https?:|%[*]|taskkill|start ""/i);
  const launcher = await readFile(join(root, "scripts", "windows", "launcher.mjs"), "utf8");
  assert.ok(launcher.indexOf("await assertPortAvailable") < launcher.indexOf("await createApp"));
  assert.ok(launcher.indexOf("if (!await probeReadiness(state))") < launcher.indexOf("await openDashboard(state.origin"));
  assert.match(launcher, /await runtime\.app\.close\(\)/);
  const library = await readFile(join(root, "scripts", "windows", "launcher-lib.mjs"), "utf8");
  assert.match(library, /shell: false/);
  assert.doesNotMatch(library, /"ci"|"install"|npmCli|load-extension|remote-debugging|disable-extensions/i);
  assert.doesNotMatch(library, /console\.(log|error)\(diagnostics/);
});
