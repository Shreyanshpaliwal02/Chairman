export const CHROME_METADATA_URL = "https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json";
// Stable official manifest dated 2026-09-18; archive also matched Google's x-goog-hash MD5.
export const CHROME_RUNTIME = Object.freeze({
  version: "153.0.8010.52",
  platform: "win64",
  archive: "chrome-153.0.8010.52-win64.zip",
  url: "https://storage.googleapis.com/chrome-for-testing-public/153.0.8010.52/win64/chrome-win64.zip",
  sha256: "df4854428c509fcf2f790ac448bca3f994151bcff22008236fa7c4587294fbe1",
  storageMd5: "zpBayjQjVXGHNOpRyiRcpw==",
  executableSha256: "f0c7648ec30b982048d8d1b60c4b0e6ddf90a8f59319bd3debb384ad91f0a2a9",
});
