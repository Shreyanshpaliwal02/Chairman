import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
import { get } from "node:http";
import { createConnection, createServer } from "node:net";
import { isAbsolute, join } from "node:path";
import { NODE_VERSION } from "./node-runtime.mjs";
import { verifyBundle } from "./bundle-integrity.mjs";

export const APPLICATION_ID = "job-application-assistant";
export const READY_PATH = "/launcher/ready";

export class LauncherError extends Error {}

export function windowsDefaults(env) {
  return {
    ...env,
    JAA_AI_PROVIDER: env.JAA_AI_PROVIDER ?? "gemini",
    JAA_GEMINI_MODEL: env.JAA_GEMINI_MODEL ?? "gemini-2.5-flash",
    JAA_ALLOW_GEMINI_REMOTE: env.JAA_ALLOW_GEMINI_REMOTE ?? "0",
    JAA_GEMINI_FREE_TIER_CONFIRMED: env.JAA_GEMINI_FREE_TIER_CONFIRMED ?? "0",
    JAA_ALLOW_COPILOT_REMOTE: env.JAA_ALLOW_COPILOT_REMOTE ?? "0",
  };
}

export function parsePort(value = "4318") {
  if (!/^\d{1,5}$/.test(value) || Number(value) < 1024 || Number(value) > 65535)
    throw new LauncherError("JAA_PORT must be a number from 1024 to 65535.");
  return Number(value);
}

export function installationId(path, platform = process.platform) {
  return createHash("sha256").update(platform === "win32" ? path.toLowerCase() : path).digest("hex");
}

export async function runNode(args, { root, env = process.env, signal, timeout = 120_000 } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, args, {
      cwd: root, env: { ...env, NODE_OPTIONS: "", NODE_PATH: "", TSX_DISABLE_CACHE: "1" },
      stdio: ["ignore", "ignore", "pipe"], windowsHide: true, signal,
    });
    let diagnostics = "";
    child.stderr.on("data", chunk => { diagnostics = (diagnostics + chunk.toString()).slice(-8192); });
    const timer = setTimeout(() => { child.kill(); }, timeout);
    child.once("error", error => { clearTimeout(timer); reject(error); });
    child.once("close", code => {
      clearTimeout(timer);
      // Import failures can include local configuration; never persist raw output.
      resolve({ ok: code === 0, code });
    });
  });
}

export async function dependenciesHealthy(root, options = {}) {
  return (await runNode(["--import", "tsx", join(root, "scripts", "windows", "check-runtime.mjs")], { ...options, root })).ok;
}

export async function ensureDependencies({ root, env, signal, log, verify = verifyBundle, healthy = dependenciesHealthy }) {
  log("Verifying the bundled app, Windows dependencies and Chrome. No installation or download is required.");
  try { await verify(root, { signal }); }
  catch (error) {
    if (error.message.startsWith("Portable bundle integrity failed")) throw new LauncherError(error.message);
    throw error;
  }
  if (!await healthy(root, { env, signal }))
    throw new LauncherError("Bundled dependencies did not pass the native runtime check. Extract the complete verified ZIP again; check Windows updates, runtime DLLs and security policy. No internet repair or package installation was attempted. See WINDOWS.md.");
  log("Bundled runtime dependencies are ready.");
}

export function readinessMatches(value, expected) {
  return value?.application === APPLICATION_ID && value?.ready === true
    && value?.installationId === expected.installationId && value?.instanceId === expected.instanceId
    && value?.origin === expected.origin;
}

export function validLocalOrigin(origin) {
  return typeof origin === "string" && /^http:\/\/127\.0\.0\.1:\d{4,5}$/.test(origin)
    && Number(origin.split(":").at(-1)) >= 1024 && Number(origin.split(":").at(-1)) <= 65535;
}

export async function probeReadiness(expected) {
  if (!validLocalOrigin(expected.origin)) return false;
  return new Promise(resolve => {
    const request = get(`${expected.origin}${READY_PATH}`, { timeout: 2000 }, response => {
      if (response.statusCode !== 200 || !response.headers["content-type"]?.startsWith("application/json")) {
        response.resume(); resolve(false); return;
      }
      let body = "";
      response.on("data", chunk => {
        body += chunk.toString();
        if (body.length > 4096) { response.destroy(); resolve(false); }
      });
      response.on("error", () => resolve(false));
      response.on("end", () => {
        try { resolve(readinessMatches(JSON.parse(body), expected)); }
        catch { resolve(false); }
      });
    });
    request.on("timeout", () => { request.destroy(); resolve(false); });
    request.on("error", () => resolve(false));
  });
}

export async function assertPortAvailable(port) {
  const probe = createServer();
  try {
    await new Promise((resolve, reject) => {
      probe.once("error", reject);
      probe.listen({ host: "127.0.0.1", port, exclusive: true }, () => { probe.off("error", reject); resolve(); });
    });
    await new Promise((resolve, reject) => probe.close(error => error ? reject(error) : resolve()));
  } catch (error) {
    if (error.code === "EADDRINUSE")
      throw new LauncherError(`Port ${port} is occupied by another server. No process was stopped. Close it yourself, or set JAA_PORT in your local .env file; the optional extension expects 4318.`);
    throw error;
  }
}

export async function acquireInstance(pipe, state) {
  const server = createServer(socket => {
    socket.on("error", () => {});
    socket.end(JSON.stringify(state));
  });
  try {
    await new Promise((resolve, reject) => {
      server.once("error", reject);
      server.listen(pipe, () => { server.off("error", reject); resolve(); });
    });
    return { owned: true, close: () => new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve())) };
  } catch (error) {
    if (error.code !== "EADDRINUSE") throw error;
  }
  const existing = await new Promise((resolve, reject) => {
    const socket = createConnection(pipe);
    let body = "";
    socket.setTimeout(2000);
    socket.on("timeout", () => socket.destroy(new LauncherError("Another launcher is not responding. Close its window and retry; no processes were stopped.")));
    socket.on("error", reject);
    socket.on("data", chunk => {
      body += chunk.toString();
      if (body.length > 4096) socket.destroy(new LauncherError("The launcher identity response was invalid."));
    });
    socket.on("end", () => {
      try { resolve(JSON.parse(body)); }
      catch { reject(new LauncherError("A different process is using the launcher address. No processes were stopped.")); }
    });
  });
  if (existing?.application !== APPLICATION_ID || existing?.installationId !== state.installationId)
    throw new LauncherError("Another copy is using this private data directory. Close that copy before starting this one; no processes were stopped.");
  return { owned: false, existing };
}

export function chromeCandidates(env = process.env) {
  return [env.PROGRAMFILES, env["PROGRAMFILES(X86)"], env.LOCALAPPDATA]
    .filter(Boolean).map(base => join(base, "Google", "Chrome", "Application", "chrome.exe"));
}

export function dashboardArguments(origin, profileDirectory) {
  if (!validLocalOrigin(origin)) throw new LauncherError("Refusing to open an unexpected dashboard address.");
  if (!isAbsolute(profileDirectory)) throw new LauncherError("Chairman's browser profile must use an absolute private local path.");
  return [`--user-data-dir=${profileDirectory}`, "--no-first-run", "--no-default-browser-check", origin];
}

export async function openDashboard(origin, chromePath, profileDirectory) {
  const args = dashboardArguments(origin, profileDirectory);
  return new Promise((resolve, reject) => {
    const child = spawn(chromePath, args, { detached: true, stdio: "ignore", shell: false, windowsHide: true });
    child.once("error", () => reject(new LauncherError("Chrome could not be opened. Open the displayed local dashboard address in your browser.")));
    child.once("spawn", () => { child.unref(); resolve(); });
  });
}

export function assertSupportedRuntime(platform = process.platform, arch = process.arch, version = process.versions.node) {
  if (platform !== "win32" || arch !== "x64" || version !== NODE_VERSION)
    throw new LauncherError(`Use the bundled Windows x64 Node ${NODE_VERSION} runtime. Native ARM64 is not included; Windows ARM64 requires working x64 emulation.`);
}
