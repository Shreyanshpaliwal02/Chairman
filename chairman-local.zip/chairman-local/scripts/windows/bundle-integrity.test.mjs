import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { BUNDLE_MANIFEST, REQUIRED_PAYLOAD, createBundleManifest, safeBundlePath, verifyBundle } from "./bundle-integrity.mjs";

async function fixture(callback) {
  const root = await mkdtemp(join(tmpdir(), "chairman-integrity-"));
  try {
    for (const path of [...REQUIRED_PAYLOAD, "packages/platform/browser.ts", "scripts/windows/launcher.mjs"]) {
      await mkdir(dirname(join(root, path)), { recursive: true });
      await writeFile(join(root, path), `public fixture: ${path}`);
    }
    const manifest = await createBundleManifest(root, { name: "Chairman", version: "0.8.0" });
    await writeFile(join(root, BUNDLE_MANIFEST), JSON.stringify(manifest));
    await callback(root, manifest);
  } finally { await rm(root, { recursive: true, force: true }); }
}

test("portable manifest validates actual file hashes offline and permits local .env only outside payload", async () => fixture(async root => {
  assert.equal((await verifyBundle(root)).arch, "x64");
  await writeFile(join(root, ".env"), "LOCAL_OVERRIDE=1");
  await verifyBundle(root);
  await writeFile(join(root, "runtime", "chrome-win64", "chrome.exe"), "tampered executable");
  await assert.rejects(verifyBundle(root), /changed.*chrome\.exe.*No files were downloaded/);
}));

test("portable manifest rejects missing files and unlisted dependency payload", async () => fixture(async root => {
  const path = join(root, "node_modules", "tsx", "unlisted.js");
  await writeFile(path, "unlisted");
  await assert.rejects(verifyBundle(root), /unexpected.*unlisted/);
  await rm(path);
  await rm(join(root, "node_modules", "tsx", "package.json"));
  await assert.rejects(verifyBundle(root), /missing.*tsx/);
}));

test("manifest rejects traversal, changed architecture, missing required entries and case collisions", async () => fixture(async (root, manifest) => {
  for (const path of ["../private", "/absolute", "runtime\\node.exe", "C:secret", "CON", "node_modules/foo./index.js"])
    assert.equal(safeBundlePath(path), false, path);
  for (const changed of [
    { ...manifest, arch: "arm64" },
    { ...manifest, files: {} },
    { ...manifest, files: { ...manifest.files, "PACKAGE.json": manifest.files["package.json"] } },
    { ...manifest, files: { ...manifest.files, "../outside": manifest.files["package.json"] } },
  ]) {
    await writeFile(join(root, BUNDLE_MANIFEST), JSON.stringify(changed));
    await assert.rejects(verifyBundle(root), /integrity failed/);
  }
}));

test("manifest rejects symlink redirection rather than hashing external private files", async t => fixture(async root => {
  const file = join(root, "runtime", "chrome-win64", "chrome.exe");
  const bytes = await readFile(file);
  await rm(file);
  try { await symlink(join(root, "package.json"), file); }
  catch (error) {
    if (process.platform === "win32" && error.code === "EPERM") {
      await writeFile(file, bytes);
      t.diagnostic("Windows symlink privilege unavailable.");
      return;
    }
    throw error;
  }
  await assert.rejects(verifyBundle(root), /changed/);
}));
