@echo off
setlocal DisableDelayedExpansion
title Chairman
cd /d "%~dp0"
if errorlevel 1 goto location_error
set "JAA_ARCH="
if /I "%PROCESSOR_ARCHITECTURE%"=="AMD64" set "JAA_ARCH=x64"
if /I "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "JAA_ARCH=x64"
if /I "%PROCESSOR_ARCHITEW6432%"=="AMD64" set "JAA_ARCH=x64"
if /I "%PROCESSOR_ARCHITEW6432%"=="ARM64" set "JAA_ARCH=x64"
if not defined JAA_ARCH goto unsupported
if not exist "runtime\win-%JAA_ARCH%\node.exe" goto missing_runtime
set "NODE_OPTIONS="
set "NODE_PATH="
"runtime\win-%JAA_ARCH%\node.exe" "scripts\windows\launcher.mjs"
set "JAA_EXIT=%ERRORLEVEL%"
if "%JAA_EXIT%"=="0" exit /b 0
echo.
echo The app did not start or stopped with an error. See the message above and WINDOWS.md.
pause
exit /b %JAA_EXIT%

:unsupported
echo Windows 10 or 11 on a 64-bit x64 or ARM64 computer is required.
echo This package is x64. Windows ARM64 requires Windows x64 emulation.
pause
exit /b 1

:missing_runtime
echo The bundled Windows runtime is missing. Extract ALL files from the Windows ZIP.
echo Do not run this launcher inside the ZIP or move it away from the extracted folder.
echo Do not disable security controls if Windows or your organization blocked a file.
pause
exit /b 1

:location_error
echo Extract the complete Windows ZIP to a writable local folder, not a network share.
pause
exit /b 1
