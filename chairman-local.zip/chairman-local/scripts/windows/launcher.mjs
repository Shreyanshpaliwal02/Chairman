import { createHash, randomUUID } from "node:crypto";
import { appendFileSync, existsSync } from "node:fs";
import { mkdir, readFile, realpath, rename, stat } from "node:fs/promises";
import { loadEnvFile } from "node:process";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { defaultDataDirectory } from "../../packages/platform/paths.ts";
import { getChromeLaunchOptions } from "../../packages/platform/browser.ts";
import { NODE_RUNTIMES } from "./node-runtime.mjs";
import {
  APPLICATION_ID, READY_PATH, LauncherError, acquireInstance, assertPortAvailable, assertSupportedRuntime,
  ensureDependencies, installationId, openDashboard, parsePort,
  probeReadiness, windowsDefaults,
} from "./launcher-lib.mjs";

export async function launch() {
  assertSupportedRuntime();
  if (process.argv.slice(2).some(arg => arg !== "--check")) throw new LauncherError("Only --check is supported by this launcher.");
  const checkOnly = process.argv.includes("--check");
  const root = await realpath(resolve(dirname(fileURLToPath(import.meta.url)), "../.."));
  process.chdir(root);
  if (existsSync(join(root, ".env"))) loadEnvFile(join(root, ".env"));
  Object.assign(process.env, windowsDefaults(process.env));
  const port = parsePort(process.env.JAA_PORT);
  const dataDirectory = resolve(process.env.JAA_DATA_DIR ?? defaultDataDirectory());
  const dashboardProfile = join(dataDirectory, "chairman-browser");
  await mkdir(dataDirectory, { recursive: true, mode: 0o700 });
  const stateDirectory = join(dataDirectory, "launcher");
  await mkdir(stateDirectory, { recursive: true, mode: 0o700 });
  const logFile = join(stateDirectory, "startup.log");
  if (existsSync(logFile) && (await stat(logFile)).size > 256 * 1024)
    await rename(logFile, join(stateDirectory, "startup.previous.log"));
  const log = message => {
    console.log(message);
    appendFileSync(logFile, `${new Date().toISOString()} ${message}\n`, { mode: 0o600 });
  };
  console.log(`Startup log: ${logFile}`);
  let guard, runtime;
  const controller = new AbortController();
  const stopped = Promise.withResolvers();
  const stop = () => { controller.abort(); stopped.resolve(); };
  process.on("SIGINT", stop);
  process.on("SIGTERM", stop);
  const state = {
    application: APPLICATION_ID,
    installationId: installationId(root),
    instanceId: randomUUID(),
    origin: `http://127.0.0.1:${port}`,
    ready: false,
  };
  try {
    const pipe = `\\\\.\\pipe\\jaa-${installationId(await realpath(dataDirectory))}`;
    guard = await acquireInstance(pipe, state);
    if (!guard.owned) {
      if (!guard.existing.ready) throw new LauncherError("This app is already starting. Keep its first window open and wait for the dashboard.");
      if (!await probeReadiness(guard.existing)) throw new LauncherError("The existing app did not confirm readiness. Check its window; no processes were stopped.");
      log("This app is already running. Reusing the existing dashboard.");
      await ensureDependencies({ root, env: process.env, signal: controller.signal, log });
      const chrome = getChromeLaunchOptions();
      if ("executablePath" in chrome && !checkOnly) await openDashboard(guard.existing.origin, chrome.executablePath, dashboardProfile);
      log(`Dashboard: ${guard.existing.origin}`);
      return;
    }
    if (!checkOnly) await assertPortAvailable(port);
    const runtimeFolder = join(root, "runtime", `win-${process.arch}`);
    if ((await realpath(process.execPath)).toLowerCase() !== (await realpath(join(runtimeFolder, "node.exe"))).toLowerCase())
      throw new LauncherError("Start with this app's bundled Node runtime, not another installation.");
    const checksum = createHash("sha256").update(await readFile(process.execPath)).digest("hex");
    if (checksum !== NODE_RUNTIMES[process.arch].executableSha256)
      throw new LauncherError("The bundled Node runtime checksum does not match. Obtain a fresh verified Windows ZIP; do not disable security controls.");
    if (!existsSync(join(root, "dist", "dashboard", "index.html")))
      throw new LauncherError("The prebuilt dashboard is missing. Extract the complete Windows ZIP again.");
    await ensureDependencies({ root, env: process.env, signal: controller.signal, log });
    if (controller.signal.aborted) return;
    const browser = getChromeLaunchOptions();
    if (!("executablePath" in browser)) throw new LauncherError("Bundled Chrome is missing. Extract the complete Chairman Windows ZIP again. Organization policies are never bypassed.");
    const chrome = browser.executablePath;
    if (checkOnly) { log("Windows setup checks passed: bundle integrity, Node, locked dependencies, SQLite, PDF processing and Chrome path. No server, AI request or application was started."); return; }
    const { register } = await import("tsx/esm/api");
    register();
    const { createApp } = await import("../../apps/local/server.ts");
    if (controller.signal.aborted) return;
    runtime = await createApp({ dataDir: dataDirectory, port });
    if (controller.signal.aborted) return;
    runtime.app.get(READY_PATH, async () => ({ ...state }));
    try { await runtime.app.listen({ port, host: "127.0.0.1" }); }
    catch (error) {
      if (error.code === "EADDRINUSE") throw new LauncherError(`Port ${port} is already occupied by another server. No process was stopped. Close the other app yourself, or set JAA_PORT in your local .env file; the optional extension expects 4318.`);
      throw error;
    }
    state.ready = true;
    if (!await probeReadiness(state)) throw new LauncherError("The local server did not confirm this app's identity and readiness. No browser was opened.");
    if (controller.signal.aborted) return;
    runtime.discovery.start();
    runtime.preparation.start();
    runtime.autopilot.start();
    runtime.careerSources.start();
    log(`Dashboard ready: ${state.origin}`);
    log("Optional extension: in Chairman Chrome open chrome://extensions, enable Developer mode if permitted, choose Load unpacked, select this folder's dist\\extension, then pair from Setup.");
    log(`Extension folder: ${join(root, "dist", "extension")}`);
    log("Browser sign-in, extension permission, Gemini key/consent and Auto Apply activation remain your choices.");
    log("Keep this window open. Press Ctrl+C once to stop cleanly.");
    try { await openDashboard(state.origin, chrome, dashboardProfile); }
    catch (error) { if (error instanceof LauncherError) log(error.message); else throw error; }
    await stopped.promise;
  } catch (error) {
    if (controller.signal.aborted && error.name === "AbortError") log("Startup cancelled. Run the launcher again to retry.");
    else {
      const code = typeof error.code === "string" && /^[A-Z][A-Z0-9_]{1,40}$/.test(error.code) ? ` (${error.code})` : "";
      log(error instanceof LauncherError ? error.message : `Startup failed${code}. Check folder permissions, free space and security software; see WINDOWS.md. Raw errors are not logged because they may contain private configuration.`);
      process.exitCode = 1;
    }
  } finally {
    state.ready = false;
    try {
      if (runtime) {
        log("Stopping this app and its automation browser...");
        await runtime.app.close();
        log("Stopped.");
      }
    } finally {
      try { if (guard?.owned) await guard.close(); }
      finally {
        process.off("SIGINT", stop);
        process.off("SIGTERM", stop);
      }
    }
  }
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  try { await launch(); }
  catch (error) {
    console.error(error instanceof LauncherError ? error.message : "The Windows launcher could not initialize or close. Check local folder permissions and WINDOWS.md. No private error details were logged.");
    process.exitCode = 1;
  }
}
