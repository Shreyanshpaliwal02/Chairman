"use strict";
(() => {
  // apps/extension/safety.ts
  var blockedDomains = ["linkedin.com", "lnkd.in", "wellfound.com", "angel.co", "naukri.com", "indeed.com", "indeed.jobs"];
  function destination(raw) {
    const url = new URL(raw);
    const host = url.hostname.toLowerCase().replace(/\.$/, "");
    if (blockedDomains.some((domain) => host === domain || host.endsWith(`.${domain}`)) || /(^|\.)indeed\.[a-z.]+$/.test(host)) {
      throw new Error("This site is manual-only. No extension inspection or automation is permitted.");
    }
    if (url.username || url.password || url.hash || host !== url.hostname) {
      throw new Error("Unsupported destination URL.");
    }
    if (url.protocol !== "https:" && !isFixture(raw)) {
      throw new Error("Only HTTPS destinations or the controlled local fixture are supported.");
    }
    if (url.protocol === "https:" && (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || !host.includes(".") || /^[\d.]+$/.test(host) || host.includes(":") || url.port !== "" && url.port !== "443")) throw new Error("Private or nonstandard destination hosts are unsupported.");
    return url;
  }
  function isFixture(raw) {
    const url = new URL(raw);
    return url.protocol === "http:" && url.hostname === "127.0.0.1" && Number(url.port) >= 1024 && url.pathname === "/fixture/application" && !url.hash && !url.username && !url.password;
  }
  function assertExactDestination(actual, expected) {
    const approved = destination(expected).href;
    if (!actual || actual !== approved) throw new Error("Activate the exact approved job page. Redirects and other tabs are not supported.");
  }
  function snapshotPayload(snapshot) {
    return JSON.stringify({
      url: snapshot.url,
      fields: snapshot.fields.map((field) => ({
        key: field.key,
        label: field.label,
        type: field.type,
        required: field.required,
        options: field.options
      })),
      hasCaptcha: snapshot.hasCaptcha,
      hasLegal: snapshot.hasLegal,
      unsupported: snapshot.unsupported
    });
  }
  async function fingerprint(snapshot) {
    const bytes = new TextEncoder().encode(snapshotPayload(snapshot));
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  function assertFillPlan(snapshot, fields, resume) {
    const keys = new Set(snapshot.fields.map((field) => field.key));
    if (keys.size !== snapshot.fields.length || Object.keys(fields).some((key) => !keys.has(key))) {
      throw new Error("The approved answer mapping does not match the form.");
    }
    let fileCount = 0;
    for (const field of snapshot.fields) {
      if (field.type === "file") {
        fileCount++;
        if (!/\b(resume|cv|curriculum vitae)\b/i.test(`${field.label} ${field.key}`) || Object.hasOwn(fields, field.key)) {
          throw new Error("Only one explicitly identified resume upload is supported.");
        }
        continue;
      }
      if (!Object.hasOwn(fields, field.key) || typeof fields[field.key] !== "string") {
        throw new Error(`A confirmed answer is required for: ${field.label || field.key}.`);
      }
      if (field.type === "select" && !field.options.includes(fields[field.key])) {
        throw new Error(`The approved option is not available for: ${field.label || field.key}.`);
      }
      if (!["text", "email", "tel", "url", "number", "date", "textarea", "select"].includes(field.type)) {
        throw new Error("An unsupported field cannot be filled.");
      }
    }
    if (fileCount !== 1) throw new Error("Exactly one resume file input is required.");
    decodeResume(resume);
  }
  function decodeResume(resume) {
    if (!resume || !["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"].includes(resume.mime) || typeof resume.filename !== "string" || !/^[^/\\\x00-\x1f]{1,150}\.(pdf|docx)$/i.test(resume.filename) || typeof resume.base64 !== "string" || resume.base64.length > 14e6 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(resume.base64)) {
      throw new Error("The approved resume is invalid or exceeds the 10 MB limit.");
    }
    const bytes = Uint8Array.from(atob(resume.base64), (char) => char.charCodeAt(0));
    if (!bytes.length || bytes.length > 1e7) throw new Error("The approved resume is empty or too large.");
    const pdf = resume.mime === "application/pdf";
    if (pdf ? !resume.filename.toLowerCase().endsWith(".pdf") || new TextDecoder().decode(bytes.slice(0, 5)) !== "%PDF-" : !resume.filename.toLowerCase().endsWith(".docx") || bytes[0] !== 80 || bytes[1] !== 75) {
      throw new Error("The resume content does not match its approved file type.");
    }
    return bytes;
  }

  // apps/extension/receipt.ts
  function readFixtureReceipt(approvedUrl, suppliedDocument) {
    const doc = suppliedDocument ?? document;
    const approved = new URL(approvedUrl);
    const current = new URL(doc.location.href);
    if (approved.protocol !== "http:" || approved.hostname !== "127.0.0.1" || Number(approved.port) < 1024 || approved.pathname !== "/fixture/application" || approved.username || approved.password || approved.hash || current.origin !== approved.origin || current.pathname !== "/fixture/confirmation" || current.hash || current.username || current.password || doc.defaultView?.top !== doc.defaultView) return void 0;
    const params = [...current.searchParams.entries()];
    if (params.length !== 1 || params[0][0] !== "id" || !/^[A-Za-z0-9_-]{1,100}$/.test(params[0][1])) return void 0;
    const markers = doc.querySelectorAll('main[data-jaa-submitted="true"][data-confirmation-id]');
    if (markers.length !== 1) return void 0;
    const marker = markers[0];
    const style = doc.defaultView.getComputedStyle(marker);
    if (marker.getAttribute("data-confirmation-id") !== params[0][1] || marker.closest('[hidden], [inert], [aria-hidden="true"]') || style.display === "none" || style.visibility === "hidden" || !marker.getClientRects().length) return void 0;
    return `Controlled fixture receipt: ${params[0][1]}`;
  }

  // apps/extension/form.ts
  var allowedInputs = ["text", "email", "tel", "url", "number", "date", "file"];
  var legalPattern = /\b(i (?:agree|certify|consent|acknowledge|attest|confirm|declare)|by (?:submitting|continuing|clicking)|terms (?:of|and)|privacy (?:policy|notice)|legal declaration|under penalty|consent to|background check|own (?:words|work)|solely my own|without (?:the )?(?:use|assistance) of (?:ai|artificial intelligence))\b/i;
  var aiPattern = /\b(no[\s-]ai|(?:do not|must not|cannot|may not|not permitted to|not allowed to|prohibited to) use (?:[\w-]+\s+){0,5}(?:ai|artificial intelligence|chatgpt)|(?:ai|artificial intelligence|chatgpt)(?:[\s\w,-]){0,65}(?:prohibited|not permitted|not allowed|forbidden|must not|cannot be used)|(?:own|your own) (?:words|work)|human[\s-]authored)\b/i;
  var settle = () => new Promise((resolve) => setTimeout(resolve, 300));
  function visible(element) {
    const win = element.ownerDocument.defaultView;
    const style = win.getComputedStyle(element);
    return !element.closest("[hidden], [inert], [aria-hidden='true']") && style.display !== "none" && style.visibility !== "hidden" && element.getClientRects().length > 0;
  }
  function safeText(root) {
    const doc = root.ownerDocument;
    const walker = doc.createTreeWalker(root, 4);
    const chunks = [];
    let node;
    let length = 0;
    while (node = walker.nextNode()) {
      if (node.parentElement?.closest("input, textarea, select, script, style, noscript")) continue;
      const text = node.textContent ?? "";
      length += text.length;
      if (length > 3e5) throw new Error("The page is too complex for safe preflight.");
      chunks.push(text);
    }
    return chunks.join(" ").replace(/\s+/g, " ").trim();
  }
  function labelFor(control) {
    const explicit = [...control.labels ?? []].map(safeText).join(" ").trim();
    const labelled = (control.getAttribute("aria-labelledby") ?? "").split(/\s+/).filter(Boolean).map((id) => control.ownerDocument.getElementById(id)).filter((node) => !!node).map(safeText).join(" ").trim();
    return (explicit || labelled || control.getAttribute("aria-label") || "").slice(0, 500);
  }
  function formControls(form) {
    const win = form.ownerDocument.defaultView;
    return [...form.elements].filter(
      (element) => element instanceof win.HTMLInputElement || element instanceof win.HTMLSelectElement || element instanceof win.HTMLTextAreaElement
    ).filter((element) => !(element instanceof win.HTMLInputElement && ["hidden", "submit", "button", "reset", "image"].includes(element.type)));
  }
  function submitButton(form) {
    const buttons = [...form.elements].filter((element) => element.tagName === "BUTTON" || element.tagName === "INPUT").filter((element) => visible(element) && element.type === "submit");
    if (buttons.length !== 1 || buttons[0].tagName !== "BUTTON") throw new Error("Exactly one standard submit button is required.");
    const button = buttons[0];
    if (!/^(submit(?: application)?|send application|apply now)$/i.test(safeText(button)) || button.hasAttribute("formaction") || button.hasAttribute("formmethod") || button.hasAttribute("formtarget") || button.hasAttribute("formnovalidate")) throw new Error("The submit action is ambiguous or unsupported.");
    return button;
  }
  function findForm(doc) {
    const forms = [...doc.forms].filter(visible);
    if (forms.length !== 1) throw new Error("Exactly one visible, single-step application form is required.");
    return forms[0];
  }
  async function inspectForm(doc, url) {
    destination(url);
    const unsupported = [];
    const add = (reason) => {
      if (!unsupported.includes(reason)) unsupported.push(reason);
    };
    const text = safeText(doc.body);
    const hasCaptcha = !!doc.querySelector('iframe[src*="captcha"], [class*="captcha" i], [id*="captcha" i], [data-sitekey]') || /\b(captcha|verify (?:that )?you are human|checking your browser|unusual traffic)\b/i.test(text);
    const hasLegal = legalPattern.test(text);
    if (aiPattern.test(text)) add("AI-use restriction or own-words requirement: manual application required.");
    if (doc.defaultView?.top !== doc.defaultView) add("Only the top-level document is supported.");
    if (doc.querySelector("iframe, frame, object, embed")) add("Embedded frames and third-party widgets are unsupported.");
    if (doc.querySelector('input[type="password"], input[autocomplete="one-time-code"]')) add("Login or verification requires a user handoff.");
    if (doc.querySelector('input[type="hidden"]')) add("Hidden input payloads require a separately reviewed adapter.");
    if (doc.querySelector('[contenteditable]:not([contenteditable="false"]), [role="combobox"], [role="listbox"], [role="slider"], [role="switch"], [role="checkbox"], [role="radio"], [role="textbox"], [role="spinbutton"], [role="button"]') || doc.querySelector("form [tabindex]:not(input, select, textarea, button)") || [...doc.querySelectorAll("*")].some((element) => element.shadowRoot || element.tagName.includes("-"))) {
      add("Custom controls and shadow DOM are unsupported.");
    }
    if (/\b(step\s+\d+\s+(?:of|\/)\s*\d+|next step|continue application|assessment|take (?:a|the) test)\b/i.test(text)) {
      add("Multi-step forms and assessments are unsupported.");
    }
    if (!isFixture(url)) add("No reviewed submission adapter exists for this destination; use a manual application.");
    let form;
    try {
      form = findForm(doc);
    } catch (error) {
      add(error.message);
    }
    const fields = [];
    if (form) {
      if (!isFixture(url) || form.action !== new URL("/fixture/submit", url).href || form.method.toLowerCase() !== "post" || form.enctype !== "multipart/form-data" || form.target && form.target !== "_self" || form.noValidate) {
        add("The form must use the reviewed fixture multipart POST action with native validation.");
      }
      try {
        submitButton(form);
      } catch (error) {
        add(error.message);
      }
      if ([...form.querySelectorAll('button, input[type="button"], input[type="reset"], input[type="image"]')].some((button) => visible(button) && button.type !== "submit")) {
        add("Additional form actions require manual review.");
      }
      const controls = formControls(form);
      if (controls.length > 80) add("The form has too many controls.");
      const allIds = [...doc.querySelectorAll("[id]")].map((element) => element.id);
      const seen = /* @__PURE__ */ new Set();
      for (const control of controls.slice(0, 81)) {
        const key = control.name || control.id;
        const type = control.tagName === "SELECT" ? "select" : control.tagName === "TEXTAREA" ? "textarea" : control.type;
        if (!key || key.length > 200 || ["__proto__", "prototype", "constructor"].includes(key)) add("Every field needs a safe, unique name or id.");
        if (seen.has(key) || control.id && allIds.filter((id) => id === control.id).length !== 1) add("Duplicate field names or ids are unsupported.");
        seen.add(key);
        if (!visible(control) || control.disabled || control.matches(":disabled") || control.hasAttribute("readonly")) add("Hidden, disabled, or read-only application controls are unsupported.");
        if (!["select", "textarea", ...allowedInputs].includes(type)) add(`Unsupported control type: ${type}.`);
        if (["min", "max", "minlength", "maxlength", "pattern", "step", "multiple"].some((attribute) => control.hasAttribute(attribute))) {
          add("Additional input constraints or multi-value controls require manual review.");
        }
        const options = type === "select" ? [...control.options].filter((option) => !option.disabled && !option.closest("optgroup[disabled]")).map((option) => option.value) : [];
        if (new Set(options).size !== options.length || options.some((option) => option.length > 500) || options.length > 200) {
          add("Select options are ambiguous or too complex.");
        }
        const label = labelFor(control);
        if (!label) add("Every application control needs an accessible label.");
        if (type === "file" && !/\b(resume|cv|curriculum vitae)\b/i.test(`${label} ${key}`)) add("Only a resume file upload is supported.");
        fields.push({ key, label, type, required: control.required, options });
      }
      if (fields.filter((field) => field.type === "file").length !== 1) add("Exactly one resume upload is required.");
    }
    const data = { url, fields, hasCaptcha, hasLegal, unsupported };
    const guard = observeChanges(doc);
    try {
      const result = { ...data, fingerprint: await fingerprint(data) };
      guard.assertStable();
      return result;
    } finally {
      guard.disconnect();
    }
  }
  async function checkedForm(doc, url, expected) {
    assertExactDestination(doc.location.href, url);
    const snapshot = await inspectForm(doc, url);
    if (snapshot.fingerprint !== expected) throw new Error("The form changed after approval. No further action was taken.");
    if (snapshot.hasCaptcha || snapshot.hasLegal || snapshot.unsupported.length) {
      throw new Error("The form requires manual review; automation is blocked.");
    }
    return findForm(doc);
  }
  function observeChanges(doc) {
    let changed = false;
    const observer = new doc.defaultView.MutationObserver(() => {
      changed = true;
    });
    observer.observe(doc.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
    return {
      assertStable() {
        if (changed || observer.takeRecords().length) throw new Error("The page changed while it was being checked. Run preflight again.");
      },
      disconnect() {
        observer.disconnect();
      }
    };
  }
  function assertLive(doc, command) {
    assertExactDestination(doc.location.href, command.url);
    if (doc.visibilityState !== "visible" || command.expiresAt !== void 0 && Date.now() >= command.expiresAt) {
      throw new Error("The active-page operation expired or the tab is no longer visible. Continue manually.");
    }
  }
  function nativeSet(control, value) {
    const win = control.ownerDocument.defaultView;
    const prototype = control.tagName === "SELECT" ? win.HTMLSelectElement.prototype : control.tagName === "TEXTAREA" ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (!setter) throw new Error("A native field setter is unavailable.");
    setter.call(control, value);
    control.dispatchEvent(new win.Event("input", { bubbles: true }));
    control.dispatchEvent(new win.Event("change", { bubbles: true }));
  }
  function controlByKey(form, key) {
    const controls = formControls(form).filter((control) => (control.name || control.id) === key);
    if (controls.length !== 1) throw new Error("The field mapping is no longer unique.");
    return controls[0];
  }
  function accepts(input, resume) {
    const accepted = input.accept.split(",").map((value) => value.trim().toLowerCase()).filter(Boolean);
    return !accepted.length || accepted.some((value) => value === resume.mime.toLowerCase() || value.startsWith(".") && resume.filename.toLowerCase().endsWith(value));
  }
  async function verifyAttachment(form, resume) {
    const inputs = formControls(form).filter((control) => control.type === "file");
    const file = inputs[0]?.files?.[0];
    const expected = decodeResume(resume);
    if (inputs.length !== 1 || inputs[0].files?.length !== 1 || !file || file.name !== resume.filename || file.type !== resume.mime || file.size !== expected.length || !accepts(inputs[0], resume)) {
      throw new Error("The resume was not accepted by the file input.");
    }
    const actual = new Uint8Array(await file.arrayBuffer());
    if (actual.length !== expected.length || actual.some((byte, index) => byte !== expected[index])) {
      throw new Error("The attached resume bytes do not match the approved file.");
    }
    const win = form.ownerDocument.defaultView;
    const submittedFile = new win.FormData(form).get(inputs[0].name);
    if (!(submittedFile instanceof win.File) || submittedFile.name !== file.name || submittedFile.type !== file.type || submittedFile.size !== file.size) {
      throw new Error("The native form has not accepted the exact resume upload.");
    }
    const submittedBytes = new Uint8Array(await submittedFile.arrayBuffer());
    if (submittedBytes.length !== expected.length || submittedBytes.some((byte, index) => byte !== expected[index])) {
      throw new Error("The form's upload payload differs from the approved resume.");
    }
    const marker = form.ownerDocument.querySelector("#jaa-resume-accepted");
    if (!isFixture(form.ownerDocument.location.href) || marker && (!visible(marker) || marker.getAttribute("data-filename") !== file.name || marker.getAttribute("data-bytes") !== String(file.size))) {
      throw new Error("The application has not acknowledged the exact resume. Continue manually.");
    }
    return file;
  }
  function verifyCurrentValues(form, fields) {
    for (const [key, value] of Object.entries(fields)) {
      const control = controlByKey(form, key);
      if (control.type === "file" || control.value !== value || !control.checkValidity()) {
        throw new Error(`The application did not retain the approved answer for ${key}.`);
      }
    }
  }
  async function verifyFields(doc, command) {
    let form = await checkedForm(doc, command.url, command.fingerprint);
    assertFillPlan(await inspectForm(doc, command.url), command.fields, command.resume);
    verifyCurrentValues(form, command.fields);
    const file = await verifyAttachment(form, command.resume);
    form = await checkedForm(doc, command.url, command.fingerprint);
    verifyCurrentValues(form, command.fields);
    if (!form.checkValidity() || doc.querySelector('[aria-invalid="true"], [data-jaa-validation-error]')) {
      throw new Error("The application reports a validation error. Continue manually.");
    }
    return { form, file };
  }
  function confirmationEvidence(doc, url) {
    if (!isFixture(url)) return void 0;
    return readFixtureReceipt(url, doc);
  }
  async function handlePageCommand(doc, command) {
    assertLive(doc, command);
    if (doc.defaultView?.top !== doc.defaultView) throw new Error("Only the top-level frame is permitted.");
    if (command.action === "snapshot") return { snapshot: await inspectForm(doc, command.url) };
    const guard = observeChanges(doc);
    try {
      const form = await checkedForm(doc, command.url, command.fingerprint);
      if (command.action === "fill") {
        const control = controlByKey(form, command.key);
        if (control.type === "file" || !["text", "email", "tel", "url", "number", "date", "textarea", "select-one"].includes(control.type)) {
          throw new Error("This field cannot be filled automatically.");
        }
        if (control.tagName === "SELECT" && ![...control.options].some((option) => option.value === command.value && !option.disabled && !option.closest("optgroup[disabled]"))) throw new Error("The approved select option is unavailable.");
        guard.assertStable();
        assertLive(doc, command);
        nativeSet(control, command.value);
        await settle();
        const current2 = await checkedForm(doc, command.url, command.fingerprint);
        if (controlByKey(current2, command.key).value !== command.value) throw new Error("The application did not retain the answer.");
        return {};
      }
      if (command.action === "attach") {
        const inputs = formControls(form).filter((control) => control.type === "file");
        if (inputs.length !== 1 || !accepts(inputs[0], command.resume)) throw new Error("The resume upload is unsupported.");
        const win = doc.defaultView;
        const bytes = decodeResume(command.resume);
        const transfer = new win.DataTransfer();
        transfer.items.add(new win.File([bytes], command.resume.filename, { type: command.resume.mime }));
        const setter = Object.getOwnPropertyDescriptor(win.HTMLInputElement.prototype, "files")?.set;
        if (!setter) throw new Error("The browser cannot attach the approved resume.");
        guard.assertStable();
        assertLive(doc, command);
        setter.call(inputs[0], transfer.files);
        inputs[0].dispatchEvent(new win.Event("input", { bubbles: true }));
        inputs[0].dispatchEvent(new win.Event("change", { bubbles: true }));
        await settle();
        await verifyAttachment(await checkedForm(doc, command.url, command.fingerprint), command.resume);
        return {};
      }
      await settle();
      const { form: current, file } = await verifyFields(doc, command);
      guard.assertStable();
      assertLive(doc, command);
      verifyCurrentValues(current, command.fields);
      if (formControls(current).find((control) => control.type === "file")?.files?.[0] !== file) {
        throw new Error("The approved attachment changed before submission.");
      }
      if (command.action === "verify") return {};
      if (doc.querySelector('main[data-jaa-submitted="true"]')) throw new Error("An existing receipt makes this submission ambiguous.");
      const button = submitButton(current);
      if (button.disabled || !visible(button)) throw new Error("The submit button is not ready.");
      button.click();
      await settle();
      const confirmation = confirmationEvidence(doc, command.url);
      return confirmation ? { confirmation } : {};
    } finally {
      guard.disconnect();
    }
  }

  // apps/extension/content.ts
  var state = globalThis;
  try {
    destination(location.href);
    if (window.top === window && !state.__jaaContentInstalled) {
      state.__jaaContentInstalled = true;
      let busy = false;
      chrome.runtime.onMessage.addListener((message, sender, respond) => {
        if (sender.id !== chrome.runtime.id || sender.tab || !message || typeof message !== "object" || message.channel !== "jaa:page") return;
        const command = message.command;
        if (!command || !["snapshot", "fill", "attach", "verify", "submit"].includes(command.action) || typeof command.url !== "string") {
          respond({ ok: false, error: "Invalid page operation." });
          return;
        }
        if (busy) {
          respond({ ok: false, error: "Another page operation is active." });
          return;
        }
        busy = true;
        handlePageCommand(document, command).then(
          (result) => respond({ ok: true, result }),
          (error) => respond({ ok: false, error: error instanceof Error ? error.message : "The page operation failed." })
        ).finally(() => {
          busy = false;
        });
        return true;
      });
    }
  } catch {
  }
})();
