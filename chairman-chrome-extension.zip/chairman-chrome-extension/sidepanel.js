// apps/extension/contracts.ts
var API_ORIGIN = "http://127.0.0.1:4318";

// apps/extension/safety.ts
var blockedDomains = ["linkedin.com", "lnkd.in", "wellfound.com", "angel.co", "naukri.com", "indeed.com", "indeed.jobs"];
function destination(raw) {
  const url = new URL(raw);
  const host = url.hostname.toLowerCase().replace(/\.$/, "");
  if (blockedDomains.some((domain) => host === domain || host.endsWith(`.${domain}`)) || /(^|\.)indeed\.[a-z.]+$/.test(host)) {
    throw new Error("This site is manual-only. No extension inspection or automation is permitted.");
  }
  if (url.username || url.password || url.hash || host !== url.hostname) {
    throw new Error("Unsupported destination URL.");
  }
  if (url.protocol !== "https:" && !isFixture(raw)) {
    throw new Error("Only HTTPS destinations or the controlled local fixture are supported.");
  }
  if (url.protocol === "https:" && (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || !host.includes(".") || /^[\d.]+$/.test(host) || host.includes(":") || url.port !== "" && url.port !== "443")) throw new Error("Private or nonstandard destination hosts are unsupported.");
  return url;
}
function permissionFor(raw) {
  const url = destination(raw);
  return `${url.protocol}//${url.hostname}/*`;
}
function isFixture(raw) {
  const url = new URL(raw);
  return url.protocol === "http:" && url.hostname === "127.0.0.1" && Number(url.port) >= 1024 && url.pathname === "/fixture/application" && !url.hash && !url.username && !url.password;
}

// apps/extension/sidepanel.ts
var element = (id) => document.getElementById(id);
var errorBox = element("error");
var latest;
var busy = false;
function showError(error) {
  errorBox.hidden = false;
  errorBox.textContent = error instanceof Error ? error.message : "The operation failed. Refresh and review the local dashboard.";
}
async function request(action, extra = {}) {
  const result = await chrome.runtime.sendMessage({ channel: "jaa:panel", action, ...extra });
  if (!result?.ok) throw new Error(result?.error || "The extension worker did not respond.");
  return result.state;
}
async function perform(action, extra = {}) {
  if (busy) return;
  busy = true;
  errorBox.hidden = true;
  element("status").textContent = action === "execute" ? "Revalidating and executing the approved packet. Keep the job tab active. Do not edit its form." : "Checking the local service\u2026";
  document.querySelectorAll("button").forEach((button) => {
    button.disabled = true;
  });
  try {
    latest = await request(action, extra);
  } catch (error) {
    showError(error);
  } finally {
    busy = false;
    document.querySelectorAll("button").forEach((button) => {
      button.disabled = false;
    });
    if (latest) render(latest);
    else element("status").textContent = "Not connected. Start the local service and pair this extension.";
  }
}
function text(tag, value, className) {
  const node = document.createElement(tag);
  node.textContent = value;
  if (className) node.className = className;
  return node;
}
function packetRow(item, state) {
  const row = document.createElement("li");
  row.append(text("h3", item.job.title), text("p", item.job.company, "company"));
  row.append(text("p", `${item.packet.status.replaceAll("_", " ")} \xB7 ${item.job.applyUrl}`, "metadata"));
  const attribution = text("p", "", "metadata");
  const sourceName = item.job.sourceId === "himalayas" ? "Himalayas" : item.job.sourceId;
  try {
    const canonical = new URL(item.job.canonicalUrl);
    if (canonical.protocol !== "https:" || canonical.username || canonical.password) throw new Error("Unsupported source link.");
    const link = text("a", `Source: ${sourceName}`);
    link.href = canonical.href;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    attribution.append(link);
  } catch {
    attribution.textContent = `Source: ${sourceName}`;
  }
  row.append(attribution);
  const blocked = !item.automationAllowed || state.queue?.stopped || !!state.pending;
  if (item.reason) row.append(text("p", item.reason, "blocker"));
  if (item.packet.formSnapshot) {
    const form = item.packet.formSnapshot;
    const blockers = [...form.unsupported, ...form.hasCaptcha ? ["CAPTCHA requires you."] : [], ...form.hasLegal ? ["Declarations require manual review."] : []];
    if (blockers.length) row.append(text("p", blockers.join(" "), "blocker"));
  }
  const actions = document.createElement("div");
  actions.className = "packet-actions";
  const open = text("button", "Open job", "quiet");
  open.type = "button";
  open.disabled = blocked;
  open.addEventListener("click", () => {
    if (busy) return;
    let origin;
    try {
      origin = permissionFor(item.job.applyUrl);
    } catch (error) {
      showError(error);
      return;
    }
    chrome.permissions.request({ origins: [origin] }).then((granted) => {
      if (!granted) throw new Error("Host access was declined. Continue manually or choose Open job again.");
      return perform("open", { packetId: item.packet.id });
    }).catch(showError);
  });
  const preflight = text("button", "Inspect form", "quiet");
  preflight.type = "button";
  preflight.disabled = blocked || !["prepared", "approved"].includes(item.packet.status);
  preflight.addEventListener("click", () => {
    void perform("preflight", { packetId: item.packet.id });
  });
  const execute = text("button", "Execute approved packet", "execute");
  execute.type = "button";
  execute.disabled = blocked || item.packet.status !== "approved" || !item.packet.formSnapshot || !!item.packet.formSnapshot.hasCaptcha || !!item.packet.formSnapshot.hasLegal || !!item.packet.formSnapshot.unsupported.length;
  execute.addEventListener("click", () => {
    void perform("execute", { packetId: item.packet.id });
  });
  actions.append(open, preflight, execute);
  row.append(actions);
  return row;
}
function render(state) {
  const origin = new URL(state.apiOrigin ?? API_ORIGIN);
  element("endpoint").textContent = `${origin.host} \xB7 No remote service`;
  element("dashboard-link").href = origin.href;
  element("port").value = origin.port;
  element("connection-state").textContent = state.paired ? "Paired for this session" : "Not paired";
  element("status").textContent = state.message;
  element("queue-state").textContent = state.queue?.stopped ? "Stopped. Resume the queue in the dashboard before inspecting or executing." : "Open job \u2192 inspect form \u2192 approve in dashboard \u2192 execute.";
  element("recover").hidden = !state.pending;
  element("refresh").disabled = busy;
  element("pair-form").querySelector("button").disabled = busy || !!state.pending;
  const packets = element("packets");
  packets.replaceChildren(...(state.queue?.items ?? []).map((item) => packetRow(item, state)));
  element("empty").hidden = !!state.queue?.items.length;
  element("empty").textContent = state.paired ? "No application packets yet. Prepare one in the local dashboard, then refresh." : "No packets loaded. Pair the local service, then prepare a packet in your dashboard.";
}
element("pair-form").addEventListener("submit", (event) => {
  event.preventDefault();
  if (busy) return;
  const input = element("token");
  const token = input.value.trim();
  const port = Number(element("port").value);
  input.value = "";
  chrome.permissions.request({ origins: [`${new URL(API_ORIGIN).protocol}//${new URL(API_ORIGIN).hostname}/*`] }).then((granted) => {
    if (!granted) throw new Error("Local service access was declined. Pair again to grant loopback access.");
    return perform("pair", { token, port });
  }).catch(showError);
});
element("refresh").addEventListener("click", () => {
  void perform("state");
});
element("recover").addEventListener("click", () => {
  void perform("recover");
});
void perform("state");
