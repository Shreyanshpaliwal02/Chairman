"use strict";
(() => {
  // packages/domain/assist-match.ts
  function canonicalJson(value) {
    return JSON.stringify(sortKeys(value));
  }
  function sortKeys(value) {
    if (Array.isArray(value)) return value.map((item) => item === void 0 ? null : sortKeys(item));
    if (value && typeof value === "object") {
      const result = {};
      for (const key2 of Object.keys(value).sort()) {
        const item = value[key2];
        if (item !== void 0) result[key2] = sortKeys(item);
      }
      return result;
    }
    return value;
  }
  function cyrb53(text, seed = 0) {
    let h1 = 3735928559 ^ seed, h2 = 1103547991 ^ seed;
    for (let index = 0; index < text.length; index++) {
      const code = text.charCodeAt(index);
      h1 = Math.imul(h1 ^ code, 2654435761);
      h2 = Math.imul(h2 ^ code, 1597334677);
    }
    h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507);
    h1 ^= Math.imul(h2 ^ h2 >>> 13, 3266489909);
    h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507);
    h2 ^= Math.imul(h1 ^ h1 >>> 13, 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
  }
  function stableFieldKey(identity) {
    return `f${cyrb53(identity).toString(36).padStart(11, "0").slice(-11)}`;
  }
  function normalizeText(text) {
    return text.normalize("NFKC").toLowerCase().replace(/[‘’`´]/g, "'").replace(/[“”]/g, '"').replace(/\s+/g, " ").trim();
  }
  function cleanQuestion(text, limit = 300) {
    return text.replace(/\s+/g, " ").trim().replace(/(?:\s*\((?:required|optional)\)|\s*[*✱]|\s*:)+\s*$/i, "").trim().slice(0, limit);
  }
  var SYNONYM_GROUPS = [
    [
      "i don't wish to answer",
      "i do not wish to answer",
      "decline to self identify",
      "decline to self-identify",
      "i decline to self identify",
      "i decline to self-identify",
      "prefer not to say",
      "prefer not to answer",
      "i prefer not to answer",
      "i prefer not to say",
      "decline to answer",
      "choose not to disclose",
      "i choose not to disclose",
      "i do not wish to disclose",
      "i don't wish to disclose",
      "i do not want to answer",
      "i don't want to answer",
      "decline",
      "not declared"
    ],
    ["male", "man", "cis man", "cisgender man"],
    ["female", "woman", "cis woman", "cisgender woman"],
    ["non-binary", "nonbinary", "non binary", "genderqueer", "gender non-conforming", "gender nonconforming"],
    ["i am not a protected veteran", "i am not a veteran", "not a protected veteran", "not a veteran", "no, i am not a protected veteran", "i'm not a protected veteran", "i am not a protected veteran."],
    [
      "i identify as one or more of the classifications of protected veteran",
      "i am a protected veteran",
      "protected veteran",
      "yes, i am a protected veteran",
      "i identify as a protected veteran",
      "i identify as one or more of the classifications of protected veterans"
    ],
    [
      "no, i do not have a disability",
      "no, i don't have a disability",
      "i do not have a disability",
      "no disability",
      "no, i do not have a disability and have not had one in the past",
      "no, i don't have a disability and have not had one in the past"
    ],
    [
      "yes, i have a disability (or previously had a disability)",
      "yes, i have a disability",
      "i have a disability",
      "yes, i have a disability, or have had one in the past",
      "yes, i have a disability or have a history/record of having a disability"
    ],
    ["asian", "asian (not hispanic or latino)"],
    ["white", "white (not hispanic or latino)", "caucasian"],
    ["black or african american", "black or african american (not hispanic or latino)", "black", "african american"],
    ["hispanic or latino", "hispanic/latino", "hispanic", "latino", "latina", "latinx"],
    ["two or more races", "two or more races (not hispanic or latino)", "multiracial", "mixed race"]
  ];
  function synonymGroup(text) {
    const value = normalizeText(text).replace(/[.!]+$/, "");
    return SYNONYM_GROUPS.findIndex((group) => group.includes(value));
  }
  var placeholderLabel = /^(?:[-–—._\s]*|(?:please\s+)?(?:select|choose|pick)(?:\s+(?:one|an?\s+option|an?\s+answer|from\s+the\s+list))?(?:\s*\.{3}|…)?|none selected|--\s*(?:select|choose)\s*--)$/i;
  function isPlaceholderOption(option) {
    return !option.value.trim() || placeholderLabel.test(option.label.trim());
  }
  var stopWords = /* @__PURE__ */ new Set(["a", "an", "the", "of", "in", "and", "or", "to", "for", "with", "at", "on", "i", "am", "my", "me", "is", "are", "be"]);
  function core(text) {
    return normalizeText(text).replace(/\([^)]*\)|\[[^\]]*\]/g, " ").replace(/'s\b/g, "").replace(/[^\p{L}\p{N}+#\s]/gu, " ").replace(/\s+/g, " ").trim();
  }
  function tokens(text) {
    return core(text).split(" ").filter((token) => token && !stopWords.has(token));
  }
  function booleanOf(text) {
    const value = normalizeText(text).replace(/[.!]+$/, "");
    if (["yes", "true", "y"].includes(value)) return true;
    if (["no", "false", "n"].includes(value)) return false;
    return void 0;
  }
  function leadingBoolean(label) {
    const value = normalizeText(label);
    if (/^yes\b/.test(value)) return true;
    if (/^no\b/.test(value) && !/^no\s+(?:preference|answer)\b/.test(value)) return false;
    return booleanOf(value);
  }
  function parseRange(label) {
    const text = normalizeText(label).replace(/(\d),(\d{3})/g, "$1$2");
    const number = "(\\d+(?:\\.\\d+)?)";
    let match;
    if (match = text.match(new RegExp(`^(?:less than|under|fewer than|below|<)\\s*${number}`))) return { min: -Infinity, max: Number(match[1]) - 1e-9 };
    if (match = text.match(new RegExp(`^(?:more than|over|above|greater than|>)\\s*${number}`))) return { min: Number(match[1]) + 1e-9, max: Infinity };
    if (match = text.match(new RegExp(`^${number}\\s*(?:\\+|or more\\b|and above\\b|and up\\b|plus\\b)`))) return { min: Number(match[1]), max: Infinity };
    if (match = text.match(new RegExp(`^${number}\\s*(?:-|\u2013|\u2014|to)\\s*${number}`))) return { min: Number(match[1]), max: Number(match[2]) };
    if (match = text.match(new RegExp(`^${number}(?:\\s*(?:years?|yrs?|months?|weeks?|days?))?$`))) return { min: Number(match[1]), max: Number(match[1]) };
    return void 0;
  }
  var unitWords = {
    years: /\b(?:months?|weeks?|days?|hours?)\b/,
    days: /\b(?:years?|months?|weeks?|hours?)\b/
  };
  var isoCodes = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(" ");
  var countryAliases = {
    usa: "US",
    "u s a": "US",
    "u s": "US",
    "united states of america": "US",
    america: "US",
    uk: "GB",
    "u k": "GB",
    britain: "GB",
    "great britain": "GB",
    england: "GB",
    "south korea": "KR",
    "korea republic of": "KR",
    "north korea": "KP",
    "czech republic": "CZ",
    turkey: "TR",
    t\u00FCrkiye: "TR",
    russia: "RU",
    "russian federation": "RU",
    vietnam: "VN",
    "viet nam": "VN",
    uae: "AE",
    "hong kong sar": "HK",
    "hong kong sar china": "HK",
    holland: "NL",
    "the netherlands": "NL"
  };
  var countryIndex;
  function countryKey(text) {
    return core(text.replace(/\./g, " ")).replace(/^the /, "");
  }
  function countryCode(text) {
    const trimmed = text.trim();
    if (/^[A-Z]{2}$/.test(trimmed)) return isoCodes.includes(trimmed) ? trimmed : void 0;
    if (!countryIndex) {
      countryIndex = new Map(Object.entries(countryAliases).map(([name, code]) => [countryKey(name), code]));
      try {
        const names = new Intl.DisplayNames(["en"], { type: "region" });
        for (const code of isoCodes) {
          const name = names.of(code);
          if (name && name !== code) countryIndex.set(countryKey(name), code);
        }
      } catch {
      }
    }
    return countryIndex.get(countryKey(trimmed));
  }
  function matchChoice(answer, options, unit) {
    const usable = options.filter((option) => !isPlaceholderOption(option));
    const wanted = answer.trim();
    if (!wanted || !usable.length) return { error: "none" };
    const boolean = booleanOf(wanted);
    const numeric = /^\d+(?:\.\d+)?$/.test(wanted) ? Number(wanted) : void 0;
    const country = countryCode(wanted);
    const wantedTokens = tokens(wanted);
    const tiers = [
      ["value", (option) => option.value === wanted],
      ["label", (option) => normalizeText(option.label) === normalizeText(wanted)],
      ["core", (option) => !!core(wanted) && core(option.label) === core(wanted)],
      ["synonym", (option) => synonymGroup(wanted) >= 0 && synonymGroup(option.label) === synonymGroup(wanted)],
      ["boolean", (option) => boolean !== void 0 && leadingBoolean(option.label) === boolean],
      ["range", (option) => {
        if (numeric === void 0 || unit && unitWords[unit].test(normalizeText(option.label))) return false;
        const range = parseRange(option.label);
        return !!range && numeric >= range.min && numeric <= range.max;
      }],
      ["country", (option) => !!country && (countryCode(option.label) === country || countryCode(option.value) === country)],
      ["tokens", (option) => {
        if (boolean !== void 0 || numeric !== void 0) return false;
        const optionTokens = tokens(option.label);
        if (!optionTokens.length || !wantedTokens.length) return false;
        const contains = (whole, part) => part.every((token) => whole.includes(token));
        return core(wanted).length >= 3 && contains(optionTokens, wantedTokens) || core(option.label).length >= 3 && contains(wantedTokens, optionTokens);
      }]
    ];
    for (const [tier, test] of tiers) {
      const matches = usable.filter(test);
      if (matches.length === 1) return { value: matches[0].value, label: matches[0].label, tier };
      if (matches.length > 1) return { error: "ambiguous" };
    }
    return { error: "none" };
  }
  var AUTOCOMPLETE_MEANINGS = Object.freeze({
    name: "name",
    "given-name": "first_name",
    "family-name": "last_name",
    email: "email",
    tel: "phone",
    "tel-national": "phone",
    "address-level2": "city",
    "country-name": "country",
    country: "country",
    "postal-code": "postal_code"
  });
  function comparableValue(type, value) {
    const text = value.normalize("NFKC").replace(/\s+/g, " ").trim();
    if (type === "tel") return text.replace(/\D/g, "");
    if (type === "number") return Number.isFinite(Number(text)) && text !== "" ? String(Number(text)) : text;
    if (type === "email" || type === "url" || type === "combobox") return text.toLowerCase();
    return text;
  }
  function sameComparable(type, expected, actual) {
    const a = comparableValue(type, expected), b = comparableValue(type, actual);
    if (a === b) return true;
    return type === "tel" && a.length >= 7 && b.length >= 7 && (a.endsWith(b) || b.endsWith(a));
  }

  // packages/domain/extension-assist.ts
  var CONFIRMATION_TEXT = /\b(?:thank(?:s| you) for (?:applying|your application|submitting(?: your application)?)|(?:your )?application (?:has been |was |is )?(?:successfully )?(?:submitted|received|sent|completed?)\b(?! (?:by|before|on or before|until))|we(?:'ve| have) (?:successfully )?received your application|you(?:'ve| have) (?:successfully )?(?:applied|submitted your application)|successfully (?:applied|submitted)|application submitted)/i;
  function assistanceSnapshotPayload(snapshot) {
    return canonicalJson({
      v: 2,
      url: snapshot.url,
      fields: snapshot.fields.map(({ hint: _hint, ...field }) => field),
      hasCaptcha: snapshot.hasCaptcha,
      hasLegal: snapshot.hasLegal,
      unsupported: snapshot.unsupported
    });
  }
  function assistancePagePayload(page) {
    return canonicalJson({
      v: 2,
      url: page.url,
      kind: page.kind,
      job: page.job ? { title: page.job.title, company: page.job.company, evidence: page.job.evidence } : null,
      snapshot: JSON.parse(assistanceSnapshotPayload(page.snapshot)),
      embedded: page.embedded ?? null
    });
  }

  // apps/extension/safety.ts
  var blockedDomains = ["linkedin.com", "lnkd.in", "wellfound.com", "angel.co", "naukri.com", "indeed.com", "indeed.jobs"];
  function destination(raw) {
    const url = new URL(raw);
    const host = url.hostname.toLowerCase().replace(/\.$/, "");
    if (blockedDomains.some((domain) => host === domain || host.endsWith(`.${domain}`)) || /(^|\.)indeed\.[a-z.]+$/.test(host)) {
      throw new Error("This site is manual-only. No extension inspection or automation is permitted.");
    }
    if (url.username || url.password || url.hash || host !== url.hostname) {
      throw new Error("Unsupported destination URL.");
    }
    if (url.protocol !== "https:" && !isFixture(raw)) {
      throw new Error("Only HTTPS destinations or the controlled local fixture are supported.");
    }
    if (url.protocol === "https:" && (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || !host.includes(".") || /^[\d.]+$/.test(host) || host.includes(":") || url.port !== "" && url.port !== "443")) throw new Error("Private or nonstandard destination hosts are unsupported.");
    return url;
  }
  function isFixture(raw) {
    const url = new URL(raw);
    return url.protocol === "http:" && url.hostname === "127.0.0.1" && Number(url.port) >= 1024 && url.pathname === "/fixture/application" && !url.hash && !url.username && !url.password;
  }
  function decodeResume(resume) {
    if (!resume || !["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"].includes(resume.mime) || typeof resume.filename !== "string" || !/^[^/\\\x00-\x1f]{1,150}\.(pdf|docx)$/i.test(resume.filename) || typeof resume.base64 !== "string" || resume.base64.length > 14e6 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(resume.base64)) {
      throw new Error("The approved resume is invalid or exceeds the 10 MB limit.");
    }
    const bytes = Uint8Array.from(atob(resume.base64), (char) => char.charCodeAt(0));
    if (!bytes.length || bytes.length > 1e7) throw new Error("The approved resume is empty or too large.");
    const pdf = resume.mime === "application/pdf";
    if (pdf ? !resume.filename.toLowerCase().endsWith(".pdf") || new TextDecoder().decode(bytes.slice(0, 5)) !== "%PDF-" : !resume.filename.toLowerCase().endsWith(".docx") || bytes[0] !== 80 || bytes[1] !== 75) {
      throw new Error("The resume content does not match its approved file type.");
    }
    return bytes;
  }

  // apps/extension/assist-safety.ts
  function publicJobToken(url, key2, value) {
    return key2 === "token" && /^\d{1,20}$/.test(value) && ["boards.greenhouse.io", "job-boards.greenhouse.io"].includes(url.hostname.toLowerCase()) && url.pathname === "/embed/job_app";
  }
  function assistanceDestination(raw) {
    const url = new URL(raw);
    const hash = url.hash;
    url.hash = "";
    destination(url.href);
    const host = url.hostname.toLowerCase();
    if (/(^|\.)indeed\.[a-z.]+$/.test(host) || host === "indeed.jobs" || host.endsWith(".indeed.jobs"))
      throw new Error("Indeed is manual-only; Chairman does not inspect or automate it.");
    if (/(?:^|\/)(?:login|signin|sign-in|auth|oauth|account|accounts|register|signup)(?:\/|$)/i.test(url.pathname))
      throw new Error("Account and sign-in pages are manual-only. Sign in yourself, then return to the public application.");
    if ([...url.searchParams.entries()].some(([key2, value]) => /password|secret|token|code|session|auth|email/i.test(key2) && !publicJobToken(url, key2, value)))
      throw new Error("Pages with credential/session parameters cannot be inspected. Open the public job URL.");
    if (!isFixture(url.href) && /(^|\.)indeed\./.test(host)) throw new Error("This platform is manual-only.");
    url.hash = hash;
    return url;
  }

  // packages/documents/no-ai.ts
  function hasNoAiRestriction(text) {
    const normalized = text.replace(/&#(?:x([0-9a-f]+)|([0-9]+));/gi, (_, hex, decimal) => {
      const code = Number.parseInt(hex || decimal, hex ? 16 : 10);
      return code > 0 && code <= 1114111 ? String.fromCodePoint(code) : " ";
    }).replace(/&(?:nbsp|ensp|emsp);/gi, " ").replace(/<[^>]*>/g, " ").replace(/[’‘]/g, "'").replace(/\s+/g, " ").toLowerCase();
    const ai = "(?:ai\\b|artificial intelligence|chatgpt\\b|large language models?\\b|llms?\\b)";
    return [
      /\b(?:your|their|one's|my|our|applicant's|candidate's)\s+own[- ]words\b/,
      /\bown[- ]words\b/,
      /\b(?:human[- ]authored|human[- ]written)\b/,
      /\b(?:written|completed|prepared)\s+(?:entirely|solely|only)\s+by\s+(?:you|the applicant|the candidate)\b/,
      new RegExp(`\\bno[- ]+(?:(?:use of|generative)[- ]+)*${ai}`),
      new RegExp(`\\b(?:do not|don't|must not|mustn't|cannot|can't|may not|never|not to)\\b[^.!?]{0,100}\\b(?:use|used|using|submit|accept|generate|generated|employ)\\b[^.!?]{0,100}${ai}`),
      new RegExp(`\\b(?:not|never|haven't|hasn't)\\b[^.!?]{0,80}\\b(?:used|written|generated|produced|prepared|assisted)\\b[^.!?]{0,80}${ai}`),
      new RegExp(`\\b(?:without|not using)\\b[^.!?]{0,100}${ai}`),
      new RegExp(`${ai}[^.!?]{0,100}\\b(?:prohibited|forbidden|not (?:allowed|permitted|accepted|to be used)|disallowed|rejected|disqualif(?:ied|ication|ying)|invalidate)\\b`),
      new RegExp(`\\b(?:prohibit|forbid|disallow|reject|ban)(?:s|ted|ned|ed)?\\b[^.!?]{0,100}${ai}`)
    ].some((pattern) => pattern.test(normalized));
  }

  // apps/extension/assist-page.ts
  var sensitive = /\b(?:password|passcode|passphrase|secret|token|otp|one time (?:code|password)|verification code|security code|credit card|card number|cc (?:number|csc|exp)|cvv|cvc|social security|ssn|national id|national insurance|passport number|bank account|routing number|iban)\b/i;
  var manualOnly = /\b(?:signature|sign here|own words|marital|religio(?:n|us)|date of birth|birth ?date|criminal|convict(?:ed|ion)|arrest(?:ed)?|felony)\b/i;
  var disclosureWords = /\b(?:gender|sex|sexual|pronouns?|race|racial|ethnic(?:ity)?|hispanic|latin[oax]|disabilit(?:y|ies)|veteran|military|transgender)\b/i;
  var acknowledgementWords = /\b(?:agree|agreement|consent|certify|certification|attest|declaration|declare|terms (?:and|&|of)|privacy|acknowledge|background check|opt.?in|subscribe|newsletter)\b/i;
  var sensitivityOf = (label) => disclosureWords.test(label) ? "disclosure" : acknowledgementWords.test(label) ? "acknowledgement" : void 0;
  var resumeLabel = /\b(?:resume|résumé|cv|curriculum vitae)\b/i;
  var autofillHelper = /\bauto-?fill\b|\bparse (?:your |my )?(?:resume|cv)\b|\bimport (?:from )?(?:your |my )?(?:resume|cv)\b|\bquick apply\b/i;
  var clean = (value, limit = 1e3) => value.replace(/\s+/g, " ").trim().slice(0, limit);
  var humanize = (value) => value.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[_\-.[\]]+/g, " ");
  var autoGenerated = /^(?::r[0-9a-z]*:|react-select-\d+.*|mui-\d+.*|headlessui-.*|radix-.*|downshift-.*|select2-.*|input-?\d+|field-?\d+|[0-9a-f-]{16,}|.*\d{6,}.*)$/i;
  var sha256 = async (value) => {
    const bytes = typeof value === "string" ? new TextEncoder().encode(value) : value;
    return [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map((n) => n.toString(16).padStart(2, "0")).join("");
  };
  var ticker;
  function useTicker(tick) {
    ticker = tick;
  }
  var timer = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));
  var wait = (milliseconds) => ticker ? Promise.race([ticker(milliseconds).catch(() => timer(milliseconds)), timer(milliseconds + 1e3)]) : timer(milliseconds);
  var trace = [];
  var traceStarted = 0;
  var verbose = false;
  function startTrace(debug = false) {
    trace = [];
    traceStarted = performance.now();
    verbose = debug;
  }
  function takeTrace() {
    const result = trace;
    trace = [];
    return result;
  }
  function note(step, detail = "", ok = true) {
    if (trace.length >= 400 || trace.some((entry) => entry.step === step && entry.detail === (detail.slice(0, 500) || void 0))) return;
    trace.push({ t: Math.round(performance.now() - traceStarted), step, ...detail ? { detail: detail.slice(0, 500) } : {}, ...ok ? {} : { ok: false } });
    if (verbose) (ok ? console.debug : console.warn)(`[Chairman page] ${step}`, detail);
  }
  function describeElement(element) {
    const classes = typeof element.className === "string" ? element.className.trim().split(/\s+/).filter(Boolean).slice(0, 3).map((name) => `.${name}`).join("") : "";
    return `${element.tagName.toLowerCase()}${element.id ? `#${element.id}` : ""}${classes}`.slice(0, 120);
  }
  var textKinds = /* @__PURE__ */ new Set(["text", "email", "tel", "url", "number", "date", "textarea"]);
  var choiceKinds = /* @__PURE__ */ new Set(["select", "radio", "aria-radio", "yesno", "checkbox"]);
  var fieldType = {
    text: "text",
    email: "email",
    tel: "tel",
    url: "url",
    number: "number",
    date: "date",
    textarea: "textarea",
    select: "select",
    radio: "radio",
    "aria-radio": "radio",
    combobox: "combobox",
    yesno: "radio",
    checkbox: "checkbox",
    file: "file"
  };
  function rendered(element) {
    if (element.closest('[hidden],[inert],[aria-hidden="true"]')) return false;
    const style = getComputedStyle(element);
    return style.display !== "none" && style.visibility !== "hidden" && style.visibility !== "collapse" && element.getClientRects().length > 0;
  }
  async function settle(doc, quietMs, maxMs) {
    if (quietMs <= 0 || !doc.documentElement) return;
    const start = Date.now();
    let changed = start;
    const observer = new MutationObserver(() => {
      changed = Date.now();
    });
    observer.observe(doc.documentElement, { childList: true, subtree: true });
    try {
      while (Date.now() - start < maxMs && Date.now() - changed < quietMs)
        await wait(Math.max(10, Math.min(50, quietMs - (Date.now() - changed), maxMs - (Date.now() - start))));
    } finally {
      observer.disconnect();
    }
  }
  function ownText(element) {
    const copy = element.cloneNode(true);
    copy.querySelectorAll('input,select,textarea,button,script,style,noscript,svg,[hidden],[role="listbox"],[role="option"],[role="alert"]').forEach((node) => node.remove());
    return copy.textContent ?? "";
  }
  function textById(doc, ids, exclude) {
    return (ids ?? "").split(/\s+/).filter(Boolean).slice(0, 8).map((id) => doc.getElementById(id)).filter((node) => !!node && node !== exclude && !node.contains(exclude)).map(ownText).join(" ");
  }
  var errorish = (element) => element.getAttribute("role") === "alert" || /\b(?:error|invalid|alert|warning|danger)\b/i.test(`${typeof element.className === "string" ? element.className : ""} ${element.id}`.replace(/[_-]+/g, " "));
  function textOf(element, allowForm = false) {
    const result = [];
    const walker = element.ownerDocument.createTreeWalker(element, 4);
    let node, count = 0, size = 0;
    while ((node = walker.nextNode()) && count++ < 5e3 && size < 5e4) {
      const parent = node.parentElement;
      if (!parent || parent.closest(`script,style,noscript,${allowForm ? "" : "form,"}input,textarea,select,[hidden],[aria-hidden=true]`) || !rendered(parent)) continue;
      const text = clean(node.textContent ?? "", 5e3);
      if (text) {
        result.push(text);
        size += text.length;
      }
    }
    return result.join("\n").slice(0, 5e4);
  }
  function htmlText(doc, value) {
    const template = doc.createElement("template");
    template.innerHTML = value.slice(0, 1e5);
    template.content.querySelectorAll("script,style,input,textarea,form").forEach((element) => element.remove());
    for (const element of template.content.querySelectorAll("p,div,li,h1,h2,h3,br")) element.before(doc.createTextNode(" "));
    return clean(template.content.textContent ?? "", 5e4);
  }
  function capturedJob(doc) {
    const postings = [];
    let budget = 200;
    function visit(value, depth = 0) {
      if (depth > 8 || budget-- <= 0 || !value || typeof value !== "object") return;
      if (Array.isArray(value)) {
        value.slice(0, 100).forEach((item2) => visit(item2, depth + 1));
        return;
      }
      const item = value;
      if (item["@type"] === "JobPosting" || Array.isArray(item["@type"]) && item["@type"].includes("JobPosting")) postings.push(item);
      if (item["@graph"]) visit(item["@graph"], depth + 1);
      if (item.mainEntity) visit(item.mainEntity, depth + 1);
      if (item.itemListElement) visit(item.itemListElement, depth + 1);
      if (item.item) visit(item.item, depth + 1);
    }
    for (const script of [...doc.querySelectorAll('script[type="application/ld+json"]')].slice(0, 12)) {
      if ((script.textContent?.length ?? 0) > 15e4) continue;
      try {
        visit(JSON.parse(script.textContent || "null"));
      } catch {
      }
    }
    if (postings.length > 1) return { listing: true };
    const posting = postings[0];
    if (posting && typeof posting.title === "string" && typeof posting.description === "string") {
      const org = posting.hiringOrganization;
      const place = Array.isArray(posting.jobLocation) ? posting.jobLocation[0] : posting.jobLocation;
      const country = place?.address?.addressCountry;
      const location2 = [
        place?.address?.addressLocality,
        place?.address?.addressRegion,
        typeof country === "string" ? country : country?.name
      ].filter((item) => typeof item === "string").join(", ");
      const description = htmlText(doc, posting.description);
      if (description.length >= 100) return { listing: false, job: {
        title: clean(posting.title, 300),
        company: typeof org?.name === "string" ? clean(org.name, 300) : "",
        location: clean(location2, 300),
        description,
        evidence: "JobPosting"
      } };
    }
    const headings = [...doc.querySelectorAll("h1")].filter(rendered);
    const candidates = [...doc.querySelectorAll('[itemprop="description"],[data-testid="job-description"],.job-description,.job-description-content,.ashby-job-posting-description,.job__description,article,main')].slice(0, 16);
    for (const candidate of candidates) {
      const description = textOf(candidate);
      if (headings.length === 1 && description.length >= 200 && /responsibilit|qualifications|about (?:the |this )?role|what you.ll|requirements|you will|we.re looking/i.test(description)) {
        const links = [...candidate.querySelectorAll("a[href]")].filter((link) => /\/(?:jobs|positions)\//.test(link.getAttribute("href") ?? ""));
        if (links.length > 8) return { listing: true };
        return { listing: false, job: {
          title: clean(headings[0].textContent ?? "", 300),
          company: clean(doc.querySelector('meta[property="og:site_name"]')?.getAttribute("content") ?? "", 300),
          location: "",
          description,
          evidence: "visible-description"
        } };
      }
    }
    return { listing: !!doc.querySelector('a[href*="/jobs/"],a[href*="/positions/"],[itemtype*="ItemList"]') };
  }
  var excludedRegion = 'header,nav,footer,[role="search"],[role="banner"],[role="navigation"],[role="contentinfo"],[id*="cookie" i],[class*="cookie" i],[id*="newsletter" i],[class*="newsletter" i]';
  var dropdownButton = 'button[aria-haspopup="listbox"],[role="button"][aria-haspopup="listbox"]';
  var promptContainer = '[data-uxi-widget-type="multiselect"],[data-uxi-widget-type="selectinput"],[data-automation-id="multiSelectContainer"],[data-automation-id="multiselectInputContainer"]';
  var isPrompt = (element) => !!element.closest(promptContainer) || element.getAttribute("data-automation-id") === "searchBox";
  var controlSelector = `input,select,textarea,[role="combobox"],[role="radiogroup"],[role="radio"],${dropdownButton}`;
  function usableFile(input) {
    if (input.matches(":disabled") || input.closest("[hidden],[inert]")) return false;
    if (rendered(input)) return true;
    const holders = [...input.labels ?? [], input.closest("label"), input.parentElement, input.parentElement?.parentElement];
    return holders.some((holder) => !!holder && holder !== input.ownerDocument.body && rendered(holder));
  }
  var workdayPage = (doc) => /\.myworkdayjobs\.com$|^wd\d{1,3}\.myworkdaysite\.com$/.test(doc.location.hostname);
  function resumeSection(anchor) {
    for (let node = anchor, depth = 0; node && depth < 8; node = node.parentElement, depth++) {
      const identity = ["id", "class", "data-automation-id", "data-testid", "aria-label", "name"].map((name) => node.getAttribute(name) ?? "").join(" ");
      if (/resume|curriculum|(?:^|[\s_-])cv(?:$|[\s_-])/i.test(identity)) return true;
      for (let sibling = node.previousElementSibling, count = 0; sibling && count < 3; sibling = sibling.previousElementSibling, count++) {
        if (sibling.querySelector("input,select,textarea,button")) continue;
        const text = clean(sibling.textContent ?? "", 120);
        if (text && resumeLabel.test(text)) return true;
      }
    }
    return false;
  }
  function uploadShowsFile(anchor) {
    for (let node = anchor.parentElement, depth = 0; node && depth < 4; node = node.parentElement, depth++) {
      const text = clean(node.innerText || node.textContent || "", 2e3);
      if (/[\w()[\]\- ]{1,120}\.(?:pdf|docx?|rtf|odt|txt)\b/i.test(text)) return true;
      if (node.querySelectorAll("input,select,textarea").length > 3) break;
    }
    return false;
  }
  function candidateControls(scope) {
    const pageBody = scope === scope.ownerDocument.body;
    return [...scope.querySelectorAll(controlSelector)].filter((element) => {
      if (pageBody && element.closest(excludedRegion)) return false;
      if (element instanceof HTMLInputElement) {
        if (["hidden", "submit", "button", "reset", "image"].includes(element.type)) return false;
        if (element.type === "file") return usableFile(element);
        if (element.type === "radio" || element.type === "checkbox")
          return !element.matches(":disabled") && (rendered(element) || [...element.labels ?? []].some(rendered));
      }
      if (element.matches(":disabled") || element.getAttribute("aria-disabled") === "true") return false;
      return rendered(element);
    });
  }
  function applicationRoot(doc) {
    const selectors = 'form,[role="form"],#application-form,#application_form,.application-form,.ashby-application-form-container,[data-qa*="application" i],[class*="application-form" i],[id*="application-form" i],[data-automation-id*="applyFlow" i]';
    let best, candidates = 0;
    for (const element of doc.querySelectorAll(selectors)) {
      if (!rendered(element) || element.closest(excludedRegion)) continue;
      const controls = candidateControls(element);
      if (!controls.length) continue;
      const identity = `${element.id} ${typeof element.className === "string" ? element.className : ""} ${element.getAttribute("action") ?? ""} ${element.getAttribute("role") ?? ""}`;
      const text = (element.textContent ?? "").slice(0, 2e4);
      const score = controls.length + (controls.some((control) => control instanceof HTMLInputElement && control.type === "file") && resumeLabel.test(text) ? 6 : 0) + (controls.some((control) => control instanceof HTMLInputElement && control.type === "email") ? 3 : 0) + (/\b(?:first name|full name|last name|given name)\b/i.test(text) ? 3 : 0) + (/\b(?:submit application|apply now|submit your application|send application)\b/i.test(text) ? 2 : 0) - (/search|newsletter|subscribe|login|log-in|sign-?in/i.test(identity) || element.matches('[role="search"]') ? 30 : 0);
      candidates++;
      if (score <= 0) continue;
      if (!best || score > best.score || score === best.score && best.element.contains(element) && controls.length === best.count)
        best = { element, score, count: controls.length };
    }
    return best ? { element: best.element, info: `${describeElement(best.element)} (score ${best.score}, ${best.count} controls, ${candidates} candidate forms)` } : { element: doc.body, info: `page body (no application form among ${candidates} candidate forms; page chrome excluded)` };
  }
  function optionLabel(control) {
    const labels = control instanceof HTMLInputElement ? [...control.labels ?? []].map(ownText).join(" ") : "";
    let text = labels || control.getAttribute("aria-label") || textById(control.ownerDocument, control.getAttribute("aria-labelledby"), control);
    if (!text && !(control instanceof HTMLInputElement)) text = ownText(control);
    if (!text) {
      const sibling = control.nextSibling;
      text = sibling?.nodeType === 3 ? sibling.textContent ?? "" : sibling instanceof Element ? ownText(sibling) : "";
    }
    return clean(text, 300);
  }
  var dropZone = '[data-automation-id*="drop-zone" i],[data-automation-id*="dropzone" i],[class*="drop-zone" i],[class*="dropzone" i],[class*="drop_zone" i]';
  var uploadChatter = /^(?:or|and|drop (?:a |your |the )?files? here|drag (?:and|&) drop(?: (?:a |your )?files?)?(?: here)?|(?:select|choose|browse for|attach|upload) (?:a |your )?files?|browse)$/i;
  function precedingLabel(container, anchor, group, allowFollowing = false, exclude) {
    const strong = 'label,legend,[class*="label" i],[class*="question" i],[class*="title" i],[id*="label" i],[id*="question" i]';
    const weak = "h2,h3,h4,h5,h6,p,span,div,strong,b,dt";
    for (const selector of allowFollowing ? ["label"] : [strong, weak]) {
      let best;
      for (const candidate of container.querySelectorAll(selector)) {
        if (candidate.contains(anchor) || [...group].some((member) => candidate.contains(member)) || exclude?.contains(candidate)) continue;
        const precedes = !!(candidate.compareDocumentPosition(anchor) & Node.DOCUMENT_POSITION_FOLLOWING);
        if (precedes === allowFollowing) continue;
        if (candidate instanceof HTMLLabelElement && candidate.control && group.has(candidate.control)) continue;
        if (candidate.querySelector("input,select,textarea,[role=combobox]") || errorish(candidate) || !rendered(candidate)) continue;
        const text = clean(ownText(candidate), 400);
        if (text.length < 2 || text.length > 300 || !new RegExp("\\p{L}{2}", "u").test(text) || uploadChatter.test(text)) continue;
        best = text;
        if (allowFollowing) return best;
      }
      if (best) return best;
    }
    return void 0;
  }
  function question(anchor, group, kind, controls, root) {
    const doc = anchor.ownerDocument;
    const members = new Set(group.length ? group : [anchor]);
    const grouped = kind === "radio" || kind === "aria-radio" || kind === "yesno";
    let raw = "";
    if (grouped) {
      const holder = anchor.closest('[role="radiogroup"],[role="group"]') ?? (anchor.matches('[role="radiogroup"]') ? anchor : null);
      raw = holder ? textById(doc, holder.getAttribute("aria-labelledby"), anchor) || holder.getAttribute("aria-label") || "" : "";
      const fieldset = group[0]?.closest("fieldset");
      if (!raw && fieldset && group.every((member) => fieldset.contains(member))) raw = ownText(fieldset.querySelector("legend") ?? doc.createElement("i"));
    } else {
      const picker = anchor.matches(dropdownButton) || isPrompt(anchor);
      raw = textById(doc, anchor.getAttribute("aria-labelledby"), anchor) || (picker ? "" : anchor.getAttribute("aria-label") || "");
      if (!raw && anchor instanceof HTMLElement && "labels" in anchor) raw = [...anchor.labels ?? []].map(ownText).join(" ");
      if (picker && /^(?:search|select one|select|choose)$/i.test(clean(raw))) raw = "";
    }
    if (!/[\p{L}\p{N}]/u.test(raw)) raw = "";
    let container;
    let qualify = kind === "checkbox" && !!clean(raw) && clean(raw).length < 25;
    const zone = kind === "file" ? anchor.closest(dropZone) : null;
    const start = zone?.parentElement ?? anchor.parentElement;
    for (let node = start, depth = 0; node && depth < 6; node = node.parentElement, depth++) {
      if (controls.some((control) => !members.has(control) && node.contains(control) && !anchor.contains(control))) break;
      container = node;
      if (qualify) {
        const text = precedingLabel(node, anchor, members, false, zone);
        if (text && normalizeText(text) !== normalizeText(raw)) {
          raw = `${text} (${clean(raw)})`;
          qualify = false;
        }
      }
      if (!clean(raw)) {
        const text = precedingLabel(node, anchor, members, false, zone) ?? (grouped ? void 0 : precedingLabel(node, anchor, members, true, zone));
        if (text) raw = text;
      }
      if (node === root) break;
    }
    if (clean(raw)) return { raw, container, weak: false };
    if (anchor.matches(dropdownButton)) {
      const shown = clean(anchor.textContent ?? "", 300);
      const spoken = clean((anchor.getAttribute("aria-label") ?? "").replace(shown, " ").replace(/\b(?:required|select one)\b/gi, " "), 300);
      if (new RegExp("\\p{L}{2}", "u").test(spoken)) return { raw: spoken, container, weak: false };
    }
    const fallback = anchor.getAttribute("placeholder") || anchor.getAttribute("title") || "";
    if (clean(fallback)) return { raw: fallback, container, weak: false };
    const named = humanize(anchor.getAttribute("name") || anchor.id || "");
    return { raw: new RegExp("\\p{L}{2}", "u").test(named) && named.length <= 60 && !autoGenerated.test(anchor.getAttribute("name") || anchor.id) ? named : "", container, weak: true };
  }
  function requiredFor(anchor, group, raw, container) {
    const members = group.length ? group : [anchor];
    if (members.some((member) => member.required || member.getAttribute("aria-required") === "true")) return true;
    if (anchor.closest('[aria-required="true"]')) return true;
    const labels = "labels" in anchor ? [...anchor.labels ?? []].map((label) => label.textContent ?? "").join(" ") : "";
    if (/\*\s*$|\(required\)/i.test(clean(raw)) || /\*/.test(labels)) return true;
    return !!container?.querySelector('[class*="required" i]:not(input):not(select):not(textarea),[class*="asterisk" i],abbr[title*="required" i]');
  }
  function stableAttribute(element) {
    if (!element) return void 0;
    if (element.id && !autoGenerated.test(element.id)) return `id:${element.id}`;
    const name = element.getAttribute("name");
    if (name && !autoGenerated.test(name)) return `name:${name}`;
    for (let node = element, depth = 0; node && depth < 4; node = node.parentElement, depth++) {
      for (const attribute of ["data-field-path", "data-qa", "data-automation-id", "data-testid", "data-field", "data-question-id"]) {
        const value = node.getAttribute(attribute);
        if (value && !autoGenerated.test(value)) return `${attribute}:${value}`;
      }
    }
    return void 0;
  }
  function comboboxShell(anchor) {
    let shell = anchor;
    for (let node = anchor.parentElement, depth = 0; node && depth < 4; node = node.parentElement, depth++) {
      if (node.querySelectorAll('[role="combobox"],input:not([type="hidden"])').length > 1) break;
      shell = node;
      if (node.querySelector('[class*="single-value" i],[class*="singlevalue" i]') || /select__control|-control\b/i.test(typeof node.className === "string" ? node.className : "")) break;
    }
    return shell;
  }
  function comboboxDisplay(anchor) {
    const pills = [...anchor.closest(promptContainer)?.querySelectorAll('[data-automation-id="selectedItem"]') ?? []].filter(rendered);
    if (pills.length) return clean(pills.map((pill) => pill.textContent ?? "").join(", "), 300);
    const shell = comboboxShell(anchor);
    const single = shell.querySelector('[class*="single-value" i],[class*="singlevalue" i]');
    if (single && rendered(single)) return clean(single.textContent ?? "", 300);
    if (anchor instanceof HTMLInputElement) return clean(anchor.value, 300);
    const copy = anchor.cloneNode(true);
    copy.querySelectorAll('[class*="placeholder" i],svg,input').forEach((node) => node.remove());
    return clean(copy.textContent ?? "", 300).replace(/[\u200b\u200c\u200d\ufeff]/g, "");
  }
  function emptyish(value) {
    return !value.trim() || /^(?:https?:\/\/|\+\d{0,3})$/i.test(value.trim());
  }
  function pressed(element) {
    return element.getAttribute("aria-pressed") === "true" || element.getAttribute("aria-checked") === "true" || /^(?:on|checked|active|selected)$/.test(element.getAttribute("data-state") ?? "") || // Also CSS-module classes such as "_active_1ks5v_14" or "option--selected".
    /(?:^|[\s_-])(?:selected|active|checked|is-selected|is-active|is-checked)(?=$|[\s_-])/i.test(typeof element.className === "string" ? element.className : "");
  }
  function selectedOption(select) {
    const option = select.selectedOptions[0];
    if (!option) return void 0;
    const choice = { value: option.value, label: clean(option.textContent ?? "") };
    if (isPlaceholderOption(choice) || select.selectedIndex === 0 && !option.defaultSelected && select.options.length > 1) return void 0;
    return choice;
  }
  function currentValue(unit, raw = false) {
    const anchor = unit.anchor;
    switch (unit.kind) {
      case "select":
        return raw ? anchor.value : selectedOption(anchor)?.value ?? "";
      // Options use labels when radio values repeat (or are "on"), so map the checked radio back through its option.
      case "radio":
        return [...unit.optionNodes].find(([, node]) => node.checked)?.[0] ?? "";
      case "aria-radio":
      case "yesno":
        return [...unit.optionNodes].find(([, node]) => pressed(node))?.[0] ?? "";
      case "combobox": {
        const shown = comboboxDisplay(anchor);
        return isPlaceholderOption({ value: shown, label: shown }) ? "" : shown;
      }
      case "file":
        return anchor.files?.[0]?.name ?? "";
      case "checkbox":
        return anchor.checked ? "true" : raw ? "false" : "";
      default:
        return anchor.value;
    }
  }
  function scanStructure(doc) {
    const { element: root, info: rootInfo } = applicationRoot(doc);
    const controls = candidateControls(root);
    if (controls.length > 600) throw new Error("This page exceeds the bounded form inspection limit. Continue manually.");
    const unsupported = [];
    let hasLegal = false;
    const units = [], identities = [], consumed = /* @__PURE__ */ new Set();
    const manual = (label, required, legal, reason) => {
      if (legal) hasLegal = true;
      if (required) unsupported.push(`${reason}: ${label || "unlabeled required question"}`);
    };
    const add = (kind, anchor, group, options, optionNodes) => {
      const asked = question(anchor, group, kind, controls, root);
      const label = cleanQuestion(clean(asked.raw, 600));
      const required = requiredFor(anchor, group, asked.raw, asked.container);
      const identitySource = `${label} ${anchor.getAttribute("name") ?? ""} ${anchor.id} ${anchor.getAttribute("autocomplete") ?? ""}`;
      if (sensitive.test(humanize(identitySource))) {
        manual(label, required, false, "Enter this yourself");
        return;
      }
      if (manualOnly.test(label)) {
        manual(label, required, true, "Answer this yourself");
        return;
      }
      const sensitivity = kind === "file" ? void 0 : sensitivityOf(label);
      if (!label) {
        manual(label, required, false, "Answer this yourself");
        return;
      }
      if (kind === "file" && !workdayPage(doc) && (anchor.closest('[class*="autofill" i]') || autofillHelper.test(`${identitySource} ${asked.container ? ownText(asked.container).slice(0, 400) : ""}`))) {
        note("skip-autofill-upload", `${label || "file input"}: site autofill helper, not the resume field`);
        return;
      }
      if (kind === "file" && !resumeLabel.test(identitySource) && !resumeSection(anchor)) {
        manual(label, required, false, "Upload this yourself");
        return;
      }
      if (choiceKinds.has(kind) && (!options.length || new Set(options.map((option) => option.value)).size !== options.length || options.some((option) => option.value.length > 1e3 || option.label.length > 1e3))) {
        manual(label, required, false, "Select this yourself");
        return;
      }
      const input = anchor;
      const shown = kind === "file" && !resumeLabel.test(label) ? clean(`Resume/CV: ${label}`, 600) : label;
      const field = { key: "", label: shown, type: fieldType[kind], required, options: options.map((option) => option.value), ...sensitivity ? { sensitivity } : {} };
      if (options.length) field.optionLabels = Object.fromEntries(options.map((option) => [option.value, option.label]));
      if (kind === "file") field.accept = input.accept.split(",").map((item) => item.trim().toLowerCase()).filter((item) => item && item.length <= 200).slice(0, 30);
      if (textKinds.has(kind) || kind === "combobox") {
        const placeholder = clean(anchor.getAttribute("placeholder") ?? "", 200), autocomplete = clean(anchor.getAttribute("autocomplete") ?? "", 100);
        const pattern = anchor.getAttribute("pattern") ?? "", hint = clean(textById(doc, anchor.getAttribute("aria-describedby"), anchor), 500);
        if (placeholder && placeholder !== label) field.placeholder = placeholder;
        if (autocomplete && !/^(?:on|off)$/i.test(autocomplete)) field.autocomplete = autocomplete;
        if (pattern && pattern.length <= 500) field.pattern = pattern;
        if (hint && hint !== label) field.hint = hint;
        if ("maxLength" in input && input.maxLength > 0) field.maxLength = input.maxLength;
        if ("minLength" in input && input.minLength > 0) field.minLength = input.minLength;
      }
      identities.push(`${identityGroupOf(kind)}|${stableAttribute(kind === "radio" ? group[0] : anchor) ?? `label:${normalizeText(label)}`}`);
      units.push({ kind, anchor, group, optionNodes, container: asked.container, field, occupied: false });
    };
    for (const element of controls) {
      if (consumed.has(element)) continue;
      if (element.matches('[role="radiogroup"]')) {
        if (element.querySelector('input[type="radio"]')) continue;
        const radios = [...element.querySelectorAll('[role="radio"]')].filter(rendered);
        radios.forEach((radio) => consumed.add(radio));
        const options = radios.map((radio) => ({ value: optionLabel(radio), label: optionLabel(radio) }));
        add("aria-radio", element, radios, options, new Map(radios.map((radio, index) => [options[index].value, radio])));
        continue;
      }
      if (element.matches('[role="radio"]') && !(element instanceof HTMLInputElement)) continue;
      if (element instanceof HTMLSelectElement) {
        const options = [...element.options].filter((option) => !option.disabled && !option.hidden).map((option) => ({ value: option.value, label: clean(option.textContent ?? "", 300) })).filter((option) => !isPlaceholderOption(option));
        if (element.multiple || options.length > 300) {
          const asked = question(element, [], "select", controls, root);
          manual(cleanQuestion(clean(asked.raw)), requiredFor(element, [], asked.raw, asked.container), manualOnly.test(asked.raw), "Select this yourself");
          continue;
        }
        add("select", element, [], options, /* @__PURE__ */ new Map());
        continue;
      }
      if (element instanceof HTMLTextAreaElement) {
        add("textarea", element, [], [], /* @__PURE__ */ new Map());
        continue;
      }
      if (element instanceof HTMLInputElement) {
        const type = element.type;
        if (type === "password") continue;
        if (type === "checkbox") {
          const scope = element.closest("form") ?? root;
          const siblings = element.name ? controls.filter((control) => control instanceof HTMLInputElement && control.type === "checkbox" && control.name === element.name && scope.contains(control)) : [element];
          if (siblings.length > 1) {
            siblings.forEach((box) => consumed.add(box));
            const asked = question(element, siblings, "radio", controls, root);
            manual(cleanQuestion(clean(asked.raw)), requiredFor(element, siblings, asked.raw, asked.container), manualOnly.test(asked.raw), "Select these yourself");
            continue;
          }
          add("checkbox", element, [], [{ value: "true", label: "Checked" }, { value: "false", label: "Unchecked" }], /* @__PURE__ */ new Map());
          continue;
        }
        if (type === "radio") {
          const scope = element.closest("form") ?? root;
          const radios = element.name ? controls.filter((control) => control instanceof HTMLInputElement && control.type === "radio" && control.name === element.name && scope.contains(control)) : [element];
          radios.forEach((radio) => consumed.add(radio));
          const labels = radios.map(optionLabel);
          const valuesUnique = new Set(radios.map((radio) => radio.value)).size === radios.length && radios.every((radio) => radio.value && radio.value !== "on");
          const options = radios.map((radio, index) => ({ value: valuesUnique ? radio.value : labels[index], label: labels[index] || radio.value }));
          add("radio", radios[0], radios, options, new Map(radios.map((radio, index) => [options[index].value, radio])));
          continue;
        }
        if (type === "file") {
          add("file", element, [], [], /* @__PURE__ */ new Map());
          continue;
        }
        const combobox = element.getAttribute("role") === "combobox" || !!element.closest('[role="combobox"]') || isPrompt(element) || element.getAttribute("aria-haspopup") === "listbox" || element.getAttribute("aria-autocomplete") === "list" && /select__|react-select/i.test(`${element.id} ${element.closest('[class*="select__"]')?.className ?? ""}`);
        if (combobox) {
          add("combobox", element, [], [], /* @__PURE__ */ new Map());
          continue;
        }
        const kind = { text: "text", search: "text", "": "text", email: "email", tel: "tel", url: "url", number: "number", date: "date" }[type];
        if (kind) add(kind, element, [], [], /* @__PURE__ */ new Map());
        else {
          const asked = question(element, [], "text", controls, root);
          manual(cleanQuestion(clean(asked.raw)), requiredFor(element, [], asked.raw, asked.container), false, "Unsupported control; answer it yourself");
        }
        continue;
      }
      if (element.matches(dropdownButton)) {
        if (!element.closest('[role="combobox"]') && !element.closest(promptContainer)) add("combobox", element, [], [], /* @__PURE__ */ new Map());
        continue;
      }
      if (element.matches('[role="combobox"]') && !element.querySelector('input:not([type="hidden"])')) add("combobox", element, [], [], /* @__PURE__ */ new Map());
    }
    const pairs = /* @__PURE__ */ new Map();
    for (const button of root.querySelectorAll('button,[role="button"]')) {
      if (root === doc.body && button.closest(excludedRegion) || !rendered(button) || !["yes", "no"].includes(normalizeText(button.textContent ?? "")) || !button.parentElement) continue;
      pairs.set(button.parentElement, [...pairs.get(button.parentElement) ?? [], button]);
    }
    for (const [holder, buttons] of pairs) {
      const labels = buttons.map((button) => clean(button.textContent ?? ""));
      if (buttons.length !== 2 || new Set(labels.map(normalizeText)).size !== 2) continue;
      add("yesno", holder, buttons, labels.map((label) => ({ value: label, label })), new Map(buttons.map((button, index) => [labels[index], button])));
    }
    const ordered = units.map((unit, index) => ({ unit, identity: identities[index] })).sort((a, b) => a.unit.anchor === b.unit.anchor ? 0 : a.unit.anchor.compareDocumentPosition(b.unit.anchor) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1);
    if (ordered.length > 100) throw new Error("More than 100 fillable questions require manual handling.");
    const counts = /* @__PURE__ */ new Map(), used = /* @__PURE__ */ new Set(), finished = [];
    for (const { unit, identity } of ordered) {
      const occurrence = (counts.get(identity) ?? 0) + 1;
      counts.set(identity, occurrence);
      let key2 = stableFieldKey(identity) + (occurrence > 1 ? `-${occurrence}` : "");
      for (let suffix = 2; used.has(key2) && suffix < 100; suffix++) key2 = `${stableFieldKey(identity)}-${suffix}`;
      used.add(key2);
      const complete = { ...unit, key: key2, field: { ...unit.field, key: key2 } };
      complete.occupied = complete.kind === "file" ? !!complete.anchor.files?.length || uploadShowsFile(complete.anchor) : !emptyish(currentValue(complete));
      finished.push(complete);
    }
    const dialog = [...doc.querySelectorAll('[role="dialog"][aria-modal="true"],dialog[open]')].some(rendered);
    return { root, rootInfo, units: finished, byKey: new Map(finished.map((unit) => [unit.key, unit])), hasLegal, unsupported: [...new Set(unsupported)].slice(0, 100), dialog };
  }
  function identityGroupOf(kind) {
    return textKinds.has(kind) ? "text" : kind === "file" ? "file" : "choice";
  }
  function captchaState(doc) {
    const large = (element) => {
      const box = element.getBoundingClientRect();
      return box.width >= 100 && box.height >= 100;
    };
    const active = [...doc.querySelectorAll('iframe[src*="/bframe"],iframe[src*="hcaptcha.com"][src*="frame=challenge"],[data-captcha-challenge]')].some((element) => rendered(element) && large(element) && !element.closest(".grecaptcha-badge")) || [...doc.querySelectorAll('h1,h2,[role="alert"]')].some((element) => rendered(element) && /verify (?:that )?you(?:'re| are) (?:a )?human|checking your browser|complete the security check/i.test(element.textContent ?? ""));
    const widget = [...doc.querySelectorAll('.g-recaptcha:not([data-size="invisible"]),.h-captcha:not([data-size="invisible"]),.cf-turnstile,iframe[src*="recaptcha/api2/anchor"],iframe[src*="recaptcha/enterprise/anchor"],iframe[src*="hcaptcha.com"]')].some((element) => rendered(element) && !element.closest(".grecaptcha-badge"));
    const tokens2 = [...doc.querySelectorAll('[name^="g-recaptcha-response"],[name="h-captcha-response"],[name="cf-turnstile-response"]')];
    const solved = tokens2.length > 0 && tokens2.some((token) => token.value.trim().length >= 20);
    return { active, widget, solved };
  }
  var atsHosts = /(?:^|\.)(?:greenhouse\.io|lever\.co|ashbyhq\.com|workable\.com|smartrecruiters\.com|myworkdayjobs\.com|bamboohr\.com|recruitee\.com|jobvite\.com|icims\.com|breezy\.hr|teamtailor\.com|personio\.(?:de|com)|applytojob\.com|rippling\.com|pinpointhq\.com)$/i;
  function embeddedForm(doc) {
    for (const frame of doc.querySelectorAll("iframe[src]")) {
      const box = frame.getBoundingClientRect();
      if (!rendered(frame) || box.width < 200 || box.height < 200) continue;
      try {
        const url = new URL(frame.src, doc.baseURI);
        url.hash = "";
        if (url.protocol !== "https:" || !atsHosts.test(url.hostname) || url.origin === doc.location.origin) continue;
        assistanceDestination(url.href);
        return { url: url.href, host: url.hostname };
      } catch {
      }
    }
    return void 0;
  }
  async function inspectAssistancePage(doc, timing = {}) {
    const url = assistanceDestination(doc.location.href).href;
    const settleStarted = performance.now();
    await settle(doc, timing.quietMs ?? 400, timing.maxWaitMs ?? 2500);
    note("settle", `DOM quiet after ${Math.round(performance.now() - settleStarted)} ms`);
    if ([...doc.querySelectorAll('input[type="password"]')].some(rendered)) {
      note("credential-check", "visible password field; inspection stopped", false);
      throw new Error("A credential form is visible. Sign in yourself; Chairman never reads account credentials.");
    }
    const structure = scanStructure(doc), captured = capturedJob(doc), captcha = captchaState(doc);
    note("form-root", structure.rootInfo);
    for (const unit of structure.units)
      note("field", `${unit.field.label} [${unit.kind}${unit.field.required ? ", required" : ""}${unit.occupied ? ", has a value" : ""}${unit.field.options.length ? `, ${unit.field.options.length} options` : ""}] ${unit.key}`);
    if (!structure.units.length) note("fields", "no fillable questions detected", false);
    if (structure.unsupported.length) note("manual-only", structure.unsupported.join(" | "));
    note("captcha", `challenge open: ${captcha.active}; widget present: ${captcha.widget}; solved: ${captcha.solved}`, !captcha.active);
    note("job", captured.job ? `${captured.job.evidence}: ${captured.job.title}` : captured.listing ? "looks like a listing page" : "no job description on this page");
    const formText = structure.root === doc.body ? structure.units.map((unit) => unit.field.label).join("\n") : textOf(structure.root, true);
    if (hasNoAiRestriction([captured.job?.description ?? "", formText].join("\n"))) {
      note("no-ai-check", "the posting or form restricts AI assistance", false);
      throw new Error("The posting restricts AI assistance. Use human-authored materials and apply manually.");
    }
    const fields = structure.units.map((unit) => unit.field);
    const base = { url, fields, hasCaptcha: captcha.active, hasLegal: structure.hasLegal, unsupported: structure.unsupported };
    const snapshot = { ...base, fingerprint: await sha256(assistanceSnapshotPayload(base)) };
    const embedded = fields.length ? void 0 : embeddedForm(doc);
    const heading = [...doc.querySelectorAll("h1")].find(rendered)?.textContent ?? doc.title;
    const page = {
      url,
      kind: captured.job ? "job" : fields.length ? "form" : captured.listing ? "listing" : "unsupported",
      title: clean(heading ?? "", 300),
      ...captured.job ? { job: captured.job } : {},
      snapshot,
      occupied: structure.units.filter((unit) => unit.occupied).map((unit) => unit.key),
      blockers: [
        ...structure.unsupported,
        ...captcha.active ? ["A verification challenge is open. Complete it yourself; Chairman never solves or bypasses CAPTCHA."] : [],
        ...captcha.widget && !captcha.active && !captcha.solved ? ["This page has a CAPTCHA. Solve it yourself before you submit."] : [],
        ...structure.hasLegal ? ["Consent, declarations and demographic answers remain yours."] : [],
        ...!fields.length && structure.dialog ? ["A dialog is open. Close it, then rescan."] : [],
        ...embedded ? [`The application form is embedded from ${embedded.host}. Open it directly to fill it.`] : []
      ].slice(0, 120),
      ...embedded ? { embedded } : {}
    };
    if (embedded) note("embedded-form", embedded.host);
    const fingerprint = await sha256(assistancePagePayload(page));
    note("fingerprint", `${fingerprint.slice(0, 12)} (${fields.length} questions)`);
    return { ...page, fingerprint };
  }
  function setNativeValue(element, value) {
    const prototype = element instanceof HTMLSelectElement ? HTMLSelectElement.prototype : element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(prototype, "value").set.call(element, value);
  }
  function mouse(element, type) {
    const Constructor = type.startsWith("pointer") && typeof PointerEvent === "function" ? PointerEvent : MouseEvent;
    element.dispatchEvent(new Constructor(type, { bubbles: true, cancelable: true, composed: true, button: 0, view: element.ownerDocument.defaultView }));
  }
  function guardedClick(element) {
    const view = element.ownerDocument.defaultView;
    if (!view || element.closest('input[type="submit"],input[type="image"],a[href]')) throw new Error("Chairman only clicks answer buttons.");
    const block = (event) => {
      event.preventDefault();
      event.stopImmediatePropagation();
      note("submit-guard", "cancelled a submission triggered by an answer button");
    };
    view.addEventListener("submit", block, true);
    try {
      for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup"]) mouse(element, type);
      element.click();
    } finally {
      view.setTimeout(() => view.removeEventListener("submit", block, true), 150);
    }
  }
  function safeToClick(element) {
    const button = element.closest("button");
    return !(button && button.type !== "button") && !element.closest('input[type="submit"],input[type="image"],a[href]');
  }
  function click(element) {
    if (!safeToClick(element)) throw new Error("Chairman only clicks controls that cannot submit or navigate.");
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup"]) mouse(element, type);
    element.click();
  }
  function guardedEnter(element) {
    const view = element.ownerDocument.defaultView;
    if (!view || !isPrompt(element)) throw new Error("Chairman presses Enter only in a picker's search box.");
    const block = (event) => {
      event.preventDefault();
      event.stopImmediatePropagation();
      note("submit-guard", "cancelled a submission triggered by a search box");
    };
    view.addEventListener("submit", block, true);
    try {
      for (const type of ["keydown", "keypress", "keyup"]) element.dispatchEvent(new KeyboardEvent(type, { key: "Enter", code: "Enter", keyCode: 13, bubbles: true, cancelable: true }));
    } finally {
      view.setTimeout(() => view.removeEventListener("submit", block, true), 150);
    }
  }
  function key(element, name) {
    element.dispatchEvent(new KeyboardEvent("keydown", { key: name, code: name, bubbles: true, cancelable: true }));
  }
  function typeText(element, value, commit = true) {
    element.focus({ preventScroll: true });
    setNativeValue(element, value);
    element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertReplacementText", data: value }));
    if (!commit) return;
    element.dispatchEvent(new Event("change", { bubbles: true }));
    element.blur();
  }
  function listboxFor(anchor) {
    const doc = anchor.ownerDocument;
    const input = anchor instanceof HTMLInputElement ? anchor : anchor.querySelector("input");
    for (const node of [input, anchor]) {
      const id = node?.getAttribute("aria-controls") || node?.getAttribute("aria-owns");
      const list = id ? doc.getElementById(id.split(/\s+/)[0]) : null;
      if (list && rendered(list)) return list;
    }
    const near = comboboxShell(anchor).parentElement?.querySelector('[role="listbox"],[class*="select__menu" i],[class*="-menu" i]');
    if (near && rendered(near)) return near;
    const lists = [...doc.querySelectorAll('[role="listbox"]')].filter(rendered);
    return lists.length === 1 ? lists[0] : void 0;
  }
  function visibleOptions(anchor) {
    const list = listboxFor(anchor);
    if (!list) return [];
    let nodes = [...list.querySelectorAll('[role="option"]')];
    if (!nodes.length) nodes = [...list.querySelectorAll('[class*="__option" i],[class*="-option" i]')];
    return nodes.filter((node) => rendered(node) && node.getAttribute("aria-disabled") !== "true").map((node) => ({ label: clean(node.textContent ?? "", 300), node })).filter((option) => option.label).slice(0, 500);
  }
  async function waitForOptions(anchor, timeout, stableMs = 0) {
    const deadline = Date.now() + timeout;
    let last = "", since = Date.now(), options = [];
    while (Date.now() < deadline) {
      options = visibleOptions(anchor);
      const signature = options.map((option) => option.label).join("\n");
      if (signature !== last) {
        last = signature;
        since = Date.now();
      }
      if (options.length && Date.now() - since >= stableMs) return options;
      await wait(50);
    }
    return options;
  }
  async function chooseFromCombobox(unit, answer) {
    const anchor = unit.anchor;
    const input = anchor instanceof HTMLInputElement ? anchor : anchor.querySelector('input:not([type="hidden"])');
    const shell = anchor.matches(dropdownButton) ? anchor : comboboxShell(anchor);
    if (!safeToClick(anchor) || !safeToClick(shell)) return { ok: false, message: "This dropdown sits inside a submit button or link; choose it yourself." };
    const close = () => {
      const target = input ?? anchor;
      key(target, "Escape");
      if (input && input.value && !unit.occupied) typeText(input, "", false);
      input?.blur();
    };
    const name = unit.field.label;
    (input ?? anchor).focus({ preventScroll: true });
    click(shell === anchor ? anchor : shell);
    let options = await waitForOptions(anchor, 1200);
    note("combobox-open", `${name}: ${options.length} options after opening${listboxFor(anchor) ? "" : " (no listbox found)"}`);
    if (!options.length && input) {
      key(input, "ArrowDown");
      options = await waitForOptions(anchor, 800);
      note("combobox-arrow", `${name}: ${options.length} options after ArrowDown`);
    }
    let match = options.length ? matchChoice(answer, options.map((option) => ({ value: option.label, label: option.label }))) : { error: "none" };
    if ("error" in match && input) {
      typeText(input, answer, false);
      options = await waitForOptions(anchor, 3e3, 250);
      if (!options.length && isPrompt(input)) {
        guardedEnter(input);
        options = await waitForOptions(anchor, 3e3, 250);
        note("combobox-enter", `${name}: ${options.length} options after searching`);
      }
      note("combobox-search", `${name}: ${options.length} options after typing the answer`);
      match = options.length ? matchChoice(answer, options.map((option) => ({ value: option.label, label: option.label }))) : { error: "none" };
    }
    note("combobox-match", `${name}: ${"error" in match ? `${match.error}; first options: ${options.slice(0, 5).map((option) => option.label).join(" | ")}` : `matched by ${match.tier}`}`, !("error" in match));
    if ("error" in match) {
      const seen = options.map((option) => option.label).slice(0, 50);
      close();
      return { ok: false, message: match.error === "ambiguous" ? "Several listed options match this answer; choose one yourself." : "No listed option matched this answer; choose one yourself.", options: seen };
    }
    const chosen = options.find((option) => option.label === match.label);
    if (!safeToClick(chosen.node)) {
      close();
      return { ok: false, message: "The matching option is a link or submit control; choose it yourself." };
    }
    chosen.node.scrollIntoView?.({ block: "nearest" });
    click(chosen.node);
    await wait(120);
    const display = normalizeText(comboboxDisplay(anchor)), expected = normalizeText(chosen.label);
    note("combobox-verify", `${name}: ${display ? "selection displayed" : "nothing displayed"}${display && display !== expected && !display.includes(expected) ? " (different option)" : ""}`, !!display && (display === expected || display.includes(expected)));
    if (!display || display !== expected && !display.includes(expected)) {
      close();
      return { ok: false, message: "The site did not keep the selected option; choose it yourself.", options: options.map((option) => option.label).slice(0, 50) };
    }
    input?.blur();
    return { ok: true, display: chosen.label };
  }
  async function fillUnit(unit, value) {
    const anchor = unit.anchor;
    if (textKinds.has(unit.kind)) {
      const element = anchor;
      typeText(element, value);
      if (sameComparable(unit.field.type, value, element.value)) return { ok: true };
      element.focus({ preventScroll: true });
      element.select?.();
      if (element.ownerDocument.execCommand?.("insertText", false, value)) {
        element.dispatchEvent(new Event("change", { bubbles: true }));
        element.blur();
        await wait(80);
        if (sameComparable(unit.field.type, value, element.value) || element.value.replace(/\D/g, "") === value.replace(/\D/g, "") && /\d/.test(value)) {
          note("typed", `${unit.field.label}: typed`);
          return { ok: true };
        }
      }
      return { ok: false, message: "The site rejected or reformatted this value; check it on the page." };
    }
    if (unit.kind === "select") {
      const select = anchor;
      select.focus({ preventScroll: true });
      setNativeValue(select, value);
      select.dispatchEvent(new Event("input", { bubbles: true }));
      select.dispatchEvent(new Event("change", { bubbles: true }));
      select.blur();
      return select.value === value ? { ok: true } : { ok: false, message: "The site rejected this option; select it yourself." };
    }
    if (unit.kind === "combobox") return chooseFromCombobox(unit, value);
    if (unit.kind === "checkbox") {
      const box = anchor, wanted = value === "true";
      if (box.checked !== wanted) box.click();
      await wait(30);
      return box.checked === wanted ? { ok: true } : { ok: false, message: "The site did not keep this tick; set it yourself." };
    }
    const node = unit.optionNodes.get(value);
    if (!node) return { ok: false, message: "The approved option is no longer listed." };
    if (unit.kind === "radio") {
      if (!node.checked) node.click();
      return node.checked ? { ok: true } : { ok: false, message: "The site did not keep this choice; select it yourself." };
    }
    const before = `${node.getAttribute("aria-pressed")}|${node.getAttribute("aria-checked")}|${node.getAttribute("data-state")}|${node.className}`;
    const guarded = !safeToClick(node);
    if (guarded && !(node instanceof HTMLButtonElement && unit.kind === "yesno")) return { ok: false, message: "Chairman only clicks explicit non-submit option buttons; choose this yourself." };
    if (!pressed(node)) {
      if (guarded) guardedClick(node);
      else click(node);
    }
    await wait(60);
    const after = `${node.getAttribute("aria-pressed")}|${node.getAttribute("aria-checked")}|${node.getAttribute("data-state")}|${node.className}`;
    return pressed(node) || unit.kind === "yesno" && after !== before && ![...unit.optionNodes.values()].some((other) => other !== node && pressed(other)) ? { ok: true } : { ok: false, message: "The site did not confirm this choice; select it yourself." };
  }
  async function attachResume(unit, resume, bytes) {
    const input = unit.anchor;
    const transfer = new DataTransfer();
    transfer.items.add(new File([bytes], resume.filename, { type: resume.mime }));
    input.files = transfer.files;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    const attached = input.files?.[0];
    if (attached && attached.name === resume.filename && attached.size === bytes.length && await sha256(new Uint8Array(await attached.arrayBuffer())) === resume.sha256) return { ok: true };
    const name = resume.filename.toLowerCase();
    for (let waited = 0; waited < 6e3; waited += 250) {
      const places = [];
      for (let node = input.parentElement, depth = 0; node && depth < 5; node = node.parentElement, depth++) places.push(node);
      if (!input.isConnected) places.push(unit.container?.isConnected ? unit.container : input.ownerDocument.body);
      if (places.some((node) => (node.textContent ?? "").toLowerCase().includes(name))) {
        note("upload-listed", `${unit.field.label}: the site lists ${resume.filename}`);
        return { ok: true };
      }
      await wait(250);
    }
    return { ok: false, message: "The site did not retain the exact resume. Upload and verify it yourself." };
  }
  function describe(unit) {
    return JSON.stringify([unit.field.label, identityGroupOf(unit.kind), unit.field.type, unit.field.options, unit.field.optionLabels ?? null]);
  }
  function validationMessage(unit) {
    const members = unit.group.length ? unit.group : [unit.anchor];
    const native = members.find((member) => "validity" in member && !member.validity.valid && !member.validity.valueMissing);
    if (native) return clean(native.validationMessage || "The site reports an invalid value.", 300);
    const invalid = [unit.anchor, ...members].some((member) => member.getAttribute("aria-invalid") === "true");
    if (!invalid) return void 0;
    const doc = unit.anchor.ownerDocument;
    for (const id of `${unit.anchor.getAttribute("aria-errormessage") ?? ""} ${unit.anchor.getAttribute("aria-describedby") ?? ""}`.split(/\s+/).filter(Boolean)) {
      const node = doc.getElementById(id), text2 = node && rendered(node) ? clean(node.textContent ?? "", 300) : "";
      if (text2 && /error|invalid|required|please|must|enter|format|valid|only|digits?|characters?/i.test(text2)) return text2;
    }
    const near = unit.container?.querySelector('[role="alert"],[class*="error" i],[class*="invalid" i]');
    const text = near && rendered(near) ? clean(near.textContent ?? "", 300) : "";
    return text || "The site marked this answer as invalid.";
  }
  var SUBMIT_TEXT = /^(?:submit(?: (?:my |your |the )?application| now| form)?|send(?: (?:my |your )?application)?|finish(?: (?:and submit|application))?|complete(?: (?:my |your )?application)?|confirm (?:and|&) submit|submit (?:and|&) apply|apply(?: now)?)$/i;
  var NEXT_TEXT = /^(?:next(?: step| page)?|continue(?: to (?:the )?(?:next step|review))?|save (?:and|&) continue|save (?:and|&) next|proceed(?: to (?:the )?next step)?|review(?: (?:my |your )?application)?|go to review|next ?[›»→>])$/i;
  var APPLY_TEXT = /^(?:apply(?: now| for this (?:job|position|role)| (?:here|online)| to this (?:job|position|role))?|start (?:your |my |an? )?application|begin (?:your )?application|apply manually|i'?m interested|autofill with (?:my )?(?:resume|cv)|apply with (?:my )?(?:resume|cv)|upload (?:my |your )?(?:resume|cv)|use my last application)$/i;
  function startPreference(text) {
    return /^(?:autofill|apply) with (?:my )?(?:resume|cv)$|^upload (?:my |your )?(?:resume|cv)$/i.test(text) ? 3 : /^apply manually$/i.test(text) ? 2 : /^use my last application$/i.test(text) ? 1 : 0;
  }
  var WORKDAY_FORWARD = /^(?:bottom-navigation-next-button|pageFooterNextButton)$/i;
  var FINAL_WORDS = /\b(?:submit|apply|send|finish|complete|confirm|done|agree|accept)\b/i;
  var siteChrome = 'header,nav,[role="banner"],[role="navigation"],[role="search"]';
  function buttonText(element) {
    const text = element instanceof HTMLInputElement ? element.value : element.innerText || element.textContent || "";
    return clean(text || element.getAttribute("aria-label") || element.getAttribute("title") || "", 80);
  }
  function openDialog(doc) {
    return [...doc.querySelectorAll('[role="dialog"][aria-modal="true"],dialog[open],[role="alertdialog"],[data-automation-id="wd-Popup"],[data-automation-id*="popUp" i]')].find((dialog) => rendered(dialog) && !!dialog.querySelector('button,a[href],[role="button"]'));
  }
  function navigationCandidates(doc, fields) {
    const found = [];
    const dialog = openDialog(doc);
    for (const element of (dialog ?? doc).querySelectorAll('button,input[type="submit"],input[type="button"],a[href],[role="button"]')) {
      if (!rendered(element) || !dialog && element.closest(siteChrome) || !dialog && element.closest('[aria-hidden="true"],[inert]') || element.matches(":disabled") || element.getAttribute("aria-disabled") === "true") continue;
      const text = buttonText(element);
      if (!text || text.length > 60) continue;
      const forward = WORKDAY_FORWARD.test(element.getAttribute("data-automation-id") ?? "");
      const kind = forward ? NEXT_TEXT.test(text) || !(SUBMIT_TEXT.test(text) || APPLY_TEXT.test(text) || FINAL_WORDS.test(text)) ? "next" : "submit" : SUBMIT_TEXT.test(text) && !(APPLY_TEXT.test(text) && !fields) ? "submit" : NEXT_TEXT.test(text) ? "next" : APPLY_TEXT.test(text) ? fields ? "submit" : "apply" : void 0;
      if (kind) found.push({ element, kind, text });
    }
    return found;
  }
  function questionCount(doc) {
    try {
      return scanStructure(doc).units.length;
    } catch {
      return 100;
    }
  }
  function confirmationOf(doc, submitVisible) {
    if (submitVisible) return void 0;
    for (const element of doc.querySelectorAll('h1,h2,h3,[role="alert"],[role="status"],[aria-live],[class*="confirm" i],[class*="success" i],[class*="thank" i],[data-automation-id*="confirm" i],p')) {
      if (!rendered(element) || element.closest(siteChrome) || element.closest("label,legend")) continue;
      const text = clean(element.innerText || element.textContent || "", 400);
      if (text.length >= 8 && text.length <= 300 && CONFIRMATION_TEXT.test(text)) return text.slice(0, 240);
    }
    return void 0;
  }
  function inspectNavigation(doc) {
    const fields = questionCount(doc);
    const buttons = navigationCandidates(doc, fields);
    const pick = (kind) => {
      const all = buttons.filter((button) => button.kind === kind);
      const chosen = kind === "apply" ? all.reduce((best, button) => !best || startPreference(button.text) > startPreference(best.text) ? button : best, void 0) : all.at(-1);
      return chosen ? { kind, text: chosen.text } : void 0;
    };
    const next = pick("next"), submit = pick("submit"), apply = pick("apply");
    const password = [...doc.querySelectorAll('input[type="password"]')].some(rendered);
    const heading = clean([...doc.querySelectorAll("h1,h2,[role=heading]")].filter(rendered).slice(0, 3).map((element) => element.textContent ?? "").join(" | "), 300);
    const signIn = password || /\b(?:sign in|log in|create (?:an |your )?account|verify your (?:email|identity)|enter (?:the|your) (?:verification )?code)\b/i.test(heading) && fields <= 3 || /\/(?:login|signin|sign-in|createaccount|create-account|register)(?:\/|$)/i.test(doc.location.pathname);
    const errors = [...new Set([...doc.querySelectorAll('[role="alert"],[aria-live="assertive"],[data-automation-id="errorMessage"],[data-automation-id*="errorHeading" i],[class*="error-message" i],[class*="errorMessage" i],[class*="field-error" i],[class*="field_error" i]')].filter(rendered).map((element) => clean(element.innerText || element.textContent || "", 200)).filter((text) => text.length > 3 && new RegExp("\\p{L}{3}", "u").test(text) && !CONFIRMATION_TEXT.test(text)))].slice(0, 5);
    const invalid = [...doc.querySelectorAll('[aria-invalid="true"]')].filter(rendered).length;
    if (invalid && !errors.length) errors.push(`${invalid} answer${invalid === 1 ? " is" : "s are"} marked invalid on the page.`);
    const stepNode = [...doc.querySelectorAll('[data-automation-id="progressBarActiveStep"],[aria-current="step"],[class*="step" i][class*="active" i],[class*="current-step" i]')].find(rendered);
    const step = stepNode ? clean(stepNode.innerText || stepNode.textContent || "", 80) : void 0;
    const confirmation = confirmationOf(doc, !!submit);
    note("navigation", `fields ${fields}; next "${next?.text ?? ""}"; submit "${submit?.text ?? ""}"; apply "${apply?.text ?? ""}"; sign-in ${signIn}; step "${step ?? ""}"; ${errors.length} errors${confirmation ? "; confirmation page" : ""}`);
    return { ...next ? { next } : {}, ...submit ? { submit } : {}, ...apply ? { apply } : {}, signIn, ...confirmation ? { confirmation } : {}, errors, ...step ? { step } : {}, fields };
  }
  function advance(doc, which, expected) {
    const fields = questionCount(doc);
    const candidates = navigationCandidates(doc, fields).filter((button) => button.kind === which);
    const target = which === "apply" ? candidates.find((button) => normalizeText(button.text) === normalizeText(expected)) : candidates.at(-1);
    if (!target || normalizeText(target.text) !== normalizeText(expected)) throw new Error("The page's buttons changed. Look at the page again before continuing.");
    if (SUBMIT_TEXT.test(target.text) && !(which === "apply" && !fields)) throw new Error("That button submits the application; it is yours to press.");
    if (which === "next" && (APPLY_TEXT.test(target.text) || FINAL_WORDS.test(target.text))) throw new Error("That button finishes the application; it is yours to press.");
    const form = target.element instanceof HTMLButtonElement || target.element instanceof HTMLInputElement ? target.element.form : null;
    const sends = (target.element instanceof HTMLButtonElement || target.element instanceof HTMLInputElement) && target.element.type === "submit";
    if (which === "apply" && form && sends && [...form.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]),select,textarea')].length)
      throw new Error("That button sends a form; it is yours to press.");
    if (target.element instanceof HTMLAnchorElement) {
      const href = new URL(target.element.href, doc.baseURI);
      if (!/^https?:$/.test(href.protocol)) throw new Error("That link does not open a web page.");
      note("advance", `${which}: follow "${target.text}" in this tab`);
      return { clicked: target.text, href: href.href };
    }
    target.element.scrollIntoView?.({ block: "center" });
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup"]) mouse(target.element, type);
    target.element.click();
    note("advance", `${which}: pressed "${target.text}"`);
    return { clicked: target.text };
  }
  function readAnswers(doc, keys) {
    const wanted = new Set(keys.slice(0, 50));
    const answers = {};
    for (const unit of scanStructure(doc).units) {
      if (!wanted.has(unit.key) || unit.kind === "file" || unit.field.sensitivity) continue;
      const value = currentValue(unit);
      if (value.trim()) answers[unit.key] = value;
    }
    return answers;
  }
  var usedGrants = /* @__PURE__ */ new Set();
  async function fillAssistancePage(doc, grant, timing = {}) {
    if (!grant || typeof grant.id !== "string" || usedGrants.has(grant.id) || Date.now() >= grant.expiresAt || grant.expiresAt > Date.now() + 95e3)
      throw new Error("The page fill grant is expired or already used. Plan and authorize this page again.");
    if (doc.location.href !== grant.url) throw new Error("Navigation changed. Plan the current page first.");
    note("grant", `${Object.keys(grant.fields).length} fields${grant.resume ? " + resume" : ""}${grant.overwrite ? `, ${Object.keys(grant.overwrite).length} replacements` : ""}; expires in ${Math.round((grant.expiresAt - Date.now()) / 1e3)} s`);
    const page = await inspectAssistancePage(doc, { quietMs: timing.quietMs ?? 150, maxWaitMs: timing.maxWaitMs ?? 1500 });
    note("fingerprint-check", page.fingerprint === grant.pageFingerprint ? "page matches the reviewed plan" : `expected ${grant.pageFingerprint.slice(0, 12)}, found ${page.fingerprint.slice(0, 12)}`, page.fingerprint === grant.pageFingerprint);
    if (page.fingerprint !== grant.pageFingerprint) throw new Error("The page changed after review. Plan again before filling.");
    if (page.snapshot.hasCaptcha) throw new Error("A verification challenge is open. Complete it yourself, then plan again.");
    let structure = scanStructure(doc);
    const initial = new Map(structure.units.map((unit) => [unit.key, unit]));
    const overwrite = grant.overwrite ?? {};
    if (Object.keys(grant.fields).some((key2) => !initial.has(key2)) || Object.keys(overwrite).some((key2) => !Object.hasOwn(grant.fields, key2)) || grant.resume && initial.get(grant.resume.key)?.kind !== "file") throw new Error("The fill plan contains unknown fields.");
    for (const [key2, value] of Object.entries(grant.fields)) {
      const unit = initial.get(key2);
      if (typeof value !== "string" || value.length > 2e4 || unit.kind === "file") throw new Error("Unsupported fill value.");
      if (choiceKinds.has(unit.kind) && !unit.field.options.includes(value)) throw new Error("The exact approved option is unavailable.");
    }
    const bytes = grant.resume ? decodeResume(grant.resume) : void 0;
    if (grant.resume && (!bytes || await sha256(bytes) !== grant.resume.sha256)) throw new Error("Resume byte hash does not match the reviewed artifact.");
    usedGrants.add(grant.id);
    const result = { filled: [], preserved: [], skipped: [], errors: [], newFields: 0, blockers: [], selected: {} };
    const fresh = /* @__PURE__ */ new Set(), expected = /* @__PURE__ */ new Map();
    const order = structure.units.filter((unit) => Object.hasOwn(grant.fields, unit.key) || grant.resume?.key === unit.key);
    for (const planned of order) {
      if (doc.location.href !== grant.url || Date.now() >= grant.expiresAt) {
        result.blockers.push("Navigation or the fill deadline changed; review the remaining fields yourself.");
        break;
      }
      structure = scanStructure(doc);
      structure.units.forEach((unit2) => {
        if (!initial.has(unit2.key)) fresh.add(unit2.key);
      });
      const unit = structure.byKey.get(planned.key);
      if (!unit) {
        note("fill-skip", `${planned.field.label}: disappeared after an earlier answer`, false);
        result.skipped.push({ key: planned.key, reason: "The question disappeared after an earlier answer." });
        continue;
      }
      if (describe(unit) !== describe(planned)) {
        note("fill-skip", `${planned.field.label}: question or options changed`, false);
        result.skipped.push({ key: unit.key, reason: "The question or its options changed; plan again." });
        continue;
      }
      const resume = grant.resume?.key === unit.key;
      if (unit.occupied) {
        const previous = overwrite[unit.key];
        const replaceable = !resume && previous !== void 0 && await sha256(comparableValue(unit.field.type, currentValue(unit, true))) === previous;
        if (!replaceable) {
          note("fill-keep", `${unit.field.label}: already has a value; kept`);
          result.preserved.push(unit.key);
          continue;
        }
      }
      const fieldStarted = performance.now();
      let outcome;
      try {
        outcome = resume ? await attachResume(unit, grant.resume, bytes) : await fillUnit(unit, grant.fields[unit.key]);
      } catch (error) {
        outcome = { ok: false, message: error instanceof Error ? error.message : "Filling this control failed." };
      }
      note("fill", `${unit.field.label} [${unit.kind}]: ${outcome.ok ? "filled" : outcome.message} (${Math.round(performance.now() - fieldStarted)} ms)`, outcome.ok);
      if (outcome.ok) {
        result.filled.push(unit.key);
        if (!resume) expected.set(unit.key, outcome.display ?? grant.fields[unit.key]);
        if (outcome.display) result.selected[unit.key] = outcome.display;
      } else result.errors.push({ key: unit.key, message: outcome.message, ...outcome.options?.length ? { options: outcome.options } : {} });
      await settle(doc, timing.stepQuietMs ?? 60, 600);
    }
    await settle(doc, timing.finalQuietMs ?? 250, timing.finalMaxMs ?? 2e3);
    structure = scanStructure(doc);
    structure.units.forEach((unit) => {
      if (!initial.has(unit.key)) fresh.add(unit.key);
    });
    result.newFields = fresh.size;
    if (fresh.size) note("new-questions", structure.units.filter((unit) => fresh.has(unit.key)).map((unit) => unit.field.label).join(" | "));
    for (const key2 of [...result.filled]) {
      const unit = structure.byKey.get(key2), value = expected.get(key2);
      if (!unit || value === void 0) continue;
      const kept = unit.kind === "combobox" ? normalizeText(comboboxDisplay(unit.anchor)).includes(normalizeText(value)) : unit.kind === "select" || unit.kind === "radio" || unit.kind === "aria-radio" || unit.kind === "yesno" || unit.kind === "checkbox" ? currentValue(unit, true) === value : sameComparable(unit.field.type, value, currentValue(unit));
      if (!kept) {
        note("verify", `${unit.field.label}: the site changed or cleared the value`, false);
        result.filled = result.filled.filter((item) => item !== key2);
        delete result.selected[key2];
        result.errors.push({ key: key2, message: "The site changed or cleared this value after filling." });
        continue;
      }
      const message = validationMessage(unit);
      if (message) {
        note("site-validation", `${unit.field.label}: ${message}`, false);
        result.errors.push({ key: key2, message });
      }
    }
    note("fill-summary", `${result.filled.length} filled, ${result.preserved.length} kept, ${result.errors.length} errors, ${result.skipped.length} skipped, ${result.newFields} new`);
    for (const unit of structure.units)
      if (unit.field.required && !unit.occupied && !result.filled.includes(unit.key) && !result.errors.some((error) => error.key === unit.key)) result.blockers.push(`Required: ${unit.field.label}`);
    result.blockers.push(...structure.unsupported, ...structure.hasLegal ? ["Review consent, declarations and demographic questions yourself."] : []);
    if (result.newFields) result.blockers.push(`${result.newFields} new question${result.newFields === 1 ? "" : "s"} appeared after filling. Plan again to review ${result.newFields === 1 ? "it" : "them"}.`);
    result.blockers = [...new Set(result.blockers)];
    return result;
  }

  // apps/extension/assist-content.ts
  var state = globalThis;
  var controlCount = () => document.querySelectorAll('input,select,textarea,[role="combobox"],[role="radiogroup"],button[aria-haspopup="listbox"]').length;
  var connected = () => {
    try {
      return !!chrome.runtime?.id;
    } catch {
      return false;
    }
  };
  try {
    assistanceDestination(location.href);
    if (window.top === window && !state.__chairmanAssistInstalled) {
      state.__chairmanAssistInstalled = true;
      useTicker((milliseconds) => chrome.runtime.sendMessage({ channel: "chairman:tick", ms: milliseconds }).then(() => void 0));
      let busy = false, count = controlCount(), timer2;
      chrome.runtime.onMessage.addListener((message, sender, respond) => {
        if (sender.id !== chrome.runtime.id || sender.tab || !message || typeof message !== "object") return;
        const request = message;
        if (request.channel !== "chairman:page") return;
        if (busy) {
          respond({ ok: false, error: "Another page operation is running." });
          return;
        }
        busy = true;
        startTrace(request.debug === true);
        (async () => {
          if (request.action === "scan") return inspectAssistancePage(document);
          if (request.action === "fill" && request.grant) return fillAssistancePage(document, request.grant);
          if (request.action === "navigation") return inspectNavigation(document);
          if (request.action === "advance" && (request.which === "next" || request.which === "apply") && typeof request.expected === "string") return advance(document, request.which, request.expected);
          if (request.action === "read" && Array.isArray(request.keys)) return readAnswers(document, request.keys.filter((key2) => typeof key2 === "string"));
          throw new Error("Unsupported page action. Page scripts cannot command Chairman.");
        })().then((result) => respond({ ok: true, result, trace: takeTrace() }), (error) => respond({ ok: false, error: error instanceof Error ? error.message : "Page operation failed.", trace: takeTrace() })).finally(() => {
          busy = false;
          count = controlCount();
        });
        return true;
      });
      const observer = new MutationObserver(() => {
        if (!connected()) {
          observer.disconnect();
          clearTimeout(timer2);
          return;
        }
        if (busy) return;
        clearTimeout(timer2);
        timer2 = setTimeout(() => {
          const next = controlCount();
          if (next === count || busy) return;
          count = next;
          if (!connected()) {
            observer.disconnect();
            return;
          }
          try {
            chrome.runtime.sendMessage({ channel: "chairman:page-changed" }).catch(() => {
            });
          } catch {
            observer.disconnect();
          }
        }, 800);
      });
      observer.observe(document.documentElement, { childList: true, subtree: true });
      let answered;
      document.addEventListener("change", () => {
        if (busy) return;
        clearTimeout(answered);
        answered = setTimeout(() => {
          if (!connected()) return;
          try {
            chrome.runtime.sendMessage({ channel: "chairman:page-changed" }).catch(() => {
            });
          } catch {
          }
        }, 1500);
      }, true);
    }
  } catch {
  }
})();
