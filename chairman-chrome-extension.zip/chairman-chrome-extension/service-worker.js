// apps/extension/contracts.ts
var API_ORIGIN = "http://127.0.0.1:4318";

// apps/extension/safety.ts
var blockedDomains = ["linkedin.com", "lnkd.in", "wellfound.com", "angel.co", "naukri.com", "indeed.com", "indeed.jobs"];
function localApiOrigin(port = 4318) {
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error("Use a loopback service port between 1024 and 65535.");
  return `http://127.0.0.1:${port}`;
}
function destination(raw) {
  const url = new URL(raw);
  const host = url.hostname.toLowerCase().replace(/\.$/, "");
  if (blockedDomains.some((domain) => host === domain || host.endsWith(`.${domain}`)) || /(^|\.)indeed\.[a-z.]+$/.test(host)) {
    throw new Error("This site is manual-only. No extension inspection or automation is permitted.");
  }
  if (url.username || url.password || url.hash || host !== url.hostname) {
    throw new Error("Unsupported destination URL.");
  }
  if (url.protocol !== "https:" && !isFixture(raw)) {
    throw new Error("Only HTTPS destinations or the controlled local fixture are supported.");
  }
  if (url.protocol === "https:" && (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || !host.includes(".") || /^[\d.]+$/.test(host) || host.includes(":") || url.port !== "" && url.port !== "443")) throw new Error("Private or nonstandard destination hosts are unsupported.");
  return url;
}
function permissionFor(raw) {
  const url = destination(raw);
  return `${url.protocol}//${url.hostname}/*`;
}
function isFixture(raw) {
  const url = new URL(raw);
  return url.protocol === "http:" && url.hostname === "127.0.0.1" && Number(url.port) >= 1024 && url.pathname === "/fixture/application" && !url.hash && !url.username && !url.password;
}
function isFixtureReceipt(raw, approvedUrl) {
  if (!isFixture(approvedUrl)) return false;
  const url = new URL(raw);
  const approved = new URL(approvedUrl);
  const parameters = [...url.searchParams.entries()];
  return url.origin === approved.origin && url.pathname === "/fixture/confirmation" && !url.hash && !url.username && !url.password && parameters.length === 1 && parameters[0][0] === "id" && /^[A-Za-z0-9_-]{1,100}$/.test(parameters[0][1]);
}
function assertExactDestination(actual, expected) {
  const approved = destination(expected).href;
  if (!actual || actual !== approved) throw new Error("Activate the exact approved job page. Redirects and other tabs are not supported.");
}
function snapshotPayload(snapshot) {
  return JSON.stringify({
    url: snapshot.url,
    fields: snapshot.fields.map((field) => ({
      key: field.key,
      label: field.label,
      type: field.type,
      required: field.required,
      options: field.options
    })),
    hasCaptcha: snapshot.hasCaptcha,
    hasLegal: snapshot.hasLegal,
    unsupported: snapshot.unsupported
  });
}
async function fingerprint(snapshot) {
  const bytes = new TextEncoder().encode(snapshotPayload(snapshot));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
async function assertApprovedSnapshot(current, approved) {
  if (!approved || approved.fingerprint !== await fingerprint(approved) || current.fingerprint !== await fingerprint(current) || snapshotPayload(current) !== snapshotPayload(approved)) {
    throw new Error("The form changed or has not been approved. Run preflight and approve a new packet.");
  }
  if (current.hasCaptcha || current.hasLegal || current.unsupported.length) {
    throw new Error("This form needs manual review; CAPTCHA, declarations, or unsupported controls prevent automation.");
  }
}
function assertFillPlan(snapshot, fields, resume) {
  const keys = new Set(snapshot.fields.map((field) => field.key));
  if (keys.size !== snapshot.fields.length || Object.keys(fields).some((key) => !keys.has(key))) {
    throw new Error("The approved answer mapping does not match the form.");
  }
  let fileCount = 0;
  for (const field of snapshot.fields) {
    if (field.type === "file") {
      fileCount++;
      if (!/\b(resume|cv|curriculum vitae)\b/i.test(`${field.label} ${field.key}`) || Object.hasOwn(fields, field.key)) {
        throw new Error("Only one explicitly identified resume upload is supported.");
      }
      continue;
    }
    if (!Object.hasOwn(fields, field.key) || typeof fields[field.key] !== "string") {
      throw new Error(`A confirmed answer is required for: ${field.label || field.key}.`);
    }
    if (field.type === "select" && !field.options.includes(fields[field.key])) {
      throw new Error(`The approved option is not available for: ${field.label || field.key}.`);
    }
    if (!["text", "email", "tel", "url", "number", "date", "textarea", "select"].includes(field.type)) {
      throw new Error("An unsupported field cannot be filled.");
    }
  }
  if (fileCount !== 1) throw new Error("Exactly one resume file input is required.");
  decodeResume(resume);
}
function decodeResume(resume) {
  if (!resume || !["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"].includes(resume.mime) || typeof resume.filename !== "string" || !/^[^/\\\x00-\x1f]{1,150}\.(pdf|docx)$/i.test(resume.filename) || typeof resume.base64 !== "string" || resume.base64.length > 14e6 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(resume.base64)) {
    throw new Error("The approved resume is invalid or exceeds the 10 MB limit.");
  }
  const bytes = Uint8Array.from(atob(resume.base64), (char) => char.charCodeAt(0));
  if (!bytes.length || bytes.length > 1e7) throw new Error("The approved resume is empty or too large.");
  const pdf = resume.mime === "application/pdf";
  if (pdf ? !resume.filename.toLowerCase().endsWith(".pdf") || new TextDecoder().decode(bytes.slice(0, 5)) !== "%PDF-" : !resume.filename.toLowerCase().endsWith(".docx") || bytes[0] !== 80 || bytes[1] !== 75) {
    throw new Error("The resume content does not match its approved file type.");
  }
  return bytes;
}

// apps/extension/controller.ts
function recoveryReport(pending) {
  return pending.runToken ? {
    packetId: pending.packetId,
    runToken: pending.runToken,
    outcome: "submission_unknown",
    error: "The browser worker was interrupted. A prior action may have transmitted data; no automatic retry was made."
  } : void 0;
}
var ExtensionController = class {
  constructor(ports) {
    this.ports = ports;
  }
  busy = false;
  message = "Pair with the local service to load application packets.";
  async exclusive(operation) {
    if (this.busy) throw new Error("Another operation is active. Wait for its result.");
    this.busy = true;
    try {
      return await operation();
    } finally {
      this.busy = false;
    }
  }
  async recover() {
    return this.exclusive(() => this.recoverPending());
  }
  async recoverPending() {
    const pending = await this.ports.getPending();
    if (!pending) return;
    const report = recoveryReport(pending);
    if (!report) {
      if (await this.serverReconciled(pending)) return;
      this.message = "Claim interrupted before its receipt was stored. Reconcile the executing packet in the dashboard; never rerun it automatically.";
      return;
    }
    try {
      await this.ports.api("/api/extension/report", report);
      await this.ports.clearPending();
      this.message = "Interrupted execution recorded as unknown. Check the destination and dashboard manually.";
    } catch {
      if (await this.serverReconciled(pending)) return;
      this.message = "Interrupted execution is unresolved. Reconnect the local service to report it; no further execution is allowed.";
    }
  }
  async serverReconciled(pending) {
    try {
      const queue = await this.queue();
      const item = queue.items.find((entry) => entry.packet.id === pending.packetId);
      if (item && !["submission_unknown", "submitted_confirmed", "failed", "withdrawn_from_queue"].includes(item.packet.status)) return false;
      await this.ports.clearPending();
      this.message = "The interrupted packet is no longer executable in the server queue. Review its final state in the dashboard; no application was retried.";
      return true;
    } catch {
      return false;
    }
  }
  async state() {
    const paired = await this.ports.hasToken();
    return {
      paired,
      apiOrigin: await this.ports.apiOrigin?.() ?? API_ORIGIN,
      pending: await this.ports.getPending(),
      message: paired && this.message === "Pair with the local service to load application packets." ? "Connected locally. Open a permitted job and inspect its form before approving a packet." : this.message,
      ...paired ? { queue: await this.queue() } : {}
    };
  }
  async queue() {
    const result = await this.ports.api("/api/extension/jobs");
    if (!result || !Array.isArray(result.items) || result.items.length > 1e3 || typeof result.stopped !== "boolean") {
      throw new Error("The local service returned an invalid queue or missing Stop state.");
    }
    return result;
  }
  async permitted(packetId, status) {
    const queue = await this.queue();
    if (queue.stopped) throw new Error("The queue is stopped. Resume it in the dashboard before continuing.");
    const matches = queue.items.filter((item2) => item2.packet?.id === packetId);
    if (matches.length !== 1) throw new Error("The packet is unavailable or ambiguous. Refresh the dashboard.");
    const item = matches[0];
    if (item.automationAllowed !== true) throw new Error(item.reason || "This destination has not been permitted by the local service.");
    if (item.packet.jobId !== item.job.id || item.job.status !== "open" || item.job.aiPolicy === "prohibited" || status !== void 0 && item.job.aiPolicy !== "allowed" && !isFixture(item.job.applyUrl)) {
      throw new Error("The job or its AI policy no longer permits this operation.");
    }
    const target = destination(item.job.applyUrl);
    if (isFixture(item.job.applyUrl) && target.origin !== (await this.ports.apiOrigin?.() ?? API_ORIGIN)) {
      throw new Error("The controlled fixture must be hosted by the paired local service.");
    }
    if (status && item.packet.status !== status) throw new Error(`This operation requires a ${status} packet.`);
    return item;
  }
  async open(packetId) {
    await this.exclusive(async () => {
      const item = await this.permitted(packetId);
      await this.ports.open(destination(item.job.applyUrl).href);
      this.message = "Job opened. Complete login yourself, then run preflight on this exact page.";
    });
  }
  async preflight(packetId) {
    await this.exclusive(async () => {
      if (await this.ports.getPending()) throw new Error("Resolve the interrupted execution before inspecting another packet.");
      const item = await this.permitted(packetId);
      if (!["prepared", "approved"].includes(item.packet.status)) throw new Error("Only a prepared or approved packet can be inspected.");
      const url = destination(item.job.applyUrl).href;
      const tabId = await this.ports.activeTab(url);
      const documentId = await this.ports.inject(tabId, url);
      await this.permitted(packetId);
      await this.ports.activeTab(url, tabId);
      const { snapshot } = await this.ports.page(tabId, documentId, { action: "snapshot", url });
      if (!snapshot || snapshot.url !== url || snapshot.fingerprint !== await fingerprint(snapshot)) throw new Error("The page returned an invalid preflight snapshot.");
      await this.permitted(packetId);
      await this.ports.api("/api/extension/preflight", { packetId, snapshot });
      this.message = snapshot.hasCaptcha || snapshot.hasLegal || snapshot.unsupported.length ? "Preflight saved with blockers. Use the dashboard's manual checklist; nothing was filled or uploaded." : "Preflight attached. Review the exact packet and approve it in the dashboard before execution.";
    });
  }
  async execute(packetId) {
    await this.exclusive(async () => {
      if (await this.ports.getPending()) throw new Error("An interrupted execution must be reconciled first.");
      const approved = await this.permitted(packetId, "approved");
      const url = destination(approved.job.applyUrl).href;
      const tabId = await this.ports.activeTab(url);
      const documentId = await this.ports.inject(tabId, url);
      await this.permitted(packetId, "approved");
      await this.ports.activeTab(url, tabId);
      const { snapshot } = await this.ports.page(tabId, documentId, { action: "snapshot", url });
      if (!snapshot) throw new Error("No preflight snapshot was returned.");
      await assertApprovedSnapshot(snapshot, approved.packet.formSnapshot);
      assertExactDestination(snapshot.url, url);
      let pending = { packetId, tabId, url, phase: "claiming" };
      await this.ports.setPending(pending);
      let claim;
      let report;
      try {
        await this.permitted(packetId, "approved");
        await this.ports.activeTab(url, tabId);
        claim = await this.ports.api("/api/extension/claim", { packetId });
        if (!claim || typeof claim.runToken !== "string" || !claim.runToken || claim.runToken.length > 500) {
          throw new Error("The execution receipt is missing; reconcile this attempt in the dashboard.");
        }
        pending = { ...pending, phase: "claimed", runToken: claim.runToken };
        await this.ports.setPending(pending);
        if (claim.packet?.id !== packetId || claim.packet.status !== "executing" || claim.job?.id !== approved.job.id || claim.job.applyUrl !== approved.job.applyUrl || !approved.packet.approvalHash || claim.packet.approvalHash !== approved.packet.approvalHash) {
          throw new Error("The claimed packet is not the exact approved application.");
        }
        await assertApprovedSnapshot(snapshot, claim.packet.formSnapshot);
        assertFillPlan(snapshot, claim.fields, claim.resume);
        const bytes = decodeResume(claim.resume);
        const digest = [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map((byte) => byte.toString(16).padStart(2, "0")).join("");
        if (!approved.packet.artifacts.some((artifact) => artifact.filename === claim.resume.filename && artifact.sha256 === digest && artifact.bytes === bytes.length)) {
          throw new Error("The resume is not an exact approved artifact.");
        }
        const next = async (command) => {
          const live = await this.permitted(packetId, "executing");
          if (live.job.applyUrl !== approved.job.applyUrl || live.packet.approvalHash !== approved.packet.approvalHash) {
            throw new Error("The packet or destination changed during execution.");
          }
          await assertApprovedSnapshot(snapshot, live.packet.formSnapshot);
          await this.ports.activeTab(url, tabId);
          return this.ports.page(tabId, documentId, command);
        };
        const current = await next({ action: "snapshot", url });
        if (!current.snapshot) throw new Error("The current form is unavailable.");
        await assertApprovedSnapshot(current.snapshot, snapshot);
        for (const [key, value] of Object.entries(claim.fields)) {
          await next({ action: "fill", url, fingerprint: snapshot.fingerprint, key, value });
        }
        await next({ action: "attach", url, fingerprint: snapshot.fingerprint, resume: claim.resume });
        const verification = { url, fingerprint: snapshot.fingerprint, fields: claim.fields, resume: claim.resume };
        await next({ action: "verify", ...verification });
        pending = { ...pending, phase: "submitting" };
        await this.ports.setPending(pending);
        let confirmation;
        let submitIssued = false;
        try {
          const live = await this.permitted(packetId, "executing");
          if (live.job.applyUrl !== approved.job.applyUrl || live.packet.approvalHash !== approved.packet.approvalHash) {
            throw new Error("The packet or destination changed before submission.");
          }
          await assertApprovedSnapshot(snapshot, live.packet.formSnapshot);
          await this.ports.activeTab(url, tabId);
          submitIssued = true;
          confirmation = (await this.ports.page(tabId, documentId, { action: "submit", ...verification })).confirmation;
        } catch (error) {
          if (!submitIssued || !isFixture(url) || !this.ports.fixtureConfirmation) throw error;
        }
        if (!confirmation && submitIssued && isFixture(url)) {
          confirmation = await this.ports.fixtureConfirmation?.(tabId, url);
        }
        report = {
          packetId,
          runToken: claim.runToken,
          outcome: confirmation ? "submitted_confirmed" : "submission_unknown",
          ...confirmation ? { confirmation } : {
            error: "No trustworthy receipt was observed. Check the destination manually; do not retry automatically."
          }
        };
      } catch (error) {
        if (!pending.runToken) {
          this.message = "Claim outcome unknown. Reconcile the packet in the dashboard; automatic retry is blocked.";
          throw new Error(this.message);
        }
        report = {
          packetId,
          runToken: pending.runToken,
          outcome: pending.phase === "submitting" ? "submission_unknown" : "failed",
          error: error instanceof Error ? error.message : "Execution stopped unexpectedly."
        };
      }
      if (report) {
        await this.ports.api("/api/extension/report", report);
        await this.ports.clearPending();
        this.message = report.outcome === "submitted_confirmed" ? "The controlled fixture confirmed receipt. This is not a real employer submission." : `${report.outcome === "failed" ? "Paused" : "Submission outcome unknown"}: ${report.error}`;
      }
    });
  }
};

// apps/extension/receipt.ts
function readFixtureReceipt(approvedUrl, suppliedDocument) {
  const doc = suppliedDocument ?? document;
  const approved = new URL(approvedUrl);
  const current = new URL(doc.location.href);
  if (approved.protocol !== "http:" || approved.hostname !== "127.0.0.1" || Number(approved.port) < 1024 || approved.pathname !== "/fixture/application" || approved.username || approved.password || approved.hash || current.origin !== approved.origin || current.pathname !== "/fixture/confirmation" || current.hash || current.username || current.password || doc.defaultView?.top !== doc.defaultView) return void 0;
  const params = [...current.searchParams.entries()];
  if (params.length !== 1 || params[0][0] !== "id" || !/^[A-Za-z0-9_-]{1,100}$/.test(params[0][1])) return void 0;
  const markers = doc.querySelectorAll('main[data-jaa-submitted="true"][data-confirmation-id]');
  if (markers.length !== 1) return void 0;
  const marker = markers[0];
  const style = doc.defaultView.getComputedStyle(marker);
  if (marker.getAttribute("data-confirmation-id") !== params[0][1] || marker.closest('[hidden], [inert], [aria-hidden="true"]') || style.display === "none" || style.visibility === "hidden" || !marker.getClientRects().length) return void 0;
  return `Controlled fixture receipt: ${params[0][1]}`;
}

// packages/domain/assist-match.ts
function canonicalJson(value) {
  return JSON.stringify(sortKeys(value));
}
function sortKeys(value) {
  if (Array.isArray(value)) return value.map((item) => item === void 0 ? null : sortKeys(item));
  if (value && typeof value === "object") {
    const result = {};
    for (const key of Object.keys(value).sort()) {
      const item = value[key];
      if (item !== void 0) result[key] = sortKeys(item);
    }
    return result;
  }
  return value;
}
var isoCodes = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(" ");
var AUTOCOMPLETE_MEANINGS = Object.freeze({
  name: "name",
  "given-name": "first_name",
  "family-name": "last_name",
  email: "email",
  tel: "phone",
  "tel-national": "phone",
  "address-level2": "city",
  "country-name": "country",
  country: "country",
  "postal-code": "postal_code"
});

// packages/domain/extension-assist.ts
function pageDifference(before, after) {
  const changes = [];
  if (before.url !== after.url) changes.push("the URL changed");
  const left = new Map(before.snapshot.fields.map((field) => [field.key, field])), right = new Map(after.snapshot.fields.map((field) => [field.key, field]));
  for (const [key, field] of right) if (!left.has(key)) changes.push(`new question "${field.label}"`);
  for (const [key, field] of left) if (!right.has(key)) changes.push(`"${field.label}" disappeared`);
  for (const [key, field] of left) {
    const other = right.get(key);
    if (!other) continue;
    const kinds = [
      field.label !== other.label ? "label" : "",
      field.type !== other.type ? "type" : "",
      field.required !== other.required ? other.required ? "now required" : "no longer required" : "",
      canonicalJson([field.options, field.optionLabels ?? null]) !== canonicalJson([other.options, other.optionLabels ?? null]) ? "options" : "",
      canonicalJson([field.placeholder ?? null, field.pattern ?? null, field.maxLength ?? null, field.minLength ?? null, field.accept ?? null, field.autocomplete ?? null]) !== canonicalJson([other.placeholder ?? null, other.pattern ?? null, other.maxLength ?? null, other.minLength ?? null, other.accept ?? null, other.autocomplete ?? null]) ? "input rules" : ""
    ].filter(Boolean);
    if (kinds.length) changes.push(`"${other.label}" changed (${kinds.join(", ")})`);
  }
  if (before.snapshot.hasCaptcha !== after.snapshot.hasCaptcha) changes.push(after.snapshot.hasCaptcha ? "a CAPTCHA challenge opened" : "a CAPTCHA challenge closed");
  if (before.snapshot.hasLegal !== after.snapshot.hasLegal) changes.push("consent/declaration questions changed");
  if (canonicalJson(before.snapshot.unsupported) !== canonicalJson(after.snapshot.unsupported)) changes.push("manual-only questions changed");
  if (before.kind !== after.kind || before.job?.title !== after.job?.title || before.job?.company !== after.job?.company) changes.push("the job details changed");
  if (canonicalJson(before.embedded ?? null) !== canonicalJson(after.embedded ?? null)) changes.push("the embedded form changed");
  return changes.slice(0, 10).join("; ") || "the page structure changed";
}

// apps/extension/assist-safety.ts
function publicJobToken(url, key, value) {
  return key === "token" && /^\d{1,20}$/.test(value) && ["boards.greenhouse.io", "job-boards.greenhouse.io"].includes(url.hostname.toLowerCase()) && url.pathname === "/embed/job_app";
}
function assistanceDestination(raw) {
  const url = new URL(raw);
  const hash = url.hash;
  url.hash = "";
  destination(url.href);
  const host = url.hostname.toLowerCase();
  if (/(^|\.)indeed\.[a-z.]+$/.test(host) || host === "indeed.jobs" || host.endsWith(".indeed.jobs"))
    throw new Error("Indeed is manual-only; Chairman does not inspect or automate it.");
  if (/(?:^|\/)(?:login|signin|sign-in|auth|oauth|account|accounts|register|signup)(?:\/|$)/i.test(url.pathname))
    throw new Error("Account and sign-in pages are manual-only. Sign in yourself, then return to the public application.");
  if ([...url.searchParams.entries()].some(([key, value]) => /password|secret|token|code|session|auth|email/i.test(key) && !publicJobToken(url, key, value)))
    throw new Error("Pages with credential/session parameters cannot be inspected. Open the public job URL.");
  if (!isFixture(url.href) && /(^|\.)indeed\./.test(host)) throw new Error("This platform is manual-only.");
  url.hash = hash;
  return url;
}
function assistancePermission(raw) {
  const url = assistanceDestination(raw);
  return `${url.protocol}//${url.hostname}/*`;
}

// packages/domain/apply-start.ts
var WORKDAY_HOST = /\.myworkdayjobs\.com$|^wd\d{1,3}\.myworkdaysite\.com$/;
function applicationStartUrl(raw) {
  let url;
  try {
    url = new URL(raw);
  } catch {
    return raw;
  }
  const path = url.pathname.replace(/\/+$/, "");
  if (WORKDAY_HOST.test(url.hostname) && /\/job\//.test(path) && !/\/apply(?:\/|$)/.test(path)) {
    url.pathname = `${path}/apply/autofillWithResume`;
    url.hash = "";
    return url.href;
  }
  if (/^jobs(?:\.eu)?\.lever\.co$/.test(url.hostname) && /^\/[^/]+\/[0-9a-f-]{36}$/i.test(path)) {
    url.pathname = `${path}/apply`;
    return url.href;
  }
  if (url.hostname === "jobs.ashbyhq.com" && /^\/[^/]+\/[0-9a-f-]{36}$/i.test(path)) {
    url.pathname = `${path}/application`;
    return url.href;
  }
  return url.href;
}

// apps/extension/assist-worker.ts
var PENDING = "chairman.assistPending";
var SITES = "chairman.assistSites";
var VERBOSE = "chairman.debugVerbose";
var TABS = "chairman.tabs";
var SESSION = "chairman.session";
var INTRO = "Allow Chairman on this career site to plan answers for its application form. Visiting never fills or submits anything.";
var MAX_STEPS = 25;
var AI_SETTING = "chairman.assistAi";
var messageOf = (error) => error instanceof Error ? error.message : "The assistance operation failed.";
var pagePath = (raw) => {
  try {
    const url = new URL(raw ?? "");
    return `${url.origin}${url.pathname}`;
  } catch {
    return void 0;
  }
};
function installAssistanceWorker(api2, apiOrigin2, legacyBusy = () => false) {
  const debug = { verbose: false, runs: [] };
  const tabs = /* @__PURE__ */ new Map();
  let sites;
  let session, sessionWindow;
  let lastNotice = "", run, runStarted = 0, runs = 0, working = 0, opening = false;
  let queue = Promise.resolve();
  void chrome.storage.local.get(VERBOSE).then((value) => {
    debug.verbose = value[VERBOSE] === true;
  }).catch(() => void 0);
  const fresh = (id) => ({ id, view: { message: INTRO, busy: false, debug }, auto: false, session: false, stage: "manual", steps: 0, needs: [], scanning: false, lastPassive: 0, useAi: true });
  function tabOf(id) {
    let entry = tabs.get(id);
    if (!entry) {
      entry = fresh(id);
      tabs.set(id, entry);
    }
    return entry;
  }
  async function restore() {
    const saved = (await chrome.storage.session.get(TABS))[TABS];
    for (const [key, value] of Object.entries(saved ?? {})) {
      const entry = tabOf(Number(key));
      Object.assign(entry, {
        recordId: value.recordId,
        pending: value.pending,
        job: value.job,
        auto: value.auto === true,
        session: value.session === true,
        stage: value.stage ?? "manual",
        steps: value.steps ?? 0,
        needs: value.needs ?? [],
        lastAdvance: value.lastAdvance
      });
      entry.view.message = value.message || entry.view.message;
    }
    const kept = (await chrome.storage.session.get(SESSION))[SESSION];
    session = kept?.overview;
    sessionWindow = kept?.windowId;
  }
  const restored = restore().catch(() => void 0);
  async function persist() {
    const value = {};
    for (const [id, entry] of tabs) if (entry.recordId || entry.auto || entry.pending)
      value[id] = {
        recordId: entry.recordId,
        pending: entry.pending,
        job: entry.job,
        auto: entry.auto,
        session: entry.session,
        stage: entry.stage,
        steps: entry.steps,
        needs: entry.needs,
        lastAdvance: entry.lastAdvance,
        message: entry.view.message
      };
    await chrome.storage.session.set({ [TABS]: value });
    await chrome.storage.session.set({ [SESSION]: { overview: session, windowId: sessionWindow } });
  }
  function exclusive(work) {
    const next = queue.then(async () => {
      working++;
      try {
        return await work();
      } finally {
        working--;
      }
    });
    queue = next.catch(() => void 0);
    return next;
  }
  function begin(action) {
    run = { id: ++runs, action, at: (/* @__PURE__ */ new Date()).toISOString(), steps: [] };
    runStarted = Date.now();
    debug.runs = [run, ...debug.runs].slice(0, 6);
  }
  function step(source, name, detail = "", ok = true) {
    if (debug.verbose) (ok ? console.debug : console.warn)(`[Chairman ${source}] ${name}`, detail);
    if (!run || run.steps.length >= 500) return;
    run.steps.push({ t: Date.now() - runStarted, source, step: name, ...detail ? { detail: detail.slice(0, 600) } : {}, ...ok ? {} : { ok: false } });
  }
  function fail(name, error) {
    if (run && !run.failedAt) {
      run.failedAt = name;
      run.error = messageOf(error);
    }
  }
  function finish(entry, error) {
    if (!run) return;
    run.ms = Date.now() - runStarted;
    run.page = pagePath(entry?.view.page?.url ?? entry?.view.url);
    if (error && !run.failedAt) {
      run.failedAt = "action";
      run.error = messageOf(error);
    }
    run = void 0;
  }
  async function stage(name, work, describe) {
    const started = Date.now();
    try {
      const value = await work();
      step("worker", name, `${Date.now() - started} ms${describe ? ` \xB7 ${describe(value)}` : ""}`);
      return value;
    } catch (error) {
      step("worker", name, `${Date.now() - started} ms \xB7 ${messageOf(error)}`, false);
      fail(name, error);
      throw error;
    }
  }
  async function nonFatal(name, work) {
    const before = run ? { failedAt: run.failedAt, error: run.error } : void 0;
    try {
      await work();
      return true;
    } catch (error) {
      if (run && before) {
        run.failedAt = before.failedAt;
        run.error = before.error;
      }
      step("worker", name, `not critical: ${messageOf(error)}`, false);
      return false;
    }
  }
  async function service(name, path, body, describe) {
    return stage(name, async () => {
      const value = await api2(path, body);
      for (const entry of value?.debug ?? []) step("service", entry.step, entry.detail, entry.ok !== false);
      if (value && typeof value === "object" && "debug" in value) delete value.debug;
      return value;
    }, describe);
  }
  async function notice(entry, message) {
    if (entry) entry.view.message = message;
    await chrome.action.setBadgeText({ text: "!", ...entry?.auto ? { tabId: entry.id } : {} });
    await chrome.action.setBadgeBackgroundColor({ color: "#9b3b1c" });
    if (message !== lastNotice && await chrome.permissions.contains({ permissions: ["notifications"] })) {
      lastNotice = message;
      await chrome.notifications.create(entry?.auto ? `chairman-attention-${entry.id}` : "chairman-attention", {
        type: "basic",
        iconUrl: chrome.runtime.getURL("icon.png"),
        title: "Chairman needs your attention",
        message: entry?.auto ? "One of your application tabs is waiting for you. Open the Chairman side panel to see which." : "Open the Chairman side panel to review the current step. No application submission is implied."
      });
    }
  }
  async function tabContext(passive = false, id) {
    const tab = id === void 0 ? (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0] : await chrome.tabs.get?.(id).catch(() => void 0);
    if (!tab?.id) throw new Error(id === void 0 ? "Open a job application tab, then click the Chairman extension icon." : "This application tab was closed.");
    if (!tab.url) throw new Error("Chairman can't see this tab yet. Click the Chairman icon in Chrome's toolbar while this tab is open, then choose Allow when Chrome asks.");
    tabOf(tab.id).view.url = tab.url;
    const url = assistanceDestination(tab.url).href, permission = assistancePermission(url);
    if (!await chrome.permissions.contains({ origins: [permission] })) throw new Error("Chairman is not allowed on this site yet. Use Allow on this site; this never grants Submit permission.");
    const allowed = (await chrome.storage.local.get(SITES))[SITES];
    if (passive && id === void 0 && !allowed?.includes(permission)) throw new Error("This site has not been allowed for inspection.");
    if (tab.status !== "complete") throw new Error("Wait for the current page to finish loading.");
    return { id: tab.id, url };
  }
  async function exact(entry, url) {
    const current = await tabContext(true, entry.auto ? entry.id : void 0);
    if (current.id !== entry.id || current.url !== url) throw new Error("The active page changed. Return to the application page and plan again.");
  }
  async function inject(entry, url) {
    await exact(entry, url);
    const results = await chrome.scripting.executeScript({ target: { tabId: entry.id, frameIds: [0] }, files: ["assist-content.js"], world: "ISOLATED" });
    const documentId = results.find((result) => result.frameId === 0)?.documentId;
    if (!documentId) throw new Error("The top-level application document is unavailable.");
    await exact(entry, url);
    return documentId;
  }
  async function page(entry, documentId, url, action, extra = {}) {
    await exact(entry, url);
    let timer;
    try {
      const response = await Promise.race([
        chrome.tabs.sendMessage(entry.id, { channel: "chairman:page", action, debug: debug.verbose, ...extra }, { documentId }),
        // Chrome gives background tabs little CPU time, so a tab Chairman works through in the background gets longer.
        new Promise((_, reject) => {
          timer = setTimeout(() => reject(new Error("The page stopped responding. Inspect the actual page; do not assume data was sent.")), action === "fill" ? 95e3 : entry.auto ? 45e3 : 2e4);
        })
      ]);
      for (const item of response?.trace ?? []) step("page", item.step, item.detail, item.ok !== false);
      if (!response?.ok) throw new Error(response?.error || "The page disconnected.");
      return response.result;
    } finally {
      clearTimeout(timer);
    }
  }
  function planIsCurrent(entry) {
    const view = entry.view;
    return !!view.plan && !!view.page && view.plan.url === view.page.url && view.plan.pageFingerprint === view.page.fingerprint;
  }
  async function scan(entry, passive = false) {
    if (entry?.scanning || passive && (entry?.view.busy || working > 0)) return entry;
    let target = entry;
    try {
      const tab = passive ? await tabContext(true, entry?.auto ? entry.id : void 0) : await stage("tab", () => tabContext(true, entry?.auto ? entry.id : void 0), (value) => pagePath(value.url) ?? "");
      target = tabOf(tab.id);
      if (target.scanning) return target;
      target.scanning = true;
      const documentId = passive ? await inject(target, tab.url) : await stage("inject", () => inject(target, tab.url));
      const result = passive ? await page(target, documentId, tab.url, "scan") : await stage(
        "page-scan",
        () => page(target, documentId, tab.url, "scan"),
        (value) => `${value.snapshot.fields.length} questions, ${value.occupied.length} with values, kind ${value.kind}${value.embedded ? `, embedded ${value.embedded.host}` : ""}`
      );
      await exact(target, tab.url);
      const view = target.view;
      view.page = result;
      const questions = result.snapshot.fields.length;
      if (!target.auto || target.stage === "manual") view.message = planIsCurrent(target) ? "Your reviewed plan still matches this page." : result.embedded ? `The application form is embedded from ${result.embedded.host}. Open it directly to fill it.` : questions ? `${questions} application question${questions === 1 ? "" : "s"} found. Plan answers when you are ready; nothing is sent until then.` : result.job ? `${result.job.title}: job description captured. Open the application form (Apply) to fill it.` : "No application questions on this page yet. Open the application form, then plan answers.";
      if (!target.auto) await chrome.action.setBadgeText({ text: questions ? String(Math.min(questions, 99)) : result.job ? "JD" : "" });
      if (!target.auto && target.recordId && view.result) await watchOutcome(target, documentId, tab.url).catch(() => void 0);
      return target;
    } catch (error) {
      if (target) target.view.page = void 0;
      if (passive) {
        if (target) target.view.message = messageOf(error);
        if (!target?.auto) await chrome.action.setBadgeText({ text: "" });
        return target;
      }
      throw error;
    } finally {
      if (target) target.scanning = false;
    }
  }
  async function plan(entry, ai) {
    const target = await scan(entry) ?? entry;
    const view = target.view;
    if (!view.page) throw new Error("Open an application page first.");
    target.useAi = ai;
    const questions = view.page.snapshot.fields.length;
    view.activity = ai && questions ? "Planning answers; questions without a saved answer may be sent to your configured AI\u2026" : "Planning answers\u2026";
    try {
      const next = await service(
        "service-plan",
        "/api/extension/assist/plan",
        {
          ...target.recordId ? { id: target.recordId } : {},
          page: view.page,
          ai,
          ...target.auto && target.job ? { jobId: target.job.jobId } : {}
        },
        (value) => `${value.items.filter((item) => item.include && item.value !== void 0).length} ready of ${value.items.length}; AI asked ${value.ai.asked}, reused ${value.ai.cached}${value.ai.reason ? `; ${value.ai.reason}` : ""}`
      );
      delete next.debug;
      view.plan = next;
      await refreshSites();
      target.recordId = next.recordId;
      await persist();
      const ready = next.items.filter((item) => item.include && item.value !== void 0).length, resume = next.resume?.selected ? " and a resume" : "";
      const needs = next.items.filter((item) => item.source === "manual" && item.required && !/^Already answered/.test(item.reason ?? "")).length;
      view.message = ready || resume ? `${ready} answer${ready === 1 ? "" : "s"}${resume} ready to review${needs ? `; ${needs} question${needs === 1 ? "" : "s"} need you` : ""}. Check them, then fill.` : needs ? `${needs} question${needs === 1 ? "" : "s"} need your answer. Type them in the plan or on the page.` : "Nothing to fill on this page. Existing answers are kept.";
    } finally {
      view.activity = void 0;
    }
  }
  async function reviewed(entry) {
    if (!entry.recordId || !entry.view.page) throw new Error("Plan or import this job first.");
    const review = await service("service-review", "/api/extension/assist/review", { id: entry.recordId, page: entry.view.page });
    entry.view.review = review;
    return review;
  }
  async function recover(entry) {
    const legacy = (await chrome.storage.session.get(PENDING))[PENDING];
    const pending = entry.pending ?? legacy;
    if (!pending) {
      step("worker", "recover", "no interrupted fill");
      return;
    }
    await service("service-recover", "/api/extension/assist/recover", pending);
    entry.pending = void 0;
    if (legacy) await chrome.storage.session.remove(PENDING);
    await persist();
  }
  async function fillReviewed(entry, reviewedPlan, expected, include, edits, resume, remember) {
    const view = entry.view;
    const tab = await stage("tab", () => tabContext(true, entry.auto ? entry.id : void 0), (value) => pagePath(value.url) ?? "");
    const documentId = await stage("inject", () => inject(entry, tab.url));
    const current = await stage("page-rescan", () => page(entry, documentId, tab.url, "scan"), (value) => `${value.snapshot.fields.length} questions`);
    await stage("compare-page", async () => {
      if (current.fingerprint === expected.fingerprint && reviewedPlan.pageFingerprint === current.fingerprint) return;
      const difference = pageDifference(expected, current);
      view.page = current;
      view.plan = void 0;
      throw new Error(`The page changed after you reviewed the plan (${difference}). Plan answers again before filling.`);
    }, () => "page matches the reviewed plan");
    await exact(entry, tab.url);
    view.activity = "Filling this page\u2026";
    const grant = await service(
      "service-grant",
      "/api/extension/assist/grant",
      {
        id: reviewedPlan.recordId,
        page: current,
        planHash: reviewedPlan.planHash,
        include,
        edits,
        resume,
        confirm: true
      },
      (value) => `${Object.keys(value.fields).length} fields${value.resume ? " + resume" : ""}`
    );
    entry.pending = { id: reviewedPlan.recordId, grantId: grant.id };
    await persist();
    let result;
    try {
      result = await stage(
        "page-fill",
        () => page(entry, documentId, tab.url, "fill", { grant }),
        (value) => `${value.filled.length} filled, ${value.preserved.length} kept, ${value.errors.length} errors, ${value.skipped.length} skipped, ${value.newFields} new`
      );
    } catch (error) {
      result = { filled: [], preserved: [], skipped: [], errors: [], newFields: 0, blockers: [messageOf(error), "Inspect actual fields yourself before any further action."] };
    }
    const reported = await service("service-report", "/api/extension/assist/report", {
      id: reviewedPlan.recordId,
      grantId: grant.id,
      filled: result.filled,
      preserved: result.preserved,
      skipped: result.skipped,
      errors: result.errors,
      newFields: result.newFields,
      blockers: result.blockers,
      selected: result.selected ?? {}
    }, (value) => `status ${value.record.status}, ${value.repairs.length} fixes`);
    entry.pending = void 0;
    await persist();
    const label = (key) => reviewedPlan.items.find((item) => item.key === key)?.label ?? (key === reviewedPlan.resume?.key ? "Resume" : key);
    let remembered = 0, rememberError = "";
    const items = remember.map((key) => ({ key, value: edits[key] ?? reviewedPlan.items.find((item) => item.key === key)?.value ?? "" })).filter((item) => item.value.trim() && result.filled.includes(item.key));
    if (items.length) {
      await nonFatal("remember", async () => {
        try {
          remembered = (await service("service-remember", "/api/extension/assist/remember", { id: reviewedPlan.recordId, page: current, items, confirm: true })).remembered;
        } catch (error) {
          rememberError = ` Answers were not remembered: ${messageOf(error)}`;
          throw error;
        }
      });
    }
    view.result = {
      url: tab.url,
      at: (/* @__PURE__ */ new Date()).toISOString(),
      filled: result.filled.length,
      preserved: result.preserved.length,
      errors: result.errors.map((error) => ({ label: label(error.key), message: error.message })),
      skipped: result.skipped.map((item) => ({ label: label(item.key), reason: item.reason })),
      newFields: result.newFields,
      repairs: reported.repairs.length,
      remembered,
      blockers: result.blockers
    };
    view.activity = "Checking the page after filling\u2026";
    if (!await nonFatal("replan-after-fill", () => plan(entry, entry.useAi))) {
      view.plan = void 0;
      await nonFatal("rescan-after-fill", () => scan(entry));
    }
    view.message = `Filled ${result.filled.length}; kept ${result.preserved.length} existing answer${result.preserved.length === 1 ? "" : "s"}.` + (result.errors.length ? ` ${result.errors.length} need${result.errors.length === 1 ? "s" : ""} attention${reported.repairs.length ? "; suggested fixes are in the refreshed plan" : ""}.` : "") + (result.newFields ? ` ${result.newFields} new question${result.newFields === 1 ? "" : "s"} appeared.` : "") + (entry.auto ? "" : " Review the page, click Next or Submit yourself, then plan again on the next page. Filled is not applied.") + rememberError;
    view.activity = void 0;
    if (!entry.auto && (result.errors.length || result.skipped.length || result.blockers.length)) await notice(entry, view.message);
    return view.result;
  }
  async function quickFill(entry, ai) {
    await plan(entry, ai);
    const view = entry.view;
    let filled = 0, passes = 0, drafted = 0;
    const errors = [];
    while (view.plan && view.page && passes < 3) {
      const current = view.plan;
      const include = current.items.filter((item) => item.include && item.value !== void 0).map((item) => item.key);
      const resume = current.resume?.selected ?? null;
      if (!include.length && !resume) break;
      passes++;
      step("worker", "quick-fill", `pass ${passes}: ${include.length} answers${resume ? " + resume" : ""}`);
      drafted += current.items.filter((item) => include.includes(item.key) && item.source.startsWith("ai_")).length;
      const result = await fillReviewed(entry, current, view.page, include, {}, resume, []);
      filled += result.filled;
      errors.push(...result.errors);
      if (!result.newFields) break;
    }
    const needs = view.plan?.items.filter((item) => item.source === "manual" && item.required && !/^Already answered/.test(item.reason ?? "")) ?? [];
    if (!entry.auto) view.message = !passes ? `Nothing could be filled automatically${needs.length ? `; ${needs.length} required question${needs.length === 1 ? "" : "s"} need you (below)` : ""}. Answer on the page, then click Submit yourself.` : `Filled ${filled} answer${filled === 1 ? "" : "s"} in one pass${passes > 1 ? ` (+${passes - 1} for questions that appeared)` : ""}.` + (drafted ? ` ${drafted} ${drafted === 1 ? "is an AI suggestion" : "are AI suggestions"} from your facts: read ${drafted === 1 ? "it" : "them"} before submitting.` : "") + (errors.length ? ` ${errors.length} need${errors.length === 1 ? "s" : ""} attention: ${errors.slice(0, 3).map((item) => item.label).join("; ")}.` : "") + (needs.length ? ` ${needs.length} required question${needs.length === 1 ? "" : "s"} need you: ${needs.slice(0, 3).map((item) => item.label).join("; ")}.` : "") + " Check the page, solve any CAPTCHA, then click Submit yourself.";
    return { filled, drafted, errors };
  }
  let sitesAskedAt = 0;
  async function refreshSites(force = false) {
    if (!force && Date.now() - sitesAskedAt < 10 * 6e4) return;
    sitesAskedAt = Date.now();
    try {
      const { origins } = await api2("/api/extension/assist/sites", {});
      const granted = new Set((await chrome.permissions.getAll()).origins ?? []);
      sites = { origins, missing: origins.filter((origin) => !granted.has(origin)), at: Date.now() };
    } catch {
    }
  }
  function adopt(result) {
    const current = result.session;
    if (!current) {
      session = void 0;
      return;
    }
    const count = (state) => current.counts[state] ?? 0;
    session = {
      id: current.id,
      number: current.number,
      status: current.status,
      size: current.size,
      finished: current.finished,
      open: current.open,
      queued: count("queued"),
      submitted: count("submitted"),
      available: result.available,
      tabs: [...tabs.values()].filter((entry) => entry.session && entry.job && current.items.some((item) => item.jobId === entry.job.jobId)).map((entry) => ({ tabId: entry.id, jobId: entry.job.jobId, company: entry.job.company, title: entry.job.title, stage: entry.stage, message: entry.view.message }))
    };
  }
  function overview() {
    if (!session) return void 0;
    return { ...session, tabs: [...tabs.values()].filter((entry) => entry.session && entry.job).map((entry) => ({ tabId: entry.id, jobId: entry.job.jobId, company: entry.job.company, title: entry.job.title, stage: entry.stage, message: entry.view.message })) };
  }
  async function progress(entry, state, detail) {
    if (!entry.job && !entry.recordId) return;
    try {
      const result = entry.recordId && ["working", "needs_you", "review"].includes(state) ? await api2("/api/extension/assist/stage", { id: entry.recordId, stage: state, detail: detail.slice(0, 300) }).then(() => void 0) : entry.session && entry.job ? await api2("/api/extension/assist/session/progress", { jobId: entry.job.jobId, state, detail: detail.slice(0, 300) }) : void 0;
      if (result) adopt(result);
    } catch (error) {
      step("worker", "session-progress", messageOf(error), false);
    }
  }
  async function settle(entry, stageName, message) {
    entry.slow = 0;
    const changed = entry.stage !== stageName || entry.view.message !== message;
    entry.stage = stageName;
    entry.view.message = message;
    await persist();
    if (!changed) return;
    if (stageName === "needs_you" || stageName === "review") {
      await chrome.action.setBadgeText({ tabId: entry.id, text: stageName === "review" ? "\u2713" : "!" }).catch(() => void 0);
      await notice(entry, message).catch(() => void 0);
    } else await chrome.action.setBadgeText({ tabId: entry.id, text: stageName === "submitted" ? "" : "\u2026" }).catch(() => void 0);
    if (stageName === "working" || stageName === "needs_you" || stageName === "review") await progress(entry, stageName, message);
    if (stageName === "review") watchReview(entry);
  }
  async function openNext() {
    if (opening) return 0;
    opening = true;
    try {
      const result = await api2("/api/extension/assist/session/next", {});
      const anyActive = (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
      let first = !(anyActive?.id !== void 0 && tabs.get(anyActive.id)?.auto);
      const opened = [];
      for (const item of result.open) {
        const where = sessionWindow !== void 0 ? { windowId: sessionWindow } : {};
        const created = await chrome.tabs.create({ url: item.startUrl, active: first, ...where }).catch(() => chrome.tabs.create({ url: item.startUrl, active: first }));
        if (!created?.id) continue;
        await keep(created.id);
        const entry = tabOf(created.id);
        Object.assign(entry, { auto: true, session: true, stage: "working", steps: 0, needs: [], job: { jobId: item.jobId, company: item.company, title: item.title }, recordId: void 0, lastAdvance: void 0, started: item.startUrl });
        entry.view.message = `Opening ${item.company}: ${item.title}. Sign in or complete a check if the site asks; Chairman fills the application and stops before Submit.`;
        opened.push(created.id);
        first = false;
      }
      if (opened.length && chrome.tabs.group) {
        try {
          const groupId = await chrome.tabs.group({ tabIds: opened, ...sessionWindow !== void 0 ? { createProperties: { windowId: sessionWindow } } : {} });
          await chrome.tabGroups?.update(groupId, { title: `Chairman \xB7 session ${result.session?.number ?? ""}`.trim(), color: "green" });
        } catch {
        }
      }
      adopt(result);
      await persist();
      return opened.length;
    } finally {
      opening = false;
    }
  }
  async function reportOutcome(entry, url, text) {
    if (!entry.recordId) {
      if (!entry.job) return;
      try {
        const planned = await api2("/api/extension/assist/plan", { page: entry.view.page, ai: false, jobId: entry.job.jobId });
        entry.recordId = planned.recordId;
      } catch {
        return;
      }
    }
    await service("service-outcome", "/api/extension/assist/outcome", { id: entry.recordId, url, text });
    await settle(entry, "submitted", `Applied \u2713 The employer's page confirmed it: "${text.slice(0, 120)}". You can close this tab.`);
    if (entry.session) await openNext().catch(() => 0);
  }
  async function watchOutcome(entry, documentId, url) {
    const navigation = await page(entry, documentId, url, "navigation");
    if (!navigation?.confirmation) return false;
    await reportOutcome(entry, url, navigation.confirmation);
    return true;
  }
  async function learn(entry, documentId, url) {
    if (!entry.needs.length || !entry.recordId || !entry.view.page) return;
    const typed = await page(entry, documentId, url, "read", { keys: entry.needs });
    const current = await page(entry, documentId, url, "scan");
    let remembered = 0;
    for (const [key, value] of Object.entries(typed ?? {})) {
      try {
        remembered += (await api2("/api/extension/assist/remember", { id: entry.recordId, page: current, items: [{ key, value }], confirm: true })).remembered;
      } catch {
      }
    }
    if (remembered) step("worker", "learn", `remembered ${remembered} answer${remembered === 1 ? "" : "s"} you typed`);
    entry.needs = [];
  }
  async function drive(entry) {
    if (!entry.auto || entry.stage === "paused" || entry.stage === "submitted" || !tabs.has(entry.id)) return;
    if (entry.lastAdvance && Date.now() - entry.lastAdvance.at < 1500) {
      schedule(entry, 1500);
      return;
    }
    begin(`session-step \xB7 ${entry.job?.company ?? "role"}`);
    try {
      const tab = await chrome.tabs.get?.(entry.id).catch(() => void 0);
      if (!tab?.url || tab.status !== "complete") return;
      let url;
      try {
        url = assistanceDestination(tab.url).href;
      } catch {
        await settle(entry, "needs_you", "Sign in or finish this step in the tab (Chairman does not read sign-in or account pages). It continues on the application form.");
        return;
      }
      if (!await chrome.permissions.contains({ origins: [assistancePermission(url)] })) {
        await settle(entry, "needs_you", `Allow Chairman on ${new URL(url).hostname}: click the Chairman icon in Chrome's toolbar while this tab is open. It continues right after.`);
        return;
      }
      const documentId = await stage("inject", () => inject(entry, url));
      const navigation = await stage(
        "navigation",
        () => page(entry, documentId, url, "navigation"),
        (value) => `next "${value.next?.text ?? ""}", submit "${value.submit?.text ?? ""}", apply "${value.apply?.text ?? ""}", sign-in ${value.signIn}, ${value.fields} fields`
      );
      if (navigation.confirmation) {
        await reportOutcome(entry, url, navigation.confirmation);
        return;
      }
      if (entry.stage === "review") {
        watchReview(entry);
        return;
      }
      if (navigation.signIn) {
        await settle(entry, "needs_you", "Sign in or create your account in this tab. Chairman continues when the application form appears.");
        return;
      }
      let scanned;
      try {
        scanned = await stage("page-scan", () => page(entry, documentId, url, "scan"), (value) => `${value.snapshot.fields.length} questions`);
      } catch (error) {
        const reason = messageOf(error);
        await settle(entry, "needs_you", /credential/i.test(reason) ? "Sign in in this tab. Chairman continues on the application form." : reason);
        return;
      }
      entry.view.page = scanned;
      if (scanned.snapshot.hasCaptcha) {
        await settle(entry, "needs_you", "Complete the verification check in this tab. Chairman continues right after.");
        return;
      }
      if (entry.steps >= MAX_STEPS) {
        await settle(entry, "needs_you", "Chairman has taken many steps in this application; continue it yourself.");
        return;
      }
      const openStart = !!navigation.apply && startChoice(navigation.apply.text);
      const startPage = !!navigation.apply && !navigation.submit && !navigation.next && (!!scanned.job || openStart);
      if (!scanned.snapshot.fields.length || startPage) {
        if (navigation.submit && !navigation.next) {
          await settle(entry, "review", `Ready for your review${navigation.step ? ` (${navigation.step})` : ""}: check the answers (use the form's Back button for earlier steps), then press "${navigation.submit.text}" yourself. Chairman records the confirmation page.`);
          return;
        }
        if (scanned.job && !entry.job) await nonFatal("record-job", async () => {
          const recorded = await service(
            "service-record-job",
            "/api/extension/assist/plan",
            { ...entry.recordId ? { id: entry.recordId } : {}, page: scanned, ai: false },
            (value) => `application ${value.recordId.slice(0, 8)}`
          );
          entry.recordId = recorded.recordId;
          await persist();
        });
        const direct = applicationStartUrl(url);
        if (direct !== url && entry.started !== direct) {
          entry.started = direct;
          entry.steps++;
          await chrome.tabs.update(entry.id, { url: direct });
          await settle(entry, "working", new URL(direct).pathname.endsWith("/autofillWithResume") ? "Opening the application with Autofill with Resume. Sign in or create your account if Workday asks; Chairman uploads your resume and continues." : "Opening the application form\u2026");
          return;
        }
        if (navigation.apply && (scanned.job || !navigation.next || openStart)) {
          const pressed2 = await stage("advance-apply", () => page(entry, documentId, url, "advance", { which: "apply", expected: navigation.apply.text }));
          entry.steps++;
          if (pressed2.href) {
            try {
              assistanceDestination(pressed2.href);
              await chrome.tabs.update(entry.id, { url: pressed2.href });
            } catch {
              await settle(entry, "needs_you", `Open the application yourself ("${pressed2.clicked}"); Chairman continues on its form.`);
              return;
            }
          }
          await settle(entry, "working", `Pressed "${pressed2.clicked}". Sign in if the site asks; Chairman continues on the form.`);
          schedule(entry, 4e3);
          return;
        }
        if (navigation.next && !navigation.submit) {
          const key = `${scanned.fingerprint}|${navigation.step ?? ""}`;
          const repeated2 = entry.lastAdvance && entry.lastAdvance.fingerprint === key && Date.now() - entry.lastAdvance.at < 12e4;
          if (repeated2 && (navigation.errors.length || entry.lastAdvance.repeats >= 1)) {
            await settle(entry, "needs_you", `The site did not move past this step${navigation.errors.length ? `: ${navigation.errors.slice(0, 2).join(" \xB7 ")}` : ""}. Fix it in the tab, then press "${navigation.next.text}" or Continue below.`);
            return;
          }
          const pressed2 = await stage("advance-next", () => page(entry, documentId, url, "advance", { which: "next", expected: navigation.next.text }));
          entry.steps++;
          entry.lastAdvance = { fingerprint: key, text: pressed2.clicked, at: Date.now(), repeats: repeated2 ? entry.lastAdvance.repeats + 1 : 0 };
          const moved2 = await waitForChange(entry, documentId, url, scanned.fingerprint);
          await settle(entry, "working", `Pressed "${pressed2.clicked}".`);
          schedule(entry, moved2 ? 800 : 2500);
          return;
        }
        if (scanned.embedded && await chrome.permissions.contains({ origins: [assistancePermission(scanned.embedded.url)] })) {
          entry.steps++;
          await chrome.tabs.update(entry.id, { url: scanned.embedded.url });
          await settle(entry, "working", `Opening the application form on ${scanned.embedded.host}\u2026`);
          return;
        }
        await settle(entry, "needs_you", "Open the application form in this tab; Chairman continues there.");
        return;
      }
      entry.view.activity = "Filling this step\u2026";
      const withResume = !!scanned.snapshot.fields.some((field) => field.type === "file");
      const filled = await quickFill(entry, entry.useAi);
      entry.view.activity = void 0;
      if (withResume && filled.filled) await new Promise((resolveWait) => setTimeout(resolveWait, 2500));
      const view = entry.view;
      const waiting = (view.plan?.items ?? []).filter((item) => item.required && item.source === "manual" && !/^Already answered/.test(item.reason ?? "") && !view.page?.occupied.includes(item.key));
      if (waiting.length) {
        entry.needs = waiting.map((item) => item.key);
        await settle(entry, "needs_you", `Answer ${waiting.length} question${waiting.length === 1 ? "" : "s"} in this tab or below: ${waiting.slice(0, 3).map((item) => item.label).join("; ")}${waiting.length > 3 ? "; \u2026" : ""}. Chairman remembers your answers and continues.`);
        return;
      }
      const after = await stage(
        "navigation-after-fill",
        () => page(entry, documentId, url, "navigation"),
        (value) => `next "${value.next?.text ?? ""}", submit "${value.submit?.text ?? ""}", ${value.errors.length} errors`
      );
      const finalStep = !!after.submit && !after.next || /(?:^|[^a-z])review\b/i.test(after.step ?? "");
      if (finalStep) {
        await settle(entry, "review", `Ready for your review${after.step ? ` (${after.step})` : ""}: check every answer${filled.drafted ? `, especially the ${filled.drafted} AI-written one${filled.drafted === 1 ? "" : "s"}` : ""}, then click ${after.submit ? `"${after.submit.text}"` : "Submit"} yourself. Chairman records the confirmation page.`);
        return;
      }
      if (!after.next) {
        await settle(entry, "needs_you", "Chairman can't find this step's Next button. Continue to the next step yourself; it picks up from there.");
        return;
      }
      const fingerprint2 = view.page?.fingerprint ?? "";
      const repeated = entry.lastAdvance && entry.lastAdvance.fingerprint === fingerprint2 && Date.now() - entry.lastAdvance.at < 12e4;
      if (repeated && (after.errors.length || entry.lastAdvance.repeats >= 1)) {
        await settle(entry, "needs_you", `The site did not move past this step${after.errors.length ? `: ${after.errors.slice(0, 2).join(" \xB7 ")}` : ""}. Fix it in the tab, then press "${after.next.text}" or Continue below.`);
        return;
      }
      await nonFatal("learn", () => learn(entry, documentId, url));
      const pressed = await stage("advance-next", () => page(entry, documentId, url, "advance", { which: "next", expected: after.next.text }));
      entry.steps++;
      entry.lastAdvance = { fingerprint: fingerprint2, text: pressed.clicked, at: Date.now(), repeats: repeated ? entry.lastAdvance.repeats + 1 : 0 };
      const moved = await stage("wait-for-next-step", () => waitForChange(entry, documentId, url, fingerprint2), (value) => value ? "the step changed" : "the page did not change");
      await settle(entry, "working", `Step ${entry.steps}: filled ${filled.filled} answer${filled.filled === 1 ? "" : "s"} and pressed "${pressed.clicked}".`);
      schedule(entry, moved ? 800 : 2500);
    } catch (error) {
      fail("session-step", error);
      if (tabs.has(entry.id) && /The page stopped responding/.test(messageOf(error)) && !entry.pending && (entry.slow ?? 0) < 3) {
        entry.slow = (entry.slow ?? 0) + 1;
        entry.view.message = "Waiting for this tab's page to respond (Chrome runs background tabs slowly)\u2026";
        schedule(entry, 4e3 * entry.slow);
      } else if (tabs.has(entry.id)) await settle(entry, "needs_you", `${messageOf(error)} Continue in the tab, or press Continue below to let Chairman try again.`).catch(() => void 0);
    } finally {
      entry.view.activity = void 0;
      finish(entry);
    }
  }
  const keep = (tabId) => chrome.tabs.update(tabId, { autoDiscardable: false }).then(() => void 0, () => void 0);
  const startChoice = (text) => /^(?:autofill|apply) with (?:my )?(?:resume|cv)$|^upload (?:my |your )?(?:resume|cv)$|^apply manually$|^use my last application$/i.test(text.trim());
  async function waitForChange(entry, documentId, url, fingerprint2, timeout = 1e4) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 700));
      try {
        const current = await page(entry, documentId, url, "scan");
        if (current.fingerprint !== fingerprint2) return true;
      } catch {
        return true;
      }
    }
    return false;
  }
  function watchReview(entry) {
    clearTimeout(entry.timer);
    entry.timer = setTimeout(() => {
      void exclusive(async () => {
        if (entry.stage !== "review" || !tabs.has(entry.id)) return;
        try {
          const tab = await chrome.tabs.get?.(entry.id).catch(() => void 0);
          if (tab?.url && tab.status === "complete") {
            const url = assistanceDestination(tab.url).href;
            if (await chrome.permissions.contains({ origins: [assistancePermission(url)] })) {
              const documentId = await inject(entry, url);
              if (await watchOutcome(entry, documentId, url)) return;
            }
          }
        } catch {
        }
        if (entry.stage === "review" && tabs.has(entry.id)) watchReview(entry);
      }).catch(() => void 0);
    }, 4e3);
  }
  function schedule(entry, delay) {
    if (!entry.auto) return;
    clearTimeout(entry.timer);
    entry.timer = setTimeout(() => {
      void exclusive(() => drive(entry)).catch(() => void 0);
    }, delay);
  }
  chrome.tabs.onActivated.addListener((activated) => {
    void restored.then(() => {
      const entry = tabs.get(activated.tabId);
      if (entry?.auto) {
        if (entry.stage === "needs_you") schedule(entry, 400);
        return;
      }
      return scan(entry, true);
    }).catch(() => void 0);
  });
  chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
    void restored.then(() => {
      const entry = tabs.get(tabId);
      if (entry?.auto) {
        if (change.status === "complete" || change.url) schedule(entry, change.status === "complete" ? 900 : 2e3);
        return;
      }
      if (tab.active && (change.status === "complete" || change.url)) return scan(tabOf(tabId), true);
    }).catch(() => void 0);
  });
  chrome.tabs.onRemoved?.addListener((tabId) => {
    void restored.then(async () => {
      const entry = tabs.get(tabId);
      tabs.delete(tabId);
      if (entry?.session && entry.job && entry.stage !== "submitted") {
        await api2("/api/extension/assist/session/progress", { jobId: entry.job.jobId, state: "closed", detail: "You closed the tab without submitting." }).then(adopt).catch(() => void 0);
        await openNext().catch(() => 0);
      }
      await persist();
    }).catch(() => void 0);
  });
  async function allowSite(permission) {
    const allowed = (await chrome.storage.local.get(SITES))[SITES];
    if (!allowed?.includes(permission)) await chrome.storage.local.set({ [SITES]: [.../* @__PURE__ */ new Set([...allowed ?? [], permission])] });
  }
  chrome.action.onClicked.addListener((tab) => {
    if (tab.windowId !== void 0) chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => void 0);
    let permission;
    try {
      permission = tab.url ? assistancePermission(tab.url) : void 0;
    } catch {
      permission = void 0;
    }
    if (!permission) return;
    const origin = permission;
    chrome.permissions.request({ origins: [origin] }).then(async (granted) => {
      const entry = tab.id !== void 0 ? tabOf(tab.id) : void 0;
      if (!granted) {
        if (entry) entry.view.message = "Site access was not granted. Nothing was inspected or filled.";
        return;
      }
      await allowSite(origin);
      if (entry?.auto) {
        schedule(entry, 200);
        return;
      }
      if (entry) entry.view.message = `Chairman can read ${origin.slice(8, -2)}. Plan answers when you are ready.`;
      await scan(entry, true);
    }).catch(() => {
      if (tab.id !== void 0) tabOf(tab.id).view.message = "Click Allow on this site to let Chrome ask for access to this page.";
    });
  });
  chrome.permissions.onAdded.addListener((permissions) => {
    const origins = (permissions.origins ?? []).filter((origin) => /^https:\/\/[^*/]+\/\*$/.test(origin));
    if (!origins.length) return;
    void chrome.storage.local.get(SITES).then(async (value) => {
      const allowed = value[SITES];
      await chrome.storage.local.set({ [SITES]: [.../* @__PURE__ */ new Set([...allowed ?? [], ...origins])] });
      for (const entry2 of tabs.values()) if (entry2.auto && entry2.stage === "needs_you") schedule(entry2, 300);
      const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      const entry = active?.id !== void 0 ? tabOf(active.id) : void 0;
      if (entry && !entry.auto) {
        entry.view.message = `Chairman can now read ${origins.map((origin) => origin.slice(8, -2)).join(", ")}. Plan answers when you are ready.`;
        await scan(entry, true);
      }
    }).catch(() => void 0);
  });
  chrome.permissions.onRemoved.addListener(() => {
    for (const entry of tabs.values()) {
      entry.view.page = void 0;
      entry.view.plan = void 0;
      entry.view.review = void 0;
      entry.view.message = "Permissions changed. Allow and inspect the current site again.";
    }
  });
  chrome.runtime.onMessage.addListener((message, sender) => {
    if (sender.id !== chrome.runtime.id || !sender.tab?.id || sender.frameId !== 0 || !message || typeof message !== "object" || message.channel !== "chairman:page-changed") return;
    const tabId = sender.tab.id;
    void restored.then(async () => {
      const entry = tabs.get(tabId);
      if (entry?.auto) {
        if (entry.stage !== "paused" && entry.stage !== "submitted") schedule(entry, 1200);
        return;
      }
      const target = tabOf(tabId);
      if (Date.now() - target.lastPassive < 1500) return;
      target.lastPassive = Date.now();
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab?.id === tabId) await scan(target, true);
    }).catch(() => void 0);
  });
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || sender.tab || sender.url !== chrome.runtime.getURL("sidepanel.html") || !message || typeof message !== "object") return;
    const request = message;
    if (request.channel !== "chairman:panel") return;
    let entry;
    const current = async () => {
      await restored;
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      entry = tab?.id !== void 0 ? tabOf(tab.id) : entry ?? fresh(-1);
      return entry;
    };
    const reply = (target) => ({ state: {
      ...target.view,
      busy: target.view.busy || working > 0,
      sites,
      session: overview(),
      ...target.auto ? { tab: {
        jobId: target.job?.jobId ?? "",
        company: target.job?.company ?? target.view.page?.job?.company ?? "",
        title: target.job?.title ?? target.view.page?.job?.title ?? target.view.page?.title ?? "this application",
        stage: target.stage,
        steps: target.steps,
        needs: target.needs,
        session: target.session
      } } : {}
    } });
    (async () => {
      const target = await current();
      if (request.action === "state") return reply(target);
      if (request.action === "sites-allowed") {
        await refreshSites(true);
        await scan(target, true).catch(() => void 0);
        return reply(target);
      }
      if (request.action === "debug") {
        debug.verbose = request.verbose === true;
        await chrome.storage.local.set({ [VERBOSE]: debug.verbose });
        return reply(target);
      }
      if (request.action === "debug-clear") {
        debug.runs = [];
        return reply(target);
      }
      if (request.action === "go-to-tab" && typeof request.tabId === "number" && tabs.get(request.tabId)?.auto) {
        await chrome.tabs.update(request.tabId, { active: true });
        return reply(tabs.get(request.tabId));
      }
      if (legacyBusy()) throw new Error("Another extension action is running.");
      if (target.view.busy) throw new Error("Chairman is already working on this tab.");
      target.view.busy = true;
      try {
        return await exclusive(async () => {
          begin(request.action ?? "unknown");
          try {
            const result = await panelAction(target, request);
            return result ?? reply(target);
          } catch (error) {
            step("worker", "error", messageOf(error), false);
            finish(target, error);
            throw error;
          } finally {
            finish(target);
          }
        });
      } finally {
        target.view.busy = false;
        target.view.activity = void 0;
      }
    })().then((result) => respond({ ok: true, ...result }), (error) => {
      const target = entry;
      void notice(target && !target.auto ? target : void 0, messageOf(error)).catch(() => {
        if (target) target.view.message = messageOf(error);
      });
      respond({ ok: false, error: messageOf(error), ...target ? reply(target) : {} });
    });
    return true;
  });
  async function panelAction(target, request) {
    const view = target.view;
    if (request.action === "home") {
      await chrome.tabs.create({ url: `${await apiOrigin2()}/#today` });
      return void 0;
    }
    if (request.action === "session-start") {
      sessionWindow = request.windowId ?? sessionWindow;
      const started = await service("service-session-start", "/api/extension/assist/session/start", {});
      adopt(started);
      await refreshSites(true);
      const opened = await stage("open-tabs", () => openNext(), (value) => `${value} tabs opened`);
      view.message = opened ? `Session ${session?.number ?? ""} started: ${opened} tab${opened === 1 ? "" : "s"} opened. Sign in or solve checks where asked; Chairman fills each application and stops before Submit.` : session?.open ? "Your session's tabs are already open." : "No roles to open. Rebuild today's list in the dashboard.";
      return void 0;
    }
    if (request.action === "session-next") {
      const opened = await openNext();
      view.message = opened ? `Opened ${opened} more role${opened === 1 ? "" : "s"}.` : "No more tabs can open yet: 10 are open, or the session is finished.";
      return void 0;
    }
    if (request.action === "session-stop") {
      adopt(await service("service-session-stop", "/api/extension/assist/session/stop", {}));
      for (const entry of tabs.values()) if (entry.auto && entry.stage !== "submitted") {
        entry.stage = "paused";
        entry.view.message = "Session stopped. This tab is yours to finish or close.";
      }
      await persist();
      view.message = "Session stopped. Open tabs stay open; nothing more is filled automatically.";
      return void 0;
    }
    if (request.action === "tab-continue") {
      if (!target.auto) throw new Error("Chairman is not driving this tab. Use Fill everything to start.");
      if (target.stage === "submitted") throw new Error("This role is already applied.");
      target.stage = "working";
      target.lastAdvance = void 0;
      view.message = "Continuing\u2026";
      await persist();
      await drive(target);
      return void 0;
    }
    if (request.action === "tab-pause") {
      if (!target.auto) throw new Error("Chairman is not driving this tab.");
      await settle(target, "paused", "Paused. Chairman does nothing more here until you press Continue.");
      return void 0;
    }
    if (request.action === "tab-skip") {
      if (!target.session || !target.job) throw new Error("Only roles in your application session can be skipped here; close this tab instead.");
      target.stage = "paused";
      await api2("/api/extension/assist/session/progress", { jobId: target.job.jobId, state: "skipped", detail: "You skipped it in the side panel." }).then(adopt);
      view.message = "Skipped. It will not be opened again in this session; close the tab when you like.";
      await persist();
      await openNext().catch(() => 0);
      return void 0;
    }
    if (request.action === "authorize") {
      const tab = await stage("tab", () => tabContext(), (value) => pagePath(value.url) ?? "");
      if (request.url !== tab.url) throw new Error("The tab changed during the permission request. Allow the current page again.");
      const permission = assistancePermission(tab.url);
      await allowSite(permission);
      step("worker", "site-allowed", permission);
      await scan(target);
      return void 0;
    }
    if (request.action === "scan") {
      await scan(target);
      return void 0;
    }
    if (request.action === "recover") {
      await recover(target);
      await scan(target);
      view.message = "Interrupted fill marked for manual review. Inspect the actual page.";
      return void 0;
    }
    if (request.action === "open-embedded") {
      const embedded = view.page?.embedded, tab = await stage("tab", () => tabContext());
      if (!embedded || view.page?.url !== tab.url) throw new Error("Rescan the page first.");
      if (!await chrome.permissions.contains({ origins: [assistancePermission(embedded.url)] })) throw new Error(`Allow Chairman on ${embedded.host} first.`);
      await allowSite(assistancePermission(embedded.url));
      await chrome.tabs.update(tab.id, { url: embedded.url });
      step("worker", "open-embedded", embedded.host);
      view.page = void 0;
      view.plan = void 0;
      view.message = `Opening the form on ${embedded.host}. Plan answers once it has loaded.`;
      return void 0;
    }
    if (target.pending || (await chrome.storage.session.get(PENDING))[PENDING]) throw new Error("An interrupted fill needs reconciliation. Use Reconcile fill under More.");
    if (request.action === "plan") {
      await plan(target, request.ai !== false);
      return void 0;
    }
    if (request.action === "fill") {
      const reviewedPlan = view.plan, expected = view.page;
      if (!reviewedPlan || !expected || request.confirm !== true || request.planHash !== reviewedPlan.planHash || !Array.isArray(request.include))
        throw new Error("Review the plan and confirm it before filling.");
      step("worker", "request", `${request.include.length} rows selected, ${Object.keys(request.edits ?? {}).length} edited, resume ${request.resume ? request.resume.split(":")[0] : "none"}, remember ${request.remember?.length ?? 0}`);
      await fillReviewed(target, reviewedPlan, expected, request.include, request.edits ?? {}, request.resume ?? null, request.remember ?? []);
      if (target.auto && target.stage === "needs_you") {
        target.stage = "working";
        schedule(target, 800);
      }
      return void 0;
    }
    if (request.action === "quick-fill") {
      if (request.drive === true) {
        Object.assign(target, { auto: true, stage: "working", steps: 0, needs: [], lastAdvance: void 0, started: void 0, slow: 0, useAi: request.ai !== false });
        await keep(target.id);
        view.message = "Working through this application: filling each step and pressing Next. It stops before Submit for your review.";
        await persist();
        schedule(target, 50);
        return void 0;
      }
      await quickFill(target, request.ai !== false);
      return void 0;
    }
    if (request.action === "import") {
      if (!view.page || request.confirm !== true) throw new Error("Explicitly review and confirm this captured job before import.");
      const review = await service("service-import", "/api/extension/assist/import", { page: view.page, company: request.company || void 0, confirm: true });
      target.recordId = review.record.id;
      await persist();
      await reviewed(target);
      view.message = "Job imported. Select a baseline, then prepare and review a job-specific resume.";
    } else if (request.action === "review") {
      if (request.confirm !== true) throw new Error("Confirm this page belongs to the same job.");
      await reviewed(target);
      view.message = "Review the tailored resume options for this job.";
    } else if (request.action === "prepare" || request.action === "edit") {
      if (!view.review || !view.page || request.confirm !== true) throw new Error("Import and review the job first.");
      const id = view.review.record.id;
      view.activity = "Preparing the job-specific resume\u2026";
      try {
        await service(`service-${request.action}`, `/api/extension/assist/${request.action}`, {
          id,
          page: view.page,
          confirm: true,
          ...request.action === "prepare" ? { variantId: request.variantId, mode: request.mode } : { factIds: request.factIds, skills: request.skills }
        });
      } finally {
        view.activity = void 0;
      }
      await reviewed(target);
      if (view.plan && !await nonFatal("replan-with-new-resume", () => plan(target, target.useAi))) view.plan = void 0;
      view.message = "New immutable PDF/DOCX ready. It is now offered as the resume to attach in the plan.";
    } else if (request.action === "artifact") {
      if (!view.review || !["pdf", "docx"].includes(request.format ?? "")) throw new Error("Choose a prepared PDF or DOCX.");
      return { artifact: await service("service-artifact", "/api/extension/assist/artifact", { id: view.review.record.id, format: request.format }) };
    } else if (request.action === "queue" || request.action === "receipt") {
      const id = view.review?.record.id ?? view.plan?.recordId;
      if (!id || request.confirm !== true) throw new Error("Plan or review the tracked job first.");
      await service(`service-${request.action}`, `/api/extension/assist/${request.action}`, {
        id,
        confirm: true,
        ...request.action === "receipt" ? { confirmation: request.confirmation, submittedDate: request.submittedDate } : {}
      });
      if (view.review) await nonFatal("refresh-review", () => reviewed(target));
      view.message = request.action === "receipt" ? "Your explicit submission receipt is recorded." : "Sent to the separate local runner for evaluation under its own authorization. Chrome has not submitted.";
    } else throw new Error("Unknown assistance action.");
    return void 0;
  }
  chrome.runtime.onMessageExternal?.addListener((message, sender, respond) => {
    (async () => {
      await restored;
      const origin = await apiOrigin2();
      if (sender.origin !== origin || !message || typeof message !== "object" || message.channel !== "chairman:session")
        throw new Error("Only your paired Chairman dashboard can start a session.");
      const action = message.action;
      if (action === "status") return { ok: true, session: overview() };
      if (action === "open-job") {
        const jobId = message.jobId;
        if (typeof jobId !== "string" || !jobId || jobId.length > 300) throw new Error("Unknown role.");
        const item = await api2("/api/extension/assist/job-start", { jobId });
        assistanceDestination(item.startUrl);
        const where = sender.tab?.windowId !== void 0 ? { windowId: sender.tab.windowId } : {};
        const created = await chrome.tabs.create({ url: item.startUrl, active: true, ...where });
        if (created.id === void 0) throw new Error("Chrome did not open the tab.");
        await keep(created.id);
        const entry = tabOf(created.id);
        const ai = (await chrome.storage.local.get(AI_SETTING))[AI_SETTING] !== false;
        Object.assign(entry, {
          auto: true,
          session: false,
          stage: "working",
          steps: 0,
          needs: [],
          job: { jobId: item.jobId, company: item.company, title: item.title },
          recordId: void 0,
          lastAdvance: void 0,
          started: item.startUrl,
          useAi: ai
        });
        entry.view.message = `Opening ${item.company}: ${item.title}. Sign in or complete a check if the site asks; Chairman fills each step and stops before Submit.`;
        await persist();
        if (sender.tab?.windowId !== void 0) chrome.sidePanel.open?.({ windowId: sender.tab.windowId }).catch(() => void 0);
        return { ok: true, opened: 1 };
      }
      if (action !== "open") throw new Error("Unknown session request.");
      if (sender.tab?.windowId !== void 0) sessionWindow = sender.tab.windowId;
      await refreshSites(true);
      const opened = await openNext();
      if (sender.tab?.windowId !== void 0) chrome.sidePanel.open?.({ windowId: sender.tab.windowId }).catch(() => void 0);
      return { ok: true, opened, missingSites: sites?.missing.length ?? 0, session: overview() };
    })().then(respond, (error) => respond({ ok: false, error: messageOf(error) }));
    return true;
  });
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || !sender.tab || !message || typeof message !== "object" || message.channel !== "chairman:tick") return;
    const milliseconds = Math.min(Math.max(Number(message.ms) || 0, 0), 2e3);
    setTimeout(() => respond({ ok: true }), milliseconds);
    return true;
  });
  return { busy: () => working > 0 };
}

// apps/extension/service-worker.ts
var TOKEN = "jaa.token";
var PENDING2 = "jaa.pending";
var PORT = "jaa.port";
var sessionReady = chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
sessionReady.catch(() => {
});
async function token() {
  await sessionReady;
  const value = (await chrome.storage.session.get(TOKEN))[TOKEN];
  if (typeof value !== "string" || !value) throw new Error("Pair the extension with the local service first.");
  return value;
}
async function apiOrigin() {
  await sessionReady;
  const port = (await chrome.storage.session.get(PORT))[PORT];
  return localApiOrigin(typeof port === "number" ? port : 4318);
}
async function api(path, body) {
  const bearer = await token();
  const origin = await apiOrigin();
  let response;
  try {
    response = await fetch(`${origin}${path}`, {
      method: body === void 0 ? "GET" : "POST",
      headers: { Authorization: `Bearer ${bearer}`, ...body === void 0 ? {} : { "Content-Type": "application/json" } },
      ...body === void 0 ? {} : { body: JSON.stringify(body) },
      credentials: "omit",
      redirect: "error",
      cache: "no-store",
      referrerPolicy: "no-referrer",
      signal: AbortSignal.timeout(/^\/api\/extension\/assist\/(?:prepare|edit|plan|report)$/.test(path) ? 15e4 : /^\/api\/extension\/assist\/grant$/.test(path) ? 3e4 : 1e4)
    });
  } catch {
    throw new Error(`The local service is unavailable or timed out. Keep it running on ${origin}.`);
  }
  if (!response.ok) {
    const detail = response.headers.get("content-type")?.includes("application/json") ? await response.json() : void 0;
    const error = detail && typeof detail === "object" && "error" in detail && typeof detail.error === "string" ? detail.error.replace(/[\u0000-\u001f\u007f]/g, " ").slice(0, 1800) : `Local service rejected this operation (HTTP ${response.status}).`;
    throw new Error(error);
  }
  if (!response.headers.get("content-type")?.includes("application/json")) throw new Error("The local service did not return JSON.");
  return response.json();
}
async function activeTab(url, tabId) {
  if (!await chrome.permissions.contains({ origins: [permissionFor(url)] })) {
    throw new Error("Grant access to this exact destination using Open job.");
  }
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab?.id || tabId !== void 0 && tab.id !== tabId) throw new Error("Keep the approved application tab active.");
  assertExactDestination(tab.url, url);
  if (tab.status !== "complete") throw new Error("Wait for the application page to finish loading.");
  return tab.id;
}
async function bounded(operation, milliseconds) {
  let timeout;
  try {
    return await Promise.race([operation, new Promise((_, reject) => {
      timeout = setTimeout(() => reject(new Error("The page stopped responding. Check the application manually.")), milliseconds);
    })]);
  } finally {
    clearTimeout(timeout);
  }
}
var controller = new ExtensionController({
  api,
  apiOrigin,
  getPending: async () => {
    await sessionReady;
    return (await chrome.storage.session.get(PENDING2))[PENDING2];
  },
  setPending: async (pending) => {
    await sessionReady;
    await chrome.storage.session.set({ [PENDING2]: pending });
  },
  clearPending: async () => {
    await chrome.storage.session.remove(PENDING2);
  },
  hasToken: async () => {
    try {
      return !!await token();
    } catch {
      return false;
    }
  },
  activeTab,
  open: async (url) => {
    if (!await chrome.permissions.contains({ origins: [permissionFor(url)] })) throw new Error("Destination access was not granted.");
    await chrome.tabs.create({ url, active: true });
  },
  inject: async (tabId, url) => {
    await activeTab(url, tabId);
    const results = await chrome.scripting.executeScript({
      target: { tabId, frameIds: [0] },
      files: ["content.js"],
      world: "ISOLATED"
    });
    const documentId = results.find((result) => result.frameId === 0)?.documentId;
    if (!documentId) throw new Error("The top-level application document is unavailable.");
    await activeTab(url, tabId);
    return documentId;
  },
  page: async (tabId, documentId, command) => {
    await activeTab(command.url, tabId);
    const response = await bounded(chrome.tabs.sendMessage(tabId, {
      channel: "jaa:page",
      command: { ...command, expiresAt: Date.now() + 12e3 }
    }, { documentId }), 15e3);
    if (!response?.ok) throw new Error(response?.error || "The application page disconnected.");
    return response.result;
  },
  fixtureConfirmation: async (tabId, approvedUrl) => {
    if (!isFixture(approvedUrl)) return void 0;
    const deadline = Date.now() + 8e3;
    while (Date.now() < deadline) {
      const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (active?.id !== tabId || !active.url) return void 0;
      if (isFixtureReceipt(active.url, approvedUrl) && active.status === "complete") {
        const results = await chrome.scripting.executeScript({
          target: { tabId, frameIds: [0] },
          world: "ISOLATED",
          func: readFixtureReceipt,
          args: [approvedUrl]
        });
        const receipt = results.find((result) => result.frameId === 0)?.result;
        if (receipt) return receipt;
      } else if (active.url !== approvedUrl && !isFixtureReceipt(active.url, approvedUrl)) {
        return void 0;
      }
      await new Promise((resolve) => setTimeout(resolve, 250));
    }
    return void 0;
  }
});
var recovered = sessionReady.then(() => controller.recover());
recovered.catch(() => {
});
var assistance = installAssistanceWorker(api, apiOrigin, () => actionActive || pairing);
function ensurePanelBehavior(attempt = 0) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {
    if (attempt < 4) setTimeout(() => ensurePanelBehavior(attempt + 1), 500 * (attempt + 1));
  });
}
ensurePanelBehavior();
chrome.runtime.onInstalled.addListener(() => ensurePanelBehavior());
var pairing = false;
var actionActive = false;
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id || sender.tab || sender.url !== chrome.runtime.getURL("sidepanel.html") || !message || typeof message !== "object" || message.channel !== "jaa:panel") return;
  const request = message;
  (async () => {
    await recovered;
    const mutating = request.action !== "state";
    if (mutating && (actionActive || assistance.busy())) throw new Error("Another operation is active. Wait for its result.");
    if (mutating) actionActive = true;
    try {
      if (request.action === "pair") {
        if (pairing) throw new Error("Pairing is already in progress.");
        if ((await chrome.storage.session.get(PENDING2))[PENDING2]) throw new Error("Reconcile the existing execution before changing the pairing token.");
        if (typeof request.token !== "string" || !/^[\x21-\x7e]{16,512}$/.test(request.token)) throw new Error("Paste a valid pairing token from the local service.");
        const port = request.port === void 0 ? 4318 : request.port;
        if (typeof port !== "number") throw new Error("Choose the numeric port used by the local service.");
        const assistPending = (await chrome.storage.session.get("chairman.assistPending"))["chairman.assistPending"];
        if (assistPending && port !== ((await chrome.storage.session.get(PORT))[PORT] ?? 4318))
          throw new Error("Re-pair the same service and reconcile the interrupted fill before changing ports.");
        localApiOrigin(port);
        pairing = true;
        const previous = await chrome.storage.session.get([TOKEN, PORT]);
        try {
          await chrome.storage.session.set({ [TOKEN]: request.token, [PORT]: port });
          await api("/api/extension/connect", {});
        } catch (error) {
          await chrome.storage.session.remove([TOKEN, PORT]);
          await chrome.storage.session.set(previous);
          throw error;
        } finally {
          pairing = false;
        }
      } else if (request.action === "recover") {
        await controller.recover();
      } else if (["open", "preflight", "execute"].includes(request.action ?? "")) {
        if (pairing) throw new Error("Wait for pairing to finish.");
        if (typeof request.packetId !== "string" || !request.packetId || request.packetId.length > 200) throw new Error("Select a valid packet.");
        if (request.action === "open") await controller.open(request.packetId);
        if (request.action === "preflight") await controller.preflight(request.packetId);
        if (request.action === "execute") await controller.execute(request.packetId);
      } else if (request.action !== "state") {
        throw new Error("Unknown extension action.");
      }
      return controller.state();
    } finally {
      if (mutating) actionActive = false;
    }
  })().then(
    (state) => respond({ ok: true, state }),
    (error) => respond({ ok: false, error: error instanceof Error ? error.message : "The operation failed." })
  );
  return true;
});
