// apps/extension/safety.ts
var blockedDomains = ["linkedin.com", "lnkd.in", "wellfound.com", "angel.co", "naukri.com", "indeed.com", "indeed.jobs"];
function destination(raw) {
  const url = new URL(raw);
  const host = url.hostname.toLowerCase().replace(/\.$/, "");
  if (blockedDomains.some((domain) => host === domain || host.endsWith(`.${domain}`)) || /(^|\.)indeed\.[a-z.]+$/.test(host)) {
    throw new Error("This site is manual-only. No extension inspection or automation is permitted.");
  }
  if (url.username || url.password || url.hash || host !== url.hostname) {
    throw new Error("Unsupported destination URL.");
  }
  if (url.protocol !== "https:" && !isFixture(raw)) {
    throw new Error("Only HTTPS destinations or the controlled local fixture are supported.");
  }
  if (url.protocol === "https:" && (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || !host.includes(".") || /^[\d.]+$/.test(host) || host.includes(":") || url.port !== "" && url.port !== "443")) throw new Error("Private or nonstandard destination hosts are unsupported.");
  return url;
}
function isFixture(raw) {
  const url = new URL(raw);
  return url.protocol === "http:" && url.hostname === "127.0.0.1" && Number(url.port) >= 1024 && url.pathname === "/fixture/application" && !url.hash && !url.username && !url.password;
}
function decodeResume(resume) {
  if (!resume || !["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"].includes(resume.mime) || typeof resume.filename !== "string" || !/^[^/\\\x00-\x1f]{1,150}\.(pdf|docx)$/i.test(resume.filename) || typeof resume.base64 !== "string" || resume.base64.length > 14e6 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(resume.base64)) {
    throw new Error("The approved resume is invalid or exceeds the 10 MB limit.");
  }
  const bytes = Uint8Array.from(atob(resume.base64), (char) => char.charCodeAt(0));
  if (!bytes.length || bytes.length > 1e7) throw new Error("The approved resume is empty or too large.");
  const pdf = resume.mime === "application/pdf";
  if (pdf ? !resume.filename.toLowerCase().endsWith(".pdf") || new TextDecoder().decode(bytes.slice(0, 5)) !== "%PDF-" : !resume.filename.toLowerCase().endsWith(".docx") || bytes[0] !== 80 || bytes[1] !== 75) {
    throw new Error("The resume content does not match its approved file type.");
  }
  return bytes;
}

// apps/extension/assist-safety.ts
function publicJobToken(url, key, value) {
  return key === "token" && /^\d{1,20}$/.test(value) && ["boards.greenhouse.io", "job-boards.greenhouse.io"].includes(url.hostname.toLowerCase()) && url.pathname === "/embed/job_app";
}
function assistanceDestination(raw) {
  const url = new URL(raw);
  const hash = url.hash;
  url.hash = "";
  destination(url.href);
  const host = url.hostname.toLowerCase();
  if (/(^|\.)indeed\.[a-z.]+$/.test(host) || host === "indeed.jobs" || host.endsWith(".indeed.jobs"))
    throw new Error("Indeed is manual-only; Chairman does not inspect or automate it.");
  if (/(?:^|\/)(?:login|signin|sign-in|auth|oauth|account|accounts|register|signup)(?:\/|$)/i.test(url.pathname))
    throw new Error("Account and sign-in pages are manual-only. Sign in yourself, then return to the public application.");
  if ([...url.searchParams.entries()].some(([key, value]) => /password|secret|token|code|session|auth|email/i.test(key) && !publicJobToken(url, key, value)))
    throw new Error("Pages with credential/session parameters cannot be inspected. Open the public job URL.");
  if (!isFixture(url.href) && /(^|\.)indeed\./.test(host)) throw new Error("This platform is manual-only.");
  url.hash = hash;
  return url;
}
function assistancePermission(raw) {
  const url = assistanceDestination(raw);
  return `${url.protocol}//${url.hostname}/*`;
}

// apps/extension/assist-panel.ts
var AI_SETTING = "chairman.assistAi";
var DRIVE_SETTING = "chairman.autoContinue";
var element = (id) => document.getElementById(`assist-${id}`);
var rows = /* @__PURE__ */ new Map();
var state;
var busy = false;
var planSignature = "";
var resultSignature = "";
var moreSignature = "";
var debugSignature = "";
var sessionSignature = "";
var activeUrl;
var activeTabId;
var sourceLabels = {
  profile: ["Profile", ""],
  answers: ["Saved answer", ""],
  remembered: ["Remembered", ""],
  acknowledgement: ["Acknowledged for you", "fix"],
  ai_mapped: ["AI-matched saved answer", "ai"],
  ai_option: ["AI choice", "ai"],
  ai_draft: ["AI draft", "ai"],
  repair: ["Suggested fix", "fix"],
  manual: ["Needs you", "you"]
};
async function refreshActiveUrl() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  activeUrl = tab?.url;
  activeTabId = tab?.id;
}
function text(tag, value, className) {
  const node = document.createElement(tag);
  node.textContent = value;
  if (className) node.className = className;
  return node;
}
function choice(value, label) {
  const node = text("option", label);
  node.value = value;
  return node;
}
function error(value) {
  element("error").hidden = false;
  element("error").textContent = value instanceof Error ? value.message : "The action failed.";
}
function selected(selector) {
  return [...document.querySelectorAll(selector)].filter((input) => input.checked).map((input) => input.value);
}
function resetConsent() {
  element("confirm").checked = false;
  element("fill").disabled = true;
}
async function request(action, extra = {}) {
  const result = await chrome.runtime.sendMessage({ channel: "chairman:panel", action, ...extra });
  if (result?.state) {
    state = result.state;
    render(state);
  }
  if (!result?.ok) {
    const failed = result?.state?.debug.runs[0];
    const where = failed?.action === action && failed.failedAt ? `Failed at step "${failed.failedAt}": ` : "";
    if (where) element("debug").open = true;
    throw new Error(`${where}${result?.error || "Chairman worker did not respond."}`);
  }
  return result;
}
async function run(action, extra = {}, working) {
  if (busy) return;
  busy = true;
  element("error").hidden = true;
  if (working) {
    element("activity").hidden = false;
    element("activity").textContent = working;
  }
  try {
    const result = await request(action, extra);
    if (result.artifact) {
      const artifact = result.artifact;
      const bytes = decodeResume(artifact);
      const hash = [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map((byte) => byte.toString(16).padStart(2, "0")).join("");
      if (hash !== artifact.sha256) throw new Error("The preview bytes do not match the reviewed resume.");
      const url = URL.createObjectURL(new Blob([bytes], { type: artifact.mime }));
      const link = text("a", "Open reviewed resume");
      link.href = url;
      if (extra.format === "pdf") {
        link.target = "_blank";
        link.rel = "noopener";
      } else link.download = artifact.filename;
      document.body.append(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 6e4);
    }
  } catch (value) {
    error(value);
  } finally {
    busy = false;
    if (state) render(state);
  }
}
function aiStatus(plan) {
  const ai = plan.ai, used = ai.asked + ai.cached;
  if (!ai.enabled) return "AI help is off for this plan; only your saved answers were used.";
  const who = ai.provider ? `${ai.provider}${ai.model ? ` (${ai.model})` : ""}${ai.remote ? ", hosted" : ", on this computer"}` : "your configured AI";
  if (ai.reason) return `AI help: ${ai.reason}`;
  if (!used) return "AI help was not needed: every answerable question matched a saved answer.";
  return `AI help from ${who}: ${ai.asked} question${ai.asked === 1 ? "" : "s"} asked, ${ai.cached} reused from earlier identical questions. Suggestions are checked against your confirmed facts.`;
}
function row(item) {
  const onPage = item.source === "manual" && /^Already answered/.test(item.reason ?? "");
  const li = document.createElement("li");
  li.className = `plan-row${item.review ? " review" : ""}${onPage ? " muted" : ""}`;
  const head = document.createElement("label");
  head.className = "plan-head";
  const include = document.createElement("input");
  include.type = "checkbox";
  include.checked = item.include;
  include.disabled = onPage;
  include.setAttribute("aria-label", `Fill ${item.label}`);
  const name = text("span", item.label, "plan-label");
  if (item.required) {
    const star = text("span", "*", "required");
    star.title = "Required";
    name.append(star);
  }
  const [badge, tone] = onPage ? ["On the page", ""] : item.source === "manual" && !item.required ? ["Optional", ""] : sourceLabels[item.source];
  head.append(include, name, text("span", badge, `badge ${tone}`));
  li.append(head);
  let editor;
  if (!onPage) {
    if (item.options?.length) {
      const select = document.createElement("select");
      select.append(choice("", "Choose\u2026"), ...item.options.map((option) => choice(option.value, option.label)));
      select.value = item.value ?? "";
      editor = select;
    } else if (item.type === "textarea" || (item.value?.length ?? 0) > 90) {
      const area = document.createElement("textarea");
      area.value = item.value ?? "";
      if (item.maxLength) area.maxLength = item.maxLength;
      editor = area;
    } else {
      const input = document.createElement("input");
      input.type = "text";
      input.value = item.value ?? "";
      if (item.maxLength) input.maxLength = item.maxLength;
      editor = input;
    }
    editor.setAttribute("aria-label", `Answer for ${item.label}`);
    li.append(editor);
  }
  const note = item.reason ?? item.detail;
  if (note) li.append(text("p", note, "plan-note"));
  let remember;
  if (editor) {
    const wrap = document.createElement("label");
    wrap.className = "plan-remember";
    wrap.hidden = true;
    remember = document.createElement("input");
    remember.type = "checkbox";
    wrap.append(remember, document.createTextNode("Remember this answer for this exact question"));
    li.append(wrap);
    const offer = () => {
      const value = editor.value, changed = value !== (item.value ?? "");
      if (value.trim() && changed && !include.checked) include.checked = true;
      if (!value.trim() && include.checked) include.checked = false;
      const show = !!value.trim() && (changed || ["manual", "acknowledgement", "ai_mapped", "ai_option", "ai_draft", "repair"].includes(item.source));
      if (show && wrap.hidden && item.source === "manual" && changed) remember.checked = true;
      wrap.hidden = !show;
      if (!show) remember.checked = false;
    };
    offer();
    for (const type of ["input", "change"]) editor.addEventListener(type, () => {
      offer();
      resetConsent();
    });
  }
  include.addEventListener("change", resetConsent);
  remember?.addEventListener("change", resetConsent);
  rows.set(item.key, { item, include, editor, remember });
  return li;
}
function renderPlan(plan) {
  const signature = plan ? `${plan.planHash}:${plan.items.length}:${plan.resume?.options.length ?? 0}` : "";
  if (signature === planSignature) return;
  planSignature = signature;
  rows.clear();
  resetConsent();
  element("plan-box").hidden = !plan;
  if (!plan) {
    element("fields").replaceChildren();
    return;
  }
  const ready = plan.items.filter((item) => item.include && item.value !== void 0).length;
  const needs = plan.items.filter((item) => item.source === "manual" && item.required && !/^Already answered/.test(item.reason ?? "")).length;
  const optional = plan.items.filter((item) => item.source === "manual" && !item.required && !/^Already answered/.test(item.reason ?? "")).length;
  const fromAi = plan.items.filter((item) => item.source.startsWith("ai_")).length;
  element("summary").textContent = `${ready} answer${ready === 1 ? "" : "s"}${plan.resume?.selected ? " + resume" : ""} ready to fill \xB7 ${needs} required need${needs === 1 ? "s" : ""} you${optional ? ` \xB7 ${optional} optional left blank` : ""}${fromAi ? ` \xB7 ${fromAi} from AI (highlighted)` : ""}`;
  element("ai-status").textContent = aiStatus(plan);
  element("fields").replaceChildren(...plan.items.map(row));
  const resume = plan.resume;
  element("resume-box").hidden = !resume;
  if (resume) {
    const select = element("resume");
    select.replaceChildren(choice("", "Do not attach a resume"), ...resume.options.map((option) => choice(option.id, option.label)));
    select.value = resume.selected ?? "";
    element("resume-note").textContent = [`Upload field: ${resume.label}${resume.required ? " (required)" : ""}.`, resume.reason ?? ""].join(" ").trim();
  }
  element("blockers").replaceChildren(...plan.blockers.map((blocker) => text("span", blocker, "blocker-line")));
}
function renderResult(next) {
  const result = next.result, show = !!result && result.url === (next.page?.url ?? next.url);
  const signature = show ? `${result.at}` : "";
  if (signature === resultSignature) return;
  resultSignature = signature;
  const box = element("result");
  box.hidden = !show;
  if (!show) {
    box.replaceChildren();
    return;
  }
  const summary = `Filled ${result.filled} \xB7 kept ${result.preserved} existing${result.errors.length ? ` \xB7 ${result.errors.length} need attention` : ""}${result.remembered ? ` \xB7 remembered ${result.remembered}` : ""}`;
  const list = document.createElement("ul");
  for (const item of result.errors) list.append(text("li", `${item.label}: ${item.message}`));
  for (const item of result.skipped) list.append(text("li", `${item.label}: ${item.reason}`));
  for (const blocker of result.blockers) list.append(text("li", blocker));
  box.replaceChildren(
    text("strong", summary),
    ...list.childElementCount ? [list] : [],
    ...result.repairs ? [text("p", "Suggested fixes are highlighted in the refreshed plan above. Review them, then fill again.", "help")] : [],
    text("p", "Filled is not applied. Check the page, click Next or Submit yourself, then plan the next page.", "help")
  );
}
function renderMore(next) {
  const signature = JSON.stringify({ page: next.page?.fingerprint, job: next.page?.job?.title, record: next.review?.record, packet: next.review?.packet?.id });
  if (signature === moreSignature) return;
  moreSignature = signature;
  const captured = next.page?.job, review = next.review;
  element("job").replaceChildren();
  if (captured) {
    element("job").append(text("h3", captured.title), text("p", `${captured.company || "Employer name needs confirmation"} | ${captured.location || "Location not stated"}`));
    const details = document.createElement("details");
    details.append(text("summary", `Captured JD (${captured.evidence})`), text("pre", captured.description));
    element("job").append(details);
    if (!captured.company) {
      const label = text("label", "Employer shown on this posting");
      const input = document.createElement("input");
      input.id = "assist-company";
      input.maxLength = 300;
      label.append(input);
      element("job").append(label);
    }
  } else element("job").append(text("p", "No job description on this page. Tailoring needs the job description page; filling does not.", "help"));
  element("import").disabled = !captured;
  element("review-box").hidden = !review;
  if (!review) return;
  element("variant").replaceChildren(...review.variants.map((variant) => {
    const option = choice(variant.id, `${variant.label} (${variant.artifact.format.toUpperCase()})`);
    option.selected = variant.id === (review.packet?.variantId ?? review.suggestedVariantId);
    return option;
  }));
  element("suggestion").textContent = review.suggestion ?? "Approve a baseline in homepage setup.";
  element("packet").hidden = !review.packet;
  if (!review.packet) return;
  const packet = review.packet;
  const ordered = [...packet.draft.factIds, ...review.factOptions.map((fact) => fact.id).filter((id) => !packet.draft.factIds.includes(id))];
  element("facts").replaceChildren(...ordered.map((id) => {
    const fact = review.factOptions.find((item) => item.id === id);
    const factRow = document.createElement("div");
    factRow.className = "assist-fact";
    const label = document.createElement("label"), input = document.createElement("input");
    input.type = "checkbox";
    input.value = id;
    input.checked = packet.draft.factIds.includes(id);
    label.append(input, document.createTextNode(`${fact.category}: ${fact.text}`));
    factRow.append(label);
    for (const [title, direction] of [["Up", -1], ["Down", 1]]) {
      const button = text("button", title, "quiet");
      button.type = "button";
      button.addEventListener("click", () => {
        const neighbor = direction === -1 ? factRow.previousElementSibling : factRow.nextElementSibling;
        if (neighbor) direction === -1 ? factRow.parentElement.insertBefore(factRow, neighbor) : factRow.parentElement.insertBefore(neighbor, factRow);
      });
      factRow.append(button);
    }
    return factRow;
  }));
  element("skills").replaceChildren(...[.../* @__PURE__ */ new Set([...packet.draft.skills, ...review.skillOptions])].map((skill) => {
    const label = document.createElement("label"), input = document.createElement("input");
    label.className = "assist-check";
    input.type = "checkbox";
    input.value = skill;
    input.checked = packet.draft.skills.includes(skill);
    label.append(input, document.createTextNode(skill));
    return label;
  }));
  const content = packet.resumeContent;
  element("content").textContent = content ? [
    content.name,
    content.email,
    content.phone,
    content.location,
    ...Object.values(content.links),
    content.skills.join(", "),
    ...content.facts.map((fact) => [fact.employer, fact.role, fact.dates, fact.text].filter(Boolean).join(" | "))
  ].join("\n\n") : "Preview the packet PDF/DOCX before proceeding.";
}
function renderDebug(next) {
  element("verbose").checked = next.debug.verbose;
  const runs = next.debug.runs;
  const signature = runs.map((run2) => `${run2.id}:${run2.steps.length}:${run2.ms ?? ""}:${run2.failedAt ?? ""}`).join("|");
  if (signature === debugSignature) return;
  debugSignature = signature;
  element("debug-runs").replaceChildren(...runs.map((run2, index) => {
    const item = document.createElement("li");
    item.className = run2.failedAt ? "debug-run-failed" : "";
    const details = document.createElement("details");
    details.open = index === 0;
    details.append(text("summary", `${run2.failedAt ? "\u2717" : run2.ms === void 0 ? "\u2026" : "\u2713"} ${run2.action} \xB7 ${new Date(run2.at).toLocaleTimeString()}${run2.ms !== void 0 ? ` \xB7 ${run2.ms} ms` : ""}${run2.failedAt ? ` \xB7 failed at "${run2.failedAt}": ${run2.error ?? ""}` : ""}`));
    const steps = document.createElement("ol");
    steps.className = "debug-steps";
    for (const entry of run2.steps) {
      const line = document.createElement("li");
      if (entry.ok === false) line.className = "failed";
      line.append(text("span", `+${entry.t}ms`, "source"), text("span", ` ${entry.source} `, "source"), document.createTextNode(`${entry.ok === false ? "\u2717 " : ""}${entry.step}${entry.detail ? ` \u2014 ${entry.detail}` : ""}`));
      steps.append(line);
    }
    details.append(steps);
    item.append(details);
    return item;
  }));
  if (!runs.length) element("debug-runs").append(text("li", "No actions recorded yet. Plan or fill a page to see its steps.", "help"));
}
function debugReport(runs) {
  return JSON.stringify({
    tool: "Chairman page assistance",
    extensionVersion: chrome.runtime.getManifest().version,
    generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    note: "Value-free: labels, counts, timings and errors only.",
    runs
  }, null, 2);
}
var STAGES = { manual: "You", working: "Filling", needs_you: "Needs you", review: "Ready for your review", submitted: "Applied \u2713", paused: "Paused" };
function renderSession(next) {
  const tab = next.tab;
  const banner = element("tab-stage");
  banner.hidden = !tab;
  if (tab) {
    banner.className = `stage-banner ${tab.stage}`;
    element("tab-stage-title").textContent = `${STAGES[tab.stage]} \xB7 ${tab.company ? `${tab.company}: ` : ""}${tab.title}`;
    element("tab-stage-text").textContent = tab.stage === "review" ? "Chairman filled every step it could and stopped before Submit. Review each answer on the page (use the form's Back button to check earlier steps), then submit yourself." : tab.stage === "submitted" ? "The employer's confirmation page was seen; this role counts as applied." : tab.stage === "paused" ? "Chairman does nothing more in this tab until you press Continue automatically." : tab.stage === "needs_you" ? "Do what the message above asks in this tab; Chairman continues on its own afterwards (or press Continue)." : "Chairman is working in this tab. You can switch to another tab meanwhile.";
    element("tab-continue").hidden = !["needs_you", "paused", "review"].includes(tab.stage);
    element("tab-continue").textContent = tab.stage === "review" ? "Fill this step again" : "Continue automatically";
    element("tab-pause").hidden = !["working", "needs_you"].includes(tab.stage);
    element("tab-skip").hidden = tab.stage === "submitted" || !tab.session;
  }
  const current = next.session;
  const active = current?.status === "active";
  element("session-start").hidden = active;
  const signature = JSON.stringify(current ?? null);
  if (signature === sessionSignature) return;
  sessionSignature = signature;
  element("session").hidden = !current;
  if (!current) {
    element("session-tabs").replaceChildren();
    return;
  }
  element("session-title").textContent = active ? `Session ${current.number}: ${current.finished} of ${current.size} finished` : current.status === "complete" ? `Session ${current.number} finished: ${current.submitted} applied of ${current.size}` : `Session ${current.number} stopped`;
  element("session-counts").textContent = active ? `${current.open} open \xB7 ${current.queued} waiting to open \xB7 ${current.submitted} applied${current.available ? ` \xB7 ${current.available} more to-do roles today` : ""}` : current.available ? `${current.available} to-do roles are left today. Start the next session below.` : "No to-do roles are left on today's list.";
  element("session-next").hidden = !active || !current.queued;
  element("session-stop").hidden = !active;
  const order = ["needs_you", "review", "working", "paused", "submitted", "manual"];
  element("session-tabs").replaceChildren(...[...current.tabs].sort((a, b) => order.indexOf(a.stage) - order.indexOf(b.stage)).map((item) => {
    const li = document.createElement("li");
    const who = document.createElement("div");
    who.append(text("div", `${item.company}: ${item.title}`, "who"), text("div", item.message.length > 140 ? `${item.message.slice(0, 140)}\u2026` : item.message, "what"));
    const go = text("button", "Go to tab", "quiet");
    go.type = "button";
    go.addEventListener("click", () => {
      void request("go-to-tab", { tabId: item.tabId }).catch(error);
    });
    li.append(text("span", STAGES[item.stage], `stage-chip ${item.stage}`), who, go);
    return li;
  }));
}
function render(next) {
  renderDebug(next);
  renderSession(next);
  element("message").textContent = next.message;
  const activity = element("activity");
  if (!busy) {
    activity.hidden = !next.activity;
    activity.textContent = next.activity ?? "";
  }
  element("url").textContent = activeTabId !== void 0 && !activeUrl ? "This tab is hidden from Chairman until you allow its site: click Allow on this site." : activeUrl && next.page?.url !== activeUrl ? activeUrl : next.page?.url ?? next.url ?? "No site allowed yet";
  const current = !!next.plan && !!next.page && next.plan.url === next.page.url && next.plan.pageFingerprint === next.page.fingerprint;
  const stale = !!next.plan && !!next.page && next.plan.url === next.page.url && !current;
  element("state").textContent = current ? "Plan matches this page" : stale ? "Page changed; plan again" : "";
  element("plan").textContent = current || stale ? "Plan again" : "Plan answers for this page";
  element("quick").textContent = next.result && next.page?.url === next.result.url ? "Fill again" : "Fill everything";
  const missing = next.sites?.missing ?? [];
  element("sites").hidden = !missing.length;
  if (missing.length) element("sites-text").textContent = `Chrome has not allowed Chairman on ${missing.length} of your companies' application site${missing.length === 1 ? "" : "s"} yet (${missing.slice(0, 3).map((origin) => origin.slice(8, -2)).join(", ")}${missing.length > 3 ? ", \u2026" : ""}). Allow them once so each role from Today fills with one click.`;
  const embedded = next.page?.embedded;
  element("embedded").hidden = !embedded;
  if (embedded) element("embedded-text").textContent = `This application form is embedded from ${embedded.host}. Chairman fills it on its own page, after you allow that site.`;
  renderPlan(current ? next.plan : void 0);
  renderResult(next);
  renderMore(next);
}
element("grant").addEventListener("click", () => {
  const url = activeUrl;
  if (!url) {
    if (activeTabId === void 0) {
      error(new Error("Open the job application tab first."));
      return;
    }
    if (typeof chrome.permissions.addHostAccessRequest === "function") chrome.permissions.addHostAccessRequest({ tabId: activeTabId }).catch(() => void 0);
    error(new Error("Chrome hides this tab from Chairman until you allow the site. Click the Chairman icon (C) in Chrome's toolbar while this tab is open; Chrome will ask to allow the site. Choose Allow."));
    return;
  }
  let permission;
  try {
    permission = assistancePermission(url);
  } catch (value) {
    error(value);
    return;
  }
  chrome.permissions.request({ origins: [permission] }).then((granted) => {
    if (!granted) throw new Error("Site permission was denied. Nothing was inspected or filled.");
    return run("authorize", { url });
  }).catch(error);
});
element("open-embedded").addEventListener("click", () => {
  const embedded = state?.page?.embedded;
  if (!embedded) return;
  let permission;
  try {
    permission = assistancePermission(embedded.url);
  } catch (value) {
    error(value);
    return;
  }
  chrome.permissions.request({ origins: [permission] }).then((granted) => {
    if (!granted) throw new Error(`Access to ${embedded.host} was denied. Open the form yourself to continue.`);
    return run("open-embedded");
  }).catch(error);
});
element("notify").addEventListener("click", () => {
  chrome.permissions.request({ permissions: ["notifications"] }).then((granted) => {
    if (!granted) throw new Error("Notifications were declined; the side panel and badge still show intervention reasons.");
    element("message").textContent = "Private intervention alerts enabled. Notifications contain no applicant or employer details.";
  }).catch(error);
});
element("quick").addEventListener("click", () => {
  const ai = element("ai").checked, drive = element("drive").checked;
  void run("quick-fill", { ai, drive }, drive ? "Starting: Chairman works through this application step by step and stops before Submit\u2026" : "Filling everything Chairman knows on this page\u2026");
});
element("drive").addEventListener("change", () => {
  void chrome.storage.local.set({ [DRIVE_SETTING]: element("drive").checked });
});
element("sites-allow").addEventListener("click", () => {
  const missing = state?.sites?.missing ?? [];
  if (!missing.length) return;
  chrome.permissions.request({ origins: missing }).then((granted) => {
    if (!granted) throw new Error("Chrome did not allow the sites. You can still allow each site with the toolbar icon.");
    return run("sites-allowed");
  }).catch(error);
});
element("plan").addEventListener("click", () => {
  const ai = element("ai").checked;
  void run("plan", { ai }, ai ? "Planning answers. Questions without a saved answer may be sent to your configured AI; this can take up to a minute\u2026" : "Planning answers from your saved information\u2026");
});
element("ai").addEventListener("change", () => {
  void chrome.storage.local.set({ [AI_SETTING]: element("ai").checked });
});
element("verbose").addEventListener("change", () => {
  void request("debug", { verbose: element("verbose").checked }).catch(error);
});
element("clear-debug").addEventListener("click", () => {
  void request("debug-clear").catch(error);
});
element("copy-debug").addEventListener("click", () => {
  const runs = state?.debug.runs ?? [];
  navigator.clipboard.writeText(debugReport(runs)).then(() => {
    element("message").textContent = `Debug report copied (${runs.length} action${runs.length === 1 ? "" : "s"}). It contains labels, counts, timings and errors, never your answers or files.`;
  }).catch(error);
});
for (const [id, action] of [["scan", "scan"], ["home", "home"], ["recover", "recover"]])
  element(id).addEventListener("click", () => {
    void run(action);
  });
element("confirm").addEventListener("change", () => {
  element("fill").disabled = !element("confirm").checked;
});
element("resume").addEventListener("change", resetConsent);
element("fill").addEventListener("click", () => {
  const plan = state?.plan;
  if (!element("confirm").checked || !plan) {
    error(new Error("Review the plan and confirm it first."));
    return;
  }
  const include = [], edits = {}, remember = [];
  for (const [key, { item, include: box, editor, remember: keep }] of rows) {
    if (!box.checked) continue;
    const value = editor?.value ?? item.value ?? "";
    if (!value.trim()) continue;
    include.push(key);
    if (value !== (item.value ?? "")) edits[key] = value;
    if (keep?.checked && !keep.parentElement?.hidden) remember.push(key);
  }
  const resume = plan.resume ? element("resume").value || null : null;
  void run("fill", { confirm: true, planHash: plan.planHash, include, edits, remember, resume }, "Filling this page\u2026");
});
element("session-begin").addEventListener("click", () => {
  void chrome.windows.getCurrent().then((window) => run("session-start", { windowId: window.id }, "Starting your session and opening the first roles\u2026")).catch(error);
});
element("session-next").addEventListener("click", () => {
  void run("session-next", {}, "Opening the next roles\u2026");
});
element("session-stop").addEventListener("click", () => {
  if (confirm("Stop this session? Open tabs stay open, and nothing more is filled automatically.")) void run("session-stop");
});
element("tab-continue").addEventListener("click", () => {
  void run("tab-continue", {}, "Continuing in this tab\u2026");
});
element("tab-pause").addEventListener("click", () => {
  void run("tab-pause");
});
element("tab-skip").addEventListener("click", () => {
  if (confirm("Skip this role? It will not be opened again in this session.")) void run("tab-skip");
});
element("import").addEventListener("click", () => {
  void run("import", { company: document.querySelector("#assist-company")?.value, confirm: true });
});
element("review").addEventListener("click", () => {
  void run("review", { confirm: true });
});
element("prepare").addEventListener("click", () => {
  void run("prepare", { variantId: element("variant").value || void 0, mode: element("mode").value, confirm: true }, "Preparing the job-specific resume\u2026");
});
element("edit").addEventListener("click", () => {
  void run("edit", { factIds: selected("#assist-facts input"), skills: selected("#assist-skills input"), confirm: true });
});
for (const format of ["pdf", "docx"]) element(format).addEventListener("click", () => {
  void run("artifact", { format });
});
element("queue").addEventListener("click", () => {
  void run("queue", { confirm: true });
});
element("record-receipt").addEventListener("click", () => {
  void run("receipt", { confirmation: element("receipt").value, submittedDate: element("date").value, confirm: true });
});
void chrome.storage.local.get(AI_SETTING).then((value) => {
  if (value[AI_SETTING] === false) element("ai").checked = false;
});
void chrome.storage.local.get(DRIVE_SETTING).then((value) => {
  if (value[DRIVE_SETTING] === false) element("drive").checked = false;
});
void run("state");
void refreshActiveUrl().catch(error);
setInterval(() => {
  if (!busy) void request("state").catch(error);
  void refreshActiveUrl().catch(error);
}, 1500);
